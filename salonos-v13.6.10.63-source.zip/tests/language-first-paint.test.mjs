import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { extname } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright-core';

const php = process.env.SALONOS_TEST_PHP ?? 'C:/xampp/php/php.exe';
const chrome = process.env.SALONOS_TEST_CHROME ?? 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const fixture = fileURLToPath(new URL('language-shell.php', import.meta.url));
const base = 'http://salonos.test/v13/index.php';
const mime = { '.js': 'application/javascript', '.css': 'text/css', '.json': 'application/json' };
const browser = await chromium.launch({ executablePath: chrome, headless: true });
let dictionaryResponse = 'slow';
let scriptFails = false;
let dictionaryRequests = 0;

async function routeSite(page, language, role) {
  await page.route('http://salonos.test/**', async (route) => {
    const url = new URL(route.request().url());
    const file = url.pathname.slice('/v13/'.length);
    if (file === 'index.php') {
      const body = execFileSync(php, [fixture, language, url.searchParams.get('page') ?? 'settings', role], { encoding: 'utf8' });
      return route.fulfill({ contentType: 'text/html; charset=utf-8', body });
    }
    if (file === 'assets/i18n-en.json') {
      dictionaryRequests++;
      if (dictionaryResponse === 'slow') await delay(950);
      if (dictionaryResponse === 'error') return route.fulfill({ status: 503 });
    }
    if (scriptFails && file === 'assets/i18n.js') return route.fulfill({ status: 503 });
    if (mime[extname(file)] && file.startsWith('assets/')) {
      const body = await readFile(new URL(`../v13/${file}`, import.meta.url));
      return route.fulfill({ contentType: mime[extname(file)], body });
    }
    return route.fulfill({ status: 404 });
  });
}

async function assertEnglish(page, name) {
  await page.waitForSelector('html.i18n-en-ready');
  assert.equal(await page.locator('h1').textContent(), name);
  assert.match(await page.title(), new RegExp(`^${name} · `));
  assert.equal(await page.locator('.app').evaluate((el) => getComputedStyle(el).opacity), '1');
  assert.equal(await page.locator('.i18n-status').isVisible(), false);
  const observed = await page.evaluate(() => window.salonosFirstVisibleHeading);
  assert.equal(observed, name);
}

try {
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await page.addInitScript(() => {
    function inspectPaint() {
      const app = document.querySelector('.app');
      const heading = app?.querySelector('h1');
      if (heading && getComputedStyle(app).opacity === '1' && getComputedStyle(app).visibility === 'visible') {
        window.salonosFirstVisibleHeading = heading.textContent.trim();
      } else requestAnimationFrame(inspectPaint);
    }
    requestAnimationFrame(inspectPaint);
  });
  await routeSite(page, 'en', 'owner');
  await page.goto(`${base}?page=settings`, { waitUntil: 'commit' });
  await page.locator('.app').waitFor({ state: 'attached' });
  assert.equal(await page.title(), 'System Settings · SalonOS');
  assert.equal(await page.locator('.app').evaluate((el) => getComputedStyle(el).opacity), '0');
  assert.equal(await page.getByRole('status').first().isVisible(), true);
  await assertEnglish(page, 'System Settings');
  assert.doesNotMatch(await page.locator('main.content').innerText(), /[\u3400-\u9fff]/);
  assert.equal(dictionaryRequests, 1, 'English boot reuses the dictionary preload');

  await page.locator('a[href="index.php?page=orders"]').evaluate((link) => link.click());
  await page.waitForURL('**/index.php?page=orders', { waitUntil: 'commit' });
  await assertEnglish(page, 'Service Floor');
  await page.locator('#late-label').evaluate((button) => { button.textContent = '关闭'; });
  await page.waitForFunction(() => document.querySelector('#late-label').textContent === 'Close');
  await page.goBack({ waitUntil: 'commit' });
  await assertEnglish(page, 'System Settings');

  dictionaryResponse = 'error';
  await page.reload();
  await page.getByRole('link', { name: 'Reload page' }).waitFor();
  assert.equal(await page.locator('.app').evaluate((el) => getComputedStyle(el).opacity), '0');
  dictionaryResponse = 'fast';
  await page.getByRole('link', { name: 'Reload page' }).click();
  await assertEnglish(page, 'System Settings');

  scriptFails = true;
  await page.reload();
  await page.getByRole('alert').filter({ hasText: 'The English interface could not load' }).waitFor();
  assert.equal(await page.locator('.app').evaluate((el) => getComputedStyle(el).opacity), '0');
  scriptFails = false;

  const staff = await browser.newPage();
  await staff.addInitScript(() => {
    document.addEventListener('DOMContentLoaded', () => {
      const observer = new MutationObserver(() => {
        if (document.documentElement.classList.contains('i18n-en-ready')) {
          window.salonosFirstVisibleHeading = document.querySelector('h1').textContent;
          observer.disconnect();
        }
      });
      observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    });
  });
  await routeSite(staff, 'en', 'staff');
  await staff.goto(`${base}?page=orders`);
  await assertEnglish(staff, 'Service Floor');
  assert.equal(await staff.locator('body').getAttribute('class'), 'employee-shell');

  const chinese = await browser.newPage();
  const beforeChinese = dictionaryRequests;
  await routeSite(chinese, 'zh', 'owner');
  await chinese.goto(`${base}?page=settings`);
  assert.equal(await chinese.locator('html').getAttribute('lang'), 'zh-CN');
  assert.equal(await chinese.locator('h1').textContent(), '系统设置');
  assert.equal(await chinese.locator('.app').evaluate((el) => getComputedStyle(el).opacity), '1');
  assert.equal(dictionaryRequests, beforeChinese);
  console.log('English first paint passed: delayed dictionary, owner and staff, navigation/back, dynamic labels, failure and retry, Chinese mode.');
} finally {
  await browser.close();
}
