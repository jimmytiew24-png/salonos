<?php
declare(strict_types=1);

// Render the production shell without a live login or Supabase connection.
$app=dirname(__DIR__).'/v13';
require $app.'/v12_feature_bridge.php';
$source=file_get_contents($app.'/index.php');
$start=strpos($source,'function salonos_shell_title(');
$end=strpos($source,"\nif (!user()) {",$start);
eval(str_replace('__DIR__',var_export($app,true),substr($source,$start,$end-$start)));

function salonos_app_version(): string {return trim(file_get_contents(dirname(__DIR__).'/v13/VERSION'));}
function salonos_asset_version(): string {return salonos_app_version();}
function salonos_supabase_identity(): array {return ['organization_name'=>'SalonOS','stores'=>[['id'=>'fixture']]];}
function salonos_v1361055_owner_avatar_url(): string {return '';}
function salonos_v1354_employee_avatar_url(): string {return '';}
function v1361062_is_uuid(mixed $value): bool {return false;}
function v135_runtime_contract_info(): array {return ['ok'=>true];}
function current_store(): array {return ['name'=>'SalonOS'];}
function v13_is_owner(): bool {return ($GLOBALS['argv'][3]??'owner')==='owner';}
function user(): array {return ['employee_name'=>'Fixture','role'=>'manager'];}
function csrf_token(): string {return 'fixture';}
function ui_icon(string $icon): string {return '';}
function e(string $text): string {return htmlspecialchars($text,ENT_QUOTES,'UTF-8');}

$_SESSION['v1361051_ui_language']=$argv[1]??'en';
$page=$argv[2]??'settings';
$title=v132_titles()[$page];
render_shell_start($title,$page);
if($page==='settings') v132_page_settings_hub();
else echo '<h1>'.e($title).'</h1><button id="late-label">Close</button>';
render_shell_end();
