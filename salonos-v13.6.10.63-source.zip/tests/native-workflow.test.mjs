import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { mkdtemp, readFile, realpath } from 'node:fs/promises';
import { createServer } from 'node:net';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import EmbeddedPostgres from 'embedded-postgres';
import { Client } from 'pg';
import { verifyWhatsApp } from './whatsapp-workflow.mjs';

const read = (path) => readFile(new URL(path, import.meta.url), 'utf8');
const id = (n) => '00000000-0000-4000-8000-' + String(n).padStart(12, '0');
const [org, store, owner, employee, service] = [1, 2, 3, 10, 20].map(id);
const sql = (client, statement, args = []) => client.query(statement, args);
const one = async (client, statement, args) => (await sql(client, statement, args)).rows[0];
const value = async (...args) => Object.values(await one(...args))[0];

const probe = createServer();
await new Promise((resolve, reject) => {
  probe.once('error', reject);
  probe.listen(0, '127.0.0.1', resolve);
});
const { port } = probe.address();
await new Promise((resolve) => probe.close(resolve));
const temp = await realpath(tmpdir());
const databaseDir = await realpath(await mkdtemp(join(temp, 'salonos-acceptance-')));
assert.equal(dirname(databaseDir), temp);
const password = randomBytes(24).toString('hex');
const server = new EmbeddedPostgres({
  databaseDir, port, user: 'salonos_test', password, persistent: false,
  initdbFlags: ['--locale=C', '--encoding=UTF8', '--no-sync'],
  postgresFlags: ['-h', '127.0.0.1'],
  onLog: (line) => { if (process.env.SALONOS_PG_LOG) process.stderr.write(line); },
  onError: (line) => process.stderr.write(String(line)),
});
const clients = [];
async function connect() {
  const client = new Client({
    host: '127.0.0.1', port, database: 'postgres', user: 'salonos_test', password,
    statement_timeout: 15000,
  });
  await client.connect();
  clients.push(client);
  return client;
}
const booking = (phone, hour) => ({
  visit_type: 'appointment', scheduled_at: `2099-01-06T${hour}:00:00+08:00`,
  customer: { name: 'Synthetic customer', phone },
  recipients: [],
  items: [{ service_id: service, recipient_key: 'self', price: 80, workers: [{ id: employee, role: 'primary', pct: 100 }] }],
  preference_type: 'specified', preference_employee: employee,
});
const create = (client, key, payload) => value(client,
  'select public.v1361062_create_owner_order($1,$2,$3::jsonb)', [store, key, JSON.stringify(payload)]);

let started = false;
try {
  await server.initialise();
  await server.start();
  started = true;
  const [a, b, observer] = await Promise.all([connect(), connect(), connect()]);
  await sql(observer, await read('schema-fixture.sql'));
  await sql(observer, await read('../v13/supabase/migrations/20261105075034_salonos_workflow_v1361062.sql'));
  await sql(observer, "insert into stores(id,organization_id,name) values($1,$2,'Local fixture')", [store, org]);
  await sql(observer, "insert into test_roles values($1,$2,$3,'owner')", [owner, org, store]);
  await sql(observer, "insert into employees(id,organization_id,primary_store_id,employee_code,name,position) values($1,$2,$3,'A','Fixture A','Stylist')", [employee, org, store]);
  await sql(observer, 'insert into employee_stores(organization_id,employee_id,store_id) values($1,$2,$3)', [org, employee, store]);
  await sql(observer, "insert into services(id,organization_id,store_id,category,name,estimated_minutes,default_price) values($1,$2,$3,'Cut','Fixture cut',60,80)", [service, org, store]);
  for (const client of [a, b]) {
    await sql(client, "select set_config('request.jwt.claim.sub',$1,false)", [owner]);
  }
  const aPid = await value(a, 'select pg_backend_pid()');
  const bPid = await value(b, 'select pg_backend_pid()');

  async function race(first, second) {
    await sql(a, 'begin');
    await sql(b, 'begin');
    try {
      const winner = await first();
      const contender = second().then((result) => ({ result }), (error) => ({ error }));
      let blocked = false;
      for (let attempt = 0; attempt < 100 && !blocked; attempt++) {
        blocked = await value(observer, 'select $1::int = any(pg_blocking_pids($2))', [aPid, bPid]);
        if (!blocked) await delay(25);
      }
      assert.ok(blocked, 'second PostgreSQL connection must actually wait for the first');
      await sql(a, 'commit');
      const outcome = await contender;
      await sql(b, outcome.error ? 'rollback' : 'commit');
      return [winner, outcome];
    } finally {
      await Promise.allSettled([sql(a, 'rollback'), sql(b, 'rollback')]);
    }
  }

  const [booked, conflict] = await race(
    () => create(a, id(40), booking('000001', 15)),
    () => create(b, id(41), booking('000002', 15)),
  );
  assert.match(conflict.error?.message ?? '', /时段已被占用/);
  assert.equal(await value(observer, 'select count(*)::int from visits'), 1);
  assert.equal(await value(observer, 'select count(*)::int from customers'), 1);

  const [created, duplicate] = await race(
    () => create(a, id(42), booking('000003', 17)),
    () => create(b, id(42), booking('000003', 17)),
  );
  assert.equal(duplicate.result?.visit_id, created.visit_id);
  assert.equal(duplicate.result?.replayed, true);
  assert.equal(await value(observer, 'select count(*)::int from visits'), 2);

  for (const status of ['arrived', 'in_service', 'ready_for_checkout']) {
    await sql(a, 'select public.v1361062_owner_visit_status($1,$2,$3)', [store, booked.visit_id, status]);
  }
  const checkout = (client) => one(client, 'select * from public.checkout_visit($1,$2::jsonb,0,0,null)',
    [booked.visit_id, JSON.stringify([{ method: 'cash', amount: 80 }])]);
  const [paid, rejected] = await race(() => checkout(a), () => checkout(b));
  assert.ok(paid.payment_id);
  assert.match(rejected.error?.message ?? '', /not ready|already/i);
  assert.equal(await value(observer, 'select count(*)::int from payments where visit_id=$1', [booked.visit_id]), 1);
  console.log('PostgreSQL two-session tests passed: one overlapping booking, one idempotent replay, one payment.');

  await verifyWhatsApp({ client: observer, sql, one, value, org, store, employee, service, id });
} finally {
  await Promise.allSettled(clients.map((client) => client.end()));
  if (started) await server.stop();
}
