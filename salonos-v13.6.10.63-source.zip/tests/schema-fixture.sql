-- Isolated fixture: relevant production column metadata and check constraints; no production rows.
create role anon;
create role authenticated;
create role service_role;
create schema auth;
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
grant usage on schema auth to authenticated,anon;
create table public."appointment_employee_preferences" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "visit_id" uuid not null,
  "preference_type" text not null,
  "employee_id" uuid,
  "notes" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  CHECK (preference_type = 'specified'::text AND employee_id IS NOT NULL OR preference_type = 'random'::text AND employee_id IS NULL),
  PRIMARY KEY (id),
  CHECK (preference_type = ANY (ARRAY['specified'::text, 'random'::text])),
  UNIQUE (visit_id)
);
create table public."employees" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "primary_store_id" uuid not null,
  "user_id" uuid,
  "employee_code" text not null,
  "name" text not null,
  "phone" text,
  "position" text not null,
  "age" smallint,
  "gender" text default 'unspecified'::text not null,
  "skill_tags" text,
  "is_on_duty" boolean default true not null,
  "availability_status" text default 'available'::text not null,
  "employment_status" text default 'active'::text not null,
  "joined_at" date,
  "left_at" date,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "app_role" text default 'staff'::text not null,
  "last_login_at" timestamp with time zone,
  "avatar_path" text,
  "ui_language" text,
  CHECK (age IS NULL OR age >= 14 AND age <= 100),
  CHECK (app_role = ANY (ARRAY['manager'::text, 'receptionist'::text, 'accountant'::text, 'stylist'::text, 'assistant'::text, 'staff'::text])),
  CHECK (availability_status = ANY (ARRAY['available'::text, 'break'::text, 'off_duty'::text, 'in_service'::text, 'busy'::text, 'disabled'::text, 'inactive'::text])),
  CHECK (employment_status = ANY (ARRAY['active'::text, 'leave'::text, 'inactive'::text])),
  CHECK (gender = ANY (ARRAY['male'::text, 'female'::text, 'unspecified'::text])),
  UNIQUE (organization_id, employee_code),
  UNIQUE (organization_id, id),
  UNIQUE (organization_id, user_id),
  PRIMARY KEY (id),
  CHECK (ui_language IS NULL OR (ui_language = ANY (ARRAY['zh'::text, 'en'::text])))
);
create table public."inventory_stock_movements" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "product_id" uuid not null,
  "quantity_delta" numeric(14,3) not null,
  "movement_type" text not null,
  "unit_cost" numeric(12,2),
  "reference_type" text,
  "reference_id" uuid,
  "notes" text,
  "created_by_user_id" uuid,
  "created_at" timestamp with time zone default now() not null,
  CHECK (movement_type = ANY (ARRAY['opening'::text, 'purchase'::text, 'sale'::text, 'sale_return'::text, 'adjustment_in'::text, 'adjustment_out'::text])),
  PRIMARY KEY (id),
  CHECK (quantity_delta <> 0::numeric),
  CHECK (unit_cost IS NULL OR unit_cost >= 0::numeric)
);
create table public."member_wallet_ledger" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "membership_id" uuid not null,
  "amount_delta" numeric(12,2) not null,
  "transaction_type" text not null,
  "reference_type" text,
  "reference_id" uuid,
  "notes" text,
  "created_by_user_id" uuid,
  "created_at" timestamp with time zone default now() not null,
  "external_source" text,
  "external_id" text,
  CHECK (amount_delta <> 0::numeric),
  PRIMARY KEY (id),
  CHECK (transaction_type = ANY (ARRAY['top_up'::text, 'payment'::text, 'refund'::text, 'adjustment'::text]))
);
create table public."memberships" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "customer_id" uuid not null,
  "current_level_id" uuid not null,
  "member_number" text not null,
  "status" text default 'active'::text not null,
  "joined_at" timestamp with time zone default now() not null,
  "notes" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "external_source" text,
  "external_id" text,
  UNIQUE (organization_id, customer_id),
  UNIQUE (organization_id, id),
  UNIQUE (organization_id, member_number),
  PRIMARY KEY (id),
  CHECK (status = ANY (ARRAY['active'::text, 'suspended'::text, 'closed'::text]))
);
create table public."payment_items" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "payment_id" uuid not null,
  "payment_method" text not null,
  "amount" numeric(12,2) not null,
  "reference_number" text,
  "notes" text,
  "created_at" timestamp with time zone default now() not null,
  "membership_id" uuid,
  CHECK (amount > 0::numeric),
  CHECK (payment_method = ANY (ARRAY['cash'::text, 'card'::text, 'ewallet'::text, 'bank_transfer'::text, 'member_wallet'::text, 'other'::text])),
  PRIMARY KEY (id)
);
create table public."payments" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "visit_id" uuid not null,
  "receipt_number" text not null,
  "service_subtotal" numeric(12,2) default 0 not null,
  "product_subtotal" numeric(12,2) default 0 not null,
  "discount_total" numeric(12,2) default 0 not null,
  "tax_total" numeric(12,2) default 0 not null,
  "grand_total" numeric(12,2) not null,
  "paid_total" numeric(12,2) not null,
  "change_amount" numeric(12,2) default 0 not null,
  "status" text default 'paid'::text not null,
  "checkout_by_user_id" uuid,
  "paid_at" timestamp with time zone default now() not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  CHECK (change_amount >= 0::numeric),
  CHECK (discount_total >= 0::numeric),
  CHECK (grand_total >= 0::numeric),
  UNIQUE (organization_id, store_id, id),
  UNIQUE (organization_id, receipt_number),
  CHECK (paid_total >= 0::numeric),
  PRIMARY KEY (id),
  CHECK (product_subtotal >= 0::numeric),
  CHECK (service_subtotal >= 0::numeric),
  CHECK (status = ANY (ARRAY['paid'::text, 'voided'::text, 'refunded'::text])),
  CHECK (tax_total >= 0::numeric),
  UNIQUE (visit_id)
);
create table public."service_performance_ledger" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "employee_id" uuid not null,
  "service_item_id" uuid not null,
  "payment_id" uuid not null,
  "service_amount" numeric(12,2) not null,
  "contribution_percent" numeric(6,2) not null,
  "performance_amount" numeric(12,2) not null,
  "created_at" timestamp with time zone default now() not null,
  CHECK (contribution_percent >= 0::numeric AND contribution_percent <= 100::numeric),
  UNIQUE (employee_id, service_item_id),
  CHECK (performance_amount >= 0::numeric),
  PRIMARY KEY (id),
  CHECK (service_amount >= 0::numeric)
);
create table public."services" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "category" text not null,
  "name" text not null,
  "default_price" numeric(12,2) default 0 not null,
  "estimated_minutes" integer default 30 not null,
  "allows_assistant" boolean default false not null,
  "active" boolean default true not null,
  "external_source" text,
  "external_id" text,
  "barcode" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "category_id" uuid,
  CHECK (default_price >= 0::numeric),
  CHECK (estimated_minutes > 0),
  UNIQUE (organization_id, store_id, id),
  UNIQUE (organization_id, id),
  PRIMARY KEY (id)
);
create table public."stores" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "name" text not null,
  "code" text,
  "is_main" boolean default false not null,
  "status" text default 'active'::text not null,
  "phone" text,
  "email" text,
  "address" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "logo_path" text,
  "login_email" text,
  "central_subscription_id" bigint,
  "subscription_plan" text,
  "subscription_status" text default 'included'::text not null,
  "subscription_expires_at" timestamp with time zone,
  "external_source" text,
  "external_id" text,
  UNIQUE (organization_id, code),
  UNIQUE (organization_id, id),
  PRIMARY KEY (id),
  CHECK (status = ANY (ARRAY['active'::text, 'suspended'::text, 'expired'::text, 'closed'::text]))
);
create table public."visit_product_items" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "visit_id" uuid not null,
  "product_id" uuid not null,
  "product_name_snapshot" text not null,
  "sku_snapshot" text,
  "unit_price" numeric(12,2) not null,
  "cost_price_snapshot" numeric(12,2) default 0 not null,
  "quantity" integer default 1 not null,
  "line_total" numeric(12,2) generated always as ((unit_price * (quantity)::numeric)) stored,
  "salesperson_employee_id" uuid,
  "commission_rate_snapshot" numeric(6,2) default 0 not null,
  "status" text default 'active'::text not null,
  "notes" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "bundle_id" uuid,
  "item_type" text default 'product'::text not null,
  CHECK (commission_rate_snapshot >= 0::numeric AND commission_rate_snapshot <= 100::numeric),
  CHECK (cost_price_snapshot >= 0::numeric),
  PRIMARY KEY (id),
  CHECK (quantity > 0),
  CHECK (status = ANY (ARRAY['active'::text, 'cancelled'::text, 'returned'::text])),
  CHECK (unit_price >= 0::numeric)
);
create table public."visit_recipients" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "visit_id" uuid not null,
  "customer_id" uuid,
  "name_snapshot" text not null,
  "phone_snapshot" text,
  "recipient_type" text default 'primary'::text not null,
  "notes" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  UNIQUE (organization_id, visit_id, id),
  UNIQUE (organization_id, id),
  PRIMARY KEY (id),
  CHECK (recipient_type = ANY (ARRAY['primary'::text, 'child'::text, 'family'::text, 'friend'::text, 'other'::text]))
);
create table public."visit_service_items" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "visit_id" uuid not null,
  "recipient_id" uuid not null,
  "service_id" uuid not null,
  "service_name_snapshot" text not null,
  "category_snapshot" text,
  "unit_price" numeric(12,2) default 0 not null,
  "quantity" integer default 1 not null,
  "estimated_minutes_snapshot" integer,
  "line_total" numeric(12,2) generated always as ((unit_price * (quantity)::numeric)) stored,
  "status" text default 'waiting'::text not null,
  "started_at" timestamp with time zone,
  "completed_at" timestamp with time zone,
  "notes" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "service_category_snapshot" text,
  CHECK (estimated_minutes_snapshot IS NULL OR estimated_minutes_snapshot > 0),
  UNIQUE (organization_id, store_id, id),
  PRIMARY KEY (id),
  CHECK (quantity > 0),
  CHECK (status = ANY (ARRAY['waiting'::text, 'in_service'::text, 'paused'::text, 'completed'::text, 'cancelled'::text])),
  CHECK (unit_price >= 0::numeric)
);
create table public."visit_service_workers" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "service_item_id" uuid not null,
  "employee_id" uuid not null,
  "worker_role" text default 'primary'::text not null,
  "contribution_percent" numeric(6,2) default 100 not null,
  "status" text default 'active'::text not null,
  "assigned_at" timestamp with time zone default now() not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  UNIQUE (organization_id, store_id, service_item_id, employee_id),
  CHECK (contribution_percent >= 0::numeric AND contribution_percent <= 100::numeric),
  PRIMARY KEY (id),
  UNIQUE (service_item_id, employee_id),
  CHECK (status = ANY (ARRAY['active'::text, 'removed'::text])),
  CHECK (worker_role = ANY (ARRAY['primary'::text, 'assistant'::text, 'support'::text]))
);
create table public."visits" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "visit_number" text not null,
  "visit_type" text default 'walk_in'::text not null,
  "status" text default 'draft'::text not null,
  "scheduled_at" timestamp with time zone,
  "arrived_at" timestamp with time zone,
  "started_at" timestamp with time zone,
  "service_completed_at" timestamp with time zone,
  "checked_out_at" timestamp with time zone,
  "notes" text,
  "created_by_user_id" uuid,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "assignment_type" text,
  "assignment_strategy" text,
  UNIQUE (organization_id, store_id, id),
  UNIQUE (organization_id, id),
  UNIQUE (organization_id, visit_number),
  PRIMARY KEY (id),
  CHECK (status = ANY (ARRAY['draft'::text, 'booked'::text, 'arrived'::text, 'waiting'::text, 'in_service'::text, 'paused'::text, 'ready_for_checkout'::text, 'completed'::text, 'cancelled'::text, 'no_show'::text])),
  CHECK (visit_type = ANY (ARRAY['walk_in'::text, 'appointment'::text]))
);
create table public."whatsapp_ai_queue" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "connection_id" uuid not null,
  "conversation_id" uuid not null,
  "message_id" uuid not null,
  "lead_id" uuid,
  "status" text default 'queued'::text not null,
  "context" jsonb default '{}'::jsonb not null,
  "attempts" integer default 0 not null,
  "last_error" text,
  "available_at" timestamp with time zone default now() not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  UNIQUE (message_id),
  PRIMARY KEY (id),
  CHECK (status = ANY (ARRAY['queued'::text, 'processing'::text, 'completed'::text, 'failed'::text, 'skipped'::text]))
);
create table public."customers" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "name" text not null,
  "phone" text not null,
  "gender" text default 'unspecified'::text not null,
  "birth_date" date,
  "ethnicity" text,
  "identification_number" text,
  "email" text,
  "address" text,
  "acquisition_platform" text,
  "external_source" text,
  "external_id" text,
  "notes" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "ethnicity_source" text default 'unknown'::text not null,
  "reported_age" integer,
  "age_range" text,
  "age_source" text default 'unknown'::text not null,
  "age_reported_at" timestamp with time zone,
  CHECK (age_source = ANY (ARRAY['unknown'::text, 'customer_provided'::text, 'staff_entered'::text, 'imported'::text])),
  CHECK (ethnicity_source = ANY (ARRAY['unknown'::text, 'customer_provided'::text, 'staff_entered'::text, 'imported'::text])),
  CHECK (gender = ANY (ARRAY['male'::text, 'female'::text, 'unspecified'::text])),
  UNIQUE (organization_id, id),
  PRIMARY KEY (id),
  CHECK (reported_age IS NULL OR reported_age >= 1 AND reported_age <= 120)
);
create table public."employee_commission_ledger" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "employee_id" uuid not null,
  "source_type" text not null,
  "source_id" uuid,
  "base_amount" numeric(12,2) default 0 not null,
  "commission_rate" numeric(6,2) default 0 not null,
  "commission_amount" numeric(12,2) not null,
  "notes" text,
  "created_at" timestamp with time zone default now() not null,
  CHECK (commission_rate >= 0::numeric AND commission_rate <= 100::numeric),
  UNIQUE (employee_id, source_type, source_id),
  PRIMARY KEY (id),
  CHECK (source_type = ANY (ARRAY['service'::text, 'product'::text, 'kpi_bonus'::text, 'manual_adjustment'::text]))
);
create table public."employee_stores" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "employee_id" uuid not null,
  "store_id" uuid not null,
  "is_primary" boolean default false not null,
  "status" text default 'active'::text not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  UNIQUE (employee_id, store_id),
  UNIQUE (organization_id, employee_id, store_id),
  PRIMARY KEY (id),
  CHECK (status = ANY (ARRAY['active'::text, 'disabled'::text]))
);
create table public."member_loyalty_ledger" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "membership_id" uuid not null,
  "experience_delta" numeric(14,2) default 0 not null,
  "points_delta" numeric(14,2) default 0 not null,
  "transaction_type" text not null,
  "reference_type" text,
  "reference_id" uuid,
  "notes" text,
  "created_by_user_id" uuid,
  "created_at" timestamp with time zone default now() not null,
  "external_source" text,
  "external_id" text,
  CHECK (experience_delta <> 0::numeric OR points_delta <> 0::numeric),
  PRIMARY KEY (id),
  CHECK (transaction_type = ANY (ARRAY['purchase'::text, 'redeem'::text, 'refund'::text, 'adjustment'::text]))
);
create table public.whatsapp_conversations(id uuid primary key,organization_id uuid not null,store_id uuid not null,customer_phone text,ai_enabled boolean default true,updated_at timestamptz default now());
create table public.test_roles(actor uuid,organization_id uuid,store_id uuid,role text);
create table public.test_employee_sessions(token text primary key, employee_id uuid,organization_id uuid,store_id uuid,role text);
create function public.can_access_store(target_store_id uuid) returns boolean language sql stable as $$ select exists(select 1 from public.test_roles where actor=auth.uid() and store_id=target_store_id) $$;
create function public.has_organization_role(target_organization_id uuid,allowed_roles text[]) returns boolean language sql stable as $$ select exists(select 1 from public.test_roles where actor=auth.uid() and organization_id=target_organization_id and role=any(allowed_roles)) $$;
create function public.employee_session_context(p_session_token text) returns jsonb language sql as $$ select jsonb_build_object('employee_id',employee_id,'organization_id',organization_id,'store_id',store_id,'employee_role',role) from public.test_employee_sessions where token=p_session_token $$;
create function public.v13_employee_api(p_session_token text,p_action text,p_payload jsonb default '{}'::jsonb) returns jsonb language sql as $$ select jsonb_build_object('legacy',p_action) $$;
create function public.v1361030_employee_qualified_for_service(p_org uuid,p_store uuid,p_employee uuid,p_service uuid) returns boolean language sql stable as $$ select p_employee <> '00000000-0000-0000-0000-000000000099'::uuid $$;
create function public.v1361030_employee_free_for_slot(p_org uuid,p_store uuid,p_employee uuid,p_start timestamptz,p_minutes int,p_type text,p_exclude uuid) returns boolean language sql stable as $$ select exists(select 1 from public.employee_stores where organization_id=p_org and store_id=p_store and employee_id=p_employee and status='active') $$;
CREATE OR REPLACE FUNCTION public.v13681_visit_lifecycle_integrity()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
begin
  if new.status is distinct from old.status then
    if new.status='arrived' then
      new.arrived_at := coalesce(new.arrived_at,old.arrived_at,now());

    elsif new.status='in_service' then
      if coalesce(new.visit_type,old.visit_type)='appointment'
         and coalesce(new.arrived_at,old.arrived_at) is null then
        raise exception '预约顾客尚未确认到店，不能开始服务。';
      end if;
      new.started_at := coalesce(new.started_at,old.started_at,now());

    elsif new.status='ready_for_checkout' then
      if coalesce(new.started_at,old.started_at) is null then
        raise exception '服务尚未开始，不能直接进入待结账。';
      end if;
      new.service_completed_at := coalesce(new.service_completed_at,old.service_completed_at,now());

    elsif new.status='completed' then
      if coalesce(new.visit_type,old.visit_type)='appointment'
         and coalesce(new.arrived_at,old.arrived_at) is null then
        raise exception '预约顾客尚未确认到店，不能完成结账。';
      end if;
      -- completed semantically means the service is complete. If an older client skipped
      -- writing service_completed_at, anchor it no later than checkout.
      new.service_completed_at := coalesce(
        new.service_completed_at,
        old.service_completed_at,
        new.checked_out_at,
        old.checked_out_at,
        now()
      );
      new.checked_out_at := coalesce(new.checked_out_at,old.checked_out_at,now());
    end if;
  end if;

  return new;
end;
$function$
;
create trigger trg_v13681_visit_lifecycle_integrity before update of status on public.visits for each row execute function public.v13681_visit_lifecycle_integrity();
create table public."membership_levels" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "level_number" integer not null,
  "name" text not null,
  "min_experience" numeric(14,2) default 0 not null,
  "discount_percent" numeric(6,2) default 0 not null,
  "points_multiplier" numeric(6,2) default 1 not null,
  "active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "external_source" text,
  "external_id" text,
  CHECK (discount_percent >= 0::numeric AND discount_percent <= 100::numeric),
  CHECK (level_number >= 1),
  CHECK (min_experience >= 0::numeric),
  UNIQUE (organization_id, id),
  UNIQUE (organization_id, level_number),
  PRIMARY KEY (id),
  CHECK (points_multiplier >= 0::numeric)
);
create table public."products" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "sku" text not null,
  "barcode" text,
  "name" text not null,
  "category" text,
  "sale_price" numeric(12,2) default 0 not null,
  "cost_price" numeric(12,2) default 0 not null,
  "default_commission_rate" numeric(6,2) default 0 not null,
  "image_path" text,
  "active" boolean default true not null,
  "external_source" text,
  "external_id" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "reorder_level" numeric default 0 not null,
  "purpose" text,
  "retail_enabled" boolean default true not null,
  "stock_enabled" boolean default true not null,
  "stock_unit" text default 'pcs'::text not null,
  "tunaipro_id" text,
  "category_id" uuid,
  CHECK (cost_price >= 0::numeric),
  CHECK (default_commission_rate >= 0::numeric AND default_commission_rate <= 100::numeric),
  UNIQUE (organization_id, store_id, id),
  UNIQUE (organization_id, store_id, sku),
  PRIMARY KEY (id),
  CHECK (sale_price >= 0::numeric)
);
create table public."visit_service_signoffs" (
  "id" uuid default gen_random_uuid() not null,
  "organization_id" uuid not null,
  "store_id" uuid not null,
  "service_item_id" uuid not null,
  "employee_id" uuid not null,
  "employee_name_snapshot" text not null,
  "signature_path" text not null,
  "signed_at" timestamp with time zone default now() not null,
  "signed_by_user_id" uuid,
  "notes" text,
  "created_at" timestamp with time zone default now() not null,
  "signature_data" text,
  PRIMARY KEY (id),
  UNIQUE (service_item_id, employee_id)
);
CREATE OR REPLACE FUNCTION public.recompute_visit_status(target_visit_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare

  v_has_items boolean;
  v_all_completed boolean;
  v_has_in_service boolean;
  v_has_paused boolean;
  v_missing_worker boolean;
  v_missing_signoff boolean;

begin

  -- 有没有有效的服务项目
  select exists (
    select 1
    from public.visit_service_items
    where visit_id = target_visit_id
      and status <> 'cancelled'
  )
  into v_has_items;


  if not v_has_items then
    return;
  end if;


  -- 是否全部服务完成
  select not exists (
    select 1
    from public.visit_service_items
    where visit_id = target_visit_id
      and status <> 'cancelled'
      and status <> 'completed'
  )
  into v_all_completed;


  -- 有没有正在服务
  select exists (
    select 1
    from public.visit_service_items
    where visit_id = target_visit_id
      and status = 'in_service'
  )
  into v_has_in_service;


  -- 有没有暂停
  select exists (
    select 1
    from public.visit_service_items
    where visit_id = target_visit_id
      and status = 'paused'
  )
  into v_has_paused;


  -- 有没有服务项目根本没安排员工
  select exists (
    select 1
    from public.visit_service_items vsi

    where vsi.visit_id = target_visit_id
      and vsi.status <> 'cancelled'

      and not exists (
        select 1
        from public.visit_service_workers vsw
        where vsw.service_item_id = vsi.id
          and vsw.status = 'active'
      )
  )
  into v_missing_worker;


  -- 有没有负责员工还没签名
  select exists (
    select 1
    from public.visit_service_workers vsw

    join public.visit_service_items vsi
      on vsi.id = vsw.service_item_id

    where vsi.visit_id = target_visit_id
      and vsi.status <> 'cancelled'
      and vsw.status = 'active'

      and not exists (
        select 1
        from public.visit_service_signoffs vss
        where vss.service_item_id = vsw.service_item_id
          and vss.employee_id = vsw.employee_id
      )
  )
  into v_missing_signoff;


  -- ==================================================
  -- 所有服务完成 + 有员工 + 全部签名
  -- → 自动进入待结账
  -- ==================================================

  if
    v_all_completed
    and not v_missing_worker
    and not v_missing_signoff
  then

    update public.visits
    set
      status = 'ready_for_checkout',

      service_completed_at =
        coalesce(
          service_completed_at,
          now()
        ),

      updated_at = now()

    where id = target_visit_id
      and status <> 'completed';

    return;

  end if;


  -- ==================================================
  -- 有项目正在服务
  -- ==================================================

  if v_has_in_service then

    update public.visits
    set
      status = 'in_service',

      started_at =
        coalesce(
          started_at,
          now()
        ),

      updated_at = now()

    where id = target_visit_id
      and status not in (
        'completed',
        'cancelled'
      );

    return;

  end if;


  -- ==================================================
  -- 服务暂停
  -- ==================================================

  if v_has_paused then

    update public.visits
    set
      status = 'paused',
      updated_at = now()

    where id = target_visit_id
      and status not in (
        'completed',
        'cancelled'
      );

  end if;

end;
$function$
;
CREATE OR REPLACE FUNCTION public.trigger_recompute_visit_from_item()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare

  v_visit_id uuid;

begin

  v_visit_id :=
    coalesce(
      new.visit_id,
      old.visit_id
    );

  perform public.recompute_visit_status(
    v_visit_id
  );

  return coalesce(new, old);

end;
$function$
;
create trigger visit_service_items_recompute_visit after insert or delete or update on public.visit_service_items for each row execute function public.trigger_recompute_visit_from_item();
CREATE OR REPLACE FUNCTION public.protect_visit_checkout()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin

  -- 只有在真的要进入 completed 或写入结账时间时检查
  if (
      new.status = 'completed'
      and old.status is distinct from new.status
     )
     or (
      new.checked_out_at is not null
      and old.checked_out_at is distinct from new.checked_out_at
     )
  then

    -- Dashboard / server 后台操作没有 auth.uid 时先允许
    -- 正常 App 用户一定会有 auth.uid()
    if auth.uid() is not null then

      if not public.has_organization_role(
        new.organization_id,
        array[
          'owner',
          'manager',
          'receptionist'
        ]
      )
      then

        raise exception
          'You do not have permission to checkout this visit.';

      end if;

    end if;

  end if;

  return new;

end;
$function$
;
create trigger protect_visit_checkout_trigger before update on public.visits for each row execute function public.protect_visit_checkout();
CREATE OR REPLACE FUNCTION public.record_service_performance_for_payment(target_payment_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$

declare

  v_payment public.payments%rowtype;

begin

  select *
  into v_payment

  from public.payments

  where id = target_payment_id;


  if not found then
    raise exception 'Payment not found.';
  end if;


  insert into public.service_performance_ledger (

    organization_id,

    store_id,

    employee_id,

    service_item_id,

    payment_id,

    service_amount,

    contribution_percent,

    performance_amount

  )

  select

    vsi.organization_id,

    vsi.store_id,

    vsw.employee_id,

    vsi.id,

    v_payment.id,

    vsi.line_total,

    vsw.contribution_percent,

    round(
      (
        vsi.line_total
        *
        vsw.contribution_percent
        /
        100
      )::numeric,
      2
    )

  from public.visit_service_items vsi

  join public.visit_service_workers vsw
    on vsw.service_item_id = vsi.id

  where vsi.visit_id = v_payment.visit_id

    and vsi.status <> 'cancelled'

    and vsw.status = 'active'

  on conflict (
    employee_id,
    service_item_id
  )

  do nothing;

end;
$function$
;
CREATE OR REPLACE FUNCTION public.checkout_visit(target_visit_id uuid, payment_lines jsonb, discount_amount numeric DEFAULT 0, tax_amount numeric DEFAULT 0, loyalty_membership_id uuid DEFAULT NULL::uuid)
 RETURNS TABLE(payment_id uuid, receipt_number text, grand_total numeric, paid_total numeric, change_amount numeric, wallet_used numeric, experience_earned numeric, points_earned numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$

declare

  v_visit public.visits%rowtype;

  v_service_subtotal numeric(12,2);

  v_product_subtotal numeric(12,2);

  v_grand_total numeric(12,2);

  v_paid_total numeric(12,2) := 0;

  v_non_cash_total numeric(12,2) := 0;

  v_change numeric(12,2) := 0;

  v_payment_id uuid;

  v_receipt text;

  v_line jsonb;

  v_method text;

  v_amount numeric(12,2);

  v_reference text;

  v_has_cash boolean := false;

  v_wallet_membership_id uuid;

  v_wallet_balance numeric(12,2);

  v_wallet_used numeric(12,2) := 0;

  v_wallet_line_count integer;

  v_experience_earned numeric(14,2) := 0;

  v_points_earned numeric(14,2) := 0;

  v_product_item record;

  v_stock numeric(14,3);

begin


  -- ==================================================
  -- 1. 必须登录
  -- ==================================================

  if auth.uid() is null then

    raise exception
      'Authentication required.';

  end if;


  -- ==================================================
  -- 2. 锁住订单
  -- 防止两台柜台同时结账
  -- ==================================================

  select *

  into v_visit

  from public.visits

  where id = target_visit_id

  for update;


  if not found then

    raise exception
      'Visit not found.';

  end if;


  -- ==================================================
  -- 3. 检查分行权限
  -- ==================================================

  if not public.can_access_store(
    v_visit.store_id
  )
  then

    raise exception
      'You cannot access this store.';

  end if;


  -- ==================================================
  -- 4. 只有这些角色可以结账
  -- ==================================================

  if not public.has_organization_role(

    v_visit.organization_id,

    array[
      'owner',
      'manager',
      'receptionist'
    ]

  )
  then

    raise exception
      'You do not have permission to checkout.';

  end if;


  -- ==================================================
  -- 5. 必须已经进入待结账
  -- ==================================================

  if v_visit.status <> 'ready_for_checkout'
  then

    raise exception
      'Visit is not ready for checkout. Current status: %',
      v_visit.status;

  end if;


  -- ==================================================
  -- 6. 防止重复结账
  -- ==================================================

  if exists (

    select 1

    from public.payments

    where visit_id = target_visit_id

  )
  then

    raise exception
      'This visit has already been checked out.';

  end if;


  -- ==================================================
  -- 7. Discount / Tax
  -- ==================================================

  if discount_amount < 0 then

    raise exception
      'Discount cannot be negative.';

  end if;


  if tax_amount < 0 then

    raise exception
      'Tax cannot be negative.';

  end if;


  -- ==================================================
  -- 8. 服务金额
  -- ==================================================

  select

    coalesce(
      sum(line_total)
      filter (
        where status <> 'cancelled'
      ),
      0
    )

  into v_service_subtotal

  from public.visit_service_items

  where visit_id = target_visit_id;


  -- ==================================================
  -- 9. 产品金额
  -- ==================================================

  select

    coalesce(
      sum(line_total)
      filter (
        where status = 'active'
      ),
      0
    )

  into v_product_subtotal

  from public.visit_product_items

  where visit_id = target_visit_id;


  -- ==================================================
  -- 10. 总额
  -- ==================================================

  v_grand_total :=

    greatest(

      0,

      v_service_subtotal
      +
      v_product_subtotal
      -
      discount_amount
      +
      tax_amount

    );


  -- ==================================================
  -- 11. 结账前检查产品库存
  -- ==================================================

  for v_product_item in

    select *

    from public.visit_product_items

    where visit_id = target_visit_id
      and status = 'active'

  loop


    -- 锁产品
    perform 1

    from public.products

    where id =
          v_product_item.product_id

    for update;


    -- 当前实际库存
    select

      coalesce(
        sum(quantity_delta),
        0
      )

    into v_stock

    from public.inventory_stock_movements

    where product_id =
          v_product_item.product_id

      and store_id =
          v_product_item.store_id;


    if v_stock <
       v_product_item.quantity
    then

      raise exception
        'Insufficient stock for product %. Available: %, required: %',
        v_product_item.product_name_snapshot,
        v_stock,
        v_product_item.quantity;

    end if;


  end loop;


  -- ==================================================
  -- 12. 必须提供付款方式
  -- ==================================================

  if payment_lines is null

     or jsonb_typeof(
          payment_lines
        ) <> 'array'

     or jsonb_array_length(
          payment_lines
        ) = 0

  then

    raise exception
      'At least one payment method is required.';

  end if;


  -- ==================================================
  -- 13. 一次暂时只允许一个会员 Wallet
  -- ==================================================

  select count(*)

  into v_wallet_line_count

  from jsonb_array_elements(
    payment_lines
  ) x

  where x ->> 'method'
        = 'member_wallet';


  if v_wallet_line_count > 1
  then

    raise exception
      'Only one member wallet payment is allowed per checkout.';

  end if;


  -- ==================================================
  -- 14. 检查付款项目
  -- ==================================================

  for v_line in

    select value

    from jsonb_array_elements(
      payment_lines
    )

  loop


    v_method :=
      v_line ->> 'method';


    v_amount :=
      (
        v_line ->> 'amount'
      )::numeric;


    v_reference :=

      nullif(
        v_line ->> 'reference_number',
        ''
      );


    if v_method not in (

      'cash',
      'card',
      'ewallet',
      'bank_transfer',
      'member_wallet',
      'other'

    )
    then

      raise exception
        'Invalid payment method: %',
        v_method;

    end if;


    if v_amount is null
       or v_amount <= 0
    then

      raise exception
        'Payment amount must be greater than zero.';

    end if;


    v_paid_total :=
      v_paid_total
      +
      v_amount;


    if v_method = 'cash'
    then

      v_has_cash := true;

    else

      v_non_cash_total :=
        v_non_cash_total
        +
        v_amount;

    end if;


    -- =================================================
    -- Member Wallet
    -- =================================================

    if v_method =
       'member_wallet'
    then


      if nullif(
        v_line ->> 'membership_id',
        ''
      ) is null
      then

        raise exception
          'membership_id is required for member wallet payment.';

      end if;


      v_wallet_membership_id :=

        (
          v_line ->> 'membership_id'
        )::uuid;


      -- 锁住会员记录
      perform 1

      from public.memberships m

      where m.id =
            v_wallet_membership_id

        and m.organization_id =
            v_visit.organization_id

        and m.status =
            'active'

      for update;


      if not found then

        raise exception
          'Active membership not found.';

      end if;


      -- Wallet 必须属于这一张 Visit 的顾客
      if not exists (

        select 1

        from public.memberships m

        join public.visit_recipients vr

          on vr.customer_id =
             m.customer_id

          and vr.organization_id =
              m.organization_id

        where m.id =
              v_wallet_membership_id

          and vr.visit_id =
              target_visit_id

      )
      then

        raise exception
          'This member wallet does not belong to a customer in this visit.';

      end if;


      -- 计算实际 Wallet 余额
      select

        coalesce(
          sum(amount_delta),
          0
        )

      into v_wallet_balance

      from public.member_wallet_ledger

      where membership_id =
            v_wallet_membership_id;


      if v_wallet_balance <
         v_amount
      then

        raise exception
          'Insufficient member wallet balance. Available: %, required: %',
          v_wallet_balance,
          v_amount;

      end if;


      v_wallet_used :=
        v_wallet_used
        +
        v_amount;


    end if;


  end loop;


  -- ==================================================
  -- 15. 付款不足
  -- ==================================================

  if v_paid_total <
     v_grand_total
  then

    raise exception
      'Insufficient payment. Required: %, received: %',
      v_grand_total,
      v_paid_total;

  end if;


  -- 非现金不能超过订单总额
  if v_non_cash_total >
     v_grand_total
  then

    raise exception
      'Non-cash payment cannot exceed the order total.';

  end if;


  -- 超额付款必须有 Cash
  if v_paid_total >
     v_grand_total

     and not v_has_cash
  then

    raise exception
      'Overpayment is only allowed when cash is included.';

  end if;


  v_change :=

    greatest(
      0,
      v_paid_total
      -
      v_grand_total
    );


  -- ==================================================
  -- 16. Loyalty Member 检查
  -- ==================================================

  if loyalty_membership_id
     is not null
  then


    perform 1

    from public.memberships m

    where m.id =
          loyalty_membership_id

      and m.organization_id =
          v_visit.organization_id

      and m.status =
          'active'

    for update;


    if not found then

      raise exception
        'Loyalty membership not found.';

    end if;


    if not exists (

      select 1

      from public.memberships m

      join public.visit_recipients vr

        on vr.customer_id =
           m.customer_id

        and vr.organization_id =
            m.organization_id

      where m.id =
            loyalty_membership_id

        and vr.visit_id =
            target_visit_id

    )
    then

      raise exception
        'Loyalty membership does not belong to this visit.';

    end if;


  end if;


  -- ==================================================
  -- 17. Receipt Number
  -- ==================================================

  v_receipt :=

    'PAY-'

    || to_char(
         now(),
         'YYYYMMDD'
       )

    || '-'

    || upper(

      substr(

        replace(
          gen_random_uuid()::text,
          '-',
          ''
        ),

        1,
        8

      )

    );


  -- ==================================================
  -- 18. 建立付款记录
  -- ==================================================

  insert into public.payments (

    organization_id,

    store_id,

    visit_id,

    receipt_number,

    service_subtotal,

    product_subtotal,

    discount_total,

    tax_total,

    grand_total,

    paid_total,

    change_amount,

    status,

    checkout_by_user_id,

    paid_at

  )

  values (

    v_visit.organization_id,

    v_visit.store_id,

    v_visit.id,

    v_receipt,

    v_service_subtotal,

    v_product_subtotal,

    discount_amount,

    tax_amount,

    v_grand_total,

    v_paid_total,

    v_change,

    'paid',

    auth.uid(),

    now()

  )

  returning id

  into v_payment_id;


  -- ==================================================
  -- 19. 保存付款方式
  -- ==================================================

  for v_line in

    select value

    from jsonb_array_elements(
      payment_lines
    )

  loop


    v_method :=
      v_line ->> 'method';


    v_amount :=
      (
        v_line ->> 'amount'
      )::numeric;


    v_reference :=

      nullif(
        v_line ->> 'reference_number',
        ''
      );


    if v_method =
       'member_wallet'
    then

      v_wallet_membership_id :=

        (
          v_line ->> 'membership_id'
        )::uuid;

    else

      v_wallet_membership_id := null;

    end if;


    insert into public.payment_items (

      organization_id,

      store_id,

      payment_id,

      payment_method,

      amount,

      reference_number,

      membership_id

    )

    values (

      v_visit.organization_id,

      v_visit.store_id,

      v_payment_id,

      v_method,

      v_amount,

      v_reference,

      v_wallet_membership_id

    );


    -- Wallet 真正扣款
    if v_method =
       'member_wallet'
    then


      insert into public.member_wallet_ledger (

        organization_id,

        membership_id,

        amount_delta,

        transaction_type,

        reference_type,

        reference_id,

        notes,

        created_by_user_id

      )

      values (

        v_visit.organization_id,

        v_wallet_membership_id,

        -v_amount,

        'payment',

        'payment',

        v_payment_id,

        'SalonOS checkout wallet payment',

        auth.uid()

      );


    end if;


  end loop;


  -- ==================================================
  -- 20. 付款成功以后才真正扣库存
  -- ==================================================

  for v_product_item in

    select *

    from public.visit_product_items

    where visit_id =
          target_visit_id

      and status =
          'active'

  loop


    insert into public.inventory_stock_movements (

      organization_id,

      store_id,

      product_id,

      quantity_delta,

      movement_type,

      unit_cost,

      reference_type,

      reference_id,

      notes,

      created_by_user_id

    )

    values (

      v_product_item.organization_id,

      v_product_item.store_id,

      v_product_item.product_id,

      -v_product_item.quantity,

      'sale',

      v_product_item.cost_price_snapshot,

      'payment',

      v_payment_id,

      'SalonOS product sale',

      auth.uid()

    );


    -- =================================================
    -- 产品销售员工抽成
    -- =================================================

    if
      v_product_item.salesperson_employee_id
      is not null

      and

      v_product_item.commission_rate_snapshot
      > 0

    then


      insert into public.employee_commission_ledger (

        organization_id,

        store_id,

        employee_id,

        source_type,

        source_id,

        base_amount,

        commission_rate,

        commission_amount,

        notes

      )

      values (

        v_product_item.organization_id,

        v_product_item.store_id,

        v_product_item.salesperson_employee_id,

        'product',

        v_product_item.id,

        v_product_item.line_total,

        v_product_item.commission_rate_snapshot,

        round(

          (
            v_product_item.line_total
            *
            v_product_item.commission_rate_snapshot
            /
            100
          )::numeric,

          2

        ),

        v_product_item.product_name_snapshot
        ||
        ' product commission'

      )

      on conflict (
        employee_id,
        source_type,
        source_id
      )

      do nothing;


    end if;


  end loop;


  -- ==================================================
  -- 21. 消费 = Experience = Points
  -- ==================================================

  if loyalty_membership_id
     is not null

     and v_grand_total > 0

  then


    v_experience_earned :=
      v_grand_total;


    v_points_earned :=
      v_grand_total;


    insert into public.member_loyalty_ledger (

      organization_id,

      membership_id,

      experience_delta,

      points_delta,

      transaction_type,

      reference_type,

      reference_id,

      notes,

      created_by_user_id

    )

    values (

      v_visit.organization_id,

      loyalty_membership_id,

      v_experience_earned,

      v_points_earned,

      'purchase',

      'payment',

      v_payment_id,

      'SalonOS purchase loyalty reward',

      auth.uid()

    );


  end if;


  -- ==================================================
  -- 22. 完成订单
  -- ==================================================

  update public.visits

  set

    status = 'completed',

    checked_out_at = now(),

    updated_at = now()

  where id =
        target_visit_id;


  -- ==================================================
  -- 23. 返回结账结果
  -- ==================================================

  return query

  select

    v_payment_id,

    v_receipt,

    v_grand_total,

    v_paid_total,

    v_change,

    v_wallet_used,

    v_experience_earned,

    v_points_earned;


end;
$function$
;
CREATE OR REPLACE FUNCTION public.trigger_record_service_performance()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$

begin

  if new.status = 'paid' then

    perform public.record_service_performance_for_payment(
      new.id
    );

  end if;

  return new;

end;
$function$
;
create trigger record_service_performance_after_payment after insert on public.payments for each row execute function public.trigger_record_service_performance();
