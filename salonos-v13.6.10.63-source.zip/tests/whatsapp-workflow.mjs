import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const files = {
  webhook: '6_1_WHATSAPP_WEBHOOK',
  state: '6_3_AI_WORKER_INTENT',
  policy: '6_5_APPOINTMENT_TOOL_LAYER',
  config: '6_6_AI_REPLY_CONVERSATION_STATE',
  booking: '6_7_APPOINTMENT_DRAFT_CONFIRM',
  reminder: '6_8_LIFECYCLE_INTELLIGENCE_REMINDER',
  change: '6_9_CANCEL_RESCHEDULE_EXISTING_CUSTOMER',
  leave: '6_10_49_LEAVE_APPOINTMENT_AVAILABILITY',
};
const extract = (source, start, end, name) => {
  const match = source.match(new RegExp(`^${start}public\\.${name} \\([\\s\\S]*?^${end}`, 'im'))
    ?? source.match(new RegExp(`^${start}public\\.${name}\\([\\s\\S]*?^${end}`, 'im'));
  assert.ok(match, `Expected release SQL for ${name}`);
  return match[0];
};

export async function verifyWhatsApp({ client, sql, one, value, org, store, employee, service, id }) {
  const sources = Object.fromEntries(await Promise.all(Object.entries(files).map(async ([key, file]) => [
    key, await readFile(new URL(`../v13/RUN_ONCE_V13_${file}.sql`, import.meta.url), 'utf8'),
  ])));
  const query = (statement, args) => sql(client, statement, args);
  const row = (statement, args) => one(client, statement, args);
  const scalar = (statement, args) => value(client, statement, args);
  const table = (key, name) => extract(sources[key], 'create table if not exists ', '\\);', name);
  const routine = (key, name) => extract(sources[key], 'create or replace function ', '\\$\\$;', name);
  const reminderConfig = sources.reminder.match(/^alter table public\.whatsapp_store_configs[\s\S]*?;/im)[0];
  await query(`
    create schema extensions;
    create extension pgcrypto with schema extensions;
    create table public.organizations(id uuid primary key);
    create table public.marketing_leads(id uuid primary key, customer_id uuid, updated_at timestamptz);
    drop table public.whatsapp_conversations;
    ${table('webhook', 'whatsapp_business_connections')}
    ${table('webhook', 'whatsapp_conversations')}
    ${table('webhook', 'whatsapp_messages')}
    ${table('state', 'whatsapp_ai_conversation_state')}
    ${table('config', 'whatsapp_store_configs')}
    ${reminderConfig}
    ${table('policy', 'whatsapp_ai_booking_settings')}
    ${table('policy', 'whatsapp_ai_employee_schedules')}
    ${table('leave', 'employee_leave_requests')}
    ${table('booking', 'whatsapp_ai_appointment_drafts')}
    ${table('booking', 'whatsapp_ai_booking_events')}
    ${table('change', 'whatsapp_ai_appointment_change_drafts')}
    ${table('change', 'whatsapp_ai_appointment_change_events')}
    ${table('reminder', 'whatsapp_appointment_reminders')}
    ${routine('policy', 'v1365_ai_queue_tenant')}
    ${routine('leave', 'v1365_ai_check_availability')}
    ${routine('leave', 'v1366_ai_check_availability')}
    ${routine('booking', 'v1367_ai_confirm_draft')}
    ${routine('change', 'v1369_ai_check_reschedule_availability')}
    ${routine('change', 'v1369_ai_confirm_change')}
    ${routine('reminder', 'v1368_sync_reminder_queue')}
    ${routine('reminder', 'v1368_claim_due_reminders')}
    ${routine('reminder', 'v1368_finish_reminder')}
  `);

  const [connection, conversation, message, queue] = [80, 81, 82, 83].map(id);
  const phone = '0000000000';
  await query('insert into organizations values($1)', [org]);
  await query("insert into whatsapp_business_connections(id,organization_id,store_id,phone_number_id) values($1,$2,$3,'local-fixture')", [connection, org, store]);
  await query('insert into whatsapp_store_configs(organization_id,store_id,connection_id) values($1,$2,$3)', [org, store, connection]);
  await query('insert into whatsapp_ai_booking_settings(organization_id,store_id) values($1,$2)', [org, store]);
  await query("insert into whatsapp_ai_employee_schedules(organization_id,store_id,employee_id,iso_weekday,start_time,end_time) select $1,$2,$3,weekday,'09:00','19:00' from generate_series(1,7) weekday", [org, store, employee]);
  await query('insert into whatsapp_conversations(id,organization_id,store_id,connection_id,customer_wa_id,customer_phone) values($1,$2,$3,$4,$5,$5)', [conversation, org, store, connection, phone]);
  await query("insert into whatsapp_messages(id,organization_id,store_id,connection_id,conversation_id,text_body) values($1,$2,$3,$4,$5,'Synthetic confirm')", [message, org, store, connection, conversation]);
  await query('insert into whatsapp_ai_queue(id,organization_id,store_id,connection_id,conversation_id,message_id) values($1,$2,$3,$4,$5,$6)', [queue, org, store, connection, conversation, message]);
  const date = await scalar("select ((now() at time zone 'Asia/Kuala_Lumpur')::date+3)::text");
  await query(`insert into whatsapp_ai_appointment_drafts(
    organization_id,store_id,connection_id,conversation_id,customer_phone,customer_name,
    age_collection_status,ethnicity_collection_status,service_id,service_name_snapshot,
    employee_id,employee_name_snapshot,appointment_date,appointment_time,scheduled_at,status
  ) values($1,$2,$3,$4,$5,'Synthetic WhatsApp guest','skipped','skipped',
    $6,'Fixture cut',$7,'Fixture A',$8::date,'14:00',
    ($8::date+time '14:00') at time zone 'Asia/Kuala_Lumpur','pending_confirmation')`,
  [org, store, connection, conversation, phone, service, employee, date]);

  const confirm = () => scalar('select public.v1367_ai_confirm_draft($1)', [queue]);
  const booked = await confirm();
  assert.equal(booked.status, 'confirmed', JSON.stringify(booked));
  const visit = booked.visit_id;
  const replay = await confirm();
  assert.equal(replay.status, 'already_confirmed');
  assert.equal(replay.visit_id, visit);
  assert.equal(await scalar("select count(*)::int from whatsapp_ai_booking_events where event_type='appointment_confirmed'"), 1);
  assert.equal(await scalar('select count(*)::int from visit_service_workers w join visit_service_items i on i.id=w.service_item_id where i.visit_id=$1 and w.employee_id=$2', [visit, employee]), 1);

  const reminder = () => row('select * from whatsapp_appointment_reminders where visit_id=$1', [visit]);
  const claim = async () => (await query('select id from public.v1368_claim_due_reminders(20)')).rows;
  const finish = (id, status, mode = null, meta = null, error = null) =>
    scalar('select public.v1368_finish_reminder($1,$2,$3,$4,null,$5)', [id, status, mode, meta, error]);
  const makeDue = () => query(`update whatsapp_store_configs set reminder_minutes_before=
    ceil(extract(epoch from ((select scheduled_at from visits where id=$1)-now()))/60)+1 where store_id=$2`, [visit, store]);
  await query('select public.v1368_sync_reminder_queue()');
  const initial = await reminder();
  assert.equal(initial.status, 'pending');
  assert.equal(initial.conversation_id, conversation);
  assert.ok(!(await claim()).some((task) => task.id === initial.id));
  await makeDue();
  assert.deepEqual(await claim(), [{ id: initial.id }]);
  assert.deepEqual(await claim(), []);
  await finish(initial.id, 'sent', 'text', 'synthetic-message-id');
  assert.equal((await reminder()).status, 'sent');

  const change = async (action, time = null) => {
    await query(`insert into whatsapp_ai_appointment_change_drafts(
      organization_id,store_id,connection_id,conversation_id,customer_phone,action_type,
      target_visit_id,requested_date,requested_time,requested_scheduled_at
    ) values($1,$2,$3,$4,$5,$6,$7,$8::date,$9::time,($8::date+$9::time) at time zone 'Asia/Kuala_Lumpur')`,
    [org, store, connection, conversation, phone, action, visit, date, time]);
    return scalar('select public.v1369_ai_confirm_change($1)', [queue]);
  };
  const moved = await change('reschedule', '16:00');
  assert.equal(moved.status, 'rescheduled', JSON.stringify(moved));
  const reset = await reminder();
  assert.equal(reset.id, initial.id);
  assert.equal(reset.status, 'pending');
  assert.equal(reset.attempts, 0);
  assert.equal(reset.meta_message_id, null);
  assert.equal(reset.scheduled_at.getTime() - initial.scheduled_at.getTime(), 2 * 60 * 60 * 1000);
  assert.equal(reset.due_at.getTime(), reset.scheduled_at.getTime() - reset.reminder_minutes_before * 60_000);
  assert.deepEqual(await claim(), []);
  await makeDue();
  assert.deepEqual(await claim(), [{ id: initial.id }]);
  await finish(initial.id, 'failed', null, null, 'Synthetic provider failure');

  const failures = [];
  await query("update whatsapp_appointment_reminders set updated_at=now()-interval '6 minutes' where id=$1", [initial.id]);
  if (!(await claim()).some((task) => task.id === initial.id)) {
    const failed = await reminder();
    failures.push(`Failed reminder was not reclaimed after 6 minutes: status=${failed.status}, attempts=${failed.attempts}.`);
  }
  await query("update whatsapp_appointment_reminders set status='processing',updated_at=now()-interval '11 minutes' where id=$1", [initial.id]);
  if (!(await claim()).some((task) => task.id === initial.id)) {
    const stuck = await reminder();
    failures.push(`Stuck reminder was not reclaimed after 11 minutes: status=${stuck.status}, attempts=${stuck.attempts}.`);
  }

  const cancelled = await change('cancel');
  assert.equal(cancelled.status, 'cancelled', JSON.stringify(cancelled));
  assert.equal(await scalar('select status from visits where id=$1', [visit]), 'cancelled');
  assert.equal((await reminder()).status, 'skipped');
  assert.deepEqual(await claim(), []);
  await finish(initial.id, 'sent', 'text', 'synthetic-late-callback');
  if ((await reminder()).status !== 'skipped') {
    failures.push('Late completion changed a cancelled reminder from skipped to sent.');
  }
  assert.equal(await scalar("select count(*)::int from whatsapp_ai_appointment_change_events where event_type in ('appointment_rescheduled','appointment_cancelled')"), 2);
  console.log('WhatsApp database passed: confirm, replay, staff assignment, first reminder, reschedule/rebase, cancellation and audit events.');
  assert.deepEqual(failures, [], failures.join('\n'));
}
