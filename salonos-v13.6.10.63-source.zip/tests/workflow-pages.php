<?php
declare(strict_types=1);
require __DIR__.'/../v13/supabase_all_modules.php';
require __DIR__.'/../v13/workflow_v1361062.php';

function v13_is_owner(): bool {return true;}
function v13_business_token(): string {return 'fixture';}
function salonos_supabase_identity(): array {return ['organization_id'=>'fixture-org'];}
function current_store(): array {return ['id'=>'fixture-store'];}
function e(string $s): string {return htmlspecialchars($s,ENT_QUOTES,'UTF-8');}
function money(mixed $v): string {return 'RM '.number_format((float)$v,2);}
function csrf_token(): string {return 'fixture-csrf';}
function ui_icon(string $name): string {return '';}
function user(): array {return ['id'=>'fixture-user'];}

function salonos_supabase_rest_rows(string $table,string $query,string $token): array {
    if($table==='service_categories')return [['id'=>'cut','name'=>'剪发','active'=>true]];
    if($table!=='services')throw new RuntimeException('Unexpected table '.$table);
    $base=['category_id'=>'cut','category'=>'剪发','default_price'=>20,'estimated_minutes'=>30,'allows_assistant'=>false];
    $rows=[['id'=>'active','name'=>'FixtureActiveService','active'=>true]+$base,['id'=>'archived','name'=>'FixtureArchivedService','active'=>false]+$base];
    if(str_contains($query,'active=eq.false'))return [$rows[1]];
    if(str_contains($query,'active=eq.true'))return [$rows[0]];
    return $rows;
}
function v13_rpc(string $name,array $args,string $token): array {
    $id='00000000-0000-4000-8000-000000000010';
    if(($args['p_store_id']??'')!=='fixture-store')throw new RuntimeException('Missing store scope');
    return match($name) {
        'v1361062_receipt_for_visit'=>['payment_id'=>$id,'receipt'=>'R-TEST','status'=>'paid','total'=>100,'external'=>80,'wallet'=>20,'refund'=>null],
        'v1361062_operations'=>[
            'orders'=>[['id'=>$id,'visit_number'=>'V-TEST','status'=>'waiting','order_at'=>'2026-10-01T13:00:00Z']],
            'messages'=>[['id'=>$id,'status'=>'failed','created_at'=>'2026-10-01T13:00:00Z','attempts'=>1,'customer_phone'=>'000000','error_group'=>'AI 服务']],
        ],
        default=>throw new RuntimeException('Unexpected RPC '.$name),
    };
}
function render_fixture(callable $render): string {
    ob_start();
    try{$render();return (string)ob_get_contents();}
    finally{ob_end_clean();}
}
function check(bool $ok,string $msg): void {if(!$ok)throw new RuntimeException($msg);}

$_GET=['show_archived'=>'1','category_id'=>'cut'];
$archived=render_fixture('v13_page_services');
check(str_contains($archived,'FixtureArchivedService')&&!str_contains($archived,'FixtureActiveService'),'Archive shows only stopped services');
check(str_contains($archived,'href="index.php?page=services&amp;show_archived=1&amp;category_id=cut"'),'Archive category link preserves mode');
check(str_contains($archived,'href="index.php?page=services&amp;show_archived=1"'),'Archive all link preserves mode');
$_GET=[];
$regular=render_fixture('v13_page_services');
check(str_contains($regular,'FixtureActiveService')&&!str_contains($regular,'FixtureArchivedService'),'Regular view shows only active services');
$_GET=['visit_id'=>'00000000-0000-4000-8000-000000000010'];
$receipt=render_fixture('v1361062_page_receipt');
check(str_contains($receipt,'R-TEST')&&str_contains($receipt,'refund_receipt_v1361062')&&str_contains($receipt,'external_confirmed'),'Receipt ties refund to an original receipt and requires external confirmation');
$ops=render_fixture('v1361062_page_operations');
check(str_contains($ops,'V-TEST')&&str_contains($ops,'board_date=2026-10-01')&&str_contains($ops,'wa_manual')&&str_contains($ops,'order_review'),'Pending list exposes both review workflows');
echo "PHP render: archive visibility, category URLs, receipt form and pending operations passed\n";
