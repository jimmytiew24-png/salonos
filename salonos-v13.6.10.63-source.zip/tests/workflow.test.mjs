import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {PGlite} from '@electric-sql/pglite';

const db=new PGlite();
const read=p=>readFileSync(new URL(p,import.meta.url),'utf8');
const migration=read('../v13/supabase/migrations/20261105075034_salonos_workflow_v1361062.sql');
const sql=(s,args=[])=>db.query(s,args);
const one=async(s,args=[]) => (await sql(s,args)).rows[0];
const value=async(s,args=[]) => Object.values(await one(s,args))[0];
const id=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const O=id(1), S=id(2), OWN=id(3), O2=id(4), S2=id(5), OUT=id(6), EMP=id(10), ALT=id(11), SERVICE=id(20);
const PRODUCT=id(21), MEMBER=id(31), CONV=id(34), Q1=id(35), Q2=id(36), Q3=id(37);
let PAY;
const who=async(actor)=>{await sql("select set_config('request.jwt.claim.sub',$1,false)",[actor]);};
const create=async(key,payload,store=S)=>value('select public.v1361062_create_owner_order($1,$2,$3::jsonb)',[store,key,JSON.stringify(payload)]);
const employee=(token,visit,status)=>value('select public.v13_employee_api($1,$2,$3::jsonb)',[token,'visit_status',JSON.stringify({visit_id:visit,status})]);
const ownerStatus=(visit,status)=>value('select public.v1361062_owner_visit_status($1,$2,$3)',[S,visit,status]);
const review=(kind,subject,pause=false)=>value('select public.v1361062_review_operation($1,$2,$3,$4,$5)',[S,kind,subject,'Review fixture',pause]);
const refund=(confirmed,ref,returned=true)=>value('select public.v1361062_refund_receipt($1,$2,$3,$4,$5,$6)',[S,PAY,'Customer returned full sale',confirmed,ref,returned]);
const booking=(phone,employee=EMP)=>({
  visit_type:'appointment',scheduled_at:'2099-01-06T15:00:00+08:00',notes:'test',
  customer:{id:null,name:'Synthetic customer',phone},
  recipients:[{key:'guest',name:'Synthetic guest',type:'friend'}],
  items:[{service_id:SERVICE,recipient_key:'guest',price:80,workers:[{id:employee,role:'primary',pct:100}]}],
  preference_type:'specified',preference_employee:employee,
});

try {
  await db.exec(read('schema-fixture.sql'));
  await db.exec(migration);
  await db.exec(migration); // re-running must keep the protected legacy wrapper intact
  const engine=await value('select current_setting(\'server_version\')');
  await sql('insert into stores(id,organization_id,name) values($1,$2,$3),($4,$5,$6)',[S,O,'A',S2,O2,'B']);
  await sql('insert into test_roles values($1,$2,$3,$4),($5,$6,$7,$4)',[OWN,O,S,'owner',OUT,O2,S2]);
  await sql("insert into employees(id,organization_id,primary_store_id,employee_code,name,position) values($1,$2,$3,'A','Fixture A','Stylist'),($4,$2,$3,'B','Fixture B','Stylist')",[EMP,O,S,ALT]);
  await sql('insert into employee_stores(organization_id,employee_id,store_id) values($1,$2,$3),($1,$4,$3)',[O,EMP,S,ALT]);
  await sql("insert into test_employee_sessions values('assigned',$1,$2,$3,'staff'),('unassigned',$4,$2,$3,'staff'),('cross',$4,$5,$6,'manager')",[EMP,O,S,ALT,O2,S2]);
  await sql("insert into services(id,organization_id,store_id,category,name,estimated_minutes,allows_assistant) values($1,$2,$3,'Cut','Fixture cut',60,true)",[SERVICE,O,S]);
  await who(OUT);
  await assert.rejects(create(id(40),booking('001')),/没有当前分行/);
  await who(OWN);
  const broken=booking('001');
  broken.items[0].workers[0].pct=99;
  await assert.rejects(create(id(40),broken),/贡献比例/);
  assert.equal(await value('select count(*)::int from customers'),0);
  assert.equal(await value('select count(*)::int from visits'),0);
  const payload=booking('001');
  const order=await create(id(40),payload);
  assert.equal(order.replayed,false);
  assert.equal((await create(id(40),payload)).visit_id,order.visit_id);
  assert.equal(await value('select count(*)::int from visit_recipients where visit_id=$1',[order.visit_id]),2);
  assert.equal(await value('select count(*)::int from appointment_employee_preferences where visit_id=$1',[order.visit_id]),1);
  assert.equal((await value('select public.v1361062_find_owner_order($1,$2)',[S,id(40)])).visit_id,order.visit_id);
  await assert.rejects(create(id(41),booking('002')),/时段已被占用/);
  assert.equal(await value('select count(*)::int from visits'),1);
  assert.equal(await value('select count(*)::int from customers'),1);
  const other=await create(id(42),booking('002',ALT));
  const adjacent=booking('003');
  adjacent.scheduled_at='2099-01-06T16:00:00+08:00';
  const later=await create(id(44),adjacent);
  await assert.rejects(sql("update visits set scheduled_at='2099-01-06T15:30:00+08:00' where id=$1",[later.visit_id]),/时段已被占用/);
  await ownerStatus(later.visit_id,'cancelled');
  const item=await value('select id from visit_service_items where visit_id=$1',[other.visit_id]);
  await assert.rejects(value('select public.v1361062_replace_workers($1,$2,$3::jsonb)',[S,item,JSON.stringify([{id:EMP,role:'primary',pct:100}])]),/时段已被占用/);
  assert.equal(await value('select employee_id from visit_service_workers where service_item_id=$1',[item]),ALT);
  await assert.rejects(employee('unassigned',order.visit_id,'arrived'),/不是这笔订单的负责员工/);
  await assert.rejects(employee('cross',order.visit_id,'arrived'),/找不到可操作的订单/);
  await assert.rejects(employee('assigned',order.visit_id,'ready_for_checkout'),/当前订单状态/);
  await employee('assigned',order.visit_id,'arrived');
  await ownerStatus(order.visit_id,'waiting');
  await employee('assigned',order.visit_id,'in_service');
  await employee('assigned',order.visit_id,'paused');
  await employee('assigned',order.visit_id,'ready_for_checkout');
  await assert.rejects(employee('assigned',order.visit_id,'waiting'),/当前订单状态/);
  await assert.rejects(value("select public.v13_employee_api('unassigned','visit_detail',jsonb_build_object('visit_id',$1::uuid))",[order.visit_id]),/不是这笔订单的负责员工/);
  assert.equal((await value("select public.v13_employee_api('assigned','catalog','{}')")).legacy,'catalog');
  console.log('Order: rollback, retry, conflict, worker replacement, owner and legacy employee permissions passed');

  const v=order.visit_id;
  await sql("insert into products(id,organization_id,store_id,sku,name,stock_enabled) values($1,$2,$3,'P-001','Fixture product',true)",[PRODUCT,O,S]);
  const pitem=await value("insert into visit_product_items(organization_id,store_id,visit_id,product_id,product_name_snapshot,unit_price,cost_price_snapshot,quantity,salesperson_employee_id,commission_rate_snapshot) values($1,$2,$3,$4,'Fixture product',20,8,1,$5,25) returning id",[O,S,v,PRODUCT,EMP]);
  const customer=await value("select customer_id from visit_recipients where visit_id=$1 and recipient_type='primary'",[v]);
  await sql("insert into membership_levels(id,organization_id,level_number,name,min_experience) values($1,$2,1,'Base',0),($3,$2,2,'Gold',80)",[id(38),O,id(39)]);
  await sql("insert into memberships(id,organization_id,customer_id,current_level_id,member_number) values($1,$2,$3,$4,'M-001')",[MEMBER,O,customer,id(39)]);
  await sql("insert into inventory_stock_movements(organization_id,store_id,product_id,quantity_delta,movement_type) values($1,$2,$3,3,'opening')",[O,S,PRODUCT]);
  await sql("insert into member_wallet_ledger(organization_id,membership_id,amount_delta,transaction_type) values($1,$2,50,'top_up')",[O,MEMBER]);
  const payArgs=[v,JSON.stringify([{method:'member_wallet',amount:20,membership_id:MEMBER},{method:'cash',amount:90}]),MEMBER];
  const checkout=()=>one('select * from public.checkout_visit($1,$2::jsonb,0,0,$3)',payArgs);
  const paid=await checkout();
  PAY=paid.payment_id;
  assert.ok(PAY);
  assert.equal(Number(paid.change_amount),10);
  await assert.rejects(checkout(),/not ready|already/i);
  await assert.rejects(employee('assigned',v,'waiting'),/已关闭或已结账/);
  await assert.rejects(sql("update visit_product_items set quantity=2 where id=$1",[pitem]),/已结账或已关闭/);
  await assert.rejects(sql("delete from visit_product_items where id=$1",[pitem]),/已结账或已关闭/);
  await assert.rejects(sql("insert into visit_product_items(organization_id,store_id,visit_id,product_id,product_name_snapshot,unit_price,cost_price_snapshot,quantity) values($1,$2,$3,$4,'Late product',20,8,1)",[O,S,v,PRODUCT]),/已结账或已关闭/);
  await assert.rejects(refund(false,null),/外部支付退款/);
  await assert.rejects(refund(true,'Fixture drawer reference',false),/确认已收到退回商品/);
  await sql("update inventory_stock_movements set reference_id=null where movement_type='sale'");
  await assert.rejects(refund(true,'Fixture drawer reference'),/缺失的扣库记录/);
  await sql("update inventory_stock_movements set reference_id=$1 where movement_type='sale'",[PAY]);
  assert.equal(await value('select status from payments where id=$1',[PAY]),'paid');
  const reversed=await refund(true,'Fixture drawer reference');
  assert.equal(Number(reversed.external_amount),80);
  assert.equal(Number(reversed.wallet_amount),20);
  assert.deepEqual(reversed.breakdown,{stock_rows:1,wallet_rows:1,loyalty_rows:1,commission_rows:1,commission_amount:5,performance_amount:80});
  assert.equal((await refund(true,'Fixture drawer reference')).id,reversed.id);
  assert.equal(await value('select status from payments where id=$1',[PAY]),'refunded');
  assert.equal(await value('select status from visits where id=$1',[v]),'completed');
  assert.equal(await value('select status from visit_product_items where id=$1',[pitem]),'returned');
  const originalReceipt=await value('select public.v1361062_receipt_for_visit($1,$2)',[S,v]);
  assert.equal(originalReceipt.receipt,paid.receipt_number);
  assert.equal(originalReceipt.products[0].returned,true);
  assert.equal(Number(originalReceipt.products[0].amount),20);
  for(const [table,field,balance,count] of [['inventory_stock_movements','quantity_delta',3,3],['member_wallet_ledger','amount_delta',50,3],['member_loyalty_ledger','points_delta',0,2],['employee_commission_ledger','commission_amount',0,2]]){
    assert.equal(Number(await value('select sum('+field+') from '+table)),balance,table);
    assert.equal(await value('select count(*)::int from '+table),count,table);
  }
  assert.equal(await value('select current_level_id from memberships where id=$1',[MEMBER]),id(38));
  assert.equal(await value("select count(*)::int from service_performance_ledger l join payments p on p.id=l.payment_id where p.status='paid'"),0);
  assert.equal(await value("select count(*)::int from service_performance_ledger where payment_id=$1",[PAY]),1);
  console.log('Refund: receipt lock, net cash, inventory, wallet, points, commission, historical performance and idempotency passed');

  const cancelled=await ownerStatus(other.visit_id,'cancelled');
  assert.equal(cancelled.status,'cancelled');
  const released=await create(id(43),booking('002',ALT));
  assert.ok(released.visit_id);
  await sql("update visits set scheduled_at=now()-interval '8 days' where id=$1",[released.visit_id]);
  await sql("insert into whatsapp_conversations values($1,$2,$3,'60000000000',true,now())",[CONV,O,S]);
  await sql("insert into whatsapp_ai_queue(id,organization_id,store_id,connection_id,conversation_id,message_id,status,available_at,last_error) values($1,$4,$5,$6,$7,$8,'failed',now()-interval '1 day','Meta error'),($2,$4,$5,$6,$7,$9,'queued',now()-interval '1 day',null),($3,$4,$5,$6,$7,$10,'processing',now(),null)",[Q1,Q2,Q3,O,S,id(80),CONV,id(81),id(82),id(83)]);
  const issues=await value('select public.v1361062_operations($1)',[S]);
  assert.equal(issues.orders.length,1);
  assert.equal(issues.messages.length,2);
  await review('order_review',released.visit_id);
  assert.equal(await value('select status from visits where id=$1',[released.visit_id]),'booked');
  await review('wa_manual',Q2,true);
  assert.equal(await value('select status from whatsapp_ai_queue where id=$1',[Q2]),'skipped');
  await assert.rejects(sql("update whatsapp_ai_queue set status='queued' where id=$1",[Q2]),/不能重新自动发送/);
  assert.equal(await value('select ai_enabled from whatsapp_conversations where id=$1',[CONV]),false);
  assert.equal((await review('wa_manual',Q2,true)).replayed,true);
  assert.equal((await value('select public.v1361062_operations($1)',[S])).messages.find(q=>q.id===Q2).can_resume,true);
  await value('select public.v1361062_resume_conversation($1,$2)',[S,CONV]);
  assert.equal(await value('select ai_enabled from whatsapp_conversations where id=$1',[CONV]),true);
  assert.equal(await value('select status from whatsapp_ai_queue where id=$1',[Q2]),'skipped');
  await assert.rejects(value('select public.v1361062_resume_conversation($1,$2)',[S,CONV]),/没有可恢复/);
  await assert.rejects(review('wa_manual',Q3),/正在处理或已完成/);
  assert.equal(await value("select has_function_privilege('anon','public.v1361062_refund_receipt(uuid,uuid,text,boolean,text,boolean)','EXECUTE')"),false);
  assert.equal(await value("select has_schema_privilege('authenticated','salonos_workflow','USAGE')"),false);
  assert.equal(await value("select has_function_privilege('authenticated','salonos_workflow.v13_employee_api(text,text,jsonb)','EXECUTE')"),false);
  console.log('Operations: overdue order review, manual takeover, no retries, and private schema access passed ('+engine+')');
} finally {
  await db.close();
}
