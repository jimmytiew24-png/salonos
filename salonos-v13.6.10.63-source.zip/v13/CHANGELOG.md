

## v13.6.10.60
- Reverted v13.6.10.59 aggressive Service Worker/cache-first performance changes that could mix stale CSS/JS with new HTML and break UI rendering.
- Restored stable v13.6.10.58 static asset loading/i18n behavior.
- Kept in-page category filtering for Services, Inventory, Sales Products and Product Bundles without page reload.
- No UI visual redesign.
## v13.6.10.59 — Navigation Performance + Instant Category Filters

- Kept the current SalonOS visual UI unchanged.
- Static PWA assets are served cache-first from a release-specific cache instead of being re-downloaded with `no-store` on every page transition.
- Navigation Preload reduces Service Worker startup delay for dynamic page requests without caching business HTML.
- Services / Inventory / Sales Products / Product Bundles category switching now filters cards in place with no page reload.
- No SQL and no Edge Function redeploy required.

# v13.6.10.58
- WhatsApp AI now requires an explicit stylist choice before availability/draft creation: choose a named stylist or ask the system to assign a qualified available stylist.
- Date/time-only replies can no longer be interpreted by the model as implicit system assignment; an unknown stylist preference remains a genuinely missing booking field.
- When a customer says `我要指定理发师` / `I want to choose a stylist` / `saya mahu pilih stylist`, the old unconfirmed draft is abandoned, its employee-dependent slots are cleared, and the worker asks only for the stylist name while preserving service/date/time.
- Multilingual Chinese, English and Bahasa Melayu prompts now acknowledge the known booking details and explain both stylist-choice options naturally.
- No SQL required. Redeploy only `supabase/functions/whatsapp-ai-worker/index.ts`.

# v13.6.10.57
- WhatsApp AI context-aware slot filling: short time-only replies (`晚上7点`, `7pm`, `下午3点`, `pukul 7 malam`) now fill only the time slot and preserve the service/stylist already established in the conversation.
- A time reply with no known date is acknowledged naturally and asks only for the date; a trusted known date is combined with the new time and continues through qualified availability/system assignment.
- Customer-explicit dates from price/service conversations now retain provenance so a following time reply cannot be mistaken for a date or reset the transaction.
- Numeric clock replies inherit the conversation language; Malaysian Malay detection was expanded without translating store-defined service or employee names.
- No SQL required. Redeploy only `supabase/functions/whatsapp-ai-worker/index.ts`.

# v13.6.10.56
- WhatsApp AI conversational upgrade: customer-language replies, rapid-message dedupe, deterministic today/now/time continuation, real service price replies, single-stylist auto-resolution, friendlier slot collection, and multi-person clarification.

# v13.6.10.55

- Inventory image cards separated media/content so photos no longer cover text on desktop/mobile.
- Owner avatar is clickable on desktop/mobile and opens profile modal with avatar change + logout.
- Requires RUN_ONCE_V13_6_10_55_OWNER_AVATAR.sql for owner profile avatar persistence.

- Social Inbox redesigned as guided Instagram/Facebook setup cards with tutorial modals, wizard, connection status, recent inbox preview and manual source capture.
- Requires RUN_ONCE_V13_6_10_54_SOCIAL_INBOX_TUTORIAL_UI.sql for manual lead table.

## 13.6.10.53
- Clickable Order History detail + customer signature evidence.
- Authorized manual employee clock-in/out with audit note.
- Instagram/Facebook Direct Message Inbox capture foundation + Meta webhook.

## v13.6.10.51 — Role modal permissions + personal UI language
- System Settings permissions are granular per module.
- Role Permissions now shows positions only; click a role to edit in a modal.
- Personal UI language is per user and no longer changes everyone.

## v13.6.10.49 — Leave-aware appointments + leave approval

- AI appointment availability no longer depends on whether an employee has clocked in today.
- Added employee leave requests from Staff Attendance with date range + reason.
- Added owner approval/rejection workflow in Staff Attendance.
- Only approved leave blocks the employee from AI appointment availability for the approved dates.
- Pending/rejected leave does not block appointments.
- Same-day Walk-in assignment still requires a real Clock In.
- Attendance snapshot now shows approved leave as On Leave.
- Added bilingual UI strings for the new leave workflow.

## v13.6.10.48 — Bilingual UI + Monthly Attendance
- Fixed English language switch loading.
- Added cache-safe system-wide English translation layer.
- Added monthly attendance summary to employee performance details.

# v13.6.10.45
- Added visible full-screen version update feedback before automatic PWA/browser refresh.
- Keeps update feedback visible across reload and shows old -> new version when available.
- Shared by Owner, Staff and Creator.
- Preserves dirty-form protection so unsaved edits are not force-reloaded.
- Cache-busted shared PWA updater and bumped app/Creator service-worker cache IDs.
- No SQL or Edge Function redeploy required.

# v13.6.10.42
- Added global page-switch loading overlay for Owner/Staff/Creator.
- Prevents repeated taps while a navigation or normal form submission is already in progress.
- Loader auto-clears on pageshow/load, including browser back-forward cache restores.

## v13.6.10.41
- Mobile Owner/Staff: removed bottom quick navigation; hamburger/sidebar only.
- Reduced mobile bottom content padding after nav removal.

## v13.6.10.37 — WhatsApp Setup UX / Beginner Wizard
- Rebuilt Settings -> WhatsApp Business around a simple connection-status dashboard.
- Added Manual / Connect with Meta method cards.
- Converted Manual Cloud API setup into a 5-step onboarding wizard.
- Added in-product tutorial modals for App ID, App Secret, WABA/Phone ID, System User Token and Webhook setup.
- Moved technical IDs, token rotation, templates and diagnostics into collapsed Advanced sections.
- Preserved all v13.6.10.36 Manual Multi-App backend and security behavior.
- No SQL or Edge Function redeploy required.

## v13.6.10.36 — Customer-Owned Meta App Manual Cloud API Connect
- Added authenticated `whatsapp-manual-connect` Edge Function.
- Added per-customer App Secret + hashed Verify Token storage.
- Added customer Manual Cloud API wizard and one-time webhook setup handoff.
- Added token/app/WABA/phone validation before connection persistence.
- Upgraded shared `whatsapp-webhook` for strict multi-App signature verification.
- Preserved legacy/global SalonOS Meta App webhook path and stable AI worker.
- New SQL required; new manual-connect function + webhook redeploy required.

## v13.6.10.35 — Customer WhatsApp Embedded Signup Foundation
- Added Meta Embedded Signup customer onboarding for branch-owned WhatsApp Business accounts.
- Added existing WhatsApp Business App / Coexistence launch path and standard Cloud API path.
- Added authenticated `whatsapp-embedded-signup` Edge Function for code exchange, WABA verification, webhook subscription and branch-scoped business-token storage.
- Added onboarding/token-source/audit metadata and a non-secret Embedded Signup audit table.
- Reframed manual Phone Number ID / Access Token entry as Advanced fallback.

## v13.6.10.34 — Meta Delivery Failure Isolation
- Fixed the second outbound-send path that still threw Meta delivery/authentication errors and surfaced them as worker HTTP 500.
- Meta delivery errors now mark the outbound/reply audit as failed while allowing queue, AI, booking and conversation state to finish truthfully.
- Added richer Meta send diagnostics with available Graph error code, subcode, type, trace and HTTP status.
- Keeps all v13.6.10.33 relative-date follow-up behavior unchanged.
- No SQL; WhatsApp AI worker redeploy required.
- A rejected/expired Meta token must still be renewed or replaced; code cannot bypass Meta authentication.

## v13.6.10.33 — Relative Date Follow-up Guard
- Fixes `明天呢` / `tomorrow?` / `esok?` reusing the previous appointment date.
- Adds deterministic relative-date arithmetic using the worker's Asia/Kuala_Lumpur local clock.
- Prevents unresolved explicit dates from falling back to stale prior dates.
- Corrects date provenance so `customer_explicit` means the current turn actually resolved the customer's date.
- Preserves the previous exact appointment time for date-only follow-ups unless a new time/daypart is stated.
- No SQL; WhatsApp AI worker redeploy required.

## v13.6.10.32 — Fresh Booking Date Provenance Guard
- Fixed fresh booking requests inheriting a date from cancelled/failed/older appointment state.
- Fixed model-side implicit `today` when the latest message only contains a time.
- Explicit fresh booking requests cancel/abandon an older unconfirmed draft before starting the new transaction.
- Added trusted date provenance: `customer_explicit`, `draft_authoritative`, `carried_same_transaction`.
- Legacy date slots without provenance are not trusted.
- Added diagnostic fields to `whatsapp_ai_runs.input_snapshot`.
- No new SQL; WhatsApp AI worker redeploy required.

## v13.6.10.31 — WhatsApp Staff / Service Entity Separation
- Fixes compact customer text such as `weihong染头发` being treated as one service name.
- Adds branch-scoped deterministic employee mention detection before service/staff resolution.
- Adds multilingual deterministic service aliases including `染头发` / `染頭髮`.
- Prevents a new appointment from inheriting stale slots after cancel/reschedule.
- Corrects service not-found wording.
- No SQL; WhatsApp worker redeploy required.

## v13.6.10.30 — Manual Booking Staff Integrity
- Unifies manual SalonOS New Order staff filtering with service skills, requested-date schedule/breaks, and active Visit conflicts.
- `available_stylists` now uses the actual selected service IDs and returns `common`, `by_service`, and `assistant_pool` instead of a store-wide active employee list.
- Lead/co-stylist dropdowns are service-specific; assistants must be free for the booking window.
- Final server-side preflight runs immediately before order creation, so stale frontend choices cannot silently create an invalid team.
- System assignment now chooses from the qualified + scheduled + free pool and avoids employees already selected as collaborators.
- Existing service-item worker reassignment validates the full replacement team before deleting old worker rows.
- Future appointments depend on the requested schedule, not the employee's current live on-duty flag; walk-ins still respect live Service Board status.
- Cancelled/no-show/completed Visits stop blocking availability while historical worker assignments remain intact.
- Owner `datetime-local` appointments are persisted with an explicit Asia/Kuala_Lumpur offset.
- Requires one SQL patch; no WhatsApp Edge Function redeploy.

## v13.6.10.29 — Order Detail Worker Scope Fix
- Fixes Service Board order detail modal showing staff from unrelated orders in the same store.
- `v13_owner_visit_detail()` now scopes `visit_service_workers` to the current visit's service-item IDs instead of loading up to 1000 store-wide worker rows.
- Owner detail items are now hydrated with their exact `workers` array, so the top `员工` summary and each SERVICE ITEM use the same assignment data.
- `visit_service_signoffs` is scoped to the same current-order service items to prevent cross-order detail leakage.
- No SQL migration and no WhatsApp Edge Function redeploy required; web package only.

## v13.6.10.28 — Booking Staff Follow-up State Machine
- Fixes booking follow-ups such as `换个人做咯不一定要fatchew`, `have another 理发师?`, `have 谁可以做`, `random`, and `谁都可以`.
- A request for another stylist now preserves the known service/date/time, clears the old specified stylist, and queries the qualified + available staff pool instead of keeping the previous name.
- `who can do / who is available / 还有谁 / 谁可以做` now shows qualified alternatives and waits for the customer to choose a name/number or say `random`; it does not silently mutate or confirm the old draft.
- Replies to an alternative list can select a stylist deterministically by name or list number.
- Generic `换成 / change to` no longer becomes an existing-appointment reschedule unless the message actually contains a date/time target; staff/service edits stay inside the booking draft flow.
- Pending booking-draft revisions now take precedence for staff, service, date, and time changes, blocking the old `future appointment ... self-service` loop.
- Booking detail revisions can escape profile-collection states instead of being mistaken for name/age/ethnicity answers.
- Plain cancel phrases can cancel an unconfirmed draft at any booking stage.
- Draft confirmation is restricted to explicit confirmation states so stale draft values cannot be confirmed while a revision is unresolved.
- Directly specified stylists are now checked against `service_skill_requirements` + `employee_skills` before availability, matching the random-assignment qualification rule.
- Damaged conversations can recover booking context from recent inbound `ai_entities` even if a previous safe fallback reset the conversation state.
- No new SQL migration; redeploy `whatsapp-ai-worker`.

## v13.6.10.27 — Booking Draft Revision Precedence Fix
- Confirmed the remaining repeated self-service reply was caused by router precedence, not draft lookup.
- `deterministicDraftRevision` correctly classified a pending-draft time change as `appointment`.
- The following reschedule-continuity rule immediately overwrote it to `reschedule` whenever the previous state was `reschedule_not_found`.
- Draft revision now bypasses that stale continuity rule and is explicitly locked to the appointment flow.
- Added `deterministic_draft_revision_router` diagnostics.
- No SQL migration; redeploy `whatsapp-ai-worker`.

## 13.6.10.26 — Draft History Recovery + State Preservation

- Replaced named-column latest-draft lookup with schema-tolerant `select("*")` plus created_at ordering fallback.
- Added bounded six-hour recovery from recent `whatsapp_ai_runs` snapshots when old versions already wiped `slots.booking_draft`.
- Re-validates recovered draft IDs against `whatsapp_ai_appointment_drafts` whenever possible.
- Preserves a recoverable unconfirmed booking draft in conversation state on later generic routing turns.
- Adds richer `booking_draft_lookup` diagnostics to AI run input snapshots.
- No new SQL migration required.

## 13.6.10.25 — Draft Lookup Failsafe + Misroute Guard

- Fixes another concrete path that could still produce `I couldn't find a future appointment...` while an UNCONFIRMED booking draft existed.
- v13.6.10.24 selected later `assignment_type / assignment_strategy` columns in the same PostgREST query as the core draft fields and ignored the query error. A schema mismatch could therefore become `data = null`, which looked like “no draft”.
- Worker now retries the draft lookup with v13.6.7-compatible base columns when the full select errors.
- If no DB row is available, the durable `conversation_state.slots.booking_draft` snapshot is used as a second recovery source.
- A terminal DB row still blocks old snapshot resurrection.
- Random-vs-specified stylist assignment metadata is retained when the fallback query is used.
- `whatsapp_ai_runs.input_snapshot.booking_draft_lookup` now records lookup source/error/draft id/status for diagnosis.
- Natural Chinese hour revisions such as `下午三点` are accepted.
- No new SQL migration is required for this patch. Deploy the included `whatsapp-ai-worker/index.ts`.

## 13.6.10.24 — Stale Booking Draft Recovery

- Fixes the remaining loop where `I couldn't find a future appointment...` could continue even after v13.6.10.23.
- Confirmed root cause: v13.6.10.23 only loaded a draft when `expires_at > now()`. SalonOS booking drafts expire after 20 minutes.
- After 20 minutes, the worker stopped seeing the still-unconfirmed draft and again interpreted `换去下午3点 / change to 3 PM` as rescheduling a confirmed appointment.
- Worker now inspects the latest booking transaction for the conversation.
- An active or recently-expired unconfirmed draft is recoverable for 24 hours.
- A time/date revision reactivates the SAME draft for 20 minutes and then re-runs the normal skill + availability pipeline.
- A stale `confirm` is never blindly accepted; SalonOS asks for the desired time again so availability is revalidated.
- A newer confirmed/cancelled/failed transaction prevents an older expired draft from being resurrected.
- No SQL required.
- `whatsapp-ai-worker` Edge Function redeploy is REQUIRED.

## 13.6.10.23 — Pending Booking Draft Revision Router Fix

- Fixes the WhatsApp loop: `I couldn't find a future appointment for this WhatsApp number...` while the customer actually has an UNCONFIRMED booking draft.
- Root cause: phrases such as `我要换去下午3点 / change to 3 PM` were sent through the existing-confirmed-appointment reschedule router.
- Pending draft date/time revisions are now deterministically treated as `appointment` draft edits, never as rescheduling a confirmed Visit.
- A durable pending draft is read directly from `whatsapp_ai_appointment_drafts`, so it can recover even after conversation state was previously misrouted.
- If the conversation is already stuck in `reschedule_not_found`, replying `confirm` no longer blindly confirms the old draft or repeats the no-appointment message; SalonOS restores booking flow and asks for the desired new time again.
- Once the customer sends the new time, SalonOS re-runs service skill + full staff-pool availability and updates the SAME draft while preserving name/age/ethnicity.
- No new SQL required.
- WhatsApp `whatsapp-ai-worker` Edge Function redeploy IS REQUIRED.

## 13.6.10.22 — Unified Staff Pool & Service Board Availability

- Fixes WhatsApp AI saying no stylist is free while Service Board visibly shows another employee as Available.
- Root cause: AI previously required a separate hidden `whatsapp_ai_employee_schedules` row; Service Board did not.
- AI availability now uses a dedicated employee schedule when configured, otherwise falls back to the Service Board 09:00–00:00 operating window.
- Real Visit conflicts remain the final availability truth.
- System/random assignment continues checking all qualified employees; a busy stylist is skipped and another qualified + free stylist can be assigned.
- Required service skills remain mandatory. "Available" only means free/on-duty; it does not by itself mean qualified for Hair Coloring.
- Re-syncs employee `skill_tags` into canonical `employee_skills`.
- Requires one SQL run: `RUN_ONCE_V13_6_10_22_UNIFIED_STAFF_POOL.sql`.
- No WhatsApp Edge Function redeploy required.

## 13.6.10.21 — Canonical Marketing Lifecycle Sync

- Fixes the remaining mismatch where CLOSED LOOP HEALTH showed Visit/Arrived/Paid = 1 but the Marketing KPI cards/funnel/content analytics still showed 0 / RM0.
- Adds `v13621_marketing_lifecycle_rows(...)`, a secure per-First-Touch-customer lifecycle RPC.
- KPI cards, Customer Funnel, Content Performance, Channel Quality, Staff IP Ranking, Media Account Ranking and source-detail table now use the same canonical Visits/Payments lifecycle source.
- Old PHP REST joins remain only as a fallback.
- Does not rewrite First-Touch attribution.
- Does not duplicate payment/revenue data.
- Requires one SQL run: `RUN_ONCE_V13_6_10_21_MARKETING_LIFECYCLE_RPC.sql`.
- No WhatsApp Edge Function redeploy required.

## 13.6.10.20 — Closed Loop Summary Carry Fix

- Fixes the remaining false `SQL REQUIRED / 0 / 0` display after the v13.6.10.19 Health RPC was successfully installed.
- Root cause: the v13.6.10.17 filter/ranking page rebuilt a local `$summary` and accidentally dropped the closed-loop fields returned by the dataset/RPC.
- The page-local summary now carries `bridge_ready`, Customer Linked, Visit Linked, Arrived, Paid, Revenue and bridge version from the database health dataset.
- No new SQL is required if v13.6.10.19 Health RPC already shows READY in Supabase.
- No WhatsApp Edge Function redeploy required.

## 13.6.10.19 — Closed Loop Health RPC Fix

- Fixes a false `SQL REQUIRED` state after the v13.6.10.18 Bridge SQL had actually succeeded.
- Root cause: the old web UI probed `salonos_system_meta` through ordinary owner REST/RLS and could receive no marker row.
- Adds `v13619_closed_loop_health(...)` SECURITY DEFINER RPC with owner/store permission validation.
- CLOSED LOOP HEALTH now reads exact tenant/date-scoped Customer Linked / Visit Linked / Arrived / Paid counts from the database.
- Does not alter First-Touch attribution.
- Does not duplicate Revenue.
- Requires one SQL run: `RUN_ONCE_V13_6_10_19_CLOSED_LOOP_HEALTH_RPC.sql`.
- No WhatsApp Edge Function redeploy required.

## 13.6.10.18 — Marketing Closed Loop Bridge

- Adds a database-level lifecycle bridge from immutable WhatsApp First Touch to canonical SalonOS Customer and the first eligible post-touch Visit.
- Works for both WhatsApp AI-created appointments and manual SalonOS visits because both use `visit_recipients`.
- Never attributes a visit that existed before the customer's first WhatsApp touch.
- Backfills existing First-Touch customers to canonical customers by normalized phone.
- Backfills the earliest Marketing Lead to the first eligible post-touch Visit.
- Arrived / Paid / Revenue remain live canonical data from `visits` / `payments`; no revenue totals are duplicated into marketing tables.
- Marketing 来源分析 now has a compact CLOSED LOOP HEALTH section.
- Requires one SQL run: `RUN_ONCE_V13_6_10_18_MARKETING_CLOSED_LOOP_BRIDGE.sql`.
- No WhatsApp Edge Function redeploy required.

## 13.6.10.17 — Marketing Filters & Ranking

- Adds one owner filter console to Marketing 来源分析.
- Date remains Day / Month / Year + anchor date.
- Adds source filters for Platform, Staff IP and Content Placement.
- Adds ranking modes: Unique Customers, Booked, Arrived, Revenue, Repeat Rate and Loyal Customers.
- Filtered summary cards and customer funnel recalculate from the same First-Touch cohort.
- Content Performance, Channel Quality, Staff IP Ranking, Media Account Ranking and First-Touch Detail all follow the selected filters and ranking mode.
- Link opens remain diagnostic-only and never affect customer counts or ranking.
- Filters never mutate immutable First-Touch attribution.
- No SQL migration and no Edge Function redeploy required.

## 13.6.10.16 — Content Lifecycle Status

- Content Performance cards now show `ACTIVE` or `OFF · HISTORICAL`.
- Disabled Tracking Links remain visible when they own historical First-Touch customers.
- Content detail small modal explains whether the link is current or historical.
- Historical links explicitly state that they cannot acquire new traffic but keep old First-Touch customers, Booking, Arrived and Revenue.
- Adds First-Touch lifecycle time range for each tracked content/link.
- Link opens remain diagnostic-only and do not affect customer counts or rankings.
- No SQL migration and no Edge Function redeploy required.

## 13.6.10.15 — Content Performance Analytics

- Adds First-Touch content performance for Profile / Reel / Post / Story and other tracked media placements.
- Rankings use UNIQUE WhatsApp customers and downstream Booking / Arrived / Repeat / Loyal / Revenue.
- Link opens remain technical diagnostics only and never affect customer counts or content ranking.
- Each content card opens a SalonOS small modal with detailed lifecycle metrics and its unique First-Touch customer list.
- Customer rows show name, phone, first WhatsApp touch time, lifecycle badges and attributed revenue.
- One customer belongs only to the first tracked content/source that brought that phone into WhatsApp; later Facebook/Instagram/TikTok entries do not move the attribution.
- No SQL migration and no Edge Function redeploy required from v13.6.10.14.

## 13.6.10.14 — Dynamic Version & Cache Busting

- Centralizes the displayed SalonOS version through `salonos_app_version()`.
- Sidebar version now always reads the current `v13/VERSION` file.
- Main CSS / JS / PWA service-worker URLs now use the same current VERSION as their cache-busting value.
- Removes stale hard-coded asset versions such as `13.6.10.8` and `13.6.2` from the main business shell.
- Creator status panel now reads the current root VERSION too.
- Service-worker cache name bumped for this release so old cached UI assets are discarded.
- No SQL migration and no Edge Function redeploy required.

## 13.6.10.13 — Profile Link Duplicate Guard

- Enforces: one media account may have only one ACTIVE Profile / Bio Tracking Link.
- Reel / Post / Story / Ad / QR / Landing links remain unlimited.
- Guard applies to create, edit, and re-enable.
- Existing legacy duplicates are not auto-deleted or auto-disabled, preserving historical attribution.
- Media Tracking page shows an amber warning when legacy duplicate active Profile links are detected.
- No SQL migration and no Edge Function redeploy required from v13.6.10.12.

## 13.6.10.12 — Media Content & Tracking Link Management Center

- Replaces the large Tracking Link builder with a SalonOS small-modal workflow.
- Adds one management center for Profile / Bio / Reel / Post / Story / Ad / QR / Landing links.
- `+ 新增内容 / Link` and `修改` use the same compact modal.
- Selecting a media account auto-fills its platform and linked employee.
- Profile / Bio remains account-level attribution with `content_id = NULL`.
- Reel / Post / Story create or update `marketing_contents` records and attach them to the Tracking Link.
- Tracking Link rows now support `复制链接`, `测试`, `修改`, and `停用`.
- Slug can be auto-suggested from account + content name and remains editable.
- WhatsApp destination always uses the active branch WhatsApp Business number.
- Existing First-Touch customer attribution stays immutable; editing a link does not rewrite historical first-source customers.
- No new SQL and no Edge Function redeploy required when upgrading from v13.6.10.11.

## 13.6.10.11 — Owner Analytics Overview
- Adds a simplified OWNER SNAPSHOT to the top of 经营分析.
- Adds clickable cards for current-period new customers, social new customers, best source platform, best staff IP, arrival conversion, repeat rate, stylist-loyal conversion and social attributed revenue.
- Every owner summary card opens a compact SalonOS modal / detail view.
- Preserves all existing detailed reports while moving the old 10 operational KPI cards into a collapsed “经营详细指标” block.
- Reuses immutable First Touch + unique WhatsApp phone rules from v13.6.10.9.
- No new SQL or Edge Function deploy is required when upgrading from v13.6.10.10.

## 13.6.10.10 — Marketing Lifecycle Quality Analytics
- Redesigns Marketing Analytics around first-touch acquisition cohorts instead of click volume.
- Adds unique Booked Customer, Arrived Customer, Repeat Customer and Stylist-Loyal Customer KPIs.
- Excludes visits that happened before the customer's first WhatsApp marketing touch.
- Attributes later paid revenue back to the immutable first source.
- Adds Customer Journey Funnel, Channel Quality comparison, Staff Personal-IP ranking and Media Account ranking.
- Detailed source rows now include repeat, loyalty and Revenue per Customer.
- No new SQL or Edge Function deploy is required when upgrading from v13.6.10.9.

## 13.6.10.9 — First-Touch Unique Customer Analytics
- Added immutable first-touch attribution keyed by Organization + Branch + normalized WhatsApp phone.
- Repeated messages and later platform entries no longer inflate or overwrite the customer's first source.
- Marketing Dashboard now treats unique WhatsApp phones as customers; raw link opens are diagnostic only.
- Customer Structure cards now open small modals with first media source, age bands, gender, ethnicity and detailed customer behavior.
- Malaysia +60 / local 0 phone formats are canonicalized for customer-source matching.
- Sidebar version display now reads `VERSION` dynamically.
- Requires one-time SQL `RUN_ONCE_V13_6_10_9_FIRST_TOUCH_UNIQUE_CUSTOMER_ANALYTICS.sql`; no Edge Function redeploy required.

## 13.6.10.8 — Marketing Analytics Employee Scope Fix
- Fixes Marketing 来源分析 failing with a misleading old v13.5.5 schema warning.
- Root cause: v13.6.10.7 incorrectly filtered `employees` by a non-existent `store_id` column.
- Employee display-name mapping is now organization-scoped while attribution rows remain current-store scoped.
- No SQL migration and no Edge Function redeploy required.

## 13.6.10.7 — Marketing Attribution Analytics
- Added Marketing 来源分析 page under 经营分析.
- Added funnel KPIs for Click → Lead → Appointment → Arrived → Revenue.
- Added channel, social account, source staff and placement breakdown.
- Profile attribution supports content_id NULL without treating it as missing data.
- No new SQL required.

# v13.6.10.6 — Media Account Small Modal UX

- Corrects v13.6.10.5 to follow the existing SalonOS modal-first UI rule.
- `+ Add Account` and `Modify` now open the same small dark modal instead of expanding a large editor in the settings page.
- Removes `edit_account` query-string navigation for this editor.
- Keeps all media-account fields, re-enable behavior, future Tracking Link mapping synchronization and historical Lead preservation.
- No database schema change and no Edge Function redeploy are required for the modal UI itself.
- Includes cumulative SQL for users who had not yet run the v13.6.10.5/10.4 destination repair.

# v13.6.10.5 — Media Account Edit

- Adds a Modify action to every Media / Staff Social Account row.
- Owners can correct platform, account type, display name, username, linked employee, Profile URL and external Account ID.
- Disabled media accounts remain editable and can be re-enabled.
- When an account's platform or linked employee changes, linked Tracking Links are synchronized for future attribution.
- Historical marketing leads are not rewritten.
- Includes cumulative `RUN_ONCE_V13_6_10_5_MEDIA_ACCOUNT_EDIT.sql`, which also installs the v13.6.10.4 WhatsApp Business destination repair for users upgrading directly from v13.6.10.3 or earlier.
- No Edge Function redeploy is required for this UI/account-edit feature.

# v13.6.10.1 — Groq JSON Fallback Hotfix

- Changed Groq intent structured output from strict JSON schema to non-strict schema.
- Added one automatic json_object retry for Groq JSON generation/validation failures.
- Local validateIntent remains authoritative.
- No SQL/database migration required.

## v13.6.10 — English Skills + Skill-Aware System Assignment

- Adds `skill_catalog`, `employee_skills`, and `service_skill_requirements` with English canonical skill codes and 1–5 proficiency levels.
- Seeds 54 salon skill definitions covering haircut, color, bleaching/highlights/balayage, perm, straightening, treatment, styling, grooming, extensions and wellness.
- Preserves legacy `employees.skill_tags` / service name/category and maps recognized Chinese/English/Malay legacy labels into the canonical English skill layer.
- Adds `v13610_ai_assign_staff`: no-preference appointments are assigned only after service-skill qualification and the existing branch schedule/break/visit-conflict availability check.
- No exact time means no early stylist assignment; pooled times are shown first, then the chosen time is re-evaluated before selecting a qualified available stylist.
- AI drafts persist `assignment_type` / `assignment_strategy`; confirmed system assignments are corrected to `random` preference analytics while the actual worker remains on `visit_service_workers`.
- Customer-specified stylist bookings remain `specified`.
- WhatsApp outbound replies default to English while multilingual inbound intent/no-preference phrases remain recognized.
- Common legacy Chinese service labels are rendered as English service descriptions in English WhatsApp replies.
- Requires `RUN_ONCE_V13_6_10_ENGLISH_SKILLS_SYSTEM_ASSIGNMENT.sql` before deploying the v13.6.10 WhatsApp worker.

## v13.6.9.7 — WhatsApp Reply + State Finalization Hotfix

- Fixes `intent = other` messages such as `你好` being recorded as `auto_reply_not_enabled_for_intent:other` and suppressed with no outbound WhatsApp message.
- Adds deterministic greeting reply plus a safe non-hallucinating fallback for unsupported intents.
- Resets completed booking/cancel/reschedule transaction state to `idle` and clears stale booking/change slots.
- Meta delivery failure is now audited without aborting business-state finalization after a backend mutation already succeeded.
- Keeps all v13.6.9.6 Service Board live-sync behavior unchanged.
- No new SQL migration is required.

## v13.6.9.6 — Service Board Live Sync

- Fixes stale Service Floor snapshots after WhatsApp AI reschedules an appointment: the detail modal could show 16:30 while the timeline/list still showed 15:00 until a manual refresh.
- Adds a lightweight 5-second authenticated board-signature check and automatically reloads only when board data actually changed.
- Adds `Cache-Control: no-store` for the Service Floor page and live endpoint, plus no-store modal fetches.
- Defers automatic reload while the service-detail modal is open, then re-checks after closing it.

## v13.6.9.5 — Reschedule Reference Scope Fix

- Fixes a hidden stale `appointment_reference` surviving from an older cancelled booking and filtering the current FUTURE + BOOKED lookup to the wrong visit number.
- New cancel/reschedule commands use a booking reference only when the customer explicitly includes one in the current message.
- Reference inheritance is limited to an already-active cancel/reschedule flow.
- Booking state now clears the top-level `appointment_reference` together with stale target/change fields.
- Keeps the v13.6.9.4 stale target UUID validation and the v13.6.9.3 Chinese half-hour parser fix.
- Database layer remains v13.6.9; no SQL migration is required.

## v13.6.9.4 — Reschedule Stale Target Guard

- Fixed persistent conversation state carrying a cancelled/completed `selected_target_visit_id` into a later appointment.
- Booking state now clears appointment-change fields.
- Reschedule now validates a carried target through `v1369_ai_find_upcoming_appointments` before checking availability and self-heals to the current FUTURE + BOOKED appointment when stale.
- Keeps the v13.6.9.3 Chinese half-hour parser fix (`4点半` → `16:30`).

## v13.6.9.3 — Reschedule Half-Hour Parser Hotfix

- Fixes Chinese explicit reschedule phrases such as `帮我改到明天下午4点半`: deterministic router now extracts `16:30`, not `16:00`.
- Supports Chinese `X点半`, `X点30分`, and `X:30` style clock input in explicit change commands.
- Keeps the existing guarded backend flow: availability must pass and the customer must still reply `确认改期` before the original visit is updated.
- No database migration is required beyond the existing v13.6.9 SQL.

## v13.6.9.2 — Deterministic Change Router Hotfix
- Explicit cancel/reschedule commands are recognized before Groq intent classification.
- Chinese relative date/time commands such as 今天 / 明天 / 后天, 上午 / 下午 / 晚上, 5点 / 5:30 / 17:00 are parsed deterministically for change requests.
- Prevents Groq Structured Output JSON failures from blocking clear appointment-change commands.
- Existing guarded find / availability / draft / explicit confirmation / final backend re-check flow remains unchanged.
- No database migration beyond v13.6.9.
- PWA cache/version marker bumped to v13.6.9.2; UI/UX layout remains unchanged.

## v13.6.9 — Cancel + Reschedule + Existing-Customer Continuity
- Added branch-safe discovery of the current WhatsApp customer's own future booked appointments.
- Added durable appointment-change drafts and audit events; cancellation and reschedule require explicit customer confirmation.
- Cancellation marks the canonical SalonOS visit `cancelled` and suppresses unsent reminders; it never counts as a completed visit.
- Reschedule keeps the same visit/services/staff, excludes the target visit during conflict checks, and performs a final locked availability re-check before changing `scheduled_at`.
- Rescheduled reminders are rebased/reset to the new appointment time, including appointments whose previous reminder had already been sent.
- Multiple matching appointments are shown as a numbered selection; multi-employee appointments require human handling instead of unsafe automatic changes.
- Returning-customer continuity can reuse favourite-service/dominant-stylist history for lookup when appropriate, without skipping the normal booking draft/confirmation rules or inferring sensitive data.
- PWA cache/version marker bumped to v13.6.9; UI/UX layout remains unchanged.

## v13.6.8.1 — Lifecycle Integrity Hotfix
- Fixed Owner/Reception service-board transition to `ready_for_checkout` so `service_completed_at` is always written.
- Added database lifecycle timestamp guard for arrival, start, service completion, and checkout.
- Safely backfills already completed + paid visits that had a missing `service_completed_at`.
- Keeps Customer Intelligence strict: booked/no-show appointments still do not count as completed visits.

## v13.6.8 — Appointment Lifecycle + Customer Intelligence + Reminder
- Search Customer now uses `v1368_ai_prepare_customer_context`, adding customer segment, completed-visit history, favourite service, dominant stylist and specified/random preference statistics.
- Completed Visit remains strict: completed service + checkout + paid payment (+ arrived for appointment visits). Booking/no-show/cancelled/unpaid never inflates history.
- Added `whatsapp_ai_visit_lifecycle_events` audit for WhatsApp-AI-created appointments without replacing the existing SalonOS visit/payment workflow.
- Added branch-scoped `whatsapp_appointment_reminders` queue with cancellation/completion suppression, retry controls and duplicate protection.
- Added scheduled `whatsapp-reminder-worker` Edge Function. Within the 24-hour WhatsApp customer-service window it can send text; outside the window it requires a configured Meta Approved Template.
- WhatsApp Settings now stores reminder policy per branch: enabled, minutes-before, text template, approved template name and language.
- PWA/browser cache bumped to v13.6.8.

## v13.6.7 — Customer Profile Collection + Appointment Draft + Confirm
- Added branch-scoped `whatsapp_ai_appointment_drafts`; selecting a slot creates/reuses a **draft only**, not a real appointment.
- Added controlled profile collection: name required; age/age range optional with explicit skip; ethnicity optional with explicit choices including `不愿透露`.
- Age/ethnicity may only be stored from explicit customer input. AI inference from name/language/photo/phone is prohibited by both prompt and backend accepted values/provenance.
- Existing customers reuse known profile data; only missing fields are requested.
- Added booking draft summary and explicit confirm/cancel state handling for short WhatsApp replies.
- Added `v1367_ai_confirm_draft(queue_id)` as the only AI booking creation path. It derives tenant scope from the verified queue, revalidates service/staff, and performs a final exact-slot availability check before INSERT.
- If the slot becomes unavailable before confirmation, no appointment is created; the draft moves to reschedule and backend alternatives are returned.
- Confirmed bookings create the canonical SalonOS `visits`, recipient, service item, service worker and specified-employee preference records.
- Appointment creation does not increment completed visits; normal arrival/service/checkout/payment rules remain unchanged.
- Added `whatsapp_ai_booking_events` audit history and v13.6.7 Search Customer wrapper for customer-provided age metadata.

## v13.6.6 — AI WhatsApp Reply + Multi-turn Conversation State
- Added branch-scoped WhatsApp send configuration (`whatsapp_store_configs`) and migrated the existing saved token into the current branch.
- Added secure owner/manager RPC for saving WhatsApp credentials without returning the Access Token.
- Added automatic Meta Cloud API text replies after deterministic SalonOS backend tools resolve appointment facts.
- Added outbound message linkage and `whatsapp_ai_reply_runs` for reply/send auditing.
- Added multi-turn appointment state so short follow-ups such as `3点` reuse the prior service/staff/date and re-check availability.
- Added deterministic afternoon handling (13:00–18:00 for broad afternoon requests).
- Unsupported intents remain suppressed until their backend tools exist; no appointment is created by this version.

## v13.6.5 — Appointment Tool Layer

- Added tenant-safe backend tools: `v1365_ai_resolve_service`, `v1365_ai_resolve_staff`, `v1365_ai_check_availability`.
- Added multilingual `service_search_terms` from the intent model; database resolution still validates only real branch records.
- Added `whatsapp_ai_employee_schedules` as the future-shift truth source; no default working hours are invented.
- Added `whatsapp_ai_booking_settings` for timezone, slot interval, notice and booking horizon.
- Added `whatsapp_ai_tool_runs` audit log for every backend tool call.
- AI Worker automatically runs appointment tools after intent detection.
- Still no automatic WhatsApp reply, appointment draft or appointment INSERT in this release.

## v13.6.4 — AI Provider Layer / Groq Free-Tier Development

- Added provider-selectable WhatsApp AI Worker (`AI_PROVIDER=groq|openai`).
- Added Groq API support using `POST /openai/v1/chat/completions`.
- Groq default model: `openai/gpt-oss-20b` with strict JSON Schema Structured Outputs.
- OpenAI remains supported as an optional provider; `OPENAI_INTENT_MODEL` is now honored.
- No database migration is required from v13.6.3.
- WhatsApp webhook, Search Customer, tenant isolation, queue/state/audit behavior remain unchanged.
- No customer-facing AI reply and no appointment mutation are introduced in this phase.

## v13.6.3 — Automatic WhatsApp AI Worker / Intent Router

- Added `supabase/functions/whatsapp-ai-worker/index.ts`: automatically claims AI queue items, runs mandatory Search Customer first, then classifies intent with OpenAI Structured Outputs.
- Added durable `whatsapp_ai_conversation_state` for multi-turn state and pending backend actions.
- Added `whatsapp_ai_runs` audit table for model/run troubleshooting and duration tracking.
- Added `ai_intent`, `ai_confidence`, `ai_entities`, and `ai_processed_at` to WhatsApp messages.
- Updated `whatsapp-webhook` to trigger the AI worker as a Supabase background task after queue creation, while returning the Meta webhook quickly.
- Hardened Tracking Ref attribution so a Ref is accepted only when it belongs to the same verified Organization + Branch as the incoming WhatsApp number.
- Default intent model is configurable with `OPENAI_MODEL`; fallback is `gpt-5.6-luna`.
- This phase does NOT send an AI reply and does NOT write appointments. The next backend action is stored as `pending_action` for the Tool Calling phase.
- PWA/browser cache version bumped to v13.6.3; UI/UX layout remains unchanged.

## v13.6.2 — AI Customer Context / Search Customer
- WhatsApp AI pipeline first action is now defined as deterministic customer lookup before any LLM reply.
- Added `v1362_ai_prepare_customer_context(queue_id)`; tenant, branch, phone and lead are derived from the verified queue/conversation rather than trusted AI-supplied IDs.
- Existing customers return completed visit count, last visit, favourite service, dominant stylist, membership/points/wallet and marketing attribution context.
- Unknown WhatsApp contacts remain Marketing Leads; the first enquiry does not automatically create a permanent Customer row.
- Added `customers.ethnicity_source`; allowed provenance is unknown/customer_provided/staff_entered/imported. AI-predicted race/ethnicity is intentionally unsupported.
- Visit history counts only completed + checked-out + paid visits; appointment/no-show/cancelled/unpaid records do not inflate customer history.
- PWA/browser build version bumped to v13.6.2; UI/UX layout remains unchanged.

## v13.5.11
- 经营分析新增「顾客结构分析」，按当前筛选期间的活跃顾客分成三类：首次到店新客、回访随机／未固定型、指定理发师忠诚客。
- 分类判断使用顾客在当前分行的历史累计完成订单：首次=累计1次；随机／未固定=累计2次以上且随机/系统次数>=指定次数；忠诚客=累计2次以上且指定次数>随机次数。
- 新客分析新增来源、年龄区间、种族分布与新客明细。
- 回访客显示累计到店、随机次数、指定次数、指定率；忠诚客额外显示最常指定理发师。
- 经营分析 CSV 导出加入顾客结构、新客来源/年龄/种族及三类顾客明细。
- 新建顾客订单新增「第一次到店来源」字段，支持 Google / Facebook / Instagram / TikTok / 小红书 / 朋友介绍 / WhatsApp / 路过门店或自定义来源。
- v13.5.11 起老板端与员工端新订单都会记录指定/随机偏好，供长期顾客忠诚度分析。
- 员工端需运行 RUN_ONCE_V13_5_11_CUSTOMER_SEGMENT_ANALYTICS.sql，以启用员工订单偏好与来源写入 RPC。
- PWA 静态缓存升级至 v13.5.11。

## v13.5.10
- 修复顾客订单待结账产品搜索：兼容旧产品只有文字分类、没有 category_id 的资料。
- 分类筛选现在同时按分类 UUID 与旧 category 名称匹配。
- 员工端搜索不再因为旧 category_id 为空而读取不到产品。
- 产品搜索结果加入 48x48 缩略图；图片失效时自动退回名称首字占位。
- 已选产品卡片继续显示产品图片、库存与售价。
- PWA 静态缓存升级至 v13.5.10。

## v13.5.9

- 修复服务现场「顾客订单」动态浮窗里的产品分类搜索没有初始化的问题。
- 选择产品分类后会立即列出该分类可销售产品，不需要先输入完整名称。
- 在已选分类内输入产品名称 / SKU / Barcode 可即时继续筛选。
- 老板端与员工端打开顾客订单浮窗时都会重新绑定同一套分类产品搜索。
- 无数据库结构变更，不需要运行 SQL。

## v13.5.8
- 预约签名规则改为到店后才开放。
- 负责员工可确认自己预约顾客到店（需 v13.5.8 SQL）。
- Dashboard 3 秒自动同步。


## v13.5.6 — Employee mobile order fix
- 修复员工端建立预约时日期／时间字段在部分手机浏览器与 PWA 无法点击的问题。
- 日期控件保留 DD/MM/YYYY 显示，但真实 date/datetime-local 控件透明覆盖整个输入区域，手机可直接调用系统 Picker。
- 修复员工端建立订单底部「下一步」操作栏被统一抬高 82px 的问题。
- 82px 底部偏移现在只用于有 Mobile Bottom Nav 的 Owner；员工端回到底部 0，不再无故挡住表单内容。
- 无数据库变更。


## v13.5.7
- 修复员工端预约使用 datetime-local 无时区值直接写入 Supabase 时被当成 UTC，导致马来西亚预约偏移 +8 小时、跨日或掉出 09:00–00:00 服务现场时间轴的问题。
- 员工预约现在在送往 Supabase 前转换为 Asia/Kuala_Lumpur 的明确 ISO 时区时间。
- 顾客签名完成或点击稍后处理后，会自动回到预约日期对应的服务现场，不再固定回今天。


## v13.6.0 Media Attribution
- Settings 增加媒体来源、门店/员工社交账号、Content 与 Tracking Link 管理。
- 默认渠道：Instagram / Facebook / TikTok / Google / XHS / Website / QR / Referral / Walk-in / Other。
- /t/<slug> 自动生成唯一 Ref、记录 click 并跳转 WhatsApp/URL。
- 建立 marketing_leads 数据底座，供后续 WhatsApp Webhook + AI Agent 连接 Lead → Appointment → Arrived → Revenue。

## v13.6.1 — WhatsApp Business Cloud API Webhook / AI Intake
- Added Supabase Edge Function `whatsapp-webhook`.
- GET webhook verification via `WHATSAPP_VERIFY_TOKEN`.
- POST Meta authenticity verification via `X-Hub-Signature-256` + `META_APP_SECRET` before privileged writes.
- Routes inbound events to the correct SalonOS organization/store using Meta `phone_number_id`.
- Added WhatsApp connections, conversations, messages and AI queue tables.
- Extracts SalonOS Tracking Ref from inbound messages and links WhatsApp leads back to Channel / Account / Content / Staff.
- Missing/deleted Ref is retained as a valid lead with `source_fallback_needed=true` for the AI fallback source question.
- Settings → WhatsApp now shows Edge Function callback URL, live webhook status, conversation/message counts and AI queue count.

## v13.6.10.2 — Groq Reasoning-Safe JSON Fallback Hotfix
- Prevented Groq GPT-OSS structured/JSON formatting failures from crashing the WhatsApp worker.
- Added include_reasoning=false, low reasoning effort, larger completion budget, and a three-stage JSON fallback.
- Added conservative deterministic booking extraction as a final safety net for explicit booking requests.
- No SQL migration required.

## 13.6.10.3 — Profile Attribution Full
- Packaged the profile-level WhatsApp attribution route as a complete SalonOS release.
- Kept the existing production `/t/<slug>` -> `track.php` flow that writes a unique tracking click and redirects to WhatsApp.
- Added a shared-hosting `/t/` fallback router that delegates to the same tracker.
- Profile links can attribute channel/social account/staff while leaving `content_id` NULL; content links continue to support `content_id`.
- Changed only the fallback WhatsApp prefill to English when no database prefill is configured.
- Added `SALONOS_PROGRESS.md` so each future release records the exact development step.

## v13.6.10.4 — Tracking Business Phone Fix
- Fixed profile/content tracking links opening the customer's own WhatsApp number when a stale `destination_phone` was stored.
- `v1360_marketing_track()` now prefers the branch's enabled WhatsApp Business connection display number.
- Added idempotent migration to repair existing active WhatsApp tracking links.
- New tracking links automatically use the connected branch WhatsApp Business number.
- Tracking Link Builder destination phone is read-only to prevent accidental customer-number routing.
- Default WhatsApp prefill is English.

## v13.6.10.46 — Expanded Role Permissions
- Expanded Role Permissions from the legacy short list into grouped operational permissions.
- Added employee attendance permissions: scan, team attendance visibility, counter rotating QR station.
- Added explicit view/manage entries for services, products, inventory, KPI, training and commission modules.
- Navigation and direct page access now use the same expanded permission mapping for operational pages.
- Attendance UI enforces role permissions for self scan, team status and QR station separately.
- Organization-security areas (role editor itself, WhatsApp credentials, data migration and tenant administration) remain owner-only by design.

## v13.6.10.50
- Added staff-role permission gate for System Settings and all settings sub-pages.
- Prevented English mode from flashing Chinese content before i18n translation by adding a pre-render i18n boot overlay.
