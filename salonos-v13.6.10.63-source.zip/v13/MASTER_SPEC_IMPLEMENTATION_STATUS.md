# v13.6.10.37 WhatsApp Setup UX Status

- Owner-facing WhatsApp settings are now beginner-first instead of developer-first.
- Manual Multi-App onboarding remains the current production path until Meta Embedded Signup can be activated.
- Manual onboarding is split into 5 guided steps with tutorial modals.
- Existing connection controls expose only daily business settings by default; technical details are under Advanced / Diagnostics.
- v13.6.10.36 backend, per-customer secrets, webhook HMAC, and AI worker are unchanged.

# v13.6.10.36 Manual Multi-App WhatsApp Status

- Real customers can manually connect their own Meta App / WABA / Cloud API number before SalonOS Tech Provider approval.
- Customer App Secret is server-only; Verify Token plaintext is one-time; webhook HMAC is verified per connection.
- Embedded Signup v13.6.10.35 remains the future recommended one-click path after Meta verification.
- `whatsapp-ai-worker` is unchanged in this release.

# v13.6.10.35 WhatsApp SaaS Onboarding Status

## Implemented in this build
- Branch-scoped Meta Embedded Signup foundation for customer-owned WhatsApp Business accounts.
- Standard Cloud API and WhatsApp Business App / Coexistence launch paths.
- Server-side one-time code exchange; Meta App Secret remains in Supabase Edge Function Secrets.
- Business token stored only in branch-scoped `whatsapp_store_configs`; never returned to browser.
- Customer WABA webhook subscription and phone/WABA ownership validation.
- Manual configuration retained as an Advanced fallback.

## Requires live Meta acceptance
- SalonOS Meta App must be configured for customer onboarding / Tech Provider requirements and current Embedded Signup v4.
- Required Meta permissions/advanced access and business verification must be approved where applicable.
- First external customer WABA must complete end-to-end acceptance before production certification.

# SalonOS v13.5.4 — Implementation Status

## Integrated in this build
- v12.4.4 UI/UX lock retained; Supabase Only runtime retained.
- Four-step Order Wizard and Team Appointment Board retained.
- New Order customer/member search now uses the same de-duplicated current-store `customers` dataset as 顾客与会员.
- Customer/member AJAX JSON contract retained; raw HTML redirect is not parsed as JSON.
- Product category folders are shared by Inventory / Retail Products / Product Bundles.
- Inventory / Retail Product / Product Bundle creation and editing are modal-first.
- Images continue to use compressed Supabase Storage objects; database stores URL/path metadata only.
- Member retail purchase: category-first product search + Member Wallet + Cash/Card/E-Wallet remainder.
- Member retail history stores item snapshots and displays purchased product names/quantity.
- Service Board checkout add-on products use category-first fuzzy search and visibly show PRODUCT ITEMS after adding.
- v13.5.2 custom permission roles and safe delete/archive behavior retained.
- v13.5.1 long-modal scrolling/media preview behavior retained.
- Complete portable product specification packaged at `docs/SalonOS_COMPLETE_PRODUCT_SPEC_v13.5.4.md`.

## Requires live Supabase acceptance
- Run the v13.5.4 SQL contract and confirm `/v13/system-test.php` passes.
- Test member wallet/product purchase against the live ledger constraints and stock RPC.
- Test Service Board product add-on → checkout → successful stock deduction.
- Test Owner/Manager/Front Desk role behavior across branches.

## Still not production-certified deep workflows
- exact concurrent Walk-in/Appointment collision engine;
- versioned re-sign history after order changes;
- full material reversal/audit workflow;
- all split-payment/refund/void edge cases;
- bundle transactional sale/component deduction/refund;
- KPI bonus lock and commission payout/refund reversal;
- WhatsApp scheduler/delivery logs;
- cross-tenant penetration/acceptance testing and production security review.
