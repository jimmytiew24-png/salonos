# SalonOS Progress · v13.6.10.39

## Completed in this build
- Simplified Creator BRN Code generation: no branch name/email pre-entry.
- Creator branch records use actual customer-created branch data after redemption.
- Creator responsive/mobile drawer navigation.
- Subscription pricing changed to RM300/month, RM3000/year, RM6000/2 years.
- Added rotating QR employee attendance with separate IN/OUT modes.
- Added owner/manager/reception counter QR station.
- Added employee mobile QR scanner.
- Added per-employee start/end/late-grace settings.
- Added live attendance status to Employee Management.
- Added Walk-in eligibility gate: attendance + duty + availability + existing skill/schedule/conflict rules.

## Current stable baseline preserved
- WhatsApp AI booking flow and Meta delivery code from prior builds.
- Branch creation modal from v13.6.10.38.
- Manual multi-app WhatsApp connection architecture.

## Next recommended validation
- Real phone camera permissions on Android/iPhone/PWA.
- Two employees scanning the same active QR within one 15-second cycle.
- Late arrival boundary tests.
- Walk-in customer selecting an employee before and after Clock In.
- Midnight / overnight shift behavior if a future salon needs it.
