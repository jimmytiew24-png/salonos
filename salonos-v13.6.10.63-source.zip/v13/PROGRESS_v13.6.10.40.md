# SalonOS Progress · v13.6.10.40

## Completed in this build
- Fixed upgrade compatibility for `employees_availability_status_check`.
- Attendance migration now upgrades the legacy availability constraint before writing `off_duty`.
- Corrected migration is idempotent and can be rerun after the failed v13.6.10.39 attempt.
- All v13.6.10.39 features are preserved: RM300 pricing, Creator mobile UI, rotating QR IN/OUT attendance, late status, and Walk-in attendance eligibility.

## Stable baseline preserved
- WhatsApp AI and Meta delivery.
- Manual multi-app WhatsApp connection.
- Branch creation modal.

## Next validation
- Run the v13.6.10.40 SQL and confirm READY / monthly_rm=300 / attendance_ok=true.
- Test Clock In and Clock Out with one employee.
- Confirm an employee without Clock In cannot be selected for Walk-in.
