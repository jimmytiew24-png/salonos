# SalonOS v13.6.10.42 Progress

## Completed
- Added a global loading overlay for Owner and Staff page navigation.
- Added immediate feedback on same-origin page links: "正在切换页面…".
- Added submit-state overlay: "正在处理…" and duplicate-click protection.
- Added BFCache/pageshow recovery so Back navigation never leaves the loader stuck.
- Added the same loading UX to Creator desktop/mobile navigation.
- Preserved hamburger-only mobile navigation from v13.6.10.41.
- No database or WhatsApp Edge Function changes.

## Current
- Page navigation feedback / repeated-click prevention.

## Next
- Continue field testing on slow mobile/PWA connections and opt out any AJAX-only form with data-no-page-loader if needed.
