# SalonOS v13.6.10.43

## Completed
- Added pre-checkout order product removal.
- Removal soft-cancels only the selected visit_product_items row; product catalog and history are untouched.
- Active-only order totals recalculate immediately.
- Completed/cancelled/no-show orders cannot remove add-ons.
- Added explicit confirmation before removal.

## Current
- Verify add product -> remove product -> add another product -> checkout flow.

## Next
- Consider quantity editing for an already-added order product if needed.
