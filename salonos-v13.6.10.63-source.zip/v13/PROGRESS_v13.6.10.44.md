# SalonOS v13.6.10.44

## Completed
- Customer / membership directory now behaves as a master-detail workspace.
- Clicking a customer on the left no longer reloads the full SalonOS page.
- Only the right customer/member detail panel is fetched and replaced.
- Selected customer highlight updates immediately.
- Browser URL/history still updates, so reload/back/forward remain meaningful.
- Right-side loading state prevents repeated clicks while profile data is loading.
- Customer/member AJAX save actions refresh only the right-side workspace instead of forcing a full page navigation.
- Mobile keeps the same behavior; after selecting a customer, the detail area can scroll into view.

## Preserved
- Customer list / search behavior.
- Membership, wallet, loyalty and product-purchase workflows.
- WhatsApp, attendance, branch creation, RM300 pricing and global loading guard unchanged.

## Current
- v13.6.10.44 CUSTOMER MASTER-DETAIL AJAX.

## Next
- Continue UX regression testing on customer search, member upgrade, wallet top-up and product purchase inside the partial workspace.
