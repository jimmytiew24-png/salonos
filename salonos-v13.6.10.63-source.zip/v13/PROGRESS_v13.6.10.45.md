# SalonOS v13.6.10.45

## Completed
- Added a visible full-screen release update state for Owner, Staff and Creator when SalonOS detects a newer deployed build.
- Update state appears before automatic reload with clear copy: SalonOS is updating, syncing latest files, and users do not need to tap repeatedly.
- Update state persists across the reload and briefly shows a completion phase so the refresh no longer looks unexplained.
- Added version text to the transition when available (old version -> new version).
- Added cache-busting to the shared `pwa-install.js` loader and bumped both app/Creator service-worker cache IDs.
- Preserved dirty-form protection: SalonOS will not force an update reload while the user has unsaved form input.
- Added a one-time migration completion state for clients upgrading from the older silent-update mechanism.

## Preserved
- Global navigation/submit loading guard.
- Mobile hamburger-only navigation.
- Customer master-detail AJAX.
- Attendance, WhatsApp, branch creation, RM300 pricing and order product removal unchanged.

## Deployment
- No SQL required.
- No Supabase Edge Function redeploy required.
- Upload/replace `/v13`, then allow the browser/PWA to refresh normally.

## Current
- v13.6.10.45 VERSION UPDATE FEEDBACK.

## Next
- Test one real deployment from 13.6.10.45 to the next build on desktop browser, Android PWA and iPhone Home Screen mode.
