# SalonOS v13.6.10.46

Completed: Expanded employee role permission matrix to match current SalonOS modules; grouped permissions by business area; wired attendance permissions to menu/page/UI; expanded navigation/page guards; preserved owner full access.
Current: Role-permission coverage expansion.
Next: Validate each delegated management action that currently requires an owner-only RPC before allowing non-owner mutation for those specific administrative modules.
