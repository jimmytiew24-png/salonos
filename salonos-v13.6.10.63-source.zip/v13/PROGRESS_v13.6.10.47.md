# SalonOS v13.6.10.48

## Completed
- Fixed the General Settings language switch so English actually loads the system-wide i18n layer after login.
- HTML language metadata now follows the selected interface language.
- i18n dictionary receives the application asset version to avoid stale PWA JSON caches.
- Expanded common English translations including attendance and performance terminology.
- Employee Performance Detail now shows owner-only monthly attendance counts for the selected year.
- Monthly attendance includes clock-in count, completed shifts, and late arrivals.

## Current
- Bilingual owner/staff interface and attendance visibility in employee performance.

## Next
- Continue adding translations if any page-specific Chinese text is discovered during real-device testing.
- Optional attendance exports / absence reasons / manual attendance corrections.

## Deployment
- Full /v13 overwrite.
- No SQL required.
- No Edge Function redeploy required.
