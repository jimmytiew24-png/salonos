# SalonOS v13.6.10.48 Progress

## Completed
- Reworked English i18n runtime to prefer whole-string translations and removed unsafe one-character replacement behavior that caused mixed Chinese/English UI.
- Audited current runtime UI source strings and expanded the English dictionary to cover static interface/help/error text in the latest build.
- Added order product salesperson selection. Product items can be credited to a selected active staff member.
- Product item rows show the salesperson, and existing employee performance RPCs continue to count `visit_product_items.salesperson_employee_id` toward product sales and commission.

## Current baseline
- Version: 13.6.10.48
- No new SQL required; `visit_product_items.salesperson_employee_id` already exists in the cumulative runtime schema.
- No WhatsApp Edge Function changes.

## Next
- Continue UI/UX testing in both Chinese and English, especially dynamic AJAX/modal states and user-entered business data.
