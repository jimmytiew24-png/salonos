# SalonOS v13.6.10.49 Progress

## Completed
- Decoupled AI appointment availability from live attendance / `is_on_duty`.
- Added `employee_leave_requests`.
- Staff can request leave with start/end date and reason.
- Owner can approve or reject leave from Staff Attendance.
- Approved leave blocks AI booking on overlapping dates.
- Pending/rejected requests do not block appointments.
- Walk-in assignment remains clock-in gated.
- English translations added for leave UI.

## Install
1. Upload the complete `/v13` folder.
2. Confirm `/v13/VERSION` is `13.6.10.49`.
3. Run `RUN_ONCE_V13_6_10_49_LEAVE_APPOINTMENT_AVAILABILITY.sql` in Supabase SQL Editor.
4. No WhatsApp Edge Function redeploy is required.

## Next
- Test: employee not clocked in + no approved leave => AI can still offer appointment slots.
- Test: approved leave date => AI must not offer that employee.
- Test: same-day Walk-in before Clock In => employee remains unavailable for Walk-in.
