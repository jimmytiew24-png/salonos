# SalonOS v13.6.10.50

## Completed
- Added `settings.view` to role permissions.
- System Settings menu is hidden for staff roles without `settings.view`.
- Direct access to Settings and all Settings sub-pages is blocked without permission.
- Fixed English navigation flash: English pages now enter an i18n boot state before body content becomes visible, show a neutral Loading SalonOS overlay, then reveal only after the English dictionary is applied.
- i18n boot state safely releases if dictionary loading fails.
- Updated PWA cache name for this release.

## Preserved
- v13.6.10.49 leave-aware appointment behavior.
- Attendance, WhatsApp AI, product salesperson, RM300 pricing, mobile hamburger-only navigation and all previous features.

## Next
- Verify each staff role from Settings > Role Permissions and explicitly enable System Settings only where needed.
