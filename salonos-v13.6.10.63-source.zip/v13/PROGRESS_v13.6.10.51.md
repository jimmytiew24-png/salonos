# SalonOS v13.6.10.51

## Completed
- Role Permissions page changed to position-only list; click a position to open a permission modal.
- Granular System Settings visibility permissions added per position.
- Personal UI language added; employee preference persists per employee and does not change other users.
- Organization language is now explicitly a default, not a forced global UI override.
- Employee WhatsApp / Marketing / Import / Transfer settings views are safe read-only surfaces; secrets and destructive actions stay owner-only.
- English pre-render boot now follows each user's effective UI language.

## Current
- Run the v13.6.10.51 SQL patch, upload the full /v13 build, then test one staff role with Settings permissions.

## Next
- Continue granular permissions for any newly added settings modules.
