# SalonOS v13.6.10.53

## Completed
- Order History rows open order detail modal.
- Historical order detail includes stored customer signature evidence and signed timestamp.
- Added `attendance.manual` permission and owner/counter manual clock-in/out fallback with mandatory note + audit trail.
- Added Instagram/Facebook Social Direct Message Inbox foundation, owner connection UI, schema and Meta webhook Edge Function.
- Preserved v13.6.10.51 personal language, granular Settings permissions, v13.6.10.49 leave-aware appointment rules and WhatsApp stack.

## Current
- IG/FB inbound messaging capture is ready once a customer's Meta App has the required Messaging permissions and webhook subscription.

## Next
- Optional: unify WhatsApp + Instagram + Facebook into one omnichannel conversation inbox and let the AI agent answer across channels.
