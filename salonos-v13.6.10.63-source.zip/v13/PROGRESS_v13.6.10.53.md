# SalonOS v13.6.10.53

## Completed
- Fixed historical customer signature evidence visibility.
- Signature proof panel now uses a dark canvas so the existing white signature strokes remain clearly visible.
- No signature data is modified or regenerated.

## Current
- Order history evidence display fix.

## Next
- Continue social inbox connection/deployment testing.
