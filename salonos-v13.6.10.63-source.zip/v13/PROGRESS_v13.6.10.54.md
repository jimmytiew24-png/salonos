# SalonOS v13.6.10.54

## Completed
- Replaced raw Instagram/Facebook DM connection form with WhatsApp-style guided setup UX.
- Separate Instagram Direct and Facebook Messenger status cards.
- Five-step connection wizard: prepare account, Meta setup, credentials, webhook, test.
- Tutorial modal for Instagram and Facebook.
- One-time Verify Token presentation with copy controls.
- Recent connection status and recent message preview.
- Manual social lead capture fallback for accounts not yet connected to Meta.
- Bilingual dictionary extended for the new UI.

## Installation
1. Upload the full `/v13` package.
2. Run `RUN_ONCE_V13_6_10_54_SOCIAL_INBOX_TUTORIAL_UI.sql` once in Supabase SQL Editor.
3. Existing `meta-social-webhook` from v13.6.10.52 remains the webhook function; deploy it if not deployed yet with Verify JWT disabled.
4. Existing WhatsApp Edge Functions are unchanged.

## Next
- Finish live Meta asset onboarding/testing for one Instagram account.
- Add contact-to-customer merge and Social Inbox AI reply workflow after webhook receive is proven live.
