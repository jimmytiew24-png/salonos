# SalonOS v13.6.10.55 Progress

## Completed
- Inventory cards now keep product photos in a dedicated media area; text/metrics/actions are never layered underneath the photo.
- Mobile inventory cards use a bounded responsive photo area and readable stacked metrics/actions.
- Owner top-right avatar/profile is now clickable on desktop and mobile, matching the staff profile behavior.
- Owner profile modal supports avatar upload/change and logout.
- Owner avatar is stored in Supabase Storage and its path is persisted on `profiles.avatar_path`.

## Database
Run `RUN_ONCE_V13_6_10_55_OWNER_AVATAR.sql` once before testing owner avatar upload.

## Unchanged
- Social Inbox / Meta webhook code from v13.6.10.54 remains unchanged.
- WhatsApp Edge Functions remain unchanged.
