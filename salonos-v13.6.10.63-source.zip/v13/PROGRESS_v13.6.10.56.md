# SalonOS v13.6.10.56 Progress

## Completed
- WhatsApp AI replies now follow the customer's active language instead of forcing every reply to English.
- Rapid multi-message bursts are collapsed: stale earlier inbound messages are skipped when a newer customer message already exists, reducing duplicate/repetitive replies.
- Short booking follow-ups such as “今天”, “现在”, “下午三点”, “7点” are deterministically repaired before booking routing.
- “现在 / now / sekarang” is treated as a concrete today/current-time request instead of asking for the date again.
- Price enquiries such as “染发多少钱” now resolve the real branch service and answer from SalonOS service price/duration data; the AI no longer falls back to “I only handle bookings” for this common case.
- Single-candidate stylist resolution no longer asks the customer to choose between one option.
- Staff enquiries with a recognized branch employee respond conversationally and invite the customer to continue the booking.
- Two-customer wording is acknowledged and clarified instead of being ignored while repeating the same date question.
- Missing booking questions are more conversational and acknowledge already captured context.

## Deployment
- No SQL required.
- Redeploy only `supabase/functions/whatsapp-ai-worker/index.ts`.
- Keep Verify JWT / function settings the same as the currently working worker deployment.
- WhatsApp webhook, manual-connect, embedded-signup and Meta social webhook are unchanged.

## Expected examples
- “染发多少钱” -> answer actual configured service price, not a generic refusal.
- “我要染头发” -> ask a useful next question once.
- “今天” -> continue with today's booking context instead of asking for a date again.
- “现在可以吗” -> check the current local time/date context.
- “crystal在吗” -> recognize Crystal conversationally when she is the sole branch match.
