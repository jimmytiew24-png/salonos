# SalonOS v13.6.10.57 Progress

## Completed
- Added deterministic date/time slot classification for Chinese, English and Bahasa Melayu short replies.
- Time-only messages such as `晚上7点`, `7pm`, `下午3点` and `pukul 7 malam` populate only `time_text`, `time_iso` and the daypart; they do not invent a date.
- A short temporal answer after `price_enquiry`, `service_enquiry` or `staff_enquiry` promotes the fresh factual context into the appointment flow.
- Existing `service_text`, service search aliases, named stylist and explicit staff preference are retained instead of reset.
- Customer-explicit date provenance can be retained from a price/service turn and safely carried into the immediate booking continuation.
- If the date is missing, the reply acknowledges the time and asks only for today/tomorrow/another date.
- If service + trusted date + exact time are already present and no stylist was named, the existing qualified system-assignment path performs the availability check.
- Numeric time tokens such as `7pm` inherit the preceding conversation language; common Malaysian Malay vocabulary detection was expanded.
- Store-defined service and staff names remain unchanged in multilingual replies.

## Regression coverage
- Chinese time-only: `晚上7点` -> `19:00`, date remains null.
- English numeric time: `7pm` -> `19:00` and inherits the prior customer language when appropriate.
- Chinese afternoon time: `下午3点` -> `15:00`.
- Malay time: `pukul 7 malam` -> `19:00`.
- Date-only: `明天` fills the date and does not create a new time.
- Price -> time preserves service and produces the natural missing-date question.
- Price-with-date -> time has no missing appointment slot and enters availability/system assignment.
- Appointment date change preserves the known service, stylist and exact time.
- Context carry is blocked without an authorized immediate informational/appointment continuation.

## Deployment
- No SQL migration required.
- Redeploy only `supabase/functions/whatsapp-ai-worker/index.ts`.
- Keep the currently working Verify JWT and secret settings for this function.
- `whatsapp-webhook`, `whatsapp-manual-connect`, `whatsapp-embedded-signup`, `whatsapp-reminder-worker` and `meta-social-webhook` are unchanged.

