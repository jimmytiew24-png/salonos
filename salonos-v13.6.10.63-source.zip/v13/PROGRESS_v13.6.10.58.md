# SalonOS v13.6.10.58 Progress

## Completed
- Added an explicit stylist-choice gate after service/date/time slot completion.
- System assignment now requires a grounded customer instruction; date/time-only replies cannot silently become `no_preference`.
- Added Chinese, English and Bahasa Melayu recognition for choosing a stylist versus system assignment.
- Added contextual choice prompts that repeat the known service/date/time before asking the customer to choose.
- Added a direct name question after generic replies such as `我要指定理发师`.
- An active unconfirmed draft is cancelled before changing to named-stylist mode.
- Old employee, staff resolver, availability and draft slots are cleared while service/date/time remain intact.
- Model-copied employee names are rejected when the latest customer message does not contain that name.

## Regression coverage
- Price -> `晚上7点` preserves service, fills time only, and asks for the date.
- Known date + time still requires `staff_preference` rather than jumping to availability.
- The Chinese choice prompt contains service + date + time and both `指定理发师` / `系统安排` options.
- `我要指定理发师`, English and Malay equivalents enter named-stylist mode.
- `系统安排`, `system assign` and `sistem aturkan` explicitly authorize system assignment.
- Old Fatchew draft state is cleared without resetting service/date/time.
- Chinese, English and Malay name/choice replies remain in the conversation language.

## Deployment
- No SQL migration required.
- Redeploy only `supabase/functions/whatsapp-ai-worker/index.ts`.
- Keep the currently working Verify JWT and secret settings for this function.
- `whatsapp-webhook`, `whatsapp-manual-connect`, `whatsapp-embedded-signup`, `whatsapp-reminder-worker` and `meta-social-webhook` are unchanged.
