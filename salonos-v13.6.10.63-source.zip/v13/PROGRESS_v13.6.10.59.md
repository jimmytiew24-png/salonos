# SalonOS v13.6.10.59 Progress

## Completed
- Preserved the current SalonOS UI/UX and visual design without changing layout, colors, spacing, typography or component styling.
- Reworked the PWA static-asset path from network-first `no-store` to cache-first inside a release-specific Service Worker cache.
- Enabled Service Worker Navigation Preload for dynamic page navigation to remove avoidable Service Worker startup delay while keeping HTML responses network-fresh.
- Changed English dictionary loading to `force-cache`; its URL is already release-versioned, so new releases still invalidate correctly.
- Added paint containment to the existing page-loading overlay without changing its appearance.
- Added in-page category filtering for Services, Inventory, Sales Products and Product Bundles.
- Category clicks now hide non-matching cards and reveal matching cards immediately instead of requesting a new PHP page.
- “All” restores all items.
- Direct category URLs and browser Back/Forward remain supported.
- Added lazy image loading/decoding on inventory/product/bundle catalog photos.

## Deployment
- Full `/v13` upload only.
- No SQL migration.
- No Edge Function redeploy.
- Existing WhatsApp AI worker from v13.6.10.58 is unchanged.
