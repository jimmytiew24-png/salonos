

## v13.6.10.60
- Reverted v13.6.10.59 aggressive Service Worker/cache-first performance changes that could mix stale CSS/JS with new HTML and break UI rendering.
- Restored stable v13.6.10.58 static asset loading/i18n behavior.
- Kept in-page category filtering for Services, Inventory, Sales Products and Product Bundles without page reload.
- No UI visual redesign.
## v13.6.10.59 — Navigation Performance + Instant Category Filters

- Kept the current SalonOS visual UI unchanged.
- Static PWA assets are served cache-first from a release-specific cache instead of being re-downloaded with `no-store` on every page transition.
- Navigation Preload reduces Service Worker startup delay for dynamic page requests without caching business HTML.
- Services / Inventory / Sales Products / Product Bundles category switching now filters cards in place with no page reload.
- No SQL and no Edge Function redeploy required.


# SalonOS v13.6.10.58

## WhatsApp AI explicit stylist choice

- A complete service/date/time request must still ask whether the customer wants to choose a stylist or use system assignment.
- `我要指定理发师` abandons any old unconfirmed assigned-stylist draft and asks for the stylist name without losing service/date/time.
- System assignment runs only after an explicit customer choice such as `系统安排`, `system assign` or `sistem aturkan`.
- Chinese, English and Bahasa Melayu behavior is preserved.
- No SQL is required; redeploy only `supabase/functions/whatsapp-ai-worker/index.ts`.

## v13.6.10.57

## WhatsApp AI context-aware slot filling

- Short time-only replies preserve the service/stylist already discussed and fill only the time slot.
- If the date is missing, the reply acknowledges the time and asks only for today/tomorrow/another date.
- If a trusted date is already known, date + time continue to the qualified availability path.
- Chinese, English and Bahasa Melayu conversation continuity is preserved.
- No SQL is required; redeploy only `supabase/functions/whatsapp-ai-worker/index.ts`.

## v13.6.10.55
Social Inbox tutorial UI + manual source capture.
# SalonOS v13.6.10.37

## v13.6.10.37 current upgrade — WhatsApp Setup UX / Beginner Wizard

- Rebuilds Settings -> WhatsApp Business for non-technical salon owners.
- Adds a clear connection-status dashboard and connection method chooser.
- Converts Manual Cloud API Setup into a 5-step guided wizard.
- Adds tutorial modals for App ID, App Secret, WABA / Phone Number ID, System User Token and Webhook setup.
- Keeps daily AI / reminder controls simple; raw Meta IDs, token rotation, templates and diagnostics are collapsed under Advanced sections.
- Preserves all v13.6.10.36 Manual Multi-App backend/security behavior.
- No SQL migration and no Edge Function redeploy required.

# SalonOS v13.6.10.36

## v13.6.10.36 current upgrade — Customer-Owned Meta App Manual Cloud API Connect

- Adds a real customer Manual Cloud API onboarding wizard without requiring SalonOS Tech Provider approval.
- Validates the customer's App ID/App Secret/Access Token, WABA and Phone Number ID against Meta before saving.
- Adds service-role-only per-connection Meta App Secret storage and one-time hashed Webhook Verify Tokens.
- Upgrades `whatsapp-webhook` to support multiple customer Meta Apps with strict per-connection HMAC verification while preserving the existing global SalonOS App path.
- Adds authenticated `whatsapp-manual-connect` Edge Function.
- Requires v13.6.10.36 SQL + deploy `whatsapp-manual-connect` + re-deploy `whatsapp-webhook`.
- Does not change `whatsapp-ai-worker`.

# SalonOS v13.6.10.35

## v13.6.10.35 current upgrade — Customer WhatsApp Embedded Signup Foundation

- Adds the recommended SaaS onboarding path: each salon owner connects their own WhatsApp Business / WABA from SalonOS Settings.
- Supports standard Cloud API Embedded Signup and existing WhatsApp Business App onboarding / Coexistence.
- Adds authenticated `whatsapp-embedded-signup` Supabase Edge Function for Meta code exchange, WABA/phone validation, webhook subscription, and branch-scoped business-token storage.
- Adds non-secret onboarding status/audit metadata and cross-tenant Phone Number ID conflict protection.
- Keeps the current manual Phone Number ID / Access Token form as an Advanced fallback.
- Requires the v13.6.10.35 SQL migration, new Edge Function deployment, and platform-level Meta Embedded Signup configuration/secrets.
- Does not modify the stable v13.6.10.34 `whatsapp-ai-worker` or existing webhook logic.

# SalonOS v13.6.10.34

## v13.6.10.34 current upgrade — Meta Delivery Failure Isolation

- Separates outbound WhatsApp delivery failure from AI/business-processing failure.
- Fixes the remaining inline send path that re-threw `meta_send_error:*` and produced HTTP 500 after delivery auditing had already been written.
- Preserves queue/conversation/business state when Meta rejects an outbound message.
- Records detailed Meta error metadata (HTTP status and available code/subcode/type/trace) for faster diagnosis.
- Does not change v13.6.10.33 relative-date booking behavior.
- No new SQL. Redeploy `whatsapp-ai-worker`. A valid Meta access token is still required for the customer to receive replies.

# SalonOS v13.6.10.33

## v13.6.10.33 current upgrade — Relative Date Follow-up Guard

- Fixes `明天呢` incorrectly reusing the previous date after a same-booking availability failure.
- Adds backend-authoritative relative-date resolution for Chinese / English / Malay today, tomorrow, and day-after-tomorrow expressions.
- The latest explicit date wins over prior conversation state.
- `customer_explicit` date provenance now requires a date that was actually resolved in the latest turn.
- If an explicit date cannot be resolved, SalonOS clears the old date and asks again instead of silently using it.
- Date-only follow-ups preserve the previous exact clock time when the customer did not state a new time/daypart.
- No new SQL. Redeploy only `whatsapp-ai-worker`. Meta token unchanged.

# SalonOS v13.6.10.32

## v13.6.10.32 current upgrade — Fresh Booking Date Provenance Guard

- Fixes a new booking such as `我要预约下午三点weihong染头发` incorrectly inheriting/assuming `20/08/2026` when the customer never stated a date.
- Explicit new-booking sentences now start a clean transaction and abandon any older unconfirmed draft before routing.
- The LLM is no longer allowed to infer `today` merely from a time such as `3 PM`.
- A date can only come from the customer's current message, an authoritative pending draft, or a date explicitly established earlier in the same v13.6.10.32 booking transaction.
- Legacy appointment state without date provenance is treated conservatively and asks for the date again instead of reusing an unproven date.
- Keeps the v13.6.10.31 staff/service separation fix (`weihong染头发` => staff `weihong` + service `染头发`).
- No new SQL. Redeploy `whatsapp-ai-worker`. Meta token unchanged.

# SalonOS v13.6.10.31

## v13.6.10.31 current upgrade — WhatsApp Staff / Service Entity Separation

- Separates branch employee names from adjacent multilingual service text before backend resolution.
- `weihong染头发` is repaired to staff=`weihong`, service=`染头发`, instead of becoming a fake service query.
- Adds deterministic aliases for common conversational service phrases.
- Fresh appointments after cancel/reschedule start with clean slots; stale dates/staff/services are not inherited.
- Service clarification now distinguishes true ambiguity from a real not-found result.
- No new SQL. Redeploy `whatsapp-ai-worker`. Meta token unchanged.

# SalonOS v13.6.10.30

## v13.6.10.30 current upgrade — Manual Booking Staff Integrity

This release hardens SalonOS's own New Order / worker-assignment path so it does not use a weaker staff truth than the stable WhatsApp booking flow.

Key changes:
- New Order availability is now filtered by the exact selected service(s), required skills, requested-date schedule/breaks, and active Visit conflicts.
- Lead/co-stylist lists are service-specific; assistant choices must be free for the booking window.
- Final server-side preflight runs again immediately before writes.
- System Assignment selects from the qualified + scheduled + free pool and avoids duplicate-role random choices.
- Existing service-item worker reassignment validates the replacement team before deleting old worker rows.
- Future appointments do not depend on the employee's current live on-duty flag; walk-ins still do.
- Cancelled/no-show/completed Visits release occupancy while worker history is retained.
- Owner datetime-local appointment persistence is explicitly Asia/Kuala_Lumpur.
- Run `RUN_ONCE_V13_6_10_30_MANUAL_BOOKING_STAFF_INTEGRITY.sql` once. No WhatsApp Edge Function redeploy is required.

# SalonOS v13.6.10.27

## v13.6.10.27 current upgrade — Booking Draft Revision Precedence Fix

This hotfix fixes the exact router collision that kept reproducing the existing-appointment self-service reply even after v13.6.10.26 had recovered the unconfirmed booking draft.

Confirmed root cause:
- `pendingDraftRevisionIntent(...)` correctly returns `intent = appointment` for messages such as `我要换去下午3点` while an unconfirmed draft exists.
- A later legacy continuity block then saw previous state `reschedule_not_found` and changed that `appointment` intent straight back to `reschedule`.
- The worker therefore called the confirmed-appointment lookup again and emitted the same not-found reply.

Fix:
- Deterministic booking-draft revision now has higher precedence than stale `reschedule_*` continuity.
- When that router is active, the intent is explicitly locked to `appointment`.
- Adds `deterministic_draft_revision_router` to run diagnostics.
- No new SQL. Redeploy `whatsapp-ai-worker`.

# SalonOS v13.6.10.26

## v13.6.10.26 current upgrade — Draft History Recovery + State Preservation

This hotfix closes the remaining path that could still send the existing-appointment self-service message while the customer was actually editing an unconfirmed booking draft.

Key changes:
- Draft lookup now starts with `select("*")` so optional-column schema drift cannot null the result.
- If older releases already erased `conversation_state.slots.booking_draft`, the worker can recover the recent draft id/snapshot from `whatsapp_ai_runs`.
- A recoverable pending draft is preserved in conversation state even if a turn is accidentally routed through cancel/reschedule.
- No new SQL is required. Redeploy `whatsapp-ai-worker`.

# SalonOS v13.6.10.25

## v13.6.10.25 current upgrade — Draft Lookup Failsafe + Misroute Guard

- Prevents an unconfirmed WhatsApp booking draft from falling back into the existing-confirmed-appointment reschedule path when the full draft select fails.
- Adds a v13.6.7-compatible base-column retry plus conversation-state `booking_draft` recovery.
- Keeps terminal database transactions authoritative and preserves random/specified stylist assignment semantics.
- Adds draft lookup diagnostics to `whatsapp_ai_runs`.
- Supports Chinese written-number hours such as `下午三点`.
- No new SQL for this patch; redeploy `supabase/functions/whatsapp-ai-worker/index.ts`.


## v13.6.10.8 current upgrade — Marketing Analytics Employee Scope Fix

- Fixes the Marketing 来源分析 page failing with a misleading v13.5.5 schema warning.
- v13.6.10.7 queried `employees.store_id`, but employees are organization-scoped in the current SalonOS data model.
- Marketing rows remain filtered by the active organization + store; employee names are mapped from organization employees.
- No new SQL migration is required.
- No Edge Function redeploy is required.
- Full package includes all previous Media Account modal, Tracking/WhatsApp, AI appointment and attribution functionality.

## v13.6.10 current upgrade — English Skills + Skill-Aware System Assignment

- Adds an English canonical skill catalog with 54 initial skill codes and multilingual aliases for compatibility.
- Adds employee skill proficiency levels (1 Beginner → 5 Expert) and per-service required skills/minimum levels.
- Existing `employees.skill_tags` and service name/category data are preserved and mapped into the new skill layer instead of being deleted.
- When a WhatsApp customer says **no preference / anyone / you choose / random**, SalonOS now filters the current branch by required service skills and real schedule availability before system-assigning a stylist.
- Without an exact time, the AI shows pooled times first and does **not** lock a stylist early. After the customer selects a time, qualification + availability are checked again and one eligible stylist is assigned.
- System-assigned appointments remain `random` for customer-preference analytics while the real assigned worker is still stored on the service item.
- Customer-specified stylists remain `specified`; prior/dominant stylist history is never silently converted into customer preference.
- WhatsApp outbound conversation is English-first. Multilingual inbound booking phrases remain understood, while common legacy Chinese service labels are rendered with an English label in replies.
- Run `RUN_ONCE_V13_6_10_ENGLISH_SKILLS_SYSTEM_ASSIGNMENT.sql` **before** deploying the included `whatsapp-ai-worker/index.ts`.

## v13.6.9.7 previous upgrade

- WhatsApp AI no longer silently suppresses greetings / `other` intent. Safe greeting and fallback replies are now sent without inventing salon facts.
- Completed booking / cancel / reschedule transactions reset the durable conversation state to `idle` and clear transaction-only slots, preventing old confirmations or appointment references from leaking into the next message.
- Meta send failures are audited as failed delivery but no longer prevent the already-committed booking/change state from being finalized, avoiding the mismatch where a visit changed in Supabase while the conversation stayed stuck on `确认取消`.
- No new SQL migration is required; deploy the included `supabase/functions/whatsapp-ai-worker/index.ts`.

## v13.6.9.6 previous upgrade

- Service Floor / Team Appointment Board now self-checks every 5 seconds and automatically refreshes when appointment time/status changes in Supabase (including WhatsApp AI reschedule).
- The board page and service-detail modal both use no-store requests so the timeline/list cannot remain at an old time while the modal already shows the new time.
- Existing v13.6.9.5 cancel/reschedule reference-scope protections remain intact.

## v13.6.9.5 previous upgrade

Database layer remains v13.6.9. This build fixes a second stale-state path in reschedule lookup: a historical `appointment_reference` could survive in conversation slots and silently filter the FUTURE + BOOKED search to an old cancelled booking number. New cancel/reschedule commands now only use a booking reference when the current customer message explicitly contains one; references are only inherited while already inside the same change flow. Booking state also clears the top-level `appointment_reference`. No new SQL migration is required.


UI/UX baseline: **v12.4.4**. Business backend: **Supabase Only**. InfinityFree hosts PHP/PWA/static files only.

## v13.6.9.4 current upgrade

Database layer remains v13.6.9. Run `RUN_ONCE_V13_6_9_CANCEL_RESCHEDULE_EXISTING_CUSTOMER.sql` if it has not already been installed, then deploy the included `supabase/functions/whatsapp-ai-worker/index.ts`. This full build includes the v13.6.9.3 deterministic change-command router: explicit cancel/reschedule commands such as “帮我改到明天下午5点” bypass Groq intent JSON generation and go directly into the guarded backend change flow. Existing v13.6.8 reminder worker and 5-minute Cron remain in place.

### v13.6.9.4 reschedule stale-target fix

- Clears old cancel/reschedule target UUIDs whenever the conversation returns to the appointment booking flow.
- Re-validates any carried reschedule target against the tenant-scoped FUTURE + BOOKED appointment lookup before availability checks.
- Automatically falls back to the customer's current eligible appointment if the saved target was cancelled/completed/stale.
- Prevents the exact failure where WhatsApp replied “理发师在这个时段暂时没有可改期的空位” with a blank stylist/date even though the current yellow booking was still valid.


## Upgrade from v13.5.3

Run `RUN_ONCE_V13_5_4_EMPLOYEE_WORKSPACE.sql`, then upload/overwrite the v13.5.4 patch/full build.
If earlier v13.5.x database patch status is uncertain, run `RUN_ONCE_V13_5_4_CUMULATIVE_RUNTIME.sql` instead.
After deployment, open `/v13/system-test.php`.

## v13.5.4 changes

- Default and custom employee permission roles can be deleted; at least one role must remain and assigned employees are safely moved to another remaining role.
- Employee mobile/PWA workspace has no bottom shortcut bar. Navigation uses the hamburger side menu.
- Employee side-menu entries and direct page access follow the role permission matrix.
- Employee `顾客与会员` route is implemented for roles with customer permission and is scoped by employee session + current store.
- Employee performance is a leaderboard with Top 3 podium, complete ranking and clickable employee detail.
- Performance detail supports Day / Month / Year and includes service contribution, product sales, total performance, commission, customers, appointments, Walk-ins and activity detail.
- Employees can upload a compressed avatar to Supabase Storage. PostgreSQL stores only `avatar_path`.
- Clicking the employee avatar opens a profile modal with avatar upload and a clear `退出登录` action.
- v13.5.3 member/product/category/order improvements remain retained.

## Requirement source

Read `docs/SalonOS_COMPLETE_PRODUCT_SPEC_v13.5.4.md` before future changes. Confirmed requirements must not be silently removed by later database/UI work.


## v13.5.7
- 修复员工端预约使用 datetime-local 无时区值直接写入 Supabase 时被当成 UTC，导致马来西亚预约偏移 +8 小时、跨日或掉出 09:00–00:00 服务现场时间轴的问题。
- 员工预约现在在送往 Supabase 前转换为 Asia/Kuala_Lumpur 的明确 ISO 时区时间。
- 顾客签名完成或点击稍后处理后，会自动回到预约日期对应的服务现场，不再固定回今天。


## v13.5.8
- 预约建立阶段不再进入顾客签名；预约建立后直接回到对应日期的服务现场。
- 顾客到店后，负责员工／经理／柜台可确认「顾客已到达」，系统记录 arrived_at 后才开放整单顾客确认与签名。
- 服务现场 booked 状态不再显示任何签名入口；arrived 状态先要求整单签名，签名后进入 waiting 才能开始服务。
- Dashboard 加入 3 秒自动同步，不再需要手动 Refresh。
- 现有 Supabase 项目需运行 RUN_ONCE_V13_5_8_APPOINTMENT_ARRIVAL_SIGNATURE.sql。


## v13.5.9
顾客订单的追加产品功能已支持动态浮窗内的分类优先搜索：选择分类即列出产品，输入关键词继续在该分类内筛选。无需 SQL 升级。


## v13.5.10
顾客订单的分类产品搜索兼容旧 category 文字资料，并在即时搜索结果显示产品缩略图。无需新增数据库字段或执行 SQL。

## v13.5.11
经营分析加入顾客结构分析：首次到店新客、回访随机／未固定型、指定理发师忠诚客。新客可分析来源、年龄与种族，回访客可分析指定率与常指定员工。员工建立订单的偏好与首次来源写入需要运行 `RUN_ONCE_V13_5_11_CUSTOMER_SEGMENT_ANALYTICS.sql`。


## v13.6.0 Media Attribution
- Settings 增加媒体来源、门店/员工社交账号、Content 与 Tracking Link 管理。
- 默认渠道：Instagram / Facebook / TikTok / Google / XHS / Website / QR / Referral / Walk-in / Other。
- /t/<slug> 自动生成唯一 Ref、记录 click 并跳转 WhatsApp/URL。
- 建立 marketing_leads 数据底座，供后续 WhatsApp Webhook + AI Agent 连接 Lead → Appointment → Arrived → Revenue。

### v13.6.1 WhatsApp Cloud API inbound
Run `RUN_ONCE_V13_6_1_WHATSAPP_WEBHOOK.sql`, then deploy the included Supabase Edge Function at `supabase/functions/whatsapp-webhook/index.ts`. The Meta-facing function is configured with JWT verification off because Meta does not send a Supabase JWT; it verifies the provider inside the handler using `X-Hub-Signature-256` and `META_APP_SECRET` before any privileged database write. See `V13_6_1_WHATSAPP_WEBHOOK_GUIDE.txt`.


### v13.6.2 AI Customer Context / Search Customer
Run `RUN_ONCE_V13_6_2_AI_CUSTOMER_CONTEXT.sql` after the v13.6.1 WhatsApp inbound flow is working. This stage adds the deterministic backend action `v1362_ai_prepare_customer_context(queue_id)`: it derives tenant/branch/phone from the verified WhatsApp queue, searches the current branch customer by normalized phone, returns visit/membership/stylist/service context for existing customers, and keeps unknown contacts as Marketing Leads instead of immediately creating permanent Customer rows. Ethnicity provenance is explicit and AI inference is not allowed. Appointment/No-show does not increase completed visit count; only completed, checked-out and paid visits count. See `V13_6_2_AI_CUSTOMER_CONTEXT_GUIDE.txt`.


### v13.6.3 Automatic WhatsApp AI Worker / Intent Router
Run `RUN_ONCE_V13_6_3_AI_WORKER_INTENT.sql`, add the server-side Secrets `OPENAI_API_KEY` and `SALONOS_AI_WORKER_TOKEN`, deploy `supabase/functions/whatsapp-ai-worker/index.ts`, and redeploy the v13.6.3 `whatsapp-webhook`. New inbound WhatsApp messages are queued, Search Customer runs deterministically first, then the worker classifies the message into a strict intent schema and persists durable conversation state/audit rows. This phase intentionally does not send customer-facing replies or mutate appointments. See `V13_6_3_AI_WORKER_INTENT_GUIDE.txt`.


### v13.6.6 AI WhatsApp Reply + Multi-turn State
- Automatic fact-safe WhatsApp replies through Meta Cloud API after backend availability checks.
- Branch-scoped send token/config instead of one organization-wide secret.
- Durable reply audit and outbound message records.
- Multi-turn appointment context carries service, stylist, date and offered slots into short follow-up messages.
- Still no direct AI appointment creation: Draft + Confirm remains the next guarded step.

### v13.6.5 Appointment Tool Layer

Adds server-side `resolve_service`, `resolve_staff`, and `check_availability` tools for WhatsApp appointment intent. Tenant/store scope is derived from the trusted queue ID, never from LLM-supplied IDs. Future staff working hours are stored in `whatsapp_ai_employee_schedules`; if a day has no configured schedule, availability returns `schedule_unconfigured` instead of inventing slots. Tool executions are audited in `whatsapp_ai_tool_runs`. This release still does **not** send an automatic WhatsApp reply and does **not** create appointments.

### v13.6.4 AI Provider Layer / Groq
No new SQL is required if v13.6.3 SQL already ran successfully. Add Supabase Secrets `GROQ_API_KEY`, `AI_PROVIDER=groq`, and optionally `GROQ_MODEL=openai/gpt-oss-20b`, then redeploy `supabase/functions/whatsapp-ai-worker/index.ts`. The worker uses Groq Structured Outputs for Intent Detection while retaining the existing deterministic Search Customer step and all tenant checks. OpenAI remains an optional provider. See `V13_6_4_GROQ_PROVIDER_GUIDE.txt`.


### v13.6.7 Customer Profile → Appointment Draft → Confirm
- Adds a durable, branch-scoped `whatsapp_ai_appointment_drafts` layer. A draft does **not** reserve or create a real appointment.
- After a verified time is selected, WhatsApp AI collects only missing customer fields: required name, optional age/age range (customer may skip), and optional ethnicity (customer may choose 华人 / 马来人 / 印度人 / 其他 / 不愿透露).
- Age and ethnicity provenance is explicit. The AI is forbidden from inferring race/ethnicity from name, language, phone, photo or other indirect signals.
- Existing customer profiles are reused and only missing profile fields are requested. Unknown WhatsApp contacts remain Leads until final booking confirmation.
- The customer receives a booking draft summary before any appointment is created.
- Only `v1367_ai_confirm_draft(queue_id)` may create the real SalonOS appointment, and only after a final tenant/staff/service/schedule/slot re-check.
- If the selected slot is taken before confirmation, the draft moves to `needs_reschedule` and alternatives are returned; no appointment is silently created.
- Confirmed appointments are created as `visits.visit_type=appointment` + `status=booked`. They do **not** count as a completed visit until the normal Arrived → Service Completed → Checkout → Paid flow finishes.
- Adds `whatsapp_ai_booking_events` for draft/profile/confirm audit history.
