-- SalonOS v13.5.0 · Product / UX Contract
-- Additive + idempotent. Does NOT delete historical business records.
-- Run after v13.4.7, or use RUN_ONCE_V13_5_0_CUMULATIVE_RUNTIME.sql instead.

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- 1) Media stays in Supabase Storage, not inside PostgreSQL rows.
--    PHP compresses photos to WebP when GD is available; bucket enforces <= 2 MB.
-- -----------------------------------------------------------------------------
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('salonos-media','salonos-media',true,2097152,array['image/jpeg','image/png','image/webp']::text[])
on conflict (id) do update set
  public=excluded.public,
  file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists salonos_media_member_read on storage.objects;
create policy salonos_media_member_read on storage.objects
for select to authenticated
using (
  bucket_id='salonos-media'
  and exists (
    select 1 from public.organization_members om
    where om.user_id=auth.uid() and om.status='active'
      and om.organization_id::text=split_part(storage.objects.name,'/',1)
  )
);

drop policy if exists salonos_media_manager_insert on storage.objects;
create policy salonos_media_manager_insert on storage.objects
for insert to authenticated
with check (
  bucket_id='salonos-media'
  and exists (
    select 1 from public.organization_members om
    where om.user_id=auth.uid() and om.status='active'
      and om.role in ('owner','manager')
      and om.organization_id::text=split_part(storage.objects.name,'/',1)
  )
);

drop policy if exists salonos_media_manager_update on storage.objects;
create policy salonos_media_manager_update on storage.objects
for update to authenticated
using (
  bucket_id='salonos-media'
  and exists (
    select 1 from public.organization_members om
    where om.user_id=auth.uid() and om.status='active'
      and om.role in ('owner','manager')
      and om.organization_id::text=split_part(storage.objects.name,'/',1)
  )
)
with check (
  bucket_id='salonos-media'
  and exists (
    select 1 from public.organization_members om
    where om.user_id=auth.uid() and om.status='active'
      and om.role in ('owner','manager')
      and om.organization_id::text=split_part(storage.objects.name,'/',1)
  )
);

-- -----------------------------------------------------------------------------
-- 2) Service categories are real folder-like records.
-- -----------------------------------------------------------------------------
create table if not exists public.service_categories (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  name text not null,
  description text,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(organization_id,store_id,name)
);
create index if not exists service_categories_store_idx on public.service_categories(organization_id,store_id,active,sort_order,name);

alter table public.service_categories enable row level security;
drop policy if exists v1350_service_categories_read on public.service_categories;
create policy v1350_service_categories_read on public.service_categories for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1350_service_categories_manage on public.service_categories;
create policy v1350_service_categories_manage on public.service_categories for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

alter table public.services add column if not exists category_id uuid;
do $$
begin
  if not exists(select 1 from pg_constraint where conname='services_category_id_fkey') then
    alter table public.services add constraint services_category_id_fkey
      foreign key(category_id) references public.service_categories(id) on delete set null;
  end if;
end $$;

-- Backfill a category record for every current service category. Blank categories become 未分类.
insert into public.service_categories(organization_id,store_id,name,description,sort_order,active)
select distinct s.organization_id,s.store_id,coalesce(nullif(trim(s.category),''),'未分类'),null,0,true
from public.services s
where s.organization_id is not null and s.store_id is not null
on conflict(organization_id,store_id,name) do nothing;

update public.services s
set category_id=c.id,
    category=c.name,
    updated_at=now()
from public.service_categories c
where c.organization_id=s.organization_id and c.store_id=s.store_id
  and c.name=coalesce(nullif(trim(s.category),''),'未分类')
  and (s.category_id is distinct from c.id or s.category is distinct from c.name);

-- -----------------------------------------------------------------------------
-- 3) Inventory unit + Storage URL. The quantity truth remains the stock ledger.
-- -----------------------------------------------------------------------------
alter table public.products add column if not exists stock_unit text not null default 'pcs';

-- -----------------------------------------------------------------------------
-- 4) KPI: employee-first assignment supports per-employee target/bonus/status.
-- -----------------------------------------------------------------------------
do $$
declare r record;
begin
  for r in
    select conname from pg_constraint
    where conrelid='public.v13_kpi_rules'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%metric_type%'
  loop
    execute format('alter table public.v13_kpi_rules drop constraint %I',r.conname);
  end loop;
end $$;
alter table public.v13_kpi_rules add constraint v1350_kpi_metric_type_check
  check (metric_type in ('service_performance','product_sales','total_sales','service_count','customer_count','avg_ticket','requested_count','training_completion','manual'));

alter table public.v13_kpi_assignments
  add column if not exists target_value numeric,
  add column if not exists bonus_amount numeric,
  add column if not exists status text not null default 'active',
  add column if not exists updated_at timestamptz not null default now();

do $$
declare r record;
begin
  for r in
    select conname from pg_constraint
    where conrelid='public.v13_kpi_assignments'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%status%'
  loop
    execute format('alter table public.v13_kpi_assignments drop constraint %I',r.conname);
  end loop;
end $$;
alter table public.v13_kpi_assignments add constraint v1350_kpi_assignment_status_check
  check (status in ('active','achieved','reviewed','bonus_paid','archived'));

-- -----------------------------------------------------------------------------
-- 5) Training: category + role targeting + media metadata.
-- -----------------------------------------------------------------------------
alter table public.v13_training_courses
  add column if not exists category text not null default '通用培训',
  add column if not exists target_roles jsonb not null default '[]'::jsonb,
  add column if not exists content_url text,
  add column if not exists cover_image_path text,
  add column if not exists estimated_minutes integer not null default 0,
  add column if not exists version_label text,
  add column if not exists required boolean not null default false,
  add column if not exists publication_status text not null default 'published';

alter table public.v13_training_progress add column if not exists started_at timestamptz;

-- -----------------------------------------------------------------------------
-- 6) Commission tier editor compatibility + monthly manual override.
-- -----------------------------------------------------------------------------
alter table public.service_commission_tiers add column if not exists updated_at timestamptz not null default now();

create table if not exists public.v13_monthly_commission_overrides (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  employee_id uuid not null,
  month_start date not null,
  override_rate numeric,
  final_commission_amount numeric,
  notes text,
  locked boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(organization_id,store_id,employee_id,month_start),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  foreign key (organization_id,employee_id) references public.employees(organization_id,id) on delete cascade,
  check (override_rate is null or (override_rate>=0 and override_rate<=100)),
  check (final_commission_amount is null or final_commission_amount>=0)
);
create index if not exists v1350_monthly_commission_idx on public.v13_monthly_commission_overrides(organization_id,store_id,month_start,employee_id);
alter table public.v13_monthly_commission_overrides enable row level security;
drop policy if exists v1350_monthly_commission_read on public.v13_monthly_commission_overrides;
create policy v1350_monthly_commission_read on public.v13_monthly_commission_overrides for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1350_monthly_commission_manage on public.v13_monthly_commission_overrides;
create policy v1350_monthly_commission_manage on public.v13_monthly_commission_overrides for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

-- -----------------------------------------------------------------------------
-- 7) Employee catalog includes category_id so New Order can select category first.
-- -----------------------------------------------------------------------------
create or replace function public.v1350_employee_catalog(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_store uuid; v_result jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  return jsonb_build_object(
    'context',v_ctx,
    'categories',coalesce((select jsonb_agg(jsonb_build_object('id',c.id,'name',c.name,'sort_order',c.sort_order) order by c.sort_order,c.name)
      from public.service_categories c where c.organization_id=v_org and c.store_id=v_store and c.active),'[]'::jsonb),
    'services',coalesce((select jsonb_agg(jsonb_build_object(
        'id',s.id,'category_id',s.category_id,'category',coalesce(c.name,s.category,'未分类'),'name',s.name,
        'default_price',s.default_price,'estimated_minutes',s.estimated_minutes,'allows_assistant',s.allows_assistant
      ) order by coalesce(c.sort_order,9999),coalesce(c.name,s.category,'未分类'),s.name)
      from public.services s left join public.service_categories c on c.id=s.category_id and c.organization_id=s.organization_id
      where s.organization_id=v_org and s.store_id=v_store and s.active),'[]'::jsonb),
    'employees',coalesce((select jsonb_agg(jsonb_build_object(
        'id',e.id,'name',e.name,'position',e.position,'app_role',e.app_role,'availability_status',coalesce(e.availability_status,case when e.is_on_duty then 'available' else 'off_duty' end)
      ) order by e.name)
      from public.employees e join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
      where e.organization_id=v_org and es.store_id=v_store and es.status='active' and e.employment_status='active'),'[]'::jsonb)
  );
end;
$$;
revoke all on function public.v1350_employee_catalog(text) from public;
grant execute on function public.v1350_employee_catalog(text) to anon,authenticated;

-- -----------------------------------------------------------------------------
-- 8) Employee training is role-filtered. Employees cannot see irrelevant courses.
-- -----------------------------------------------------------------------------
create or replace function public.v1350_employee_training(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_e uuid; v_org uuid; v_role text; v_result jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  select coalesce(jsonb_agg(jsonb_build_object(
      'id',c.id,'title',c.title,'category',c.category,'description',c.description,'content',c.content,'content_url',c.content_url,
      'cover_image_path',c.cover_image_path,'estimated_minutes',c.estimated_minutes,'version_label',c.version_label,'required',c.required,
      'progress_percent',coalesce(p.progress_percent,0),'status',coalesce(p.status,'not_started'),'started_at',p.started_at,'completed_at',p.completed_at
    ) order by c.category,c.required desc,c.created_at desc),'[]'::jsonb)
  into v_result
  from public.v13_training_courses c
  left join public.v13_training_progress p on p.course_id=c.id and p.employee_id=v_e and p.organization_id=v_org
  where c.organization_id=v_org and c.active and c.publication_status='published'
    and (jsonb_array_length(coalesce(c.target_roles,'[]'::jsonb))=0 or coalesce(c.target_roles,'[]'::jsonb) ? v_role);
  return coalesce(v_result,'[]'::jsonb);
end;
$$;
revoke all on function public.v1350_employee_training(text) from public;
grant execute on function public.v1350_employee_training(text) to anon,authenticated;

create or replace function public.v1350_employee_training_progress(p_session_token text,p_course_id uuid,p_progress_percent integer)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_e uuid; v_org uuid; v_role text; v_pct integer:=greatest(0,least(100,coalesce(p_progress_percent,0)));
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  if not exists(
    select 1 from public.v13_training_courses c
    where c.id=p_course_id and c.organization_id=v_org and c.active and c.publication_status='published'
      and (jsonb_array_length(coalesce(c.target_roles,'[]'::jsonb))=0 or coalesce(c.target_roles,'[]'::jsonb) ? v_role)
  ) then raise exception '这个课程不适用于当前员工。'; end if;
  insert into public.v13_training_progress(organization_id,employee_id,course_id,progress_percent,status,started_at,completed_at,updated_at)
  values(v_org,v_e,p_course_id,v_pct,
    case when v_pct>=100 then 'completed' when v_pct>0 then 'in_progress' else 'not_started' end,
    case when v_pct>0 then now() else null end,
    case when v_pct>=100 then now() else null end,now())
  on conflict(employee_id,course_id) do update set
    progress_percent=excluded.progress_percent,
    status=excluded.status,
    started_at=coalesce(v13_training_progress.started_at,excluded.started_at),
    completed_at=case when excluded.progress_percent>=100 then coalesce(v13_training_progress.completed_at,now()) else null end,
    updated_at=now();
  return jsonb_build_object('ok',true,'course_id',p_course_id,'progress_percent',v_pct);
end;
$$;
revoke all on function public.v1350_employee_training_progress(text,uuid,integer) from public;
grant execute on function public.v1350_employee_training_progress(text,uuid,integer) to anon,authenticated;

-- -----------------------------------------------------------------------------
-- 9) Runtime contract: detect drift before normal pages expose raw database errors.
-- -----------------------------------------------------------------------------
create or replace function public.v1350_runtime_contract_status()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_missing text[]:=array[]::text[];
  v_ok boolean;
begin
  if to_regprocedure('public.v1347_runtime_contract_status()') is null then v_missing:=array_append(v_missing,'v1347_runtime_contract_status'); end if;
  if to_regprocedure('public.v1350_employee_catalog(text)') is null then v_missing:=array_append(v_missing,'v1350_employee_catalog'); end if;
  if to_regprocedure('public.v1350_employee_training(text)') is null then v_missing:=array_append(v_missing,'v1350_employee_training'); end if;
  if to_regprocedure('public.v1350_employee_training_progress(text,uuid,integer)') is null then v_missing:=array_append(v_missing,'v1350_employee_training_progress'); end if;
  if to_regclass('public.service_categories') is null then v_missing:=array_append(v_missing,'service_categories'); end if;
  if to_regclass('public.v13_monthly_commission_overrides') is null then v_missing:=array_append(v_missing,'v13_monthly_commission_overrides'); end if;
  if not exists(select 1 from information_schema.columns where table_schema='public' and table_name='services' and column_name='category_id') then v_missing:=array_append(v_missing,'services.category_id'); end if;
  if not exists(select 1 from information_schema.columns where table_schema='public' and table_name='products' and column_name='stock_unit') then v_missing:=array_append(v_missing,'products.stock_unit'); end if;
  if not exists(select 1 from information_schema.columns where table_schema='public' and table_name='v13_training_courses' and column_name='target_roles') then v_missing:=array_append(v_missing,'training.target_roles'); end if;
  if not exists(select 1 from storage.buckets where id='salonos-media') then v_missing:=array_append(v_missing,'storage.salonos-media'); end if;
  v_ok:=cardinality(v_missing)=0;
  return jsonb_build_object('version','13.5.0','ok',v_ok,'missing_contracts',to_jsonb(v_missing),'storage_bucket','salonos-media','schema_cache_marker','v13.5.0');
end;
$$;
revoke all on function public.v1350_runtime_contract_status() from public;
grant execute on function public.v1350_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('compat_patch_version','13.5.0'),
 ('runtime_contract_version','13.5.0'),
 ('product_ux_contract_version','13.5.0'),
 ('service_category_version','13.5.0'),
 ('training_role_version','13.5.0'),
 ('commission_editor_version','13.5.0')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.5.0 PRODUCT UX CONTRACT READY' as result,
  to_regprocedure('public.v1350_runtime_contract_status()') is not null as runtime_contract_ok,
  to_regclass('public.service_categories') is not null as service_categories_ok,
  to_regclass('public.v13_monthly_commission_overrides') is not null as monthly_commission_override_ok,
  exists(select 1 from storage.buckets where id='salonos-media') as media_storage_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='services' and column_name='category_id') as service_category_fk_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='products' and column_name='stock_unit') as inventory_unit_ok,
  (public.v1350_runtime_contract_status()->>'ok')::boolean as contract_complete;
