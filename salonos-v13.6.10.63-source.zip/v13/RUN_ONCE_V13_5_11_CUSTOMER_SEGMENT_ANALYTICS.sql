-- SalonOS v13.5.11 · Customer Segment Analytics
-- Run once in Supabase SQL Editor.
-- Additive only: no customer/order data is deleted.

begin;
set local statement_timeout = '0';

-- Legacy table name retained for compatibility. From v13.5.11 it stores
-- specified/random preference for BOTH appointment and walk-in visits.
create table if not exists public.appointment_employee_preferences (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  visit_id uuid not null references public.visits(id) on delete cascade,
  preference_type text not null default 'random' check (preference_type in ('random','specified')),
  employee_id uuid null references public.employees(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(visit_id)
);

create index if not exists appointment_employee_preferences_org_store_idx
  on public.appointment_employee_preferences(organization_id,store_id,created_at desc);

create or replace function public.v13511_employee_finalize_visit_intake(
  p_session_token text,
  p_visit_id uuid,
  p_preference_type text,
  p_employee_id uuid default null,
  p_acquisition_platform text default ''
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb;
  v_org uuid;
  v_store uuid;
  v_employee uuid;
  v_customer uuid;
  v_pref text;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_employee:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_pref:=case when lower(coalesce(p_preference_type,''))='specified' then 'specified' else 'random' end;

  if not exists(
    select 1 from public.visits v
    where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store
  ) then
    raise exception '订单不存在或不属于当前员工分行。';
  end if;

  if v_pref='specified' and p_employee_id is not null then
    if not exists(
      select 1 from public.employees e
      join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
      where e.id=p_employee_id and e.organization_id=v_org and e.employment_status='active'
        and es.store_id=v_store and es.status='active'
    ) then
      p_employee_id:=null;
    end if;
  else
    p_employee_id:=null;
  end if;

  insert into public.appointment_employee_preferences(
    organization_id,store_id,visit_id,preference_type,employee_id,updated_at
  ) values(
    v_org,v_store,p_visit_id,v_pref,p_employee_id,now()
  )
  on conflict(visit_id) do update set
    preference_type=excluded.preference_type,
    employee_id=excluded.employee_id,
    updated_at=now();

  if nullif(trim(coalesce(p_acquisition_platform,'')),'') is not null then
    select r.customer_id into v_customer
    from public.visit_recipients r
    where r.organization_id=v_org and r.visit_id=p_visit_id and r.recipient_type='primary'
    order by r.created_at asc
    limit 1;

    if v_customer is not null then
      update public.customers c
      set acquisition_platform=trim(p_acquisition_platform)
      where c.id=v_customer and c.organization_id=v_org and c.store_id=v_store
        and nullif(trim(coalesce(c.acquisition_platform,'')),'') is null;
    end if;
  end if;

  return jsonb_build_object('ok',true,'visit_id',p_visit_id,'preference_type',v_pref);
end;
$$;

revoke all on function public.v13511_employee_finalize_visit_intake(text,uuid,text,uuid,text) from public;
grant execute on function public.v13511_employee_finalize_visit_intake(text,uuid,text,uuid,text) to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values('customer_segment_analytics_version','13.5.11')
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

commit;

select 'SalonOS v13.5.11 CUSTOMER SEGMENT ANALYTICS READY' as result;
