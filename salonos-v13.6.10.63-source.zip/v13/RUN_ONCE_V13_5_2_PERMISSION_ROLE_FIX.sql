-- SalonOS v13.5.2 · employee custom-role permission bridge
-- Additive/idempotent. Does not delete business data.

begin;
set local statement_timeout='0';

create or replace function public.v1352_employee_role_permissions(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_h text:=encode(digest(coalesce(p_session_token,''),'sha256'),'hex');
  v_ls public.employee_login_sessions%rowtype;
  v_role text;
  v_permissions jsonb:='{}'::jsonb;
  v_org uuid;
begin
  select ls.* into v_ls
  from public.employee_login_sessions ls
  where ls.token_hash=v_h and ls.revoked_at is null and ls.expires_at>now()
  limit 1;
  if v_ls.id is null then raise exception '员工登录已过期，请重新输入手机号。'; end if;

  select e.organization_id,e.app_role into v_org,v_role
  from public.employees e
  join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id and es.store_id=v_ls.store_id and es.status='active'
  join public.stores s on s.id=v_ls.store_id and s.organization_id=e.organization_id and s.status='active'
  join public.organizations o on o.id=e.organization_id and o.status in ('active','trialing')
  where e.id=v_ls.employee_id and e.employment_status='active'
  limit 1;

  if v_org is null then
    update public.employee_login_sessions set revoked_at=coalesce(revoked_at,now()) where id=v_ls.id;
    raise exception '员工账号已停用或门店不可使用。';
  end if;

  select coalesce(s.role_permissions,'{}'::jsonb) into v_permissions
  from public.v13_organization_settings s
  where s.organization_id=v_org
  limit 1;

  update public.employee_login_sessions set last_seen_at=now() where id=v_ls.id;
  return jsonb_build_object(
    'organization_id',v_org,
    'employee_role',coalesce(v_role,'staff'),
    'role_permissions',coalesce(v_permissions,'{}'::jsonb)
  );
end;
$$;

revoke all on function public.v1352_employee_role_permissions(text) from public;
grant execute on function public.v1352_employee_role_permissions(text) to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values('permission_contract_version','13.5.2')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.5.2 PERMISSION ROLE FIX READY' as result,
  to_regprocedure('public.v1352_employee_role_permissions(text)') is not null as employee_role_permissions_rpc_ok;
