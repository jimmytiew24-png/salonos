-- SalonOS v13.5.3 · Customer Search + Product Categories + Member Retail Purchase
-- Additive / idempotent. Does not delete historical business data.
-- Run after v13.5.2 (or run the cumulative v13.5.3 SQL shipped with the full package).

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- 1) Real folder-like product categories shared by Inventory / Retail / Bundles.
-- -----------------------------------------------------------------------------
create table if not exists public.v13_product_categories (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  name text not null,
  description text,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(organization_id,store_id,name)
);
create index if not exists v1353_product_categories_store_idx
  on public.v13_product_categories(organization_id,store_id,active,sort_order,name);

alter table public.v13_product_categories enable row level security;
drop policy if exists v1353_product_categories_read on public.v13_product_categories;
create policy v1353_product_categories_read on public.v13_product_categories for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1353_product_categories_manage on public.v13_product_categories;
create policy v1353_product_categories_manage on public.v13_product_categories for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

alter table public.products add column if not exists category_id uuid;
do $$ begin
  if not exists(select 1 from pg_constraint where conname='products_v1353_category_id_fkey') then
    alter table public.products add constraint products_v1353_category_id_fkey
      foreign key(category_id) references public.v13_product_categories(id) on delete set null;
  end if;
end $$;

alter table public.v13_product_bundles
  add column if not exists category_id uuid,
  add column if not exists category text;
do $$ begin
  if not exists(select 1 from pg_constraint where conname='v13_product_bundles_v1353_category_id_fkey') then
    alter table public.v13_product_bundles add constraint v13_product_bundles_v1353_category_id_fkey
      foreign key(category_id) references public.v13_product_categories(id) on delete set null;
  end if;
end $$;

insert into public.v13_product_categories(organization_id,store_id,name,description,sort_order,active)
select distinct p.organization_id,p.store_id,coalesce(nullif(trim(p.category),''),'未分类'),null,0,true
from public.products p
where p.organization_id is not null and p.store_id is not null
on conflict(organization_id,store_id,name) do nothing;

update public.products p
set category_id=c.id,
    category=c.name,
    updated_at=now()
from public.v13_product_categories c
where c.organization_id=p.organization_id and c.store_id=p.store_id
  and c.name=coalesce(nullif(trim(p.category),''),'未分类')
  and (p.category_id is distinct from c.id or p.category is distinct from c.name);

-- Existing bundles may not have had a category; keep them in a real 未分类 folder.
insert into public.v13_product_categories(organization_id,store_id,name,description,sort_order,active)
select distinct b.organization_id,b.store_id,'未分类',null,0,true
from public.v13_product_bundles b
where b.organization_id is not null and b.store_id is not null
on conflict(organization_id,store_id,name) do nothing;

update public.v13_product_bundles b
set category_id=c.id,
    category=coalesce(nullif(trim(b.category),''),c.name),
    updated_at=now()
from public.v13_product_categories c
where c.organization_id=b.organization_id and c.store_id=b.store_id
  and c.name=coalesce(nullif(trim(b.category),''),'未分类')
  and (b.category_id is distinct from c.id or b.category is null or trim(b.category)='');

-- -----------------------------------------------------------------------------
-- 2) Direct member retail sales. This is separate from salon service checkout.
--    It supports stored-value wallet + one external method (Cash/Card/E-Wallet).
-- -----------------------------------------------------------------------------
create table if not exists public.v13_member_product_sales (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  membership_id uuid not null references public.memberships(id) on delete restrict,
  customer_id uuid not null references public.customers(id) on delete restrict,
  total_amount numeric(12,2) not null check(total_amount>=0),
  wallet_amount numeric(12,2) not null default 0 check(wallet_amount>=0),
  external_amount numeric(12,2) not null default 0 check(external_amount>=0),
  external_method text not null default 'cash' check(external_method in ('cash','card','ewallet','none')),
  status text not null default 'paid' check(status in ('paid','voided','refunded')),
  created_by_user_id uuid,
  created_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists v1353_member_product_sales_customer_idx
  on public.v13_member_product_sales(organization_id,store_id,customer_id,created_at desc);

create table if not exists public.v13_member_product_sale_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  sale_id uuid not null references public.v13_member_product_sales(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  product_name_snapshot text not null,
  category_snapshot text,
  sku_snapshot text,
  image_path_snapshot text,
  unit_price numeric(12,2) not null check(unit_price>=0),
  quantity numeric(12,3) not null check(quantity>0),
  line_total numeric(12,2) not null check(line_total>=0),
  created_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists v1353_member_product_sale_items_sale_idx
  on public.v13_member_product_sale_items(sale_id);

alter table public.v13_member_product_sales enable row level security;
alter table public.v13_member_product_sale_items enable row level security;
drop policy if exists v1353_member_product_sales_read on public.v13_member_product_sales;
create policy v1353_member_product_sales_read on public.v13_member_product_sales for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1353_member_product_sale_items_read on public.v13_member_product_sale_items;
create policy v1353_member_product_sale_items_read on public.v13_member_product_sale_items for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));

-- Sale writes go through this RPC to keep payment, wallet, points and inventory together.
create or replace function public.v1353_member_product_purchase(
  p_store_id uuid,
  p_membership_id uuid,
  p_product_id uuid,
  p_quantity numeric,
  p_wallet_amount numeric default 0,
  p_external_method text default 'cash',
  p_external_amount numeric default 0
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_org uuid;
  v_customer uuid;
  v_product public.products%rowtype;
  v_qty numeric:=greatest(coalesce(p_quantity,1),0.001);
  v_total numeric(12,2);
  v_wallet numeric(12,2):=greatest(coalesce(p_wallet_amount,0),0);
  v_external numeric(12,2):=greatest(coalesce(p_external_amount,0),0);
  v_method text:=lower(trim(coalesce(p_external_method,'cash')));
  v_balance numeric:=0;
  v_sale uuid:=gen_random_uuid();
  v_stock numeric:=0;
  v_remaining numeric:=0;
begin
  select m.organization_id,m.customer_id into v_org,v_customer
  from public.memberships m
  where m.id=p_membership_id and m.status='active'
  limit 1;
  if v_org is null then raise exception '会员不存在或已停用。'; end if;
  if not public.has_organization_role(v_org,array['owner','manager','receptionist']) then
    raise exception '你没有进行会员产品销售的权限。';
  end if;
  if not public.can_access_store(p_store_id) then raise exception '你没有当前分行权限。'; end if;

  select * into v_product from public.products p
  where p.id=p_product_id and p.organization_id=v_org and p.store_id=p_store_id
    and p.active=true and p.retail_enabled=true
  limit 1;
  if v_product.id is null then raise exception '销售产品不存在、已停用或不属于当前分行。'; end if;

  v_total:=round(greatest(coalesce(v_product.sale_price,0),0)*v_qty,2);
  if v_total<=0 then raise exception '产品售价必须大于 RM 0。'; end if;

  if coalesce(v_product.stock_enabled,false) then
    select coalesce(sum(m.quantity_delta),0) into v_stock
    from public.inventory_stock_movements m
    where m.organization_id=v_org and m.store_id=p_store_id and m.product_id=v_product.id;
    if v_stock < v_qty then raise exception '库存不足，目前可售 %。',v_stock; end if;
  end if;

  select coalesce(sum(w.amount_delta),0) into v_balance
  from public.member_wallet_ledger w
  where w.organization_id=v_org and w.membership_id=p_membership_id;
  if v_wallet>v_balance then raise exception '会员储值余额不足，目前余额 RM %。',round(v_balance,2); end if;
  if v_wallet>v_total then v_wallet:=v_total; end if;
  v_remaining:=round(v_total-v_wallet,2);
  if v_method not in ('cash','card','ewallet','none') then raise exception '付款方式无效。'; end if;
  if v_remaining=0 then v_method:='none'; v_external:=0; end if;
  if v_remaining>0 and v_method='none' then raise exception '还有 RM % 未付款，请选择现金、银行卡或电子钱包。',v_remaining; end if;
  if abs(v_external-v_remaining)>0.01 then raise exception '付款金额不正确，应付剩余 RM %。',v_remaining; end if;

  insert into public.v13_member_product_sales(
    id,organization_id,store_id,membership_id,customer_id,total_amount,wallet_amount,external_amount,external_method,status,created_by_user_id
  ) values(
    v_sale,v_org,p_store_id,p_membership_id,v_customer,v_total,v_wallet,v_external,v_method,'paid',auth.uid()
  );

  insert into public.v13_member_product_sale_items(
    organization_id,store_id,sale_id,product_id,product_name_snapshot,category_snapshot,sku_snapshot,image_path_snapshot,unit_price,quantity,line_total
  ) values(
    v_org,p_store_id,v_sale,v_product.id,v_product.name,v_product.category,v_product.sku,v_product.image_path,
    coalesce(v_product.sale_price,0),v_qty,v_total
  );

  if v_wallet>0 then
    insert into public.member_wallet_ledger(
      organization_id,membership_id,amount_delta,transaction_type,notes
    ) values(
      v_org,p_membership_id,-v_wallet,'payment','会员储值购买产品 · '||v_product.name||' · Sale '||v_sale::text
    );
  end if;

  -- Experience / points follow the current SalonOS 1 RM = 1 XP = 1 point base rule.
  insert into public.member_loyalty_ledger(
    organization_id,membership_id,experience_delta,points_delta,transaction_type,notes
  ) values(
    v_org,p_membership_id,v_total,v_total,'purchase','产品消费 · '||v_product.name||' · Sale '||v_sale::text
  );

  if coalesce(v_product.stock_enabled,false) then
    perform public.v1346_add_product_stock(
      v_product.id,
      -v_qty,
      greatest(coalesce(v_product.cost_price,0),0),
      'Member retail sale '||v_sale::text||' · '||v_product.name
    );
  end if;

  return jsonb_build_object(
    'success',true,'sale_id',v_sale,'customer_id',v_customer,'membership_id',p_membership_id,
    'product_name',v_product.name,'quantity',v_qty,'total_amount',v_total,
    'wallet_used',v_wallet,'external_amount',v_external,'external_method',v_method,
    'wallet_balance',round(v_balance-v_wallet,2)
  );
end;
$$;
revoke all on function public.v1353_member_product_purchase(uuid,uuid,uuid,numeric,numeric,text,numeric) from public;
grant execute on function public.v1353_member_product_purchase(uuid,uuid,uuid,numeric,numeric,text,numeric) to authenticated;

-- Employee-session product search for Manager / Front Desk checkout UI. No cost fields are exposed.
create or replace function public.v1353_employee_product_search(
  p_session_token text,
  p_query text default '',
  p_category_id uuid default null
)
returns jsonb
language plpgsql
stable
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb;
  v_org uuid;
  v_store uuid;
  v_q text:=lower(trim(coalesce(p_query,'')));
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id',p.id,'type','single','type_text','销售产品','name',p.name,
      'code',coalesce(nullif(p.sku,''),p.barcode,''),'sku',coalesce(p.sku,''),'barcode',coalesce(p.barcode,''),
      'category_id',p.category_id,'category',coalesce(c.name,p.category,'未分类'),'description',coalesce(p.purpose,''),
      'price',coalesce(p.sale_price,0),'price_text','RM '||to_char(coalesce(p.sale_price,0),'FM999999990.00'),
      'image_url',coalesce(p.image_path,''),
      'available',case when coalesce(p.stock_enabled,false) then greatest(0,coalesce((select sum(m.quantity_delta) from public.inventory_stock_movements m where m.organization_id=v_org and m.store_id=v_store and m.product_id=p.id),0)) else 999999 end,
      'stock_text',case when coalesce(p.stock_enabled,false) then to_char(greatest(0,coalesce((select sum(m.quantity_delta) from public.inventory_stock_movements m where m.organization_id=v_org and m.store_id=v_store and m.product_id=p.id),0)),'FM999999990.##')||' '||coalesce(p.stock_unit,'pcs') else '不追踪库存' end
    ) order by coalesce(c.sort_order,9999),coalesce(c.name,p.category,'未分类'),p.name)
    from public.products p
    left join public.v13_product_categories c on c.id=p.category_id and c.organization_id=p.organization_id and c.store_id=p.store_id
    where p.organization_id=v_org and p.store_id=v_store and p.active and coalesce(p.retail_enabled,false)
      and (p_category_id is null or p.category_id=p_category_id)
      and (v_q='' or lower(coalesce(p.name,'')||' '||coalesce(p.sku,'')||' '||coalesce(p.barcode,'')||' '||coalesce(c.name,p.category,'')) like '%'||v_q||'%')
  ),'[]'::jsonb);
end;
$$;
revoke all on function public.v1353_employee_product_search(text,text,uuid) from public;
grant execute on function public.v1353_employee_product_search(text,text,uuid) to anon,authenticated;

create or replace function public.v1353_runtime_contract_status()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'version','13.5.3',
    'ok',
      to_regclass('public.v13_product_categories') is not null
      and to_regclass('public.v13_member_product_sales') is not null
      and to_regclass('public.v13_member_product_sale_items') is not null
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='products' and column_name='category_id')
      and to_regprocedure('public.v1353_member_product_purchase(uuid,uuid,uuid,numeric,numeric,text,numeric)') is not null
      and to_regprocedure('public.v1353_employee_product_search(text,text,uuid)') is not null,
    'product_categories_ok',to_regclass('public.v13_product_categories') is not null,
    'product_category_column_ok',exists(select 1 from information_schema.columns where table_schema='public' and table_name='products' and column_name='category_id'),
    'member_product_sales_ok',to_regclass('public.v13_member_product_sales') is not null,
    'member_product_purchase_rpc_ok',to_regprocedure('public.v1353_member_product_purchase(uuid,uuid,uuid,numeric,numeric,text,numeric)') is not null,
    'employee_product_search_rpc_ok',to_regprocedure('public.v1353_employee_product_search(text,text,uuid)') is not null
  );
$$;
revoke all on function public.v1353_runtime_contract_status() from public;
grant execute on function public.v1353_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('runtime_contract_version','13.5.3'),
 ('product_ux_version','13.5.3'),
 ('customer_search_version','13.5.3'),
 ('member_retail_version','13.5.3')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.5.3 PRODUCT / MEMBER / SEARCH READY' as result,
  to_regclass('public.v13_product_categories') is not null as product_categories_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='products' and column_name='category_id') as product_category_column_ok,
  to_regclass('public.v13_member_product_sales') is not null as member_product_sales_ok,
  to_regprocedure('public.v1353_member_product_purchase(uuid,uuid,uuid,numeric,numeric,text,numeric)') is not null as member_product_purchase_rpc_ok,
  to_regprocedure('public.v1353_employee_product_search(text,text,uuid)') is not null as employee_product_search_rpc_ok;
