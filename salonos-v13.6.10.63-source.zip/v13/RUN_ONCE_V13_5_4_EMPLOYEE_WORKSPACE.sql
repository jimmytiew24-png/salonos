-- SalonOS v13.5.4 · Employee Workspace / Permission / Performance Contract
-- Additive + idempotent. Does not delete historical business records.
-- Run after v13.5.3, or use the cumulative v13.5.4 SQL shipped with the full package.

begin;
set local statement_timeout='0';
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('salonos-media','salonos-media',true,2097152,array['image/jpeg','image/png','image/webp']::text[])
on conflict (id) do update set public=excluded.public,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

-- 1) Employee avatar metadata + short-lived anonymous Storage upload tickets.
alter table public.employees add column if not exists avatar_path text;

create table if not exists public.v13_employee_avatar_upload_tokens (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists v1354_avatar_ticket_employee_idx
  on public.v13_employee_avatar_upload_tokens(employee_id,expires_at desc);
alter table public.v13_employee_avatar_upload_tokens enable row level security;

create or replace function public.v1354_employee_permission_allowed(p_session_token text,p_permission text)
returns boolean
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_role text; v_permissions jsonb:='{}'::jsonb; v_list jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_role:=coalesce(nullif(v_ctx->>'employee_role',''),'staff');
  select coalesce(s.role_permissions,'{}'::jsonb) into v_permissions
  from public.v13_organization_settings s where s.organization_id=v_org limit 1;
  v_list:=v_permissions->v_role;
  if jsonb_typeof(v_list)='array' then
    return v_list ? '*' or v_list ? p_permission;
  end if;
  -- Safe defaults mirror the PHP defaults when a role has never been customized.
  if v_role='manager' then return true; end if;
  if v_role='receptionist' then
    return p_permission = any(array['dashboard.view','visits.create','orders.view','performance.view','training.view','orders.manage','customers.view','customers.manage','checkout.manage','products.view','appointments.manage']);
  end if;
  if v_role='accountant' then
    return p_permission = any(array['dashboard.view','order_history.view','analytics.view','performance.view','commission.view','reports.export']);
  end if;
  if v_role='stylist' then
    return p_permission = any(array['dashboard.view','visits.create','orders.view','performance.view','training.view','customers.view','products.view']);
  end if;
  return p_permission = any(array['dashboard.view','visits.create','orders.view','performance.view','training.view']);
end;
$$;
revoke all on function public.v1354_employee_permission_allowed(text,text) from public;
grant execute on function public.v1354_employee_permission_allowed(text,text) to anon,authenticated;

create or replace function public.v1354_avatar_upload_path_allowed(p_name text)
returns boolean
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_org_text text:=split_part(coalesce(p_name,''),'/',1);
  v_folder text:=split_part(coalesce(p_name,''),'/',2);
  v_employee_text text:=split_part(coalesce(p_name,''),'/',3);
  v_file text:=split_part(coalesce(p_name,''),'/',4);
  v_token text:=split_part(v_file,'.',1);
  v_org uuid; v_employee uuid;
begin
  if v_folder<>'employee-avatars' then return false; end if;
  if v_org_text !~* '^[0-9a-f-]{36}$' or v_employee_text !~* '^[0-9a-f-]{36}$' or v_token !~ '^[0-9a-f]{32,128}$' then return false; end if;
  v_org:=v_org_text::uuid; v_employee:=v_employee_text::uuid;
  return exists(
    select 1 from public.v13_employee_avatar_upload_tokens t
    where t.organization_id=v_org and t.employee_id=v_employee
      and t.token_hash=encode(digest(v_token,'sha256'),'hex')
      and t.used_at is null and t.expires_at>now()
  );
end;
$$;
revoke all on function public.v1354_avatar_upload_path_allowed(text) from public;
grant execute on function public.v1354_avatar_upload_path_allowed(text) to anon,authenticated;

-- Employee custom sessions are not Supabase Auth users. This narrowly-scoped Storage
-- policy allows only a short-lived random avatar path that was issued by a validated
-- employee session. Other anonymous uploads remain denied.
drop policy if exists salonos_employee_avatar_ticket_insert on storage.objects;
create policy salonos_employee_avatar_ticket_insert on storage.objects
for insert to anon,authenticated
with check (
  bucket_id='salonos-media'
  and public.v1354_avatar_upload_path_allowed(name)
);

create or replace function public.v1354_employee_avatar_upload_ticket(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_store uuid; v_employee uuid; v_token text:=encode(gen_random_bytes(24),'hex');
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid; v_employee:=(v_ctx->>'employee_id')::uuid;
  delete from public.v13_employee_avatar_upload_tokens where expires_at<now()-interval '1 hour' or used_at is not null;
  insert into public.v13_employee_avatar_upload_tokens(organization_id,store_id,employee_id,token_hash,expires_at)
  values(v_org,v_store,v_employee,encode(digest(v_token,'sha256'),'hex'),now()+interval '5 minutes');
  return jsonb_build_object('organization_id',v_org,'store_id',v_store,'employee_id',v_employee,'upload_token',v_token,'expires_at',now()+interval '5 minutes');
end;
$$;
revoke all on function public.v1354_employee_avatar_upload_ticket(text) from public;
grant execute on function public.v1354_employee_avatar_upload_ticket(text) to anon,authenticated;

create or replace function public.v1354_employee_set_avatar(p_session_token text,p_avatar_path text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_employee uuid; v_token text; v_prefix text;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid; v_employee:=(v_ctx->>'employee_id')::uuid;
  v_prefix:=v_org::text||'/employee-avatars/'||v_employee::text||'/';
  if p_avatar_path is null or left(p_avatar_path,length(v_prefix))<>v_prefix then raise exception '头像路径无效。'; end if;
  v_token:=split_part(split_part(p_avatar_path,'/',4),'.',1);
  if not exists(select 1 from public.v13_employee_avatar_upload_tokens t where t.organization_id=v_org and t.employee_id=v_employee and t.token_hash=encode(digest(v_token,'sha256'),'hex') and t.used_at is null and t.expires_at>now()) then
    raise exception '头像上传授权已过期，请重新选择图片。';
  end if;
  update public.employees set avatar_path=p_avatar_path,updated_at=now() where id=v_employee and organization_id=v_org;
  update public.v13_employee_avatar_upload_tokens set used_at=now() where organization_id=v_org and employee_id=v_employee and token_hash=encode(digest(v_token,'sha256'),'hex') and used_at is null;
  return jsonb_build_object('avatar_path',p_avatar_path);
end;
$$;
revoke all on function public.v1354_employee_set_avatar(text,text) from public;
grant execute on function public.v1354_employee_set_avatar(text,text) to anon,authenticated;

create or replace function public.v1354_employee_profile(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_employee uuid; v_org uuid;
begin
  v_ctx:=public.employee_session_context(p_session_token); v_employee:=(v_ctx->>'employee_id')::uuid; v_org:=(v_ctx->>'organization_id')::uuid;
  return (select jsonb_build_object('employee_id',e.id,'name',e.name,'position',e.position,'employee_code',e.employee_code,'app_role',e.app_role,'avatar_path',e.avatar_path)
          from public.employees e where e.id=v_employee and e.organization_id=v_org);
end;
$$;
revoke all on function public.v1354_employee_profile(text) from public;
grant execute on function public.v1354_employee_profile(text) to anon,authenticated;

-- Existing employee login/session RPCs remain untouched to avoid dependency churn.
-- PHP fetches avatar_path from v1354_employee_profile after validating the existing session.

-- Owner directory now exposes avatar_path too (salary remains in this owner-only RPC).
create or replace function public.v13_employee_directory(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_org uuid; v_result jsonb;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id;
  if v_org is null then raise exception '找不到门店。'; end if;
  if not public.has_organization_role(v_org,array['owner','manager','accountant']) then raise exception '你没有查看员工资料的权限。'; end if;
  if not public.can_access_store(p_store_id) then raise exception '你没有这个门店的权限。'; end if;
  select coalesce(jsonb_agg(x order by (x->>'employment_status'='active') desc,x->>'name'),'[]'::jsonb) into v_result from (
    select jsonb_build_object(
      'id',e.id,'employee_code',e.employee_code,'name',e.name,'phone',e.phone,'position',e.position,'avatar_path',e.avatar_path,
      'age',e.age,'gender',e.gender,'skill_tags',e.skill_tags,'app_role',e.app_role,
      'base_salary',coalesce(ec.base_salary,0),'joined_at',e.joined_at,'employment_status',e.employment_status,
      'is_on_duty',e.is_on_duty,'availability_status',e.availability_status,'last_login_at',e.last_login_at,
      'order_count',(select count(distinct vv.id) from public.visit_service_workers w join public.visit_service_items si on si.id=w.service_item_id and si.organization_id=e.organization_id join public.visits vv on vv.id=si.visit_id and vv.organization_id=e.organization_id where w.employee_id=e.id and w.organization_id=e.organization_id)
    ) x
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id and es.store_id=p_store_id and es.status='active'
    left join public.employee_compensation ec on ec.employee_id=e.id and ec.organization_id=e.organization_id
    where e.organization_id=v_org
  ) q;
  return v_result;
end;
$$;
revoke all on function public.v13_employee_directory(uuid) from public;
grant execute on function public.v13_employee_directory(uuid) to authenticated;

-- 2) Employee customer/member directory. Access is checked against the live role matrix.
create or replace function public.v1354_employee_customer_directory(p_session_token text,p_query text default '',p_customer_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_store uuid; v_q text:=lower(trim(coalesce(p_query,''))); v_rows jsonb; v_detail jsonb; v_manage boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token); v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid;
  if not public.v1354_employee_permission_allowed(p_session_token,'customers.view') and not public.v1354_employee_permission_allowed(p_session_token,'customers.manage') then
    raise exception '你的职位没有查看顾客与会员的权限。';
  end if;
  v_manage:=public.v1354_employee_permission_allowed(p_session_token,'customers.manage');
  select coalesce(jsonb_agg(x order by x->>'name'),'[]'::jsonb) into v_rows from (
    select jsonb_build_object(
      'id',c.id,'name',c.name,'phone',c.phone,'gender',c.gender,'birth_date',c.birth_date,'ethnicity',c.ethnicity,'email',c.email,
      'identification_number',c.identification_number,'address',c.address,'acquisition_platform',c.acquisition_platform,'notes',c.notes,
      'member_number',m.member_number,'level_number',ml.level_number,'level_name',ml.name,
      'visit_count',(select count(distinct vr.visit_id) from public.visit_recipients vr join public.visits vv on vv.id=vr.visit_id and vv.organization_id=vr.organization_id where vr.organization_id=v_org and vr.customer_id=c.id and vv.store_id=v_store)
    ) x
    from public.customers c
    left join public.memberships m on m.customer_id=c.id and m.organization_id=c.organization_id and m.status='active'
    left join public.membership_levels ml on ml.id=m.current_level_id and ml.organization_id=c.organization_id
    where c.organization_id=v_org and c.store_id=v_store
      and (v_q='' or lower(coalesce(c.name,'')||' '||coalesce(c.phone,'')||' '||coalesce(m.member_number,'')||' '||coalesce(c.email,'')||' '||coalesce(c.identification_number,'')) like '%'||v_q||'%')
    order by c.created_at desc limit 120
  ) q;
  if p_customer_id is not null then
    select jsonb_build_object(
      'customer',jsonb_build_object('id',c.id,'name',c.name,'phone',c.phone,'gender',c.gender,'birth_date',c.birth_date,'ethnicity',c.ethnicity,'email',c.email,'identification_number',c.identification_number,'address',c.address,'acquisition_platform',c.acquisition_platform,'notes',c.notes),
      'membership',case when m.id is null then null else jsonb_build_object('id',m.id,'member_number',m.member_number,'joined_at',m.joined_at,'level_number',ml.level_number,'level_name',ml.name) end,
      'wallet_balance',coalesce((select sum(w.amount_delta) from public.member_wallet_ledger w where w.organization_id=v_org and w.membership_id=m.id),0),
      'points',coalesce((select sum(l.points_delta) from public.member_loyalty_ledger l where l.organization_id=v_org and l.membership_id=m.id),0),
      'experience',coalesce((select sum(l.experience_delta) from public.member_loyalty_ledger l where l.organization_id=v_org and l.membership_id=m.id),0),
      'visit_count',(select count(distinct vr.visit_id) from public.visit_recipients vr join public.visits vv on vv.id=vr.visit_id and vv.organization_id=vr.organization_id where vr.organization_id=v_org and vr.customer_id=c.id and vv.store_id=v_store)
    ) into v_detail
    from public.customers c
    left join public.memberships m on m.customer_id=c.id and m.organization_id=c.organization_id and m.status='active'
    left join public.membership_levels ml on ml.id=m.current_level_id and ml.organization_id=c.organization_id
    where c.id=p_customer_id and c.organization_id=v_org and c.store_id=v_store limit 1;
  end if;
  return jsonb_build_object('customers',coalesce(v_rows,'[]'::jsonb),'detail',v_detail,'can_manage',v_manage);
end;
$$;
revoke all on function public.v1354_employee_customer_directory(text,text,uuid) from public;
grant execute on function public.v1354_employee_customer_directory(text,text,uuid) to anon,authenticated;

-- 3) Shared performance board core: day / month / year, ranking + employee drill-down.
create or replace function public.v1354_performance_board_core(p_organization_id uuid,p_store_id uuid,p_period text,p_anchor date,p_employee_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_period text:=case when p_period in ('day','month','year') then p_period else 'month' end;
  v_anchor date:=coalesce(p_anchor,current_date); v_start timestamptz; v_end timestamptz; v_label text; v_ranking jsonb; v_detail jsonb; v_activity jsonb;
begin
  if v_period='day' then
    v_start=(v_anchor::timestamp at time zone 'Asia/Kuala_Lumpur'); v_end=((v_anchor+1)::timestamp at time zone 'Asia/Kuala_Lumpur'); v_label=to_char(v_anchor,'DD/MM/YYYY');
  elsif v_period='year' then
    v_start=(date_trunc('year',v_anchor::timestamp) at time zone 'Asia/Kuala_Lumpur'); v_end=(date_trunc('year',v_anchor::timestamp)+interval '1 year') at time zone 'Asia/Kuala_Lumpur'; v_label=to_char(v_anchor,'YYYY');
  else
    v_start=(date_trunc('month',v_anchor::timestamp) at time zone 'Asia/Kuala_Lumpur'); v_end=(date_trunc('month',v_anchor::timestamp)+interval '1 month') at time zone 'Asia/Kuala_Lumpur'; v_label=to_char(v_anchor,'MM/YYYY');
  end if;
  with staff as (
    select e.id,e.name,e.position,e.employee_code,e.avatar_path,e.employment_status
    from public.employees e join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
    where e.organization_id=p_organization_id and es.store_id=p_store_id and es.status='active'
  ), service as (
    select sp.employee_id,coalesce(sum(sp.performance_amount),0)::numeric service_performance,count(*)::int service_count,count(distinct sp.visit_id)::int customer_count
    from public.service_performance_ledger sp join public.payments p on p.id=sp.payment_id and p.organization_id=sp.organization_id and p.store_id=sp.store_id
    where sp.organization_id=p_organization_id and sp.store_id=p_store_id and p.status='paid' and p.paid_at>=v_start and p.paid_at<v_end group by sp.employee_id
  ), visit_stats as (
    select sp.employee_id,count(distinct case when v.visit_type='appointment' then sp.visit_id end)::int appointments,count(distinct case when v.visit_type<>'appointment' then sp.visit_id end)::int walkins
    from public.service_performance_ledger sp join public.payments p on p.id=sp.payment_id and p.status='paid' join public.visits v on v.id=sp.visit_id and v.organization_id=sp.organization_id
    where sp.organization_id=p_organization_id and sp.store_id=p_store_id and p.paid_at>=v_start and p.paid_at<v_end group by sp.employee_id
  ), product as (
    select pi.salesperson_employee_id employee_id,coalesce(sum(pi.line_total),0)::numeric product_sales,coalesce(sum(pi.quantity),0)::numeric product_units
    from public.visit_product_items pi
    where pi.organization_id=p_organization_id and pi.store_id=p_store_id and pi.status='active' and pi.salesperson_employee_id is not null
      and exists(select 1 from public.payments pp where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end)
    group by pi.salesperson_employee_id
  ), commission as (
    select c.employee_id,coalesce(sum(c.commission_amount),0)::numeric commission_amount from public.employee_commission_ledger c
    where c.organization_id=p_organization_id and c.store_id=p_store_id and c.created_at>=v_start and c.created_at<v_end group by c.employee_id
  ), scores as (
    select s.*,coalesce(se.service_performance,0)::numeric service_performance,coalesce(pr.product_sales,0)::numeric product_sales,
      (coalesce(se.service_performance,0)+coalesce(pr.product_sales,0))::numeric total_performance,coalesce(co.commission_amount,0)::numeric commission_amount,
      coalesce(se.service_count,0)::int service_count,coalesce(se.customer_count,0)::int customer_count,coalesce(vs.appointments,0)::int appointments,coalesce(vs.walkins,0)::int walkins,coalesce(pr.product_units,0)::numeric product_units
    from staff s left join service se on se.employee_id=s.id left join product pr on pr.employee_id=s.id left join commission co on co.employee_id=s.id left join visit_stats vs on vs.employee_id=s.id
  ), ranked as (
    select row_number() over(order by total_performance desc,service_performance desc,name asc)::int rank_no,* from scores
  )
  select coalesce(jsonb_agg(jsonb_build_object('rank',rank_no,'employee_id',id,'name',name,'position',position,'employee_code',employee_code,'avatar_path',avatar_path,'employment_status',employment_status,'service_performance',service_performance,'product_sales',product_sales,'total_performance',total_performance,'commission_amount',commission_amount,'service_count',service_count,'customer_count',customer_count,'appointments',appointments,'walkins',walkins,'product_units',product_units) order by rank_no),'[]'::jsonb) into v_ranking from ranked;

  if p_employee_id is not null then
    select x into v_detail from jsonb_array_elements(v_ranking) x where x->>'employee_id'=p_employee_id::text limit 1;
    select coalesce(jsonb_agg(z.a order by z.a->>'occurred_at' desc),'[]'::jsonb) into v_activity from (
      select jsonb_build_object('type','service','label',coalesce(v.visit_number,'服务项目'),'amount',sp.performance_amount,'occurred_at',p.paid_at) a
      from public.service_performance_ledger sp join public.payments p on p.id=sp.payment_id and p.status='paid' left join public.visits v on v.id=sp.visit_id
      where sp.organization_id=p_organization_id and sp.store_id=p_store_id and sp.employee_id=p_employee_id and p.paid_at>=v_start and p.paid_at<v_end
      union all
      select jsonb_build_object('type','product','label',coalesce(pi.product_name_snapshot,'产品销售'),'amount',pi.line_total,'occurred_at',(select max(pp.paid_at) from public.payments pp where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end))
      from public.visit_product_items pi
      where pi.organization_id=p_organization_id and pi.store_id=p_store_id and pi.salesperson_employee_id=p_employee_id and pi.status='active'
        and exists(select 1 from public.payments pp where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end)
    ) z;
  end if;
  return jsonb_build_object('period',v_period,'anchor',v_anchor,'label',v_label,'range_start',v_start,'range_end',v_end,'ranking',coalesce(v_ranking,'[]'::jsonb),'detail',v_detail,'activity',coalesce(v_activity,'[]'::jsonb));
end;
$$;
revoke all on function public.v1354_performance_board_core(uuid,uuid,text,date,uuid) from public;

create or replace function public.v1354_owner_performance_board(p_store_id uuid,p_period text,p_anchor date,p_employee_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_org uuid;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id and s.status='active';
  if v_org is null then raise exception '找不到门店。'; end if;
  if not public.can_access_store(p_store_id) or not public.has_organization_role(v_org,array['owner','manager','accountant']) then raise exception '你没有查看员工业绩的权限。'; end if;
  return public.v1354_performance_board_core(v_org,p_store_id,p_period,p_anchor,p_employee_id);
end;
$$;
revoke all on function public.v1354_owner_performance_board(uuid,text,date,uuid) from public;
grant execute on function public.v1354_owner_performance_board(uuid,text,date,uuid) to authenticated;

create or replace function public.v1354_employee_performance_board(p_session_token text,p_period text,p_anchor date,p_employee_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_org uuid; v_store uuid;
begin
  v_ctx:=public.employee_session_context(p_session_token); v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid;
  if not public.v1354_employee_permission_allowed(p_session_token,'performance.view') then raise exception '你的职位没有查看员工业绩的权限。'; end if;
  return public.v1354_performance_board_core(v_org,v_store,p_period,p_anchor,p_employee_id);
end;
$$;
revoke all on function public.v1354_employee_performance_board(text,text,date,uuid) from public;
grant execute on function public.v1354_employee_performance_board(text,text,date,uuid) to anon,authenticated;

create or replace function public.v1354_runtime_contract_status()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'version','13.5.4',
    'ok',
      to_regprocedure('public.v1353_runtime_contract_status()') is not null
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='employees' and column_name='avatar_path')
      and to_regclass('public.v13_employee_avatar_upload_tokens') is not null
      and to_regprocedure('public.v1354_employee_customer_directory(text,text,uuid)') is not null
      and to_regprocedure('public.v1354_employee_performance_board(text,text,date,uuid)') is not null
      and to_regprocedure('public.v1354_owner_performance_board(uuid,text,date,uuid)') is not null
      and to_regprocedure('public.v1354_employee_avatar_upload_ticket(text)') is not null,
    'employee_avatar_column_ok',exists(select 1 from information_schema.columns where table_schema='public' and table_name='employees' and column_name='avatar_path'),
    'avatar_ticket_table_ok',to_regclass('public.v13_employee_avatar_upload_tokens') is not null,
    'employee_customer_rpc_ok',to_regprocedure('public.v1354_employee_customer_directory(text,text,uuid)') is not null,
    'employee_performance_rpc_ok',to_regprocedure('public.v1354_employee_performance_board(text,text,date,uuid)') is not null,
    'owner_performance_rpc_ok',to_regprocedure('public.v1354_owner_performance_board(uuid,text,date,uuid)') is not null,
    'employee_avatar_ticket_rpc_ok',to_regprocedure('public.v1354_employee_avatar_upload_ticket(text)') is not null
  );
$$;
revoke all on function public.v1354_runtime_contract_status() from public;
grant execute on function public.v1354_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('employee_workspace_version','13.5.4'),
 ('runtime_contract_version','13.5.4')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.5.4 EMPLOYEE WORKSPACE READY' as result,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='employees' and column_name='avatar_path') as employee_avatar_column_ok,
  to_regprocedure('public.v1354_employee_customer_directory(text,text,uuid)') is not null as employee_customer_directory_ok,
  to_regprocedure('public.v1354_employee_performance_board(text,text,date,uuid)') is not null as employee_performance_board_ok,
  to_regprocedure('public.v1354_owner_performance_board(uuid,text,date,uuid)') is not null as owner_performance_board_ok,
  to_regprocedure('public.v1354_employee_avatar_upload_ticket(text)') is not null as employee_avatar_ticket_ok;
