-- SalonOS v13.4.5.1 · CUMULATIVE RUNTIME CONTRACT HOTFIX + SERVICE BOARD
-- Additive/idempotent. Safe to run again. Does NOT delete business data.
-- Purpose: prevent PHP/Database version drift from turning a whole module into a raw PGRST202/PGRST204 error.

begin;
set local statement_timeout='0';

create table if not exists public.salonos_system_meta (
  meta_key text primary key,
  meta_value text not null,
  updated_at timestamptz not null default now()
);

-- Cumulative compatibility contract from v13.4.2 / v13.4.3.
alter table public.employee_stores add column if not exists updated_at timestamptz not null default now();
alter table public.employees add column if not exists availability_status text not null default 'available';
alter table public.employees add column if not exists is_on_duty boolean not null default true;
alter table public.employees add column if not exists updated_at timestamptz not null default now();
alter table public.visit_service_items add column if not exists service_category_snapshot text;
alter table public.visits add column if not exists started_at timestamptz;
alter table public.visits add column if not exists service_completed_at timestamptz;
alter table public.visits add column if not exists checked_out_at timestamptz;
alter table public.visits add column if not exists updated_at timestamptz not null default now();

update public.employees set availability_status='available'
where availability_status is null or availability_status not in ('available','break','off_duty','in_service','busy','disabled','inactive');

do $$ begin
  if not exists (select 1 from pg_constraint where conrelid='public.employees'::regclass and conname='employees_availability_status_check') then
    alter table public.employees add constraint employees_availability_status_check
      check (availability_status in ('available','break','off_duty','in_service','busy','disabled','inactive'));
  end if;
end $$;

update public.visit_service_items si set service_category_snapshot=s.category
from public.services s
where si.service_category_snapshot is null and si.service_id=s.id and si.organization_id=s.organization_id
  and (si.store_id is null or si.store_id=s.store_id);

-- v13.4.4 referenced this table but older Supabase schemas never created it.
-- Define it here before any Service Board function can reference it.
create table if not exists public.visit_product_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  store_id uuid not null,
  visit_id uuid not null,
  product_id uuid,
  bundle_id uuid,
  item_type text not null default 'product',
  product_name_snapshot text not null default '',
  sku_snapshot text,
  unit_price numeric(12,2) not null default 0,
  cost_price_snapshot numeric(12,2) not null default 0,
  quantity numeric(12,3) not null default 1,
  salesperson_employee_id uuid,
  commission_rate_snapshot numeric(8,3) not null default 0,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.visit_product_items add column if not exists bundle_id uuid;
alter table public.visit_product_items add column if not exists item_type text not null default 'product';
alter table public.visit_product_items add column if not exists product_name_snapshot text not null default '';
alter table public.visit_product_items add column if not exists sku_snapshot text;
alter table public.visit_product_items add column if not exists unit_price numeric(12,2) not null default 0;
alter table public.visit_product_items add column if not exists cost_price_snapshot numeric(12,2) not null default 0;
alter table public.visit_product_items add column if not exists quantity numeric(12,3) not null default 1;
alter table public.visit_product_items add column if not exists salesperson_employee_id uuid;
alter table public.visit_product_items add column if not exists commission_rate_snapshot numeric(8,3) not null default 0;
alter table public.visit_product_items add column if not exists status text not null default 'active';
alter table public.visit_product_items add column if not exists created_at timestamptz not null default now();
alter table public.visit_product_items add column if not exists updated_at timestamptz not null default now();
create index if not exists visit_product_items_visit_idx on public.visit_product_items(organization_id,store_id,visit_id);
create index if not exists visit_product_items_product_idx on public.visit_product_items(organization_id,store_id,product_id);

-- line_total compatibility:
-- Some older SalonOS schemas define line_total as GENERATED ALWAYS, while newer compatibility
-- builds may have it as a normal numeric column. Never UPDATE or assign to a generated column.
alter table public.visit_product_items add column if not exists line_total numeric(14,2);

create or replace function public.v135_visit_product_line_total_sync()
returns trigger language plpgsql set search_path=public as $$
begin
  new.line_total:=round((coalesce(new.unit_price,0)*coalesce(new.quantity,0))::numeric,2);
  new.updated_at:=now();
  return new;
end; $$;

do $$
declare v_generated text;
begin
  select a.attgenerated into v_generated
  from pg_attribute a
  where a.attrelid='public.visit_product_items'::regclass
    and a.attname='line_total'
    and a.attnum>0
    and not a.attisdropped;

  drop trigger if exists trg_v135_visit_product_line_total_sync on public.visit_product_items;

  if coalesce(v_generated,'')='' then
    update public.visit_product_items
      set line_total=round((coalesce(unit_price,0)*coalesce(quantity,0))::numeric,2)
      where line_total is null;
    execute 'create trigger trg_v135_visit_product_line_total_sync before insert or update of unit_price,quantity on public.visit_product_items for each row execute function public.v135_visit_product_line_total_sync()';
  end if;
end $$;

-- Core module contract fields: additive only; old pages keep working if they do not use them yet.
alter table public.products add column if not exists stock_unit text not null default 'pcs';
alter table public.products add column if not exists tunaipro_id text;
do $$ begin
  if to_regclass('public.v13_training_courses') is not null then
    execute 'alter table public.v13_training_courses add column if not exists category text';
    execute 'alter table public.v13_training_courses add column if not exists target_roles jsonb not null default ''[]''::jsonb';
    execute 'alter table public.v13_training_courses add column if not exists content_url text';
    execute 'alter table public.v13_training_courses add column if not exists estimated_minutes integer not null default 0';
    execute 'alter table public.v13_training_courses add column if not exists version_label text';
    execute 'alter table public.v13_training_courses add column if not exists required boolean not null default false';
    execute 'alter table public.v13_training_courses add column if not exists publication_status text not null default ''published''';
  end if;
  if to_regclass('public.v13_kpi_assignments') is not null then
    execute 'alter table public.v13_kpi_assignments add column if not exists target_value numeric';
    execute 'alter table public.v13_kpi_assignments add column if not exists bonus_amount numeric';
    execute 'alter table public.v13_kpi_assignments add column if not exists status text not null default ''active''';
    execute 'alter table public.v13_kpi_assignments add column if not exists achieved_at timestamptz';
    execute 'alter table public.v13_kpi_assignments add column if not exists reviewed_at timestamptz';
    execute 'alter table public.v13_kpi_assignments add column if not exists paid_at timestamptz';
    execute 'alter table public.v13_kpi_assignments add column if not exists locked_at timestamptz';
  end if;
end $$;

-- Shared internal board snapshot. Not directly executable by clients.
create or replace function public.v1344_board_snapshot_internal(
  p_organization_id uuid,
  p_store_id uuid,
  p_employee_id uuid,
  p_can_see_all boolean,
  p_board_date date
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result jsonb;
begin
  select jsonb_build_object(
    'board_date', p_board_date,
    'can_see_all', p_can_see_all,
    'employees', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',e.id,
        'employee_code',e.employee_code,
        'name',e.name,
        'position',e.position,
        'availability_status',coalesce(e.availability_status,'available'),
        'is_on_duty',coalesce(e.is_on_duty,true),
        'employment_status',e.employment_status
      ) order by e.name)
      from public.employees e
      join public.employee_stores es
        on es.employee_id=e.id
       and es.organization_id=e.organization_id
       and es.store_id=p_store_id
       and es.status='active'
      where e.organization_id=p_organization_id
        and e.employment_status='active'
        and (p_can_see_all or e.id=p_employee_id)
    ), '[]'::jsonb),
    'visits', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',v.id,
        'visit_number',v.visit_number,
        'visit_type',v.visit_type,
        'status',v.status,
        'scheduled_at',v.scheduled_at,
        'arrived_at',v.arrived_at,
        'started_at',v.started_at,
        'service_completed_at',v.service_completed_at,
        'checked_out_at',v.checked_out_at,
        'created_at',v.created_at,
        'sort_at',coalesce(v.scheduled_at,v.created_at),
        'customer_name',coalesce((
          select r.name_snapshot from public.visit_recipients r
          where r.visit_id=v.id and r.organization_id=p_organization_id
          order by case when r.recipient_type='primary' then 0 else 1 end, r.id
          limit 1
        ),'顾客'),
        'customer_phone',coalesce((
          select r.phone_snapshot from public.visit_recipients r
          where r.visit_id=v.id and r.organization_id=p_organization_id
          order by case when r.recipient_type='primary' then 0 else 1 end, r.id
          limit 1
        ),''),
        'member_number',(
          select m.member_number
          from public.visit_recipients r
          join public.memberships m on m.customer_id=r.customer_id and m.organization_id=p_organization_id and m.status='active'
          where r.visit_id=v.id and r.organization_id=p_organization_id and r.customer_id is not null
          order by case when r.recipient_type='primary' then 0 else 1 end, m.created_at desc
          limit 1
        ),
        'services',coalesce((
          select string_agg(distinct si.service_name_snapshot,'、')
          from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),'尚未加入项目'),
        'service_count',coalesce((
          select count(*) from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),0),
        'estimated_minutes',greatest(30,coalesce((
          select sum(greatest(coalesce(si.estimated_minutes_snapshot,30),1))
          from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),30)),
        'workers',coalesce((
          select jsonb_agg(jsonb_build_object(
            'employee_id',x.employee_id,
            'employee_name',x.employee_name,
            'worker_role',x.worker_role,
            'contribution_percent',x.contribution_percent
          ) order by x.employee_name,x.worker_role)
          from (
            select distinct w.employee_id,e.name employee_name,w.worker_role,w.contribution_percent
            from public.visit_service_items si
            join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
            join public.employees e on e.id=w.employee_id
            where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
          ) x
        ),'[]'::jsonb),
        'employees',coalesce((
          select string_agg(distinct e.name,'、')
          from public.visit_service_items si
          join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
          join public.employees e on e.id=w.employee_id
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),'待分配'),
        'service_total',coalesce((
          select sum(coalesce(si.line_total,0)) from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),0),
        'product_total',coalesce((
          select sum(coalesce(pi.line_total,0)) from public.visit_product_items pi
          where pi.visit_id=v.id and pi.organization_id=p_organization_id and pi.store_id=p_store_id and pi.status='active'
        ),0),
        'total_amount',coalesce((
          select p.grand_total from public.payments p
          where p.visit_id=v.id and p.organization_id=p_organization_id and p.store_id=p_store_id
          order by p.paid_at desc nulls last,p.id desc limit 1
        ),
          coalesce((select sum(coalesce(si.line_total,0)) from public.visit_service_items si where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'),0)
          + coalesce((select sum(coalesce(pi.line_total,0)) from public.visit_product_items pi where pi.visit_id=v.id and pi.organization_id=p_organization_id and pi.store_id=p_store_id and pi.status='active'),0)
        ),
        'payment_status',coalesce((
          select p.status from public.payments p
          where p.visit_id=v.id and p.organization_id=p_organization_id and p.store_id=p_store_id
          order by p.paid_at desc nulls last,p.id desc limit 1
        ),'unpaid')
      ) order by coalesce(v.scheduled_at,v.created_at),v.id)
      from public.visits v
      where v.organization_id=p_organization_id
        and v.store_id=p_store_id
        and ((coalesce(v.scheduled_at,v.created_at) at time zone 'Asia/Kuala_Lumpur')::date=p_board_date)
        and (
          p_can_see_all
          or exists(
            select 1
            from public.visit_service_items si
            join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
            where si.visit_id=v.id and si.organization_id=p_organization_id and w.employee_id=p_employee_id
          )
        )
    ), '[]'::jsonb)
  ) into v_result;
  return v_result;
end;
$$;
revoke all on function public.v1344_board_snapshot_internal(uuid,uuid,uuid,boolean,date) from public;

create or replace function public.v1344_owner_service_board(p_store_id uuid,p_board_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_org uuid;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id and s.status='active';
  if v_org is null or not public.can_access_store(p_store_id) then raise exception '门店权限无效。'; end if;
  return public.v1344_board_snapshot_internal(v_org,p_store_id,null,true,coalesce(p_board_date,(now() at time zone 'Asia/Kuala_Lumpur')::date));
end;
$$;
revoke all on function public.v1344_owner_service_board(uuid,date) from public;
grant execute on function public.v1344_owner_service_board(uuid,date) to authenticated;

create or replace function public.v1344_employee_service_board(p_session_token text,p_board_date date)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_all boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_all:=v_role in ('manager','receptionist');
  return public.v1344_board_snapshot_internal(v_org,v_store,v_e,v_all,coalesce(p_board_date,(now() at time zone 'Asia/Kuala_Lumpur')::date));
end;
$$;
revoke all on function public.v1344_employee_service_board(text,date) from public;
grant execute on function public.v1344_employee_service_board(text,date) to anon,authenticated;

create or replace function public.v1344_employee_visit_detail(p_session_token text,p_visit_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_all boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_all:=v_role in ('manager','receptionist');

  if not exists(
    select 1 from public.visits v
    where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store
      and (v_all or exists(
        select 1 from public.visit_service_items si
        join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
        where si.visit_id=v.id and w.employee_id=v_e
      ))
  ) then raise exception '你没有权限查看这笔订单。'; end if;

  return jsonb_build_object(
    'visit',(select to_jsonb(v) from public.visits v where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store),
    'recipients',coalesce((select jsonb_agg(to_jsonb(r) order by case when r.recipient_type='primary' then 0 else 1 end,r.id) from public.visit_recipients r where r.organization_id=v_org and r.visit_id=p_visit_id),'[]'::jsonb),
    'items',coalesce((select jsonb_agg(jsonb_build_object(
      'id',si.id,'recipient_id',si.recipient_id,'service_id',si.service_id,
      'service_name_snapshot',si.service_name_snapshot,'service_category_snapshot',si.service_category_snapshot,
      'unit_price',si.unit_price,'quantity',si.quantity,'line_total',si.line_total,
      'estimated_minutes_snapshot',si.estimated_minutes_snapshot,'status',si.status,
      'assigned_to_me',exists(select 1 from public.visit_service_workers wm where wm.service_item_id=si.id and wm.employee_id=v_e and wm.status='active'),
      'signed_by_me',exists(select 1 from public.visit_service_signoffs sg where sg.service_item_id=si.id and sg.employee_id=v_e),
      'workers',coalesce((select jsonb_agg(jsonb_build_object('employee_id',w.employee_id,'employee_name',e.name,'worker_role',w.worker_role,'contribution_percent',w.contribution_percent) order by e.name) from public.visit_service_workers w join public.employees e on e.id=w.employee_id where w.service_item_id=si.id and w.status='active'),'[]'::jsonb)
    ) order by si.id) from public.visit_service_items si where si.organization_id=v_org and si.visit_id=p_visit_id and si.status<>'cancelled'),'[]'::jsonb),
    'product_items',coalesce((select jsonb_agg(to_jsonb(pi) order by pi.id) from public.visit_product_items pi where pi.organization_id=v_org and pi.store_id=v_store and pi.visit_id=p_visit_id and pi.status='active'),'[]'::jsonb),
    'payments',coalesce((select jsonb_agg(to_jsonb(p) order by p.paid_at desc nulls last,p.id desc) from public.payments p where p.organization_id=v_org and p.store_id=v_store and p.visit_id=p_visit_id),'[]'::jsonb)
  );
end;
$$;
revoke all on function public.v1344_employee_visit_detail(text,uuid) from public;
grant execute on function public.v1344_employee_visit_detail(text,uuid) to anon,authenticated;

create or replace function public.v1344_employee_set_availability(p_session_token text,p_status text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_status text:=lower(coalesce(p_status,''));
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  if v_status not in ('available','break') then raise exception '员工状态无效。'; end if;
  update public.employees set availability_status=v_status,updated_at=now() where id=v_e and organization_id=v_org and employment_status='active';
  return jsonb_build_object('ok',true,'availability_status',v_status);
end;
$$;
revoke all on function public.v1344_employee_set_availability(text,text) from public;
grant execute on function public.v1344_employee_set_availability(text,text) to anon,authenticated;

create or replace function public.v1344_employee_set_visit_status(p_session_token text,p_visit_id uuid,p_status text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_status text:=lower(coalesce(p_status,'')); v_all boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_all:=v_role in ('manager','receptionist');

  if v_all then
    if v_status not in ('arrived','waiting','in_service','paused','ready_for_checkout','cancelled','no_show') then raise exception '不允许的订单状态。'; end if;
  else
    if v_status not in ('waiting','in_service','paused','ready_for_checkout') then raise exception '这个员工角色不能执行该状态操作。'; end if;
    if not exists(
      select 1 from public.visit_service_items si
      join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
      where si.visit_id=p_visit_id and si.organization_id=v_org and w.employee_id=v_e
    ) then raise exception '你不是这笔订单的负责员工。'; end if;
  end if;

  update public.visits set
    status=v_status,
    arrived_at=case when v_status='arrived' then coalesce(arrived_at,now()) else arrived_at end,
    started_at=case when v_status='in_service' then coalesce(started_at,now()) else started_at end,
    service_completed_at=case when v_status='ready_for_checkout' then coalesce(service_completed_at,now()) else service_completed_at end,
    updated_at=now()
  where id=p_visit_id and organization_id=v_org and store_id=v_store;
  if not found then raise exception '找不到订单。'; end if;
  return jsonb_build_object('ok',true,'status',v_status);
end;
$$;
revoke all on function public.v1344_employee_set_visit_status(text,uuid,text) from public;
grant execute on function public.v1344_employee_set_visit_status(text,uuid,text) to anon,authenticated;



-- RLS for the add-on product table. Employee sessions still go through SECURITY DEFINER RPCs;
-- authenticated Owner/Manager REST access is tenant-scoped.
alter table public.visit_product_items enable row level security;
drop policy if exists v135_visit_product_items_read on public.visit_product_items;
create policy v135_visit_product_items_read on public.visit_product_items for select to authenticated
  using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v135_visit_product_items_manage on public.visit_product_items;
create policy v135_visit_product_items_manage on public.visit_product_items for all to authenticated
  using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
  with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('compat_patch_version','13.4.5.1'),
 ('service_board_version','13.4.5.1'),
 ('runtime_contract_version','13.4.5.1')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.4.5.1 RUNTIME CONTRACT READY' as result,
  to_regprocedure('public.v1344_owner_service_board(uuid,date)') is not null as owner_service_board_rpc_ok,
  to_regprocedure('public.v1344_employee_service_board(text,date)') is not null as employee_service_board_rpc_ok,
  to_regclass('public.visit_product_items') is not null as visit_product_items_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='visit_service_items' and column_name='service_category_snapshot') as service_category_snapshot_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='employee_stores' and column_name='updated_at') as employee_store_timestamp_ok;


-- =============================================================================
-- SalonOS v13.4.6 · COMPLETE RPC CONTRACT ADAPTER
-- This block intentionally does not replace the existing checkout/inventory business
-- functions. It creates stable v13.4.6 adapters around the historical signatures so
-- PHP and Supabase cannot drift merely because argument names changed between builds.
-- =============================================================================

begin;
set local statement_timeout='0';

create or replace function public.v1346_checkout_visit(
  p_visit_id uuid,
  p_payments jsonb,
  p_discount_total numeric default 0,
  p_tax_total numeric default 0,
  p_membership_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_names text[];
  v_out jsonb;
begin
  select p.proargnames into v_names
  from pg_proc p
  join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='public' and p.proname='checkout_visit' and p.pronargs=5
  order by p.oid desc
  limit 1;

  if v_names is null then
    raise exception 'SalonOS 基础结账 RPC checkout_visit 不存在。请先安装完整 Supabase Core Schema。';
  end if;

  if v_names @> array['target_visit_id','payment_lines','discount_amount','tax_amount','loyalty_membership_id']::text[] then
    execute 'select coalesce(to_jsonb(x),''{}''::jsonb) from public.checkout_visit(discount_amount => $1, loyalty_membership_id => $2, payment_lines => $3, target_visit_id => $4, tax_amount => $5) x limit 1'
      into v_out
      using coalesce(p_discount_total,0),p_membership_id,coalesce(p_payments,'[]'::jsonb),p_visit_id,coalesce(p_tax_total,0);
  elsif v_names @> array['p_visit_id','p_payments','p_discount_total','p_tax_total','p_membership_id']::text[] then
    execute 'select coalesce(to_jsonb(x),''{}''::jsonb) from public.checkout_visit(p_visit_id => $1, p_payments => $2, p_discount_total => $3, p_tax_total => $4, p_membership_id => $5) x limit 1'
      into v_out
      using p_visit_id,coalesce(p_payments,'[]'::jsonb),coalesce(p_discount_total,0),coalesce(p_tax_total,0),p_membership_id;
  else
    raise exception 'checkout_visit 参数签名与 SalonOS v13.4.6 不兼容：%',array_to_string(v_names,', ');
  end if;

  return coalesce(v_out,jsonb_build_object('ok',true));
end;
$$;
revoke all on function public.v1346_checkout_visit(uuid,jsonb,numeric,numeric,uuid) from public;
grant execute on function public.v1346_checkout_visit(uuid,jsonb,numeric,numeric,uuid) to authenticated;

create or replace function public.v1346_add_product_stock(
  p_product_id uuid,
  p_quantity_delta numeric,
  p_unit_cost numeric default 0,
  p_notes text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_names text[];
  v_out jsonb;
begin
  select p.proargnames into v_names
  from pg_proc p
  join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='public' and p.proname='add_product_stock' and p.pronargs=4
  order by p.oid desc
  limit 1;

  if v_names is null then
    raise exception 'SalonOS 基础库存 RPC add_product_stock 不存在。请先安装完整 Supabase Core Schema。';
  end if;

  if v_names @> array['product_id','quantity_delta','unit_cost','notes']::text[] then
    execute 'select coalesce(to_jsonb(x),''{}''::jsonb) from public.add_product_stock(product_id => $1, quantity_delta => $2, unit_cost => $3, notes => $4) x limit 1'
      into v_out using p_product_id,p_quantity_delta,coalesce(p_unit_cost,0),p_notes;
  elsif v_names @> array['p_product_id','p_quantity_delta','p_unit_cost','p_notes']::text[] then
    execute 'select coalesce(to_jsonb(x),''{}''::jsonb) from public.add_product_stock(p_product_id => $1, p_quantity_delta => $2, p_unit_cost => $3, p_notes => $4) x limit 1'
      into v_out using p_product_id,p_quantity_delta,coalesce(p_unit_cost,0),p_notes;
  else
    -- Most historical stock functions kept the same positional order even when the
    -- argument names differed. Only use this fallback when exactly one 4-arg overload exists.
    if (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='add_product_stock' and p.pronargs=4)=1 then
      execute 'select coalesce(to_jsonb(x),''{}''::jsonb) from public.add_product_stock($1,$2,$3,$4) x limit 1'
        into v_out using p_product_id,p_quantity_delta,coalesce(p_unit_cost,0),p_notes;
    else
      raise exception 'add_product_stock 参数签名与 SalonOS v13.4.6 不兼容：%',array_to_string(v_names,', ');
    end if;
  end if;

  return coalesce(v_out,jsonb_build_object('ok',true));
end;
$$;
revoke all on function public.v1346_add_product_stock(uuid,numeric,numeric,text) from public;
grant execute on function public.v1346_add_product_stock(uuid,numeric,numeric,text) to authenticated;

create or replace function public.v1346_runtime_contract_status()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_required text[]:=array[
    'check_owner_trusted_device','creator_cancel_activation_code','creator_dashboard_snapshot','creator_renew_subscription',
    'creator_revoke_device','creator_set_subscription_status','employee_phone_login','employee_session_context','employee_session_logout',
    'redeem_branch_activation_code','redeem_device_activation_code','redeem_owner_activation_code_v2','validate_owner_activation_code',
    'v132_inventory_snapshot','v1331_employee_confirm_visit','v1331_employee_customer_search','v1331_employee_order_review',
    'v1344_employee_service_board','v1344_employee_set_availability','v1344_employee_set_visit_status','v1344_employee_visit_detail',
    'v1344_owner_service_board','v134_employee_create_visit','v13_employee_api','v13_employee_directory','v13_healthcheck',
    'v13_owner_dashboard','v13_save_employee','v13_toggle_employee','v1346_checkout_visit','v1346_add_product_stock'
  ];
  v_missing text[]:=array[]::text[];
  v_name text;
  v_checkout_names text[];
  v_stock_names text[];
  v_checkout_ok boolean:=false;
  v_stock_ok boolean:=false;
begin
  foreach v_name in array v_required loop
    if not exists(
      select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname=v_name
    ) then v_missing:=array_append(v_missing,v_name); end if;
  end loop;

  select p.proargnames into v_checkout_names
  from pg_proc p join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='public' and p.proname='checkout_visit' and p.pronargs=5
  order by p.oid desc limit 1;
  v_checkout_ok:=v_checkout_names is not null and (
    v_checkout_names @> array['target_visit_id','payment_lines','discount_amount','tax_amount','loyalty_membership_id']::text[]
    or v_checkout_names @> array['p_visit_id','p_payments','p_discount_total','p_tax_total','p_membership_id']::text[]
  );

  select p.proargnames into v_stock_names
  from pg_proc p join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='public' and p.proname='add_product_stock' and p.pronargs=4
  order by p.oid desc limit 1;
  v_stock_ok:=v_stock_names is not null;

  return jsonb_build_object(
    'version','13.4.6',
    'ok',cardinality(v_missing)=0 and v_checkout_ok and v_stock_ok,
    'required_rpc_count',cardinality(v_required),
    'present_rpc_count',cardinality(v_required)-cardinality(v_missing),
    'missing_rpc_names',to_jsonb(v_missing),
    'checkout_signature_ok',v_checkout_ok,
    'checkout_argument_names',to_jsonb(coalesce(v_checkout_names,array[]::text[])),
    'stock_signature_ok',v_stock_ok,
    'stock_argument_names',to_jsonb(coalesce(v_stock_names,array[]::text[])),
    'service_board_rpc_ok',exists(select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='v1344_owner_service_board'),
    'schema_cache_marker','v13.4.6'
  );
end;
$$;
revoke all on function public.v1346_runtime_contract_status() from public;
grant execute on function public.v1346_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('compat_patch_version','13.4.6'),
 ('service_board_version','13.4.6'),
 ('runtime_contract_version','13.4.6'),
 ('rpc_contract_version','13.4.6')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.4.6 RPC CONTRACT COMPLETE' as result,
  to_regprocedure('public.v1346_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null as checkout_adapter_ok,
  to_regprocedure('public.v1346_add_product_stock(uuid,numeric,numeric,text)') is not null as stock_adapter_ok,
  to_regprocedure('public.v1346_runtime_contract_status()') is not null as contract_probe_ok,
  (select (public.v1346_runtime_contract_status()->>'checkout_signature_ok')::boolean) as legacy_checkout_signature_ok,
  (select (public.v1346_runtime_contract_status()->>'stock_signature_ok')::boolean) as legacy_stock_signature_ok;

-- SalonOS v13.4.7 · CHECKOUT PAYMENT-LINE CONTRACT FIX
-- Additive / idempotent. Does NOT delete business data.
-- Fixes legacy checkout_visit builds that read payment JSON keys such as "method"
-- while the current PHP sends "payment_method". The adapter now sends BOTH names
-- (plus other safe aliases) so payment_items.payment_method can never become NULL
-- merely because two SalonOS schema generations used different JSON field names.

begin;
set local statement_timeout='0';

create or replace function public.v1347_normalize_payment_lines(
  p_payments jsonb,
  p_membership_id uuid default null
)
returns jsonb
language plpgsql
immutable
set search_path=public
as $$
declare
  v_line jsonb;
  v_out jsonb := '[]'::jsonb;
  v_method text;
  v_amount numeric;
  v_reference text;
  v_notes text;
begin
  if p_payments is null then p_payments := '[]'::jsonb; end if;
  if jsonb_typeof(p_payments) <> 'array' then
    raise exception '付款资料格式无效：payments 必须是 JSON array。';
  end if;

  for v_line in select value from jsonb_array_elements(p_payments)
  loop
    if jsonb_typeof(v_line) <> 'object' then
      raise exception '付款资料格式无效：每个 payment line 必须是 JSON object。';
    end if;

    v_method := lower(trim(coalesce(
      nullif(v_line->>'payment_method',''),
      nullif(v_line->>'method',''),
      nullif(v_line->>'payment_type',''),
      nullif(v_line->>'type',''),
      nullif(v_line->>'payment_channel',''),
      nullif(v_line->>'payment_method_code',''),
      nullif(v_line->>'method_code',''),
      nullif(v_line->>'mode',''),
      nullif(v_line->>'channel',''),
      nullif(v_line->>'paymentMethod',''),
      'cash'
    )));

    v_method := case v_method
      when 'e-wallet' then 'ewallet'
      when 'e_wallet' then 'ewallet'
      when 'bank transfer' then 'bank_transfer'
      when 'bank-transfer' then 'bank_transfer'
      when 'banktransfer' then 'bank_transfer'
      when 'wallet' then 'member_wallet'
      when 'member wallet' then 'member_wallet'
      else v_method
    end;

    if v_method not in ('cash','card','ewallet','bank_transfer','member_wallet','other') then
      raise exception '不支持的付款方式：%',v_method;
    end if;

    v_amount := coalesce(
      nullif(v_line->>'amount','')::numeric,
      nullif(v_line->>'paid_amount','')::numeric,
      nullif(v_line->>'payment_amount','')::numeric,
      nullif(v_line->>'value','')::numeric,
      0
    );
    if v_amount <= 0 then raise exception '每一笔付款金额必须大于 0。'; end if;

    v_reference := nullif(trim(coalesce(
      v_line->>'reference_number',
      v_line->>'reference',
      v_line->>'ref',
      v_line->>'transaction_reference',
      ''
    )), '');
    v_notes := nullif(trim(coalesce(v_line->>'notes',v_line->>'note','')), '');

    -- Keep the caller payload, then add a compatibility envelope containing every
    -- payment-key spelling used by historical SalonOS checkout functions.
    v_line := v_line || jsonb_build_object(
      'payment_method',v_method,
      'method',v_method,
      'payment_type',v_method,
      'type',v_method,
      'payment_channel',v_method,
      'payment_method_code',v_method,
      'method_code',v_method,
      'mode',v_method,
      'channel',v_method,
      'paymentMethod',v_method,
      'amount',round(v_amount,2),
      'paid_amount',round(v_amount,2),
      'payment_amount',round(v_amount,2),
      'paid',round(v_amount,2),
      'total',round(v_amount,2),
      'line_total',round(v_amount,2),
      'value',round(v_amount,2),
      'reference_number',v_reference,
      'reference',v_reference,
      'ref',v_reference,
      'transaction_reference',v_reference,
      'notes',v_notes,
      'note',v_notes,
      'membership_id',p_membership_id,
      'loyalty_membership_id',p_membership_id
    );

    v_out := v_out || jsonb_build_array(jsonb_strip_nulls(v_line));
  end loop;

  if jsonb_array_length(v_out)=0 then raise exception '请至少提供一笔付款。'; end if;
  return v_out;
end;
$$;

revoke all on function public.v1347_normalize_payment_lines(jsonb,uuid) from public;
grant execute on function public.v1347_normalize_payment_lines(jsonb,uuid) to authenticated;

create or replace function public.v1347_checkout_visit(
  p_visit_id uuid,
  p_payments jsonb,
  p_discount_total numeric default 0,
  p_tax_total numeric default 0,
  p_membership_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_payments jsonb;
  v_out jsonb;
begin
  if p_visit_id is null then raise exception '订单 ID 不能为空。'; end if;

  v_payments := public.v1347_normalize_payment_lines(p_payments,p_membership_id);

  if to_regprocedure('public.v1346_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is null then
    raise exception 'SalonOS v13.4.6 基础结账 Adapter 尚未安装。请运行 v13.4.7 累计补丁。';
  end if;

  v_out := public.v1346_checkout_visit(
    p_visit_id,
    v_payments,
    greatest(coalesce(p_discount_total,0),0),
    greatest(coalesce(p_tax_total,0),0),
    p_membership_id
  );

  return coalesce(v_out,jsonb_build_object('ok',true));
end;
$$;

revoke all on function public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid) from public;
grant execute on function public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid) to authenticated;

create or replace function public.v1347_runtime_contract_status()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_base jsonb := '{}'::jsonb;
  v_sample jsonb;
  v_line jsonb;
  v_alias_ok boolean := false;
begin
  if to_regprocedure('public.v1346_runtime_contract_status()') is not null then
    begin
      v_base := public.v1346_runtime_contract_status();
    exception when others then
      v_base := jsonb_build_object('ok',false,'base_contract_error',sqlerrm);
    end;
  end if;

  v_sample := public.v1347_normalize_payment_lines('[{"payment_method":"cash","amount":1}]'::jsonb,null);
  v_line := v_sample->0;
  v_alias_ok := coalesce(v_line->>'payment_method','')='cash'
    and coalesce(v_line->>'method','')='cash'
    and coalesce(v_line->>'payment_type','')='cash'
    and coalesce(v_line->>'type','')='cash'
    and coalesce((v_line->>'amount')::numeric,0)=1;

  return jsonb_build_object(
    'version','13.4.7',
    'ok',coalesce((v_base->>'ok')::boolean,false)
      and to_regprocedure('public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null
      and v_alias_ok,
    'base_contract',v_base,
    'required_rpc_count',coalesce((v_base->>'required_rpc_count')::integer,0),
    'present_rpc_count',coalesce((v_base->>'present_rpc_count')::integer,0),
    'missing_rpc_names',coalesce(v_base->'missing_rpc_names','[]'::jsonb),
    'checkout_signature_ok',coalesce((v_base->>'checkout_signature_ok')::boolean,false),
    'stock_signature_ok',coalesce((v_base->>'stock_signature_ok')::boolean,false),
    'checkout_adapter_ok',to_regprocedure('public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null,
    'payment_alias_contract_ok',v_alias_ok,
    'payment_items_table_ok',to_regclass('public.payment_items') is not null,
    'payment_method_column_ok',exists(
      select 1 from information_schema.columns
      where table_schema='public' and table_name='payment_items' and column_name='payment_method'
    ),
    'schema_cache_marker','v13.4.7'
  );
end;
$$;

revoke all on function public.v1347_runtime_contract_status() from public;
grant execute on function public.v1347_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('compat_patch_version','13.4.7'),
 ('service_board_version','13.4.7'),
 ('runtime_contract_version','13.4.7'),
 ('rpc_contract_version','13.4.7'),
 ('checkout_payment_contract_version','13.4.7')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.4.7 CHECKOUT PAYMENT CONTRACT READY' as result,
  to_regprocedure('public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null as checkout_adapter_ok,
  to_regprocedure('public.v1347_normalize_payment_lines(jsonb,uuid)') is not null as payment_normalizer_ok,
  (public.v1347_runtime_contract_status()->>'payment_alias_contract_ok')::boolean as payment_alias_contract_ok,
  (public.v1347_runtime_contract_status()->>'payment_method_column_ok')::boolean as payment_method_column_ok;
-- SalonOS v13.5.0 · Product / UX Contract
-- Additive + idempotent. Does NOT delete historical business records.
-- Run after v13.4.7, or use RUN_ONCE_V13_5_0_CUMULATIVE_RUNTIME.sql instead.

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- 1) Media stays in Supabase Storage, not inside PostgreSQL rows.
--    PHP compresses photos to WebP when GD is available; bucket enforces <= 2 MB.
-- -----------------------------------------------------------------------------
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('salonos-media','salonos-media',true,2097152,array['image/jpeg','image/png','image/webp']::text[])
on conflict (id) do update set
  public=excluded.public,
  file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists salonos_media_member_read on storage.objects;
create policy salonos_media_member_read on storage.objects
for select to authenticated
using (
  bucket_id='salonos-media'
  and exists (
    select 1 from public.organization_members om
    where om.user_id=auth.uid() and om.status='active'
      and om.organization_id::text=split_part(storage.objects.name,'/',1)
  )
);

drop policy if exists salonos_media_manager_insert on storage.objects;
create policy salonos_media_manager_insert on storage.objects
for insert to authenticated
with check (
  bucket_id='salonos-media'
  and exists (
    select 1 from public.organization_members om
    where om.user_id=auth.uid() and om.status='active'
      and om.role in ('owner','manager')
      and om.organization_id::text=split_part(storage.objects.name,'/',1)
  )
);

drop policy if exists salonos_media_manager_update on storage.objects;
create policy salonos_media_manager_update on storage.objects
for update to authenticated
using (
  bucket_id='salonos-media'
  and exists (
    select 1 from public.organization_members om
    where om.user_id=auth.uid() and om.status='active'
      and om.role in ('owner','manager')
      and om.organization_id::text=split_part(storage.objects.name,'/',1)
  )
)
with check (
  bucket_id='salonos-media'
  and exists (
    select 1 from public.organization_members om
    where om.user_id=auth.uid() and om.status='active'
      and om.role in ('owner','manager')
      and om.organization_id::text=split_part(storage.objects.name,'/',1)
  )
);

-- -----------------------------------------------------------------------------
-- 2) Service categories are real folder-like records.
-- -----------------------------------------------------------------------------
create table if not exists public.service_categories (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  name text not null,
  description text,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(organization_id,store_id,name)
);
create index if not exists service_categories_store_idx on public.service_categories(organization_id,store_id,active,sort_order,name);

alter table public.service_categories enable row level security;
drop policy if exists v1350_service_categories_read on public.service_categories;
create policy v1350_service_categories_read on public.service_categories for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1350_service_categories_manage on public.service_categories;
create policy v1350_service_categories_manage on public.service_categories for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

alter table public.services add column if not exists category_id uuid;
do $$
begin
  if not exists(select 1 from pg_constraint where conname='services_category_id_fkey') then
    alter table public.services add constraint services_category_id_fkey
      foreign key(category_id) references public.service_categories(id) on delete set null;
  end if;
end $$;

-- Backfill a category record for every current service category. Blank categories become 未分类.
insert into public.service_categories(organization_id,store_id,name,description,sort_order,active)
select distinct s.organization_id,s.store_id,coalesce(nullif(trim(s.category),''),'未分类'),null,0,true
from public.services s
where s.organization_id is not null and s.store_id is not null
on conflict(organization_id,store_id,name) do nothing;

update public.services s
set category_id=c.id,
    category=c.name,
    updated_at=now()
from public.service_categories c
where c.organization_id=s.organization_id and c.store_id=s.store_id
  and c.name=coalesce(nullif(trim(s.category),''),'未分类')
  and (s.category_id is distinct from c.id or s.category is distinct from c.name);

-- -----------------------------------------------------------------------------
-- 3) Inventory unit + Storage URL. The quantity truth remains the stock ledger.
-- -----------------------------------------------------------------------------
alter table public.products add column if not exists stock_unit text not null default 'pcs';

-- -----------------------------------------------------------------------------
-- 4) KPI: employee-first assignment supports per-employee target/bonus/status.
-- -----------------------------------------------------------------------------
do $$
declare r record;
begin
  for r in
    select conname from pg_constraint
    where conrelid='public.v13_kpi_rules'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%metric_type%'
  loop
    execute format('alter table public.v13_kpi_rules drop constraint %I',r.conname);
  end loop;
end $$;
alter table public.v13_kpi_rules add constraint v1350_kpi_metric_type_check
  check (metric_type in ('service_performance','product_sales','total_sales','service_count','customer_count','avg_ticket','requested_count','training_completion','manual'));

alter table public.v13_kpi_assignments
  add column if not exists target_value numeric,
  add column if not exists bonus_amount numeric,
  add column if not exists status text not null default 'active',
  add column if not exists updated_at timestamptz not null default now();

do $$
declare r record;
begin
  for r in
    select conname from pg_constraint
    where conrelid='public.v13_kpi_assignments'::regclass and contype='c'
      and pg_get_constraintdef(oid) ilike '%status%'
  loop
    execute format('alter table public.v13_kpi_assignments drop constraint %I',r.conname);
  end loop;
end $$;
alter table public.v13_kpi_assignments add constraint v1350_kpi_assignment_status_check
  check (status in ('active','achieved','reviewed','bonus_paid','archived'));

-- -----------------------------------------------------------------------------
-- 5) Training: category + role targeting + media metadata.
-- -----------------------------------------------------------------------------
alter table public.v13_training_courses
  add column if not exists category text not null default '通用培训',
  add column if not exists target_roles jsonb not null default '[]'::jsonb,
  add column if not exists content_url text,
  add column if not exists cover_image_path text,
  add column if not exists estimated_minutes integer not null default 0,
  add column if not exists version_label text,
  add column if not exists required boolean not null default false,
  add column if not exists publication_status text not null default 'published';

alter table public.v13_training_progress add column if not exists started_at timestamptz;

-- -----------------------------------------------------------------------------
-- 6) Commission tier editor compatibility + monthly manual override.
-- -----------------------------------------------------------------------------
alter table public.service_commission_tiers add column if not exists updated_at timestamptz not null default now();

create table if not exists public.v13_monthly_commission_overrides (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  employee_id uuid not null,
  month_start date not null,
  override_rate numeric,
  final_commission_amount numeric,
  notes text,
  locked boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(organization_id,store_id,employee_id,month_start),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  foreign key (organization_id,employee_id) references public.employees(organization_id,id) on delete cascade,
  check (override_rate is null or (override_rate>=0 and override_rate<=100)),
  check (final_commission_amount is null or final_commission_amount>=0)
);
create index if not exists v1350_monthly_commission_idx on public.v13_monthly_commission_overrides(organization_id,store_id,month_start,employee_id);
alter table public.v13_monthly_commission_overrides enable row level security;
drop policy if exists v1350_monthly_commission_read on public.v13_monthly_commission_overrides;
create policy v1350_monthly_commission_read on public.v13_monthly_commission_overrides for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1350_monthly_commission_manage on public.v13_monthly_commission_overrides;
create policy v1350_monthly_commission_manage on public.v13_monthly_commission_overrides for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

-- -----------------------------------------------------------------------------
-- 7) Employee catalog includes category_id so New Order can select category first.
-- -----------------------------------------------------------------------------
create or replace function public.v1350_employee_catalog(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_store uuid; v_result jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  return jsonb_build_object(
    'context',v_ctx,
    'categories',coalesce((select jsonb_agg(jsonb_build_object('id',c.id,'name',c.name,'sort_order',c.sort_order) order by c.sort_order,c.name)
      from public.service_categories c where c.organization_id=v_org and c.store_id=v_store and c.active),'[]'::jsonb),
    'services',coalesce((select jsonb_agg(jsonb_build_object(
        'id',s.id,'category_id',s.category_id,'category',coalesce(c.name,s.category,'未分类'),'name',s.name,
        'default_price',s.default_price,'estimated_minutes',s.estimated_minutes,'allows_assistant',s.allows_assistant
      ) order by coalesce(c.sort_order,9999),coalesce(c.name,s.category,'未分类'),s.name)
      from public.services s left join public.service_categories c on c.id=s.category_id and c.organization_id=s.organization_id
      where s.organization_id=v_org and s.store_id=v_store and s.active),'[]'::jsonb),
    'employees',coalesce((select jsonb_agg(jsonb_build_object(
        'id',e.id,'name',e.name,'position',e.position,'app_role',e.app_role,'availability_status',coalesce(e.availability_status,case when e.is_on_duty then 'available' else 'off_duty' end)
      ) order by e.name)
      from public.employees e join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
      where e.organization_id=v_org and es.store_id=v_store and es.status='active' and e.employment_status='active'),'[]'::jsonb)
  );
end;
$$;
revoke all on function public.v1350_employee_catalog(text) from public;
grant execute on function public.v1350_employee_catalog(text) to anon,authenticated;

-- -----------------------------------------------------------------------------
-- 8) Employee training is role-filtered. Employees cannot see irrelevant courses.
-- -----------------------------------------------------------------------------
create or replace function public.v1350_employee_training(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_e uuid; v_org uuid; v_role text; v_result jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  select coalesce(jsonb_agg(jsonb_build_object(
      'id',c.id,'title',c.title,'category',c.category,'description',c.description,'content',c.content,'content_url',c.content_url,
      'cover_image_path',c.cover_image_path,'estimated_minutes',c.estimated_minutes,'version_label',c.version_label,'required',c.required,
      'progress_percent',coalesce(p.progress_percent,0),'status',coalesce(p.status,'not_started'),'started_at',p.started_at,'completed_at',p.completed_at
    ) order by c.category,c.required desc,c.created_at desc),'[]'::jsonb)
  into v_result
  from public.v13_training_courses c
  left join public.v13_training_progress p on p.course_id=c.id and p.employee_id=v_e and p.organization_id=v_org
  where c.organization_id=v_org and c.active and c.publication_status='published'
    and (jsonb_array_length(coalesce(c.target_roles,'[]'::jsonb))=0 or coalesce(c.target_roles,'[]'::jsonb) ? v_role);
  return coalesce(v_result,'[]'::jsonb);
end;
$$;
revoke all on function public.v1350_employee_training(text) from public;
grant execute on function public.v1350_employee_training(text) to anon,authenticated;

create or replace function public.v1350_employee_training_progress(p_session_token text,p_course_id uuid,p_progress_percent integer)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_e uuid; v_org uuid; v_role text; v_pct integer:=greatest(0,least(100,coalesce(p_progress_percent,0)));
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  if not exists(
    select 1 from public.v13_training_courses c
    where c.id=p_course_id and c.organization_id=v_org and c.active and c.publication_status='published'
      and (jsonb_array_length(coalesce(c.target_roles,'[]'::jsonb))=0 or coalesce(c.target_roles,'[]'::jsonb) ? v_role)
  ) then raise exception '这个课程不适用于当前员工。'; end if;
  insert into public.v13_training_progress(organization_id,employee_id,course_id,progress_percent,status,started_at,completed_at,updated_at)
  values(v_org,v_e,p_course_id,v_pct,
    case when v_pct>=100 then 'completed' when v_pct>0 then 'in_progress' else 'not_started' end,
    case when v_pct>0 then now() else null end,
    case when v_pct>=100 then now() else null end,now())
  on conflict(employee_id,course_id) do update set
    progress_percent=excluded.progress_percent,
    status=excluded.status,
    started_at=coalesce(v13_training_progress.started_at,excluded.started_at),
    completed_at=case when excluded.progress_percent>=100 then coalesce(v13_training_progress.completed_at,now()) else null end,
    updated_at=now();
  return jsonb_build_object('ok',true,'course_id',p_course_id,'progress_percent',v_pct);
end;
$$;
revoke all on function public.v1350_employee_training_progress(text,uuid,integer) from public;
grant execute on function public.v1350_employee_training_progress(text,uuid,integer) to anon,authenticated;

-- -----------------------------------------------------------------------------
-- 9) Runtime contract: detect drift before normal pages expose raw database errors.
-- -----------------------------------------------------------------------------
create or replace function public.v1350_runtime_contract_status()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_missing text[]:=array[]::text[];
  v_ok boolean;
begin
  if to_regprocedure('public.v1347_runtime_contract_status()') is null then v_missing:=array_append(v_missing,'v1347_runtime_contract_status'); end if;
  if to_regprocedure('public.v1350_employee_catalog(text)') is null then v_missing:=array_append(v_missing,'v1350_employee_catalog'); end if;
  if to_regprocedure('public.v1350_employee_training(text)') is null then v_missing:=array_append(v_missing,'v1350_employee_training'); end if;
  if to_regprocedure('public.v1350_employee_training_progress(text,uuid,integer)') is null then v_missing:=array_append(v_missing,'v1350_employee_training_progress'); end if;
  if to_regclass('public.service_categories') is null then v_missing:=array_append(v_missing,'service_categories'); end if;
  if to_regclass('public.v13_monthly_commission_overrides') is null then v_missing:=array_append(v_missing,'v13_monthly_commission_overrides'); end if;
  if not exists(select 1 from information_schema.columns where table_schema='public' and table_name='services' and column_name='category_id') then v_missing:=array_append(v_missing,'services.category_id'); end if;
  if not exists(select 1 from information_schema.columns where table_schema='public' and table_name='products' and column_name='stock_unit') then v_missing:=array_append(v_missing,'products.stock_unit'); end if;
  if not exists(select 1 from information_schema.columns where table_schema='public' and table_name='v13_training_courses' and column_name='target_roles') then v_missing:=array_append(v_missing,'training.target_roles'); end if;
  if not exists(select 1 from storage.buckets where id='salonos-media') then v_missing:=array_append(v_missing,'storage.salonos-media'); end if;
  v_ok:=cardinality(v_missing)=0;
  return jsonb_build_object('version','13.5.0','ok',v_ok,'missing_contracts',to_jsonb(v_missing),'storage_bucket','salonos-media','schema_cache_marker','v13.5.0');
end;
$$;
revoke all on function public.v1350_runtime_contract_status() from public;
grant execute on function public.v1350_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('compat_patch_version','13.5.0'),
 ('runtime_contract_version','13.5.0'),
 ('product_ux_contract_version','13.5.0'),
 ('service_category_version','13.5.0'),
 ('training_role_version','13.5.0'),
 ('commission_editor_version','13.5.0')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.5.0 PRODUCT UX CONTRACT READY' as result,
  to_regprocedure('public.v1350_runtime_contract_status()') is not null as runtime_contract_ok,
  to_regclass('public.service_categories') is not null as service_categories_ok,
  to_regclass('public.v13_monthly_commission_overrides') is not null as monthly_commission_override_ok,
  exists(select 1 from storage.buckets where id='salonos-media') as media_storage_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='services' and column_name='category_id') as service_category_fk_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='products' and column_name='stock_unit') as inventory_unit_ok,
  (public.v1350_runtime_contract_status()->>'ok')::boolean as contract_complete;
-- SalonOS v13.5.2 · employee custom-role permission bridge
-- Additive/idempotent. Does not delete business data.

begin;
set local statement_timeout='0';

create or replace function public.v1352_employee_role_permissions(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_h text:=encode(digest(coalesce(p_session_token,''),'sha256'),'hex');
  v_ls public.employee_login_sessions%rowtype;
  v_role text;
  v_permissions jsonb:='{}'::jsonb;
  v_org uuid;
begin
  select ls.* into v_ls
  from public.employee_login_sessions ls
  where ls.token_hash=v_h and ls.revoked_at is null and ls.expires_at>now()
  limit 1;
  if v_ls.id is null then raise exception '员工登录已过期，请重新输入手机号。'; end if;

  select e.organization_id,e.app_role into v_org,v_role
  from public.employees e
  join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id and es.store_id=v_ls.store_id and es.status='active'
  join public.stores s on s.id=v_ls.store_id and s.organization_id=e.organization_id and s.status='active'
  join public.organizations o on o.id=e.organization_id and o.status in ('active','trialing')
  where e.id=v_ls.employee_id and e.employment_status='active'
  limit 1;

  if v_org is null then
    update public.employee_login_sessions set revoked_at=coalesce(revoked_at,now()) where id=v_ls.id;
    raise exception '员工账号已停用或门店不可使用。';
  end if;

  select coalesce(s.role_permissions,'{}'::jsonb) into v_permissions
  from public.v13_organization_settings s
  where s.organization_id=v_org
  limit 1;

  update public.employee_login_sessions set last_seen_at=now() where id=v_ls.id;
  return jsonb_build_object(
    'organization_id',v_org,
    'employee_role',coalesce(v_role,'staff'),
    'role_permissions',coalesce(v_permissions,'{}'::jsonb)
  );
end;
$$;

revoke all on function public.v1352_employee_role_permissions(text) from public;
grant execute on function public.v1352_employee_role_permissions(text) to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values('permission_contract_version','13.5.2')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.5.2 PERMISSION ROLE FIX READY' as result,
  to_regprocedure('public.v1352_employee_role_permissions(text)') is not null as employee_role_permissions_rpc_ok;
-- SalonOS v13.5.3 · Customer Search + Product Categories + Member Retail Purchase
-- Additive / idempotent. Does not delete historical business data.
-- Run after v13.5.2 (or run the cumulative v13.5.3 SQL shipped with the full package).

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- 1) Real folder-like product categories shared by Inventory / Retail / Bundles.
-- -----------------------------------------------------------------------------
create table if not exists public.v13_product_categories (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  name text not null,
  description text,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(organization_id,store_id,name)
);
create index if not exists v1353_product_categories_store_idx
  on public.v13_product_categories(organization_id,store_id,active,sort_order,name);

alter table public.v13_product_categories enable row level security;
drop policy if exists v1353_product_categories_read on public.v13_product_categories;
create policy v1353_product_categories_read on public.v13_product_categories for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1353_product_categories_manage on public.v13_product_categories;
create policy v1353_product_categories_manage on public.v13_product_categories for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

alter table public.products add column if not exists category_id uuid;
do $$ begin
  if not exists(select 1 from pg_constraint where conname='products_v1353_category_id_fkey') then
    alter table public.products add constraint products_v1353_category_id_fkey
      foreign key(category_id) references public.v13_product_categories(id) on delete set null;
  end if;
end $$;

alter table public.v13_product_bundles
  add column if not exists category_id uuid,
  add column if not exists category text;
do $$ begin
  if not exists(select 1 from pg_constraint where conname='v13_product_bundles_v1353_category_id_fkey') then
    alter table public.v13_product_bundles add constraint v13_product_bundles_v1353_category_id_fkey
      foreign key(category_id) references public.v13_product_categories(id) on delete set null;
  end if;
end $$;

insert into public.v13_product_categories(organization_id,store_id,name,description,sort_order,active)
select distinct p.organization_id,p.store_id,coalesce(nullif(trim(p.category),''),'未分类'),null,0,true
from public.products p
where p.organization_id is not null and p.store_id is not null
on conflict(organization_id,store_id,name) do nothing;

update public.products p
set category_id=c.id,
    category=c.name,
    updated_at=now()
from public.v13_product_categories c
where c.organization_id=p.organization_id and c.store_id=p.store_id
  and c.name=coalesce(nullif(trim(p.category),''),'未分类')
  and (p.category_id is distinct from c.id or p.category is distinct from c.name);

-- Existing bundles may not have had a category; keep them in a real 未分类 folder.
insert into public.v13_product_categories(organization_id,store_id,name,description,sort_order,active)
select distinct b.organization_id,b.store_id,'未分类',null,0,true
from public.v13_product_bundles b
where b.organization_id is not null and b.store_id is not null
on conflict(organization_id,store_id,name) do nothing;

update public.v13_product_bundles b
set category_id=c.id,
    category=coalesce(nullif(trim(b.category),''),c.name),
    updated_at=now()
from public.v13_product_categories c
where c.organization_id=b.organization_id and c.store_id=b.store_id
  and c.name=coalesce(nullif(trim(b.category),''),'未分类')
  and (b.category_id is distinct from c.id or b.category is null or trim(b.category)='');

-- -----------------------------------------------------------------------------
-- 2) Direct member retail sales. This is separate from salon service checkout.
--    It supports stored-value wallet + one external method (Cash/Card/E-Wallet).
-- -----------------------------------------------------------------------------
create table if not exists public.v13_member_product_sales (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  membership_id uuid not null references public.memberships(id) on delete restrict,
  customer_id uuid not null references public.customers(id) on delete restrict,
  total_amount numeric(12,2) not null check(total_amount>=0),
  wallet_amount numeric(12,2) not null default 0 check(wallet_amount>=0),
  external_amount numeric(12,2) not null default 0 check(external_amount>=0),
  external_method text not null default 'cash' check(external_method in ('cash','card','ewallet','none')),
  status text not null default 'paid' check(status in ('paid','voided','refunded')),
  created_by_user_id uuid,
  created_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists v1353_member_product_sales_customer_idx
  on public.v13_member_product_sales(organization_id,store_id,customer_id,created_at desc);

create table if not exists public.v13_member_product_sale_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  sale_id uuid not null references public.v13_member_product_sales(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  product_name_snapshot text not null,
  category_snapshot text,
  sku_snapshot text,
  image_path_snapshot text,
  unit_price numeric(12,2) not null check(unit_price>=0),
  quantity numeric(12,3) not null check(quantity>0),
  line_total numeric(12,2) not null check(line_total>=0),
  created_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists v1353_member_product_sale_items_sale_idx
  on public.v13_member_product_sale_items(sale_id);

alter table public.v13_member_product_sales enable row level security;
alter table public.v13_member_product_sale_items enable row level security;
drop policy if exists v1353_member_product_sales_read on public.v13_member_product_sales;
create policy v1353_member_product_sales_read on public.v13_member_product_sales for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1353_member_product_sale_items_read on public.v13_member_product_sale_items;
create policy v1353_member_product_sale_items_read on public.v13_member_product_sale_items for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));

-- Sale writes go through this RPC to keep payment, wallet, points and inventory together.
create or replace function public.v1353_member_product_purchase(
  p_store_id uuid,
  p_membership_id uuid,
  p_product_id uuid,
  p_quantity numeric,
  p_wallet_amount numeric default 0,
  p_external_method text default 'cash',
  p_external_amount numeric default 0
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_org uuid;
  v_customer uuid;
  v_product public.products%rowtype;
  v_qty numeric:=greatest(coalesce(p_quantity,1),0.001);
  v_total numeric(12,2);
  v_wallet numeric(12,2):=greatest(coalesce(p_wallet_amount,0),0);
  v_external numeric(12,2):=greatest(coalesce(p_external_amount,0),0);
  v_method text:=lower(trim(coalesce(p_external_method,'cash')));
  v_balance numeric:=0;
  v_sale uuid:=gen_random_uuid();
  v_stock numeric:=0;
  v_remaining numeric:=0;
begin
  select m.organization_id,m.customer_id into v_org,v_customer
  from public.memberships m
  where m.id=p_membership_id and m.status='active'
  limit 1;
  if v_org is null then raise exception '会员不存在或已停用。'; end if;
  if not public.has_organization_role(v_org,array['owner','manager','receptionist']) then
    raise exception '你没有进行会员产品销售的权限。';
  end if;
  if not public.can_access_store(p_store_id) then raise exception '你没有当前分行权限。'; end if;

  select * into v_product from public.products p
  where p.id=p_product_id and p.organization_id=v_org and p.store_id=p_store_id
    and p.active=true and p.retail_enabled=true
  limit 1;
  if v_product.id is null then raise exception '销售产品不存在、已停用或不属于当前分行。'; end if;

  v_total:=round(greatest(coalesce(v_product.sale_price,0),0)*v_qty,2);
  if v_total<=0 then raise exception '产品售价必须大于 RM 0。'; end if;

  if coalesce(v_product.stock_enabled,false) then
    select coalesce(sum(m.quantity_delta),0) into v_stock
    from public.inventory_stock_movements m
    where m.organization_id=v_org and m.store_id=p_store_id and m.product_id=v_product.id;
    if v_stock < v_qty then raise exception '库存不足，目前可售 %。',v_stock; end if;
  end if;

  select coalesce(sum(w.amount_delta),0) into v_balance
  from public.member_wallet_ledger w
  where w.organization_id=v_org and w.membership_id=p_membership_id;
  if v_wallet>v_balance then raise exception '会员储值余额不足，目前余额 RM %。',round(v_balance,2); end if;
  if v_wallet>v_total then v_wallet:=v_total; end if;
  v_remaining:=round(v_total-v_wallet,2);
  if v_method not in ('cash','card','ewallet','none') then raise exception '付款方式无效。'; end if;
  if v_remaining=0 then v_method:='none'; v_external:=0; end if;
  if v_remaining>0 and v_method='none' then raise exception '还有 RM % 未付款，请选择现金、银行卡或电子钱包。',v_remaining; end if;
  if abs(v_external-v_remaining)>0.01 then raise exception '付款金额不正确，应付剩余 RM %。',v_remaining; end if;

  insert into public.v13_member_product_sales(
    id,organization_id,store_id,membership_id,customer_id,total_amount,wallet_amount,external_amount,external_method,status,created_by_user_id
  ) values(
    v_sale,v_org,p_store_id,p_membership_id,v_customer,v_total,v_wallet,v_external,v_method,'paid',auth.uid()
  );

  insert into public.v13_member_product_sale_items(
    organization_id,store_id,sale_id,product_id,product_name_snapshot,category_snapshot,sku_snapshot,image_path_snapshot,unit_price,quantity,line_total
  ) values(
    v_org,p_store_id,v_sale,v_product.id,v_product.name,v_product.category,v_product.sku,v_product.image_path,
    coalesce(v_product.sale_price,0),v_qty,v_total
  );

  if v_wallet>0 then
    insert into public.member_wallet_ledger(
      organization_id,membership_id,amount_delta,transaction_type,notes
    ) values(
      v_org,p_membership_id,-v_wallet,'payment','会员储值购买产品 · '||v_product.name||' · Sale '||v_sale::text
    );
  end if;

  -- Experience / points follow the current SalonOS 1 RM = 1 XP = 1 point base rule.
  insert into public.member_loyalty_ledger(
    organization_id,membership_id,experience_delta,points_delta,transaction_type,notes
  ) values(
    v_org,p_membership_id,v_total,v_total,'purchase','产品消费 · '||v_product.name||' · Sale '||v_sale::text
  );

  if coalesce(v_product.stock_enabled,false) then
    perform public.v1346_add_product_stock(
      v_product.id,
      -v_qty,
      greatest(coalesce(v_product.cost_price,0),0),
      'Member retail sale '||v_sale::text||' · '||v_product.name
    );
  end if;

  return jsonb_build_object(
    'success',true,'sale_id',v_sale,'customer_id',v_customer,'membership_id',p_membership_id,
    'product_name',v_product.name,'quantity',v_qty,'total_amount',v_total,
    'wallet_used',v_wallet,'external_amount',v_external,'external_method',v_method,
    'wallet_balance',round(v_balance-v_wallet,2)
  );
end;
$$;
revoke all on function public.v1353_member_product_purchase(uuid,uuid,uuid,numeric,numeric,text,numeric) from public;
grant execute on function public.v1353_member_product_purchase(uuid,uuid,uuid,numeric,numeric,text,numeric) to authenticated;

-- Employee-session product search for Manager / Front Desk checkout UI. No cost fields are exposed.
create or replace function public.v1353_employee_product_search(
  p_session_token text,
  p_query text default '',
  p_category_id uuid default null
)
returns jsonb
language plpgsql
stable
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb;
  v_org uuid;
  v_store uuid;
  v_q text:=lower(trim(coalesce(p_query,'')));
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id',p.id,'type','single','type_text','销售产品','name',p.name,
      'code',coalesce(nullif(p.sku,''),p.barcode,''),'sku',coalesce(p.sku,''),'barcode',coalesce(p.barcode,''),
      'category_id',p.category_id,'category',coalesce(c.name,p.category,'未分类'),'description',coalesce(p.purpose,''),
      'price',coalesce(p.sale_price,0),'price_text','RM '||to_char(coalesce(p.sale_price,0),'FM999999990.00'),
      'image_url',coalesce(p.image_path,''),
      'available',case when coalesce(p.stock_enabled,false) then greatest(0,coalesce((select sum(m.quantity_delta) from public.inventory_stock_movements m where m.organization_id=v_org and m.store_id=v_store and m.product_id=p.id),0)) else 999999 end,
      'stock_text',case when coalesce(p.stock_enabled,false) then to_char(greatest(0,coalesce((select sum(m.quantity_delta) from public.inventory_stock_movements m where m.organization_id=v_org and m.store_id=v_store and m.product_id=p.id),0)),'FM999999990.##')||' '||coalesce(p.stock_unit,'pcs') else '不追踪库存' end
    ) order by coalesce(c.sort_order,9999),coalesce(c.name,p.category,'未分类'),p.name)
    from public.products p
    left join public.v13_product_categories c on c.id=p.category_id and c.organization_id=p.organization_id and c.store_id=p.store_id
    where p.organization_id=v_org and p.store_id=v_store and p.active and coalesce(p.retail_enabled,false)
      and (p_category_id is null or p.category_id=p_category_id)
      and (v_q='' or lower(coalesce(p.name,'')||' '||coalesce(p.sku,'')||' '||coalesce(p.barcode,'')||' '||coalesce(c.name,p.category,'')) like '%'||v_q||'%')
  ),'[]'::jsonb);
end;
$$;
revoke all on function public.v1353_employee_product_search(text,text,uuid) from public;
grant execute on function public.v1353_employee_product_search(text,text,uuid) to anon,authenticated;

create or replace function public.v1353_runtime_contract_status()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'version','13.5.3',
    'ok',
      to_regclass('public.v13_product_categories') is not null
      and to_regclass('public.v13_member_product_sales') is not null
      and to_regclass('public.v13_member_product_sale_items') is not null
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='products' and column_name='category_id')
      and to_regprocedure('public.v1353_member_product_purchase(uuid,uuid,uuid,numeric,numeric,text,numeric)') is not null
      and to_regprocedure('public.v1353_employee_product_search(text,text,uuid)') is not null,
    'product_categories_ok',to_regclass('public.v13_product_categories') is not null,
    'product_category_column_ok',exists(select 1 from information_schema.columns where table_schema='public' and table_name='products' and column_name='category_id'),
    'member_product_sales_ok',to_regclass('public.v13_member_product_sales') is not null,
    'member_product_purchase_rpc_ok',to_regprocedure('public.v1353_member_product_purchase(uuid,uuid,uuid,numeric,numeric,text,numeric)') is not null,
    'employee_product_search_rpc_ok',to_regprocedure('public.v1353_employee_product_search(text,text,uuid)') is not null
  );
$$;
revoke all on function public.v1353_runtime_contract_status() from public;
grant execute on function public.v1353_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('runtime_contract_version','13.5.3'),
 ('product_ux_version','13.5.3'),
 ('customer_search_version','13.5.3'),
 ('member_retail_version','13.5.3')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.5.3 PRODUCT / MEMBER / SEARCH READY' as result,
  to_regclass('public.v13_product_categories') is not null as product_categories_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='products' and column_name='category_id') as product_category_column_ok,
  to_regclass('public.v13_member_product_sales') is not null as member_product_sales_ok,
  to_regprocedure('public.v1353_member_product_purchase(uuid,uuid,uuid,numeric,numeric,text,numeric)') is not null as member_product_purchase_rpc_ok,
  to_regprocedure('public.v1353_employee_product_search(text,text,uuid)') is not null as employee_product_search_rpc_ok;

-- SalonOS v13.5.4 · Employee Workspace / Permission / Performance Contract
-- Additive + idempotent. Does not delete historical business records.
-- Run after v13.5.3, or use the cumulative v13.5.4 SQL shipped with the full package.

begin;
set local statement_timeout='0';
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('salonos-media','salonos-media',true,2097152,array['image/jpeg','image/png','image/webp']::text[])
on conflict (id) do update set public=excluded.public,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

-- 1) Employee avatar metadata + short-lived anonymous Storage upload tickets.
alter table public.employees add column if not exists avatar_path text;

create table if not exists public.v13_employee_avatar_upload_tokens (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists v1354_avatar_ticket_employee_idx
  on public.v13_employee_avatar_upload_tokens(employee_id,expires_at desc);
alter table public.v13_employee_avatar_upload_tokens enable row level security;

create or replace function public.v1354_employee_permission_allowed(p_session_token text,p_permission text)
returns boolean
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_role text; v_permissions jsonb:='{}'::jsonb; v_list jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_role:=coalesce(nullif(v_ctx->>'employee_role',''),'staff');
  select coalesce(s.role_permissions,'{}'::jsonb) into v_permissions
  from public.v13_organization_settings s where s.organization_id=v_org limit 1;
  v_list:=v_permissions->v_role;
  if jsonb_typeof(v_list)='array' then
    return v_list ? '*' or v_list ? p_permission;
  end if;
  -- Safe defaults mirror the PHP defaults when a role has never been customized.
  if v_role='manager' then return true; end if;
  if v_role='receptionist' then
    return p_permission = any(array['dashboard.view','visits.create','orders.view','performance.view','training.view','orders.manage','customers.view','customers.manage','checkout.manage','products.view','appointments.manage']);
  end if;
  if v_role='accountant' then
    return p_permission = any(array['dashboard.view','order_history.view','analytics.view','performance.view','commission.view','reports.export']);
  end if;
  if v_role='stylist' then
    return p_permission = any(array['dashboard.view','visits.create','orders.view','performance.view','training.view','customers.view','products.view']);
  end if;
  return p_permission = any(array['dashboard.view','visits.create','orders.view','performance.view','training.view']);
end;
$$;
revoke all on function public.v1354_employee_permission_allowed(text,text) from public;
grant execute on function public.v1354_employee_permission_allowed(text,text) to anon,authenticated;

create or replace function public.v1354_avatar_upload_path_allowed(p_name text)
returns boolean
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_org_text text:=split_part(coalesce(p_name,''),'/',1);
  v_folder text:=split_part(coalesce(p_name,''),'/',2);
  v_employee_text text:=split_part(coalesce(p_name,''),'/',3);
  v_file text:=split_part(coalesce(p_name,''),'/',4);
  v_token text:=split_part(v_file,'.',1);
  v_org uuid; v_employee uuid;
begin
  if v_folder<>'employee-avatars' then return false; end if;
  if v_org_text !~* '^[0-9a-f-]{36}$' or v_employee_text !~* '^[0-9a-f-]{36}$' or v_token !~ '^[0-9a-f]{32,128}$' then return false; end if;
  v_org:=v_org_text::uuid; v_employee:=v_employee_text::uuid;
  return exists(
    select 1 from public.v13_employee_avatar_upload_tokens t
    where t.organization_id=v_org and t.employee_id=v_employee
      and t.token_hash=encode(digest(v_token,'sha256'),'hex')
      and t.used_at is null and t.expires_at>now()
  );
end;
$$;
revoke all on function public.v1354_avatar_upload_path_allowed(text) from public;
grant execute on function public.v1354_avatar_upload_path_allowed(text) to anon,authenticated;

-- Employee custom sessions are not Supabase Auth users. This narrowly-scoped Storage
-- policy allows only a short-lived random avatar path that was issued by a validated
-- employee session. Other anonymous uploads remain denied.
drop policy if exists salonos_employee_avatar_ticket_insert on storage.objects;
create policy salonos_employee_avatar_ticket_insert on storage.objects
for insert to anon,authenticated
with check (
  bucket_id='salonos-media'
  and public.v1354_avatar_upload_path_allowed(name)
);

create or replace function public.v1354_employee_avatar_upload_ticket(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_store uuid; v_employee uuid; v_token text:=encode(gen_random_bytes(24),'hex');
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid; v_employee:=(v_ctx->>'employee_id')::uuid;
  delete from public.v13_employee_avatar_upload_tokens where expires_at<now()-interval '1 hour' or used_at is not null;
  insert into public.v13_employee_avatar_upload_tokens(organization_id,store_id,employee_id,token_hash,expires_at)
  values(v_org,v_store,v_employee,encode(digest(v_token,'sha256'),'hex'),now()+interval '5 minutes');
  return jsonb_build_object('organization_id',v_org,'store_id',v_store,'employee_id',v_employee,'upload_token',v_token,'expires_at',now()+interval '5 minutes');
end;
$$;
revoke all on function public.v1354_employee_avatar_upload_ticket(text) from public;
grant execute on function public.v1354_employee_avatar_upload_ticket(text) to anon,authenticated;

create or replace function public.v1354_employee_set_avatar(p_session_token text,p_avatar_path text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_employee uuid; v_token text; v_prefix text;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid; v_employee:=(v_ctx->>'employee_id')::uuid;
  v_prefix:=v_org::text||'/employee-avatars/'||v_employee::text||'/';
  if p_avatar_path is null or left(p_avatar_path,length(v_prefix))<>v_prefix then raise exception '头像路径无效。'; end if;
  v_token:=split_part(split_part(p_avatar_path,'/',4),'.',1);
  if not exists(select 1 from public.v13_employee_avatar_upload_tokens t where t.organization_id=v_org and t.employee_id=v_employee and t.token_hash=encode(digest(v_token,'sha256'),'hex') and t.used_at is null and t.expires_at>now()) then
    raise exception '头像上传授权已过期，请重新选择图片。';
  end if;
  update public.employees set avatar_path=p_avatar_path,updated_at=now() where id=v_employee and organization_id=v_org;
  update public.v13_employee_avatar_upload_tokens set used_at=now() where organization_id=v_org and employee_id=v_employee and token_hash=encode(digest(v_token,'sha256'),'hex') and used_at is null;
  return jsonb_build_object('avatar_path',p_avatar_path);
end;
$$;
revoke all on function public.v1354_employee_set_avatar(text,text) from public;
grant execute on function public.v1354_employee_set_avatar(text,text) to anon,authenticated;

create or replace function public.v1354_employee_profile(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_employee uuid; v_org uuid;
begin
  v_ctx:=public.employee_session_context(p_session_token); v_employee:=(v_ctx->>'employee_id')::uuid; v_org:=(v_ctx->>'organization_id')::uuid;
  return (select jsonb_build_object('employee_id',e.id,'name',e.name,'position',e.position,'employee_code',e.employee_code,'app_role',e.app_role,'avatar_path',e.avatar_path)
          from public.employees e where e.id=v_employee and e.organization_id=v_org);
end;
$$;
revoke all on function public.v1354_employee_profile(text) from public;
grant execute on function public.v1354_employee_profile(text) to anon,authenticated;

-- Existing employee login/session RPCs remain untouched to avoid dependency churn.
-- PHP fetches avatar_path from v1354_employee_profile after validating the existing session.

-- Owner directory now exposes avatar_path too (salary remains in this owner-only RPC).
create or replace function public.v13_employee_directory(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_org uuid; v_result jsonb;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id;
  if v_org is null then raise exception '找不到门店。'; end if;
  if not public.has_organization_role(v_org,array['owner','manager','accountant']) then raise exception '你没有查看员工资料的权限。'; end if;
  if not public.can_access_store(p_store_id) then raise exception '你没有这个门店的权限。'; end if;
  select coalesce(jsonb_agg(x order by (x->>'employment_status'='active') desc,x->>'name'),'[]'::jsonb) into v_result from (
    select jsonb_build_object(
      'id',e.id,'employee_code',e.employee_code,'name',e.name,'phone',e.phone,'position',e.position,'avatar_path',e.avatar_path,
      'age',e.age,'gender',e.gender,'skill_tags',e.skill_tags,'app_role',e.app_role,
      'base_salary',coalesce(ec.base_salary,0),'joined_at',e.joined_at,'employment_status',e.employment_status,
      'is_on_duty',e.is_on_duty,'availability_status',e.availability_status,'last_login_at',e.last_login_at,
      'order_count',(select count(distinct vv.id) from public.visit_service_workers w join public.visit_service_items si on si.id=w.service_item_id and si.organization_id=e.organization_id join public.visits vv on vv.id=si.visit_id and vv.organization_id=e.organization_id where w.employee_id=e.id and w.organization_id=e.organization_id)
    ) x
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id and es.store_id=p_store_id and es.status='active'
    left join public.employee_compensation ec on ec.employee_id=e.id and ec.organization_id=e.organization_id
    where e.organization_id=v_org
  ) q;
  return v_result;
end;
$$;
revoke all on function public.v13_employee_directory(uuid) from public;
grant execute on function public.v13_employee_directory(uuid) to authenticated;

-- 2) Employee customer/member directory. Access is checked against the live role matrix.
create or replace function public.v1354_employee_customer_directory(p_session_token text,p_query text default '',p_customer_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_store uuid; v_q text:=lower(trim(coalesce(p_query,''))); v_rows jsonb; v_detail jsonb; v_manage boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token); v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid;
  if not public.v1354_employee_permission_allowed(p_session_token,'customers.view') and not public.v1354_employee_permission_allowed(p_session_token,'customers.manage') then
    raise exception '你的职位没有查看顾客与会员的权限。';
  end if;
  v_manage:=public.v1354_employee_permission_allowed(p_session_token,'customers.manage');
  select coalesce(jsonb_agg(x order by x->>'name'),'[]'::jsonb) into v_rows from (
    select jsonb_build_object(
      'id',c.id,'name',c.name,'phone',c.phone,'gender',c.gender,'birth_date',c.birth_date,'ethnicity',c.ethnicity,'email',c.email,
      'identification_number',c.identification_number,'address',c.address,'acquisition_platform',c.acquisition_platform,'notes',c.notes,
      'member_number',m.member_number,'level_number',ml.level_number,'level_name',ml.name,
      'visit_count',(select count(distinct vr.visit_id) from public.visit_recipients vr join public.visits vv on vv.id=vr.visit_id and vv.organization_id=vr.organization_id where vr.organization_id=v_org and vr.customer_id=c.id and vv.store_id=v_store)
    ) x
    from public.customers c
    left join public.memberships m on m.customer_id=c.id and m.organization_id=c.organization_id and m.status='active'
    left join public.membership_levels ml on ml.id=m.current_level_id and ml.organization_id=c.organization_id
    where c.organization_id=v_org and c.store_id=v_store
      and (v_q='' or lower(coalesce(c.name,'')||' '||coalesce(c.phone,'')||' '||coalesce(m.member_number,'')||' '||coalesce(c.email,'')||' '||coalesce(c.identification_number,'')) like '%'||v_q||'%')
    order by c.created_at desc limit 120
  ) q;
  if p_customer_id is not null then
    select jsonb_build_object(
      'customer',jsonb_build_object('id',c.id,'name',c.name,'phone',c.phone,'gender',c.gender,'birth_date',c.birth_date,'ethnicity',c.ethnicity,'email',c.email,'identification_number',c.identification_number,'address',c.address,'acquisition_platform',c.acquisition_platform,'notes',c.notes),
      'membership',case when m.id is null then null else jsonb_build_object('id',m.id,'member_number',m.member_number,'joined_at',m.joined_at,'level_number',ml.level_number,'level_name',ml.name) end,
      'wallet_balance',coalesce((select sum(w.amount_delta) from public.member_wallet_ledger w where w.organization_id=v_org and w.membership_id=m.id),0),
      'points',coalesce((select sum(l.points_delta) from public.member_loyalty_ledger l where l.organization_id=v_org and l.membership_id=m.id),0),
      'experience',coalesce((select sum(l.experience_delta) from public.member_loyalty_ledger l where l.organization_id=v_org and l.membership_id=m.id),0),
      'visit_count',(select count(distinct vr.visit_id) from public.visit_recipients vr join public.visits vv on vv.id=vr.visit_id and vv.organization_id=vr.organization_id where vr.organization_id=v_org and vr.customer_id=c.id and vv.store_id=v_store)
    ) into v_detail
    from public.customers c
    left join public.memberships m on m.customer_id=c.id and m.organization_id=c.organization_id and m.status='active'
    left join public.membership_levels ml on ml.id=m.current_level_id and ml.organization_id=c.organization_id
    where c.id=p_customer_id and c.organization_id=v_org and c.store_id=v_store limit 1;
  end if;
  return jsonb_build_object('customers',coalesce(v_rows,'[]'::jsonb),'detail',v_detail,'can_manage',v_manage);
end;
$$;
revoke all on function public.v1354_employee_customer_directory(text,text,uuid) from public;
grant execute on function public.v1354_employee_customer_directory(text,text,uuid) to anon,authenticated;

-- 3) Shared performance board core: day / month / year, ranking + employee drill-down.
create or replace function public.v1354_performance_board_core(p_organization_id uuid,p_store_id uuid,p_period text,p_anchor date,p_employee_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_period text:=case when p_period in ('day','month','year') then p_period else 'month' end;
  v_anchor date:=coalesce(p_anchor,current_date); v_start timestamptz; v_end timestamptz; v_label text; v_ranking jsonb; v_detail jsonb; v_activity jsonb;
begin
  if v_period='day' then
    v_start=(v_anchor::timestamp at time zone 'Asia/Kuala_Lumpur'); v_end=((v_anchor+1)::timestamp at time zone 'Asia/Kuala_Lumpur'); v_label=to_char(v_anchor,'DD/MM/YYYY');
  elsif v_period='year' then
    v_start=(date_trunc('year',v_anchor::timestamp) at time zone 'Asia/Kuala_Lumpur'); v_end=(date_trunc('year',v_anchor::timestamp)+interval '1 year') at time zone 'Asia/Kuala_Lumpur'; v_label=to_char(v_anchor,'YYYY');
  else
    v_start=(date_trunc('month',v_anchor::timestamp) at time zone 'Asia/Kuala_Lumpur'); v_end=(date_trunc('month',v_anchor::timestamp)+interval '1 month') at time zone 'Asia/Kuala_Lumpur'; v_label=to_char(v_anchor,'MM/YYYY');
  end if;
  with staff as (
    select e.id,e.name,e.position,e.employee_code,e.avatar_path,e.employment_status
    from public.employees e join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
    where e.organization_id=p_organization_id and es.store_id=p_store_id and es.status='active'
  ), service as (
    select sp.employee_id,coalesce(sum(sp.performance_amount),0)::numeric service_performance,count(*)::int service_count,count(distinct sp.visit_id)::int customer_count
    from public.service_performance_ledger sp join public.payments p on p.id=sp.payment_id and p.organization_id=sp.organization_id and p.store_id=sp.store_id
    where sp.organization_id=p_organization_id and sp.store_id=p_store_id and p.status='paid' and p.paid_at>=v_start and p.paid_at<v_end group by sp.employee_id
  ), visit_stats as (
    select sp.employee_id,count(distinct case when v.visit_type='appointment' then sp.visit_id end)::int appointments,count(distinct case when v.visit_type<>'appointment' then sp.visit_id end)::int walkins
    from public.service_performance_ledger sp join public.payments p on p.id=sp.payment_id and p.status='paid' join public.visits v on v.id=sp.visit_id and v.organization_id=sp.organization_id
    where sp.organization_id=p_organization_id and sp.store_id=p_store_id and p.paid_at>=v_start and p.paid_at<v_end group by sp.employee_id
  ), product as (
    select pi.salesperson_employee_id employee_id,coalesce(sum(pi.line_total),0)::numeric product_sales,coalesce(sum(pi.quantity),0)::numeric product_units
    from public.visit_product_items pi
    where pi.organization_id=p_organization_id and pi.store_id=p_store_id and pi.status='active' and pi.salesperson_employee_id is not null
      and exists(select 1 from public.payments pp where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end)
    group by pi.salesperson_employee_id
  ), commission as (
    select c.employee_id,coalesce(sum(c.commission_amount),0)::numeric commission_amount from public.employee_commission_ledger c
    where c.organization_id=p_organization_id and c.store_id=p_store_id and c.created_at>=v_start and c.created_at<v_end group by c.employee_id
  ), scores as (
    select s.*,coalesce(se.service_performance,0)::numeric service_performance,coalesce(pr.product_sales,0)::numeric product_sales,
      (coalesce(se.service_performance,0)+coalesce(pr.product_sales,0))::numeric total_performance,coalesce(co.commission_amount,0)::numeric commission_amount,
      coalesce(se.service_count,0)::int service_count,coalesce(se.customer_count,0)::int customer_count,coalesce(vs.appointments,0)::int appointments,coalesce(vs.walkins,0)::int walkins,coalesce(pr.product_units,0)::numeric product_units
    from staff s left join service se on se.employee_id=s.id left join product pr on pr.employee_id=s.id left join commission co on co.employee_id=s.id left join visit_stats vs on vs.employee_id=s.id
  ), ranked as (
    select row_number() over(order by total_performance desc,service_performance desc,name asc)::int rank_no,* from scores
  )
  select coalesce(jsonb_agg(jsonb_build_object('rank',rank_no,'employee_id',id,'name',name,'position',position,'employee_code',employee_code,'avatar_path',avatar_path,'employment_status',employment_status,'service_performance',service_performance,'product_sales',product_sales,'total_performance',total_performance,'commission_amount',commission_amount,'service_count',service_count,'customer_count',customer_count,'appointments',appointments,'walkins',walkins,'product_units',product_units) order by rank_no),'[]'::jsonb) into v_ranking from ranked;

  if p_employee_id is not null then
    select x into v_detail from jsonb_array_elements(v_ranking) x where x->>'employee_id'=p_employee_id::text limit 1;
    select coalesce(jsonb_agg(z.a order by z.a->>'occurred_at' desc),'[]'::jsonb) into v_activity from (
      select jsonb_build_object('type','service','label',coalesce(v.visit_number,'服务项目'),'amount',sp.performance_amount,'occurred_at',p.paid_at) a
      from public.service_performance_ledger sp join public.payments p on p.id=sp.payment_id and p.status='paid' left join public.visits v on v.id=sp.visit_id
      where sp.organization_id=p_organization_id and sp.store_id=p_store_id and sp.employee_id=p_employee_id and p.paid_at>=v_start and p.paid_at<v_end
      union all
      select jsonb_build_object('type','product','label',coalesce(pi.product_name_snapshot,'产品销售'),'amount',pi.line_total,'occurred_at',(select max(pp.paid_at) from public.payments pp where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end))
      from public.visit_product_items pi
      where pi.organization_id=p_organization_id and pi.store_id=p_store_id and pi.salesperson_employee_id=p_employee_id and pi.status='active'
        and exists(select 1 from public.payments pp where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end)
    ) z;
  end if;
  return jsonb_build_object('period',v_period,'anchor',v_anchor,'label',v_label,'range_start',v_start,'range_end',v_end,'ranking',coalesce(v_ranking,'[]'::jsonb),'detail',v_detail,'activity',coalesce(v_activity,'[]'::jsonb));
end;
$$;
revoke all on function public.v1354_performance_board_core(uuid,uuid,text,date,uuid) from public;

create or replace function public.v1354_owner_performance_board(p_store_id uuid,p_period text,p_anchor date,p_employee_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_org uuid;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id and s.status='active';
  if v_org is null then raise exception '找不到门店。'; end if;
  if not public.can_access_store(p_store_id) or not public.has_organization_role(v_org,array['owner','manager','accountant']) then raise exception '你没有查看员工业绩的权限。'; end if;
  return public.v1354_performance_board_core(v_org,p_store_id,p_period,p_anchor,p_employee_id);
end;
$$;
revoke all on function public.v1354_owner_performance_board(uuid,text,date,uuid) from public;
grant execute on function public.v1354_owner_performance_board(uuid,text,date,uuid) to authenticated;

create or replace function public.v1354_employee_performance_board(p_session_token text,p_period text,p_anchor date,p_employee_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_org uuid; v_store uuid;
begin
  v_ctx:=public.employee_session_context(p_session_token); v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid;
  if not public.v1354_employee_permission_allowed(p_session_token,'performance.view') then raise exception '你的职位没有查看员工业绩的权限。'; end if;
  return public.v1354_performance_board_core(v_org,v_store,p_period,p_anchor,p_employee_id);
end;
$$;
revoke all on function public.v1354_employee_performance_board(text,text,date,uuid) from public;
grant execute on function public.v1354_employee_performance_board(text,text,date,uuid) to anon,authenticated;

create or replace function public.v1354_runtime_contract_status()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'version','13.5.4',
    'ok',
      to_regprocedure('public.v1353_runtime_contract_status()') is not null
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='employees' and column_name='avatar_path')
      and to_regclass('public.v13_employee_avatar_upload_tokens') is not null
      and to_regprocedure('public.v1354_employee_customer_directory(text,text,uuid)') is not null
      and to_regprocedure('public.v1354_employee_performance_board(text,text,date,uuid)') is not null
      and to_regprocedure('public.v1354_owner_performance_board(uuid,text,date,uuid)') is not null
      and to_regprocedure('public.v1354_employee_avatar_upload_ticket(text)') is not null,
    'employee_avatar_column_ok',exists(select 1 from information_schema.columns where table_schema='public' and table_name='employees' and column_name='avatar_path'),
    'avatar_ticket_table_ok',to_regclass('public.v13_employee_avatar_upload_tokens') is not null,
    'employee_customer_rpc_ok',to_regprocedure('public.v1354_employee_customer_directory(text,text,uuid)') is not null,
    'employee_performance_rpc_ok',to_regprocedure('public.v1354_employee_performance_board(text,text,date,uuid)') is not null,
    'owner_performance_rpc_ok',to_regprocedure('public.v1354_owner_performance_board(uuid,text,date,uuid)') is not null,
    'employee_avatar_ticket_rpc_ok',to_regprocedure('public.v1354_employee_avatar_upload_ticket(text)') is not null
  );
$$;
revoke all on function public.v1354_runtime_contract_status() from public;
grant execute on function public.v1354_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('employee_workspace_version','13.5.4'),
 ('runtime_contract_version','13.5.4')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.5.4 EMPLOYEE WORKSPACE READY' as result,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='employees' and column_name='avatar_path') as employee_avatar_column_ok,
  to_regprocedure('public.v1354_employee_customer_directory(text,text,uuid)') is not null as employee_customer_directory_ok,
  to_regprocedure('public.v1354_employee_performance_board(text,text,date,uuid)') is not null as employee_performance_board_ok,
  to_regprocedure('public.v1354_owner_performance_board(uuid,text,date,uuid)') is not null as owner_performance_board_ok,
  to_regprocedure('public.v1354_employee_avatar_upload_ticket(text)') is not null as employee_avatar_ticket_ok;


-- ===== v13.5.5 HOTFIX =====
-- SalonOS v13.5.5 · Performance + Employee Product/Inventory Hotfix
-- Run after v13.5.4. Additive / idempotent. Does not delete business history.
-- Fixes:
--   1) v13.5.4 performance board incorrectly assumed service_performance_ledger.visit_id exists.
--      The stable relation is service_performance_ledger.payment_id -> payments.visit_id.
--   2) Employee Product & Inventory pages were routed through owner-only REST helpers.

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- 1) Employee-safe Product / Inventory read contract.
-- -----------------------------------------------------------------------------
create or replace function public.v1355_employee_product_inventory(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_store uuid;
  v_products_view boolean; v_products_manage boolean; v_inventory_manage boolean; v_can_cost boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_products_view:=public.v1354_employee_permission_allowed(p_session_token,'products.view');
  v_products_manage:=public.v1354_employee_permission_allowed(p_session_token,'products.manage');
  v_inventory_manage:=public.v1354_employee_permission_allowed(p_session_token,'inventory.manage');
  v_can_cost:=v_products_manage or v_inventory_manage;

  if not (v_products_view or v_products_manage or v_inventory_manage) then
    raise exception '你的职位没有查看产品与库存的权限。';
  end if;

  return jsonb_build_object(
    'context',v_ctx,
    'permissions',jsonb_build_object(
      'products_view',v_products_view,
      'products_manage',v_products_manage,
      'inventory_manage',v_inventory_manage,
      'cost_view',v_can_cost
    ),
    'categories',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',c.id,'organization_id',c.organization_id,'store_id',c.store_id,'name',c.name,
        'description',c.description,'sort_order',c.sort_order,'active',c.active,
        'created_at',c.created_at,'updated_at',c.updated_at
      ) order by c.sort_order,c.name)
      from public.v13_product_categories c
      where c.organization_id=v_org and c.store_id=v_store and c.active
    ),'[]'::jsonb),
    'products',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',p.id,'organization_id',p.organization_id,'store_id',p.store_id,
        'sku',p.sku,'barcode',p.barcode,'name',p.name,'category_id',p.category_id,
        'category',coalesce(c.name,p.category,'未分类'),'sale_price',p.sale_price,
        'cost_price',case when v_can_cost then p.cost_price else null end,
        'default_commission_rate',case when v_products_manage then p.default_commission_rate else null end,
        'image_path',p.image_path,'active',p.active,'reorder_level',p.reorder_level,
        'purpose',p.purpose,'retail_enabled',p.retail_enabled,'stock_enabled',p.stock_enabled,
        'stock_unit',p.stock_unit
      ) order by coalesce(c.sort_order,9999),coalesce(c.name,p.category,'未分类'),p.name)
      from public.products p
      left join public.v13_product_categories c on c.id=p.category_id and c.organization_id=p.organization_id and c.store_id=p.store_id
      where p.organization_id=v_org and p.store_id=v_store
        and (p.active or v_products_manage or v_inventory_manage)
    ),'[]'::jsonb),
    'inventory',coalesce((
      select jsonb_agg(jsonb_build_object('product_id',x.product_id,'quantity',x.quantity) order by x.product_id)
      from (
        select p.id product_id,coalesce(sum(m.quantity_delta),0)::numeric quantity
        from public.products p
        left join public.inventory_stock_movements m
          on m.organization_id=p.organization_id and m.store_id=p.store_id and m.product_id=p.id
        where p.organization_id=v_org and p.store_id=v_store
        group by p.id
      ) x
    ),'[]'::jsonb),
    'bundles',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',b.id,'organization_id',b.organization_id,'store_id',b.store_id,'name',b.name,'sku',b.sku,
        'category_id',b.category_id,'category',coalesce(c.name,b.category,'未分类'),'sale_price',b.sale_price,
        'image_path',b.image_path,'active',b.active,'created_at',b.created_at,'updated_at',b.updated_at
      ) order by b.created_at desc)
      from public.v13_product_bundles b
      left join public.v13_product_categories c on c.id=b.category_id and c.organization_id=b.organization_id and c.store_id=b.store_id
      where b.organization_id=v_org and b.store_id=v_store and (b.active or v_products_manage)
    ),'[]'::jsonb),
    'bundle_items',coalesce((
      select jsonb_agg(jsonb_build_object('id',bi.id,'bundle_id',bi.bundle_id,'product_id',bi.product_id,'quantity',bi.quantity) order by bi.bundle_id,bi.id)
      from public.v13_product_bundle_items bi
      join public.v13_product_bundles b on b.id=bi.bundle_id and b.organization_id=bi.organization_id
      where bi.organization_id=v_org and b.store_id=v_store and (b.active or v_products_manage)
    ),'[]'::jsonb)
  );
end;
$$;
revoke all on function public.v1355_employee_product_inventory(text) from public;
grant execute on function public.v1355_employee_product_inventory(text) to anon,authenticated;

-- -----------------------------------------------------------------------------
-- 2) Performance board. Never depend on service_performance_ledger.visit_id.
--    payment_id is the stable ledger key; payments.visit_id links back to the order.
-- -----------------------------------------------------------------------------
create or replace function public.v1355_performance_board_core(
  p_organization_id uuid,p_store_id uuid,p_period text,p_anchor date,p_employee_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_period text:=case when p_period in ('day','month','year') then p_period else 'month' end;
  v_anchor date:=coalesce(p_anchor,current_date);
  v_start timestamptz; v_end timestamptz; v_label text;
  v_ranking jsonb; v_detail jsonb; v_activity jsonb;
begin
  if v_period='day' then
    v_start=(v_anchor::timestamp at time zone 'Asia/Kuala_Lumpur');
    v_end=((v_anchor+1)::timestamp at time zone 'Asia/Kuala_Lumpur');
    v_label=to_char(v_anchor,'DD/MM/YYYY');
  elsif v_period='year' then
    v_start=(date_trunc('year',v_anchor::timestamp) at time zone 'Asia/Kuala_Lumpur');
    v_end=(date_trunc('year',v_anchor::timestamp)+interval '1 year') at time zone 'Asia/Kuala_Lumpur';
    v_label=to_char(v_anchor,'YYYY');
  else
    v_start=(date_trunc('month',v_anchor::timestamp) at time zone 'Asia/Kuala_Lumpur');
    v_end=(date_trunc('month',v_anchor::timestamp)+interval '1 month') at time zone 'Asia/Kuala_Lumpur';
    v_label=to_char(v_anchor,'MM/YYYY');
  end if;

  with staff as (
    select distinct e.id,e.name,e.position,e.employee_code,e.avatar_path,e.employment_status
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
    where e.organization_id=p_organization_id and es.store_id=p_store_id and es.status='active'
  ), service as (
    select sp.employee_id,
      coalesce(sum(sp.performance_amount),0)::numeric service_performance,
      count(*)::int service_count,
      count(distinct p.visit_id)::int customer_count
    from public.service_performance_ledger sp
    join public.payments p on p.id=sp.payment_id and p.organization_id=sp.organization_id and p.store_id=sp.store_id
    where sp.organization_id=p_organization_id and sp.store_id=p_store_id
      and p.status='paid' and p.paid_at>=v_start and p.paid_at<v_end
    group by sp.employee_id
  ), visit_stats as (
    select sp.employee_id,
      count(distinct case when v.visit_type='appointment' then p.visit_id end)::int appointments,
      count(distinct case when v.visit_type<>'appointment' then p.visit_id end)::int walkins
    from public.service_performance_ledger sp
    join public.payments p on p.id=sp.payment_id and p.organization_id=sp.organization_id and p.store_id=sp.store_id and p.status='paid'
    left join public.visits v on v.id=p.visit_id and v.organization_id=sp.organization_id and v.store_id=sp.store_id
    where sp.organization_id=p_organization_id and sp.store_id=p_store_id
      and p.paid_at>=v_start and p.paid_at<v_end
    group by sp.employee_id
  ), product as (
    select pi.salesperson_employee_id employee_id,
      coalesce(sum(pi.line_total),0)::numeric product_sales,
      coalesce(sum(pi.quantity),0)::numeric product_units
    from public.visit_product_items pi
    where pi.organization_id=p_organization_id and pi.store_id=p_store_id
      and pi.status='active' and pi.salesperson_employee_id is not null
      and exists(
        select 1 from public.payments pp
        where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id
          and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end
      )
    group by pi.salesperson_employee_id
  ), commission as (
    select c.employee_id,coalesce(sum(c.commission_amount),0)::numeric commission_amount
    from public.employee_commission_ledger c
    where c.organization_id=p_organization_id and c.store_id=p_store_id
      and c.created_at>=v_start and c.created_at<v_end
    group by c.employee_id
  ), scores as (
    select s.*,
      coalesce(se.service_performance,0)::numeric service_performance,
      coalesce(pr.product_sales,0)::numeric product_sales,
      (coalesce(se.service_performance,0)+coalesce(pr.product_sales,0))::numeric total_performance,
      coalesce(co.commission_amount,0)::numeric commission_amount,
      coalesce(se.service_count,0)::int service_count,
      coalesce(se.customer_count,0)::int customer_count,
      coalesce(vs.appointments,0)::int appointments,
      coalesce(vs.walkins,0)::int walkins,
      coalesce(pr.product_units,0)::numeric product_units
    from staff s
    left join service se on se.employee_id=s.id
    left join product pr on pr.employee_id=s.id
    left join commission co on co.employee_id=s.id
    left join visit_stats vs on vs.employee_id=s.id
  ), ranked as (
    select row_number() over(order by total_performance desc,service_performance desc,name asc)::int rank_no,* from scores
  )
  select coalesce(jsonb_agg(jsonb_build_object(
    'rank',rank_no,'employee_id',id,'name',name,'position',position,'employee_code',employee_code,
    'avatar_path',avatar_path,'employment_status',employment_status,
    'service_performance',service_performance,'product_sales',product_sales,'total_performance',total_performance,
    'commission_amount',commission_amount,'service_count',service_count,'customer_count',customer_count,
    'appointments',appointments,'walkins',walkins,'product_units',product_units
  ) order by rank_no),'[]'::jsonb)
  into v_ranking from ranked;

  if p_employee_id is not null then
    select x into v_detail
    from jsonb_array_elements(v_ranking) x
    where x->>'employee_id'=p_employee_id::text limit 1;

    select coalesce(jsonb_agg(z.a order by z.a->>'occurred_at' desc nulls last),'[]'::jsonb)
    into v_activity
    from (
      select jsonb_build_object(
        'type','service','label',coalesce(v.visit_number,'服务项目'),
        'amount',sp.performance_amount,'occurred_at',p.paid_at
      ) a
      from public.service_performance_ledger sp
      join public.payments p on p.id=sp.payment_id and p.organization_id=sp.organization_id and p.store_id=sp.store_id and p.status='paid'
      left join public.visits v on v.id=p.visit_id and v.organization_id=sp.organization_id and v.store_id=sp.store_id
      where sp.organization_id=p_organization_id and sp.store_id=p_store_id and sp.employee_id=p_employee_id
        and p.paid_at>=v_start and p.paid_at<v_end
      union all
      select jsonb_build_object(
        'type','product','label',coalesce(pi.product_name_snapshot,'产品销售'),'amount',pi.line_total,
        'occurred_at',(select max(pp.paid_at) from public.payments pp
          where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id
            and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end)
      )
      from public.visit_product_items pi
      where pi.organization_id=p_organization_id and pi.store_id=p_store_id
        and pi.salesperson_employee_id=p_employee_id and pi.status='active'
        and exists(select 1 from public.payments pp
          where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id
            and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end)
    ) z;
  end if;

  return jsonb_build_object(
    'period',v_period,'anchor',v_anchor,'label',v_label,'range_start',v_start,'range_end',v_end,
    'ranking',coalesce(v_ranking,'[]'::jsonb),'detail',v_detail,'activity',coalesce(v_activity,'[]'::jsonb)
  );
end;
$$;
revoke all on function public.v1355_performance_board_core(uuid,uuid,text,date,uuid) from public;

create or replace function public.v1355_owner_performance_board(
  p_store_id uuid,p_period text,p_anchor date,p_employee_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_org uuid;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id and s.status='active';
  if v_org is null then raise exception '找不到门店。'; end if;
  if not public.can_access_store(p_store_id)
     or not public.has_organization_role(v_org,array['owner','manager','accountant']) then
    raise exception '你没有查看员工业绩的权限。';
  end if;
  return public.v1355_performance_board_core(v_org,p_store_id,p_period,p_anchor,p_employee_id);
end;
$$;
revoke all on function public.v1355_owner_performance_board(uuid,text,date,uuid) from public;
grant execute on function public.v1355_owner_performance_board(uuid,text,date,uuid) to authenticated;

create or replace function public.v1355_employee_performance_board(
  p_session_token text,p_period text,p_anchor date,p_employee_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_org uuid; v_store uuid;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  if not public.v1354_employee_permission_allowed(p_session_token,'performance.view') then
    raise exception '你的职位没有查看员工业绩的权限。';
  end if;
  return public.v1355_performance_board_core(v_org,v_store,p_period,p_anchor,p_employee_id);
end;
$$;
revoke all on function public.v1355_employee_performance_board(text,text,date,uuid) from public;
grant execute on function public.v1355_employee_performance_board(text,text,date,uuid) to anon,authenticated;

-- -----------------------------------------------------------------------------
-- 3) Runtime contract checks actual compatible ledger path instead of only checking
--    whether a broken v13.5.4 function happens to exist.
-- -----------------------------------------------------------------------------
create or replace function public.v1355_runtime_contract_status()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'version','13.5.5',
    'ok',
      to_regprocedure('public.v1353_runtime_contract_status()') is not null
      and to_regprocedure('public.v1355_owner_performance_board(uuid,text,date,uuid)') is not null
      and to_regprocedure('public.v1355_employee_performance_board(text,text,date,uuid)') is not null
      and to_regprocedure('public.v1355_employee_product_inventory(text)') is not null
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='service_performance_ledger' and column_name='payment_id')
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='payments' and column_name='visit_id')
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='employees' and column_name='avatar_path'),
    'performance_payment_link_ok',
      exists(select 1 from information_schema.columns where table_schema='public' and table_name='service_performance_ledger' and column_name='payment_id')
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='payments' and column_name='visit_id'),
    'owner_performance_rpc_ok',to_regprocedure('public.v1355_owner_performance_board(uuid,text,date,uuid)') is not null,
    'employee_performance_rpc_ok',to_regprocedure('public.v1355_employee_performance_board(text,text,date,uuid)') is not null,
    'employee_product_inventory_rpc_ok',to_regprocedure('public.v1355_employee_product_inventory(text)') is not null
  );
$$;
revoke all on function public.v1355_runtime_contract_status() from public;
grant execute on function public.v1355_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('runtime_contract_version','13.5.5'),
 ('performance_contract_version','13.5.5'),
 ('employee_product_inventory_version','13.5.5')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.5.5 PERFORMANCE + EMPLOYEE PRODUCTS READY' as result,
  to_regprocedure('public.v1355_owner_performance_board(uuid,text,date,uuid)') is not null as owner_performance_ok,
  to_regprocedure('public.v1355_employee_performance_board(text,text,date,uuid)') is not null as employee_performance_ok,
  to_regprocedure('public.v1355_employee_product_inventory(text)') is not null as employee_product_inventory_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='service_performance_ledger' and column_name='payment_id') as performance_payment_id_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='payments' and column_name='visit_id') as payments_visit_id_ok;
