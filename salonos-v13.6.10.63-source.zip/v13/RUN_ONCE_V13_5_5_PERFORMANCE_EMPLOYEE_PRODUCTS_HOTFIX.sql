-- SalonOS v13.5.5 · Performance + Employee Product/Inventory Hotfix
-- Run after v13.5.4. Additive / idempotent. Does not delete business history.
-- Fixes:
--   1) v13.5.4 performance board incorrectly assumed service_performance_ledger.visit_id exists.
--      The stable relation is service_performance_ledger.payment_id -> payments.visit_id.
--   2) Employee Product & Inventory pages were routed through owner-only REST helpers.

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- 1) Employee-safe Product / Inventory read contract.
-- -----------------------------------------------------------------------------
create or replace function public.v1355_employee_product_inventory(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_org uuid; v_store uuid;
  v_products_view boolean; v_products_manage boolean; v_inventory_manage boolean; v_can_cost boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_products_view:=public.v1354_employee_permission_allowed(p_session_token,'products.view');
  v_products_manage:=public.v1354_employee_permission_allowed(p_session_token,'products.manage');
  v_inventory_manage:=public.v1354_employee_permission_allowed(p_session_token,'inventory.manage');
  v_can_cost:=v_products_manage or v_inventory_manage;

  if not (v_products_view or v_products_manage or v_inventory_manage) then
    raise exception '你的职位没有查看产品与库存的权限。';
  end if;

  return jsonb_build_object(
    'context',v_ctx,
    'permissions',jsonb_build_object(
      'products_view',v_products_view,
      'products_manage',v_products_manage,
      'inventory_manage',v_inventory_manage,
      'cost_view',v_can_cost
    ),
    'categories',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',c.id,'organization_id',c.organization_id,'store_id',c.store_id,'name',c.name,
        'description',c.description,'sort_order',c.sort_order,'active',c.active,
        'created_at',c.created_at,'updated_at',c.updated_at
      ) order by c.sort_order,c.name)
      from public.v13_product_categories c
      where c.organization_id=v_org and c.store_id=v_store and c.active
    ),'[]'::jsonb),
    'products',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',p.id,'organization_id',p.organization_id,'store_id',p.store_id,
        'sku',p.sku,'barcode',p.barcode,'name',p.name,'category_id',p.category_id,
        'category',coalesce(c.name,p.category,'未分类'),'sale_price',p.sale_price,
        'cost_price',case when v_can_cost then p.cost_price else null end,
        'default_commission_rate',case when v_products_manage then p.default_commission_rate else null end,
        'image_path',p.image_path,'active',p.active,'reorder_level',p.reorder_level,
        'purpose',p.purpose,'retail_enabled',p.retail_enabled,'stock_enabled',p.stock_enabled,
        'stock_unit',p.stock_unit
      ) order by coalesce(c.sort_order,9999),coalesce(c.name,p.category,'未分类'),p.name)
      from public.products p
      left join public.v13_product_categories c on c.id=p.category_id and c.organization_id=p.organization_id and c.store_id=p.store_id
      where p.organization_id=v_org and p.store_id=v_store
        and (p.active or v_products_manage or v_inventory_manage)
    ),'[]'::jsonb),
    'inventory',coalesce((
      select jsonb_agg(jsonb_build_object('product_id',x.product_id,'quantity',x.quantity) order by x.product_id)
      from (
        select p.id product_id,coalesce(sum(m.quantity_delta),0)::numeric quantity
        from public.products p
        left join public.inventory_stock_movements m
          on m.organization_id=p.organization_id and m.store_id=p.store_id and m.product_id=p.id
        where p.organization_id=v_org and p.store_id=v_store
        group by p.id
      ) x
    ),'[]'::jsonb),
    'bundles',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',b.id,'organization_id',b.organization_id,'store_id',b.store_id,'name',b.name,'sku',b.sku,
        'category_id',b.category_id,'category',coalesce(c.name,b.category,'未分类'),'sale_price',b.sale_price,
        'image_path',b.image_path,'active',b.active,'created_at',b.created_at,'updated_at',b.updated_at
      ) order by b.created_at desc)
      from public.v13_product_bundles b
      left join public.v13_product_categories c on c.id=b.category_id and c.organization_id=b.organization_id and c.store_id=b.store_id
      where b.organization_id=v_org and b.store_id=v_store and (b.active or v_products_manage)
    ),'[]'::jsonb),
    'bundle_items',coalesce((
      select jsonb_agg(jsonb_build_object('id',bi.id,'bundle_id',bi.bundle_id,'product_id',bi.product_id,'quantity',bi.quantity) order by bi.bundle_id,bi.id)
      from public.v13_product_bundle_items bi
      join public.v13_product_bundles b on b.id=bi.bundle_id and b.organization_id=bi.organization_id
      where bi.organization_id=v_org and b.store_id=v_store and (b.active or v_products_manage)
    ),'[]'::jsonb)
  );
end;
$$;
revoke all on function public.v1355_employee_product_inventory(text) from public;
grant execute on function public.v1355_employee_product_inventory(text) to anon,authenticated;

-- -----------------------------------------------------------------------------
-- 2) Performance board. Never depend on service_performance_ledger.visit_id.
--    payment_id is the stable ledger key; payments.visit_id links back to the order.
-- -----------------------------------------------------------------------------
create or replace function public.v1355_performance_board_core(
  p_organization_id uuid,p_store_id uuid,p_period text,p_anchor date,p_employee_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_period text:=case when p_period in ('day','month','year') then p_period else 'month' end;
  v_anchor date:=coalesce(p_anchor,current_date);
  v_start timestamptz; v_end timestamptz; v_label text;
  v_ranking jsonb; v_detail jsonb; v_activity jsonb;
begin
  if v_period='day' then
    v_start=(v_anchor::timestamp at time zone 'Asia/Kuala_Lumpur');
    v_end=((v_anchor+1)::timestamp at time zone 'Asia/Kuala_Lumpur');
    v_label=to_char(v_anchor,'DD/MM/YYYY');
  elsif v_period='year' then
    v_start=(date_trunc('year',v_anchor::timestamp) at time zone 'Asia/Kuala_Lumpur');
    v_end=(date_trunc('year',v_anchor::timestamp)+interval '1 year') at time zone 'Asia/Kuala_Lumpur';
    v_label=to_char(v_anchor,'YYYY');
  else
    v_start=(date_trunc('month',v_anchor::timestamp) at time zone 'Asia/Kuala_Lumpur');
    v_end=(date_trunc('month',v_anchor::timestamp)+interval '1 month') at time zone 'Asia/Kuala_Lumpur';
    v_label=to_char(v_anchor,'MM/YYYY');
  end if;

  with staff as (
    select distinct e.id,e.name,e.position,e.employee_code,e.avatar_path,e.employment_status
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
    where e.organization_id=p_organization_id and es.store_id=p_store_id and es.status='active'
  ), service as (
    select sp.employee_id,
      coalesce(sum(sp.performance_amount),0)::numeric service_performance,
      count(*)::int service_count,
      count(distinct p.visit_id)::int customer_count
    from public.service_performance_ledger sp
    join public.payments p on p.id=sp.payment_id and p.organization_id=sp.organization_id and p.store_id=sp.store_id
    where sp.organization_id=p_organization_id and sp.store_id=p_store_id
      and p.status='paid' and p.paid_at>=v_start and p.paid_at<v_end
    group by sp.employee_id
  ), visit_stats as (
    select sp.employee_id,
      count(distinct case when v.visit_type='appointment' then p.visit_id end)::int appointments,
      count(distinct case when v.visit_type<>'appointment' then p.visit_id end)::int walkins
    from public.service_performance_ledger sp
    join public.payments p on p.id=sp.payment_id and p.organization_id=sp.organization_id and p.store_id=sp.store_id and p.status='paid'
    left join public.visits v on v.id=p.visit_id and v.organization_id=sp.organization_id and v.store_id=sp.store_id
    where sp.organization_id=p_organization_id and sp.store_id=p_store_id
      and p.paid_at>=v_start and p.paid_at<v_end
    group by sp.employee_id
  ), product as (
    select pi.salesperson_employee_id employee_id,
      coalesce(sum(pi.line_total),0)::numeric product_sales,
      coalesce(sum(pi.quantity),0)::numeric product_units
    from public.visit_product_items pi
    where pi.organization_id=p_organization_id and pi.store_id=p_store_id
      and pi.status='active' and pi.salesperson_employee_id is not null
      and exists(
        select 1 from public.payments pp
        where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id
          and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end
      )
    group by pi.salesperson_employee_id
  ), commission as (
    select c.employee_id,coalesce(sum(c.commission_amount),0)::numeric commission_amount
    from public.employee_commission_ledger c
    where c.organization_id=p_organization_id and c.store_id=p_store_id
      and c.created_at>=v_start and c.created_at<v_end
    group by c.employee_id
  ), scores as (
    select s.*,
      coalesce(se.service_performance,0)::numeric service_performance,
      coalesce(pr.product_sales,0)::numeric product_sales,
      (coalesce(se.service_performance,0)+coalesce(pr.product_sales,0))::numeric total_performance,
      coalesce(co.commission_amount,0)::numeric commission_amount,
      coalesce(se.service_count,0)::int service_count,
      coalesce(se.customer_count,0)::int customer_count,
      coalesce(vs.appointments,0)::int appointments,
      coalesce(vs.walkins,0)::int walkins,
      coalesce(pr.product_units,0)::numeric product_units
    from staff s
    left join service se on se.employee_id=s.id
    left join product pr on pr.employee_id=s.id
    left join commission co on co.employee_id=s.id
    left join visit_stats vs on vs.employee_id=s.id
  ), ranked as (
    select row_number() over(order by total_performance desc,service_performance desc,name asc)::int rank_no,* from scores
  )
  select coalesce(jsonb_agg(jsonb_build_object(
    'rank',rank_no,'employee_id',id,'name',name,'position',position,'employee_code',employee_code,
    'avatar_path',avatar_path,'employment_status',employment_status,
    'service_performance',service_performance,'product_sales',product_sales,'total_performance',total_performance,
    'commission_amount',commission_amount,'service_count',service_count,'customer_count',customer_count,
    'appointments',appointments,'walkins',walkins,'product_units',product_units
  ) order by rank_no),'[]'::jsonb)
  into v_ranking from ranked;

  if p_employee_id is not null then
    select x into v_detail
    from jsonb_array_elements(v_ranking) x
    where x->>'employee_id'=p_employee_id::text limit 1;

    select coalesce(jsonb_agg(z.a order by z.a->>'occurred_at' desc nulls last),'[]'::jsonb)
    into v_activity
    from (
      select jsonb_build_object(
        'type','service','label',coalesce(v.visit_number,'服务项目'),
        'amount',sp.performance_amount,'occurred_at',p.paid_at
      ) a
      from public.service_performance_ledger sp
      join public.payments p on p.id=sp.payment_id and p.organization_id=sp.organization_id and p.store_id=sp.store_id and p.status='paid'
      left join public.visits v on v.id=p.visit_id and v.organization_id=sp.organization_id and v.store_id=sp.store_id
      where sp.organization_id=p_organization_id and sp.store_id=p_store_id and sp.employee_id=p_employee_id
        and p.paid_at>=v_start and p.paid_at<v_end
      union all
      select jsonb_build_object(
        'type','product','label',coalesce(pi.product_name_snapshot,'产品销售'),'amount',pi.line_total,
        'occurred_at',(select max(pp.paid_at) from public.payments pp
          where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id
            and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end)
      )
      from public.visit_product_items pi
      where pi.organization_id=p_organization_id and pi.store_id=p_store_id
        and pi.salesperson_employee_id=p_employee_id and pi.status='active'
        and exists(select 1 from public.payments pp
          where pp.visit_id=pi.visit_id and pp.organization_id=pi.organization_id and pp.store_id=pi.store_id
            and pp.status='paid' and pp.paid_at>=v_start and pp.paid_at<v_end)
    ) z;
  end if;

  return jsonb_build_object(
    'period',v_period,'anchor',v_anchor,'label',v_label,'range_start',v_start,'range_end',v_end,
    'ranking',coalesce(v_ranking,'[]'::jsonb),'detail',v_detail,'activity',coalesce(v_activity,'[]'::jsonb)
  );
end;
$$;
revoke all on function public.v1355_performance_board_core(uuid,uuid,text,date,uuid) from public;

create or replace function public.v1355_owner_performance_board(
  p_store_id uuid,p_period text,p_anchor date,p_employee_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_org uuid;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id and s.status='active';
  if v_org is null then raise exception '找不到门店。'; end if;
  if not public.can_access_store(p_store_id)
     or not public.has_organization_role(v_org,array['owner','manager','accountant']) then
    raise exception '你没有查看员工业绩的权限。';
  end if;
  return public.v1355_performance_board_core(v_org,p_store_id,p_period,p_anchor,p_employee_id);
end;
$$;
revoke all on function public.v1355_owner_performance_board(uuid,text,date,uuid) from public;
grant execute on function public.v1355_owner_performance_board(uuid,text,date,uuid) to authenticated;

create or replace function public.v1355_employee_performance_board(
  p_session_token text,p_period text,p_anchor date,p_employee_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_org uuid; v_store uuid;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  if not public.v1354_employee_permission_allowed(p_session_token,'performance.view') then
    raise exception '你的职位没有查看员工业绩的权限。';
  end if;
  return public.v1355_performance_board_core(v_org,v_store,p_period,p_anchor,p_employee_id);
end;
$$;
revoke all on function public.v1355_employee_performance_board(text,text,date,uuid) from public;
grant execute on function public.v1355_employee_performance_board(text,text,date,uuid) to anon,authenticated;

-- -----------------------------------------------------------------------------
-- 3) Runtime contract checks actual compatible ledger path instead of only checking
--    whether a broken v13.5.4 function happens to exist.
-- -----------------------------------------------------------------------------
create or replace function public.v1355_runtime_contract_status()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
  select jsonb_build_object(
    'version','13.5.5',
    'ok',
      to_regprocedure('public.v1353_runtime_contract_status()') is not null
      and to_regprocedure('public.v1355_owner_performance_board(uuid,text,date,uuid)') is not null
      and to_regprocedure('public.v1355_employee_performance_board(text,text,date,uuid)') is not null
      and to_regprocedure('public.v1355_employee_product_inventory(text)') is not null
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='service_performance_ledger' and column_name='payment_id')
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='payments' and column_name='visit_id')
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='employees' and column_name='avatar_path'),
    'performance_payment_link_ok',
      exists(select 1 from information_schema.columns where table_schema='public' and table_name='service_performance_ledger' and column_name='payment_id')
      and exists(select 1 from information_schema.columns where table_schema='public' and table_name='payments' and column_name='visit_id'),
    'owner_performance_rpc_ok',to_regprocedure('public.v1355_owner_performance_board(uuid,text,date,uuid)') is not null,
    'employee_performance_rpc_ok',to_regprocedure('public.v1355_employee_performance_board(text,text,date,uuid)') is not null,
    'employee_product_inventory_rpc_ok',to_regprocedure('public.v1355_employee_product_inventory(text)') is not null
  );
$$;
revoke all on function public.v1355_runtime_contract_status() from public;
grant execute on function public.v1355_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('runtime_contract_version','13.5.5'),
 ('performance_contract_version','13.5.5'),
 ('employee_product_inventory_version','13.5.5')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.5.5 PERFORMANCE + EMPLOYEE PRODUCTS READY' as result,
  to_regprocedure('public.v1355_owner_performance_board(uuid,text,date,uuid)') is not null as owner_performance_ok,
  to_regprocedure('public.v1355_employee_performance_board(text,text,date,uuid)') is not null as employee_performance_ok,
  to_regprocedure('public.v1355_employee_product_inventory(text)') is not null as employee_product_inventory_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='service_performance_ledger' and column_name='payment_id') as performance_payment_id_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='payments' and column_name='visit_id') as payments_visit_id_ok;
