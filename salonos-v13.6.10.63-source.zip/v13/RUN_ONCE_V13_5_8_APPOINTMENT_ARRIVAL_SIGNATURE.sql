-- SalonOS v13.5.8 · Appointment Arrival Signature Rules
-- Existing Supabase project: run this ONCE in Supabase SQL Editor.
begin;

create or replace function public.v1344_employee_set_visit_status(p_session_token text,p_visit_id uuid,p_status text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_status text:=lower(coalesce(p_status,'')); v_all boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_all:=v_role in ('manager','receptionist');

  if v_all then
    if v_status not in ('arrived','waiting','in_service','paused','ready_for_checkout','cancelled','no_show') then raise exception '不允许的订单状态。'; end if;
  else
    -- v13.5.8: the assigned employee may confirm that their own appointment customer arrived.
    if v_status not in ('arrived','waiting','in_service','paused','ready_for_checkout') then raise exception '这个员工角色不能执行该状态操作。'; end if;
    if not exists(
      select 1 from public.visit_service_items si
      join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
      where si.visit_id=p_visit_id and si.organization_id=v_org and w.employee_id=v_e
    ) then raise exception '你不是这笔订单的负责员工。'; end if;
  end if;

  update public.visits set
    status=v_status,
    arrived_at=case when v_status='arrived' then coalesce(arrived_at,now()) else arrived_at end,
    started_at=case when v_status='in_service' then coalesce(started_at,now()) else started_at end,
    service_completed_at=case when v_status='ready_for_checkout' then coalesce(service_completed_at,now()) else service_completed_at end,
    updated_at=now()
  where id=p_visit_id and organization_id=v_org and store_id=v_store;
  if not found then raise exception '找不到订单。'; end if;
  return jsonb_build_object('ok',true,'status',v_status);
end;
$$;
revoke all on function public.v1344_employee_set_visit_status(text,uuid,text) from public;
grant execute on function public.v1344_employee_set_visit_status(text,uuid,text) to anon,authenticated;

create or replace function public.v1331_employee_confirm_visit(p_session_token text,p_visit_id uuid,p_customer_name text,p_signature_data text)
returns jsonb
language plpgsql security definer set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_type text; v_status text; v_arrived_at timestamptz; v_snapshot jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid; v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid;
  if length(coalesce(p_signature_data,''))<40 then raise exception '请先完成顾客签名。'; end if;
  select v.visit_type,v.status,v.arrived_at into v_type,v_status,v_arrived_at
  from public.visits v where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store;
  if v_type is null then raise exception '找不到订单。'; end if;
  if v_type='appointment' and v_arrived_at is null then
    raise exception '预约顾客尚未确认到店；顾客到店后才可以签名。';
  end if;
  v_snapshot:=public.v1331_employee_order_review(p_session_token,p_visit_id);
  insert into public.v13_visit_confirmations(organization_id,store_id,visit_id,customer_name,signature_data,order_snapshot,signed_at,created_by_employee_id,updated_at)
  values(v_org,v_store,p_visit_id,coalesce(nullif(trim(p_customer_name),''),'顾客'),p_signature_data,v_snapshot,now(),v_e,now())
  on conflict(visit_id) do update set customer_name=excluded.customer_name,signature_data=excluded.signature_data,order_snapshot=excluded.order_snapshot,signed_at=now(),created_by_employee_id=excluded.created_by_employee_id,updated_at=now();
  if v_type='walk_in' or (v_type='appointment' and v_status='arrived') then
    update public.visits set status='waiting',updated_at=now() where id=p_visit_id;
  end if;
  return jsonb_build_object('ok',true,'visit_id',p_visit_id);
end;
$$;
revoke all on function public.v1331_employee_confirm_visit(text,uuid,text,text) from public;
grant execute on function public.v1331_employee_confirm_visit(text,uuid,text,text) to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values('appointment_signature_flow_version','13.5.8-arrival-required')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

notify pgrst, 'reload schema';
commit;
select 'SalonOS v13.5.8 APPOINTMENT ARRIVAL SIGNATURE READY' as result;
