-- SalonOS v13.6.0 · Media Accounts + Tracking Attribution Foundation
-- Additive / idempotent. Run once in Supabase SQL Editor.

begin;
set local statement_timeout='0';

create table if not exists public.marketing_channels (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  code text not null,
  name text not null,
  channel_type text not null default 'other' check(channel_type in ('social','search','owned','offline','referral','other')),
  is_system boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(organization_id,store_id,code)
);
create index if not exists marketing_channels_store_idx on public.marketing_channels(organization_id,store_id,active,name);

create table if not exists public.social_accounts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  channel_id uuid not null references public.marketing_channels(id) on delete restrict,
  platform text not null,
  account_type text not null default 'store' check(account_type in ('store','staff','other')),
  staff_id uuid references public.employees(id) on delete set null,
  display_name text not null,
  username text,
  profile_url text,
  external_account_id text,
  connection_status text not null default 'tracking_only' check(connection_status in ('tracking_only','api_connected','disconnected')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists social_accounts_store_idx on public.social_accounts(organization_id,store_id,channel_id,active);
create index if not exists social_accounts_staff_idx on public.social_accounts(staff_id) where staff_id is not null;

create table if not exists public.marketing_contents (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  social_account_id uuid references public.social_accounts(id) on delete set null,
  content_type text not null default 'other' check(content_type in ('bio','reel','story','post','ad','qr','landing','referral','other')),
  content_code text,
  title text not null,
  external_url text,
  published_at timestamptz,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists marketing_contents_store_idx on public.marketing_contents(organization_id,store_id,social_account_id,active,created_at desc);

create table if not exists public.tracking_links (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  channel_id uuid not null references public.marketing_channels(id) on delete restrict,
  social_account_id uuid references public.social_accounts(id) on delete set null,
  content_id uuid references public.marketing_contents(id) on delete set null,
  staff_id uuid references public.employees(id) on delete set null,
  slug text not null unique,
  ref_prefix text not null,
  destination_type text not null default 'whatsapp' check(destination_type in ('whatsapp','url')),
  destination_phone text,
  destination_url text,
  prefill_message text not null default 'Hi，我想了解预约',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists tracking_links_store_idx on public.tracking_links(organization_id,store_id,active,created_at desc);
create index if not exists tracking_links_account_idx on public.tracking_links(social_account_id) where social_account_id is not null;

create table if not exists public.tracking_clicks (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  tracking_link_id uuid not null references public.tracking_links(id) on delete cascade,
  ref_code text not null unique,
  user_agent text,
  clicked_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists tracking_clicks_link_idx on public.tracking_clicks(tracking_link_id,clicked_at desc);
create index if not exists tracking_clicks_store_idx on public.tracking_clicks(organization_id,store_id,clicked_at desc);

create table if not exists public.marketing_leads (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  tracking_link_id uuid references public.tracking_links(id) on delete set null,
  channel_id uuid references public.marketing_channels(id) on delete set null,
  social_account_id uuid references public.social_accounts(id) on delete set null,
  content_id uuid references public.marketing_contents(id) on delete set null,
  staff_id uuid references public.employees(id) on delete set null,
  ref_code text,
  customer_phone text,
  whatsapp_message_id text,
  lead_status text not null default 'new' check(lead_status in ('new','contacted','appointment','arrived','completed','lost')),
  customer_id uuid references public.customers(id) on delete set null,
  visit_id uuid references public.visits(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists marketing_leads_store_idx on public.marketing_leads(organization_id,store_id,created_at desc);
create index if not exists marketing_leads_ref_idx on public.marketing_leads(ref_code) where ref_code is not null;

-- Default channels for every existing branch.
insert into public.marketing_channels(organization_id,store_id,code,name,channel_type,is_system,active)
select s.organization_id,s.id,v.code,v.name,v.kind,true,true
from public.stores s
cross join (values
 ('INSTAGRAM','Instagram','social'),('FACEBOOK','Facebook','social'),('TIKTOK','TikTok','social'),('GOOGLE','Google','search'),('XHS','XHS / 小红书','social'),
 ('WEBSITE','Website','owned'),('QR','QR','owned'),('REFERRAL','Referral','referral'),('WALK_IN','Walk-in','offline'),('OTHER','Other','other')
) as v(code,name,kind)
on conflict(organization_id,store_id,code) do nothing;

-- Owner / manager access. Public clicks are written only through a security-definer RPC.
do $$ declare t text; begin
  foreach t in array array['marketing_channels','social_accounts','marketing_contents','tracking_links','tracking_clicks','marketing_leads'] loop
    execute format('alter table public.%I enable row level security',t);
  end loop;
end $$;

drop policy if exists v1360_marketing_channels_read on public.marketing_channels;
create policy v1360_marketing_channels_read on public.marketing_channels for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1360_marketing_channels_manage on public.marketing_channels;
create policy v1360_marketing_channels_manage on public.marketing_channels for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

drop policy if exists v1360_social_accounts_read on public.social_accounts;
create policy v1360_social_accounts_read on public.social_accounts for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1360_social_accounts_manage on public.social_accounts;
create policy v1360_social_accounts_manage on public.social_accounts for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

drop policy if exists v1360_marketing_contents_read on public.marketing_contents;
create policy v1360_marketing_contents_read on public.marketing_contents for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1360_marketing_contents_manage on public.marketing_contents;
create policy v1360_marketing_contents_manage on public.marketing_contents for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

drop policy if exists v1360_tracking_links_read on public.tracking_links;
create policy v1360_tracking_links_read on public.tracking_links for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1360_tracking_links_manage on public.tracking_links;
create policy v1360_tracking_links_manage on public.tracking_links for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

drop policy if exists v1360_tracking_clicks_read on public.tracking_clicks;
create policy v1360_tracking_clicks_read on public.tracking_clicks for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));

drop policy if exists v1360_marketing_leads_read on public.marketing_leads;
create policy v1360_marketing_leads_read on public.marketing_leads for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1360_marketing_leads_manage on public.marketing_leads;
create policy v1360_marketing_leads_manage on public.marketing_leads for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

-- Public short-link resolver. It exposes only redirect/attribution metadata needed by /t/<slug>.
create or replace function public.v1360_marketing_track(
  p_slug text,
  p_ref_code text,
  p_user_agent text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_link public.tracking_links%rowtype;
  v_channel public.marketing_channels%rowtype;
  v_account public.social_accounts%rowtype;
  v_content public.marketing_contents%rowtype;
begin
  select * into v_link from public.tracking_links
  where slug=lower(trim(p_slug)) and active=true limit 1;
  if v_link.id is null then return jsonb_build_object('ok',false,'error','not_found'); end if;

  select * into v_channel from public.marketing_channels where id=v_link.channel_id;
  if v_link.social_account_id is not null then select * into v_account from public.social_accounts where id=v_link.social_account_id; end if;
  if v_link.content_id is not null then select * into v_content from public.marketing_contents where id=v_link.content_id; end if;

  insert into public.tracking_clicks(organization_id,store_id,tracking_link_id,ref_code,user_agent)
  values(v_link.organization_id,v_link.store_id,v_link.id,upper(trim(p_ref_code)),left(coalesce(p_user_agent,''),500))
  on conflict(ref_code) do nothing;

  return jsonb_build_object(
    'ok',true,
    'organization_id',v_link.organization_id,
    'store_id',v_link.store_id,
    'tracking_link_id',v_link.id,
    'channel_id',v_link.channel_id,
    'channel_code',v_channel.code,
    'channel_name',v_channel.name,
    'social_account_id',v_link.social_account_id,
    'account_name',v_account.display_name,
    'username',v_account.username,
    'staff_id',coalesce(v_link.staff_id,v_account.staff_id),
    'content_id',v_link.content_id,
    'content_type',v_content.content_type,
    'content_code',v_content.content_code,
    'content_title',v_content.title,
    'ref_code',upper(trim(p_ref_code)),
    'destination_type',v_link.destination_type,
    'destination_phone',v_link.destination_phone,
    'destination_url',v_link.destination_url,
    'prefill_message',v_link.prefill_message
  );
end;
$$;
revoke all on function public.v1360_marketing_track(text,text,text) from public;
grant execute on function public.v1360_marketing_track(text,text,text) to anon, authenticated;

-- Future WhatsApp webhook / AI Agent can use this secured function once it has authenticated context.
create or replace function public.v1360_capture_marketing_lead(
  p_ref_code text,
  p_customer_phone text,
  p_whatsapp_message_id text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_click public.tracking_clicks%rowtype;
  v_link public.tracking_links%rowtype;
  v_id uuid;
begin
  select * into v_click from public.tracking_clicks where ref_code=upper(trim(p_ref_code)) order by clicked_at desc limit 1;
  if v_click.id is null then return jsonb_build_object('ok',false,'error','ref_not_found'); end if;
  select * into v_link from public.tracking_links where id=v_click.tracking_link_id;
  insert into public.marketing_leads(organization_id,store_id,tracking_link_id,channel_id,social_account_id,content_id,staff_id,ref_code,customer_phone,whatsapp_message_id)
  values(v_link.organization_id,v_link.store_id,v_link.id,v_link.channel_id,v_link.social_account_id,v_link.content_id,v_link.staff_id,v_click.ref_code,nullif(trim(p_customer_phone),''),nullif(trim(p_whatsapp_message_id),''))
  returning id into v_id;
  return jsonb_build_object('ok',true,'lead_id',v_id,'tracking_link_id',v_link.id,'channel_id',v_link.channel_id,'social_account_id',v_link.social_account_id,'content_id',v_link.content_id,'staff_id',v_link.staff_id);
end;
$$;
revoke all on function public.v1360_capture_marketing_lead(text,text,text) from public;
grant execute on function public.v1360_capture_marketing_lead(text,text,text) to authenticated;

commit;

select 'SalonOS v13.6.0 MEDIA ATTRIBUTION READY' as result;
