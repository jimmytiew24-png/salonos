-- SalonOS v13.6.10.18
-- MARKETING CLOSED LOOP BRIDGE
--
-- PURPOSE
-- First-Touch WhatsApp source remains immutable, while the same customer is
-- automatically connected to the canonical SalonOS customer + first eligible
-- post-touch Visit. Arrived / Paid / Revenue continue to come from canonical
-- visits/payments and are NOT copied into marketing tables.
--
-- SAFE RULES
-- 1) Never overwrite first source.
-- 2) Never attribute a Visit scheduled/created before first WhatsApp touch.
-- 3) Same normalized phone is the identity bridge.
-- 4) First eligible post-touch Visit is linked to the earliest Marketing Lead.
-- 5) New AI bookings and manual SalonOS bookings both use visit_recipients, so
--    one trigger covers both workflows.
-- 6) Re-running this file is idempotent.

begin;

create or replace function public.v13618_bridge_visit_recipient_to_marketing()
returns trigger
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_visit public.visits%rowtype;
  v_phone text;
  v_customer_phone text;
  v_ft public.marketing_customer_first_touch%rowtype;
  v_effective_at timestamptz;
  v_lead_id uuid;
begin
  if coalesce(new.recipient_type,'primary') <> 'primary' then
    return new;
  end if;

  select * into v_visit
  from public.visits
  where id=new.visit_id
    and organization_id=new.organization_id
  limit 1;

  if v_visit.id is null then
    return new;
  end if;

  if new.customer_id is not null then
    select c.phone into v_customer_phone
    from public.customers c
    where c.id=new.customer_id
      and c.organization_id=v_visit.organization_id
      and c.store_id=v_visit.store_id
    limit 1;
  end if;

  v_phone:=public.v136109_normalize_phone_text(coalesce(v_customer_phone,new.phone_snapshot,''));
  if v_phone='' then
    return new;
  end if;

  select * into v_ft
  from public.marketing_customer_first_touch
  where organization_id=v_visit.organization_id
    and store_id=v_visit.store_id
    and normalized_phone=v_phone
  limit 1;

  if v_ft.id is null then
    return new;
  end if;

  v_effective_at:=coalesce(v_visit.scheduled_at,v_visit.created_at,now());

  -- Never steal an old appointment/visit that existed before acquisition.
  if v_effective_at < v_ft.first_message_at then
    return new;
  end if;

  -- Customer identity can be completed later without changing attribution.
  if new.customer_id is not null and v_ft.customer_id is null then
    update public.marketing_customer_first_touch
    set customer_id=new.customer_id,updated_at=now()
    where id=v_ft.id and customer_id is null;
  end if;

  update public.marketing_leads ml
  set customer_id=coalesce(ml.customer_id,new.customer_id),
      updated_at=now()
  where ml.organization_id=v_visit.organization_id
    and ml.store_id=v_visit.store_id
    and public.v136109_normalize_phone_text(ml.customer_phone)=v_phone
    and new.customer_id is not null
    and ml.customer_id is null;

  -- Store the FIRST eligible post-touch Visit on the earliest Lead only.
  select ml.id into v_lead_id
  from public.marketing_leads ml
  where ml.organization_id=v_visit.organization_id
    and ml.store_id=v_visit.store_id
    and public.v136109_normalize_phone_text(ml.customer_phone)=v_phone
  order by coalesce(ml.first_message_at,ml.created_at) asc,ml.created_at asc,ml.id asc
  limit 1;

  if v_lead_id is not null then
    update public.marketing_leads
    set visit_id=coalesce(visit_id,v_visit.id),
        customer_id=coalesce(customer_id,new.customer_id),
        updated_at=now()
    where id=v_lead_id;
  end if;

  return new;
end;
$$;

revoke all on function public.v13618_bridge_visit_recipient_to_marketing() from public;
grant execute on function public.v13618_bridge_visit_recipient_to_marketing() to authenticated,service_role;

drop trigger if exists trg_v13618_visit_recipient_marketing_bridge on public.visit_recipients;
create trigger trg_v13618_visit_recipient_marketing_bridge
after insert or update of customer_id,phone_snapshot,recipient_type
on public.visit_recipients
for each row
execute function public.v13618_bridge_visit_recipient_to_marketing();

-- ---------------------------------------------------------------------------
-- Backfill 1: first-touch customer_id from canonical customer phone.
-- ---------------------------------------------------------------------------
with customer_match as (
  select distinct on (c.organization_id,c.store_id,public.v136109_normalize_phone_text(c.phone))
    c.organization_id,
    c.store_id,
    public.v136109_normalize_phone_text(c.phone) as normalized_phone,
    c.id as customer_id
  from public.customers c
  where public.v136109_normalize_phone_text(c.phone)<>''
  order by c.organization_id,c.store_id,public.v136109_normalize_phone_text(c.phone),c.created_at asc,c.id asc
)
update public.marketing_customer_first_touch ft
set customer_id=cm.customer_id,updated_at=now()
from customer_match cm
where ft.organization_id=cm.organization_id
  and ft.store_id=cm.store_id
  and ft.normalized_phone=cm.normalized_phone
  and ft.customer_id is null;

-- Keep Marketing Leads linked to that canonical customer too.
update public.marketing_leads ml
set customer_id=ft.customer_id,updated_at=now()
from public.marketing_customer_first_touch ft
where ml.organization_id=ft.organization_id
  and ml.store_id=ft.store_id
  and public.v136109_normalize_phone_text(ml.customer_phone)=ft.normalized_phone
  and ft.customer_id is not null
  and ml.customer_id is null;

-- ---------------------------------------------------------------------------
-- Backfill 2: link the earliest Marketing Lead to the first eligible Visit that
-- happened after the immutable first WhatsApp touch.
-- ---------------------------------------------------------------------------
with candidate_visits as (
  select
    ft.id as first_touch_id,
    ft.organization_id,
    ft.store_id,
    ft.normalized_phone,
    ft.first_message_at,
    v.id as visit_id,
    coalesce(v.scheduled_at,v.created_at) as visit_at,
    row_number() over(
      partition by ft.id
      order by coalesce(v.scheduled_at,v.created_at) asc,v.created_at asc,v.id asc
    ) as rn
  from public.marketing_customer_first_touch ft
  join public.visit_recipients vr
    on vr.organization_id=ft.organization_id
   and vr.customer_id=ft.customer_id
   and coalesce(vr.recipient_type,'primary')='primary'
  join public.visits v
    on v.id=vr.visit_id
   and v.organization_id=ft.organization_id
   and v.store_id=ft.store_id
  where ft.customer_id is not null
    and coalesce(v.scheduled_at,v.created_at)>=ft.first_message_at
),
first_visit as (
  select * from candidate_visits where rn=1
),
first_lead as (
  select distinct on (
    ml.organization_id,
    ml.store_id,
    public.v136109_normalize_phone_text(ml.customer_phone)
  )
    ml.id as lead_id,
    ml.organization_id,
    ml.store_id,
    public.v136109_normalize_phone_text(ml.customer_phone) as normalized_phone
  from public.marketing_leads ml
  where public.v136109_normalize_phone_text(ml.customer_phone)<>''
  order by
    ml.organization_id,
    ml.store_id,
    public.v136109_normalize_phone_text(ml.customer_phone),
    coalesce(ml.first_message_at,ml.created_at) asc,
    ml.created_at asc,
    ml.id asc
)
update public.marketing_leads ml
set visit_id=fv.visit_id,
    customer_id=coalesce(ml.customer_id,ft.customer_id),
    updated_at=now()
from first_visit fv
join public.marketing_customer_first_touch ft
  on ft.id=fv.first_touch_id
join first_lead fl
  on fl.organization_id=ft.organization_id
 and fl.store_id=ft.store_id
 and fl.normalized_phone=ft.normalized_phone
where ml.id=fl.lead_id
  and ml.visit_id is null;

insert into public.salonos_system_meta(meta_key,meta_value,updated_at)
values('marketing_closed_loop_bridge_version','13.6.10.18',now())
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

commit;

notify pgrst,'reload schema';

select
  'SalonOS v13.6.10.18 MARKETING CLOSED LOOP BRIDGE READY' as result,
  (select count(*) from public.marketing_customer_first_touch) as first_touch_customers,
  (select count(*) from public.marketing_customer_first_touch where customer_id is not null) as customer_linked,
  (
    select count(distinct public.v136109_normalize_phone_text(customer_phone))
    from public.marketing_leads
    where visit_id is not null
      and public.v136109_normalize_phone_text(customer_phone)<>''
  ) as visit_linked_customers;
