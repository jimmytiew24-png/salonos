-- SalonOS v13.6.10.19
-- CLOSED LOOP HEALTH RPC FIX
--
-- WHY THIS EXISTS
-- v13.6.10.18 Bridge SQL may already be installed successfully, but the web UI
-- previously checked salonos_system_meta through ordinary REST/RLS. On some
-- owner sessions that probe returns no row, so the page incorrectly shows:
-- SQL REQUIRED / CUSTOMER LINKED 0 / VISIT LINKED 0.
--
-- This SECURITY DEFINER RPC reports the exact tenant/date-scoped bridge state.
-- It does NOT change First-Touch attribution and does NOT duplicate revenue.
-- Safe/idempotent to run again.

begin;

create or replace function public.v13619_closed_loop_health(
  p_organization_id uuid,
  p_store_id uuid,
  p_start_at timestamptz,
  p_end_at timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_bridge_version text:='';
  v_health_version text:='13.6.10.19';
  v_first_touch integer:=0;
  v_customer_linked integer:=0;
  v_visit_linked integer:=0;
  v_arrived integer:=0;
  v_paid integer:=0;
  v_revenue numeric:=0;
begin
  if p_organization_id is null or p_store_id is null then
    raise exception 'organization/store required';
  end if;

  if not public.has_organization_role(p_organization_id,array['owner','manager'])
     or not public.can_access_store(p_store_id) then
    raise exception 'permission denied';
  end if;

  select coalesce(meta_value,'')
  into v_bridge_version
  from public.salonos_system_meta
  where meta_key='marketing_closed_loop_bridge_version'
  limit 1;

  with cohort as (
    select ft.*
    from public.marketing_customer_first_touch ft
    where ft.organization_id=p_organization_id
      and ft.store_id=p_store_id
      and ft.first_message_at>=p_start_at
      and ft.first_message_at<p_end_at
  ),
  candidates as (
    -- Canonical Customer -> visit_recipients -> visits.
    select distinct
      c.normalized_phone,
      v.id as visit_id,
      v.status,
      v.arrived_at,
      coalesce(v.scheduled_at,v.created_at) as visit_at
    from cohort c
    join public.visit_recipients vr
      on c.customer_id is not null
     and vr.organization_id=c.organization_id
     and vr.customer_id=c.customer_id
     and coalesce(vr.recipient_type,'primary')='primary'
    join public.visits v
      on v.id=vr.visit_id
     and v.organization_id=c.organization_id
     and v.store_id=c.store_id
     and coalesce(v.scheduled_at,v.created_at)>=c.first_message_at

    union

    -- Marketing Lead -> visit_id fallback.
    select distinct
      c.normalized_phone,
      v.id as visit_id,
      v.status,
      v.arrived_at,
      coalesce(v.scheduled_at,v.created_at) as visit_at
    from cohort c
    join public.marketing_leads ml
      on ml.organization_id=c.organization_id
     and ml.store_id=c.store_id
     and public.v136109_normalize_phone_text(ml.customer_phone)=c.normalized_phone
     and ml.visit_id is not null
    join public.visits v
      on v.id=ml.visit_id
     and v.organization_id=c.organization_id
     and v.store_id=c.store_id
     and coalesce(v.scheduled_at,v.created_at)>=c.first_message_at
  ),
  paid_visits as (
    select
      x.normalized_phone,
      x.visit_id,
      sum(coalesce(p.grand_total,0)) as paid_total
    from candidates x
    join public.payments p
      on p.visit_id=x.visit_id
     and p.organization_id=p_organization_id
     and p.store_id=p_store_id
     and lower(coalesce(p.status,''))='paid'
    group by x.normalized_phone,x.visit_id
  )
  select
    (select count(*) from cohort),
    (select count(*) from cohort where customer_id is not null),
    (select count(distinct normalized_phone) from candidates),
    (
      select count(distinct normalized_phone)
      from candidates
      where arrived_at is not null
         or lower(coalesce(status,'')) in ('arrived','waiting','in_service','ready_for_checkout','completed')
    ),
    (select count(distinct normalized_phone) from paid_visits),
    coalesce((select sum(paid_total) from paid_visits),0)
  into
    v_first_touch,
    v_customer_linked,
    v_visit_linked,
    v_arrived,
    v_paid,
    v_revenue;

  return jsonb_build_object(
    'ok',true,
    'bridge_ready',version_compare(coalesce(v_bridge_version,'0'),'13.6.10.18') >= 0,
    'bridge_version',v_bridge_version,
    'health_rpc_version',v_health_version,
    'first_touch_customers',v_first_touch,
    'customer_linked',v_customer_linked,
    'visit_linked_customers',v_visit_linked,
    'arrived_customers',v_arrived,
    'paid_customers',v_paid,
    'revenue',v_revenue
  );
end;
$$;

-- PostgreSQL does not provide version_compare() by default. Replace the
-- bridge_ready expression with a direct marker check using a tiny wrapper.
create or replace function public.v13619_closed_loop_health(
  p_organization_id uuid,
  p_store_id uuid,
  p_start_at timestamptz,
  p_end_at timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_bridge_version text:='';
  v_first_touch integer:=0;
  v_customer_linked integer:=0;
  v_visit_linked integer:=0;
  v_arrived integer:=0;
  v_paid integer:=0;
  v_revenue numeric:=0;
begin
  if p_organization_id is null or p_store_id is null then
    raise exception 'organization/store required';
  end if;

  if not public.has_organization_role(p_organization_id,array['owner','manager'])
     or not public.can_access_store(p_store_id) then
    raise exception 'permission denied';
  end if;

  select coalesce(meta_value,'')
  into v_bridge_version
  from public.salonos_system_meta
  where meta_key='marketing_closed_loop_bridge_version'
  limit 1;

  with cohort as (
    select ft.*
    from public.marketing_customer_first_touch ft
    where ft.organization_id=p_organization_id
      and ft.store_id=p_store_id
      and ft.first_message_at>=p_start_at
      and ft.first_message_at<p_end_at
  ),
  candidates as (
    select distinct
      c.normalized_phone,
      v.id as visit_id,
      v.status,
      v.arrived_at,
      coalesce(v.scheduled_at,v.created_at) as visit_at
    from cohort c
    join public.visit_recipients vr
      on c.customer_id is not null
     and vr.organization_id=c.organization_id
     and vr.customer_id=c.customer_id
     and coalesce(vr.recipient_type,'primary')='primary'
    join public.visits v
      on v.id=vr.visit_id
     and v.organization_id=c.organization_id
     and v.store_id=c.store_id
     and coalesce(v.scheduled_at,v.created_at)>=c.first_message_at

    union

    select distinct
      c.normalized_phone,
      v.id as visit_id,
      v.status,
      v.arrived_at,
      coalesce(v.scheduled_at,v.created_at) as visit_at
    from cohort c
    join public.marketing_leads ml
      on ml.organization_id=c.organization_id
     and ml.store_id=c.store_id
     and public.v136109_normalize_phone_text(ml.customer_phone)=c.normalized_phone
     and ml.visit_id is not null
    join public.visits v
      on v.id=ml.visit_id
     and v.organization_id=c.organization_id
     and v.store_id=c.store_id
     and coalesce(v.scheduled_at,v.created_at)>=c.first_message_at
  ),
  paid_visits as (
    select
      x.normalized_phone,
      x.visit_id,
      sum(coalesce(p.grand_total,0)) as paid_total
    from candidates x
    join public.payments p
      on p.visit_id=x.visit_id
     and p.organization_id=p_organization_id
     and p.store_id=p_store_id
     and lower(coalesce(p.status,''))='paid'
    group by x.normalized_phone,x.visit_id
  )
  select
    (select count(*) from cohort),
    (select count(*) from cohort where customer_id is not null),
    (select count(distinct normalized_phone) from candidates),
    (
      select count(distinct normalized_phone)
      from candidates
      where arrived_at is not null
         or lower(coalesce(status,'')) in ('arrived','waiting','in_service','ready_for_checkout','completed')
    ),
    (select count(distinct normalized_phone) from paid_visits),
    coalesce((select sum(paid_total) from paid_visits),0)
  into
    v_first_touch,
    v_customer_linked,
    v_visit_linked,
    v_arrived,
    v_paid,
    v_revenue;

  return jsonb_build_object(
    'ok',true,
    'bridge_ready',coalesce(v_bridge_version,'')<>'',
    'bridge_version',v_bridge_version,
    'health_rpc_version','13.6.10.19',
    'first_touch_customers',v_first_touch,
    'customer_linked',v_customer_linked,
    'visit_linked_customers',v_visit_linked,
    'arrived_customers',v_arrived,
    'paid_customers',v_paid,
    'revenue',v_revenue
  );
end;
$$;

revoke all on function public.v13619_closed_loop_health(uuid,uuid,timestamptz,timestamptz) from public;
grant execute on function public.v13619_closed_loop_health(uuid,uuid,timestamptz,timestamptz) to authenticated,service_role;

insert into public.salonos_system_meta(meta_key,meta_value,updated_at)
values('marketing_closed_loop_health_rpc_version','13.6.10.19',now())
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.6.10.19 CLOSED LOOP HEALTH RPC READY' as result,
  to_regprocedure('public.v13619_closed_loop_health(uuid,uuid,timestamptz,timestamptz)') is not null as health_rpc_ok,
  (select meta_value from public.salonos_system_meta where meta_key='marketing_closed_loop_bridge_version') as bridge_version,
  (select meta_value from public.salonos_system_meta where meta_key='marketing_closed_loop_health_rpc_version') as health_rpc_version;
