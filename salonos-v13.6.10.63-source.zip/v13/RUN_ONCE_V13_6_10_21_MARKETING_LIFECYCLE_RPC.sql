-- SalonOS v13.6.10.21
-- CANONICAL MARKETING LIFECYCLE RPC
--
-- FIXES:
-- CLOSED LOOP HEALTH can already show Customer/Visit/Arrived/Paid correctly,
-- while the older PHP analytics joins may still show:
-- Booked 0 / Arrived 0 / Revenue RM0.
--
-- This RPC returns one lifecycle row per immutable First-Touch phone.
-- Dashboard KPI, funnel, content performance and rankings then use exactly
-- the same canonical Visits / Payments source of truth.
--
-- SAFE:
-- - Does not modify attribution.
-- - Does not copy revenue into marketing tables.
-- - Same phone remains one First-Touch customer.
-- - Visits before First Touch are excluded.
-- - Idempotent.

begin;

create or replace function public.v13621_marketing_lifecycle_rows(
  p_organization_id uuid,
  p_store_id uuid,
  p_start_at timestamptz,
  p_end_at timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_rows jsonb;
begin
  if p_organization_id is null or p_store_id is null then
    raise exception 'organization/store required';
  end if;

  if not public.has_organization_role(p_organization_id,array['owner','manager'])
     or not public.can_access_store(p_store_id) then
    raise exception 'permission denied';
  end if;

  with cohort as (
    select
      ft.id,
      ft.customer_id,
      ft.normalized_phone,
      ft.first_message_at
    from public.marketing_customer_first_touch ft
    where ft.organization_id=p_organization_id
      and ft.store_id=p_store_id
      and ft.first_message_at>=p_start_at
      and ft.first_message_at<p_end_at
  ),
  candidate_raw as (
    -- Canonical Customer -> visit_recipients -> visits.
    select
      c.normalized_phone,
      c.first_message_at,
      v.id as visit_id,
      v.visit_type,
      v.status,
      v.arrived_at,
      v.checked_out_at,
      v.created_at,
      v.scheduled_at
    from cohort c
    join public.visit_recipients vr
      on c.customer_id is not null
     and vr.organization_id=p_organization_id
     and vr.customer_id=c.customer_id
     and coalesce(vr.recipient_type,'primary')='primary'
    join public.visits v
      on v.id=vr.visit_id
     and v.organization_id=p_organization_id
     and v.store_id=p_store_id
     and coalesce(v.scheduled_at,v.created_at)>=c.first_message_at

    union

    -- Marketing Lead visit_id fallback.
    select
      c.normalized_phone,
      c.first_message_at,
      v.id as visit_id,
      v.visit_type,
      v.status,
      v.arrived_at,
      v.checked_out_at,
      v.created_at,
      v.scheduled_at
    from cohort c
    join public.marketing_leads ml
      on ml.organization_id=p_organization_id
     and ml.store_id=p_store_id
     and public.v136109_normalize_phone_text(ml.customer_phone)=c.normalized_phone
     and ml.visit_id is not null
    join public.visits v
      on v.id=ml.visit_id
     and v.organization_id=p_organization_id
     and v.store_id=p_store_id
     and coalesce(v.scheduled_at,v.created_at)>=c.first_message_at
  ),
  candidates as (
    select distinct on (normalized_phone,visit_id)
      normalized_phone,
      first_message_at,
      visit_id,
      visit_type,
      status,
      arrived_at,
      checked_out_at,
      created_at,
      scheduled_at
    from candidate_raw
    order by normalized_phone,visit_id,coalesce(scheduled_at,created_at)
  ),
  preference as (
    select distinct on (aep.visit_id)
      aep.visit_id,
      lower(coalesce(aep.preference_type,'random')) as preference_type
    from public.appointment_employee_preferences aep
    where aep.organization_id=p_organization_id
      and aep.store_id=p_store_id
    order by aep.visit_id,aep.created_at asc nulls last,aep.id asc
  ),
  paid as (
    select
      p.visit_id,
      sum(coalesce(p.grand_total,0))::numeric as paid_total
    from public.payments p
    where p.organization_id=p_organization_id
      and p.store_id=p_store_id
      and lower(coalesce(p.status,''))='paid'
    group by p.visit_id
  ),
  visit_enriched as (
    select
      x.normalized_phone,
      x.visit_id,
      lower(coalesce(x.visit_type,'walk_in')) as visit_type,
      lower(coalesce(x.status,'')) as status,
      x.arrived_at,
      coalesce(pr.preference_type,'random') as preference_type,
      coalesce(pd.paid_total,0)::numeric as paid_total,
      case
        when lower(coalesce(x.status,''))='completed'
          or coalesce(pd.paid_total,0)>0
        then 1 else 0
      end as is_completed,
      case
        when x.arrived_at is not null
          or lower(coalesce(x.status,'')) in ('arrived','waiting','in_service','ready_for_checkout','completed')
        then 1 else 0
      end as is_arrived
    from candidates x
    left join preference pr on pr.visit_id=x.visit_id
    left join paid pd on pd.visit_id=x.visit_id
  ),
  outcome as (
    select
      c.normalized_phone,
      count(distinct ve.visit_id) filter (where ve.visit_type='appointment')::int as bookings,
      count(distinct ve.visit_id) filter (where ve.is_arrived=1)::int as arrived_visits,
      count(distinct ve.visit_id) filter (where ve.is_completed=1)::int as completed_visits,
      count(distinct ve.visit_id) filter (where ve.is_completed=1 and ve.preference_type='specified')::int as specified,
      count(distinct ve.visit_id) filter (where ve.is_completed=1 and ve.preference_type<>'specified')::int as random,
      coalesce(sum(ve.paid_total),0)::numeric as revenue
    from cohort c
    left join visit_enriched ve on ve.normalized_phone=c.normalized_phone
    group by c.normalized_phone
  ),
  final_rows as (
    select
      o.normalized_phone,
      o.bookings,
      o.arrived_visits,
      o.completed_visits,
      o.specified,
      o.random,
      o.revenue,
      case when o.bookings>0 then 1 else 0 end::int as booked_customer,
      case when o.arrived_visits>0 then 1 else 0 end::int as arrived_customer,
      case when o.completed_visits>=2 then 1 else 0 end::int as repeat_customer,
      case when o.completed_visits>=2 and o.specified>o.random then 1 else 0 end::int as loyal_customer
    from outcome o
  )
  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'normalized_phone',normalized_phone,
        'bookings',bookings,
        'arrived_visits',arrived_visits,
        'completed_visits',completed_visits,
        'specified',specified,
        'random',random,
        'revenue',revenue,
        'booked_customer',booked_customer,
        'arrived_customer',arrived_customer,
        'repeat_customer',repeat_customer,
        'loyal_customer',loyal_customer
      )
      order by normalized_phone
    ),
    '[]'::jsonb
  )
  into v_rows
  from final_rows;

  return jsonb_build_object(
    'ok',true,
    'version','13.6.10.21',
    'rows',v_rows
  );
end;
$$;

revoke all on function public.v13621_marketing_lifecycle_rows(uuid,uuid,timestamptz,timestamptz) from public;
grant execute on function public.v13621_marketing_lifecycle_rows(uuid,uuid,timestamptz,timestamptz) to authenticated,service_role;

insert into public.salonos_system_meta(meta_key,meta_value,updated_at)
values('marketing_lifecycle_rpc_version','13.6.10.21',now())
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.6.10.21 MARKETING LIFECYCLE RPC READY' as result,
  to_regprocedure('public.v13621_marketing_lifecycle_rows(uuid,uuid,timestamptz,timestamptz)') is not null as lifecycle_rpc_ok,
  (select meta_value from public.salonos_system_meta where meta_key='marketing_closed_loop_bridge_version') as bridge_version,
  (select meta_value from public.salonos_system_meta where meta_key='marketing_closed_loop_health_rpc_version') as health_rpc_version,
  (select meta_value from public.salonos_system_meta where meta_key='marketing_lifecycle_rpc_version') as lifecycle_rpc_version;
