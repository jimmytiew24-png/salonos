-- SalonOS v13.6.10.22
-- UNIFIED STAFF POOL + SERVICE BOARD AVAILABILITY FALLBACK
--
-- RUNTIME PROBLEM:
-- Service Board can show another employee as "Available / 可接单", while WhatsApp AI
-- says no qualified stylist is free.
--
-- ROOT CAUSE:
-- The old AI availability function required a separate hidden
-- whatsapp_ai_employee_schedules row. Service Board did not use that hidden table.
-- Therefore an employee could be visibly free on Service Board but invisible to AI.
--
-- NEW RULE:
-- 1) Required service skill is still mandatory.
-- 2) Existing dedicated AI schedule rows remain authoritative when configured.
-- 3) If no dedicated AI schedule row exists, active + on-duty staff fall back to the
--    same Service Board operating window: 09:00 -> 00:00.
-- 4) Real Visit conflicts are always checked.
-- 5) If one qualified stylist is busy, AI continues checking the other qualified staff.
-- 6) Random/system assignment is only from qualified + free staff.
--
-- No Edge Function redeploy is required: whatsapp-ai-worker already calls
-- v1366_ai_check_availability -> v1365_ai_check_availability and
-- v13610_ai_assign_staff.

begin;
set local statement_timeout='0';

-- Re-sync legacy employee skill_tags to the canonical employee_skills table.
-- This is safe/idempotent and helps employees edited before v13.6.10.
do $$
declare r record;
begin
  if to_regprocedure('public.v13610_sync_employee_legacy_skills(uuid)') is not null then
    for r in
      select e.id
      from public.employees e
      where e.employment_status='active'
    loop
      perform public.v13610_sync_employee_legacy_skills(r.id);
    end loop;
  end if;
end $$;

create or replace function public.v1365_ai_check_availability(
  p_queue_id uuid,
  p_service_id uuid,
  p_employee_id uuid,
  p_date date,
  p_time_iso text default null,
  p_time_period text default 'unspecified'
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_tenant jsonb;
  v_org uuid;
  v_store uuid;
  v_service record;
  v_employee record;
  v_settings record;
  v_shift record;
  v_timezone text:='Asia/Kuala_Lumpur';
  v_interval integer:=30;
  v_notice integer:=30;
  v_max_days integer:=90;
  v_duration integer:=60;

  v_schedule_source text:='employee_schedule';
  v_shift_start timestamp;
  v_shift_end timestamp;
  v_break_start timestamp;
  v_break_end timestamp;

  v_window_start timestamp;
  v_window_end timestamp;
  v_exact timestamp;
  v_slot timestamp;
  v_slot_end timestamp;
  v_slots jsonb:='[]'::jsonb;
  v_busy boolean;
  v_now_local timestamp;
  v_count integer:=0;
  v_period text:=lower(coalesce(p_time_period,'unspecified'));
begin
  v_tenant:=public.v1365_ai_queue_tenant(p_queue_id);
  v_org:=(v_tenant->>'organization_id')::uuid;
  v_store:=(v_tenant->>'store_id')::uuid;

  select s.id,s.name,s.default_price,s.estimated_minutes,s.active
    into v_service
  from public.services s
  where s.id=p_service_id
    and s.organization_id=v_org
    and s.store_id=v_store
    and coalesce(s.active,true)=true;

  if v_service.id is null then
    return jsonb_build_object(
      'ok',false,'availability_status','invalid_service','slots','[]'::jsonb
    );
  end if;

  v_duration:=greatest(coalesce(v_service.estimated_minutes,60),1);

  select e.id,e.name,e.is_on_duty,e.availability_status,e.employment_status
    into v_employee
  from public.employees e
  where e.id=p_employee_id
    and e.organization_id=v_org
    and e.employment_status='active'
    and exists(
      select 1
      from public.employee_stores es
      where es.organization_id=v_org
        and es.store_id=v_store
        and es.employee_id=e.id
        and es.status='active'
    );

  if v_employee.id is null then
    return jsonb_build_object(
      'ok',false,'availability_status','invalid_staff','slots','[]'::jsonb
    );
  end if;

  -- Service Board eligibility switch.
  if not coalesce(v_employee.is_on_duty,false) then
    return jsonb_build_object(
      'ok',true,
      'availability_status','employee_off',
      'availability_source','service_board_on_duty',
      'employee',jsonb_build_object('id',v_employee.id,'name',v_employee.name),
      'date',p_date,
      'slots','[]'::jsonb
    );
  end if;

  select * into v_settings
  from public.whatsapp_ai_booking_settings b
  where b.organization_id=v_org
    and b.store_id=v_store
    and b.active=true;

  if v_settings.id is not null then
    v_timezone:=coalesce(nullif(v_settings.timezone,''),'Asia/Kuala_Lumpur');
    v_interval:=greatest(coalesce(v_settings.slot_interval_minutes,30),5);
    v_notice:=greatest(coalesce(v_settings.minimum_notice_minutes,30),0);
    v_max_days:=greatest(coalesce(v_settings.max_booking_days_ahead,90),1);
  end if;

  v_now_local:=now() at time zone v_timezone;

  if p_date is null then
    return jsonb_build_object(
      'ok',true,'availability_status','missing_date','slots','[]'::jsonb
    );
  end if;

  if p_date < v_now_local::date then
    return jsonb_build_object(
      'ok',true,'availability_status','date_in_past','slots','[]'::jsonb
    );
  end if;

  if p_date > (v_now_local::date + v_max_days) then
    return jsonb_build_object(
      'ok',true,
      'availability_status','date_too_far',
      'max_booking_days_ahead',v_max_days,
      'slots','[]'::jsonb
    );
  end if;

  -- Dedicated per-employee AI schedule remains the strongest truth if present.
  select * into v_shift
  from public.whatsapp_ai_employee_schedules x
  where x.organization_id=v_org
    and x.store_id=v_store
    and x.employee_id=p_employee_id
    and x.iso_weekday=extract(isodow from p_date)::int;

  if v_shift.id is not null then
    v_schedule_source:='employee_schedule';

    if not coalesce(v_shift.is_working,false) then
      return jsonb_build_object(
        'ok',true,
        'availability_status','employee_off',
        'availability_source',v_schedule_source,
        'date',p_date,
        'slots','[]'::jsonb
      );
    end if;

    if v_shift.start_time is null or v_shift.end_time is null then
      return jsonb_build_object(
        'ok',true,
        'availability_status','schedule_invalid',
        'availability_source',v_schedule_source,
        'slots','[]'::jsonb
      );
    end if;

    v_interval:=greatest(coalesce(v_shift.slot_interval_minutes,v_interval),5);
    v_shift_start:=p_date::timestamp + v_shift.start_time;
    v_shift_end:=p_date::timestamp + v_shift.end_time;

    if v_shift_end<=v_shift_start then
      v_shift_end:=v_shift_end+interval '1 day';
    end if;

    if v_shift.break_start is not null and v_shift.break_end is not null then
      v_break_start:=p_date::timestamp + v_shift.break_start;
      v_break_end:=p_date::timestamp + v_shift.break_end;
      if v_break_end<=v_break_start then
        v_break_end:=v_break_end+interval '1 day';
      end if;
    end if;
  else
    -- IMPORTANT FIX:
    -- No hidden AI schedule row -> use the Service Board's 09:00 -> 00:00 model.
    -- This prevents "weihong is Available on Service Board but AI cannot see him".
    v_schedule_source:='service_board_fallback';
    v_shift_start:=p_date::timestamp + time '09:00';
    v_shift_end:=(p_date+1)::timestamp; -- next day 00:00
    v_break_start:=null;
    v_break_end:=null;
  end if;

  v_window_start:=v_shift_start;
  v_window_end:=v_shift_end;

  if v_period='morning' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '06:00');
    v_window_end:=least(v_window_end,p_date::timestamp+time '12:00');
  elsif v_period='afternoon' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '12:00');
    v_window_end:=least(v_window_end,p_date::timestamp+time '18:00');
  elsif v_period='evening' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '18:00');
    v_window_end:=least(v_window_end,p_date::timestamp+time '22:00');
  elsif v_period='night' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '22:00');
  end if;

  if nullif(trim(coalesce(p_time_iso,'')),'') is not null then
    if trim(p_time_iso) !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' then
      return jsonb_build_object(
        'ok',true,'availability_status','invalid_time','slots','[]'::jsonb
      );
    end if;

    v_exact:=p_date::timestamp + trim(p_time_iso)::time;
    v_window_start:=v_exact;
    v_window_end:=v_exact + make_interval(mins=>v_duration);
  end if;

  if v_window_end<=v_window_start
     or v_window_start+make_interval(mins=>v_duration)>v_shift_end then
    return jsonb_build_object(
      'ok',true,
      'availability_status','outside_shift',
      'availability_source',v_schedule_source,
      'date',p_date,
      'slots','[]'::jsonb
    );
  end if;

  v_slot:=v_window_start;

  while v_slot + make_interval(mins=>v_duration) <= v_window_end loop
    v_slot_end:=v_slot+make_interval(mins=>v_duration);

    -- Minimum booking notice.
    if v_slot < v_now_local + make_interval(mins=>v_notice) then
      v_slot:=v_slot+make_interval(mins=>v_interval);
      continue;
    end if;

    -- Dedicated schedule break only. Service Board fallback has no hidden break.
    if v_break_start is not null
       and v_break_end is not null
       and v_slot < v_break_end
       and v_slot_end > v_break_start then
      v_slot:=v_slot+make_interval(mins=>v_interval);
      continue;
    end if;

    -- Real SalonOS Visit conflicts are the final availability truth.
    select exists(
      select 1
      from public.visits v
      where v.organization_id=v_org
        and v.store_id=v_store
        and v.status in (
          'booked','arrived','waiting','in_service','paused','ready_for_checkout'
        )
        and exists(
          select 1
          from public.visit_service_items si
          join public.visit_service_workers w
            on w.service_item_id=si.id
           and w.status='active'
          where si.visit_id=v.id
            and si.organization_id=v_org
            and si.status<>'cancelled'
            and w.employee_id=p_employee_id
        )
        and (coalesce(v.scheduled_at,v.started_at,v.created_at) at time zone v_timezone) < v_slot_end
        and (
          (coalesce(v.scheduled_at,v.started_at,v.created_at) at time zone v_timezone)
          + make_interval(
              mins=>greatest(
                30,
                coalesce((
                  select sum(greatest(coalesce(si2.estimated_minutes_snapshot,30),1))::int
                  from public.visit_service_items si2
                  where si2.visit_id=v.id
                    and si2.organization_id=v_org
                    and si2.status<>'cancelled'
                ),30)
              )
            )
        ) > v_slot
    ) into v_busy;

    if not v_busy then
      v_slots:=v_slots || jsonb_build_array(
        jsonb_build_object(
          'time',to_char(v_slot,'HH24:MI'),
          'start_local',to_char(v_slot,'YYYY-MM-DD"T"HH24:MI:SS'),
          'end_local',to_char(v_slot_end,'YYYY-MM-DD"T"HH24:MI:SS'),
          'duration_minutes',v_duration
        )
      );

      v_count:=v_count+1;
      if v_count>=12 then
        exit;
      end if;
    end if;

    if v_exact is not null then
      exit;
    end if;

    v_slot:=v_slot+make_interval(mins=>v_interval);
  end loop;

  return jsonb_build_object(
    'ok',true,
    'tool','check_availability',
    'availability_status',
      case when jsonb_array_length(v_slots)>0 then 'available' else 'no_slots' end,
    'availability_source',v_schedule_source,
    'date',p_date,
    'timezone',v_timezone,
    'service',jsonb_build_object(
      'id',v_service.id,
      'name',v_service.name,
      'duration_minutes',v_duration,
      'price',v_service.default_price
    ),
    'employee',jsonb_build_object(
      'id',v_employee.id,
      'name',v_employee.name,
      'is_on_duty',v_employee.is_on_duty,
      'live_availability_status',v_employee.availability_status
    ),
    'shift',jsonb_build_object(
      'source',v_schedule_source,
      'start',to_char(v_shift_start,'HH24:MI'),
      'end',case
        when v_shift_end::date>p_date then '00:00'
        else to_char(v_shift_end,'HH24:MI')
      end,
      'break_start',case
        when v_break_start is null then null else to_char(v_break_start,'HH24:MI')
      end,
      'break_end',case
        when v_break_end is null then null else to_char(v_break_end,'HH24:MI')
      end
    ),
    'slot_interval_minutes',v_interval,
    'slots',v_slots
  );
end;
$$;

revoke all on function public.v1365_ai_check_availability(uuid,uuid,uuid,date,text,text)
  from public,anon,authenticated;
grant execute on function public.v1365_ai_check_availability(uuid,uuid,uuid,date,text,text)
  to service_role;

-- Keep the v13.6.6 wrapper in place; it automatically calls the new v1365.
insert into public.salonos_system_meta(meta_key,meta_value,updated_at)
values
  ('whatsapp_ai_staff_pool_version','13.6.10.22',now()),
  ('whatsapp_ai_schedule_truth_source','employee_schedule_or_service_board_fallback',now())
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.6.10.22 UNIFIED STAFF POOL READY' as result,
  to_regprocedure('public.v1365_ai_check_availability(uuid,uuid,uuid,date,text,text)') is not null as availability_ok,
  to_regprocedure('public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text)') is not null as wrapper_ok,
  to_regprocedure('public.v13610_ai_assign_staff(uuid,uuid,date,text,text)') is not null as random_assignment_ok,
  (select meta_value from public.salonos_system_meta where meta_key='whatsapp_ai_schedule_truth_source') as availability_source;
