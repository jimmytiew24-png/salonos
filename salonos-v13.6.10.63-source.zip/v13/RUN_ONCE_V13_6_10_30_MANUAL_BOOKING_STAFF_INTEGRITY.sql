-- SalonOS v13.6.10.30
-- MANUAL BOOKING STAFF INTEGRITY
-- Unifies SalonOS manual-order staff filtering with the same business truths used by WhatsApp booking:
-- active branch staff + service skills + schedule/break + live availability for walk-ins + Visit conflicts.
-- Additive / idempotent.

begin;
set local statement_timeout='0';

create or replace function public.v1361030_employee_qualified_for_service(
  p_organization_id uuid,
  p_store_id uuid,
  p_employee_id uuid,
  p_service_id uuid
) returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select
    exists(
      select 1
      from public.services s
      where s.id=p_service_id
        and s.organization_id=p_organization_id
        and s.store_id=p_store_id
        and coalesce(s.active,true)=true
    )
    and not exists(
      select 1
      from public.service_skill_requirements r
      where r.organization_id=p_organization_id
        and r.store_id=p_store_id
        and r.service_id=p_service_id
        and r.active=true
        and r.required=true
        and not exists(
          select 1
          from public.employee_skills sk
          where sk.organization_id=p_organization_id
            and sk.employee_id=p_employee_id
            and sk.skill_code=r.skill_code
            and sk.active=true
            and sk.skill_level>=r.minimum_level
        )
    );
$$;
revoke all on function public.v1361030_employee_qualified_for_service(uuid,uuid,uuid,uuid) from public,anon,authenticated;

create or replace function public.v1361030_employee_free_for_slot(
  p_organization_id uuid,
  p_store_id uuid,
  p_employee_id uuid,
  p_start_at timestamptz,
  p_duration_minutes integer,
  p_visit_type text default 'appointment',
  p_exclude_visit_id uuid default null
) returns boolean
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_employee record;
  v_schedule record;
  v_timezone text:='Asia/Kuala_Lumpur';
  v_start_local timestamp;
  v_end_local timestamp;
  v_duration integer:=greatest(coalesce(p_duration_minutes,30),1);
  v_shift_start timestamp;
  v_shift_end timestamp;
  v_break_start timestamp;
  v_break_end timestamp;
  v_visit_type text:=case when lower(coalesce(p_visit_type,''))='walk_in' then 'walk_in' else 'appointment' end;
begin
  if p_start_at is null then return false; end if;

  select e.id,e.name,e.position,e.is_on_duty,e.availability_status,e.employment_status
  into v_employee
  from public.employees e
  where e.id=p_employee_id
    and e.organization_id=p_organization_id
    and e.employment_status='active'
    and exists(
      select 1 from public.employee_stores es
      where es.organization_id=p_organization_id
        and es.store_id=p_store_id
        and es.employee_id=e.id
        and es.status='active'
    );
  if v_employee.id is null then return false; end if;

  select coalesce(nullif(b.timezone,''),'Asia/Kuala_Lumpur') into v_timezone
  from public.whatsapp_ai_booking_settings b
  where b.organization_id=p_organization_id and b.store_id=p_store_id and b.active=true
  limit 1;
  v_timezone:=coalesce(v_timezone,'Asia/Kuala_Lumpur');
  v_start_local:=p_start_at at time zone v_timezone;
  v_end_local:=v_start_local+make_interval(mins=>v_duration);

  -- Live Service Board status applies to a walk-in happening now. Future appointments
  -- must NOT depend on whether the employee happens to be on duty at the moment this
  -- booking is created; their schedule for the requested date/time is the source of truth.
  if v_visit_type='walk_in' then
    if not coalesce(v_employee.is_on_duty,false) then return false; end if;
    if lower(coalesce(v_employee.availability_status,'available')) in
       ('break','off_duty','in_service','busy','disabled','inactive') then
      return false;
    end if;
  end if;

  select * into v_schedule
  from public.whatsapp_ai_employee_schedules x
  where x.organization_id=p_organization_id
    and x.store_id=p_store_id
    and x.employee_id=p_employee_id
    and x.iso_weekday=extract(isodow from v_start_local)::int
  limit 1;

  if v_schedule.id is not null then
    if not coalesce(v_schedule.is_working,false) or v_schedule.start_time is null or v_schedule.end_time is null then
      return false;
    end if;
    v_shift_start:=v_start_local::date::timestamp+v_schedule.start_time;
    v_shift_end:=v_start_local::date::timestamp+v_schedule.end_time;
    if v_shift_end<=v_shift_start then v_shift_end:=v_shift_end+interval '1 day'; end if;
    if v_schedule.break_start is not null and v_schedule.break_end is not null then
      v_break_start:=v_start_local::date::timestamp+v_schedule.break_start;
      v_break_end:=v_start_local::date::timestamp+v_schedule.break_end;
      if v_break_end<=v_break_start then v_break_end:=v_break_end+interval '1 day'; end if;
    end if;
  else
    -- Same fallback as the Service Board / WhatsApp unified pool.
    v_shift_start:=v_start_local::date::timestamp+time '09:00';
    v_shift_end:=(v_start_local::date+1)::timestamp;
    v_break_start:=null; v_break_end:=null;
  end if;

  if v_start_local<v_shift_start or v_end_local>v_shift_end then return false; end if;
  if v_break_start is not null and v_break_end is not null
     and v_start_local<v_break_end and v_end_local>v_break_start then return false; end if;

  -- Visit status is the occupancy truth. Cancelled / no-show / completed visits are
  -- intentionally absent, so cancelling a visit releases the slot without deleting
  -- historical visit_service_workers rows.
  if exists(
    select 1
    from public.visits v
    where v.organization_id=p_organization_id
      and v.store_id=p_store_id
      and v.status in ('booked','arrived','waiting','in_service','paused','ready_for_checkout')
      and (p_exclude_visit_id is null or v.id<>p_exclude_visit_id)
      and exists(
        select 1
        from public.visit_service_items si
        join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
        where si.visit_id=v.id
          and si.organization_id=p_organization_id
          and si.store_id=p_store_id
          and si.status<>'cancelled'
          and w.employee_id=p_employee_id
      )
      and (coalesce(v.scheduled_at,v.started_at,v.arrived_at,v.created_at) at time zone v_timezone) < v_end_local
      and (
        (coalesce(v.scheduled_at,v.started_at,v.arrived_at,v.created_at) at time zone v_timezone)
        + make_interval(mins=>greatest(30,coalesce((
          select sum(greatest(coalesce(si2.estimated_minutes_snapshot,30),1))::int
          from public.visit_service_items si2
          where si2.visit_id=v.id
            and si2.organization_id=p_organization_id
            and si2.store_id=p_store_id
            and si2.status<>'cancelled'
            and exists(
              select 1 from public.visit_service_workers w2
              where w2.service_item_id=si2.id
                and w2.employee_id=p_employee_id
                and w2.status='active'
            )
        ),30)))
      ) > v_start_local
  ) then return false; end if;

  return true;
end;
$$;
revoke all on function public.v1361030_employee_free_for_slot(uuid,uuid,uuid,timestamptz,integer,text,uuid) from public,anon,authenticated;

create or replace function public.v1361030_staff_pool_internal(
  p_organization_id uuid,
  p_store_id uuid,
  p_service_ids uuid[],
  p_start_at timestamptz,
  p_visit_type text default 'appointment',
  p_exclude_visit_id uuid default null
) returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_services uuid[]:=coalesce(p_service_ids,array[]::uuid[]);
  v_service uuid;
  v_service_row record;
  v_employee record;
  v_duration integer;
  v_total_duration integer:=0;
  v_by_service jsonb:='{}'::jsonb;
  v_rows jsonb;
  v_common jsonb:='[]'::jsonb;
  v_assistants jsonb:='[]'::jsonb;
  v_all_qualified boolean;
begin
  select coalesce(sum(greatest(coalesce(s.estimated_minutes,30),1)),30)::int
  into v_total_duration
  from public.services s
  where s.organization_id=p_organization_id and s.store_id=p_store_id
    and s.id=any(v_services) and coalesce(s.active,true)=true;
  v_total_duration:=greatest(coalesce(v_total_duration,30),30);

  foreach v_service in array v_services loop
    select s.id,s.estimated_minutes into v_service_row
    from public.services s
    where s.id=v_service and s.organization_id=p_organization_id and s.store_id=p_store_id and coalesce(s.active,true)=true;
    if v_service_row.id is null then continue; end if;
    v_duration:=greatest(coalesce(v_service_row.estimated_minutes,30),1);
    v_rows:='[]'::jsonb;
    for v_employee in
      select e.id,e.name,e.position,e.employee_code,e.availability_status,e.is_on_duty
      from public.employees e
      join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
      where e.organization_id=p_organization_id and es.store_id=p_store_id and es.status='active'
        and e.employment_status='active'
        and lower(coalesce(e.position,'')) not like '%reception%'
        and coalesce(e.position,'') not like '%前台%'
        and lower(coalesce(e.position,'')) not like '%assistant%'
        and coalesce(e.position,'') not like '%助理%'
      order by e.name
    loop
      if public.v1361030_employee_qualified_for_service(p_organization_id,p_store_id,v_employee.id,v_service)
         and public.v1361030_employee_free_for_slot(p_organization_id,p_store_id,v_employee.id,p_start_at,v_duration,p_visit_type,p_exclude_visit_id) then
        v_rows:=v_rows||jsonb_build_array(jsonb_build_object(
          'id',v_employee.id,'name',v_employee.name,'position',v_employee.position,
          'employee_code',v_employee.employee_code,'availability_status',v_employee.availability_status,
          'availability_reason','技能 / 排班 / 时间冲突已验证'
        ));
      end if;
    end loop;
    v_by_service:=jsonb_set(v_by_service,array[v_service::text],v_rows,true);
  end loop;

  -- Appointment-level preferred stylist: must be qualified for every selected service
  -- and free for the whole visit window.
  for v_employee in
    select e.id,e.name,e.position,e.employee_code,e.availability_status,e.is_on_duty
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
    where e.organization_id=p_organization_id and es.store_id=p_store_id and es.status='active'
      and e.employment_status='active'
      and lower(coalesce(e.position,'')) not like '%reception%'
      and coalesce(e.position,'') not like '%前台%'
      and lower(coalesce(e.position,'')) not like '%assistant%'
      and coalesce(e.position,'') not like '%助理%'
    order by e.name
  loop
    v_all_qualified:=true;
    foreach v_service in array v_services loop
      if not public.v1361030_employee_qualified_for_service(p_organization_id,p_store_id,v_employee.id,v_service) then
        v_all_qualified:=false; exit;
      end if;
    end loop;
    if v_all_qualified and public.v1361030_employee_free_for_slot(
      p_organization_id,p_store_id,v_employee.id,p_start_at,v_total_duration,p_visit_type,p_exclude_visit_id
    ) then
      v_common:=v_common||jsonb_build_array(jsonb_build_object(
        'id',v_employee.id,'name',v_employee.name,'position',v_employee.position,
        'employee_code',v_employee.employee_code,'availability_status',v_employee.availability_status,
        'availability_reason','整张订单技能 / 排班 / 时间冲突已验证'
      ));
    end if;
  end loop;

  -- Assistants do not need to satisfy stylist skill requirements, but must belong to the
  -- branch and be free for the order window. Reception/front desk remains excluded.
  for v_employee in
    select e.id,e.name,e.position,e.employee_code,e.availability_status,e.is_on_duty
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
    where e.organization_id=p_organization_id and es.store_id=p_store_id and es.status='active'
      and e.employment_status='active'
      and lower(coalesce(e.position,'')) not like '%reception%'
      and coalesce(e.position,'') not like '%前台%'
    order by e.name
  loop
    if public.v1361030_employee_free_for_slot(
      p_organization_id,p_store_id,v_employee.id,p_start_at,v_total_duration,p_visit_type,p_exclude_visit_id
    ) then
      v_assistants:=v_assistants||jsonb_build_array(jsonb_build_object(
        'id',v_employee.id,'name',v_employee.name,'position',v_employee.position,
        'employee_code',v_employee.employee_code,'availability_status',v_employee.availability_status,
        'availability_reason','排班 / 时间冲突已验证'
      ));
    end if;
  end loop;

  return jsonb_build_object(
    'ok',true,'validated',true,'start_at',p_start_at,'visit_type',p_visit_type,
    'total_duration_minutes',v_total_duration,'common',v_common,'by_service',v_by_service,'assistant_pool',v_assistants
  );
end;
$$;
revoke all on function public.v1361030_staff_pool_internal(uuid,uuid,uuid[],timestamptz,text,uuid) from public,anon,authenticated;

create or replace function public.v1361030_owner_staff_pool(
  p_store_id uuid,
  p_service_ids uuid[],
  p_start_at timestamptz,
  p_visit_type text default 'appointment',
  p_exclude_visit_id uuid default null
) returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare v_org uuid;
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  select s.organization_id into v_org from public.stores s where s.id=p_store_id and coalesce(s.status,'active')='active';
  if v_org is null or not public.can_access_store(p_store_id) then raise exception '门店权限无效。'; end if;
  return public.v1361030_staff_pool_internal(v_org,p_store_id,p_service_ids,p_start_at,p_visit_type,p_exclude_visit_id);
end;
$$;
revoke all on function public.v1361030_owner_staff_pool(uuid,uuid[],timestamptz,text,uuid) from public;
grant execute on function public.v1361030_owner_staff_pool(uuid,uuid[],timestamptz,text,uuid) to authenticated;

create or replace function public.v1361030_employee_staff_pool(
  p_session_token text,
  p_service_ids uuid[],
  p_start_at timestamptz,
  p_visit_type text default 'appointment',
  p_exclude_visit_id uuid default null
) returns jsonb
language plpgsql
stable
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_org uuid; v_store uuid;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  return public.v1361030_staff_pool_internal(v_org,v_store,p_service_ids,p_start_at,p_visit_type,p_exclude_visit_id);
end;
$$;
revoke all on function public.v1361030_employee_staff_pool(text,uuid[],timestamptz,text,uuid) from public;
grant execute on function public.v1361030_employee_staff_pool(text,uuid[],timestamptz,text,uuid) to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values('manual_booking_staff_integrity_version','13.6.10.30')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.6.10.30 MANUAL BOOKING STAFF INTEGRITY READY' as result,
  to_regprocedure('public.v1361030_owner_staff_pool(uuid,uuid[],timestamptz,text,uuid)') is not null as owner_pool_ok,
  to_regprocedure('public.v1361030_employee_staff_pool(text,uuid[],timestamptz,text,uuid)') is not null as employee_pool_ok;
