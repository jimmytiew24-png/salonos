begin;
set local statement_timeout='0';

-- SalonOS v13.6.10.35
-- WhatsApp Embedded Signup / multi-customer onboarding foundation.
-- This migration stores only connection metadata and audit events. Meta App Secret
-- remains in Supabase Edge Function Secrets and is never written to PostgreSQL.

alter table public.whatsapp_business_connections
  add column if not exists onboarding_method text not null default 'manual',
  add column if not exists embedded_signup_status text not null default 'not_started',
  add column if not exists meta_business_id text,
  add column if not exists embedded_signup_connected_at timestamptz,
  add column if not exists webhook_subscribed_at timestamptz,
  add column if not exists embedded_signup_last_error text;

alter table public.whatsapp_store_configs
  add column if not exists token_source text not null default 'manual',
  add column if not exists token_last_verified_at timestamptz;

do $$ begin
  if not exists (
    select 1 from pg_constraint
    where conname='whatsapp_business_connections_onboarding_method_check'
      and conrelid='public.whatsapp_business_connections'::regclass
  ) then
    alter table public.whatsapp_business_connections
      add constraint whatsapp_business_connections_onboarding_method_check
      check (onboarding_method in ('manual','embedded_signup'));
  end if;
  if not exists (
    select 1 from pg_constraint
    where conname='whatsapp_business_connections_embedded_status_check'
      and conrelid='public.whatsapp_business_connections'::regclass
  ) then
    alter table public.whatsapp_business_connections
      add constraint whatsapp_business_connections_embedded_status_check
      check (embedded_signup_status in ('not_started','connecting','connected','error','disconnected'));
  end if;
  if not exists (
    select 1 from pg_constraint
    where conname='whatsapp_store_configs_token_source_check'
      and conrelid='public.whatsapp_store_configs'::regclass
  ) then
    alter table public.whatsapp_store_configs
      add constraint whatsapp_store_configs_token_source_check
      check (token_source in ('manual','embedded_signup'));
  end if;
end $$;

create table if not exists public.whatsapp_embedded_signup_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  actor_user_id uuid,
  event_type text not null,
  status text not null,
  flow_type text,
  waba_id text,
  phone_number_id text,
  meta_business_id text,
  error_code text,
  error_message text,
  created_at timestamptz not null default now()
);

create index if not exists whatsapp_embedded_signup_events_store_created_idx
  on public.whatsapp_embedded_signup_events(organization_id,store_id,created_at desc);

alter table public.whatsapp_embedded_signup_events enable row level security;
drop policy if exists v136635_embedded_signup_events_read on public.whatsapp_embedded_signup_events;
create policy v136635_embedded_signup_events_read
on public.whatsapp_embedded_signup_events
for select to authenticated
using (
  public.has_organization_role(organization_id,array['owner','manager'])
  and public.can_access_store(store_id)
);
revoke all on public.whatsapp_embedded_signup_events from anon;
grant select on public.whatsapp_embedded_signup_events to authenticated;
grant all on public.whatsapp_embedded_signup_events to service_role;

create or replace function public.v136635_owner_whatsapp_embedded_signup_status(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  v_org uuid;
  v_row record;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id;
  if v_org is null then raise exception 'Store not found'; end if;
  if not public.has_organization_role(v_org,array['owner','manager']) or not public.can_access_store(p_store_id) then
    raise exception 'Not allowed';
  end if;

  select
    c.id as connection_id,
    c.phone_number_id,
    c.business_account_id,
    c.display_phone_number,
    c.enabled,
    c.connection_status,
    c.onboarding_method,
    c.embedded_signup_status,
    c.meta_business_id,
    c.embedded_signup_connected_at,
    c.webhook_subscribed_at,
    c.embedded_signup_last_error,
    x.auto_reply_enabled,
    x.graph_api_version,
    x.token_source,
    x.token_configured_at,
    x.token_last_verified_at,
    nullif(trim(coalesce(x.access_token,'')),'') is not null as token_configured,
    x.last_send_at,
    x.last_send_error
  into v_row
  from public.whatsapp_business_connections c
  left join public.whatsapp_store_configs x on x.connection_id=c.id
  where c.organization_id=v_org and c.store_id=p_store_id
  order by c.updated_at desc
  limit 1;

  if v_row.connection_id is null then
    return jsonb_build_object(
      'configured',false,
      'onboarding_method','manual',
      'embedded_signup_status','not_started',
      'token_configured',false
    );
  end if;
  return to_jsonb(v_row) || jsonb_build_object('configured',true);
end;
$$;
revoke all on function public.v136635_owner_whatsapp_embedded_signup_status(uuid) from public;
revoke all on function public.v136635_owner_whatsapp_embedded_signup_status(uuid) from anon;
grant execute on function public.v136635_owner_whatsapp_embedded_signup_status(uuid) to authenticated;

create or replace function public.v136635_owner_mark_whatsapp_manual_token(p_store_id uuid)
returns void
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare v_org uuid;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id;
  if v_org is null then raise exception 'Store not found'; end if;
  if not public.has_organization_role(v_org,array['owner','manager']) or not public.can_access_store(p_store_id) then raise exception 'Not allowed'; end if;
  update public.whatsapp_store_configs
  set token_source='manual',token_last_verified_at=null,updated_at=now()
  where organization_id=v_org and store_id=p_store_id;
  update public.whatsapp_business_connections
  set onboarding_method='manual',embedded_signup_status='not_started',embedded_signup_last_error=null,updated_at=now()
  where organization_id=v_org and store_id=p_store_id and enabled=true;
end;
$$;
revoke all on function public.v136635_owner_mark_whatsapp_manual_token(uuid) from public;
revoke all on function public.v136635_owner_mark_whatsapp_manual_token(uuid) from anon;
grant execute on function public.v136635_owner_mark_whatsapp_manual_token(uuid) to authenticated;

-- Existing connections stay manual. The Edge Function changes these values only
-- after a successful Embedded Signup code exchange + WABA webhook subscription.
update public.whatsapp_business_connections
set onboarding_method=coalesce(nullif(onboarding_method,''),'manual'),
    embedded_signup_status=coalesce(nullif(embedded_signup_status,''),'not_started')
where onboarding_method is null or onboarding_method='' or embedded_signup_status is null or embedded_signup_status='';

update public.whatsapp_store_configs
set token_source=coalesce(nullif(token_source,''),'manual')
where token_source is null or token_source='';

commit;

select
  to_regprocedure('public.v136635_owner_whatsapp_embedded_signup_status(uuid)') is not null as status_rpc_ok,
  to_regclass('public.whatsapp_embedded_signup_events') is not null as audit_table_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='whatsapp_business_connections' and column_name='onboarding_method') as connection_columns_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='whatsapp_store_configs' and column_name='token_source') as token_source_ok,
  'SalonOS v13.6.10.35 EMBEDDED SIGNUP FOUNDATION READY' as result;
