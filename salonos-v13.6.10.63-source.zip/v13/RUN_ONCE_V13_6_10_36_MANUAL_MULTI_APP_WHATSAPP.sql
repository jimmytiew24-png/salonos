begin;
set local statement_timeout='0';

-- SalonOS v13.6.10.36
-- Manual multi-customer WhatsApp Cloud API onboarding.
-- Customer Meta App secrets are stored in a service-role-only table so the
-- shared SalonOS webhook can validate each customer's X-Hub-Signature-256.

-- Include the small v13.6.10.35 metadata prerequisites so this migration can
-- be run directly on an older v13.6.10.34-style database as well.
alter table public.whatsapp_business_connections
  add column if not exists onboarding_method text not null default 'manual',
  add column if not exists embedded_signup_status text not null default 'not_started',
  add column if not exists meta_business_id text,
  add column if not exists embedded_signup_connected_at timestamptz,
  add column if not exists webhook_subscribed_at timestamptz,
  add column if not exists embedded_signup_last_error text,
  add column if not exists meta_app_id text,
  add column if not exists manual_setup_status text not null default 'not_started',
  add column if not exists manual_connected_at timestamptz,
  add column if not exists manual_last_error text;

alter table public.whatsapp_store_configs
  add column if not exists token_source text not null default 'manual',
  add column if not exists token_last_verified_at timestamptz;

do $$ begin
  if not exists (
    select 1 from pg_constraint
    where conname='whatsapp_business_connections_onboarding_method_check'
      and conrelid='public.whatsapp_business_connections'::regclass
  ) then
    alter table public.whatsapp_business_connections
      add constraint whatsapp_business_connections_onboarding_method_check
      check (onboarding_method in ('manual','embedded_signup'));
  end if;
  if not exists (
    select 1 from pg_constraint
    where conname='whatsapp_business_connections_embedded_status_check'
      and conrelid='public.whatsapp_business_connections'::regclass
  ) then
    alter table public.whatsapp_business_connections
      add constraint whatsapp_business_connections_embedded_status_check
      check (embedded_signup_status in ('not_started','connecting','connected','error','disconnected'));
  end if;
  if not exists (
    select 1 from pg_constraint
    where conname='whatsapp_store_configs_token_source_check'
      and conrelid='public.whatsapp_store_configs'::regclass
  ) then
    alter table public.whatsapp_store_configs
      add constraint whatsapp_store_configs_token_source_check
      check (token_source in ('manual','embedded_signup'));
  end if;
  if not exists (
    select 1 from pg_constraint
    where conname='whatsapp_business_connections_manual_setup_status_check'
      and conrelid='public.whatsapp_business_connections'::regclass
  ) then
    alter table public.whatsapp_business_connections
      add constraint whatsapp_business_connections_manual_setup_status_check
      check (manual_setup_status in ('not_started','credentials_valid','webhook_pending','webhook_verified','live','error','disconnected'));
  end if;
end $$;

create table if not exists public.whatsapp_connection_secrets (
  connection_id uuid primary key references public.whatsapp_business_connections(id) on delete cascade,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  meta_app_id text not null,
  meta_app_secret text not null,
  verify_token_hash text not null unique,
  verify_token_hint text,
  webhook_verified_at timestamptz,
  token_last_verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(organization_id,store_id)
);

create index if not exists whatsapp_connection_secrets_store_idx
  on public.whatsapp_connection_secrets(organization_id,store_id);

alter table public.whatsapp_connection_secrets enable row level security;
revoke all on public.whatsapp_connection_secrets from anon;
revoke all on public.whatsapp_connection_secrets from authenticated;
grant all on public.whatsapp_connection_secrets to service_role;

create table if not exists public.whatsapp_manual_connect_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  connection_id uuid references public.whatsapp_business_connections(id) on delete set null,
  actor_user_id uuid,
  event_type text not null,
  status text not null,
  meta_app_id text,
  waba_id text,
  phone_number_id text,
  error_message text,
  created_at timestamptz not null default now()
);
create index if not exists whatsapp_manual_connect_events_store_created_idx
  on public.whatsapp_manual_connect_events(organization_id,store_id,created_at desc);

alter table public.whatsapp_manual_connect_events enable row level security;
drop policy if exists v136636_manual_connect_events_read on public.whatsapp_manual_connect_events;
create policy v136636_manual_connect_events_read
on public.whatsapp_manual_connect_events
for select to authenticated
using (
  public.has_organization_role(organization_id,array['owner','manager'])
  and public.can_access_store(store_id)
);
revoke all on public.whatsapp_manual_connect_events from anon;
grant select on public.whatsapp_manual_connect_events to authenticated;
grant all on public.whatsapp_manual_connect_events to service_role;

create or replace function public.v136636_owner_whatsapp_manual_status(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  v_org uuid;
  v_row record;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id;
  if v_org is null then raise exception 'Store not found'; end if;
  if not public.has_organization_role(v_org,array['owner','manager']) or not public.can_access_store(p_store_id) then
    raise exception 'Not allowed';
  end if;

  select
    c.id as connection_id,
    c.phone_number_id,
    c.business_account_id,
    c.display_phone_number,
    c.enabled,
    c.connection_status,
    c.onboarding_method,
    c.meta_app_id,
    c.manual_setup_status,
    c.manual_connected_at,
    c.manual_last_error,
    x.auto_reply_enabled,
    x.graph_api_version,
    x.token_source,
    x.token_configured_at,
    x.token_last_verified_at,
    nullif(trim(coalesce(x.access_token,'')),'') is not null as token_configured,
    s.verify_token_hint,
    s.webhook_verified_at,
    nullif(trim(coalesce(s.meta_app_secret,'')),'') is not null as app_secret_configured,
    x.last_send_at,
    x.last_send_error
  into v_row
  from public.whatsapp_business_connections c
  left join public.whatsapp_store_configs x on x.connection_id=c.id
  left join public.whatsapp_connection_secrets s on s.connection_id=c.id
  where c.organization_id=v_org and c.store_id=p_store_id
  order by c.updated_at desc
  limit 1;

  if v_row.connection_id is null then
    return jsonb_build_object(
      'configured',false,
      'onboarding_method','manual',
      'manual_setup_status','not_started',
      'token_configured',false,
      'app_secret_configured',false
    );
  end if;
  return to_jsonb(v_row) || jsonb_build_object('configured',true);
end;
$$;
revoke all on function public.v136636_owner_whatsapp_manual_status(uuid) from public;
revoke all on function public.v136636_owner_whatsapp_manual_status(uuid) from anon;
grant execute on function public.v136636_owner_whatsapp_manual_status(uuid) to authenticated;

-- Preserve existing manual rows. They remain usable with the legacy global Meta
-- App Secret until the owner completes the new per-customer Manual Connect flow.
update public.whatsapp_business_connections
set manual_setup_status=coalesce(nullif(manual_setup_status,''),'not_started')
where manual_setup_status is null or manual_setup_status='';

commit;

select
  to_regclass('public.whatsapp_connection_secrets') is not null as secret_table_ok,
  to_regclass('public.whatsapp_manual_connect_events') is not null as audit_table_ok,
  to_regprocedure('public.v136636_owner_whatsapp_manual_status(uuid)') is not null as status_rpc_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='whatsapp_business_connections' and column_name='manual_setup_status') as connection_columns_ok,
  'SalonOS v13.6.10.36 MANUAL MULTI-APP WHATSAPP READY' as result;
