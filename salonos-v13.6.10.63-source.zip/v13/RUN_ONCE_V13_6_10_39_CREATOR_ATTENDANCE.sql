-- SalonOS v13.6.10.39 · Creator simplicity + RM300 pricing + QR attendance
-- Run once in Supabase SQL Editor. Additive/idempotent; no business history is deleted.

create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------------------
-- Subscription pricing: RM300/month, keep the existing annual / 2-year ratio.
-- ---------------------------------------------------------------------------
create or replace function public.salonos_plan_amount(p_plan text)
returns numeric language sql immutable as $$
  select case lower(coalesce(p_plan,''))
    when 'annual' then 3000::numeric
    when 'biennial' then 6000::numeric
    else 300::numeric
  end;
$$;

-- Creator only chooses owner + plan. Customer supplies branch name/email while redeeming.
create or replace function public.creator_generate_branch_code(
  p_organization_id uuid,
  p_plan_code text default 'monthly'
)
returns table(code text, expires_at timestamptz, amount_rm numeric, billing_months integer)
language plpgsql security definer set search_path=public,extensions as $$
declare
  v_code text;
  v_exp timestamptz:=now()+interval '5 minutes';
  v_amount numeric;
  v_months integer;
begin
  if auth.uid() is null or not public.is_creator_admin() then raise exception 'Creator permission required'; end if;
  if not exists(select 1 from public.organizations where id=p_organization_id) then raise exception 'Organization not found'; end if;
  if lower(coalesce(p_plan_code,'')) not in ('monthly','annual','biennial') then raise exception 'Invalid plan'; end if;
  v_code:=public.salonos_new_code('BRN');
  v_amount:=public.salonos_plan_amount(p_plan_code);
  v_months:=public.salonos_plan_months(p_plan_code);
  insert into public.saas_activation_codes(
    purpose,code_hash,code_hint,label,target_organization_id,target_email,plan_code,amount_rm,billing_months,status,expires_at,created_by
  ) values (
    'branch_signup',encode(digest(upper(v_code),'sha256'),'hex'),right(v_code,4),null,p_organization_id,null,
    lower(p_plan_code),v_amount,v_months,'pending',v_exp,auth.uid()
  );
  insert into public.creator_audit_logs(creator_user_id,organization_id,action_name,detail)
  values(auth.uid(),p_organization_id,'branch_code.generated','customer will provide branch profile · '||lower(p_plan_code));
  return query select v_code,v_exp,v_amount,v_months;
end; $$;
revoke all on function public.creator_generate_branch_code(uuid,text) from public;
grant execute on function public.creator_generate_branch_code(uuid,text) to authenticated;

-- ---------------------------------------------------------------------------
-- Attendance data model
-- ---------------------------------------------------------------------------
alter table public.employees add column if not exists availability_status text not null default 'off_duty';

create table if not exists public.employee_attendance_settings(
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  enabled boolean not null default true,
  scheduled_start_time time not null default time '09:00',
  scheduled_end_time time not null default time '18:00',
  late_grace_minutes integer not null default 10 check(late_grace_minutes between 0 and 240),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(store_id,employee_id)
);

create table if not exists public.employee_attendance_days(
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  work_date date not null,
  scheduled_start_time_snapshot time not null,
  scheduled_end_time_snapshot time not null,
  late_grace_minutes_snapshot integer not null default 10,
  clock_in_at timestamptz,
  clock_out_at timestamptz,
  arrival_status text check(arrival_status is null or arrival_status in ('on_time','late')),
  clock_in_source text,
  clock_out_source text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(store_id,employee_id,work_date)
);

create table if not exists public.employee_attendance_qr_challenges(
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  qr_action text not null check(qr_action in ('in','out')),
  token_hash text not null unique,
  valid_from timestamptz not null default now(),
  expires_at timestamptz not null,
  created_by_user uuid,
  created_by_employee uuid references public.employees(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists idx_attendance_day_store_date on public.employee_attendance_days(store_id,work_date,employee_id);
create index if not exists idx_attendance_qr_expiry on public.employee_attendance_qr_challenges(store_id,expires_at desc);

alter table public.employee_attendance_settings enable row level security;
alter table public.employee_attendance_days enable row level security;
alter table public.employee_attendance_qr_challenges enable row level security;
revoke all on public.employee_attendance_settings from anon,authenticated;
revoke all on public.employee_attendance_days from anon,authenticated;
revoke all on public.employee_attendance_qr_challenges from anon,authenticated;

insert into public.employee_attendance_settings(organization_id,store_id,employee_id,enabled)
select es.organization_id,es.store_id,es.employee_id,true
from public.employee_stores es join public.employees e on e.id=es.employee_id and e.organization_id=es.organization_id
where es.status='active' and e.employment_status='active'
on conflict(store_id,employee_id) do nothing;

-- Starting with attendance enabled, nobody is physically present until they scan IN.
update public.employees e set is_on_duty=false, availability_status='off_duty', updated_at=now()
where e.employment_status='active';

-- ---------------------------------------------------------------------------
-- Owner attendance settings
-- ---------------------------------------------------------------------------
create or replace function public.v1361039_owner_save_attendance_setting(
  p_store_id uuid,p_employee_id uuid,p_enabled boolean,p_start_time time,p_end_time time,p_late_grace_minutes integer
) returns jsonb language plpgsql security definer set search_path=public as $$
declare v_org uuid;
begin
  select organization_id into v_org from public.stores where id=p_store_id and status='active';
  if v_org is null or not public.can_access_store(p_store_id) or not public.has_organization_role(v_org,array['owner','manager']) then
    raise exception '你没有管理员工打卡规则的权限。';
  end if;
  if not exists(select 1 from public.employee_stores es join public.employees e on e.id=es.employee_id
                where es.organization_id=v_org and es.store_id=p_store_id and es.employee_id=p_employee_id and es.status='active' and e.employment_status='active') then
    raise exception '员工不属于当前分行或已停用。';
  end if;
  insert into public.employee_attendance_settings(organization_id,store_id,employee_id,enabled,scheduled_start_time,scheduled_end_time,late_grace_minutes,updated_at)
  values(v_org,p_store_id,p_employee_id,coalesce(p_enabled,true),coalesce(p_start_time,time '09:00'),coalesce(p_end_time,time '18:00'),least(240,greatest(0,coalesce(p_late_grace_minutes,10))),now())
  on conflict(store_id,employee_id) do update set enabled=excluded.enabled,scheduled_start_time=excluded.scheduled_start_time,
    scheduled_end_time=excluded.scheduled_end_time,late_grace_minutes=excluded.late_grace_minutes,updated_at=now();
  return jsonb_build_object('ok',true);
end; $$;
revoke all on function public.v1361039_owner_save_attendance_setting(uuid,uuid,boolean,time,time,integer) from public;
grant execute on function public.v1361039_owner_save_attendance_setting(uuid,uuid,boolean,time,time,integer) to authenticated;

-- ---------------------------------------------------------------------------
-- Rotating QR: 15-second refresh, server-side expiry 20 seconds.
-- ---------------------------------------------------------------------------
create or replace function public.v1361039_owner_attendance_qr(p_store_id uuid,p_action text)
returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_org uuid; v_raw text; v_exp timestamptz:=now()+interval '20 seconds'; v_action text:=lower(coalesce(p_action,''));
begin
  if v_action not in ('in','out') then raise exception '无效的打卡二维码类型。'; end if;
  select organization_id into v_org from public.stores where id=p_store_id and status='active';
  if v_org is null or not public.can_access_store(p_store_id) or not public.has_organization_role(v_org,array['owner','manager']) then raise exception '没有显示打卡二维码的权限。'; end if;
  v_raw:='ATT-'||upper(encode(gen_random_bytes(18),'hex'));
  insert into public.employee_attendance_qr_challenges(organization_id,store_id,qr_action,token_hash,expires_at,created_by_user)
  values(v_org,p_store_id,v_action,encode(digest(v_raw,'sha256'),'hex'),v_exp,auth.uid());
  delete from public.employee_attendance_qr_challenges where expires_at<now()-interval '10 minutes';
  return jsonb_build_object('token',v_raw,'action',v_action,'expires_at',v_exp,'refresh_after_seconds',15);
end; $$;
revoke all on function public.v1361039_owner_attendance_qr(uuid,text) from public;
grant execute on function public.v1361039_owner_attendance_qr(uuid,text) to authenticated;

create or replace function public.v1361039_employee_attendance_qr(p_session_token text,p_action text)
returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_ctx jsonb; v_org uuid; v_store uuid; v_employee uuid; v_role text; v_raw text; v_exp timestamptz:=now()+interval '20 seconds'; v_action text:=lower(coalesce(p_action,''));
begin
  if v_action not in ('in','out') then raise exception '无效的打卡二维码类型。'; end if;
  v_ctx:=public.employee_session_context(p_session_token); v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid;
  v_employee:=(v_ctx->>'employee_id')::uuid; v_role:=coalesce(v_ctx->>'employee_role','staff');
  if v_role not in ('manager','receptionist') then raise exception '只有经理或前台可以显示门店打卡二维码。'; end if;
  v_raw:='ATT-'||upper(encode(gen_random_bytes(18),'hex'));
  insert into public.employee_attendance_qr_challenges(organization_id,store_id,qr_action,token_hash,expires_at,created_by_employee)
  values(v_org,v_store,v_action,encode(digest(v_raw,'sha256'),'hex'),v_exp,v_employee);
  delete from public.employee_attendance_qr_challenges where expires_at<now()-interval '10 minutes';
  return jsonb_build_object('token',v_raw,'action',v_action,'expires_at',v_exp,'refresh_after_seconds',15);
end; $$;
revoke all on function public.v1361039_employee_attendance_qr(text,text) from public;
grant execute on function public.v1361039_employee_attendance_qr(text,text) to anon,authenticated;

-- ---------------------------------------------------------------------------
-- Employee scans the rotating QR to clock IN / OUT.
-- ---------------------------------------------------------------------------
create or replace function public.v1361039_employee_clock(p_session_token text,p_qr_token text)
returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare
  v_ctx jsonb; v_org uuid; v_store uuid; v_employee uuid; v_ch record; v_setting record; v_day record;
  v_today date:=(now() at time zone 'Asia/Kuala_Lumpur')::date;
  v_local_now timestamp:=now() at time zone 'Asia/Kuala_Lumpur';
  v_late boolean; v_threshold timestamp;
begin
  v_ctx:=public.employee_session_context(p_session_token); v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid; v_employee:=(v_ctx->>'employee_id')::uuid;
  select * into v_ch from public.employee_attendance_qr_challenges q
   where q.organization_id=v_org and q.store_id=v_store and q.token_hash=encode(digest(trim(coalesce(p_qr_token,'')),'sha256'),'hex')
     and q.valid_from<=now() and q.expires_at>=now() order by q.created_at desc limit 1;
  if v_ch.id is null then raise exception '二维码已过期，请扫描柜台当前显示的新二维码。'; end if;
  select * into v_setting from public.employee_attendance_settings s where s.organization_id=v_org and s.store_id=v_store and s.employee_id=v_employee limit 1;
  if v_setting.id is null then
    insert into public.employee_attendance_settings(organization_id,store_id,employee_id) values(v_org,v_store,v_employee) returning * into v_setting;
  end if;
  if not coalesce(v_setting.enabled,true) then raise exception '你的打卡规则目前已由老板停用。'; end if;
  select * into v_day from public.employee_attendance_days d where d.store_id=v_store and d.employee_id=v_employee and d.work_date=v_today for update;
  if v_ch.qr_action='in' then
    if v_day.id is not null and v_day.clock_in_at is not null and v_day.clock_out_at is null then
      return jsonb_build_object('ok',true,'status','working','message','你今天已经打过上班卡。','clock_in_at',v_day.clock_in_at);
    end if;
    if v_day.id is not null and v_day.clock_out_at is not null then raise exception '你今天已经完成下班打卡；如需重新上班请让老板处理。'; end if;
    v_threshold:=v_today::timestamp+v_setting.scheduled_start_time+make_interval(mins=>v_setting.late_grace_minutes);
    v_late:=v_local_now>v_threshold;
    insert into public.employee_attendance_days(organization_id,store_id,employee_id,work_date,scheduled_start_time_snapshot,scheduled_end_time_snapshot,late_grace_minutes_snapshot,clock_in_at,arrival_status,clock_in_source,updated_at)
    values(v_org,v_store,v_employee,v_today,v_setting.scheduled_start_time,v_setting.scheduled_end_time,v_setting.late_grace_minutes,now(),case when v_late then 'late' else 'on_time' end,'rotating_qr',now())
    on conflict(store_id,employee_id,work_date) do update set clock_in_at=excluded.clock_in_at,clock_out_at=null,arrival_status=excluded.arrival_status,clock_in_source='rotating_qr',updated_at=now();
    update public.employees set is_on_duty=true,availability_status='available',updated_at=now() where id=v_employee and organization_id=v_org and employment_status='active';
    return jsonb_build_object('ok',true,'status',case when v_late then 'working_late' else 'working' end,'late',v_late,'message',case when v_late then '上班打卡成功 · 系统已记录迟到。' else '上班打卡成功。' end,'clock_in_at',now());
  else
    if v_day.id is null or v_day.clock_in_at is null then raise exception '今天还没有上班打卡，不能直接下班。'; end if;
    if v_day.clock_out_at is not null then return jsonb_build_object('ok',true,'status','clocked_out','message','你今天已经完成下班打卡。','clock_out_at',v_day.clock_out_at); end if;
    update public.employee_attendance_days set clock_out_at=now(),clock_out_source='rotating_qr',updated_at=now() where id=v_day.id;
    update public.employees set is_on_duty=false,availability_status='off_duty',updated_at=now() where id=v_employee and organization_id=v_org;
    return jsonb_build_object('ok',true,'status','clocked_out','message','下班打卡成功。','clock_out_at',now());
  end if;
end; $$;
revoke all on function public.v1361039_employee_clock(text,text) from public;
grant execute on function public.v1361039_employee_clock(text,text) to anon,authenticated;

-- ---------------------------------------------------------------------------
-- Shared snapshot builders
-- ---------------------------------------------------------------------------
create or replace function public.v1361039_attendance_rows(p_org uuid,p_store uuid,p_only_employee uuid default null)
returns jsonb language sql stable security definer set search_path=public as $$
  with local_now as (select now() at time zone 'Asia/Kuala_Lumpur' n),
  rows as (
    select e.id employee_id,e.name,e.position,e.app_role,e.employment_status,e.is_on_duty,e.availability_status,
      coalesce(s.enabled,true) attendance_enabled,coalesce(s.scheduled_start_time,time '09:00') scheduled_start_time,
      coalesce(s.scheduled_end_time,time '18:00') scheduled_end_time,coalesce(s.late_grace_minutes,10) late_grace_minutes,
      d.clock_in_at,d.clock_out_at,d.arrival_status,
      case
        when not coalesce(s.enabled,true) then 'attendance_disabled'
        when d.clock_out_at is not null then 'clocked_out'
        when d.clock_in_at is not null and d.arrival_status='late' then 'working_late'
        when d.clock_in_at is not null then 'working'
        when (select n from local_now) > ((select n::date from local_now)::timestamp + coalesce(s.scheduled_start_time,time '09:00') + make_interval(mins=>coalesce(s.late_grace_minutes,10))) then 'not_arrived'
        else 'not_clocked_in'
      end attendance_status,
      (d.clock_in_at is not null and d.clock_out_at is null and coalesce(e.is_on_duty,false)
       and lower(coalesce(e.availability_status,'available')) not in ('break','off_duty','in_service','busy','disabled','inactive')) can_assign_walkin
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id and es.store_id=p_store and es.status='active'
    left join public.employee_attendance_settings s on s.organization_id=e.organization_id and s.store_id=p_store and s.employee_id=e.id
    left join public.employee_attendance_days d on d.organization_id=e.organization_id and d.store_id=p_store and d.employee_id=e.id and d.work_date=(now() at time zone 'Asia/Kuala_Lumpur')::date
    where e.organization_id=p_org and e.employment_status='active' and (p_only_employee is null or e.id=p_only_employee)
    order by e.name
  ) select coalesce(jsonb_agg(to_jsonb(rows)),'[]'::jsonb) from rows;
$$;
revoke all on function public.v1361039_attendance_rows(uuid,uuid,uuid) from public,anon,authenticated;

create or replace function public.v1361039_owner_attendance_snapshot(p_store_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_rows jsonb;
begin
  select organization_id into v_org from public.stores where id=p_store_id and status='active';
  if v_org is null or not public.can_access_store(p_store_id) or not public.has_organization_role(v_org,array['owner','manager']) then raise exception '没有查看打卡状态的权限。'; end if;
  v_rows:=public.v1361039_attendance_rows(v_org,p_store_id,null);
  return jsonb_build_object('store_id',p_store_id,'timezone','Asia/Kuala_Lumpur','employees',v_rows,'server_time',now());
end; $$;
revoke all on function public.v1361039_owner_attendance_snapshot(uuid) from public;
grant execute on function public.v1361039_owner_attendance_snapshot(uuid) to authenticated;

create or replace function public.v1361039_employee_attendance_snapshot(p_session_token text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_ctx jsonb; v_org uuid; v_store uuid; v_employee uuid; v_role text; v_self jsonb; v_staff jsonb:='[]'::jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token); v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid; v_employee:=(v_ctx->>'employee_id')::uuid; v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_self:=public.v1361039_attendance_rows(v_org,v_store,v_employee);
  if v_role in ('manager','receptionist') then v_staff:=public.v1361039_attendance_rows(v_org,v_store,null); end if;
  return jsonb_build_object('context',v_ctx,'timezone','Asia/Kuala_Lumpur','self',v_self,'employees',v_staff,'can_display_qr',v_role in ('manager','receptionist'),'server_time',now());
end; $$;
revoke all on function public.v1361039_employee_attendance_snapshot(text) from public;
grant execute on function public.v1361039_employee_attendance_snapshot(text) to anon,authenticated;

-- New/re-enabled employees start physically OFF until they scan the IN QR.
create or replace function public.v13_save_employee(
  p_store_id uuid,p_employee_id uuid,p_name text,p_phone text,p_position text,p_age integer,p_gender text,p_skill_tags text,p_base_salary numeric,p_joined_at date,p_app_role text
) returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_org uuid; v_id uuid:=p_employee_id; v_phone text:=regexp_replace(coalesce(p_phone,''),'[^0-9]','','g'); v_code text;
begin
 select s.organization_id into v_org from public.stores s where s.id=p_store_id and s.status='active';
 if v_org is null then raise exception '找不到 active 门店。'; end if;
 if not public.has_organization_role(v_org,array['owner','manager']) or not public.can_access_store(p_store_id) then raise exception '你没有管理员工的权限。'; end if;
 if trim(coalesce(p_name,''))='' or trim(coalesce(p_position,''))='' then raise exception '员工姓名和职位必填。'; end if;
 if length(v_phone)<8 then raise exception '请输入有效的员工手机号。'; end if;
 if exists(select 1 from public.employees e where regexp_replace(coalesce(e.phone,''),'[^0-9]','','g')=v_phone and (v_id is null or e.id<>v_id)) then raise exception '这个手机号码已经属于另一位员工。'; end if;
 if v_id is null then
   v_id:=gen_random_uuid(); v_code:='EMP-'||upper(substr(replace(v_id::text,'-',''),1,8));
   insert into public.employees(id,organization_id,primary_store_id,employee_code,name,phone,position,age,gender,skill_tags,app_role,is_on_duty,availability_status,employment_status,joined_at,created_at,updated_at)
   values(v_id,v_org,p_store_id,v_code,trim(p_name),v_phone,trim(p_position),p_age,case when p_gender in ('male','female','unspecified') then p_gender else 'unspecified' end,nullif(trim(coalesce(p_skill_tags,'')),''),case when p_app_role in ('manager','receptionist','accountant','stylist','assistant','staff') then p_app_role else 'staff' end,false,'off_duty','active',coalesce(p_joined_at,current_date),now(),now());
 else
   update public.employees e set primary_store_id=p_store_id,name=trim(p_name),phone=v_phone,position=trim(p_position),age=p_age,gender=case when p_gender in ('male','female','unspecified') then p_gender else 'unspecified' end,skill_tags=nullif(trim(coalesce(p_skill_tags,'')),''),app_role=case when p_app_role in ('manager','receptionist','accountant','stylist','assistant','staff') then p_app_role else 'staff' end,joined_at=coalesce(p_joined_at,e.joined_at),updated_at=now() where e.id=v_id and e.organization_id=v_org;
   if not found then raise exception '找不到员工资料。'; end if;
 end if;
 insert into public.employee_stores(organization_id,employee_id,store_id,is_primary,status) values(v_org,v_id,p_store_id,true,'active') on conflict(employee_id,store_id) do update set is_primary=true,status='active',updated_at=now();
 insert into public.employee_compensation(organization_id,employee_id,base_salary,default_commission_rate,effective_from,created_at,updated_at) values(v_org,v_id,greatest(coalesce(p_base_salary,0),0),0,coalesce(p_joined_at,current_date),now(),now()) on conflict(employee_id) do update set base_salary=excluded.base_salary,effective_from=excluded.effective_from,updated_at=now();
 insert into public.employee_attendance_settings(organization_id,store_id,employee_id) values(v_org,p_store_id,v_id) on conflict(store_id,employee_id) do nothing;
 return jsonb_build_object('employee_id',v_id);
end; $$;
revoke all on function public.v13_save_employee(uuid,uuid,text,text,text,integer,text,text,numeric,date,text) from public;
grant execute on function public.v13_save_employee(uuid,uuid,text,text,text,integer,text,text,numeric,date,text) to authenticated;

create or replace function public.v13_toggle_employee(p_employee_id uuid,p_target_status text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_target text:=case when p_target_status='active' then 'active' else 'inactive' end;
begin
 select e.organization_id into v_org from public.employees e where e.id=p_employee_id;
 if v_org is null then raise exception '找不到员工资料。'; end if;
 if not public.has_organization_role(v_org,array['owner','manager']) then raise exception '你没有修改员工状态的权限。'; end if;
 if v_target='inactive' then
   update public.employees set employment_status='inactive',is_on_duty=false,availability_status='off_duty',left_at=current_date,updated_at=now() where id=p_employee_id;
   update public.employee_login_sessions set revoked_at=coalesce(revoked_at,now()) where employee_id=p_employee_id and revoked_at is null;
   return jsonb_build_object('message','员工已停用；手机号登录立即失效，历史资料全部保留。');
 else
   update public.employees set employment_status='active',is_on_duty=false,availability_status='off_duty',left_at=null,updated_at=now() where id=p_employee_id;
   return jsonb_build_object('message','员工账号已重新启用；请到店扫描上班二维码后才会进入可接单状态。');
 end if;
end; $$;
revoke all on function public.v13_toggle_employee(uuid,text) from public;
grant execute on function public.v13_toggle_employee(uuid,text) to authenticated;

-- Walk-in assignment now requires today's open attendance when tracking is enabled.
create or replace function public.v1361030_employee_free_for_slot(
  p_organization_id uuid,
  p_store_id uuid,
  p_employee_id uuid,
  p_start_at timestamptz,
  p_duration_minutes integer,
  p_visit_type text default 'appointment',
  p_exclude_visit_id uuid default null
) returns boolean
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_employee record;
  v_schedule record;
  v_timezone text:='Asia/Kuala_Lumpur';
  v_start_local timestamp;
  v_end_local timestamp;
  v_duration integer:=greatest(coalesce(p_duration_minutes,30),1);
  v_shift_start timestamp;
  v_shift_end timestamp;
  v_break_start timestamp;
  v_break_end timestamp;
  v_visit_type text:=case when lower(coalesce(p_visit_type,''))='walk_in' then 'walk_in' else 'appointment' end;
begin
  if p_start_at is null then return false; end if;

  select e.id,e.name,e.position,e.is_on_duty,e.availability_status,e.employment_status
  into v_employee
  from public.employees e
  where e.id=p_employee_id
    and e.organization_id=p_organization_id
    and e.employment_status='active'
    and exists(
      select 1 from public.employee_stores es
      where es.organization_id=p_organization_id
        and es.store_id=p_store_id
        and es.employee_id=e.id
        and es.status='active'
    );
  if v_employee.id is null then return false; end if;

  select coalesce(nullif(b.timezone,''),'Asia/Kuala_Lumpur') into v_timezone
  from public.whatsapp_ai_booking_settings b
  where b.organization_id=p_organization_id and b.store_id=p_store_id and b.active=true
  limit 1;
  v_timezone:=coalesce(v_timezone,'Asia/Kuala_Lumpur');
  v_start_local:=p_start_at at time zone v_timezone;
  v_end_local:=v_start_local+make_interval(mins=>v_duration);

  -- Live Service Board status applies to a walk-in happening now. Future appointments
  -- must NOT depend on whether the employee happens to be on duty at the moment this
  -- booking is created; their schedule for the requested date/time is the source of truth.
  if v_visit_type='walk_in' then
    -- v13.6.10.39: attendance is the physical-presence source of truth for walk-ins.
    -- If attendance tracking is enabled for this employee, an open clock-in for the
    -- requested local work date is required; a stale/manual is_on_duty flag cannot bypass it.
    if coalesce((select s.enabled from public.employee_attendance_settings s
                 where s.organization_id=p_organization_id and s.store_id=p_store_id and s.employee_id=p_employee_id limit 1),true) then
      if not exists(
        select 1 from public.employee_attendance_days ad
        where ad.organization_id=p_organization_id and ad.store_id=p_store_id and ad.employee_id=p_employee_id
          and ad.work_date=v_start_local::date and ad.clock_in_at is not null and ad.clock_out_at is null
      ) then return false; end if;
    end if;
    if not coalesce(v_employee.is_on_duty,false) then return false; end if;
    if lower(coalesce(v_employee.availability_status,'available')) in
       ('break','off_duty','in_service','busy','disabled','inactive') then
      return false;
    end if;
  end if;

  select * into v_schedule
  from public.whatsapp_ai_employee_schedules x
  where x.organization_id=p_organization_id
    and x.store_id=p_store_id
    and x.employee_id=p_employee_id
    and x.iso_weekday=extract(isodow from v_start_local)::int
  limit 1;

  if v_schedule.id is not null then
    if not coalesce(v_schedule.is_working,false) or v_schedule.start_time is null or v_schedule.end_time is null then
      return false;
    end if;
    v_shift_start:=v_start_local::date::timestamp+v_schedule.start_time;
    v_shift_end:=v_start_local::date::timestamp+v_schedule.end_time;
    if v_shift_end<=v_shift_start then v_shift_end:=v_shift_end+interval '1 day'; end if;
    if v_schedule.break_start is not null and v_schedule.break_end is not null then
      v_break_start:=v_start_local::date::timestamp+v_schedule.break_start;
      v_break_end:=v_start_local::date::timestamp+v_schedule.break_end;
      if v_break_end<=v_break_start then v_break_end:=v_break_end+interval '1 day'; end if;
    end if;
  else
    -- Same fallback as the Service Board / WhatsApp unified pool.
    v_shift_start:=v_start_local::date::timestamp+time '09:00';
    v_shift_end:=(v_start_local::date+1)::timestamp;
    v_break_start:=null; v_break_end:=null;
  end if;

  if v_start_local<v_shift_start or v_end_local>v_shift_end then return false; end if;
  if v_break_start is not null and v_break_end is not null
     and v_start_local<v_break_end and v_end_local>v_break_start then return false; end if;

  -- Visit status is the occupancy truth. Cancelled / no-show / completed visits are
  -- intentionally absent, so cancelling a visit releases the slot without deleting
  -- historical visit_service_workers rows.
  if exists(
    select 1
    from public.visits v
    where v.organization_id=p_organization_id
      and v.store_id=p_store_id
      and v.status in ('booked','arrived','waiting','in_service','paused','ready_for_checkout')
      and (p_exclude_visit_id is null or v.id<>p_exclude_visit_id)
      and exists(
        select 1
        from public.visit_service_items si
        join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
        where si.visit_id=v.id
          and si.organization_id=p_organization_id
          and si.store_id=p_store_id
          and si.status<>'cancelled'
          and w.employee_id=p_employee_id
      )
      and (coalesce(v.scheduled_at,v.started_at,v.arrived_at,v.created_at) at time zone v_timezone) < v_end_local
      and (
        (coalesce(v.scheduled_at,v.started_at,v.arrived_at,v.created_at) at time zone v_timezone)
        + make_interval(mins=>greatest(30,coalesce((
          select sum(greatest(coalesce(si2.estimated_minutes_snapshot,30),1))::int
          from public.visit_service_items si2
          where si2.visit_id=v.id
            and si2.organization_id=p_organization_id
            and si2.store_id=p_store_id
            and si2.status<>'cancelled'
            and exists(
              select 1 from public.visit_service_workers w2
              where w2.service_item_id=si2.id
                and w2.employee_id=p_employee_id
                and w2.status='active'
            )
        ),30)))
      ) > v_start_local
  ) then return false; end if;

  return true;
end;
$$;

revoke all on function public.v1361030_employee_free_for_slot(uuid,uuid,uuid,timestamptz,integer,text,uuid) from public,anon,authenticated;


-- Contract check
create or replace function public.v1361039_attendance_contract_status()
returns jsonb language sql stable security definer set search_path=public as $$
select jsonb_build_object(
 'settings_table',to_regclass('public.employee_attendance_settings') is not null,
 'days_table',to_regclass('public.employee_attendance_days') is not null,
 'qr_table',to_regclass('public.employee_attendance_qr_challenges') is not null,
 'monthly_price',public.salonos_plan_amount('monthly'),
 'annual_price',public.salonos_plan_amount('annual'),
 'biennial_price',public.salonos_plan_amount('biennial')
); $$;
revoke all on function public.v1361039_attendance_contract_status() from public;
grant execute on function public.v1361039_attendance_contract_status() to authenticated;

notify pgrst,'reload schema';
select 'SalonOS v13.6.10.39 CREATOR + ATTENDANCE READY' as result,
       public.salonos_plan_amount('monthly') as monthly_rm,
       to_regclass('public.employee_attendance_days') is not null as attendance_ok;
