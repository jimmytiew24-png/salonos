-- SalonOS v13.6.10.49 · Leave requests + appointment attendance decoupling
-- Run once in Supabase SQL Editor after uploading the v13.6.10.49 files.

begin;

create table if not exists public.employee_leave_requests(
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  start_date date not null,
  end_date date not null,
  reason text not null,
  status text not null default 'pending',
  employee_note text,
  manager_note text,
  requested_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid,
  cancelled_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint employee_leave_date_order check(end_date>=start_date),
  constraint employee_leave_status_check check(status in ('pending','approved','rejected','cancelled'))
);
create index if not exists idx_employee_leave_store_status_dates on public.employee_leave_requests(store_id,status,start_date,end_date);
create index if not exists idx_employee_leave_employee_dates on public.employee_leave_requests(employee_id,start_date desc,end_date desc);
alter table public.employee_leave_requests enable row level security;
revoke all on public.employee_leave_requests from anon,authenticated;

create or replace function public.v1361049_employee_submit_leave(
  p_session_token text,p_start_date date,p_end_date date,p_reason text
) returns jsonb language plpgsql security definer set search_path=public as $$
declare v_ctx jsonb; v_org uuid; v_store uuid; v_employee uuid; v_id uuid; v_today date:=(now() at time zone 'Asia/Kuala_Lumpur')::date;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid; v_employee:=(v_ctx->>'employee_id')::uuid;
  if p_start_date is null or p_end_date is null or p_end_date<p_start_date then raise exception '请选择正确的请假日期。'; end if;
  if p_start_date<v_today then raise exception '不能提交过去日期的请假申请。'; end if;
  if p_end_date>p_start_date+interval '90 days' then raise exception '单次请假最长 90 天。'; end if;
  if length(trim(coalesce(p_reason,'')))<2 then raise exception '请填写请假原因。'; end if;
  if exists(select 1 from public.employee_leave_requests r where r.organization_id=v_org and r.store_id=v_store and r.employee_id=v_employee and r.status in ('pending','approved') and daterange(r.start_date,r.end_date,'[]') && daterange(p_start_date,p_end_date,'[]')) then
    raise exception '这个日期范围已经有待审批或已批准的请假。';
  end if;
  insert into public.employee_leave_requests(organization_id,store_id,employee_id,start_date,end_date,reason,status)
  values(v_org,v_store,v_employee,p_start_date,p_end_date,trim(p_reason),'pending') returning id into v_id;
  return jsonb_build_object('ok',true,'request_id',v_id,'status','pending','message','请假申请已提交，等待老板审批。');
end; $$;
revoke all on function public.v1361049_employee_submit_leave(text,date,date,text) from public;
grant execute on function public.v1361049_employee_submit_leave(text,date,date,text) to anon,authenticated;

create or replace function public.v1361049_employee_leave_requests(p_session_token text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_ctx jsonb; v_org uuid; v_store uuid; v_employee uuid; v_rows jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid; v_employee:=(v_ctx->>'employee_id')::uuid;
  select coalesce(jsonb_agg(to_jsonb(x) order by x.start_date desc,x.requested_at desc),'[]'::jsonb) into v_rows
  from (select id,start_date,end_date,reason,status,manager_note,requested_at,reviewed_at from public.employee_leave_requests where organization_id=v_org and store_id=v_store and employee_id=v_employee order by start_date desc,requested_at desc limit 30) x;
  return jsonb_build_object('ok',true,'requests',v_rows);
end; $$;
revoke all on function public.v1361049_employee_leave_requests(text) from public;
grant execute on function public.v1361049_employee_leave_requests(text) to anon,authenticated;

create or replace function public.v1361049_employee_cancel_leave(p_session_token text,p_request_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_ctx jsonb; v_org uuid; v_store uuid; v_employee uuid;
begin
  v_ctx:=public.employee_session_context(p_session_token); v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid; v_employee:=(v_ctx->>'employee_id')::uuid;
  update public.employee_leave_requests set status='cancelled',cancelled_at=now(),updated_at=now() where id=p_request_id and organization_id=v_org and store_id=v_store and employee_id=v_employee and status='pending';
  if not found then raise exception '只有待审批的请假申请可以撤回。'; end if;
  return jsonb_build_object('ok',true,'status','cancelled','message','请假申请已撤回。');
end; $$;
revoke all on function public.v1361049_employee_cancel_leave(text,uuid) from public;
grant execute on function public.v1361049_employee_cancel_leave(text,uuid) to anon,authenticated;

create or replace function public.v1361049_owner_leave_requests(p_store_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_rows jsonb;
begin
  select organization_id into v_org from public.stores where id=p_store_id and status='active';
  if v_org is null or not public.can_access_store(p_store_id) or not public.has_organization_role(v_org,array['owner']) then raise exception '只有老板可以审批请假申请。'; end if;
  select coalesce(jsonb_agg(to_jsonb(x) order by case x.status when 'pending' then 0 else 1 end,x.start_date,x.requested_at desc),'[]'::jsonb) into v_rows
  from (select r.id,r.employee_id,e.name employee_name,e.position,r.start_date,r.end_date,r.reason,r.status,r.manager_note,r.requested_at,r.reviewed_at from public.employee_leave_requests r join public.employees e on e.id=r.employee_id and e.organization_id=r.organization_id where r.organization_id=v_org and r.store_id=p_store_id and r.status<>'cancelled' and r.end_date >= (now() at time zone 'Asia/Kuala_Lumpur')::date - 31 order by r.requested_at desc limit 100) x;
  return jsonb_build_object('ok',true,'requests',v_rows);
end; $$;
revoke all on function public.v1361049_owner_leave_requests(uuid) from public;
grant execute on function public.v1361049_owner_leave_requests(uuid) to authenticated;

create or replace function public.v1361049_owner_review_leave(p_store_id uuid,p_request_id uuid,p_decision text,p_manager_note text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_decision text:=lower(trim(coalesce(p_decision,''))); v_req record; v_today date:=(now() at time zone 'Asia/Kuala_Lumpur')::date;
begin
  if v_decision not in ('approved','rejected') then raise exception '审批结果无效。'; end if;
  select organization_id into v_org from public.stores where id=p_store_id and status='active';
  if v_org is null or not public.can_access_store(p_store_id) or not public.has_organization_role(v_org,array['owner']) then raise exception '只有老板可以审批请假申请。'; end if;
  select * into v_req from public.employee_leave_requests where id=p_request_id and organization_id=v_org and store_id=p_store_id for update;
  if v_req.id is null then raise exception '找不到请假申请。'; end if;
  if v_req.status<>'pending' then raise exception '这份申请已经处理过。'; end if;
  if v_decision='approved' and v_today between v_req.start_date and v_req.end_date and exists(select 1 from public.employee_attendance_days d where d.organization_id=v_org and d.store_id=p_store_id and d.employee_id=v_req.employee_id and d.work_date=v_today and d.clock_in_at is not null) then
    raise exception '这名员工今天已经打过上班卡，不能批准今天的整日请假。';
  end if;
  if v_decision='approved' and exists(
    select 1 from public.visits v
    where v.organization_id=v_org and v.store_id=p_store_id
      and v.status in ('booked','arrived','waiting','in_service','paused','ready_for_checkout')
      and (coalesce(v.scheduled_at,v.started_at,v.created_at) at time zone 'Asia/Kuala_Lumpur')::date between v_req.start_date and v_req.end_date
      and exists(
        select 1 from public.visit_service_items si
        join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
        where si.visit_id=v.id and si.organization_id=v_org and si.status<>'cancelled' and w.employee_id=v_req.employee_id
      )
  ) then
    raise exception '这段请假日期内已有预约或进行中的订单，请先改派、改期或取消相关预约后再批准。';
  end if;
  update public.employee_leave_requests set status=v_decision,manager_note=nullif(trim(coalesce(p_manager_note,'')),''),reviewed_at=now(),reviewed_by=auth.uid(),updated_at=now() where id=p_request_id;
  if v_decision='approved' and v_today between v_req.start_date and v_req.end_date then
    update public.employees set is_on_duty=false,availability_status='off_duty',updated_at=now() where id=v_req.employee_id and organization_id=v_org;
  end if;
  return jsonb_build_object('ok',true,'status',v_decision,'message',case when v_decision='approved' then '已批准请假申请。' else '已拒绝请假申请。' end);
end; $$;
revoke all on function public.v1361049_owner_review_leave(uuid,uuid,text,text) from public;
grant execute on function public.v1361049_owner_review_leave(uuid,uuid,text,text) to authenticated;

-- Prevent clock-in on an approved full-day leave.
create or replace function public.v1361049_has_approved_leave(p_org uuid,p_store uuid,p_employee uuid,p_date date)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.employee_leave_requests r where r.organization_id=p_org and r.store_id=p_store and r.employee_id=p_employee and r.status='approved' and p_date between r.start_date and r.end_date);
$$;
revoke all on function public.v1361049_has_approved_leave(uuid,uuid,uuid,date) from public,anon,authenticated;

create or replace function public.v1365_ai_check_availability(
  p_queue_id uuid,
  p_service_id uuid,
  p_employee_id uuid,
  p_date date,
  p_time_iso text default null,
  p_time_period text default 'unspecified'
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_tenant jsonb;
  v_org uuid;
  v_store uuid;
  v_service record;
  v_employee record;
  v_settings record;
  v_shift record;
  v_timezone text:='Asia/Kuala_Lumpur';
  v_interval integer:=30;
  v_notice integer:=30;
  v_max_days integer:=90;
  v_duration integer:=60;

  v_schedule_source text:='employee_schedule';
  v_shift_start timestamp;
  v_shift_end timestamp;
  v_break_start timestamp;
  v_break_end timestamp;

  v_window_start timestamp;
  v_window_end timestamp;
  v_exact timestamp;
  v_slot timestamp;
  v_slot_end timestamp;
  v_slots jsonb:='[]'::jsonb;
  v_busy boolean;
  v_now_local timestamp;
  v_count integer:=0;
  v_period text:=lower(coalesce(p_time_period,'unspecified'));
begin
  v_tenant:=public.v1365_ai_queue_tenant(p_queue_id);
  v_org:=(v_tenant->>'organization_id')::uuid;
  v_store:=(v_tenant->>'store_id')::uuid;

  select s.id,s.name,s.default_price,s.estimated_minutes,s.active
    into v_service
  from public.services s
  where s.id=p_service_id
    and s.organization_id=v_org
    and s.store_id=v_store
    and coalesce(s.active,true)=true;

  if v_service.id is null then
    return jsonb_build_object(
      'ok',false,'availability_status','invalid_service','slots','[]'::jsonb
    );
  end if;

  v_duration:=greatest(coalesce(v_service.estimated_minutes,60),1);

  select e.id,e.name,e.is_on_duty,e.availability_status,e.employment_status
    into v_employee
  from public.employees e
  where e.id=p_employee_id
    and e.organization_id=v_org
    and e.employment_status='active'
    and exists(
      select 1
      from public.employee_stores es
      where es.organization_id=v_org
        and es.store_id=v_store
        and es.employee_id=e.id
        and es.status='active'
    );

  if v_employee.id is null then
    return jsonb_build_object(
      'ok',false,'availability_status','invalid_staff','slots','[]'::jsonb
    );
  end if;

  -- v13.6.10.49: Appointment availability must NOT depend on whether the employee
  -- has clocked in today. Clock-in is a same-day Walk-in eligibility signal only.
  -- Future/today appointments stay bookable by schedule/skills/conflicts unless an
  -- approved full-day leave overlaps the requested appointment date.
  if p_date is not null and exists(
    select 1
    from public.employee_leave_requests lr
    where lr.organization_id=v_org
      and lr.store_id=v_store
      and lr.employee_id=p_employee_id
      and lr.status='approved'
      and p_date between lr.start_date and lr.end_date
  ) then
    return jsonb_build_object(
      'ok',true,
      'availability_status','employee_on_leave',
      'availability_source','approved_leave',
      'employee',jsonb_build_object('id',v_employee.id,'name',v_employee.name),
      'date',p_date,
      'slots','[]'::jsonb
    );
  end if;

  select * into v_settings
  from public.whatsapp_ai_booking_settings b
  where b.organization_id=v_org
    and b.store_id=v_store
    and b.active=true;

  if v_settings.id is not null then
    v_timezone:=coalesce(nullif(v_settings.timezone,''),'Asia/Kuala_Lumpur');
    v_interval:=greatest(coalesce(v_settings.slot_interval_minutes,30),5);
    v_notice:=greatest(coalesce(v_settings.minimum_notice_minutes,30),0);
    v_max_days:=greatest(coalesce(v_settings.max_booking_days_ahead,90),1);
  end if;

  v_now_local:=now() at time zone v_timezone;

  if p_date is null then
    return jsonb_build_object(
      'ok',true,'availability_status','missing_date','slots','[]'::jsonb
    );
  end if;

  if p_date < v_now_local::date then
    return jsonb_build_object(
      'ok',true,'availability_status','date_in_past','slots','[]'::jsonb
    );
  end if;

  if p_date > (v_now_local::date + v_max_days) then
    return jsonb_build_object(
      'ok',true,
      'availability_status','date_too_far',
      'max_booking_days_ahead',v_max_days,
      'slots','[]'::jsonb
    );
  end if;

  -- Dedicated per-employee AI schedule remains the strongest truth if present.
  select * into v_shift
  from public.whatsapp_ai_employee_schedules x
  where x.organization_id=v_org
    and x.store_id=v_store
    and x.employee_id=p_employee_id
    and x.iso_weekday=extract(isodow from p_date)::int;

  if v_shift.id is not null then
    v_schedule_source:='employee_schedule';

    if not coalesce(v_shift.is_working,false) then
      return jsonb_build_object(
        'ok',true,
        'availability_status','employee_off',
        'availability_source',v_schedule_source,
        'date',p_date,
        'slots','[]'::jsonb
      );
    end if;

    if v_shift.start_time is null or v_shift.end_time is null then
      return jsonb_build_object(
        'ok',true,
        'availability_status','schedule_invalid',
        'availability_source',v_schedule_source,
        'slots','[]'::jsonb
      );
    end if;

    v_interval:=greatest(coalesce(v_shift.slot_interval_minutes,v_interval),5);
    v_shift_start:=p_date::timestamp + v_shift.start_time;
    v_shift_end:=p_date::timestamp + v_shift.end_time;

    if v_shift_end<=v_shift_start then
      v_shift_end:=v_shift_end+interval '1 day';
    end if;

    if v_shift.break_start is not null and v_shift.break_end is not null then
      v_break_start:=p_date::timestamp + v_shift.break_start;
      v_break_end:=p_date::timestamp + v_shift.break_end;
      if v_break_end<=v_break_start then
        v_break_end:=v_break_end+interval '1 day';
      end if;
    end if;
  else
    -- IMPORTANT FIX:
    -- No hidden AI schedule row -> use the Service Board's 09:00 -> 00:00 model.
    -- This prevents "weihong is Available on Service Board but AI cannot see him".
    v_schedule_source:='service_board_fallback';
    v_shift_start:=p_date::timestamp + time '09:00';
    v_shift_end:=(p_date+1)::timestamp; -- next day 00:00
    v_break_start:=null;
    v_break_end:=null;
  end if;

  v_window_start:=v_shift_start;
  v_window_end:=v_shift_end;

  if v_period='morning' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '06:00');
    v_window_end:=least(v_window_end,p_date::timestamp+time '12:00');
  elsif v_period='afternoon' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '12:00');
    v_window_end:=least(v_window_end,p_date::timestamp+time '18:00');
  elsif v_period='evening' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '18:00');
    v_window_end:=least(v_window_end,p_date::timestamp+time '22:00');
  elsif v_period='night' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '22:00');
  end if;

  if nullif(trim(coalesce(p_time_iso,'')),'') is not null then
    if trim(p_time_iso) !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' then
      return jsonb_build_object(
        'ok',true,'availability_status','invalid_time','slots','[]'::jsonb
      );
    end if;

    v_exact:=p_date::timestamp + trim(p_time_iso)::time;
    v_window_start:=v_exact;
    v_window_end:=v_exact + make_interval(mins=>v_duration);
  end if;

  if v_window_end<=v_window_start
     or v_window_start+make_interval(mins=>v_duration)>v_shift_end then
    return jsonb_build_object(
      'ok',true,
      'availability_status','outside_shift',
      'availability_source',v_schedule_source,
      'date',p_date,
      'slots','[]'::jsonb
    );
  end if;

  v_slot:=v_window_start;

  while v_slot + make_interval(mins=>v_duration) <= v_window_end loop
    v_slot_end:=v_slot+make_interval(mins=>v_duration);

    -- Minimum booking notice.
    if v_slot < v_now_local + make_interval(mins=>v_notice) then
      v_slot:=v_slot+make_interval(mins=>v_interval);
      continue;
    end if;

    -- Dedicated schedule break only. Service Board fallback has no hidden break.
    if v_break_start is not null
       and v_break_end is not null
       and v_slot < v_break_end
       and v_slot_end > v_break_start then
      v_slot:=v_slot+make_interval(mins=>v_interval);
      continue;
    end if;

    -- Real SalonOS Visit conflicts are the final availability truth.
    select exists(
      select 1
      from public.visits v
      where v.organization_id=v_org
        and v.store_id=v_store
        and v.status in (
          'booked','arrived','waiting','in_service','paused','ready_for_checkout'
        )
        and exists(
          select 1
          from public.visit_service_items si
          join public.visit_service_workers w
            on w.service_item_id=si.id
           and w.status='active'
          where si.visit_id=v.id
            and si.organization_id=v_org
            and si.status<>'cancelled'
            and w.employee_id=p_employee_id
        )
        and (coalesce(v.scheduled_at,v.started_at,v.created_at) at time zone v_timezone) < v_slot_end
        and (
          (coalesce(v.scheduled_at,v.started_at,v.created_at) at time zone v_timezone)
          + make_interval(
              mins=>greatest(
                30,
                coalesce((
                  select sum(greatest(coalesce(si2.estimated_minutes_snapshot,30),1))::int
                  from public.visit_service_items si2
                  where si2.visit_id=v.id
                    and si2.organization_id=v_org
                    and si2.status<>'cancelled'
                ),30)
              )
            )
        ) > v_slot
    ) into v_busy;

    if not v_busy then
      v_slots:=v_slots || jsonb_build_array(
        jsonb_build_object(
          'time',to_char(v_slot,'HH24:MI'),
          'start_local',to_char(v_slot,'YYYY-MM-DD"T"HH24:MI:SS'),
          'end_local',to_char(v_slot_end,'YYYY-MM-DD"T"HH24:MI:SS'),
          'duration_minutes',v_duration
        )
      );

      v_count:=v_count+1;
      if v_count>=12 then
        exit;
      end if;
    end if;

    if v_exact is not null then
      exit;
    end if;

    v_slot:=v_slot+make_interval(mins=>v_interval);
  end loop;

  return jsonb_build_object(
    'ok',true,
    'tool','check_availability',
    'availability_status',
      case when jsonb_array_length(v_slots)>0 then 'available' else 'no_slots' end,
    'availability_source',v_schedule_source,
    'date',p_date,
    'timezone',v_timezone,
    'service',jsonb_build_object(
      'id',v_service.id,
      'name',v_service.name,
      'duration_minutes',v_duration,
      'price',v_service.default_price
    ),
    'employee',jsonb_build_object(
      'id',v_employee.id,
      'name',v_employee.name,
      'is_on_duty',v_employee.is_on_duty,
      'live_availability_status',v_employee.availability_status
    ),
    'shift',jsonb_build_object(
      'source',v_schedule_source,
      'start',to_char(v_shift_start,'HH24:MI'),
      'end',case
        when v_shift_end::date>p_date then '00:00'
        else to_char(v_shift_end,'HH24:MI')
      end,
      'break_start',case
        when v_break_start is null then null else to_char(v_break_start,'HH24:MI')
      end,
      'break_end',case
        when v_break_end is null then null else to_char(v_break_end,'HH24:MI')
      end
    ),
    'slot_interval_minutes',v_interval,
    'slots',v_slots
  );
end;
$$;

revoke all on function public.v1365_ai_check_availability(uuid,uuid,uuid,date,text,text)
  from public,anon,authenticated;
grant execute on function public.v1365_ai_check_availability(uuid,uuid,uuid,date,text,text)
  to service_role;

create or replace function public.v1366_ai_check_availability(
  p_queue_id uuid,
  p_service_id uuid,
  p_employee_id uuid,
  p_date date,
  p_time_iso text default null,
  p_time_period text default 'unspecified'
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result jsonb;
  v_filtered jsonb:='[]'::jsonb;
  v_status text;
begin
  v_result:=public.v1365_ai_check_availability(
    p_queue_id,p_service_id,p_employee_id,p_date,p_time_iso,p_time_period
  );
  if nullif(trim(coalesce(p_time_iso,'')),'') is null
     and lower(coalesce(p_time_period,'unspecified'))='afternoon'
     and jsonb_typeof(coalesce(v_result->'slots','[]'::jsonb))='array' then
    select coalesce(jsonb_agg(x order by x->>'time'),'[]'::jsonb)
      into v_filtered
    from jsonb_array_elements(coalesce(v_result->'slots','[]'::jsonb)) x
    where coalesce(x->>'time','') >= '13:00' and coalesce(x->>'time','') < '18:00';
    v_result:=jsonb_set(v_result,'{slots}',v_filtered,true);
    if (v_result->>'availability_status') in ('available','no_slots') then
      v_status:=case when jsonb_array_length(v_filtered)>0 then 'available' else 'no_slots' end;
      v_result:=jsonb_set(v_result,'{availability_status}',to_jsonb(v_status),true);
    end if;
  end if;
  return v_result || jsonb_build_object('tool','check_availability','tool_version','13.6.10.49');
end;
$$;
revoke all on function public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text) from public;
revoke all on function public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text) from anon;
revoke all on function public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text) from authenticated;
grant execute on function public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text) to service_role;

-- Attendance snapshot now surfaces approved leave as its own state.
create or replace function public.v1361039_attendance_rows(p_org uuid,p_store uuid,p_only_employee uuid default null)
returns jsonb language sql stable security definer set search_path=public as $$
  with local_now as (select now() at time zone 'Asia/Kuala_Lumpur' n),
  rows as (
    select e.id employee_id,e.name,e.position,e.app_role,e.employment_status,e.is_on_duty,e.availability_status,
      coalesce(s.enabled,true) attendance_enabled,coalesce(s.scheduled_start_time,time '09:00') scheduled_start_time,
      coalesce(s.scheduled_end_time,time '18:00') scheduled_end_time,coalesce(s.late_grace_minutes,10) late_grace_minutes,
      d.clock_in_at,d.clock_out_at,d.arrival_status,
      leave_today.id leave_request_id, leave_today.reason leave_reason,
      case
        when leave_today.id is not null and d.clock_in_at is null then 'on_leave'
        when not coalesce(s.enabled,true) then 'attendance_disabled'
        when d.clock_out_at is not null then 'clocked_out'
        when d.clock_in_at is not null and d.arrival_status='late' then 'working_late'
        when d.clock_in_at is not null then 'working'
        when (select n from local_now) > ((select n::date from local_now)::timestamp + coalesce(s.scheduled_start_time,time '09:00') + make_interval(mins=>coalesce(s.late_grace_minutes,10))) then 'not_arrived'
        else 'not_clocked_in'
      end attendance_status,
      (leave_today.id is null and d.clock_in_at is not null and d.clock_out_at is null and coalesce(e.is_on_duty,false)
       and lower(coalesce(e.availability_status,'available')) not in ('break','off_duty','in_service','busy','disabled','inactive')) can_assign_walkin
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id and es.store_id=p_store and es.status='active'
    left join public.employee_attendance_settings s on s.organization_id=e.organization_id and s.store_id=p_store and s.employee_id=e.id
    left join public.employee_attendance_days d on d.organization_id=e.organization_id and d.store_id=p_store and d.employee_id=e.id and d.work_date=(now() at time zone 'Asia/Kuala_Lumpur')::date
    left join lateral (select r.id,r.reason from public.employee_leave_requests r where r.organization_id=e.organization_id and r.store_id=p_store and r.employee_id=e.id and r.status='approved' and (now() at time zone 'Asia/Kuala_Lumpur')::date between r.start_date and r.end_date order by r.reviewed_at desc nulls last limit 1) leave_today on true
    where e.organization_id=p_org and e.employment_status='active' and (p_only_employee is null or e.id=p_only_employee)
    order by e.name
  ) select coalesce(jsonb_agg(to_jsonb(rows)),'[]'::jsonb) from rows;
$$;
revoke all on function public.v1361039_attendance_rows(uuid,uuid,uuid) from public,anon,authenticated;


create or replace function public.v1361030_employee_free_for_slot(
  p_organization_id uuid,
  p_store_id uuid,
  p_employee_id uuid,
  p_start_at timestamptz,
  p_duration_minutes integer,
  p_visit_type text default 'appointment',
  p_exclude_visit_id uuid default null
) returns boolean
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_employee record;
  v_schedule record;
  v_timezone text:='Asia/Kuala_Lumpur';
  v_start_local timestamp;
  v_end_local timestamp;
  v_duration integer:=greatest(coalesce(p_duration_minutes,30),1);
  v_shift_start timestamp;
  v_shift_end timestamp;
  v_break_start timestamp;
  v_break_end timestamp;
  v_visit_type text:=case when lower(coalesce(p_visit_type,''))='walk_in' then 'walk_in' else 'appointment' end;
begin
  if p_start_at is null then return false; end if;

  select e.id,e.name,e.position,e.is_on_duty,e.availability_status,e.employment_status
  into v_employee
  from public.employees e
  where e.id=p_employee_id
    and e.organization_id=p_organization_id
    and e.employment_status='active'
    and exists(
      select 1 from public.employee_stores es
      where es.organization_id=p_organization_id
        and es.store_id=p_store_id
        and es.employee_id=e.id
        and es.status='active'
    );
  if v_employee.id is null then return false; end if;

  select coalesce(nullif(b.timezone,''),'Asia/Kuala_Lumpur') into v_timezone
  from public.whatsapp_ai_booking_settings b
  where b.organization_id=p_organization_id and b.store_id=p_store_id and b.active=true
  limit 1;
  v_timezone:=coalesce(v_timezone,'Asia/Kuala_Lumpur');
  v_start_local:=p_start_at at time zone v_timezone;
  v_end_local:=v_start_local+make_interval(mins=>v_duration);

  -- v13.6.10.49: approved full-day leave blocks manual appointments and walk-ins.
  if public.v1361049_has_approved_leave(p_organization_id,p_store_id,p_employee_id,v_start_local::date) then
    return false;
  end if;

  -- Live Service Board status applies to a walk-in happening now. Future appointments
  -- must NOT depend on whether the employee happens to be on duty at the moment this
  -- booking is created; their schedule for the requested date/time is the source of truth.
  if v_visit_type='walk_in' then
    -- v13.6.10.39: attendance is the physical-presence source of truth for walk-ins.
    -- If attendance tracking is enabled for this employee, an open clock-in for the
    -- requested local work date is required; a stale/manual is_on_duty flag cannot bypass it.
    if coalesce((select s.enabled from public.employee_attendance_settings s
                 where s.organization_id=p_organization_id and s.store_id=p_store_id and s.employee_id=p_employee_id limit 1),true) then
      if not exists(
        select 1 from public.employee_attendance_days ad
        where ad.organization_id=p_organization_id and ad.store_id=p_store_id and ad.employee_id=p_employee_id
          and ad.work_date=v_start_local::date and ad.clock_in_at is not null and ad.clock_out_at is null
      ) then return false; end if;
    end if;
    if not coalesce(v_employee.is_on_duty,false) then return false; end if;
    if lower(coalesce(v_employee.availability_status,'available')) in
       ('break','off_duty','in_service','busy','disabled','inactive') then
      return false;
    end if;
  end if;

  select * into v_schedule
  from public.whatsapp_ai_employee_schedules x
  where x.organization_id=p_organization_id
    and x.store_id=p_store_id
    and x.employee_id=p_employee_id
    and x.iso_weekday=extract(isodow from v_start_local)::int
  limit 1;

  if v_schedule.id is not null then
    if not coalesce(v_schedule.is_working,false) or v_schedule.start_time is null or v_schedule.end_time is null then
      return false;
    end if;
    v_shift_start:=v_start_local::date::timestamp+v_schedule.start_time;
    v_shift_end:=v_start_local::date::timestamp+v_schedule.end_time;
    if v_shift_end<=v_shift_start then v_shift_end:=v_shift_end+interval '1 day'; end if;
    if v_schedule.break_start is not null and v_schedule.break_end is not null then
      v_break_start:=v_start_local::date::timestamp+v_schedule.break_start;
      v_break_end:=v_start_local::date::timestamp+v_schedule.break_end;
      if v_break_end<=v_break_start then v_break_end:=v_break_end+interval '1 day'; end if;
    end if;
  else
    -- Same fallback as the Service Board / WhatsApp unified pool.
    v_shift_start:=v_start_local::date::timestamp+time '09:00';
    v_shift_end:=(v_start_local::date+1)::timestamp;
    v_break_start:=null; v_break_end:=null;
  end if;

  if v_start_local<v_shift_start or v_end_local>v_shift_end then return false; end if;
  if v_break_start is not null and v_break_end is not null
     and v_start_local<v_break_end and v_end_local>v_break_start then return false; end if;

  -- Visit status is the occupancy truth. Cancelled / no-show / completed visits are
  -- intentionally absent, so cancelling a visit releases the slot without deleting
  -- historical visit_service_workers rows.
  if exists(
    select 1
    from public.visits v
    where v.organization_id=p_organization_id
      and v.store_id=p_store_id
      and v.status in ('booked','arrived','waiting','in_service','paused','ready_for_checkout')
      and (p_exclude_visit_id is null or v.id<>p_exclude_visit_id)
      and exists(
        select 1
        from public.visit_service_items si
        join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
        where si.visit_id=v.id
          and si.organization_id=p_organization_id
          and si.store_id=p_store_id
          and si.status<>'cancelled'
          and w.employee_id=p_employee_id
      )
      and (coalesce(v.scheduled_at,v.started_at,v.arrived_at,v.created_at) at time zone v_timezone) < v_end_local
      and (
        (coalesce(v.scheduled_at,v.started_at,v.arrived_at,v.created_at) at time zone v_timezone)
        + make_interval(mins=>greatest(30,coalesce((
          select sum(greatest(coalesce(si2.estimated_minutes_snapshot,30),1))::int
          from public.visit_service_items si2
          where si2.visit_id=v.id
            and si2.organization_id=p_organization_id
            and si2.store_id=p_store_id
            and si2.status<>'cancelled'
            and exists(
              select 1 from public.visit_service_workers w2
              where w2.service_item_id=si2.id
                and w2.employee_id=p_employee_id
                and w2.status='active'
            )
        ),30)))
      ) > v_start_local
  ) then return false; end if;

  return true;
end;
$$;

revoke all on function public.v1361030_employee_free_for_slot(uuid,uuid,uuid,timestamptz,integer,text,uuid) from public,anon,authenticated;

commit;
notify pgrst, 'reload schema';

select 'SalonOS v13.6.10.49 LEAVE + APPOINTMENT AVAILABILITY READY' as result,
       to_regclass('public.employee_leave_requests') is not null as leave_requests_ok,
       to_regprocedure('public.v1361049_employee_submit_leave(text,date,date,text)') is not null as employee_leave_rpc_ok,
       to_regprocedure('public.v1361049_owner_review_leave(uuid,uuid,text,text)') is not null as owner_review_rpc_ok,
       to_regprocedure('public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text)') is not null as ai_availability_ok;
