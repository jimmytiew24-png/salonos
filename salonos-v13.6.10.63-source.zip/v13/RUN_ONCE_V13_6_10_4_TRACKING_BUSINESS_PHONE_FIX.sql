-- SalonOS v13.6.10.4 · Tracking link WhatsApp Business destination hotfix
-- Goal: profile/reel/post tracking links must always open the STORE'S active WhatsApp Business number,
-- never a customer/test recipient number accidentally saved in tracking_links.destination_phone.
-- Idempotent: safe to run more than once.

begin;
set local statement_timeout='0';

create or replace function public.v1360_marketing_track(
  p_slug text,
  p_ref_code text,
  p_user_agent text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_link public.tracking_links%rowtype;
  v_channel public.marketing_channels%rowtype;
  v_account public.social_accounts%rowtype;
  v_content public.marketing_contents%rowtype;
  v_business_phone text;
  v_configured_phone text;
  v_effective_phone text;
begin
  select * into v_link
  from public.tracking_links
  where slug=lower(trim(p_slug)) and active=true
  limit 1;

  if v_link.id is null then
    return jsonb_build_object('ok',false,'error','not_found');
  end if;

  select * into v_channel from public.marketing_channels where id=v_link.channel_id;
  if v_link.social_account_id is not null then
    select * into v_account from public.social_accounts where id=v_link.social_account_id;
  end if;
  if v_link.content_id is not null then
    select * into v_content from public.marketing_contents where id=v_link.content_id;
  end if;

  -- Normalize the phone stored on the link, but do NOT trust it as the primary WhatsApp route.
  v_configured_phone := nullif(regexp_replace(coalesce(v_link.destination_phone,''),'[^0-9]','','g'),'');

  -- Prefer the branch's current enabled WhatsApp Business connection.
  -- If more than one exists, prefer LIVE then the most recently updated connection.
  select nullif(regexp_replace(coalesce(c.display_phone_number,''),'[^0-9]','','g'),'')
    into v_business_phone
  from public.whatsapp_business_connections c
  where c.organization_id=v_link.organization_id
    and c.store_id=v_link.store_id
    and c.enabled=true
    and nullif(regexp_replace(coalesce(c.display_phone_number,''),'[^0-9]','','g'),'') is not null
  order by (c.connection_status='live') desc, c.updated_at desc, c.created_at desc
  limit 1;

  if v_link.destination_type='whatsapp' then
    v_effective_phone := coalesce(v_business_phone,v_configured_phone);
  else
    v_effective_phone := v_configured_phone;
  end if;

  insert into public.tracking_clicks(
    organization_id,store_id,tracking_link_id,ref_code,user_agent
  )
  values(
    v_link.organization_id,v_link.store_id,v_link.id,
    upper(trim(p_ref_code)),left(coalesce(p_user_agent,''),500)
  )
  on conflict(ref_code) do nothing;

  return jsonb_build_object(
    'ok',true,
    'organization_id',v_link.organization_id,
    'store_id',v_link.store_id,
    'tracking_link_id',v_link.id,
    'channel_id',v_link.channel_id,
    'channel_code',v_channel.code,
    'channel_name',v_channel.name,
    'social_account_id',v_link.social_account_id,
    'account_name',v_account.display_name,
    'username',v_account.username,
    'staff_id',coalesce(v_link.staff_id,v_account.staff_id),
    'content_id',v_link.content_id,
    'content_type',v_content.content_type,
    'content_code',v_content.content_code,
    'content_title',v_content.title,
    'ref_code',upper(trim(p_ref_code)),
    'destination_type',v_link.destination_type,
    'destination_phone',v_effective_phone,
    'configured_destination_phone',v_configured_phone,
    'business_destination_phone',v_business_phone,
    'destination_phone_source',case
      when v_link.destination_type='whatsapp' and v_business_phone is not null then 'whatsapp_business_connection'
      when v_configured_phone is not null then 'tracking_link_fallback'
      else 'missing'
    end,
    'destination_url',v_link.destination_url,
    'prefill_message',v_link.prefill_message
  );
end;
$$;

revoke all on function public.v1360_marketing_track(text,text,text) from public;
grant execute on function public.v1360_marketing_track(text,text,text) to anon, authenticated;

-- Repair existing active WhatsApp tracking links so the stored destination also matches
-- the branch's current WhatsApp Business display number.
with chosen_connection as (
  select distinct on (c.organization_id,c.store_id)
    c.organization_id,
    c.store_id,
    nullif(regexp_replace(coalesce(c.display_phone_number,''),'[^0-9]','','g'),'') as business_phone
  from public.whatsapp_business_connections c
  where c.enabled=true
    and nullif(regexp_replace(coalesce(c.display_phone_number,''),'[^0-9]','','g'),'') is not null
  order by c.organization_id,c.store_id,
           (c.connection_status='live') desc,
           c.updated_at desc,
           c.created_at desc
)
update public.tracking_links tl
set destination_phone=cc.business_phone,
    updated_at=now()
from chosen_connection cc
where tl.organization_id=cc.organization_id
  and tl.store_id=cc.store_id
  and tl.destination_type='whatsapp'
  and tl.active=true
  and nullif(regexp_replace(coalesce(tl.destination_phone,''),'[^0-9]','','g'),'') is distinct from cc.business_phone;

commit;

select 'SalonOS v13.6.10.4 TRACKING BUSINESS PHONE FIX READY' as result;
