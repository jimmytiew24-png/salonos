-- SalonOS v13.6.10.51
-- Personal UI language + safe employee settings metadata.
-- Safe to run more than once.

begin;

alter table public.employees
  add column if not exists ui_language text;

alter table public.employees
  drop constraint if exists employees_ui_language_check;

alter table public.employees
  add constraint employees_ui_language_check
  check (ui_language is null or ui_language in ('zh','en'));

create or replace function public.v1361051_employee_ui_preference(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_h text:=encode(digest(coalesce(p_session_token,''),'sha256'),'hex');
  v_ls public.employee_login_sessions%rowtype;
  v_lang text;
begin
  select ls.* into v_ls
  from public.employee_login_sessions ls
  where ls.token_hash=v_h and ls.revoked_at is null and ls.expires_at>now()
  limit 1;
  if v_ls.id is null then raise exception '员工登录已过期，请重新输入手机号。'; end if;

  select e.ui_language into v_lang
  from public.employees e
  join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id and es.store_id=v_ls.store_id and es.status='active'
  where e.id=v_ls.employee_id and e.employment_status='active'
  limit 1;

  if not found then raise exception '员工账号已停用或门店不可使用。'; end if;
  update public.employee_login_sessions set last_seen_at=now() where id=v_ls.id;
  return jsonb_build_object('ui_language',v_lang);
end;
$$;

create or replace function public.v1361051_employee_set_ui_language(p_session_token text,p_language text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_h text:=encode(digest(coalesce(p_session_token,''),'sha256'),'hex');
  v_ls public.employee_login_sessions%rowtype;
  v_lang text:=lower(trim(coalesce(p_language,'')));
begin
  if v_lang not in ('zh','en') then raise exception '不支持的界面语言。'; end if;
  select ls.* into v_ls
  from public.employee_login_sessions ls
  where ls.token_hash=v_h and ls.revoked_at is null and ls.expires_at>now()
  limit 1;
  if v_ls.id is null then raise exception '员工登录已过期，请重新输入手机号。'; end if;

  update public.employees e
  set ui_language=v_lang,updated_at=now()
  where e.id=v_ls.employee_id
    and e.employment_status='active'
    and exists (
      select 1 from public.employee_stores es
      where es.employee_id=e.id and es.organization_id=e.organization_id
        and es.store_id=v_ls.store_id and es.status='active'
    );
  if not found then raise exception '员工账号已停用或门店不可使用。'; end if;
  update public.employee_login_sessions set last_seen_at=now() where id=v_ls.id;
  return jsonb_build_object('ok',true,'ui_language',v_lang);
end;
$$;

-- Extend the existing role-permission RPC with a SAFE general-settings subset.
-- No WhatsApp token, App Secret, connection secret or private credential is exposed.
create or replace function public.v1352_employee_role_permissions(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_h text:=encode(digest(coalesce(p_session_token,''),'sha256'),'hex');
  v_ls public.employee_login_sessions%rowtype;
  v_role text;
  v_permissions jsonb:='{}'::jsonb;
  v_general jsonb:='{}'::jsonb;
  v_org uuid;
begin
  select ls.* into v_ls
  from public.employee_login_sessions ls
  where ls.token_hash=v_h and ls.revoked_at is null and ls.expires_at>now()
  limit 1;
  if v_ls.id is null then raise exception '员工登录已过期，请重新输入手机号。'; end if;

  select e.organization_id,e.app_role into v_org,v_role
  from public.employees e
  join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id and es.store_id=v_ls.store_id and es.status='active'
  join public.stores s on s.id=v_ls.store_id and s.organization_id=e.organization_id and s.status='active'
  join public.organizations o on o.id=e.organization_id and o.status in ('active','trialing')
  where e.id=v_ls.employee_id and e.employment_status='active'
  limit 1;

  if v_org is null then
    update public.employee_login_sessions set revoked_at=coalesce(revoked_at,now()) where id=v_ls.id;
    raise exception '员工账号已停用或门店不可使用。';
  end if;

  select
    coalesce(s.role_permissions,'{}'::jsonb),
    jsonb_strip_nulls(jsonb_build_object(
      'business_name',s.general->>'business_name',
      'language',s.general->>'language',
      'timezone',s.general->>'timezone',
      'currency',s.general->>'currency',
      'receipt_prefix',s.general->>'receipt_prefix',
      'device_remember_days',s.general->>'device_remember_days'
    ))
  into v_permissions,v_general
  from public.v13_organization_settings s
  where s.organization_id=v_org
  limit 1;

  update public.employee_login_sessions set last_seen_at=now() where id=v_ls.id;
  return jsonb_build_object(
    'organization_id',v_org,
    'employee_role',coalesce(v_role,'staff'),
    'role_permissions',coalesce(v_permissions,'{}'::jsonb),
    'general',coalesce(v_general,'{}'::jsonb)
  );
end;
$$;

revoke all on function public.v1361051_employee_ui_preference(text) from public;
revoke all on function public.v1361051_employee_set_ui_language(text,text) from public;
revoke all on function public.v1352_employee_role_permissions(text) from public;
grant execute on function public.v1361051_employee_ui_preference(text) to anon,authenticated;
grant execute on function public.v1361051_employee_set_ui_language(text,text) to anon,authenticated;
grant execute on function public.v1352_employee_role_permissions(text) to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values('settings_permission_contract_version','13.6.10.51')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;

select
  'SalonOS v13.6.10.51 PERSONAL LANGUAGE + SETTINGS PERMISSIONS READY' as status,
  to_regprocedure('public.v1361051_employee_ui_preference(text)') is not null as language_read_rpc_ok,
  to_regprocedure('public.v1361051_employee_set_ui_language(text,text)') is not null as language_write_rpc_ok,
  to_regprocedure('public.v1352_employee_role_permissions(text)') is not null as settings_permission_rpc_ok;
