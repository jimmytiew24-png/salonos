-- SalonOS v13.6.10.52 · manual attendance + Meta social direct-message inbox foundation
-- Order evidence uses existing v13_visit_confirmations table and needs no schema change.
-- This script is additive/idempotent.

create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------------------
-- Manual attendance audit trail
-- ---------------------------------------------------------------------------
create table if not exists public.employee_attendance_manual_actions(
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  action text not null check(action in ('in','out')),
  note text not null,
  acted_by_user uuid,
  acted_by_employee uuid references public.employees(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists idx_attendance_manual_store_date on public.employee_attendance_manual_actions(store_id,created_at desc);
alter table public.employee_attendance_manual_actions enable row level security;
revoke all on public.employee_attendance_manual_actions from anon,authenticated;

create or replace function public.v1361052_apply_manual_clock(
  p_org uuid,p_store uuid,p_employee uuid,p_action text,p_note text,p_actor_user uuid default null,p_actor_employee uuid default null
) returns jsonb language plpgsql security definer set search_path=public as $$
declare v_setting record; v_day record; v_today date:=(now() at time zone 'Asia/Kuala_Lumpur')::date; v_local_now timestamp:=now() at time zone 'Asia/Kuala_Lumpur'; v_threshold timestamp; v_late boolean;
begin
  if lower(coalesce(p_action,'')) not in ('in','out') then raise exception '无效的打卡操作。'; end if;
  if length(trim(coalesce(p_note,'')))<2 then raise exception '请填写代打卡原因。'; end if;
  if not exists(select 1 from public.employee_stores es join public.employees e on e.id=es.employee_id and e.organization_id=es.organization_id where es.organization_id=p_org and es.store_id=p_store and es.employee_id=p_employee and es.status='active' and e.employment_status='active') then raise exception '员工不属于当前分行或已停用。'; end if;
  select * into v_setting from public.employee_attendance_settings where organization_id=p_org and store_id=p_store and employee_id=p_employee limit 1;
  if v_setting.id is null then insert into public.employee_attendance_settings(organization_id,store_id,employee_id) values(p_org,p_store,p_employee) returning * into v_setting; end if;
  select * into v_day from public.employee_attendance_days where organization_id=p_org and store_id=p_store and employee_id=p_employee and work_date=v_today for update;
  if p_action='in' then
    if v_day.id is not null and v_day.clock_in_at is not null and v_day.clock_out_at is null then return jsonb_build_object('ok',true,'message','这名员工已经在上班中。'); end if;
    if v_day.id is not null and v_day.clock_out_at is not null then raise exception '这名员工今天已经完成下班打卡；如需重新上班请由老板处理异常班次。'; end if;
    v_threshold:=v_today::timestamp+coalesce(v_setting.scheduled_start_time,time '09:00')+make_interval(mins=>coalesce(v_setting.late_grace_minutes,10)); v_late:=v_local_now>v_threshold;
    insert into public.employee_attendance_days(organization_id,store_id,employee_id,work_date,scheduled_start_time_snapshot,scheduled_end_time_snapshot,late_grace_minutes_snapshot,clock_in_at,arrival_status,clock_in_source,updated_at)
    values(p_org,p_store,p_employee,v_today,coalesce(v_setting.scheduled_start_time,time '09:00'),coalesce(v_setting.scheduled_end_time,time '18:00'),coalesce(v_setting.late_grace_minutes,10),now(),case when v_late then 'late' else 'on_time' end,'manual',now())
    on conflict(store_id,employee_id,work_date) do update set clock_in_at=excluded.clock_in_at,clock_out_at=null,arrival_status=excluded.arrival_status,clock_in_source='manual',updated_at=now();
    update public.employees set is_on_duty=true,availability_status='available',updated_at=now() where id=p_employee and organization_id=p_org;
  else
    if v_day.id is null or v_day.clock_in_at is null then raise exception '这名员工今天还没有上班记录，不能直接下班。'; end if;
    if v_day.clock_out_at is not null then return jsonb_build_object('ok',true,'message','这名员工今天已经完成下班打卡。'); end if;
    update public.employee_attendance_days set clock_out_at=now(),clock_out_source='manual',updated_at=now() where id=v_day.id;
    update public.employees set is_on_duty=false,availability_status='off_duty',updated_at=now() where id=p_employee and organization_id=p_org;
  end if;
  insert into public.employee_attendance_manual_actions(organization_id,store_id,employee_id,action,note,acted_by_user,acted_by_employee) values(p_org,p_store,p_employee,p_action,trim(p_note),p_actor_user,p_actor_employee);
  return jsonb_build_object('ok',true,'message',case when p_action='in' then '已替员工完成上班打卡。' else '已替员工完成下班打卡。' end);
end; $$;
revoke all on function public.v1361052_apply_manual_clock(uuid,uuid,uuid,text,text,uuid,uuid) from public,anon,authenticated;

create or replace function public.v1361052_owner_manual_clock(p_store_id uuid,p_employee_id uuid,p_action text,p_note text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_org uuid;
begin
 select organization_id into v_org from public.stores where id=p_store_id and status='active';
 if v_org is null or not public.can_access_store(p_store_id) or not public.has_organization_role(v_org,array['owner']) then raise exception '只有老板可以直接代员工打卡。'; end if;
 return public.v1361052_apply_manual_clock(v_org,p_store_id,p_employee_id,lower(p_action),p_note,auth.uid(),null);
end; $$;
revoke all on function public.v1361052_owner_manual_clock(uuid,uuid,text,text) from public;
grant execute on function public.v1361052_owner_manual_clock(uuid,uuid,text,text) to authenticated;

create or replace function public.v1361052_employee_manual_clock(p_session_token text,p_employee_id uuid,p_action text,p_note text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_ctx jsonb; v_org uuid; v_store uuid; v_actor uuid; v_role text; v_permissions jsonb:='{}'::jsonb; v_list jsonb; v_allowed boolean:=false;
begin
 v_ctx:=public.employee_session_context(p_session_token); v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid; v_actor:=(v_ctx->>'employee_id')::uuid; v_role:=coalesce(v_ctx->>'employee_role','staff');
 select coalesce(role_permissions,'{}'::jsonb) into v_permissions from public.v13_organization_settings where organization_id=v_org limit 1;
 v_list:=v_permissions->v_role;
 if jsonb_typeof(v_list)='array' then v_allowed := (v_list ? '*') or (v_list ? 'attendance.manual'); else v_allowed := v_role in ('manager','receptionist'); end if;
 if not v_allowed then raise exception '你的职位没有替员工打卡的权限。'; end if;
 return public.v1361052_apply_manual_clock(v_org,v_store,p_employee_id,lower(p_action),p_note,null,v_actor);
end; $$;
revoke all on function public.v1361052_employee_manual_clock(text,uuid,text,text) from public;
grant execute on function public.v1361052_employee_manual_clock(text,uuid,text,text) to anon,authenticated;

-- ---------------------------------------------------------------------------
-- Instagram / Facebook Direct Message inbox foundation
-- ---------------------------------------------------------------------------
create table if not exists public.social_inbox_connections(
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  social_account_id uuid not null references public.social_accounts(id) on delete cascade,
  platform text not null check(platform in ('instagram','facebook')),
  external_account_id text not null,
  meta_app_id text not null,
  connection_status text not null default 'configured',
  enabled boolean not null default true,
  last_webhook_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(store_id,platform,external_account_id)
);
create table if not exists public.social_inbox_connection_secrets(
  connection_id uuid primary key references public.social_inbox_connections(id) on delete cascade,
  verify_token_hash text not null,
  app_secret text not null,
  access_token text not null,
  updated_at timestamptz not null default now()
);
create table if not exists public.social_inbox_contacts(
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  connection_id uuid not null references public.social_inbox_connections(id) on delete cascade,
  social_account_id uuid not null references public.social_accounts(id) on delete cascade,
  platform text not null,
  external_user_id text not null,
  display_name text,
  customer_id uuid references public.customers(id) on delete set null,
  customer_phone text,
  first_message_at timestamptz not null default now(),
  last_message_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(connection_id,external_user_id)
);
create table if not exists public.social_inbox_messages(
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  connection_id uuid not null references public.social_inbox_connections(id) on delete cascade,
  contact_id uuid references public.social_inbox_contacts(id) on delete set null,
  platform text not null,
  external_message_id text,
  direction text not null default 'inbound',
  message_text text,
  raw_payload jsonb,
  received_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique(connection_id,external_message_id)
);
create index if not exists idx_social_inbox_contacts_store on public.social_inbox_contacts(store_id,last_message_at desc);
create index if not exists idx_social_inbox_messages_store on public.social_inbox_messages(store_id,received_at desc);
alter table public.social_inbox_connections enable row level security;
alter table public.social_inbox_connection_secrets enable row level security;
alter table public.social_inbox_contacts enable row level security;
alter table public.social_inbox_messages enable row level security;
revoke all on public.social_inbox_connection_secrets from anon,authenticated;

-- Owner-facing read policies; secrets remain service-role/RPC only.
drop policy if exists social_inbox_connections_owner_select on public.social_inbox_connections;
create policy social_inbox_connections_owner_select on public.social_inbox_connections for select to authenticated using (public.can_access_store(store_id));
drop policy if exists social_inbox_contacts_owner_select on public.social_inbox_contacts;
create policy social_inbox_contacts_owner_select on public.social_inbox_contacts for select to authenticated using (public.can_access_store(store_id));
drop policy if exists social_inbox_messages_owner_select on public.social_inbox_messages;
create policy social_inbox_messages_owner_select on public.social_inbox_messages for select to authenticated using (public.can_access_store(store_id));

create or replace function public.v1361052_owner_upsert_social_inbox_connection(p_store_id uuid,p_social_account_id uuid,p_platform text,p_external_account_id text,p_meta_app_id text,p_app_secret text,p_access_token text)
returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_org uuid; v_id uuid; v_verify text;
begin
 select organization_id into v_org from public.stores where id=p_store_id and status='active';
 if v_org is null or not public.can_access_store(p_store_id) or not public.has_organization_role(v_org,array['owner']) then raise exception '只有老板可以连接 Social Inbox。'; end if;
 if lower(p_platform) not in ('instagram','facebook') then raise exception 'Unsupported social platform'; end if;
 if not exists(select 1 from public.social_accounts where id=p_social_account_id and organization_id=v_org and store_id=p_store_id and active=true) then raise exception '媒体账号不属于当前分行。'; end if;
 insert into public.social_inbox_connections(organization_id,store_id,social_account_id,platform,external_account_id,meta_app_id,connection_status,enabled,updated_at)
 values(v_org,p_store_id,p_social_account_id,lower(p_platform),trim(p_external_account_id),trim(p_meta_app_id),'configured',true,now())
 on conflict(store_id,platform,external_account_id) do update set social_account_id=excluded.social_account_id,meta_app_id=excluded.meta_app_id,enabled=true,updated_at=now()
 returning id into v_id;
 v_verify:='SOC-'||upper(encode(gen_random_bytes(18),'hex'));
 insert into public.social_inbox_connection_secrets(connection_id,verify_token_hash,app_secret,access_token,updated_at)
 values(v_id,encode(digest(v_verify,'sha256'),'hex'),trim(p_app_secret),trim(p_access_token),now())
 on conflict(connection_id) do update set verify_token_hash=excluded.verify_token_hash,app_secret=excluded.app_secret,access_token=excluded.access_token,updated_at=now();
 update public.social_accounts set external_account_id=trim(p_external_account_id),connection_status='api_connected',updated_at=now() where id=p_social_account_id;
 return jsonb_build_object('ok',true,'connection_id',v_id,'verify_token',v_verify);
end; $$;
revoke all on function public.v1361052_owner_upsert_social_inbox_connection(uuid,uuid,text,text,text,text,text) from public;
grant execute on function public.v1361052_owner_upsert_social_inbox_connection(uuid,uuid,text,text,text,text,text) to authenticated;

select
  to_regprocedure('public.v1361052_owner_manual_clock(uuid,uuid,text,text)') is not null as owner_manual_clock_ok,
  to_regprocedure('public.v1361052_employee_manual_clock(text,uuid,text,text)') is not null as employee_manual_clock_ok,
  to_regclass('public.social_inbox_connections') is not null as social_inbox_ok;
