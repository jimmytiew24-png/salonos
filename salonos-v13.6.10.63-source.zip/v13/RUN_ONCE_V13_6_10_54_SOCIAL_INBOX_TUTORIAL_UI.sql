-- SalonOS v13.6.10.54 · Social Inbox tutorial UI + manual source capture
-- Safe to run more than once.

create table if not exists public.social_manual_leads(
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  social_account_id uuid references public.social_accounts(id) on delete set null,
  platform text not null check(platform in ('instagram','facebook','tiktok','xhs','other')),
  customer_name text,
  customer_phone text,
  note text,
  customer_id uuid references public.customers(id) on delete set null,
  status text not null default 'new' check(status in ('new','linked','converted','archived')),
  created_by_user_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_social_manual_leads_store on public.social_manual_leads(store_id,created_at desc);
alter table public.social_manual_leads enable row level security;
drop policy if exists social_manual_leads_store_access on public.social_manual_leads;
create policy social_manual_leads_store_access on public.social_manual_leads for all to authenticated
  using (public.can_access_store(store_id)) with check (public.can_access_store(store_id));
notify pgrst,'reload schema';
select
  'SalonOS v13.6.10.54 SOCIAL INBOX TUTORIAL UI READY' as result,
  to_regclass('public.social_manual_leads') is not null as manual_capture_ok,
  to_regclass('public.social_inbox_connections') is not null as social_inbox_ok;
