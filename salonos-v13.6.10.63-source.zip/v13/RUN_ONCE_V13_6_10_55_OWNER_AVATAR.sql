-- SalonOS v13.6.10.55 · Owner avatar profile support
begin;

alter table public.profiles add column if not exists avatar_path text;

create or replace function public.v1361055_owner_set_avatar(p_avatar_path text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_user uuid:=auth.uid();
  v_org uuid;
  v_prefix text;
begin
  if v_user is null then raise exception 'Not authenticated'; end if;
  select om.organization_id into v_org
  from public.organization_members om
  where om.user_id=v_user and om.role in ('owner','manager') and coalesce(om.status,'active')='active'
  order by case when om.role='owner' then 0 else 1 end
  limit 1;
  if v_org is null then raise exception 'Owner/manager membership not found'; end if;
  v_prefix:=v_org::text||'/owner-avatars/'||v_user::text||'/';
  if p_avatar_path is null or left(p_avatar_path,length(v_prefix))<>v_prefix then raise exception 'Invalid owner avatar path'; end if;
  insert into public.profiles(id,avatar_path,updated_at)
  values(v_user,p_avatar_path,now())
  on conflict(id) do update set avatar_path=excluded.avatar_path,updated_at=now();
  return jsonb_build_object('avatar_path',p_avatar_path);
end $$;

revoke all on function public.v1361055_owner_set_avatar(text) from public;
grant execute on function public.v1361055_owner_set_avatar(text) to authenticated;

notify pgrst,'reload schema';
select 'SalonOS v13.6.10.55 OWNER AVATAR READY' as result,
       exists(select 1 from information_schema.columns where table_schema='public' and table_name='profiles' and column_name='avatar_path') as owner_avatar_ok,
       to_regprocedure('public.v1361055_owner_set_avatar(text)') is not null as owner_avatar_rpc_ok;
commit;
