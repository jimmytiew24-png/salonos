-- SalonOS v13.6.10.9
-- FIRST TOUCH + UNIQUE WHATSAPP CUSTOMER ANALYTICS
-- Run once in Supabase SQL Editor.
--
-- Rules installed by this migration:
-- 1) One Organization + Branch + normalized WhatsApp phone = one first-touch customer.
-- 2) Repeated WhatsApp messages never increase the first-touch customer count.
-- 3) If the same phone enters from Instagram first and Facebook later, Instagram remains the source.
-- 4) Raw Tracking Link opens remain available for diagnostics but never define customer counts.
-- 5) Existing Marketing Leads are backfilled by the earliest lead row available for each phone.

begin;

create or replace function public.v136109_normalize_phone_text(p_phone text)
returns text
language sql
immutable
as $$
  with x as (
    select regexp_replace(coalesce(p_phone,''),'[^0-9]','','g') as d
  )
  select case
    when d like '60%' and length(d) > 10 then '0' || substr(d,3)
    else d
  end
  from x;
$$;

create table if not exists public.marketing_customer_first_touch (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  store_id uuid not null,
  customer_id uuid null references public.customers(id) on delete set null,
  customer_phone text not null,
  normalized_phone text not null,
  tracking_link_id uuid null references public.tracking_links(id) on delete set null,
  channel_id uuid null references public.marketing_channels(id) on delete set null,
  social_account_id uuid null references public.social_accounts(id) on delete set null,
  content_id uuid null references public.marketing_contents(id) on delete set null,
  staff_id uuid null references public.employees(id) on delete set null,
  ref_code text null,
  first_whatsapp_message_id text null,
  first_message_at timestamptz not null default now(),
  attribution_status text not null default 'unknown',
  source_fallback_needed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists marketing_customer_first_touch_phone_uq
  on public.marketing_customer_first_touch(organization_id,store_id,normalized_phone);
create index if not exists marketing_customer_first_touch_store_time_idx
  on public.marketing_customer_first_touch(organization_id,store_id,first_message_at desc);
create index if not exists marketing_customer_first_touch_customer_idx
  on public.marketing_customer_first_touch(customer_id)
  where customer_id is not null;

alter table public.marketing_customer_first_touch enable row level security;

drop policy if exists v136109_first_touch_read on public.marketing_customer_first_touch;
create policy v136109_first_touch_read on public.marketing_customer_first_touch
for select to authenticated
using (
  public.is_organization_member(organization_id)
  and public.can_access_store(store_id)
);

drop policy if exists v136109_first_touch_manage on public.marketing_customer_first_touch;
create policy v136109_first_touch_manage on public.marketing_customer_first_touch
for all to authenticated
using (
  public.has_organization_role(organization_id,array['owner','manager'])
  and public.can_access_store(store_id)
)
with check (
  public.has_organization_role(organization_id,array['owner','manager'])
  and public.can_access_store(store_id)
);

grant select on public.marketing_customer_first_touch to authenticated;
grant all on public.marketing_customer_first_touch to service_role;

-- Backfill ONE earliest available Marketing Lead per normalized phone.
-- This is intentionally INSERT ... ON CONFLICT DO NOTHING so rerunning this migration never rewrites first-touch history.
with ranked as (
  select
    ml.*,
    public.v136109_normalize_phone_text(ml.customer_phone) as normalized_phone_value,
    row_number() over (
      partition by ml.organization_id,ml.store_id,public.v136109_normalize_phone_text(ml.customer_phone)
      order by coalesce(ml.first_message_at,ml.created_at) asc, ml.created_at asc, ml.id asc
    ) as rn
  from public.marketing_leads ml
  where public.v136109_normalize_phone_text(ml.customer_phone) <> ''
)
insert into public.marketing_customer_first_touch(
  organization_id,store_id,customer_id,customer_phone,normalized_phone,
  tracking_link_id,channel_id,social_account_id,content_id,staff_id,ref_code,
  first_whatsapp_message_id,first_message_at,attribution_status,source_fallback_needed,
  created_at,updated_at
)
select
  organization_id,store_id,customer_id,customer_phone,normalized_phone_value,
  tracking_link_id,channel_id,social_account_id,content_id,staff_id,ref_code,
  whatsapp_message_id,coalesce(first_message_at,created_at),coalesce(attribution_status,'unknown'),coalesce(source_fallback_needed,false),
  coalesce(first_message_at,created_at),now()
from ranked
where rn=1
on conflict (organization_id,store_id,normalized_phone) do nothing;

-- Database-level first-touch lock.
-- The webhook can continue to write Marketing Leads normally; this trigger guarantees that
-- subsequent messages / new refs / later platforms cannot overwrite the first source for the same phone.
create or replace function public.v136109_lock_marketing_first_touch()
returns trigger
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_norm text;
  v_ft public.marketing_customer_first_touch%rowtype;
begin
  v_norm := public.v136109_normalize_phone_text(new.customer_phone);
  if v_norm = '' then
    return new;
  end if;

  insert into public.marketing_customer_first_touch(
    organization_id,store_id,customer_id,customer_phone,normalized_phone,
    tracking_link_id,channel_id,social_account_id,content_id,staff_id,ref_code,
    first_whatsapp_message_id,first_message_at,attribution_status,source_fallback_needed,
    created_at,updated_at
  ) values (
    new.organization_id,new.store_id,new.customer_id,new.customer_phone,v_norm,
    new.tracking_link_id,new.channel_id,new.social_account_id,new.content_id,new.staff_id,new.ref_code,
    new.whatsapp_message_id,coalesce(new.first_message_at,new.created_at,now()),coalesce(new.attribution_status,'unknown'),coalesce(new.source_fallback_needed,false),
    coalesce(new.first_message_at,new.created_at,now()),now()
  )
  on conflict (organization_id,store_id,normalized_phone) do nothing;

  select * into v_ft
  from public.marketing_customer_first_touch
  where organization_id=new.organization_id
    and store_id=new.store_id
    and normalized_phone=v_norm
  limit 1;

  if v_ft.id is not null then
    -- Immutable first-touch attribution.
    new.tracking_link_id := v_ft.tracking_link_id;
    new.channel_id := v_ft.channel_id;
    new.social_account_id := v_ft.social_account_id;
    new.content_id := v_ft.content_id;
    new.staff_id := v_ft.staff_id;
    new.ref_code := v_ft.ref_code;
    new.attribution_status := v_ft.attribution_status;
    new.source_fallback_needed := v_ft.source_fallback_needed;

    -- Preserve the first message timestamp instead of changing it on every WhatsApp message.
    if new.first_message_at is null or new.first_message_at > v_ft.first_message_at then
      new.first_message_at := v_ft.first_message_at;
    end if;

    -- Customer profile can be linked later without changing source attribution.
    if new.customer_id is not null and v_ft.customer_id is null then
      update public.marketing_customer_first_touch
      set customer_id=new.customer_id,updated_at=now()
      where id=v_ft.id and customer_id is null;
    end if;
  end if;

  return new;
end;
$$;

revoke all on function public.v136109_lock_marketing_first_touch() from public;
grant execute on function public.v136109_lock_marketing_first_touch() to authenticated,service_role;

drop trigger if exists trg_v136109_marketing_first_touch on public.marketing_leads;
create trigger trg_v136109_marketing_first_touch
before insert or update of customer_phone,customer_id,tracking_link_id,channel_id,social_account_id,content_id,staff_id,ref_code,attribution_status,source_fallback_needed,first_message_at
on public.marketing_leads
for each row
execute function public.v136109_lock_marketing_first_touch();

commit;

select
  'SalonOS v13.6.10.9 FIRST TOUCH UNIQUE CUSTOMER ANALYTICS READY' as result,
  count(*) as first_touch_customers
from public.marketing_customer_first_touch;
