-- SalonOS v13.6.10 · English Skill Catalog + Skill-Aware System Stylist Assignment
-- Run AFTER v13.6.9.7.
-- Additive / idempotent. Existing employee.skill_tags and service.category remain supported.
-- Canonical skill codes are English. Legacy Chinese/English/Malay labels are compatibility inputs only.

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- 1) Canonical English skill catalog.
-- -----------------------------------------------------------------------------
create table if not exists public.skill_catalog (
  skill_code text primary key,
  category_code text not null,
  display_name_en text not null,
  aliases jsonb not null default '[]'::jsonb,
  active boolean not null default true,
  sort_order integer not null default 100,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (skill_code ~ '^[a-z0-9_]+$'),
  check (category_code ~ '^[a-z0-9_]+$'),
  check (jsonb_typeof(aliases)='array')
);

insert into public.skill_catalog(skill_code,category_code,display_name_en,aliases,sort_order)
values
  ('haircut_general','haircut','General Haircut','["haircut","cut","trim","剪发","剪髮","理发","理髮","potong rambut"]',10),
  ('mens_haircut','haircut','Men''s Haircut','["men haircut","mens haircut","male haircut","男士剪发","男士剪髮"]',11),
  ('womens_haircut','haircut','Women''s Haircut','["women haircut","womens haircut","female haircut","女士剪发","女士剪髮"]',12),
  ('kids_haircut','haircut','Kids Haircut','["kids haircut","children haircut","child haircut","儿童剪发","兒童剪髮"]',13),
  ('precision_cut','haircut','Precision Cut','["precision cut","technical cut","精修剪"]',14),
  ('layered_cut','haircut','Layered Cut','["layered cut","layers","层次剪","層次剪"]',15),
  ('bob_cut','haircut','Bob Cut','["bob","bob cut","波波头","波波頭"]',16),
  ('pixie_cut','haircut','Pixie Cut','["pixie","pixie cut","精灵短发","精靈短髮"]',17),
  ('fringe_bangs','haircut','Fringe / Bangs','["fringe","bangs","刘海","瀏海"]',18),
  ('fade','haircut','Fade','["fade","fade cut","渐层","漸層"]',19),
  ('skin_fade','haircut','Skin Fade','["skin fade","zero fade"]',20),
  ('undercut','haircut','Undercut','["undercut"]',21),
  ('clipper_cut','haircut','Clipper Cut','["clipper cut","machine cut"]',22),
  ('scissor_cut','haircut','Scissor Cut','["scissor cut","scissor work"]',23),
  ('curly_hair_cut','haircut','Curly Hair Cut','["curly haircut","curl cut","卷发剪裁","捲髮剪裁"]',24),

  ('hair_coloring','color','Hair Coloring','["hair color","hair colour","coloring","colouring","dye","染发","染髮","warna rambut"]',100),
  ('root_touch_up','color','Root Touch-Up','["root touch up","root retouch","roots","补染发根","補染髮根"]',101),
  ('full_color','color','Full Hair Color','["full color","full colour","全头染","全頭染"]',102),
  ('grey_coverage','color','Grey Coverage','["grey coverage","gray coverage","white hair coverage","白发覆盖","白髮覆蓋"]',103),
  ('fashion_color','color','Fashion Color','["fashion color","fashion colour","creative color","时尚染","時尚染"]',104),
  ('bleaching','color','Bleaching','["bleach","bleaching","lightening","漂发","漂髮","漂色"]',105),
  ('color_correction','color','Color Correction','["color correction","colour correction","corrective color","校色","改色"]',106),
  ('highlights','color','Highlights','["highlight","highlights","挑染"]',107),
  ('lowlights','color','Lowlights','["lowlight","lowlights","低光染"]',108),
  ('balayage','color','Balayage','["balayage","法式手刷染"]',109),
  ('ombre','color','Ombre','["ombre","ombre color","渐变染","漸變染"]',110),
  ('toning','color','Toning','["toner","toning","调色","調色"]',111),
  ('vivid_color','color','Vivid / Creative Color','["vivid color","creative color","rainbow hair","鲜艳染","鮮艷染"]',112),

  ('perm','perm','Perm','["perm","perming","烫发","燙髮"]',200),
  ('cold_perm','perm','Cold Perm','["cold perm","冷烫","冷燙"]',201),
  ('digital_perm','perm','Digital Perm','["digital perm","数码烫","數碼燙"]',202),
  ('texture_perm','perm','Texture Perm','["texture perm","textured perm","纹理烫","紋理燙"]',203),
  ('mens_perm','perm','Men''s Perm','["mens perm","men perm","男士烫发","男士燙髮"]',204),

  ('rebonding','straightening','Rebonding','["rebonding","rebond","hair rebonding","离子烫","離子燙","拉直"]',300),
  ('keratin_straightening','straightening','Keratin Straightening','["keratin straightening","keratin smoothing","角蛋白拉直"]',301),
  ('smoothing','straightening','Hair Smoothing','["smoothing","smoothening","柔顺","柔順"]',302),

  ('hair_treatment','treatment','Hair Treatment','["hair treatment","treatment","护理","護理"]',400),
  ('keratin_treatment','treatment','Keratin Treatment','["keratin treatment","keratin","角蛋白护理","角蛋白護理"]',401),
  ('bond_repair','treatment','Bond Repair','["bond repair","olaplex","bond treatment","键结修护","鍵結修護"]',402),
  ('scalp_treatment','treatment','Scalp Treatment','["scalp treatment","scalp care","头皮护理","頭皮護理"]',403),
  ('dandruff_treatment','treatment','Dandruff Treatment','["dandruff treatment","anti dandruff","去屑护理","去屑護理"]',404),
  ('hair_loss_scalp_care','treatment','Hair Loss / Scalp Care','["hair loss care","hair fall care","anti hair loss","防脱护理","防脫護理"]',405),

  ('hair_wash','styling','Hair Wash','["hair wash","shampoo","wash hair","洗头","洗頭"]',500),
  ('shampoo_blowdry','styling','Shampoo & Blow Dry','["wash and blow","shampoo blow dry","洗吹"]',501),
  ('blowout','styling','Blowout','["blowout","blow dry styling","吹整"]',502),
  ('curling_styling','styling','Curl Styling','["curl styling","curling","卷发造型","捲髮造型"]',503),
  ('straight_styling','styling','Straight Styling','["straight styling","straighten styling","直发造型","直髮造型"]',504),
  ('updo_event_styling','styling','Updo / Event Styling','["updo","event styling","party hair","宴会造型","宴會造型"]',505),
  ('bridal_styling','styling','Bridal Styling','["bridal hair","wedding hair","新娘造型"]',506),

  ('beard_trim','grooming','Beard Trim','["beard trim","trim beard","胡须修剪","鬍鬚修剪"]',600),
  ('beard_styling','grooming','Beard Styling','["beard styling","胡须造型","鬍鬚造型"]',601),
  ('hair_extensions','extension','Hair Extensions','["hair extension","hair extensions","extensions","接发","接髮"]',700),
  ('extension_removal','extension','Extension Removal','["extension removal","remove extensions","拆接发","拆接髮"]',701),
  ('head_massage','wellness','Head Massage','["head massage","scalp massage","头部按摩","頭部按摩"]',800)
on conflict(skill_code) do update set
  category_code=excluded.category_code,
  display_name_en=excluded.display_name_en,
  aliases=excluded.aliases,
  sort_order=excluded.sort_order,
  active=true,
  updated_at=now();

-- -----------------------------------------------------------------------------
-- 2) Employee skills with 1..5 proficiency level.
--    1 Beginner / 2 Junior / 3 Proficient / 4 Advanced / 5 Expert.
-- -----------------------------------------------------------------------------
create table if not exists public.employee_skills (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  employee_id uuid not null,
  skill_code text not null references public.skill_catalog(skill_code) on delete restrict,
  skill_level integer not null default 3 check(skill_level between 1 and 5),
  source text not null default 'manual' check(source in ('manual','legacy_skill_tags','imported','system')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,employee_id) references public.employees(organization_id,id) on delete cascade,
  unique(organization_id,employee_id,skill_code)
);
create index if not exists employee_skills_employee_idx on public.employee_skills(organization_id,employee_id,active,skill_level desc);
create index if not exists employee_skills_skill_idx on public.employee_skills(organization_id,skill_code,active,skill_level desc);

-- -----------------------------------------------------------------------------
-- 3) Service skill requirements. Services can require multiple skills.
-- -----------------------------------------------------------------------------
create table if not exists public.service_skill_requirements (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  service_id uuid not null references public.services(id) on delete cascade,
  skill_code text not null references public.skill_catalog(skill_code) on delete restrict,
  minimum_level integer not null default 2 check(minimum_level between 1 and 5),
  required boolean not null default true,
  weight numeric(6,2) not null default 1 check(weight > 0),
  source text not null default 'manual' check(source in ('manual','legacy_service_mapping','imported','system')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(organization_id,store_id,service_id,skill_code)
);
create index if not exists service_skill_requirements_service_idx on public.service_skill_requirements(organization_id,store_id,service_id,active);
create index if not exists service_skill_requirements_skill_idx on public.service_skill_requirements(organization_id,store_id,skill_code,active);

-- -----------------------------------------------------------------------------
-- 4) RLS / grants. Catalog is shared read-only metadata; tenant skill data is scoped.
-- -----------------------------------------------------------------------------
alter table public.skill_catalog enable row level security;
alter table public.employee_skills enable row level security;
alter table public.service_skill_requirements enable row level security;

drop policy if exists skill_catalog_read on public.skill_catalog;
create policy skill_catalog_read on public.skill_catalog for select to authenticated using(active=true);

drop policy if exists employee_skills_read on public.employee_skills;
create policy employee_skills_read on public.employee_skills for select to authenticated
using(public.is_organization_member(organization_id));

drop policy if exists employee_skills_manage on public.employee_skills;
create policy employee_skills_manage on public.employee_skills for all to authenticated
using(public.has_organization_role(organization_id,array['owner','manager']))
with check(public.has_organization_role(organization_id,array['owner','manager']));

drop policy if exists service_skill_requirements_read on public.service_skill_requirements;
create policy service_skill_requirements_read on public.service_skill_requirements for select to authenticated
using(public.is_organization_member(organization_id) and public.can_access_store(store_id));

drop policy if exists service_skill_requirements_manage on public.service_skill_requirements;
create policy service_skill_requirements_manage on public.service_skill_requirements for all to authenticated
using(public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check(public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

grant select on public.skill_catalog to authenticated;
grant select,insert,update,delete on public.employee_skills,public.service_skill_requirements to authenticated;
grant all on public.skill_catalog,public.employee_skills,public.service_skill_requirements to service_role;

-- -----------------------------------------------------------------------------
-- 5) Compatibility sync: existing employees.skill_tags -> canonical English codes.
--    Existing skill_tags are retained. Legacy tags become level 3 (Proficient).
-- -----------------------------------------------------------------------------
create or replace function public.v13610_sync_employee_legacy_skills(p_employee_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_e public.employees%rowtype;
  v_tags text;
begin
  select * into v_e from public.employees where id=p_employee_id limit 1;
  if v_e.id is null then return; end if;

  delete from public.employee_skills
  where organization_id=v_e.organization_id and employee_id=v_e.id and source='legacy_skill_tags';

  v_tags:=lower(coalesce(v_e.skill_tags,''));
  if trim(v_tags)='' then return; end if;

  if v_tags ~ '(hair\s*cut|haircut|cutting|剪发|剪髮|理发|理髮|potong\s*rambut)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'haircut_general',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(men.?s\s*haircut|male\s*haircut|男士剪发|男士剪髮)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'mens_haircut',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(women.?s\s*haircut|female\s*haircut|女士剪发|女士剪髮)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'womens_haircut',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(color|colour|dye|染发|染髮|染色|warna\s*rambut)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'hair_coloring',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(bleach|漂发|漂髮|漂色)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'bleaching',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(highlight|挑染)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'highlights',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(balayage|手刷染)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'balayage',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(perm|烫发|燙髮)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'perm',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(rebond|拉直|离子|離子)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'rebonding',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(keratin|角蛋白)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'keratin_treatment',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(scalp|头皮|頭皮)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'scalp_treatment',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(treatment|护理|護理)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'hair_treatment',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(wash|shampoo|洗头|洗頭)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'hair_wash',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(styling|造型|blow\s*dry|吹整)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'blowout',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(extension|接发|接髮)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'hair_extensions',3,'legacy_skill_tags') on conflict do nothing;
  end if;
  if v_tags ~ '(beard|胡须|鬍鬚)' then
    insert into public.employee_skills(organization_id,employee_id,skill_code,skill_level,source)
    values(v_e.organization_id,v_e.id,'beard_trim',3,'legacy_skill_tags') on conflict do nothing;
  end if;
end;
$$;
revoke all on function public.v13610_sync_employee_legacy_skills(uuid) from public,anon,authenticated;
grant execute on function public.v13610_sync_employee_legacy_skills(uuid) to service_role;

create or replace function public.v13610_employee_skill_tags_trigger()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.v13610_sync_employee_legacy_skills(new.id);
  return new;
end;
$$;

drop trigger if exists trg_v13610_employee_skill_tags on public.employees;
create trigger trg_v13610_employee_skill_tags
after insert or update of skill_tags on public.employees
for each row execute function public.v13610_employee_skill_tags_trigger();

-- -----------------------------------------------------------------------------
-- 6) Compatibility sync: existing service name/category -> canonical requirements.
--    Manual requirements are never deleted by the legacy mapper.
-- -----------------------------------------------------------------------------
create or replace function public.v13610_add_legacy_service_requirement(
  p_organization_id uuid,
  p_store_id uuid,
  p_service_id uuid,
  p_skill_code text,
  p_level integer default 2
) returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  insert into public.service_skill_requirements(
    organization_id,store_id,service_id,skill_code,minimum_level,required,source,active,updated_at
  ) values(p_organization_id,p_store_id,p_service_id,p_skill_code,p_level,true,'legacy_service_mapping',true,now())
  on conflict(organization_id,store_id,service_id,skill_code) do nothing;
end;
$$;
revoke all on function public.v13610_add_legacy_service_requirement(uuid,uuid,uuid,text,integer) from public,anon,authenticated;
grant execute on function public.v13610_add_legacy_service_requirement(uuid,uuid,uuid,text,integer) to service_role;

create or replace function public.v13610_sync_service_legacy_requirements(p_service_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v_s public.services%rowtype;
  v_text text;
begin
  select * into v_s from public.services where id=p_service_id limit 1;
  if v_s.id is null then return; end if;

  delete from public.service_skill_requirements
  where organization_id=v_s.organization_id and store_id=v_s.store_id and service_id=v_s.id and source='legacy_service_mapping';

  -- If management already configured manual/imported requirements, trust those.
  if exists(
    select 1 from public.service_skill_requirements r
    where r.organization_id=v_s.organization_id and r.store_id=v_s.store_id and r.service_id=v_s.id
      and r.active=true and r.source<>'legacy_service_mapping'
  ) then return; end if;

  v_text:=lower(coalesce(v_s.name,'')||' '||coalesce(v_s.category,''));

  if v_text ~ '(balayage|手刷染)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'hair_coloring',2); perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'bleaching',2); perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'balayage',2);
  elsif v_text ~ '(ombre|渐变染|漸變染)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'hair_coloring',2); perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'bleaching',2); perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'ombre',2);
  elsif v_text ~ '(highlight|挑染)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'hair_coloring',2); perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'bleaching',2); perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'highlights',2);
  elsif v_text ~ '(bleach|漂发|漂髮|漂色)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'bleaching',2);
  elsif v_text ~ '(root\s*touch|root\s*retouch|补染发根|補染髮根)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'hair_coloring',2); perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'root_touch_up',2);
  elsif v_text ~ '(grey|gray|white\s*hair|白发|白髮)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'hair_coloring',2); perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'grey_coverage',2);
  elsif v_text ~ '(color|colour|dye|染发|染髮|染色)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'hair_coloring',2);
  elsif v_text ~ '(digital\s*perm|数码烫|數碼燙)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'perm',2); perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'digital_perm',2);
  elsif v_text ~ '(perm|烫发|燙髮)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'perm',2);
  elsif v_text ~ '(rebond|拉直|离子|離子)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'rebonding',2);
  elsif v_text ~ '(scalp|头皮|頭皮)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'scalp_treatment',2);
  elsif v_text ~ '(keratin|角蛋白)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'keratin_treatment',2);
  elsif v_text ~ '(treatment|护理|護理)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'hair_treatment',2);
  elsif v_text ~ '(beard|胡须|鬍鬚)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'beard_trim',2);
  elsif v_text ~ '(extension|接发|接髮)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'hair_extensions',2);
  elsif v_text ~ '(wash|shampoo|洗头|洗頭)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'hair_wash',1);
  elsif v_text ~ '(hair\s*cut|haircut|cut|trim|剪发|剪髮|理发|理髮)' then
    perform public.v13610_add_legacy_service_requirement(v_s.organization_id,v_s.store_id,v_s.id,'haircut_general',2);
  end if;
end;
$$;
revoke all on function public.v13610_sync_service_legacy_requirements(uuid) from public,anon,authenticated;
grant execute on function public.v13610_sync_service_legacy_requirements(uuid) to service_role;

create or replace function public.v13610_service_skill_trigger()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.v13610_sync_service_legacy_requirements(new.id);
  return new;
end;
$$;

drop trigger if exists trg_v13610_service_skill_mapping on public.services;
create trigger trg_v13610_service_skill_mapping
after insert or update of name,category on public.services
for each row execute function public.v13610_service_skill_trigger();

-- Run compatibility sync once for existing data.
do $$ declare r record; begin
  for r in select id from public.employees loop
    perform public.v13610_sync_employee_legacy_skills(r.id);
  end loop;
  for r in select id from public.services loop
    perform public.v13610_sync_service_legacy_requirements(r.id);
  end loop;
end $$;

-- -----------------------------------------------------------------------------
-- 7) Skill-aware system assignment.
--    - no exact time: return pooled slots, do NOT choose a stylist yet.
--    - exact time: randomly choose ONLY among qualified + scheduled + free staff.
-- -----------------------------------------------------------------------------
create or replace function public.v13610_ai_assign_staff(
  p_queue_id uuid,
  p_service_id uuid,
  p_date date,
  p_time_iso text default null,
  p_time_period text default 'unspecified'
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_tenant jsonb;
  v_org uuid;
  v_store uuid;
  v_service public.services%rowtype;
  v_req_count integer:=0;
  v_qualified_count integer:=0;
  v_schedule_unconfigured integer:=0;
  v_candidate_count integer:=0;
  v_emp record;
  v_availability jsonb;
  v_candidates jsonb:='[]'::jsonb;
  v_pool jsonb:='[]'::jsonb;
  v_pooled_slots jsonb:='[]'::jsonb;
  v_required jsonb:='[]'::jsonb;
  v_selected jsonb:=null;
  v_exact text:=nullif(trim(coalesce(p_time_iso,'')),'');
  v_status text;
  v_matched_skills jsonb;
  v_slot jsonb;
begin
  v_tenant:=public.v1365_ai_queue_tenant(p_queue_id);
  v_org:=(v_tenant->>'organization_id')::uuid;
  v_store:=(v_tenant->>'store_id')::uuid;

  select * into v_service from public.services s
  where s.id=p_service_id and s.organization_id=v_org and s.store_id=v_store and coalesce(s.active,true)=true;
  if v_service.id is null then
    return jsonb_build_object('ok',false,'tool','assign_staff','assignment_status','invalid_service','staff',null,'slots','[]'::jsonb);
  end if;

  select count(*)::int,
         coalesce(jsonb_agg(jsonb_build_object(
           'skill_code',r.skill_code,
           'display_name_en',c.display_name_en,
           'minimum_level',r.minimum_level,
           'required',r.required
         ) order by c.category_code,c.sort_order,c.display_name_en),'[]'::jsonb)
  into v_req_count,v_required
  from public.service_skill_requirements r
  join public.skill_catalog c on c.skill_code=r.skill_code and c.active=true
  where r.organization_id=v_org and r.store_id=v_store and r.service_id=v_service.id and r.active=true and r.required=true;

  if v_req_count=0 then
    return jsonb_build_object(
      'ok',true,'tool','assign_staff','assignment_status','service_skill_unconfigured',
      'assignment_type','random','assignment_strategy','skill_availability_random',
      'service',jsonb_build_object('id',v_service.id,'name',v_service.name,'category',v_service.category),
      'required_skills','[]'::jsonb,'staff',null,'slots','[]'::jsonb
    );
  end if;

  for v_emp in
    select e.id,e.name,e.employee_code,e.position,e.skill_tags,e.is_on_duty,e.availability_status,
      coalesce((
        select round(avg(eskl.skill_level)::numeric,2)
        from public.service_skill_requirements rr
        join public.employee_skills eskl
          on eskl.organization_id=v_org and eskl.employee_id=e.id and eskl.skill_code=rr.skill_code and eskl.active=true
        where rr.organization_id=v_org and rr.store_id=v_store and rr.service_id=v_service.id and rr.active=true and rr.required=true
      ),0) as skill_score
    from public.employees e
    join public.employee_stores est on est.employee_id=e.id and est.organization_id=e.organization_id
    where e.organization_id=v_org and est.store_id=v_store and est.status='active' and e.employment_status='active'
      and not exists(
        select 1
        from public.service_skill_requirements r
        where r.organization_id=v_org and r.store_id=v_store and r.service_id=v_service.id and r.active=true and r.required=true
          and not exists(
            select 1 from public.employee_skills sk
            where sk.organization_id=v_org and sk.employee_id=e.id and sk.skill_code=r.skill_code
              and sk.active=true and sk.skill_level>=r.minimum_level
          )
      )
    order by e.name
  loop
    v_qualified_count:=v_qualified_count+1;

    select coalesce(jsonb_agg(jsonb_build_object(
      'skill_code',r.skill_code,
      'minimum_level',r.minimum_level,
      'employee_level',sk.skill_level
    ) order by r.skill_code),'[]'::jsonb)
    into v_matched_skills
    from public.service_skill_requirements r
    join public.employee_skills sk
      on sk.organization_id=v_org and sk.employee_id=v_emp.id and sk.skill_code=r.skill_code and sk.active=true
    where r.organization_id=v_org and r.store_id=v_store and r.service_id=v_service.id and r.active=true and r.required=true;

    v_availability:=public.v1366_ai_check_availability(
      p_queue_id,v_service.id,v_emp.id,p_date,v_exact,coalesce(p_time_period,'unspecified')
    );
    v_status:=coalesce(v_availability->>'availability_status','unknown');
    if v_status in ('schedule_unconfigured','schedule_invalid') then
      v_schedule_unconfigured:=v_schedule_unconfigured+1;
      continue;
    end if;

    if v_status='available' then
      if v_exact is not null then
        if exists(
          select 1 from jsonb_array_elements(coalesce(v_availability->'slots','[]'::jsonb)) x
          where x->>'time'=v_exact
        ) then
          v_candidates:=v_candidates||jsonb_build_array(jsonb_build_object(
            'id',v_emp.id,'name',v_emp.name,'employee_code',v_emp.employee_code,'position',v_emp.position,
            'skill_score',v_emp.skill_score,'matched_skills',v_matched_skills,
            'live_availability_status',v_emp.availability_status,'availability',v_availability
          ));
          v_candidate_count:=v_candidate_count+1;
        end if;
      else
        if jsonb_array_length(coalesce(v_availability->'slots','[]'::jsonb))>0 then
          v_candidates:=v_candidates||jsonb_build_array(jsonb_build_object(
            'id',v_emp.id,'name',v_emp.name,'employee_code',v_emp.employee_code,'position',v_emp.position,
            'skill_score',v_emp.skill_score,'matched_skills',v_matched_skills,
            'live_availability_status',v_emp.availability_status
          ));
          v_candidate_count:=v_candidate_count+1;
          for v_slot in select value from jsonb_array_elements(coalesce(v_availability->'slots','[]'::jsonb)) loop
            v_pool:=v_pool||jsonb_build_array(jsonb_build_object(
              'time',v_slot->>'time','employee_id',v_emp.id,'employee_name',v_emp.name
            ));
          end loop;
        end if;
      end if;
    end if;
  end loop;

  if v_qualified_count=0 then
    return jsonb_build_object(
      'ok',true,'tool','assign_staff','assignment_status','no_qualified_staff',
      'assignment_type','random','assignment_strategy','skill_availability_random',
      'service',jsonb_build_object('id',v_service.id,'name',v_service.name,'category',v_service.category),
      'required_skills',v_required,'qualified_staff_count',0,'staff',null,'slots','[]'::jsonb
    );
  end if;

  if v_candidate_count=0 then
    return jsonb_build_object(
      'ok',true,'tool','assign_staff',
      'assignment_status',case when v_schedule_unconfigured=v_qualified_count then 'schedule_unconfigured' else 'no_slots' end,
      'assignment_type','random','assignment_strategy','skill_availability_random',
      'service',jsonb_build_object('id',v_service.id,'name',v_service.name,'category',v_service.category),
      'required_skills',v_required,'qualified_staff_count',v_qualified_count,
      'schedule_unconfigured_count',v_schedule_unconfigured,'staff',null,'candidates','[]'::jsonb,'slots','[]'::jsonb
    );
  end if;

  if v_exact is null then
    select coalesce(jsonb_agg(jsonb_build_object(
      'time',z.time,
      'available_staff_count',z.staff_count
    ) order by z.time),'[]'::jsonb)
    into v_pooled_slots
    from (
      select x->>'time' as time,count(distinct x->>'employee_id')::int as staff_count
      from jsonb_array_elements(v_pool) x
      where nullif(x->>'time','') is not null
      group by x->>'time'
      order by x->>'time'
      limit 12
    ) z;

    return jsonb_build_object(
      'ok',true,'tool','assign_staff','assignment_status','needs_time_selection',
      'resolution_status','system_pool','assignment_type','random','assignment_strategy','skill_availability_random',
      'service',jsonb_build_object('id',v_service.id,'name',v_service.name,'category',v_service.category),
      'required_skills',v_required,'qualified_staff_count',v_qualified_count,
      'eligible_staff_count',v_candidate_count,'staff',null,'candidates',v_candidates,'slots',v_pooled_slots
    );
  end if;

  select value into v_selected from jsonb_array_elements(v_candidates) order by random() limit 1;
  return jsonb_build_object(
    'ok',true,'tool','assign_staff','assignment_status','assigned','resolution_status','matched',
    'assignment_type','random','assignment_strategy','skill_availability_random',
    'service',jsonb_build_object('id',v_service.id,'name',v_service.name,'category',v_service.category),
    'required_skills',v_required,'qualified_staff_count',v_qualified_count,'eligible_staff_count',v_candidate_count,
    'staff',v_selected - 'availability',
    'candidates',v_candidates,
    'availability',coalesce(v_selected->'availability','{}'::jsonb),
    'slots',coalesce(v_selected#>'{availability,slots}','[]'::jsonb)
  );
end;
$$;
revoke all on function public.v13610_ai_assign_staff(uuid,uuid,date,text,text) from public,anon,authenticated;
grant execute on function public.v13610_ai_assign_staff(uuid,uuid,date,text,text) to service_role;

-- -----------------------------------------------------------------------------
-- 8) Persist assignment type on AI booking drafts, and fix analytics after confirm.
-- -----------------------------------------------------------------------------
alter table public.whatsapp_ai_appointment_drafts
  add column if not exists assignment_type text not null default 'specified',
  add column if not exists assignment_strategy text;

do $$ begin
  if not exists(
    select 1 from pg_constraint
    where conrelid='public.whatsapp_ai_appointment_drafts'::regclass
      and conname='whatsapp_ai_drafts_assignment_type_check'
  ) then
    alter table public.whatsapp_ai_appointment_drafts
      add constraint whatsapp_ai_drafts_assignment_type_check
      check(assignment_type in ('specified','random'));
  end if;
end $$;

create or replace function public.v13610_fix_confirmed_preference_from_ai_draft()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if new.status='confirmed' and new.confirmed_visit_id is not null
     and (old.status is distinct from new.status or old.confirmed_visit_id is distinct from new.confirmed_visit_id) then
    insert into public.appointment_employee_preferences(
      organization_id,store_id,visit_id,preference_type,employee_id,updated_at
    ) values(
      new.organization_id,new.store_id,new.confirmed_visit_id,
      case when new.assignment_type='random' then 'random' else 'specified' end,
      case when new.assignment_type='random' then null else new.employee_id end,
      now()
    )
    on conflict(visit_id) do update set
      preference_type=excluded.preference_type,
      employee_id=excluded.employee_id,
      updated_at=now();
  end if;
  return new;
end;
$$;

drop trigger if exists trg_v13610_ai_draft_preference_fix on public.whatsapp_ai_appointment_drafts;
create trigger trg_v13610_ai_draft_preference_fix
after update of status,confirmed_visit_id on public.whatsapp_ai_appointment_drafts
for each row execute function public.v13610_fix_confirmed_preference_from_ai_draft();

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('skill_catalog_version','13.6.10'),
 ('employee_skill_engine_version','13.6.10'),
 ('service_skill_requirement_version','13.6.10'),
 ('whatsapp_ai_system_assignment_version','13.6.10'),
 ('whatsapp_ai_default_reply_language','en')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.6.10 ENGLISH SKILLS + SYSTEM ASSIGNMENT READY' as result,
  to_regclass('public.skill_catalog') is not null as skill_catalog_ok,
  to_regclass('public.employee_skills') is not null as employee_skills_ok,
  to_regclass('public.service_skill_requirements') is not null as service_requirements_ok,
  to_regprocedure('public.v13610_ai_assign_staff(uuid,uuid,date,text,text)') is not null as assignment_rpc_ok,
  (select count(*) from public.skill_catalog where active=true) as canonical_skill_count,
  (select count(*) from public.employee_skills where active=true) as employee_skill_rows,
  (select count(*) from public.service_skill_requirements where active=true) as service_requirement_rows;
