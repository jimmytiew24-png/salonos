-- SalonOS v13.6.1 · WhatsApp Business Cloud API Webhook + AI Queue
-- Additive / idempotent. Run once in Supabase SQL Editor AFTER v13.6.0.

begin;
set local statement_timeout='0';

create table if not exists public.whatsapp_business_connections (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  phone_number_id text not null,
  business_account_id text,
  display_phone_number text,
  enabled boolean not null default true,
  connection_status text not null default 'configured' check(connection_status in ('configured','live','disconnected','error')),
  last_webhook_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(phone_number_id),
  unique(organization_id,store_id,phone_number_id)
);
create index if not exists whatsapp_business_connections_store_idx
  on public.whatsapp_business_connections(organization_id,store_id,enabled);

create table if not exists public.whatsapp_conversations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  connection_id uuid not null references public.whatsapp_business_connections(id) on delete cascade,
  customer_wa_id text not null,
  customer_phone text not null,
  customer_name text,
  current_lead_id uuid references public.marketing_leads(id) on delete set null,
  status text not null default 'open' check(status in ('open','closed','blocked')),
  ai_enabled boolean not null default true,
  last_message_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(connection_id,customer_wa_id)
);
create index if not exists whatsapp_conversations_store_idx
  on public.whatsapp_conversations(organization_id,store_id,last_message_at desc);
create index if not exists whatsapp_conversations_phone_idx
  on public.whatsapp_conversations(customer_phone,last_message_at desc);

create table if not exists public.whatsapp_messages (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  connection_id uuid not null references public.whatsapp_business_connections(id) on delete cascade,
  conversation_id uuid not null references public.whatsapp_conversations(id) on delete cascade,
  direction text not null default 'inbound' check(direction in ('inbound','outbound')),
  meta_message_id text,
  message_type text not null default 'unknown',
  text_body text,
  ref_code text,
  delivery_status text,
  ai_status text not null default 'queued' check(ai_status in ('queued','processing','completed','failed','skipped')),
  raw_payload jsonb not null default '{}'::jsonb,
  received_at timestamptz not null default now(),
  sent_at timestamptz,
  created_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create unique index if not exists whatsapp_messages_meta_id_uidx
  on public.whatsapp_messages(meta_message_id) where meta_message_id is not null;
create index if not exists whatsapp_messages_conversation_idx
  on public.whatsapp_messages(conversation_id,received_at desc);
create index if not exists whatsapp_messages_store_idx
  on public.whatsapp_messages(organization_id,store_id,received_at desc);
create index if not exists whatsapp_messages_ref_idx
  on public.whatsapp_messages(ref_code) where ref_code is not null;

create table if not exists public.whatsapp_ai_queue (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  connection_id uuid not null references public.whatsapp_business_connections(id) on delete cascade,
  conversation_id uuid not null references public.whatsapp_conversations(id) on delete cascade,
  message_id uuid not null references public.whatsapp_messages(id) on delete cascade,
  lead_id uuid references public.marketing_leads(id) on delete set null,
  status text not null default 'queued' check(status in ('queued','processing','completed','failed','skipped')),
  context jsonb not null default '{}'::jsonb,
  attempts integer not null default 0,
  last_error text,
  available_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(message_id)
);
create index if not exists whatsapp_ai_queue_status_idx
  on public.whatsapp_ai_queue(status,available_at,created_at);
create index if not exists whatsapp_ai_queue_store_idx
  on public.whatsapp_ai_queue(organization_id,store_id,created_at desc);

-- Link v13.6.0 marketing leads to WhatsApp conversations and store attribution fallback state.
alter table public.marketing_leads add column if not exists whatsapp_conversation_id uuid references public.whatsapp_conversations(id) on delete set null;
alter table public.marketing_leads add column if not exists attribution_status text not null default 'unknown';
alter table public.marketing_leads add column if not exists source_fallback_needed boolean not null default false;
alter table public.marketing_leads add column if not exists first_message_at timestamptz;
create index if not exists marketing_leads_whatsapp_conversation_idx
  on public.marketing_leads(whatsapp_conversation_id) where whatsapp_conversation_id is not null;
create index if not exists marketing_leads_phone_store_idx
  on public.marketing_leads(organization_id,store_id,customer_phone,created_at desc);

-- RLS: humans can only see their organization/store. The Edge Function uses a Supabase secret/service role after verifying Meta.
do $$ declare t text; begin
  foreach t in array array['whatsapp_business_connections','whatsapp_conversations','whatsapp_messages','whatsapp_ai_queue'] loop
    execute format('alter table public.%I enable row level security',t);
  end loop;
end $$;

drop policy if exists v1361_wa_connections_read on public.whatsapp_business_connections;
create policy v1361_wa_connections_read on public.whatsapp_business_connections for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1361_wa_connections_manage on public.whatsapp_business_connections;
create policy v1361_wa_connections_manage on public.whatsapp_business_connections for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

drop policy if exists v1361_wa_conversations_read on public.whatsapp_conversations;
create policy v1361_wa_conversations_read on public.whatsapp_conversations for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));

drop policy if exists v1361_wa_messages_read on public.whatsapp_messages;
create policy v1361_wa_messages_read on public.whatsapp_messages for select to authenticated
using (public.is_organization_member(organization_id) and public.can_access_store(store_id));

drop policy if exists v1361_wa_ai_queue_read on public.whatsapp_ai_queue;
create policy v1361_wa_ai_queue_read on public.whatsapp_ai_queue for select to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

-- Explicit grants. RLS still limits authenticated users; service_role/secret key is server-side only.
grant select,insert,update,delete on public.whatsapp_business_connections to authenticated;
grant select on public.whatsapp_conversations, public.whatsapp_messages, public.whatsapp_ai_queue to authenticated;
grant all on public.whatsapp_business_connections, public.whatsapp_conversations, public.whatsapp_messages, public.whatsapp_ai_queue to service_role;
grant select,insert,update on public.marketing_leads, public.tracking_clicks, public.tracking_links to service_role;

commit;

select 'SalonOS v13.6.1 WHATSAPP WEBHOOK READY' as result;
