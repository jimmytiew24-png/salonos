-- SalonOS v13.6.2 · AI Customer Context / Search Customer
-- Phase 7: WhatsApp AI's first action is deterministic customer lookup, NOT an LLM reply.
-- Additive / idempotent. Run after v13.6.1.

begin;
set local statement_timeout = '0';

-- Race / ethnicity must never be AI-inferred. Historical values remain 'unknown' provenance
-- until they are explicitly confirmed by the customer or marked by staff/import tooling.
alter table public.customers
  add column if not exists ethnicity_source text not null default 'unknown';

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conrelid = 'public.customers'::regclass
      and conname = 'customers_ethnicity_source_check'
  ) then
    alter table public.customers
      add constraint customers_ethnicity_source_check
      check (ethnicity_source in ('unknown','customer_provided','staff_entered','imported'));
  end if;
end $$;

create index if not exists customers_phone_normalized_lookup_idx
  on public.customers (
    organization_id,
    store_id,
    (regexp_replace(coalesce(phone,''), '[^0-9]', '', 'g'))
  );

-- Internal backend action.
-- Input is ONLY queue_id. Organization, branch, phone and lead are derived from the
-- already-verified WhatsApp queue/conversation. The AI is never trusted to supply tenant IDs.
create or replace function public.v1362_ai_prepare_customer_context(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_q public.whatsapp_ai_queue%rowtype;
  v_conv public.whatsapp_conversations%rowtype;
  v_phone text;
  v_customer_ids uuid[];
  v_customer public.customers%rowtype;
  v_member public.memberships%rowtype;
  v_level public.membership_levels%rowtype;
  v_completed_visit_count integer := 0;
  v_last_visit_at timestamptz;
  v_favourite_service text;
  v_dominant_stylist_id uuid;
  v_dominant_stylist_name text;
  v_points numeric := 0;
  v_experience numeric := 0;
  v_wallet numeric := 0;
  v_age integer;
  v_channel_name text;
  v_account_name text;
  v_account_username text;
  v_source_staff_id uuid;
  v_source_staff_name text;
  v_content_title text;
  v_content_code text;
  v_ref_code text;
  v_attribution_status text := 'unknown';
  v_source_fallback_needed boolean := false;
  v_result jsonb;
  v_missing_fields jsonb := '[]'::jsonb;
begin
  if p_queue_id is null then
    return jsonb_build_object('ok',false,'error','queue_id_required');
  end if;

  select * into v_q
  from public.whatsapp_ai_queue
  where id = p_queue_id
  limit 1;

  if v_q.id is null then
    return jsonb_build_object('ok',false,'error','queue_not_found');
  end if;

  select * into v_conv
  from public.whatsapp_conversations
  where id = v_q.conversation_id
    and organization_id = v_q.organization_id
    and store_id = v_q.store_id
    and connection_id = v_q.connection_id
  limit 1;

  if v_conv.id is null then
    return jsonb_build_object('ok',false,'error','conversation_scope_mismatch');
  end if;

  v_phone := regexp_replace(coalesce(v_conv.customer_phone,''), '[^0-9]', '', 'g');
  if v_phone = '' then
    return jsonb_build_object('ok',false,'error','customer_phone_missing');
  end if;

  -- Current-message attribution comes from the already-created lead. Expand IDs to names
  -- so the next AI stage receives useful context without inventing anything.
  if v_q.lead_id is not null then
    select
      mc.name,
      sa.display_name,
      sa.username,
      coalesce(ml.staff_id, sa.staff_id),
      e.name,
      ct.title,
      ct.content_code,
      ml.ref_code,
      coalesce(ml.attribution_status,'unknown'),
      coalesce(ml.source_fallback_needed,false)
    into
      v_channel_name,
      v_account_name,
      v_account_username,
      v_source_staff_id,
      v_source_staff_name,
      v_content_title,
      v_content_code,
      v_ref_code,
      v_attribution_status,
      v_source_fallback_needed
    from public.marketing_leads ml
    left join public.marketing_channels mc
      on mc.id = ml.channel_id
     and mc.organization_id = ml.organization_id
     and mc.store_id = ml.store_id
    left join public.social_accounts sa
      on sa.id = ml.social_account_id
     and sa.organization_id = ml.organization_id
     and sa.store_id = ml.store_id
    left join public.employees e
      on e.id = coalesce(ml.staff_id, sa.staff_id)
     and e.organization_id = ml.organization_id
    left join public.marketing_contents ct
      on ct.id = ml.content_id
     and ct.organization_id = ml.organization_id
     and ct.store_id = ml.store_id
    where ml.id = v_q.lead_id
      and ml.organization_id = v_q.organization_id
      and ml.store_id = v_q.store_id
    limit 1;
  end if;

  -- Exact normalized-phone lookup, hard-scoped to the verified Organization + Branch.
  select array_agg(c.id order by c.updated_at desc nulls last, c.created_at desc)
  into v_customer_ids
  from public.customers c
  where c.organization_id = v_q.organization_id
    and c.store_id = v_q.store_id
    and regexp_replace(coalesce(c.phone,''), '[^0-9]', '', 'g') = v_phone;

  if coalesce(cardinality(v_customer_ids),0) = 0 then
    -- A WhatsApp lead was already created by v13.6.1. Do NOT create a permanent customer row
    -- from an unqualified first message; that prevents spam/one-off enquiries polluting Customers.
    v_missing_fields := jsonb_build_array('name','age_or_birth_date','ethnicity');

    v_result := jsonb_build_object(
      'ok', true,
      'customer_status', 'new_lead',
      'phone', v_phone,
      'whatsapp_profile_name', nullif(v_conv.customer_name,''),
      'customer_id', null,
      'completed_visit_count', 0,
      'last_visit_at', null,
      'favourite_service', null,
      'dominant_stylist', null,
      'missing_fields', v_missing_fields,
      'attribution', jsonb_build_object(
        'ref_code', v_ref_code,
        'status', v_attribution_status,
        'source_fallback_needed', v_source_fallback_needed,
        'channel', v_channel_name,
        'source_account', coalesce(nullif(v_account_username,''), v_account_name),
        'source_staff_id', v_source_staff_id,
        'source_staff', v_source_staff_name,
        'source_content', coalesce(nullif(v_content_title,''), v_content_code)
      )
    );

    update public.whatsapp_ai_queue
    set context = coalesce(context,'{}'::jsonb) || jsonb_build_object(
          'pipeline_stage','customer_searched',
          'customer_search',v_result,
          'customer_search_at',now()
        ),
        updated_at = now()
    where id = v_q.id
      and organization_id = v_q.organization_id
      and store_id = v_q.store_id;

    return v_result;
  end if;

  -- Canonical customer: prefer an active member row, otherwise the most recently updated row.
  select c.* into v_customer
  from public.customers c
  left join public.memberships m
    on m.customer_id = c.id
   and m.organization_id = c.organization_id
   and m.status = 'active'
  where c.id = any(v_customer_ids)
    and c.organization_id = v_q.organization_id
    and c.store_id = v_q.store_id
  order by (m.id is not null) desc, c.updated_at desc nulls last, c.created_at desc
  limit 1;

  select m.* into v_member
  from public.memberships m
  where m.organization_id = v_q.organization_id
    and m.customer_id = v_customer.id
    and m.status = 'active'
  order by m.created_at desc
  limit 1;

  if v_member.id is not null then
    select ml.* into v_level
    from public.membership_levels ml
    where ml.id = v_member.current_level_id
      and ml.organization_id = v_q.organization_id
    limit 1;

    select coalesce(sum(l.points_delta),0), coalesce(sum(l.experience_delta),0)
    into v_points, v_experience
    from public.member_loyalty_ledger l
    where l.organization_id = v_q.organization_id
      and l.membership_id = v_member.id;

    select coalesce(sum(w.amount_delta),0)
    into v_wallet
    from public.member_wallet_ledger w
    where w.organization_id = v_q.organization_id
      and w.membership_id = v_member.id;
  end if;

  if v_customer.birth_date is not null then
    v_age := date_part('year', age(current_date, v_customer.birth_date))::integer;
  end if;

  -- A Visit counts ONLY after the service/order completed and was actually paid.
  -- Appointment no-show/cancelled/unpaid records therefore cannot inflate customer history.
  select
    count(distinct v.id)::integer,
    max(coalesce(
      (select max(p.paid_at)
       from public.payments p
       where p.visit_id = v.id
         and p.organization_id = v.organization_id
         and p.store_id = v.store_id
         and p.status = 'paid'),
      v.checked_out_at
    ))
  into v_completed_visit_count, v_last_visit_at
  from public.visits v
  join public.visit_recipients vr
    on vr.visit_id = v.id
   and vr.organization_id = v.organization_id
  where v.organization_id = v_q.organization_id
    and v.store_id = v_q.store_id
    and vr.customer_id = any(v_customer_ids)
    and v.status = 'completed'
    and v.service_completed_at is not null
    and v.checked_out_at is not null
    and (v.visit_type = 'walk_in' or v.arrived_at is not null)
    and exists (
      select 1
      from public.payments p
      where p.visit_id = v.id
        and p.organization_id = v.organization_id
        and p.store_id = v.store_id
        and p.status = 'paid'
    );

  select si.service_name_snapshot
  into v_favourite_service
  from public.visit_service_items si
  join public.visits v
    on v.id = si.visit_id
   and v.organization_id = si.organization_id
   and v.store_id = si.store_id
  where si.organization_id = v_q.organization_id
    and si.store_id = v_q.store_id
    and coalesce(si.status,'') <> 'cancelled'
    and exists (
      select 1
      from public.visit_recipients vr
      where vr.visit_id = v.id
        and vr.organization_id = v.organization_id
        and vr.customer_id = any(v_customer_ids)
    )
    and v.status = 'completed'
    and v.service_completed_at is not null
    and v.checked_out_at is not null
    and (v.visit_type = 'walk_in' or v.arrived_at is not null)
    and exists (
      select 1 from public.payments p
      where p.visit_id = v.id
        and p.organization_id = v.organization_id
        and p.store_id = v.store_id
        and p.status = 'paid'
    )
  group by si.service_name_snapshot
  order by count(*) desc, max(v.checked_out_at) desc
  limit 1;

  select e.id, e.name
  into v_dominant_stylist_id, v_dominant_stylist_name
  from public.visit_service_workers w
  join public.visit_service_items si
    on si.id = w.service_item_id
   and si.organization_id = w.organization_id
   and si.store_id = w.store_id
  join public.visits v
    on v.id = si.visit_id
   and v.organization_id = si.organization_id
   and v.store_id = si.store_id
  join public.employees e
    on e.id = w.employee_id
   and e.organization_id = w.organization_id
  where w.organization_id = v_q.organization_id
    and w.store_id = v_q.store_id
    and w.status = 'active'
    and w.worker_role in ('primary','support')
    and coalesce(si.status,'') <> 'cancelled'
    and exists (
      select 1
      from public.visit_recipients vr
      where vr.visit_id = v.id
        and vr.organization_id = v.organization_id
        and vr.customer_id = any(v_customer_ids)
    )
    and v.status = 'completed'
    and v.service_completed_at is not null
    and v.checked_out_at is not null
    and (v.visit_type = 'walk_in' or v.arrived_at is not null)
    and exists (
      select 1 from public.payments p
      where p.visit_id = v.id
        and p.organization_id = v.organization_id
        and p.store_id = v.store_id
        and p.status = 'paid'
    )
  group by e.id, e.name
  order by count(distinct v.id) desc,
           sum(coalesce(w.contribution_percent,0)) desc,
           max(v.checked_out_at) desc
  limit 1;

  if nullif(trim(coalesce(v_customer.name,'')),'') is null then
    v_missing_fields := v_missing_fields || '"name"'::jsonb;
  end if;
  if v_customer.birth_date is null then
    v_missing_fields := v_missing_fields || '"age_or_birth_date"'::jsonb;
  end if;
  if nullif(trim(coalesce(v_customer.ethnicity,'')),'') is null then
    v_missing_fields := v_missing_fields || '"ethnicity"'::jsonb;
  end if;

  -- Link this WhatsApp lead to the existing customer, but only inside the verified tenant/branch.
  if v_q.lead_id is not null then
    update public.marketing_leads
    set customer_id = v_customer.id,
        updated_at = now()
    where id = v_q.lead_id
      and organization_id = v_q.organization_id
      and store_id = v_q.store_id;
  end if;

  v_result := jsonb_build_object(
    'ok', true,
    'customer_status', 'existing_customer',
    'phone', v_phone,
    'customer_id', v_customer.id,
    'name', v_customer.name,
    'gender', v_customer.gender,
    'birth_date', v_customer.birth_date,
    'age', v_age,
    'ethnicity', v_customer.ethnicity,
    'ethnicity_source', coalesce(v_customer.ethnicity_source,'unknown'),
    'completed_visit_count', coalesce(v_completed_visit_count,0),
    'last_visit_at', v_last_visit_at,
    'favourite_service', v_favourite_service,
    'dominant_stylist', case when v_dominant_stylist_id is null then null else jsonb_build_object(
      'employee_id',v_dominant_stylist_id,
      'name',v_dominant_stylist_name
    ) end,
    'membership', case when v_member.id is null then null else jsonb_build_object(
      'membership_id',v_member.id,
      'member_number',v_member.member_number,
      'level_number',v_level.level_number,
      'level_name',v_level.name,
      'points',coalesce(v_points,0),
      'experience',coalesce(v_experience,0),
      'wallet_balance',coalesce(v_wallet,0)
    ) end,
    'missing_fields', v_missing_fields,
    'attribution', jsonb_build_object(
      'ref_code', v_ref_code,
      'status', v_attribution_status,
      'source_fallback_needed', v_source_fallback_needed,
      'channel', v_channel_name,
      'source_account', coalesce(nullif(v_account_username,''), v_account_name),
      'source_staff_id', v_source_staff_id,
      'source_staff', v_source_staff_name,
      'source_content', coalesce(nullif(v_content_title,''), v_content_code)
    )
  );

  update public.whatsapp_ai_queue
  set context = coalesce(context,'{}'::jsonb) || jsonb_build_object(
        'pipeline_stage','customer_searched',
        'customer_search',v_result,
        'customer_search_at',now()
      ),
      updated_at = now()
  where id = v_q.id
    and organization_id = v_q.organization_id
    and store_id = v_q.store_id;

  return v_result;
end;
$$;

-- Internal only. This is a backend action, not a browser/client RPC.
revoke all on function public.v1362_ai_prepare_customer_context(uuid) from public;
revoke all on function public.v1362_ai_prepare_customer_context(uuid) from anon;
revoke all on function public.v1362_ai_prepare_customer_context(uuid) from authenticated;
grant execute on function public.v1362_ai_prepare_customer_context(uuid) to service_role;

insert into public.salonos_system_meta(meta_key,meta_value)
values('whatsapp_ai_customer_context_version','13.6.2')
on conflict(meta_key) do update
set meta_value=excluded.meta_value, updated_at=now();

commit;
notify pgrst, 'reload schema';

select
  'SalonOS v13.6.2 AI CUSTOMER CONTEXT READY' as result,
  to_regprocedure('public.v1362_ai_prepare_customer_context(uuid)') is not null as search_customer_backend_ok;
