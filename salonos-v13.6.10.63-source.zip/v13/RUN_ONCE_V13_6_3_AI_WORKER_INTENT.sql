-- SalonOS v13.6.3 · Automatic WhatsApp AI Worker + Conversation State + Intent Detection
-- Run AFTER v13.6.2. Additive / idempotent.
-- LLM role: understand language only. It does NOT receive authority to write appointments or arbitrary SQL.

begin;
set local statement_timeout='0';

-- Machine-readable intent result on the original WhatsApp message for audit/search.
alter table public.whatsapp_messages add column if not exists ai_intent text;
alter table public.whatsapp_messages add column if not exists ai_confidence numeric(5,4);
alter table public.whatsapp_messages add column if not exists ai_entities jsonb not null default '{}'::jsonb;
alter table public.whatsapp_messages add column if not exists ai_processed_at timestamptz;

create index if not exists whatsapp_messages_ai_intent_idx
  on public.whatsapp_messages(organization_id,store_id,ai_intent,received_at desc)
  where ai_intent is not null;

-- One durable state row per WhatsApp conversation. This is the state machine foundation for
-- future multi-turn slots such as "3点" after the AI previously offered appointment times.
create table if not exists public.whatsapp_ai_conversation_state (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  conversation_id uuid not null references public.whatsapp_conversations(id) on delete cascade,
  state text not null default 'idle',
  active_intent text,
  pending_action text,
  slots jsonb not null default '{}'::jsonb,
  customer_context jsonb not null default '{}'::jsonb,
  last_queue_id uuid references public.whatsapp_ai_queue(id) on delete set null,
  last_message_id uuid references public.whatsapp_messages(id) on delete set null,
  last_model text,
  last_processed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(conversation_id)
);
create index if not exists whatsapp_ai_state_store_idx
  on public.whatsapp_ai_conversation_state(organization_id,store_id,updated_at desc);
create index if not exists whatsapp_ai_state_pending_idx
  on public.whatsapp_ai_conversation_state(organization_id,store_id,pending_action,updated_at desc)
  where pending_action is not null;

-- Immutable-ish run log for troubleshooting/cost/quality audits.
create table if not exists public.whatsapp_ai_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  queue_id uuid not null references public.whatsapp_ai_queue(id) on delete cascade,
  conversation_id uuid not null references public.whatsapp_conversations(id) on delete cascade,
  message_id uuid not null references public.whatsapp_messages(id) on delete cascade,
  stage text not null,
  provider text not null default 'openai',
  model text,
  status text not null default 'processing' check(status in ('processing','completed','failed','refused','skipped')),
  input_snapshot jsonb not null default '{}'::jsonb,
  output_snapshot jsonb not null default '{}'::jsonb,
  error text,
  duration_ms integer,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists whatsapp_ai_runs_queue_idx on public.whatsapp_ai_runs(queue_id,created_at desc);
create index if not exists whatsapp_ai_runs_store_idx on public.whatsapp_ai_runs(organization_id,store_id,created_at desc);

alter table public.whatsapp_ai_conversation_state enable row level security;
alter table public.whatsapp_ai_runs enable row level security;

drop policy if exists v1363_wa_ai_state_read on public.whatsapp_ai_conversation_state;
create policy v1363_wa_ai_state_read on public.whatsapp_ai_conversation_state
for select to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

drop policy if exists v1363_wa_ai_runs_read on public.whatsapp_ai_runs;
create policy v1363_wa_ai_runs_read on public.whatsapp_ai_runs
for select to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

grant select on public.whatsapp_ai_conversation_state, public.whatsapp_ai_runs to authenticated;
grant all on public.whatsapp_ai_conversation_state, public.whatsapp_ai_runs to service_role;
grant update on public.whatsapp_messages, public.whatsapp_ai_queue to service_role;

-- Atomic queue claim: only one worker can move a queued item into processing.
create or replace function public.v1363_ai_claim_queue(p_queue_id uuid)
returns table(
  id uuid,
  organization_id uuid,
  store_id uuid,
  connection_id uuid,
  conversation_id uuid,
  message_id uuid,
  lead_id uuid,
  context jsonb,
  attempts integer
)
language plpgsql
security definer
set search_path=public,pg_temp
as $$
begin
  return query
  update public.whatsapp_ai_queue q
     set status='processing',
         attempts=q.attempts+1,
         last_error=null,
         updated_at=now()
   where q.id=p_queue_id
     and q.status='queued'
     and q.available_at <= now()
  returning q.id,q.organization_id,q.store_id,q.connection_id,q.conversation_id,q.message_id,q.lead_id,q.context,q.attempts;
end;
$$;
revoke all on function public.v1363_ai_claim_queue(uuid) from public;
revoke all on function public.v1363_ai_claim_queue(uuid) from anon;
revoke all on function public.v1363_ai_claim_queue(uuid) from authenticated;
grant execute on function public.v1363_ai_claim_queue(uuid) to service_role;

insert into public.salonos_system_meta(meta_key,meta_value)
values('whatsapp_ai_worker_intent_version','13.6.3')
on conflict(meta_key) do update
set meta_value=excluded.meta_value, updated_at=now();

commit;
notify pgrst, 'reload schema';

select
  'SalonOS v13.6.3 AI WORKER + INTENT READY' as result,
  to_regprocedure('public.v1363_ai_claim_queue(uuid)') is not null as queue_claim_ok,
  to_regclass('public.whatsapp_ai_conversation_state') is not null as conversation_state_ok,
  to_regclass('public.whatsapp_ai_runs') is not null as ai_runs_ok;
