-- SalonOS v13.6.5 · Appointment Tool Layer
-- Adds deterministic backend tools for AI appointment handling.
-- AI may understand language, but all business facts are resolved/validated here.
-- Run ONCE in Supabase SQL Editor. Additive; does not delete business data.

begin;
set local statement_timeout = '0';

create schema if not exists extensions;
create extension if not exists pg_trgm with schema extensions;

-- -----------------------------------------------------------------------------
-- Booking policy + future staff schedules.
-- We intentionally DO NOT assume every employee works every day.
-- Until a schedule row exists, check_availability returns schedule_unconfigured.
-- -----------------------------------------------------------------------------
create table if not exists public.whatsapp_ai_booking_settings (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  timezone text not null default 'Asia/Kuala_Lumpur',
  slot_interval_minutes integer not null default 30 check (slot_interval_minutes between 5 and 120),
  minimum_notice_minutes integer not null default 30 check (minimum_notice_minutes between 0 and 10080),
  max_booking_days_ahead integer not null default 90 check (max_booking_days_ahead between 1 and 365),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(organization_id,store_id)
);

insert into public.whatsapp_ai_booking_settings(organization_id,store_id)
select s.organization_id,s.id
from public.stores s
where coalesce(s.status,'active')='active'
on conflict(organization_id,store_id) do nothing;

create table if not exists public.whatsapp_ai_employee_schedules (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  iso_weekday smallint not null check (iso_weekday between 1 and 7), -- 1=Mon ... 7=Sun
  is_working boolean not null default true,
  start_time time,
  end_time time,
  break_start time,
  break_end time,
  slot_interval_minutes integer check (slot_interval_minutes is null or slot_interval_minutes between 5 and 120),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(organization_id,store_id,employee_id,iso_weekday)
);
create index if not exists whatsapp_ai_employee_schedules_lookup_idx
  on public.whatsapp_ai_employee_schedules(organization_id,store_id,employee_id,iso_weekday);

-- Every tool execution is auditable.
create table if not exists public.whatsapp_ai_tool_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  queue_id uuid not null references public.whatsapp_ai_queue(id) on delete cascade,
  conversation_id uuid references public.whatsapp_conversations(id) on delete cascade,
  message_id uuid references public.whatsapp_messages(id) on delete cascade,
  tool_name text not null,
  status text not null default 'completed' check (status in ('completed','failed')),
  input_snapshot jsonb not null default '{}'::jsonb,
  output_snapshot jsonb not null default '{}'::jsonb,
  error text,
  duration_ms integer,
  created_at timestamptz not null default now()
);
create index if not exists whatsapp_ai_tool_runs_queue_idx on public.whatsapp_ai_tool_runs(queue_id,created_at);
create index if not exists whatsapp_ai_tool_runs_tenant_idx on public.whatsapp_ai_tool_runs(organization_id,store_id,created_at desc);

alter table public.whatsapp_ai_booking_settings enable row level security;
alter table public.whatsapp_ai_employee_schedules enable row level security;
alter table public.whatsapp_ai_tool_runs enable row level security;

-- No browser/client policy is intentionally created yet. These are server-side AI
-- tables until the owner-facing schedule UI is added. Service-role worker can access them.

-- -----------------------------------------------------------------------------
-- Shared tenant guard. Queue ID is the trust anchor; org/store are never accepted
-- from the LLM or caller as authoritative tenant IDs.
-- -----------------------------------------------------------------------------
create or replace function public.v1365_ai_queue_tenant(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_q record;
begin
  select q.organization_id,q.store_id,q.conversation_id,q.message_id
    into v_q
  from public.whatsapp_ai_queue q
  where q.id=p_queue_id;
  if v_q.organization_id is null then
    raise exception 'AI queue not found';
  end if;
  return jsonb_build_object(
    'organization_id',v_q.organization_id,
    'store_id',v_q.store_id,
    'conversation_id',v_q.conversation_id,
    'message_id',v_q.message_id
  );
end;
$$;
revoke all on function public.v1365_ai_queue_tenant(uuid) from public;
revoke all on function public.v1365_ai_queue_tenant(uuid) from anon;
revoke all on function public.v1365_ai_queue_tenant(uuid) from authenticated;
grant execute on function public.v1365_ai_queue_tenant(uuid) to service_role;

-- -----------------------------------------------------------------------------
-- resolve_service
-- Uses only active services in the queue's own tenant/store. AI may provide
-- multilingual search terms, but this function decides which DB row can match.
-- -----------------------------------------------------------------------------
create or replace function public.v1365_ai_resolve_service(
  p_queue_id uuid,
  p_query text,
  p_search_terms text[] default null
) returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_tenant jsonb;
  v_org uuid;
  v_store uuid;
  v_query text:=trim(coalesce(p_query,''));
  v_top record;
  v_second_score numeric:=0;
  v_candidates jsonb:='[]'::jsonb;
  v_status text:='not_found';
  v_service jsonb:=null;
begin
  v_tenant:=public.v1365_ai_queue_tenant(p_queue_id);
  v_org:=(v_tenant->>'organization_id')::uuid;
  v_store:=(v_tenant->>'store_id')::uuid;

  if v_query='' and coalesce(array_length(p_search_terms,1),0)=0 then
    return jsonb_build_object('ok',true,'resolution_status','missing_query','service',null,'candidates','[]'::jsonb);
  end if;

  with terms as (
    select distinct lower(trim(x)) term
    from unnest(array_append(coalesce(p_search_terms,array[]::text[]),v_query)) x
    where trim(coalesce(x,''))<>''
  ), scored as (
    select s.id,s.name,s.category,s.default_price,s.estimated_minutes,s.allows_assistant,
      greatest(
        coalesce((select max(case
          when lower(trim(s.name))=t.term then 1.0
          when lower(trim(s.name)) like '%'||t.term||'%' or t.term like '%'||lower(trim(s.name))||'%' then 0.88
          else similarity(lower(coalesce(s.name,'')),t.term)
        end) from terms t),0),
        coalesce((select max(case
          when lower(trim(coalesce(s.category,'')))=t.term then 0.72
          when lower(trim(coalesce(s.category,''))) like '%'||t.term||'%' then 0.62
          else similarity(lower(coalesce(s.category,'')),t.term)*0.65
        end) from terms t),0)
      )::numeric score
    from public.services s
    where s.organization_id=v_org and s.store_id=v_store and coalesce(s.active,true)=true
  ), ranked as (
    select * from scored where score>=0.18 order by score desc,name asc limit 5
  )
  select coalesce(jsonb_agg(jsonb_build_object(
      'id',id,'name',name,'category',category,'price',default_price,
      'estimated_minutes',estimated_minutes,'allows_assistant',allows_assistant,'score',round(score,4)
    ) order by score desc,name asc),'[]'::jsonb)
  into v_candidates from ranked;

  with terms as (
    select distinct lower(trim(x)) term
    from unnest(array_append(coalesce(p_search_terms,array[]::text[]),v_query)) x
    where trim(coalesce(x,''))<>''
  ), scored as (
    select s.id,s.name,s.category,s.default_price,s.estimated_minutes,s.allows_assistant,
      greatest(
        coalesce((select max(case
          when lower(trim(s.name))=t.term then 1.0
          when lower(trim(s.name)) like '%'||t.term||'%' or t.term like '%'||lower(trim(s.name))||'%' then 0.88
          else similarity(lower(coalesce(s.name,'')),t.term)
        end) from terms t),0),
        coalesce((select max(similarity(lower(coalesce(s.category,'')),t.term)*0.65) from terms t),0)
      )::numeric score
    from public.services s
    where s.organization_id=v_org and s.store_id=v_store and coalesce(s.active,true)=true
  ), ranked as (
    select *,row_number() over(order by score desc,name asc) rn
    from scored where score>=0.18
  )
  select r.*,(select coalesce(score,0) from ranked where rn=2) second_score
    into v_top
  from ranked r where rn=1;

  if v_top.id is null then
    v_status:='not_found';
  else
    v_second_score:=coalesce(v_top.second_score,0);
    if v_top.score>=0.97 or (v_top.score>=0.72 and (v_top.score-v_second_score)>=0.10) or (v_top.score>=0.55 and v_second_score=0) then
      v_status:='matched';
      v_service:=jsonb_build_object(
        'id',v_top.id,'name',v_top.name,'category',v_top.category,
        'price',v_top.default_price,'estimated_minutes',greatest(coalesce(v_top.estimated_minutes,60),1),
        'allows_assistant',v_top.allows_assistant,'score',round(v_top.score,4)
      );
    else
      v_status:='ambiguous';
    end if;
  end if;

  return jsonb_build_object(
    'ok',true,
    'tool','resolve_service',
    'resolution_status',v_status,
    'service',v_service,
    'candidates',v_candidates
  );
end;
$$;
revoke all on function public.v1365_ai_resolve_service(uuid,text,text[]) from public;
revoke all on function public.v1365_ai_resolve_service(uuid,text,text[]) from anon;
revoke all on function public.v1365_ai_resolve_service(uuid,text,text[]) from authenticated;
grant execute on function public.v1365_ai_resolve_service(uuid,text,text[]) to service_role;

-- -----------------------------------------------------------------------------
-- resolve_staff
-- Only active employees attached to the queue's store may match.
-- -----------------------------------------------------------------------------
create or replace function public.v1365_ai_resolve_staff(
  p_queue_id uuid,
  p_staff_name text
) returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_tenant jsonb;
  v_org uuid;
  v_store uuid;
  v_query text:=lower(trim(coalesce(p_staff_name,'')));
  v_top record;
  v_second_score numeric:=0;
  v_candidates jsonb:='[]'::jsonb;
  v_status text:='not_found';
  v_staff jsonb:=null;
begin
  v_tenant:=public.v1365_ai_queue_tenant(p_queue_id);
  v_org:=(v_tenant->>'organization_id')::uuid;
  v_store:=(v_tenant->>'store_id')::uuid;

  if v_query='' then
    return jsonb_build_object('ok',true,'resolution_status','missing_query','staff',null,'candidates','[]'::jsonb);
  end if;

  with scored as (
    select e.id,e.name,e.employee_code,e.position,e.skill_tags,e.is_on_duty,e.availability_status,
      greatest(
        case
          when lower(trim(e.name))=v_query then 1.0
          when lower(trim(e.name)) like '%'||v_query||'%' or v_query like '%'||lower(trim(e.name))||'%' then 0.90
          else similarity(lower(coalesce(e.name,'')),v_query)
        end,
        case when lower(coalesce(e.employee_code,''))=v_query then 0.98 else 0 end
      )::numeric score
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
    where e.organization_id=v_org and es.store_id=v_store and es.status='active' and e.employment_status='active'
  ), ranked as (
    select * from scored where score>=0.18 order by score desc,name asc limit 5
  )
  select coalesce(jsonb_agg(jsonb_build_object(
    'id',id,'name',name,'employee_code',employee_code,'position',position,'skill_tags',skill_tags,
    'is_on_duty',is_on_duty,'live_availability_status',availability_status,'score',round(score,4)
  ) order by score desc,name asc),'[]'::jsonb)
  into v_candidates from ranked;

  with scored as (
    select e.id,e.name,e.employee_code,e.position,e.skill_tags,e.is_on_duty,e.availability_status,
      greatest(
        case
          when lower(trim(e.name))=v_query then 1.0
          when lower(trim(e.name)) like '%'||v_query||'%' or v_query like '%'||lower(trim(e.name))||'%' then 0.90
          else similarity(lower(coalesce(e.name,'')),v_query)
        end,
        case when lower(coalesce(e.employee_code,''))=v_query then 0.98 else 0 end
      )::numeric score
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id
    where e.organization_id=v_org and es.store_id=v_store and es.status='active' and e.employment_status='active'
  ), ranked as (
    select *,row_number() over(order by score desc,name asc) rn
    from scored where score>=0.18
  )
  select r.*,(select coalesce(score,0) from ranked where rn=2) second_score
  into v_top from ranked r where rn=1;

  if v_top.id is null then
    v_status:='not_found';
  else
    v_second_score:=coalesce(v_top.second_score,0);
    if v_top.score>=0.97 or (v_top.score>=0.72 and (v_top.score-v_second_score)>=0.10) or (v_top.score>=0.55 and v_second_score=0) then
      v_status:='matched';
      v_staff:=jsonb_build_object(
        'id',v_top.id,'name',v_top.name,'employee_code',v_top.employee_code,'position',v_top.position,
        'skill_tags',v_top.skill_tags,'is_on_duty',v_top.is_on_duty,
        'live_availability_status',v_top.availability_status,'score',round(v_top.score,4)
      );
    else
      v_status:='ambiguous';
    end if;
  end if;

  return jsonb_build_object('ok',true,'tool','resolve_staff','resolution_status',v_status,'staff',v_staff,'candidates',v_candidates);
end;
$$;
revoke all on function public.v1365_ai_resolve_staff(uuid,text) from public;
revoke all on function public.v1365_ai_resolve_staff(uuid,text) from anon;
revoke all on function public.v1365_ai_resolve_staff(uuid,text) from authenticated;
grant execute on function public.v1365_ai_resolve_staff(uuid,text) to service_role;

-- -----------------------------------------------------------------------------
-- check_availability
-- Truth source = future staff schedule + existing SalonOS visits assigned to staff.
-- It never trusts an organization/store ID from AI. It does NOT create bookings.
-- -----------------------------------------------------------------------------
create or replace function public.v1365_ai_check_availability(
  p_queue_id uuid,
  p_service_id uuid,
  p_employee_id uuid,
  p_date date,
  p_time_iso text default null,
  p_time_period text default 'unspecified'
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_tenant jsonb;
  v_org uuid;
  v_store uuid;
  v_service record;
  v_employee record;
  v_settings record;
  v_shift record;
  v_timezone text:='Asia/Kuala_Lumpur';
  v_interval integer:=30;
  v_notice integer:=30;
  v_max_days integer:=90;
  v_duration integer:=60;
  v_shift_start timestamp;
  v_shift_end timestamp;
  v_break_start timestamp;
  v_break_end timestamp;
  v_window_start timestamp;
  v_window_end timestamp;
  v_exact timestamp;
  v_slot timestamp;
  v_slot_end timestamp;
  v_slots jsonb:='[]'::jsonb;
  v_busy boolean;
  v_now_local timestamp;
  v_count integer:=0;
  v_period text:=lower(coalesce(p_time_period,'unspecified'));
begin
  v_tenant:=public.v1365_ai_queue_tenant(p_queue_id);
  v_org:=(v_tenant->>'organization_id')::uuid;
  v_store:=(v_tenant->>'store_id')::uuid;

  select s.id,s.name,s.default_price,s.estimated_minutes,s.active
    into v_service
  from public.services s
  where s.id=p_service_id and s.organization_id=v_org and s.store_id=v_store and coalesce(s.active,true)=true;
  if v_service.id is null then
    return jsonb_build_object('ok',false,'availability_status','invalid_service','slots','[]'::jsonb);
  end if;
  v_duration:=greatest(coalesce(v_service.estimated_minutes,60),1);

  select e.id,e.name,e.is_on_duty,e.availability_status,e.employment_status
    into v_employee
  from public.employees e
  where e.id=p_employee_id and e.organization_id=v_org and e.employment_status='active'
    and exists(select 1 from public.employee_stores es where es.organization_id=v_org and es.store_id=v_store and es.employee_id=e.id and es.status='active');
  if v_employee.id is null then
    return jsonb_build_object('ok',false,'availability_status','invalid_staff','slots','[]'::jsonb);
  end if;

  select * into v_settings
  from public.whatsapp_ai_booking_settings b
  where b.organization_id=v_org and b.store_id=v_store and b.active=true;
  if v_settings.id is not null then
    v_timezone:=coalesce(nullif(v_settings.timezone,''),'Asia/Kuala_Lumpur');
    v_interval:=greatest(coalesce(v_settings.slot_interval_minutes,30),5);
    v_notice:=greatest(coalesce(v_settings.minimum_notice_minutes,30),0);
    v_max_days:=greatest(coalesce(v_settings.max_booking_days_ahead,90),1);
  end if;

  v_now_local:=now() at time zone v_timezone;
  if p_date is null then
    return jsonb_build_object('ok',true,'availability_status','missing_date','slots','[]'::jsonb);
  end if;
  if p_date < v_now_local::date then
    return jsonb_build_object('ok',true,'availability_status','date_in_past','slots','[]'::jsonb);
  end if;
  if p_date > (v_now_local::date + v_max_days) then
    return jsonb_build_object('ok',true,'availability_status','date_too_far','max_booking_days_ahead',v_max_days,'slots','[]'::jsonb);
  end if;

  select * into v_shift
  from public.whatsapp_ai_employee_schedules x
  where x.organization_id=v_org and x.store_id=v_store and x.employee_id=p_employee_id
    and x.iso_weekday=extract(isodow from p_date)::int;

  if v_shift.id is null then
    return jsonb_build_object(
      'ok',true,'availability_status','schedule_unconfigured','schedule_required',true,
      'employee',jsonb_build_object('id',v_employee.id,'name',v_employee.name),
      'date',p_date,'slots','[]'::jsonb
    );
  end if;
  if not coalesce(v_shift.is_working,false) then
    return jsonb_build_object('ok',true,'availability_status','employee_off','date',p_date,'slots','[]'::jsonb);
  end if;
  if v_shift.start_time is null or v_shift.end_time is null then
    return jsonb_build_object('ok',true,'availability_status','schedule_invalid','slots','[]'::jsonb);
  end if;

  v_interval:=greatest(coalesce(v_shift.slot_interval_minutes,v_interval),5);
  v_shift_start:=p_date::timestamp + v_shift.start_time;
  v_shift_end:=p_date::timestamp + v_shift.end_time;
  if v_shift_end<=v_shift_start then v_shift_end:=v_shift_end+interval '1 day'; end if;

  if v_shift.break_start is not null and v_shift.break_end is not null then
    v_break_start:=p_date::timestamp + v_shift.break_start;
    v_break_end:=p_date::timestamp + v_shift.break_end;
    if v_break_end<=v_break_start then v_break_end:=v_break_end+interval '1 day'; end if;
  end if;

  v_window_start:=v_shift_start;
  v_window_end:=v_shift_end;
  if v_period='morning' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '06:00');
    v_window_end:=least(v_window_end,p_date::timestamp+time '12:00');
  elsif v_period='afternoon' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '12:00');
    v_window_end:=least(v_window_end,p_date::timestamp+time '18:00');
  elsif v_period='evening' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '18:00');
    v_window_end:=least(v_window_end,p_date::timestamp+time '22:00');
  elsif v_period='night' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '22:00');
  end if;

  if nullif(trim(coalesce(p_time_iso,'')),'') is not null then
    if trim(p_time_iso) !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' then
      return jsonb_build_object('ok',true,'availability_status','invalid_time','slots','[]'::jsonb);
    end if;
    v_exact:=p_date::timestamp + trim(p_time_iso)::time;
    v_window_start:=v_exact;
    v_window_end:=v_exact + make_interval(mins=>v_duration);
  end if;

  if v_window_end<=v_window_start or v_window_start+make_interval(mins=>v_duration)>v_shift_end then
    return jsonb_build_object('ok',true,'availability_status','outside_shift','date',p_date,'slots','[]'::jsonb);
  end if;

  v_slot:=v_window_start;
  while v_slot + make_interval(mins=>v_duration) <= v_window_end loop
    v_slot_end:=v_slot+make_interval(mins=>v_duration);

    -- Minimum booking notice.
    if v_slot < v_now_local + make_interval(mins=>v_notice) then
      v_slot:=v_slot+make_interval(mins=>v_interval);
      continue;
    end if;

    -- Employee break.
    if v_break_start is not null and v_break_end is not null and v_slot < v_break_end and v_slot_end > v_break_start then
      v_slot:=v_slot+make_interval(mins=>v_interval);
      continue;
    end if;

    select exists(
      select 1
      from public.visits v
      where v.organization_id=v_org and v.store_id=v_store
        and v.status in ('booked','arrived','waiting','in_service','paused','ready_for_checkout')
        and exists(
          select 1
          from public.visit_service_items si
          join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
          where si.visit_id=v.id and si.organization_id=v_org and si.status<>'cancelled' and w.employee_id=p_employee_id
        )
        and (coalesce(v.scheduled_at,v.started_at,v.created_at) at time zone v_timezone) < v_slot_end
        and (
          (coalesce(v.scheduled_at,v.started_at,v.created_at) at time zone v_timezone)
          + make_interval(mins=>greatest(30,coalesce((
              select sum(greatest(coalesce(si2.estimated_minutes_snapshot,30),1))::int
              from public.visit_service_items si2
              where si2.visit_id=v.id and si2.organization_id=v_org and si2.status<>'cancelled'
            ),30)))
        ) > v_slot
    ) into v_busy;

    if not v_busy then
      v_slots:=v_slots || jsonb_build_array(jsonb_build_object(
        'time',to_char(v_slot,'HH24:MI'),
        'start_local',to_char(v_slot,'YYYY-MM-DD"T"HH24:MI:SS'),
        'end_local',to_char(v_slot_end,'YYYY-MM-DD"T"HH24:MI:SS'),
        'duration_minutes',v_duration
      ));
      v_count:=v_count+1;
      if v_count>=12 then exit; end if;
    end if;

    if v_exact is not null then exit; end if;
    v_slot:=v_slot+make_interval(mins=>v_interval);
  end loop;

  return jsonb_build_object(
    'ok',true,
    'tool','check_availability',
    'availability_status',case when jsonb_array_length(v_slots)>0 then 'available' else 'no_slots' end,
    'date',p_date,
    'timezone',v_timezone,
    'service',jsonb_build_object('id',v_service.id,'name',v_service.name,'duration_minutes',v_duration,'price',v_service.default_price),
    'employee',jsonb_build_object('id',v_employee.id,'name',v_employee.name,'live_availability_status',v_employee.availability_status),
    'shift',jsonb_build_object(
      'start',to_char(v_shift.start_time,'HH24:MI'),'end',to_char(v_shift.end_time,'HH24:MI'),
      'break_start',case when v_shift.break_start is null then null else to_char(v_shift.break_start,'HH24:MI') end,
      'break_end',case when v_shift.break_end is null then null else to_char(v_shift.break_end,'HH24:MI') end
    ),
    'slot_interval_minutes',v_interval,
    'slots',v_slots
  );
end;
$$;
revoke all on function public.v1365_ai_check_availability(uuid,uuid,uuid,date,text,text) from public;
revoke all on function public.v1365_ai_check_availability(uuid,uuid,uuid,date,text,text) from anon;
revoke all on function public.v1365_ai_check_availability(uuid,uuid,uuid,date,text,text) from authenticated;
grant execute on function public.v1365_ai_check_availability(uuid,uuid,uuid,date,text,text) to service_role;

insert into public.salonos_system_meta(meta_key,meta_value)
values
 ('whatsapp_ai_appointment_tools_version','13.6.5'),
 ('whatsapp_ai_schedule_truth_source','whatsapp_ai_employee_schedules'),
 ('whatsapp_ai_tool_audit_version','13.6.5')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst, 'reload schema';

select
  'SalonOS v13.6.5 APPOINTMENT TOOL LAYER READY' as result,
  to_regprocedure('public.v1365_ai_resolve_service(uuid,text,text[])') is not null as resolve_service_ok,
  to_regprocedure('public.v1365_ai_resolve_staff(uuid,text)') is not null as resolve_staff_ok,
  to_regprocedure('public.v1365_ai_check_availability(uuid,uuid,uuid,date,text,text)') is not null as check_availability_ok,
  to_regclass('public.whatsapp_ai_employee_schedules') is not null as employee_schedule_ok,
  to_regclass('public.whatsapp_ai_tool_runs') is not null as tool_audit_ok;
