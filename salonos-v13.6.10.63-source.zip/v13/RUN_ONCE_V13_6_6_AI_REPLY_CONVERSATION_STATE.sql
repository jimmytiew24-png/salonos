-- SalonOS v13.6.6 · AI Reply + Meta Cloud API + Multi-turn Conversation State
-- Run AFTER v13.6.5. Additive / idempotent.
-- Purpose:
--   1) store WhatsApp send credentials per branch (not organization-wide),
--   2) audit outbound AI replies,
--   3) make outbound replies idempotent per inbound message,
--   4) provide a v13.6.6 availability wrapper with a natural afternoon window.

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- Outbound message linkage. One automatic reply per inbound message prevents
-- duplicate customer messages if a worker is retried.
-- -----------------------------------------------------------------------------
alter table public.whatsapp_messages
  add column if not exists reply_to_message_id uuid references public.whatsapp_messages(id) on delete set null,
  add column if not exists reply_kind text,
  add column if not exists reply_context jsonb not null default '{}'::jsonb;

create unique index if not exists whatsapp_messages_auto_reply_once_uidx
  on public.whatsapp_messages(reply_to_message_id)
  where direction='outbound' and reply_to_message_id is not null;

-- -----------------------------------------------------------------------------
-- Branch-scoped WhatsApp send configuration.
-- Access tokens are server-side only: no authenticated SELECT policy is created.
-- Owners/managers save through a SECURITY DEFINER RPC which never returns token text.
-- -----------------------------------------------------------------------------
create table if not exists public.whatsapp_store_configs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  connection_id uuid not null references public.whatsapp_business_connections(id) on delete cascade,
  access_token text,
  graph_api_version text not null default 'v26.0',
  auto_reply_enabled boolean not null default true,
  max_slots_in_reply integer not null default 5 check(max_slots_in_reply between 1 and 10),
  token_configured_at timestamptz,
  last_send_at timestamptz,
  last_send_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);

alter table public.whatsapp_store_configs
  add column if not exists organization_id uuid,
  add column if not exists store_id uuid,
  add column if not exists connection_id uuid,
  add column if not exists access_token text,
  add column if not exists graph_api_version text not null default 'v26.0',
  add column if not exists auto_reply_enabled boolean not null default true,
  add column if not exists max_slots_in_reply integer not null default 5,
  add column if not exists token_configured_at timestamptz,
  add column if not exists last_send_at timestamptz,
  add column if not exists last_send_error text,
  add column if not exists created_at timestamptz not null default now(),
  add column if not exists updated_at timestamptz not null default now();

create unique index if not exists whatsapp_store_configs_connection_uidx
  on public.whatsapp_store_configs(connection_id);
create unique index if not exists whatsapp_store_configs_store_uidx
  on public.whatsapp_store_configs(organization_id,store_id);

-- Migrate the existing v13 organization-level token into the current branch config.
-- This is only a one-time compatibility bridge; all new saves are branch-scoped.
insert into public.whatsapp_store_configs(
  organization_id,store_id,connection_id,access_token,graph_api_version,auto_reply_enabled,
  token_configured_at,updated_at
)
select
  c.organization_id,c.store_id,c.id,
  nullif(trim(coalesce(s.whatsapp->>'access_token','')),''),
  'v26.0',true,
  case when nullif(trim(coalesce(s.whatsapp->>'access_token','')),'') is null then null else now() end,
  now()
from public.whatsapp_business_connections c
left join public.v13_organization_settings s on s.organization_id=c.organization_id
where c.enabled=true
  and (select count(*) from public.whatsapp_business_connections c2 where c2.organization_id=c.organization_id and c2.enabled=true)=1
on conflict(connection_id) do update set
  organization_id=excluded.organization_id,
  store_id=excluded.store_id,
  access_token=coalesce(nullif(public.whatsapp_store_configs.access_token,''),excluded.access_token),
  updated_at=now();

-- Remove the legacy organization-wide secret only when a branch-scoped copy now exists.
update public.v13_organization_settings s
set whatsapp=coalesce(s.whatsapp,'{}'::jsonb)-'access_token', updated_at=now()
where nullif(trim(coalesce(s.whatsapp->>'access_token','')),'') is not null
  and exists(
    select 1 from public.whatsapp_store_configs x
    where x.organization_id=s.organization_id
      and nullif(trim(coalesce(x.access_token,'')),'') is not null
  )
  and (select count(*) from public.whatsapp_business_connections c2 where c2.organization_id=s.organization_id and c2.enabled=true)=1;

alter table public.whatsapp_store_configs enable row level security;
revoke all on public.whatsapp_store_configs from anon;
revoke all on public.whatsapp_store_configs from authenticated;
grant all on public.whatsapp_store_configs to service_role;

-- -----------------------------------------------------------------------------
-- Reply audit. This holds no secret credentials.
-- -----------------------------------------------------------------------------
create table if not exists public.whatsapp_ai_reply_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  queue_id uuid not null references public.whatsapp_ai_queue(id) on delete cascade,
  conversation_id uuid not null references public.whatsapp_conversations(id) on delete cascade,
  inbound_message_id uuid not null references public.whatsapp_messages(id) on delete cascade,
  outbound_message_id uuid references public.whatsapp_messages(id) on delete set null,
  reply_type text not null default 'text',
  state_before text,
  state_after text,
  reply_text text,
  status text not null default 'planned' check(status in ('planned','sending','sent','failed','suppressed')),
  meta_response jsonb not null default '{}'::jsonb,
  error text,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(inbound_message_id)
);
create index if not exists whatsapp_ai_reply_runs_store_idx
  on public.whatsapp_ai_reply_runs(organization_id,store_id,created_at desc);
create index if not exists whatsapp_ai_reply_runs_queue_idx
  on public.whatsapp_ai_reply_runs(queue_id,created_at desc);

alter table public.whatsapp_ai_reply_runs enable row level security;
drop policy if exists v1366_reply_runs_read on public.whatsapp_ai_reply_runs;
create policy v1366_reply_runs_read on public.whatsapp_ai_reply_runs
for select to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));
grant select on public.whatsapp_ai_reply_runs to authenticated;
grant all on public.whatsapp_ai_reply_runs to service_role;
grant insert,update on public.whatsapp_messages to service_role;

-- -----------------------------------------------------------------------------
-- Secure owner/manager save RPC. The access token is never returned.
-- -----------------------------------------------------------------------------
create or replace function public.v1366_owner_save_whatsapp_store_config(
  p_store_id uuid,
  p_phone_number_id text,
  p_business_account_id text default null,
  p_display_phone_number text default null,
  p_access_token text default null,
  p_enabled boolean default true,
  p_auto_reply_enabled boolean default true,
  p_graph_api_version text default 'v26.0'
) returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare
  v_org uuid;
  v_conn uuid;
  v_existing record;
  v_version text:=trim(coalesce(p_graph_api_version,'v26.0'));
  v_token text:=nullif(trim(coalesce(p_access_token,'')),'');
  v_has_token boolean:=false;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id;
  if v_org is null then raise exception 'Store not found'; end if;
  if not public.has_organization_role(v_org,array['owner','manager']) or not public.can_access_store(p_store_id) then
    raise exception 'Not allowed';
  end if;
  if nullif(trim(coalesce(p_phone_number_id,'')),'') is null then raise exception 'Phone Number ID is required'; end if;
  if v_version !~ '^v[0-9]+\.[0-9]+$' then v_version:='v26.0'; end if;

  select c.organization_id,c.store_id into v_existing
  from public.whatsapp_business_connections c
  where c.phone_number_id=trim(p_phone_number_id)
  limit 1;
  if v_existing.organization_id is not null and (v_existing.organization_id<>v_org or v_existing.store_id<>p_store_id) then
    raise exception 'This WhatsApp Phone Number ID is already bound to another branch';
  end if;

  insert into public.whatsapp_business_connections(
    organization_id,store_id,phone_number_id,business_account_id,display_phone_number,
    enabled,connection_status,updated_at
  ) values(
    v_org,p_store_id,trim(p_phone_number_id),nullif(trim(coalesce(p_business_account_id,'')),''),
    nullif(regexp_replace(coalesce(p_display_phone_number,''),'[^0-9]','','g'),''),
    coalesce(p_enabled,true),'configured',now()
  )
  on conflict(phone_number_id) do update set
    business_account_id=excluded.business_account_id,
    display_phone_number=excluded.display_phone_number,
    enabled=excluded.enabled,
    updated_at=now()
  returning id into v_conn;

  insert into public.whatsapp_store_configs(
    organization_id,store_id,connection_id,access_token,graph_api_version,auto_reply_enabled,
    token_configured_at,updated_at
  ) values(
    v_org,p_store_id,v_conn,v_token,v_version,coalesce(p_auto_reply_enabled,true),
    case when v_token is null then null else now() end,now()
  )
  on conflict(connection_id) do update set
    organization_id=excluded.organization_id,
    store_id=excluded.store_id,
    access_token=coalesce(excluded.access_token,public.whatsapp_store_configs.access_token),
    graph_api_version=excluded.graph_api_version,
    auto_reply_enabled=excluded.auto_reply_enabled,
    token_configured_at=case when excluded.access_token is null then public.whatsapp_store_configs.token_configured_at else now() end,
    updated_at=now();

  select nullif(trim(coalesce(c.access_token,'')),'') is not null into v_has_token
  from public.whatsapp_store_configs c where c.connection_id=v_conn;

  -- Keep non-secret settings for existing UI compatibility, but remove the old secret copy.
  insert into public.v13_organization_settings(organization_id,whatsapp,updated_at)
  values(v_org,jsonb_build_object(
    'enabled',coalesce(p_enabled,true),
    'phone_number_id',trim(p_phone_number_id),
    'business_account_id',nullif(trim(coalesce(p_business_account_id,'')),''),
    'public_phone',nullif(regexp_replace(coalesce(p_display_phone_number,''),'[^0-9]','','g'),''),
    'access_token_configured',v_has_token
  ),now())
  on conflict(organization_id) do update set
    whatsapp=(coalesce(public.v13_organization_settings.whatsapp,'{}'::jsonb)-'access_token') || excluded.whatsapp,
    updated_at=now();

  return jsonb_build_object(
    'ok',true,'connection_id',v_conn,'organization_id',v_org,'store_id',p_store_id,
    'phone_number_id',trim(p_phone_number_id),'token_configured',v_has_token,
    'auto_reply_enabled',coalesce(p_auto_reply_enabled,true),'graph_api_version',v_version
  );
end;
$$;
revoke all on function public.v1366_owner_save_whatsapp_store_config(uuid,text,text,text,text,boolean,boolean,text) from public;
revoke all on function public.v1366_owner_save_whatsapp_store_config(uuid,text,text,text,text,boolean,boolean,text) from anon;
grant execute on function public.v1366_owner_save_whatsapp_store_config(uuid,text,text,text,text,boolean,boolean,text) to authenticated;

create or replace function public.v1366_owner_whatsapp_store_config_status(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare v_org uuid; v_row record;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id;
  if v_org is null then raise exception 'Store not found'; end if;
  if not public.has_organization_role(v_org,array['owner','manager']) or not public.can_access_store(p_store_id) then raise exception 'Not allowed'; end if;
  select c.id connection_id,c.phone_number_id,c.business_account_id,c.display_phone_number,c.enabled,c.connection_status,
         x.graph_api_version,x.auto_reply_enabled,x.max_slots_in_reply,
         nullif(trim(coalesce(x.access_token,'')),'') is not null token_configured,
         x.last_send_at,x.last_send_error
    into v_row
  from public.whatsapp_business_connections c
  left join public.whatsapp_store_configs x on x.connection_id=c.id
  where c.organization_id=v_org and c.store_id=p_store_id
  order by c.updated_at desc limit 1;
  if v_row.connection_id is null then return jsonb_build_object('configured',false); end if;
  return to_jsonb(v_row) || jsonb_build_object('configured',true);
end;
$$;
revoke all on function public.v1366_owner_whatsapp_store_config_status(uuid) from public;
revoke all on function public.v1366_owner_whatsapp_store_config_status(uuid) from anon;
grant execute on function public.v1366_owner_whatsapp_store_config_status(uuid) to authenticated;

-- -----------------------------------------------------------------------------
-- v13.6.6 wrapper: Chinese/Malay/English "afternoon" means 13:00-18:00 for
-- broad requests. Exact stated times are never rewritten.
-- -----------------------------------------------------------------------------
create or replace function public.v1366_ai_check_availability(
  p_queue_id uuid,
  p_service_id uuid,
  p_employee_id uuid,
  p_date date,
  p_time_iso text default null,
  p_time_period text default 'unspecified'
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result jsonb;
  v_filtered jsonb:='[]'::jsonb;
  v_status text;
begin
  v_result:=public.v1365_ai_check_availability(
    p_queue_id,p_service_id,p_employee_id,p_date,p_time_iso,p_time_period
  );
  if nullif(trim(coalesce(p_time_iso,'')),'') is null
     and lower(coalesce(p_time_period,'unspecified'))='afternoon'
     and jsonb_typeof(coalesce(v_result->'slots','[]'::jsonb))='array' then
    select coalesce(jsonb_agg(x order by x->>'time'),'[]'::jsonb)
      into v_filtered
    from jsonb_array_elements(coalesce(v_result->'slots','[]'::jsonb)) x
    where coalesce(x->>'time','') >= '13:00' and coalesce(x->>'time','') < '18:00';
    v_result:=jsonb_set(v_result,'{slots}',v_filtered,true);
    if (v_result->>'availability_status') in ('available','no_slots') then
      v_status:=case when jsonb_array_length(v_filtered)>0 then 'available' else 'no_slots' end;
      v_result:=jsonb_set(v_result,'{availability_status}',to_jsonb(v_status),true);
    end if;
  end if;
  return v_result || jsonb_build_object('tool','check_availability','tool_version','13.6.6');
end;
$$;
revoke all on function public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text) from public;
revoke all on function public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text) from anon;
revoke all on function public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text) from authenticated;
grant execute on function public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text) to service_role;

insert into public.salonos_system_meta(meta_key,meta_value)
values
 ('whatsapp_ai_reply_version','13.6.6'),
 ('whatsapp_ai_multiturn_state_version','13.6.6'),
 ('whatsapp_branch_send_config_version','13.6.6'),
 ('whatsapp_graph_api_default_version','v26.0')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst, 'reload schema';

select
  'SalonOS v13.6.6 AI REPLY + CONVERSATION STATE READY' as result,
  to_regclass('public.whatsapp_store_configs') is not null as branch_whatsapp_config_ok,
  to_regclass('public.whatsapp_ai_reply_runs') is not null as reply_audit_ok,
  to_regprocedure('public.v1366_owner_save_whatsapp_store_config(uuid,text,text,text,text,boolean,boolean,text)') is not null as secure_save_rpc_ok,
  to_regprocedure('public.v1366_ai_check_availability(uuid,uuid,uuid,date,text,text)') is not null as availability_v1366_ok,
  exists(select 1 from public.whatsapp_store_configs where nullif(trim(coalesce(access_token,'')),'') is not null) as existing_token_migrated;
