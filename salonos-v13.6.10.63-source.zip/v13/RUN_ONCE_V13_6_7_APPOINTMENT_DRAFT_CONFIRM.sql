-- SalonOS v13.6.7 · Customer Profile Collection + Appointment Draft + Confirm
-- Run AFTER v13.6.6. Additive / idempotent.
-- Core rule: the LLM never writes arbitrary SQL and never creates an appointment directly.
-- Only the backend confirm RPC may create a booked visit, after a final availability recheck.

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- Customer-provided age metadata. Exact birth date remains the preferred truth
-- when available; reported age/range is only used when the customer explicitly
-- supplies it. Never AI-predicted.
-- -----------------------------------------------------------------------------
alter table public.customers
  add column if not exists reported_age integer,
  add column if not exists age_range text,
  add column if not exists age_source text not null default 'unknown',
  add column if not exists age_reported_at timestamptz;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid='public.customers'::regclass
      and conname='customers_reported_age_check'
  ) then
    alter table public.customers
      add constraint customers_reported_age_check
      check (reported_age is null or reported_age between 1 and 120);
  end if;
  if not exists (
    select 1 from pg_constraint
    where conrelid='public.customers'::regclass
      and conname='customers_age_source_check'
  ) then
    alter table public.customers
      add constraint customers_age_source_check
      check (age_source in ('unknown','customer_provided','staff_entered','imported'));
  end if;
end $$;

-- -----------------------------------------------------------------------------
-- Durable appointment draft. A draft never reserves the time. The selected time
-- is rechecked atomically immediately before the real SalonOS visit is created.
-- -----------------------------------------------------------------------------
create table if not exists public.whatsapp_ai_appointment_drafts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  connection_id uuid not null references public.whatsapp_business_connections(id) on delete cascade,
  conversation_id uuid not null references public.whatsapp_conversations(id) on delete cascade,
  lead_id uuid,
  customer_id uuid references public.customers(id) on delete set null,
  customer_phone text not null,
  customer_name text,
  reported_age integer,
  age_range text,
  age_collection_status text not null default 'pending'
    check(age_collection_status in ('pending','provided','skipped','not_required')),
  ethnicity text,
  ethnicity_source text not null default 'unknown'
    check(ethnicity_source in ('unknown','customer_provided','staff_entered','imported')),
  ethnicity_collection_status text not null default 'pending'
    check(ethnicity_collection_status in ('pending','provided','skipped','not_required')),
  service_id uuid not null references public.services(id) on delete restrict,
  service_name_snapshot text not null,
  service_price_snapshot numeric(12,2) not null default 0,
  service_duration_minutes integer not null default 60,
  employee_id uuid not null references public.employees(id) on delete restrict,
  employee_name_snapshot text not null,
  appointment_date date not null,
  appointment_time time not null,
  scheduled_at timestamptz not null,
  timezone text not null default 'Asia/Kuala_Lumpur',
  source_snapshot jsonb not null default '{}'::jsonb,
  status text not null default 'collecting_profile'
    check(status in ('collecting_profile','pending_confirmation','needs_reschedule','confirmed','cancelled','expired','failed')),
  expires_at timestamptz not null default (now() + interval '20 minutes'),
  confirmed_visit_id uuid references public.visits(id) on delete set null,
  confirmed_at timestamptz,
  last_queue_id uuid references public.whatsapp_ai_queue(id) on delete set null,
  last_message_id uuid references public.whatsapp_messages(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);

create unique index if not exists whatsapp_ai_active_draft_conversation_uidx
  on public.whatsapp_ai_appointment_drafts(conversation_id)
  where status in ('collecting_profile','pending_confirmation','needs_reschedule');
create index if not exists whatsapp_ai_drafts_store_idx
  on public.whatsapp_ai_appointment_drafts(organization_id,store_id,updated_at desc);
create index if not exists whatsapp_ai_drafts_status_idx
  on public.whatsapp_ai_appointment_drafts(organization_id,store_id,status,expires_at);

create table if not exists public.whatsapp_ai_booking_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  draft_id uuid not null references public.whatsapp_ai_appointment_drafts(id) on delete cascade,
  queue_id uuid references public.whatsapp_ai_queue(id) on delete set null,
  message_id uuid references public.whatsapp_messages(id) on delete set null,
  event_type text not null,
  event_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists whatsapp_ai_booking_events_draft_idx
  on public.whatsapp_ai_booking_events(draft_id,created_at desc);

alter table public.whatsapp_ai_appointment_drafts enable row level security;
alter table public.whatsapp_ai_booking_events enable row level security;

drop policy if exists v1367_drafts_read on public.whatsapp_ai_appointment_drafts;
create policy v1367_drafts_read on public.whatsapp_ai_appointment_drafts
for select to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

drop policy if exists v1367_booking_events_read on public.whatsapp_ai_booking_events;
create policy v1367_booking_events_read on public.whatsapp_ai_booking_events
for select to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

grant select on public.whatsapp_ai_appointment_drafts, public.whatsapp_ai_booking_events to authenticated;
grant all on public.whatsapp_ai_appointment_drafts, public.whatsapp_ai_booking_events to service_role;
grant insert,update on public.customers, public.marketing_leads to service_role;
grant insert on public.visits,public.visit_recipients,public.visit_service_items,public.visit_service_workers to service_role;

-- -----------------------------------------------------------------------------
-- Helper: determine the next missing profile field. Name is required. Age and
-- ethnicity are optional, but the customer must either provide or explicitly skip.
-- -----------------------------------------------------------------------------
create or replace function public.v1367_ai_draft_next_field(p_draft_id uuid)
returns text
language sql
stable
security definer
set search_path=public
as $$
  select case
    when nullif(trim(coalesce(d.customer_name,'')),'') is null then 'name'
    when d.age_collection_status='pending' then 'age'
    when d.ethnicity_collection_status='pending' then 'ethnicity'
    else null
  end
  from public.whatsapp_ai_appointment_drafts d
  where d.id=p_draft_id;
$$;
revoke all on function public.v1367_ai_draft_next_field(uuid) from public,anon,authenticated;
grant execute on function public.v1367_ai_draft_next_field(uuid) to service_role;

-- -----------------------------------------------------------------------------
-- Create/reuse a draft from the VERIFIED conversation state after a time was
-- selected. Tenant/service/staff/date/time are derived from state/backend results;
-- the model is not trusted to supply organization/store IDs.
-- -----------------------------------------------------------------------------
create or replace function public.v1367_ai_ensure_draft(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_q public.whatsapp_ai_queue%rowtype;
  v_conv public.whatsapp_conversations%rowtype;
  v_state public.whatsapp_ai_conversation_state%rowtype;
  v_draft public.whatsapp_ai_appointment_drafts%rowtype;
  v_customer public.customers%rowtype;
  v_service public.services%rowtype;
  v_employee public.employees%rowtype;
  v_service_id uuid;
  v_employee_id uuid;
  v_date date;
  v_time time;
  v_time_text text;
  v_availability jsonb;
  v_phone text;
  v_source jsonb:='{}'::jsonb;
  v_next text;
  v_status text;
  v_age_status text:='pending';
  v_eth_status text:='pending';
  v_sched timestamptz;
begin
  select * into v_q from public.whatsapp_ai_queue where id=p_queue_id limit 1;
  if v_q.id is null then return jsonb_build_object('ok',false,'error','queue_not_found'); end if;

  select * into v_conv from public.whatsapp_conversations c
   where c.id=v_q.conversation_id and c.organization_id=v_q.organization_id and c.store_id=v_q.store_id
     and c.connection_id=v_q.connection_id limit 1;
  if v_conv.id is null then return jsonb_build_object('ok',false,'error','conversation_scope_mismatch'); end if;

  select * into v_state from public.whatsapp_ai_conversation_state s
   where s.conversation_id=v_q.conversation_id and s.organization_id=v_q.organization_id and s.store_id=v_q.store_id limit 1;
  if v_state.id is null then return jsonb_build_object('ok',false,'error','conversation_state_missing'); end if;

  begin v_service_id:=nullif(v_state.slots#>>'{appointment_tools,resolve_service,service,id}','')::uuid; exception when others then v_service_id:=null; end;
  begin v_employee_id:=nullif(v_state.slots#>>'{appointment_tools,resolve_staff,staff,id}','')::uuid; exception when others then v_employee_id:=null; end;
  begin v_date:=nullif(v_state.slots->>'date_iso','')::date; exception when others then v_date:=null; end;
  v_time_text:=coalesce(nullif(v_state.slots->>'selected_time',''),nullif(v_state.slots->>'time_iso',''));
  begin v_time:=nullif(v_time_text,'')::time; exception when others then v_time:=null; end;

  if v_service_id is null or v_employee_id is null or v_date is null or v_time is null then
    return jsonb_build_object('ok',false,'error','selected_appointment_context_incomplete');
  end if;

  select * into v_service from public.services s
   where s.id=v_service_id and s.organization_id=v_q.organization_id and s.store_id=v_q.store_id and coalesce(s.active,true)=true;
  if v_service.id is null then return jsonb_build_object('ok',false,'error','service_not_valid_for_branch'); end if;

  select e.* into v_employee from public.employees e
   where e.id=v_employee_id and e.organization_id=v_q.organization_id and e.employment_status='active'
     and exists(select 1 from public.employee_stores es where es.organization_id=v_q.organization_id and es.store_id=v_q.store_id and es.employee_id=e.id and es.status='active');
  if v_employee.id is null then return jsonb_build_object('ok',false,'error','staff_not_valid_for_branch'); end if;

  v_availability:=public.v1366_ai_check_availability(
    p_queue_id,v_service.id,v_employee.id,v_date,to_char(v_time,'HH24:MI'),'unspecified'
  );
  if coalesce(v_availability->>'availability_status','')<>'available'
     or not exists(select 1 from jsonb_array_elements(coalesce(v_availability->'slots','[]'::jsonb)) x where x->>'time'=to_char(v_time,'HH24:MI')) then
    return jsonb_build_object(
      'ok',false,'error','selected_slot_no_longer_available','availability',v_availability
    );
  end if;

  v_phone:=regexp_replace(coalesce(v_conv.customer_phone,''),'[^0-9]','','g');
  if v_phone='' then return jsonb_build_object('ok',false,'error','customer_phone_missing'); end if;

  select c.* into v_customer from public.customers c
   where c.organization_id=v_q.organization_id and c.store_id=v_q.store_id
     and regexp_replace(coalesce(c.phone,''),'[^0-9]','','g')=v_phone
   order by c.updated_at desc nulls last,c.created_at desc limit 1;

  if v_customer.id is not null then
    if v_customer.birth_date is not null or v_customer.reported_age is not null or nullif(trim(coalesce(v_customer.age_range,'')),'') is not null then
      v_age_status:='not_required';
    end if;
    if nullif(trim(coalesce(v_customer.ethnicity,'')),'') is not null then v_eth_status:='not_required'; end if;
  end if;

  if v_state.customer_context is not null then
    v_source:=coalesce(v_state.customer_context->'attribution','{}'::jsonb);
  end if;
  v_sched:=(v_date + v_time) at time zone 'Asia/Kuala_Lumpur';

  select * into v_draft from public.whatsapp_ai_appointment_drafts d
   where d.conversation_id=v_q.conversation_id and d.organization_id=v_q.organization_id and d.store_id=v_q.store_id
     and d.status in ('collecting_profile','pending_confirmation','needs_reschedule')
   order by d.updated_at desc limit 1;

  if v_draft.id is null then
    insert into public.whatsapp_ai_appointment_drafts(
      organization_id,store_id,connection_id,conversation_id,lead_id,customer_id,customer_phone,customer_name,
      reported_age,age_range,age_collection_status,ethnicity,ethnicity_source,ethnicity_collection_status,
      service_id,service_name_snapshot,service_price_snapshot,service_duration_minutes,
      employee_id,employee_name_snapshot,appointment_date,appointment_time,scheduled_at,timezone,source_snapshot,
      status,expires_at,last_queue_id,last_message_id,created_at,updated_at
    ) values(
      v_q.organization_id,v_q.store_id,v_q.connection_id,v_q.conversation_id,v_q.lead_id,v_customer.id,v_phone,
      nullif(trim(coalesce(v_customer.name,'')),''),v_customer.reported_age,nullif(trim(coalesce(v_customer.age_range,'')),''),v_age_status,
      nullif(trim(coalesce(v_customer.ethnicity,'')),''),coalesce(v_customer.ethnicity_source,'unknown'),v_eth_status,
      v_service.id,v_service.name,coalesce(v_service.default_price,0),greatest(coalesce(v_service.estimated_minutes,60),1),
      v_employee.id,v_employee.name,v_date,v_time,v_sched,'Asia/Kuala_Lumpur',v_source,
      'collecting_profile',now()+interval '20 minutes',v_q.id,v_q.message_id,now(),now()
    ) returning * into v_draft;
    insert into public.whatsapp_ai_booking_events(organization_id,store_id,draft_id,queue_id,message_id,event_type,event_payload)
    values(v_q.organization_id,v_q.store_id,v_draft.id,v_q.id,v_q.message_id,'draft_created',jsonb_build_object(
      'service_id',v_service.id,'employee_id',v_employee.id,'scheduled_at',v_sched,'source',v_source
    ));
  else
    update public.whatsapp_ai_appointment_drafts d set
      lead_id=coalesce(v_q.lead_id,d.lead_id),
      customer_id=coalesce(d.customer_id,v_customer.id),
      customer_phone=v_phone,
      customer_name=coalesce(d.customer_name,nullif(trim(coalesce(v_customer.name,'')),'')),
      reported_age=coalesce(d.reported_age,v_customer.reported_age),
      age_range=coalesce(d.age_range,nullif(trim(coalesce(v_customer.age_range,'')),'')),
      age_collection_status=case when d.age_collection_status='pending' then v_age_status else d.age_collection_status end,
      ethnicity=coalesce(d.ethnicity,nullif(trim(coalesce(v_customer.ethnicity,'')),'')),
      ethnicity_source=case when d.ethnicity_source='unknown' then coalesce(v_customer.ethnicity_source,'unknown') else d.ethnicity_source end,
      ethnicity_collection_status=case when d.ethnicity_collection_status='pending' then v_eth_status else d.ethnicity_collection_status end,
      service_id=v_service.id,service_name_snapshot=v_service.name,service_price_snapshot=coalesce(v_service.default_price,0),
      service_duration_minutes=greatest(coalesce(v_service.estimated_minutes,60),1),
      employee_id=v_employee.id,employee_name_snapshot=v_employee.name,
      appointment_date=v_date,appointment_time=v_time,scheduled_at=v_sched,
      source_snapshot=case when d.source_snapshot='{}'::jsonb then v_source else d.source_snapshot end,
      status='collecting_profile',expires_at=now()+interval '20 minutes',last_queue_id=v_q.id,last_message_id=v_q.message_id,updated_at=now()
    where d.id=v_draft.id returning * into v_draft;
  end if;

  v_next:=public.v1367_ai_draft_next_field(v_draft.id);
  v_status:=case when v_next is null then 'pending_confirmation' else 'collecting_profile' end;
  if v_draft.status<>v_status then
    update public.whatsapp_ai_appointment_drafts set status=v_status,updated_at=now() where id=v_draft.id returning * into v_draft;
    if v_status='pending_confirmation' then
      insert into public.whatsapp_ai_booking_events(organization_id,store_id,draft_id,queue_id,message_id,event_type,event_payload)
      values(v_q.organization_id,v_q.store_id,v_draft.id,v_q.id,v_q.message_id,'awaiting_confirmation','{}'::jsonb);
    end if;
  end if;

  return jsonb_build_object(
    'ok',true,'draft_id',v_draft.id,'status',v_draft.status,'next_profile_field',v_next,
    'customer',jsonb_build_object(
      'customer_id',v_draft.customer_id,'phone',v_draft.customer_phone,'name',v_draft.customer_name,
      'reported_age',v_draft.reported_age,'age_range',v_draft.age_range,'age_collection_status',v_draft.age_collection_status,
      'ethnicity',v_draft.ethnicity,'ethnicity_collection_status',v_draft.ethnicity_collection_status
    ),
    'appointment',jsonb_build_object(
      'service_id',v_draft.service_id,'service_name',v_draft.service_name_snapshot,'price',v_draft.service_price_snapshot,
      'duration_minutes',v_draft.service_duration_minutes,'employee_id',v_draft.employee_id,'employee_name',v_draft.employee_name_snapshot,
      'date',v_draft.appointment_date,'time',to_char(v_draft.appointment_time,'HH24:MI'),'scheduled_at',v_draft.scheduled_at,'timezone',v_draft.timezone
    ),
    'source',v_draft.source_snapshot,'expires_at',v_draft.expires_at
  );
end;
$$;
revoke all on function public.v1367_ai_ensure_draft(uuid) from public,anon,authenticated;
grant execute on function public.v1367_ai_ensure_draft(uuid) to service_role;

-- -----------------------------------------------------------------------------
-- Update only explicitly customer-provided profile fields. No AI-inferred race
-- or age is accepted. Age/race can be explicitly skipped.
-- -----------------------------------------------------------------------------
create or replace function public.v1367_ai_update_draft_profile(
  p_queue_id uuid,
  p_name text default null,
  p_reported_age integer default null,
  p_age_range text default null,
  p_skip_age boolean default false,
  p_ethnicity text default null,
  p_skip_ethnicity boolean default false
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_q public.whatsapp_ai_queue%rowtype;
  v_draft public.whatsapp_ai_appointment_drafts%rowtype;
  v_name text:=nullif(trim(coalesce(p_name,'')),'');
  v_range text:=nullif(trim(coalesce(p_age_range,'')),'');
  v_eth text:=nullif(trim(coalesce(p_ethnicity,'')),'');
  v_next text;
  v_status text;
begin
  select * into v_q from public.whatsapp_ai_queue where id=p_queue_id limit 1;
  if v_q.id is null then return jsonb_build_object('ok',false,'error','queue_not_found'); end if;

  select * into v_draft from public.whatsapp_ai_appointment_drafts d
   where d.organization_id=v_q.organization_id and d.store_id=v_q.store_id and d.conversation_id=v_q.conversation_id
     and d.status in ('collecting_profile','pending_confirmation')
   order by d.updated_at desc limit 1;
  if v_draft.id is null then return jsonb_build_object('ok',false,'error','active_draft_not_found'); end if;
  if v_draft.expires_at<=now() then
    update public.whatsapp_ai_appointment_drafts set status='expired',updated_at=now() where id=v_draft.id;
    return jsonb_build_object('ok',false,'error','draft_expired','draft_id',v_draft.id);
  end if;

  if v_name is not null then
    if length(v_name)>120 then return jsonb_build_object('ok',false,'error','name_too_long'); end if;
    v_draft.customer_name:=v_name;
  end if;

  if p_reported_age is not null then
    if p_reported_age<1 or p_reported_age>120 then return jsonb_build_object('ok',false,'error','age_out_of_range'); end if;
    v_draft.reported_age:=p_reported_age;
    v_draft.age_range:=null;
    v_draft.age_collection_status:='provided';
  elsif v_range is not null then
    if length(v_range)>40 then return jsonb_build_object('ok',false,'error','age_range_too_long'); end if;
    v_draft.age_range:=v_range;
    v_draft.reported_age:=null;
    v_draft.age_collection_status:='provided';
  elsif coalesce(p_skip_age,false) then
    v_draft.reported_age:=null;
    v_draft.age_range:=null;
    v_draft.age_collection_status:='skipped';
  end if;

  if v_eth is not null then
    if v_eth not in ('华人','马来人','印度人','其他','不愿透露') then
      return jsonb_build_object('ok',false,'error','invalid_ethnicity_option');
    end if;
    v_draft.ethnicity:=v_eth;
    v_draft.ethnicity_source:='customer_provided';
    v_draft.ethnicity_collection_status:=case when v_eth='不愿透露' then 'skipped' else 'provided' end;
  elsif coalesce(p_skip_ethnicity,false) then
    v_draft.ethnicity:='不愿透露';
    v_draft.ethnicity_source:='customer_provided';
    v_draft.ethnicity_collection_status:='skipped';
  end if;

  update public.whatsapp_ai_appointment_drafts d set
    customer_name=v_draft.customer_name,
    reported_age=v_draft.reported_age,
    age_range=v_draft.age_range,
    age_collection_status=v_draft.age_collection_status,
    ethnicity=v_draft.ethnicity,
    ethnicity_source=v_draft.ethnicity_source,
    ethnicity_collection_status=v_draft.ethnicity_collection_status,
    expires_at=now()+interval '20 minutes',last_queue_id=v_q.id,last_message_id=v_q.message_id,updated_at=now()
  where d.id=v_draft.id returning * into v_draft;

  v_next:=public.v1367_ai_draft_next_field(v_draft.id);
  v_status:=case when v_next is null then 'pending_confirmation' else 'collecting_profile' end;
  update public.whatsapp_ai_appointment_drafts set status=v_status,updated_at=now() where id=v_draft.id returning * into v_draft;

  insert into public.whatsapp_ai_booking_events(organization_id,store_id,draft_id,queue_id,message_id,event_type,event_payload)
  values(v_q.organization_id,v_q.store_id,v_draft.id,v_q.id,v_q.message_id,'profile_updated',jsonb_build_object(
    'name_present',v_draft.customer_name is not null,'age_status',v_draft.age_collection_status,
    'ethnicity_status',v_draft.ethnicity_collection_status,'next_profile_field',v_next
  ));
  if v_status='pending_confirmation' then
    insert into public.whatsapp_ai_booking_events(organization_id,store_id,draft_id,queue_id,message_id,event_type,event_payload)
    values(v_q.organization_id,v_q.store_id,v_draft.id,v_q.id,v_q.message_id,'awaiting_confirmation','{}'::jsonb);
  end if;

  return jsonb_build_object(
    'ok',true,'draft_id',v_draft.id,'status',v_draft.status,'next_profile_field',v_next,
    'customer',jsonb_build_object(
      'phone',v_draft.customer_phone,'name',v_draft.customer_name,'reported_age',v_draft.reported_age,
      'age_range',v_draft.age_range,'age_collection_status',v_draft.age_collection_status,
      'ethnicity',v_draft.ethnicity,'ethnicity_collection_status',v_draft.ethnicity_collection_status
    ),
    'appointment',jsonb_build_object(
      'service_name',v_draft.service_name_snapshot,'price',v_draft.service_price_snapshot,'duration_minutes',v_draft.service_duration_minutes,
      'employee_name',v_draft.employee_name_snapshot,'date',v_draft.appointment_date,'time',to_char(v_draft.appointment_time,'HH24:MI'),
      'scheduled_at',v_draft.scheduled_at,'timezone',v_draft.timezone
    ),'expires_at',v_draft.expires_at
  );
end;
$$;
revoke all on function public.v1367_ai_update_draft_profile(uuid,text,integer,text,boolean,text,boolean) from public,anon,authenticated;
grant execute on function public.v1367_ai_update_draft_profile(uuid,text,integer,text,boolean,text,boolean) to service_role;

-- -----------------------------------------------------------------------------
-- Cancel a pending draft from the current WhatsApp conversation.
-- -----------------------------------------------------------------------------
create or replace function public.v1367_ai_cancel_draft(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_q public.whatsapp_ai_queue%rowtype; v_draft public.whatsapp_ai_appointment_drafts%rowtype;
begin
  select * into v_q from public.whatsapp_ai_queue where id=p_queue_id limit 1;
  if v_q.id is null then return jsonb_build_object('ok',false,'error','queue_not_found'); end if;
  select * into v_draft from public.whatsapp_ai_appointment_drafts d
   where d.organization_id=v_q.organization_id and d.store_id=v_q.store_id and d.conversation_id=v_q.conversation_id
     and d.status in ('collecting_profile','pending_confirmation','needs_reschedule')
   order by d.updated_at desc limit 1;
  if v_draft.id is null then return jsonb_build_object('ok',true,'status','no_active_draft'); end if;
  update public.whatsapp_ai_appointment_drafts set status='cancelled',last_queue_id=v_q.id,last_message_id=v_q.message_id,updated_at=now()
   where id=v_draft.id returning * into v_draft;
  insert into public.whatsapp_ai_booking_events(organization_id,store_id,draft_id,queue_id,message_id,event_type,event_payload)
  values(v_q.organization_id,v_q.store_id,v_draft.id,v_q.id,v_q.message_id,'draft_cancelled','{}'::jsonb);
  return jsonb_build_object('ok',true,'status','cancelled','draft_id',v_draft.id);
end;
$$;
revoke all on function public.v1367_ai_cancel_draft(uuid) from public,anon,authenticated;
grant execute on function public.v1367_ai_cancel_draft(uuid) to service_role;

-- -----------------------------------------------------------------------------
-- Final confirmation. This is the ONLY v13.6.7 path that creates a real SalonOS
-- appointment. It rechecks the selected slot immediately before INSERT.
-- -----------------------------------------------------------------------------
create or replace function public.v1367_ai_confirm_draft(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_q public.whatsapp_ai_queue%rowtype;
  v_conv public.whatsapp_conversations%rowtype;
  v_draft public.whatsapp_ai_appointment_drafts%rowtype;
  v_availability jsonb;
  v_alternatives jsonb;
  v_period text:='unspecified';
  v_customer public.customers%rowtype;
  v_service public.services%rowtype;
  v_employee public.employees%rowtype;
  v_visit uuid;
  v_rec uuid;
  v_item uuid;
  v_phone text;
  v_acquisition text;
  v_visit_no text;
  v_slot text;
  v_price numeric;
  v_eth text;
begin
  select * into v_q from public.whatsapp_ai_queue where id=p_queue_id limit 1;
  if v_q.id is null then return jsonb_build_object('ok',false,'error','queue_not_found'); end if;
  select * into v_conv from public.whatsapp_conversations c
   where c.id=v_q.conversation_id and c.organization_id=v_q.organization_id and c.store_id=v_q.store_id and c.connection_id=v_q.connection_id limit 1;
  if v_conv.id is null then return jsonb_build_object('ok',false,'error','conversation_scope_mismatch'); end if;

  select * into v_draft from public.whatsapp_ai_appointment_drafts d
   where d.organization_id=v_q.organization_id and d.store_id=v_q.store_id and d.conversation_id=v_q.conversation_id
     and d.status in ('pending_confirmation','confirmed')
   order by d.updated_at desc limit 1;
  if v_draft.id is null then return jsonb_build_object('ok',false,'error','pending_draft_not_found'); end if;
  if v_draft.status='confirmed' and v_draft.confirmed_visit_id is not null then
    return jsonb_build_object('ok',true,'status','already_confirmed','draft_id',v_draft.id,'visit_id',v_draft.confirmed_visit_id);
  end if;
  if v_draft.expires_at<=now() then
    update public.whatsapp_ai_appointment_drafts set status='expired',updated_at=now() where id=v_draft.id;
    return jsonb_build_object('ok',false,'error','draft_expired','draft_id',v_draft.id);
  end if;
  if nullif(trim(coalesce(v_draft.customer_name,'')),'') is null then
    return jsonb_build_object('ok',false,'error','customer_name_required');
  end if;
  if v_draft.age_collection_status='pending' or v_draft.ethnicity_collection_status='pending' then
    return jsonb_build_object('ok',false,'error','customer_profile_incomplete');
  end if;

  -- Serialize AI confirms for the same employee/day so two simultaneous WhatsApp
  -- confirmations cannot both pass the AI-side check.
  perform pg_advisory_xact_lock(hashtextextended(
    v_draft.organization_id::text||':'||v_draft.store_id::text||':'||v_draft.employee_id::text||':'||v_draft.appointment_date::text,0
  ));

  v_slot:=to_char(v_draft.appointment_time,'HH24:MI');
  v_availability:=public.v1366_ai_check_availability(
    p_queue_id,v_draft.service_id,v_draft.employee_id,v_draft.appointment_date,v_slot,'unspecified'
  );
  if coalesce(v_availability->>'availability_status','')<>'available'
     or not exists(select 1 from jsonb_array_elements(coalesce(v_availability->'slots','[]'::jsonb)) x where x->>'time'=v_slot) then
    select coalesce(nullif(s.slots->>'time_period',''),'unspecified') into v_period
    from public.whatsapp_ai_conversation_state s
    where s.conversation_id=v_q.conversation_id and s.organization_id=v_q.organization_id and s.store_id=v_q.store_id
    limit 1;
    v_alternatives:=public.v1366_ai_check_availability(
      p_queue_id,v_draft.service_id,v_draft.employee_id,v_draft.appointment_date,null,coalesce(v_period,'unspecified')
    );
    update public.whatsapp_ai_appointment_drafts set status='needs_reschedule',last_queue_id=v_q.id,last_message_id=v_q.message_id,updated_at=now()
     where id=v_draft.id returning * into v_draft;
    insert into public.whatsapp_ai_booking_events(organization_id,store_id,draft_id,queue_id,message_id,event_type,event_payload)
    values(v_q.organization_id,v_q.store_id,v_draft.id,v_q.id,v_q.message_id,'confirm_slot_unavailable',jsonb_build_object('availability',v_availability,'alternatives',v_alternatives));
    return jsonb_build_object('ok',false,'error','slot_no_longer_available','draft_id',v_draft.id,'availability',v_availability,'alternatives',v_alternatives);
  end if;

  select * into v_service from public.services s
   where s.id=v_draft.service_id and s.organization_id=v_q.organization_id and s.store_id=v_q.store_id and coalesce(s.active,true)=true;
  select * into v_employee from public.employees e
   where e.id=v_draft.employee_id and e.organization_id=v_q.organization_id and e.employment_status='active'
     and exists(select 1 from public.employee_stores es where es.organization_id=v_q.organization_id and es.store_id=v_q.store_id and es.employee_id=e.id and es.status='active');
  if v_service.id is null or v_employee.id is null then
    return jsonb_build_object('ok',false,'error','service_or_staff_invalid_at_confirm');
  end if;

  v_phone:=regexp_replace(coalesce(v_conv.customer_phone,''),'[^0-9]','','g');
  if v_phone='' then return jsonb_build_object('ok',false,'error','customer_phone_missing'); end if;

  select c.* into v_customer from public.customers c
   where c.organization_id=v_q.organization_id and c.store_id=v_q.store_id
     and regexp_replace(coalesce(c.phone,''),'[^0-9]','','g')=v_phone
   order by c.updated_at desc nulls last,c.created_at desc limit 1;

  v_acquisition:=nullif(trim(coalesce(v_draft.source_snapshot->>'channel','')),'');
  v_eth:=nullif(trim(coalesce(v_draft.ethnicity,'')),'');

  if v_customer.id is null then
    insert into public.customers(
      organization_id,store_id,name,phone,gender,ethnicity,ethnicity_source,reported_age,age_range,age_source,age_reported_at,acquisition_platform
    ) values(
      v_q.organization_id,v_q.store_id,trim(v_draft.customer_name),v_phone,'unspecified',v_eth,
      case when v_eth is null then 'unknown' else 'customer_provided' end,
      v_draft.reported_age,nullif(trim(coalesce(v_draft.age_range,'')),''),
      case when v_draft.age_collection_status='provided' then 'customer_provided' else 'unknown' end,
      case when v_draft.age_collection_status='provided' then now() else null end,
      v_acquisition
    ) returning * into v_customer;
  else
    update public.customers c set
      name=case when nullif(trim(coalesce(c.name,'')),'') is null then trim(v_draft.customer_name) else c.name end,
      ethnicity=case when nullif(trim(coalesce(c.ethnicity,'')),'') is null and v_eth is not null then v_eth else c.ethnicity end,
      ethnicity_source=case when nullif(trim(coalesce(c.ethnicity,'')),'') is null and v_eth is not null then 'customer_provided' else c.ethnicity_source end,
      reported_age=case when c.birth_date is null and c.reported_age is null and v_draft.reported_age is not null then v_draft.reported_age else c.reported_age end,
      age_range=case when c.birth_date is null and c.reported_age is null and nullif(trim(coalesce(c.age_range,'')),'') is null then nullif(trim(coalesce(v_draft.age_range,'')),'') else c.age_range end,
      age_source=case when c.birth_date is null and c.reported_age is null and (v_draft.reported_age is not null or nullif(trim(coalesce(v_draft.age_range,'')),'') is not null) then 'customer_provided' else c.age_source end,
      age_reported_at=case when c.birth_date is null and c.reported_age is null and (v_draft.reported_age is not null or nullif(trim(coalesce(v_draft.age_range,'')),'') is not null) then now() else c.age_reported_at end,
      acquisition_platform=coalesce(nullif(trim(coalesce(c.acquisition_platform,'')),''),v_acquisition),
      updated_at=now()
    where c.id=v_customer.id returning * into v_customer;
  end if;

  if v_q.lead_id is not null then
    update public.marketing_leads set customer_id=v_customer.id,updated_at=now()
     where id=v_q.lead_id and organization_id=v_q.organization_id and store_id=v_q.store_id;
  end if;

  v_visit:=gen_random_uuid();
  v_rec:=gen_random_uuid();
  v_visit_no:='V'||to_char(now(),'YYMMDDHH24MISS')||'-'||upper(substr(encode(extensions.gen_random_bytes(3),'hex'),1,4));
  v_price:=coalesce(v_service.default_price,v_draft.service_price_snapshot,0);

  insert into public.visits(id,organization_id,store_id,visit_number,visit_type,status,scheduled_at,arrived_at,notes)
  values(
    v_visit,v_q.organization_id,v_q.store_id,v_visit_no,'appointment','booked',v_draft.scheduled_at,null,
    'WhatsApp AI confirmed · Draft '||v_draft.id::text
  );

  insert into public.visit_recipients(id,organization_id,visit_id,customer_id,name_snapshot,phone_snapshot,recipient_type)
  values(v_rec,v_q.organization_id,v_visit,v_customer.id,v_customer.name,v_customer.phone,'primary');

  insert into public.visit_service_items(
    organization_id,store_id,visit_id,recipient_id,service_id,service_name_snapshot,service_category_snapshot,
    unit_price,quantity,estimated_minutes_snapshot,status
  ) values(
    v_q.organization_id,v_q.store_id,v_visit,v_rec,v_service.id,v_service.name,v_service.category,
    greatest(coalesce(v_price,0),0),1,greatest(coalesce(v_service.estimated_minutes,v_draft.service_duration_minutes,60),1),'waiting'
  ) returning id into v_item;

  insert into public.visit_service_workers(
    organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status
  ) values(v_q.organization_id,v_q.store_id,v_item,v_employee.id,'primary',100,'active');

  if to_regclass('public.appointment_employee_preferences') is not null then
    insert into public.appointment_employee_preferences(organization_id,store_id,visit_id,preference_type,employee_id)
    values(v_q.organization_id,v_q.store_id,v_visit,'specified',v_employee.id)
    on conflict do nothing;
  end if;

  update public.whatsapp_ai_appointment_drafts set
    customer_id=v_customer.id,status='confirmed',confirmed_visit_id=v_visit,confirmed_at=now(),
    last_queue_id=v_q.id,last_message_id=v_q.message_id,updated_at=now()
  where id=v_draft.id returning * into v_draft;

  insert into public.whatsapp_ai_booking_events(organization_id,store_id,draft_id,queue_id,message_id,event_type,event_payload)
  values(v_q.organization_id,v_q.store_id,v_draft.id,v_q.id,v_q.message_id,'appointment_confirmed',jsonb_build_object(
    'visit_id',v_visit,'visit_number',v_visit_no,'customer_id',v_customer.id,'scheduled_at',v_draft.scheduled_at
  ));

  return jsonb_build_object(
    'ok',true,'status','confirmed','draft_id',v_draft.id,'visit_id',v_visit,'visit_number',v_visit_no,
    'customer',jsonb_build_object('customer_id',v_customer.id,'name',v_customer.name,'phone',v_customer.phone),
    'appointment',jsonb_build_object(
      'date',v_draft.appointment_date,'time',to_char(v_draft.appointment_time,'HH24:MI'),'scheduled_at',v_draft.scheduled_at,
      'service_id',v_service.id,'service_name',v_service.name,'price',v_price,'duration_minutes',greatest(coalesce(v_service.estimated_minutes,60),1),
      'employee_id',v_employee.id,'employee_name',v_employee.name
    )
  );
exception when others then
  if v_draft.id is not null then
    begin
      insert into public.whatsapp_ai_booking_events(organization_id,store_id,draft_id,queue_id,message_id,event_type,event_payload)
      values(v_q.organization_id,v_q.store_id,v_draft.id,v_q.id,v_q.message_id,'confirm_failed',jsonb_build_object('error',sqlerrm));
    exception when others then null; end;
  end if;
  raise;
end;
$$;
revoke all on function public.v1367_ai_confirm_draft(uuid) from public,anon,authenticated;
grant execute on function public.v1367_ai_confirm_draft(uuid) to service_role;


-- -----------------------------------------------------------------------------
-- Search Customer v13.6.7 wrapper: preserve the proven v13.6.2 lookup/history,
-- but treat explicitly reported age/range as valid profile data so returning
-- customers are not asked for age again after they already supplied it.
-- -----------------------------------------------------------------------------
create or replace function public.v1367_ai_prepare_customer_context(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result jsonb;
  v_customer_id uuid;
  v_customer public.customers%rowtype;
  v_missing jsonb:='[]'::jsonb;
  v_item jsonb;
begin
  v_result:=public.v1362_ai_prepare_customer_context(p_queue_id);
  if coalesce(v_result->>'customer_status','')<>'existing_customer' then return v_result; end if;
  begin v_customer_id:=nullif(v_result->>'customer_id','')::uuid; exception when others then v_customer_id:=null; end;
  if v_customer_id is null then return v_result; end if;
  select * into v_customer from public.customers where id=v_customer_id limit 1;
  if v_customer.id is null then return v_result; end if;

  for v_item in select value from jsonb_array_elements(coalesce(v_result->'missing_fields','[]'::jsonb)) loop
    if trim(both '"' from v_item::text)='age_or_birth_date'
       and (v_customer.birth_date is not null or v_customer.reported_age is not null or nullif(trim(coalesce(v_customer.age_range,'')),'') is not null) then
      continue;
    end if;
    v_missing:=v_missing||jsonb_build_array(trim(both '"' from v_item::text));
  end loop;

  return v_result || jsonb_build_object(
    'reported_age',v_customer.reported_age,
    'age_range',v_customer.age_range,
    'age_source',coalesce(v_customer.age_source,'unknown'),
    'missing_fields',v_missing
  );
end;
$$;
revoke all on function public.v1367_ai_prepare_customer_context(uuid) from public,anon,authenticated;
grant execute on function public.v1367_ai_prepare_customer_context(uuid) to service_role;

insert into public.salonos_system_meta(meta_key,meta_value)
values
 ('whatsapp_ai_booking_draft_version','13.6.7'),
 ('whatsapp_ai_profile_collection_version','13.6.7'),
 ('whatsapp_ai_confirm_appointment_version','13.6.7')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.6.7 APPOINTMENT DRAFT + CONFIRM READY' as result,
  to_regclass('public.whatsapp_ai_appointment_drafts') is not null as appointment_draft_ok,
  to_regclass('public.whatsapp_ai_booking_events') is not null as booking_audit_ok,
  to_regprocedure('public.v1367_ai_ensure_draft(uuid)') is not null as ensure_draft_ok,
  to_regprocedure('public.v1367_ai_update_draft_profile(uuid,text,integer,text,boolean,text,boolean)') is not null as profile_update_ok,
  to_regprocedure('public.v1367_ai_confirm_draft(uuid)') is not null as confirm_backend_ok,
  to_regprocedure('public.v1367_ai_cancel_draft(uuid)') is not null as cancel_backend_ok,
  to_regprocedure('public.v1367_ai_prepare_customer_context(uuid)') is not null as search_customer_v1367_ok;
