begin;

-- SalonOS v13.6.8.1
-- Lifecycle integrity hotfix:
-- 1) Normalize lifecycle timestamps at the database boundary, not only in individual clients.
-- 2) Backfill legacy completed + paid visits that reached checkout but missed service_completed_at.
-- 3) Preserve the rule that an appointment is not a completed visit until arrival + service completion + checkout + paid.

create or replace function public.v13681_visit_lifecycle_integrity()
returns trigger
language plpgsql
set search_path=public
as $$
begin
  if new.status is distinct from old.status then
    if new.status='arrived' then
      new.arrived_at := coalesce(new.arrived_at,old.arrived_at,now());

    elsif new.status='in_service' then
      if coalesce(new.visit_type,old.visit_type)='appointment'
         and coalesce(new.arrived_at,old.arrived_at) is null then
        raise exception '预约顾客尚未确认到店，不能开始服务。';
      end if;
      new.started_at := coalesce(new.started_at,old.started_at,now());

    elsif new.status='ready_for_checkout' then
      if coalesce(new.started_at,old.started_at) is null then
        raise exception '服务尚未开始，不能直接进入待结账。';
      end if;
      new.service_completed_at := coalesce(new.service_completed_at,old.service_completed_at,now());

    elsif new.status='completed' then
      if coalesce(new.visit_type,old.visit_type)='appointment'
         and coalesce(new.arrived_at,old.arrived_at) is null then
        raise exception '预约顾客尚未确认到店，不能完成结账。';
      end if;
      -- completed semantically means the service is complete. If an older client skipped
      -- writing service_completed_at, anchor it no later than checkout.
      new.service_completed_at := coalesce(
        new.service_completed_at,
        old.service_completed_at,
        new.checked_out_at,
        old.checked_out_at,
        now()
      );
      new.checked_out_at := coalesce(new.checked_out_at,old.checked_out_at,now());
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_v13681_visit_lifecycle_integrity on public.visits;
create trigger trg_v13681_visit_lifecycle_integrity
before update of status on public.visits
for each row
execute function public.v13681_visit_lifecycle_integrity();

-- Safe historical repair only for visits that have strong evidence of a real completed visit:
-- completed status + service started + checkout timestamp + paid payment + appointment arrived (when applicable).
with repairable as (
  select v.id
  from public.visits v
  where v.status='completed'
    and v.service_completed_at is null
    and v.started_at is not null
    and v.checked_out_at is not null
    and (v.visit_type='walk_in' or v.arrived_at is not null)
    and exists (
      select 1
      from public.payments p
      where p.visit_id=v.id
        and p.organization_id=v.organization_id
        and p.store_id=v.store_id
        and p.status='paid'
    )
)
update public.visits v
set service_completed_at=coalesce(v.service_completed_at,v.checked_out_at),
    updated_at=now()
from repairable r
where v.id=r.id;

insert into public.salonos_system_meta(meta_key,meta_value)
values
  ('lifecycle_integrity_version','13.6.8.1'),
  ('customer_intelligence_version','13.6.8.1')
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.6.8.1 LIFECYCLE INTEGRITY READY' as result,
  to_regprocedure('public.v13681_visit_lifecycle_integrity()') is not null as lifecycle_guard_ok,
  exists(
    select 1 from pg_trigger
    where tgname='trg_v13681_visit_lifecycle_integrity'
      and not tgisinternal
  ) as lifecycle_trigger_ok,
  count(*) filter (
    where v.status='completed'
      and v.checked_out_at is not null
      and exists (
        select 1 from public.payments p
        where p.visit_id=v.id
          and p.organization_id=v.organization_id
          and p.store_id=v.store_id
          and p.status='paid'
      )
  ) as completed_paid_visits,
  count(*) filter (
    where v.status='completed'
      and v.service_completed_at is null
      and v.checked_out_at is not null
      and exists (
        select 1 from public.payments p
        where p.visit_id=v.id
          and p.organization_id=v.organization_id
          and p.store_id=v.store_id
          and p.status='paid'
      )
  ) as remaining_completed_paid_missing_service_completed
from public.visits v;
