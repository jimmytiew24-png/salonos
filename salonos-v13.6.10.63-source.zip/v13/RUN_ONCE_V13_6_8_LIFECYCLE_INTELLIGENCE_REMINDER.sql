-- SalonOS v13.6.8 · Appointment Lifecycle + Customer Intelligence + WhatsApp Reminder
-- Run AFTER v13.6.7 / v13.6.7.1. Additive / idempotent.
--
-- Core rules:
--   * A booked appointment is NOT a completed visit.
--   * Customer history counts only completed + service_completed + checked_out + paid visits.
--   * AI-created appointments keep lifecycle audit events without changing the original SalonOS visit flow.
--   * Reminder jobs are branch-scoped and idempotent.
--   * Reminder sender decides text-vs-template based on the WhatsApp customer-service window.

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- Branch-scoped reminder configuration. Access token remains server-side only.
-- -----------------------------------------------------------------------------
alter table public.whatsapp_store_configs
  add column if not exists reminder_enabled boolean not null default true,
  add column if not exists reminder_minutes_before integer not null default 60,
  add column if not exists reminder_text_template text,
  add column if not exists reminder_template_name text,
  add column if not exists reminder_template_language text not null default 'zh_CN';

do $$ begin
  if not exists(
    select 1 from pg_constraint
    where conname='whatsapp_store_configs_reminder_minutes_check'
      and conrelid='public.whatsapp_store_configs'::regclass
  ) then
    alter table public.whatsapp_store_configs
      add constraint whatsapp_store_configs_reminder_minutes_check
      check(reminder_minutes_before between 0 and 10080);
  end if;
end $$;

-- -----------------------------------------------------------------------------
-- Reminder queue / audit.
-- One reminder policy row per visit. Updating the appointment safely updates the
-- pending reminder instead of creating duplicate customer messages.
-- -----------------------------------------------------------------------------
create table if not exists public.whatsapp_appointment_reminders (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  visit_id uuid not null references public.visits(id) on delete cascade,
  connection_id uuid not null references public.whatsapp_business_connections(id) on delete cascade,
  conversation_id uuid references public.whatsapp_conversations(id) on delete set null,
  customer_id uuid references public.customers(id) on delete set null,
  customer_phone text not null,
  customer_name text,
  store_name text,
  service_name text,
  employee_name text,
  scheduled_at timestamptz not null,
  reminder_minutes_before integer not null default 60,
  due_at timestamptz not null,
  status text not null default 'pending' check(status in (
    'pending','processing','sent','failed','skipped','template_required'
  )),
  send_mode text check(send_mode in ('text','template')),
  attempts integer not null default 0,
  meta_message_id text,
  outbound_message_id uuid references public.whatsapp_messages(id) on delete set null,
  last_inbound_at timestamptz,
  last_error text,
  sent_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(visit_id)
);
create index if not exists whatsapp_appointment_reminders_due_idx
  on public.whatsapp_appointment_reminders(status,due_at,scheduled_at);
create index if not exists whatsapp_appointment_reminders_store_idx
  on public.whatsapp_appointment_reminders(organization_id,store_id,scheduled_at desc);

alter table public.whatsapp_appointment_reminders enable row level security;
drop policy if exists v1368_reminders_read on public.whatsapp_appointment_reminders;
create policy v1368_reminders_read on public.whatsapp_appointment_reminders
for select to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));
grant select on public.whatsapp_appointment_reminders to authenticated;
grant all on public.whatsapp_appointment_reminders to service_role;

-- -----------------------------------------------------------------------------
-- Lifecycle audit for appointments created through the WhatsApp AI draft flow.
-- This is audit-only; original SalonOS visits/payments remain source of truth.
-- -----------------------------------------------------------------------------
create table if not exists public.whatsapp_ai_visit_lifecycle_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  draft_id uuid references public.whatsapp_ai_appointment_drafts(id) on delete set null,
  visit_id uuid not null references public.visits(id) on delete cascade,
  event_type text not null,
  visit_status text,
  event_payload jsonb not null default '{}'::jsonb,
  occurred_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists whatsapp_ai_visit_lifecycle_visit_idx
  on public.whatsapp_ai_visit_lifecycle_events(visit_id,occurred_at desc);
create index if not exists whatsapp_ai_visit_lifecycle_store_idx
  on public.whatsapp_ai_visit_lifecycle_events(organization_id,store_id,occurred_at desc);
alter table public.whatsapp_ai_visit_lifecycle_events enable row level security;
drop policy if exists v1368_lifecycle_read on public.whatsapp_ai_visit_lifecycle_events;
create policy v1368_lifecycle_read on public.whatsapp_ai_visit_lifecycle_events
for select to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));
grant select on public.whatsapp_ai_visit_lifecycle_events to authenticated;
grant all on public.whatsapp_ai_visit_lifecycle_events to service_role;

-- -----------------------------------------------------------------------------
-- Customer intelligence: mirrors SalonOS three-segment rule, but only uses truly
-- completed/checked-out/paid visits. Missing historical preference = random/system.
-- -----------------------------------------------------------------------------
create or replace function public.v1368_customer_intelligence(
  p_organization_id uuid,
  p_store_id uuid,
  p_customer_id uuid
) returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_customer public.customers%rowtype;
  v_phone text;
  v_customer_ids uuid[]:=array[]::uuid[];
  v_visits integer:=0;
  v_last timestamptz;
  v_favourite text;
  v_dom_id uuid;
  v_dom_name text;
  v_specified integer:=0;
  v_random integer:=0;
  v_segment text:='new_lead';
begin
  select * into v_customer from public.customers c
  where c.id=p_customer_id and c.organization_id=p_organization_id and c.store_id=p_store_id limit 1;
  if v_customer.id is null then return jsonb_build_object('ok',false,'error','customer_not_found'); end if;

  v_phone:=regexp_replace(coalesce(v_customer.phone,''),'[^0-9]','','g');
  select coalesce(array_agg(c.id),array[v_customer.id]::uuid[]) into v_customer_ids
  from public.customers c
  where c.organization_id=p_organization_id and c.store_id=p_store_id
    and (c.id=v_customer.id or (v_phone<>'' and regexp_replace(coalesce(c.phone,''),'[^0-9]','','g')=v_phone));

  with completed as (
    select distinct v.id,v.checked_out_at
    from public.visits v
    join public.visit_recipients vr on vr.visit_id=v.id and vr.organization_id=v.organization_id
    where v.organization_id=p_organization_id and v.store_id=p_store_id
      and vr.customer_id=any(v_customer_ids)
      and v.status='completed'
      and v.service_completed_at is not null
      and v.checked_out_at is not null
      and (v.visit_type='walk_in' or v.arrived_at is not null)
      and exists(select 1 from public.payments p where p.organization_id=v.organization_id and p.store_id=v.store_id and p.visit_id=v.id and p.status='paid')
  )
  select count(*)::integer,max(checked_out_at) into v_visits,v_last from completed;

  select si.service_name_snapshot into v_favourite
  from public.visit_service_items si
  join public.visits v on v.id=si.visit_id and v.organization_id=si.organization_id and v.store_id=si.store_id
  where si.organization_id=p_organization_id and si.store_id=p_store_id
    and coalesce(si.status,'')<>'cancelled'
    and exists(select 1 from public.visit_recipients vr where vr.visit_id=v.id and vr.organization_id=v.organization_id and vr.customer_id=any(v_customer_ids))
    and v.status='completed' and v.service_completed_at is not null and v.checked_out_at is not null
    and (v.visit_type='walk_in' or v.arrived_at is not null)
    and exists(select 1 from public.payments p where p.organization_id=v.organization_id and p.store_id=v.store_id and p.visit_id=v.id and p.status='paid')
  group by si.service_name_snapshot
  order by count(*) desc,max(v.checked_out_at) desc limit 1;

  select e.id,e.name into v_dom_id,v_dom_name
  from public.visit_service_workers w
  join public.visit_service_items si on si.id=w.service_item_id and si.organization_id=w.organization_id and si.store_id=w.store_id
  join public.visits v on v.id=si.visit_id and v.organization_id=si.organization_id and v.store_id=si.store_id
  join public.employees e on e.id=w.employee_id and e.organization_id=w.organization_id
  where w.organization_id=p_organization_id and w.store_id=p_store_id and w.status='active'
    and w.worker_role in ('primary','support') and coalesce(si.status,'')<>'cancelled'
    and exists(select 1 from public.visit_recipients vr where vr.visit_id=v.id and vr.organization_id=v.organization_id and vr.customer_id=any(v_customer_ids))
    and v.status='completed' and v.service_completed_at is not null and v.checked_out_at is not null
    and (v.visit_type='walk_in' or v.arrived_at is not null)
    and exists(select 1 from public.payments p where p.organization_id=v.organization_id and p.store_id=v.store_id and p.visit_id=v.id and p.status='paid')
  group by e.id,e.name
  order by count(distinct v.id) desc,sum(coalesce(w.contribution_percent,0)) desc,max(v.checked_out_at) desc limit 1;

  with completed as (
    select distinct v.id
    from public.visits v
    join public.visit_recipients vr on vr.visit_id=v.id and vr.organization_id=v.organization_id
    where v.organization_id=p_organization_id and v.store_id=p_store_id and vr.customer_id=any(v_customer_ids)
      and v.status='completed' and v.service_completed_at is not null and v.checked_out_at is not null
      and (v.visit_type='walk_in' or v.arrived_at is not null)
      and exists(select 1 from public.payments p where p.organization_id=v.organization_id and p.store_id=v.store_id and p.visit_id=v.id and p.status='paid')
  )
  select
    count(*) filter(where coalesce(pref.preference_type,'random')='specified')::integer,
    count(*) filter(where coalesce(pref.preference_type,'random')<>'specified')::integer
  into v_specified,v_random
  from completed c
  left join public.appointment_employee_preferences pref
    on pref.visit_id=c.id and pref.organization_id=p_organization_id and pref.store_id=p_store_id;

  if coalesce(v_visits,0)<=0 then v_segment:='new_lead';
  elsif v_visits=1 then v_segment:='first_visit';
  elsif coalesce(v_specified,0)>coalesce(v_random,0) then v_segment:='returning_specified';
  else v_segment:='returning_random_or_mixed'; end if;

  return jsonb_build_object(
    'ok',true,
    'segment',v_segment,
    'completed_visit_count',coalesce(v_visits,0),
    'last_visit_at',v_last,
    'favourite_service',v_favourite,
    'dominant_stylist',case when v_dom_id is null then null else jsonb_build_object('employee_id',v_dom_id,'name',v_dom_name) end,
    'preference',jsonb_build_object(
      'specified_count',coalesce(v_specified,0),
      'random_or_system_count',coalesce(v_random,0),
      'specified_rate',case when coalesce(v_visits,0)>0 then round((coalesce(v_specified,0)::numeric/v_visits::numeric)*100,1) else 0 end
    )
  );
end;
$$;
revoke all on function public.v1368_customer_intelligence(uuid,uuid,uuid) from public,anon,authenticated;
grant execute on function public.v1368_customer_intelligence(uuid,uuid,uuid) to service_role;

create or replace function public.v1368_ai_prepare_customer_context(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result jsonb;
  v_q public.whatsapp_ai_queue%rowtype;
  v_customer_id uuid;
  v_intel jsonb;
begin
  select * into v_q from public.whatsapp_ai_queue where id=p_queue_id limit 1;
  if v_q.id is null then return jsonb_build_object('ok',false,'error','queue_not_found'); end if;
  v_result:=public.v1367_ai_prepare_customer_context(p_queue_id);
  begin v_customer_id:=nullif(v_result->>'customer_id','')::uuid; exception when others then v_customer_id:=null; end;
  if v_customer_id is null then
    v_intel:=jsonb_build_object('ok',true,'segment','new_lead','completed_visit_count',0);
  else
    v_intel:=public.v1368_customer_intelligence(v_q.organization_id,v_q.store_id,v_customer_id);
  end if;
  v_result:=v_result || jsonb_build_object(
    'customer_segment',coalesce(v_intel->>'segment','new_lead'),
    'customer_intelligence',v_intel
  );
  update public.whatsapp_ai_queue set
    context=coalesce(context,'{}'::jsonb)||jsonb_build_object(
      'pipeline_stage','customer_searched',
      'customer_search',v_result,
      'customer_intelligence',v_intel,
      'customer_search_at',now()
    ),updated_at=now()
  where id=v_q.id;
  return v_result;
end;
$$;
revoke all on function public.v1368_ai_prepare_customer_context(uuid) from public,anon,authenticated;
grant execute on function public.v1368_ai_prepare_customer_context(uuid) to service_role;

-- -----------------------------------------------------------------------------
-- Owner reminder settings. This RPC does not return access-token text.
-- -----------------------------------------------------------------------------
create or replace function public.v1368_owner_save_whatsapp_reminder_config(
  p_store_id uuid,
  p_reminder_enabled boolean default true,
  p_reminder_minutes_before integer default 60,
  p_reminder_text_template text default null,
  p_reminder_template_name text default null,
  p_reminder_template_language text default 'zh_CN'
) returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare v_org uuid; v_minutes integer; v_row record;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id;
  if v_org is null then raise exception 'Store not found'; end if;
  if not public.has_organization_role(v_org,array['owner','manager']) or not public.can_access_store(p_store_id) then raise exception 'Not allowed'; end if;
  v_minutes:=greatest(0,least(10080,coalesce(p_reminder_minutes_before,60)));
  update public.whatsapp_store_configs c set
    reminder_enabled=coalesce(p_reminder_enabled,true),
    reminder_minutes_before=v_minutes,
    reminder_text_template=nullif(trim(coalesce(p_reminder_text_template,'')),''),
    reminder_template_name=nullif(trim(coalesce(p_reminder_template_name,'')),''),
    reminder_template_language=coalesce(nullif(trim(coalesce(p_reminder_template_language,'')),''),'zh_CN'),
    updated_at=now()
  where c.organization_id=v_org and c.store_id=p_store_id
  returning reminder_enabled,reminder_minutes_before,reminder_text_template,reminder_template_name,reminder_template_language into v_row;
  if not found then raise exception 'WhatsApp branch config not found. Save WhatsApp connection first.'; end if;
  -- If an approved template is newly configured, previously blocked reminders can
  -- be considered again on the next Cron run (as long as they are not stale).
  if nullif(trim(coalesce(p_reminder_template_name,'')),'') is not null then
    update public.whatsapp_appointment_reminders r set status='pending',last_error=null,updated_at=now()
    where r.organization_id=v_org and r.store_id=p_store_id and r.status='template_required' and r.scheduled_at>now();
  end if;
  return jsonb_build_object(
    'ok',true,'reminder_enabled',v_row.reminder_enabled,'reminder_minutes_before',v_row.reminder_minutes_before,
    'reminder_text_template',v_row.reminder_text_template,'reminder_template_name',v_row.reminder_template_name,
    'reminder_template_language',v_row.reminder_template_language
  );
end;
$$;
revoke all on function public.v1368_owner_save_whatsapp_reminder_config(uuid,boolean,integer,text,text,text) from public,anon;
grant execute on function public.v1368_owner_save_whatsapp_reminder_config(uuid,boolean,integer,text,text,text) to authenticated;

create or replace function public.v1368_owner_whatsapp_reminder_config_status(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,pg_temp
as $$
declare v_org uuid; v_row record;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id;
  if v_org is null then raise exception 'Store not found'; end if;
  if not public.has_organization_role(v_org,array['owner','manager']) or not public.can_access_store(p_store_id) then raise exception 'Not allowed'; end if;
  select reminder_enabled,reminder_minutes_before,reminder_text_template,reminder_template_name,reminder_template_language
  into v_row from public.whatsapp_store_configs where organization_id=v_org and store_id=p_store_id limit 1;
  if not found then return jsonb_build_object('configured',false); end if;
  return to_jsonb(v_row)||jsonb_build_object('configured',true);
end;
$$;
revoke all on function public.v1368_owner_whatsapp_reminder_config_status(uuid) from public,anon;
grant execute on function public.v1368_owner_whatsapp_reminder_config_status(uuid) to authenticated;

-- -----------------------------------------------------------------------------
-- Build/refresh reminder queue from SalonOS booked appointments.
-- -----------------------------------------------------------------------------
create or replace function public.v1368_sync_reminder_queue()
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_upserted integer:=0; v_skipped integer:=0;
begin
  insert into public.whatsapp_appointment_reminders(
    organization_id,store_id,visit_id,connection_id,conversation_id,customer_id,customer_phone,customer_name,
    store_name,service_name,employee_name,scheduled_at,reminder_minutes_before,due_at,status,last_inbound_at,updated_at
  )
  select
    v.organization_id,v.store_id,v.id,c.id,
    conv.id,vr.customer_id,regexp_replace(coalesce(vr.phone_snapshot,''),'[^0-9]','','g'),vr.name_snapshot,
    st.name,
    (select string_agg(distinct si.service_name_snapshot,' + ' order by si.service_name_snapshot) from public.visit_service_items si where si.organization_id=v.organization_id and si.store_id=v.store_id and si.visit_id=v.id and coalesce(si.status,'')<>'cancelled'),
    (select string_agg(distinct e.name,', ' order by e.name) from public.visit_service_items si join public.visit_service_workers w on w.service_item_id=si.id and w.organization_id=si.organization_id and w.store_id=si.store_id and w.status='active' join public.employees e on e.id=w.employee_id and e.organization_id=w.organization_id where si.organization_id=v.organization_id and si.store_id=v.store_id and si.visit_id=v.id and coalesce(si.status,'')<>'cancelled'),
    v.scheduled_at,cfg.reminder_minutes_before,
    v.scheduled_at-make_interval(mins=>cfg.reminder_minutes_before),
    'pending',
    (select max(m.received_at) from public.whatsapp_messages m where m.conversation_id=conv.id and m.direction='inbound'),
    now()
  from public.visits v
  join public.stores st on st.id=v.store_id and st.organization_id=v.organization_id
  join public.visit_recipients vr on vr.visit_id=v.id and vr.organization_id=v.organization_id and vr.recipient_type='primary'
  join public.whatsapp_store_configs cfg on cfg.organization_id=v.organization_id and cfg.store_id=v.store_id and cfg.reminder_enabled=true
  join public.whatsapp_business_connections c on c.id=cfg.connection_id and c.organization_id=v.organization_id and c.store_id=v.store_id and c.enabled=true
  left join lateral (
    select wc.* from public.whatsapp_conversations wc
    where wc.organization_id=v.organization_id and wc.store_id=v.store_id and wc.connection_id=c.id
      and regexp_replace(coalesce(wc.customer_phone,''),'[^0-9]','','g')=regexp_replace(coalesce(vr.phone_snapshot,''),'[^0-9]','','g')
    order by wc.last_message_at desc limit 1
  ) conv on true
  where v.visit_type='appointment' and v.status='booked' and v.scheduled_at is not null
    and v.scheduled_at>now()
    and regexp_replace(coalesce(vr.phone_snapshot,''),'[^0-9]','','g')<>''
  on conflict(visit_id) do update set
    connection_id=excluded.connection_id,conversation_id=excluded.conversation_id,customer_id=excluded.customer_id,
    customer_phone=excluded.customer_phone,customer_name=excluded.customer_name,store_name=excluded.store_name,
    service_name=excluded.service_name,employee_name=excluded.employee_name,scheduled_at=excluded.scheduled_at,
    reminder_minutes_before=excluded.reminder_minutes_before,due_at=excluded.due_at,last_inbound_at=excluded.last_inbound_at,
    status=case when public.whatsapp_appointment_reminders.status in ('sent','processing','failed','template_required') then public.whatsapp_appointment_reminders.status else 'pending' end,
    last_error=case when public.whatsapp_appointment_reminders.status in ('sent','processing','failed','template_required') then public.whatsapp_appointment_reminders.last_error else null end,
    updated_at=now();
  get diagnostics v_upserted=row_count;

  update public.whatsapp_appointment_reminders r set status='skipped',last_error='appointment_no_longer_booked',updated_at=now()
  where r.status in ('pending','failed','template_required')
    and not exists(select 1 from public.visits v where v.id=r.visit_id and v.organization_id=r.organization_id and v.store_id=r.store_id and v.status='booked' and v.scheduled_at>now());
  get diagnostics v_skipped=row_count;
  return jsonb_build_object('ok',true,'upserted',v_upserted,'skipped',v_skipped);
end;
$$;
revoke all on function public.v1368_sync_reminder_queue() from public,anon,authenticated;
grant execute on function public.v1368_sync_reminder_queue() to service_role;

create or replace function public.v1368_claim_due_reminders(p_limit integer default 20)
returns setof public.whatsapp_appointment_reminders
language plpgsql
security definer
set search_path=public
as $$
begin
  perform public.v1368_sync_reminder_queue();
  -- Anything more than 30 minutes late is stale and should not surprise the customer.
  update public.whatsapp_appointment_reminders set status='skipped',last_error='reminder_too_late',updated_at=now()
  where status in ('pending','failed','template_required') and due_at<now()-interval '30 minutes';

  return query
  with picked as (
    select r.id from public.whatsapp_appointment_reminders r
    where (
      r.status='pending'
      or (r.status='failed' and r.attempts<3 and r.updated_at<now()-interval '5 minutes')
      or (r.status='processing' and r.updated_at<now()-interval '10 minutes')
    )
      and r.due_at<=now() and r.due_at>=now()-interval '30 minutes' and r.scheduled_at>now()
    order by r.due_at,r.created_at
    for update skip locked
    limit greatest(1,least(coalesce(p_limit,20),100))
  )
  update public.whatsapp_appointment_reminders r set
    status='processing',attempts=r.attempts+1,updated_at=now(),last_error=null
  from picked p where r.id=p.id
  returning r.*;
end;
$$;
revoke all on function public.v1368_claim_due_reminders(integer) from public,anon,authenticated;
grant execute on function public.v1368_claim_due_reminders(integer) to service_role;

create or replace function public.v1368_finish_reminder(
  p_reminder_id uuid,
  p_status text,
  p_send_mode text default null,
  p_meta_message_id text default null,
  p_outbound_message_id uuid default null,
  p_error text default null
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_status text:=lower(trim(coalesce(p_status,''))); v_row public.whatsapp_appointment_reminders%rowtype;
begin
  if v_status not in ('sent','failed','skipped','template_required') then v_status:='failed'; end if;
  update public.whatsapp_appointment_reminders set
    status=v_status,send_mode=case when p_send_mode in ('text','template') then p_send_mode else send_mode end,
    meta_message_id=coalesce(nullif(trim(coalesce(p_meta_message_id,'')),''),meta_message_id),
    outbound_message_id=coalesce(p_outbound_message_id,outbound_message_id),
    last_error=nullif(trim(coalesce(p_error,'')),''),sent_at=case when v_status='sent' then now() else sent_at end,
    updated_at=now()
  where id=p_reminder_id returning * into v_row;
  if v_row.id is null then return jsonb_build_object('ok',false,'error','reminder_not_found'); end if;
  return jsonb_build_object('ok',true,'status',v_row.status,'attempts',v_row.attempts,'sent_at',v_row.sent_at);
end;
$$;
revoke all on function public.v1368_finish_reminder(uuid,text,text,text,uuid,text) from public,anon,authenticated;
grant execute on function public.v1368_finish_reminder(uuid,text,text,text,uuid,text) to service_role;

-- -----------------------------------------------------------------------------
-- Lifecycle snapshots and triggers for WhatsApp-AI-created appointments.
-- -----------------------------------------------------------------------------
create or replace function public.v1368_ai_visit_lifecycle_snapshot(p_visit_id uuid)
returns jsonb language sql stable security definer set search_path=public as $$
select jsonb_build_object(
  'visit_id',v.id,'visit_number',v.visit_number,'visit_type',v.visit_type,'status',v.status,
  'scheduled_at',v.scheduled_at,'arrived_at',v.arrived_at,'started_at',v.started_at,
  'service_completed_at',v.service_completed_at,'checked_out_at',v.checked_out_at,
  'paid',exists(select 1 from public.payments p where p.visit_id=v.id and p.organization_id=v.organization_id and p.store_id=v.store_id and p.status='paid'),
  'completed_visit',(
    v.status='completed' and v.service_completed_at is not null and v.checked_out_at is not null
    and (v.visit_type='walk_in' or v.arrived_at is not null)
    and exists(select 1 from public.payments p where p.visit_id=v.id and p.organization_id=v.organization_id and p.store_id=v.store_id and p.status='paid')
  )
) from public.visits v where v.id=p_visit_id;
$$;
revoke all on function public.v1368_ai_visit_lifecycle_snapshot(uuid) from public,anon,authenticated;
grant execute on function public.v1368_ai_visit_lifecycle_snapshot(uuid) to service_role;

create or replace function public.v1368_log_ai_visit_change()
returns trigger language plpgsql security definer set search_path=public as $$
declare v_draft uuid; v_event text; v_payload jsonb;
begin
  select d.id into v_draft from public.whatsapp_ai_appointment_drafts d where d.confirmed_visit_id=new.id limit 1;
  if v_draft is null then return new; end if;
  if tg_op='INSERT' then v_event:='appointment_created';
  elsif old.status is distinct from new.status then v_event:='status_'||new.status;
  elsif old.arrived_at is distinct from new.arrived_at and new.arrived_at is not null then v_event:='arrived';
  elsif old.started_at is distinct from new.started_at and new.started_at is not null then v_event:='service_started';
  elsif old.service_completed_at is distinct from new.service_completed_at and new.service_completed_at is not null then v_event:='service_completed';
  elsif old.checked_out_at is distinct from new.checked_out_at and new.checked_out_at is not null then v_event:='checked_out';
  else return new; end if;
  v_payload:=public.v1368_ai_visit_lifecycle_snapshot(new.id);
  insert into public.whatsapp_ai_visit_lifecycle_events(organization_id,store_id,draft_id,visit_id,event_type,visit_status,event_payload)
  values(new.organization_id,new.store_id,v_draft,new.id,v_event,new.status,coalesce(v_payload,'{}'::jsonb));
  return new;
end;
$$;

drop trigger if exists v1368_ai_visit_lifecycle_trg on public.visits;
create trigger v1368_ai_visit_lifecycle_trg
after insert or update on public.visits
for each row execute function public.v1368_log_ai_visit_change();

create or replace function public.v1368_log_ai_payment_change()
returns trigger language plpgsql security definer set search_path=public as $$
declare v_draft uuid; v_visit public.visits%rowtype;
begin
  if coalesce(new.status,'')<>'paid' then return new; end if;
  if tg_op='UPDATE' and coalesce(old.status,'')='paid' then return new; end if;
  select * into v_visit from public.visits where id=new.visit_id limit 1;
  if v_visit.id is null then return new; end if;
  select d.id into v_draft from public.whatsapp_ai_appointment_drafts d where d.confirmed_visit_id=v_visit.id limit 1;
  if v_draft is null then return new; end if;
  insert into public.whatsapp_ai_visit_lifecycle_events(organization_id,store_id,draft_id,visit_id,event_type,visit_status,event_payload)
  values(v_visit.organization_id,v_visit.store_id,v_draft,v_visit.id,'paid',v_visit.status,
    coalesce(public.v1368_ai_visit_lifecycle_snapshot(v_visit.id),'{}'::jsonb)||jsonb_build_object('payment_id',new.id,'paid_at',new.paid_at));
  return new;
end;
$$;

drop trigger if exists v1368_ai_payment_lifecycle_trg on public.payments;
create trigger v1368_ai_payment_lifecycle_trg
after insert or update on public.payments
for each row execute function public.v1368_log_ai_payment_change();

-- Backfill one current snapshot for already-confirmed AI appointments so the
-- lifecycle audit is useful immediately after upgrading.
insert into public.whatsapp_ai_visit_lifecycle_events(
  organization_id,store_id,draft_id,visit_id,event_type,visit_status,event_payload,occurred_at
)
select d.organization_id,d.store_id,d.id,v.id,'upgrade_snapshot',v.status,
       coalesce(public.v1368_ai_visit_lifecycle_snapshot(v.id),'{}'::jsonb),now()
from public.whatsapp_ai_appointment_drafts d
join public.visits v on v.id=d.confirmed_visit_id and v.organization_id=d.organization_id and v.store_id=d.store_id
where d.confirmed_visit_id is not null
  and not exists(select 1 from public.whatsapp_ai_visit_lifecycle_events x where x.draft_id=d.id and x.event_type='upgrade_snapshot');

-- Seed/update pending reminder rows immediately. Actual sending is performed by
-- the scheduled Edge Function, never by SQL itself.
do $$ begin perform public.v1368_sync_reminder_queue(); end $$;

insert into public.salonos_system_meta(meta_key,meta_value)
values
 ('whatsapp_ai_lifecycle_version','13.6.8'),
 ('whatsapp_ai_customer_intelligence_version','13.6.8'),
 ('whatsapp_appointment_reminder_version','13.6.8')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.6.8 LIFECYCLE + INTELLIGENCE + REMINDER READY' as result,
  to_regprocedure('public.v1368_customer_intelligence(uuid,uuid,uuid)') is not null as customer_intelligence_ok,
  to_regprocedure('public.v1368_ai_prepare_customer_context(uuid)') is not null as search_customer_v1368_ok,
  to_regclass('public.whatsapp_appointment_reminders') is not null as reminder_queue_ok,
  to_regprocedure('public.v1368_claim_due_reminders(integer)') is not null as reminder_claim_ok,
  to_regclass('public.whatsapp_ai_visit_lifecycle_events') is not null as lifecycle_audit_ok,
  to_regprocedure('public.v1368_owner_save_whatsapp_reminder_config(uuid,boolean,integer,text,text,text)') is not null as reminder_settings_ok;
