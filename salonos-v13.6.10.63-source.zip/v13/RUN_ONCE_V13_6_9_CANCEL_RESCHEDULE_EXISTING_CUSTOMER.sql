-- SalonOS v13.6.9 · WhatsApp AI Cancel + Reschedule + Existing-Customer Continuity
-- Run AFTER v13.6.8 / v13.6.8.1. Additive / idempotent.
-- Safety rules:
--   * AI never mutates a booked appointment directly.
--   * Cancel/reschedule always goes through a durable change draft + explicit customer confirmation.
--   * Tenant/store/customer identity is derived from the verified queue + conversation, never from LLM-supplied IDs.
--   * Only future BOOKED appointments may be self-managed by WhatsApp AI.
--   * Reschedule final confirmation rechecks real SalonOS availability while ignoring the appointment being moved.
--   * Cancel/reschedule keeps appointment history; cancellation does not count as a completed visit.
--   * Reminder rows are cancelled/rebased together with the appointment mutation.

begin;
set local statement_timeout='0';

-- -----------------------------------------------------------------------------
-- Durable action draft / audit for EXISTING booked appointments.
-- -----------------------------------------------------------------------------
create table if not exists public.whatsapp_ai_appointment_change_drafts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  connection_id uuid not null references public.whatsapp_business_connections(id) on delete cascade,
  conversation_id uuid not null references public.whatsapp_conversations(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  customer_phone text not null,
  action_type text not null check(action_type in ('cancel','reschedule')),
  target_visit_id uuid not null references public.visits(id) on delete cascade,
  target_visit_number text,
  original_snapshot jsonb not null default '{}'::jsonb,
  requested_date date,
  requested_time time,
  requested_scheduled_at timestamptz,
  requested_time_period text not null default 'unspecified'
    check(requested_time_period in ('morning','afternoon','evening','night','unspecified')),
  status text not null default 'pending_confirmation'
    check(status in ('needs_selection','needs_time','needs_reschedule','pending_confirmation','confirmed','cancelled','expired','failed')),
  expires_at timestamptz not null default (now() + interval '20 minutes'),
  confirmed_at timestamptz,
  last_queue_id uuid references public.whatsapp_ai_queue(id) on delete set null,
  last_message_id uuid references public.whatsapp_messages(id) on delete set null,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);

create unique index if not exists whatsapp_ai_active_change_conversation_uidx
  on public.whatsapp_ai_appointment_change_drafts(conversation_id)
  where status in ('needs_selection','needs_time','needs_reschedule','pending_confirmation');
create index if not exists whatsapp_ai_change_target_idx
  on public.whatsapp_ai_appointment_change_drafts(organization_id,store_id,target_visit_id,updated_at desc);
create index if not exists whatsapp_ai_change_status_idx
  on public.whatsapp_ai_appointment_change_drafts(organization_id,store_id,status,expires_at);

create table if not exists public.whatsapp_ai_appointment_change_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  change_draft_id uuid references public.whatsapp_ai_appointment_change_drafts(id) on delete set null,
  target_visit_id uuid not null references public.visits(id) on delete cascade,
  queue_id uuid references public.whatsapp_ai_queue(id) on delete set null,
  message_id uuid references public.whatsapp_messages(id) on delete set null,
  event_type text not null,
  event_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade
);
create index if not exists whatsapp_ai_change_events_visit_idx
  on public.whatsapp_ai_appointment_change_events(target_visit_id,created_at desc);
create index if not exists whatsapp_ai_change_events_draft_idx
  on public.whatsapp_ai_appointment_change_events(change_draft_id,created_at desc);

alter table public.whatsapp_ai_appointment_change_drafts enable row level security;
alter table public.whatsapp_ai_appointment_change_events enable row level security;

drop policy if exists v1369_change_drafts_read on public.whatsapp_ai_appointment_change_drafts;
create policy v1369_change_drafts_read on public.whatsapp_ai_appointment_change_drafts
for select to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

drop policy if exists v1369_change_events_read on public.whatsapp_ai_appointment_change_events;
create policy v1369_change_events_read on public.whatsapp_ai_appointment_change_events
for select to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

grant select on public.whatsapp_ai_appointment_change_drafts,public.whatsapp_ai_appointment_change_events to authenticated;
grant all on public.whatsapp_ai_appointment_change_drafts,public.whatsapp_ai_appointment_change_events to service_role;
grant update on public.visits to service_role;

-- -----------------------------------------------------------------------------
-- Find only the WhatsApp customer's own FUTURE BOOKED appointments in the
-- verified Organization + Branch. Optional reference/date/time narrow the match.
-- -----------------------------------------------------------------------------
create or replace function public.v1369_ai_find_upcoming_appointments(
  p_queue_id uuid,
  p_reference text default null,
  p_date date default null,
  p_time_iso text default null
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_q public.whatsapp_ai_queue%rowtype;
  v_conv public.whatsapp_conversations%rowtype;
  v_phone text;
  v_ref text:=regexp_replace(lower(coalesce(p_reference,'')),'[^a-z0-9]','','g');
  v_time text:=nullif(trim(coalesce(p_time_iso,'')),'');
  v_candidates jsonb:='[]'::jsonb;
  v_count integer:=0;
begin
  select * into v_q from public.whatsapp_ai_queue where id=p_queue_id limit 1;
  if v_q.id is null then return jsonb_build_object('ok',false,'error','queue_not_found'); end if;
  select * into v_conv from public.whatsapp_conversations c
   where c.id=v_q.conversation_id and c.organization_id=v_q.organization_id and c.store_id=v_q.store_id
     and c.connection_id=v_q.connection_id limit 1;
  if v_conv.id is null then return jsonb_build_object('ok',false,'error','conversation_scope_mismatch'); end if;
  v_phone:=regexp_replace(coalesce(v_conv.customer_phone,''),'[^0-9]','','g');
  if v_phone='' then return jsonb_build_object('ok',false,'error','customer_phone_missing'); end if;
  if v_time is not null and v_time !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' then v_time:=null; end if;

  select coalesce(jsonb_agg(z.candidate order by z.scheduled_at),'[]'::jsonb),count(*)::integer
    into v_candidates,v_count
  from (
    select v.scheduled_at,
      jsonb_build_object(
        'visit_id',v.id,
        'visit_number',v.visit_number,
        'status',v.status,
        'scheduled_at',v.scheduled_at,
        'date',to_char(v.scheduled_at at time zone 'Asia/Kuala_Lumpur','YYYY-MM-DD'),
        'time',to_char(v.scheduled_at at time zone 'Asia/Kuala_Lumpur','HH24:MI'),
        'customer_id',vr.customer_id,
        'customer_name',vr.name_snapshot,
        'customer_phone',regexp_replace(coalesce(vr.phone_snapshot,''),'[^0-9]','','g'),
        'service_name',coalesce(meta.service_name,'预约服务'),
        'service_count',coalesce(meta.service_count,0),
        'duration_minutes',greatest(coalesce(meta.duration_minutes,30),1),
        'employee_id',emp.employee_id,
        'employee_name',emp.employee_name,
        'employee_count',coalesce(emp.employee_count,0),
        'can_self_reschedule',coalesce(emp.employee_count,0)=1
      ) as candidate
    from public.visits v
    join public.visit_recipients vr
      on vr.visit_id=v.id and vr.organization_id=v.organization_id and vr.recipient_type='primary'
    left join lateral (
      select
        string_agg(distinct si.service_name_snapshot,' + ' order by si.service_name_snapshot) as service_name,
        count(distinct si.id)::integer as service_count,
        sum(greatest(coalesce(si.estimated_minutes_snapshot,30),1))::integer as duration_minutes
      from public.visit_service_items si
      where si.organization_id=v.organization_id and si.store_id=v.store_id and si.visit_id=v.id
        and coalesce(si.status,'')<>'cancelled'
    ) meta on true
    left join lateral (
      select
        min(e.id::text)::uuid as employee_id,
        string_agg(distinct e.name,', ' order by e.name) as employee_name,
        count(distinct e.id)::integer as employee_count
      from public.visit_service_items si
      join public.visit_service_workers w
        on w.organization_id=si.organization_id and w.store_id=si.store_id and w.service_item_id=si.id and w.status='active'
      join public.employees e on e.id=w.employee_id and e.organization_id=w.organization_id
      where si.organization_id=v.organization_id and si.store_id=v.store_id and si.visit_id=v.id
        and coalesce(si.status,'')<>'cancelled'
    ) emp on true
    where v.organization_id=v_q.organization_id and v.store_id=v_q.store_id
      and v.visit_type='appointment' and v.status='booked' and v.scheduled_at>now()
      and regexp_replace(coalesce(vr.phone_snapshot,''),'[^0-9]','','g')=v_phone
      and (v_ref='' or regexp_replace(lower(coalesce(v.visit_number,'')),'[^a-z0-9]','','g') like '%'||v_ref||'%')
      and (p_date is null or (v.scheduled_at at time zone 'Asia/Kuala_Lumpur')::date=p_date)
      and (v_time is null or to_char(v.scheduled_at at time zone 'Asia/Kuala_Lumpur','HH24:MI')=v_time)
    order by v.scheduled_at
    limit 8
  ) z;

  return jsonb_build_object(
    'ok',true,
    'tool','find_upcoming_appointments',
    'tool_version','13.6.9',
    'resolution_status',case when v_count=0 then 'not_found' when v_count=1 then 'matched' else 'multiple' end,
    'match_count',v_count,
    'customer_phone',v_phone,
    'candidates',v_candidates,
    'appointment',case when v_count=1 then v_candidates->0 else null end
  );
end;
$$;
revoke all on function public.v1369_ai_find_upcoming_appointments(uuid,text,date,text) from public,anon,authenticated;
grant execute on function public.v1369_ai_find_upcoming_appointments(uuid,text,date,text) to service_role;

-- -----------------------------------------------------------------------------
-- Reschedule availability: keeps the original services and assigned employee,
-- but ignores the target appointment itself while calculating conflicts.
-- Complex multi-employee appointments are handed to staff rather than guessed.
-- -----------------------------------------------------------------------------
create or replace function public.v1369_ai_check_reschedule_availability(
  p_queue_id uuid,
  p_visit_id uuid,
  p_date date,
  p_time_iso text default null,
  p_time_period text default 'unspecified'
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_tenant jsonb;
  v_org uuid;
  v_store uuid;
  v_visit public.visits%rowtype;
  v_employee record;
  v_settings record;
  v_shift record;
  v_timezone text:='Asia/Kuala_Lumpur';
  v_interval integer:=30;
  v_notice integer:=30;
  v_max_days integer:=90;
  v_duration integer:=60;
  v_service_name text;
  v_employee_count integer:=0;
  v_shift_start timestamp;
  v_shift_end timestamp;
  v_break_start timestamp;
  v_break_end timestamp;
  v_window_start timestamp;
  v_window_end timestamp;
  v_exact timestamp;
  v_slot timestamp;
  v_slot_end timestamp;
  v_slots jsonb:='[]'::jsonb;
  v_busy boolean;
  v_now_local timestamp;
  v_count integer:=0;
  v_period text:=lower(coalesce(p_time_period,'unspecified'));
begin
  v_tenant:=public.v1365_ai_queue_tenant(p_queue_id);
  v_org:=(v_tenant->>'organization_id')::uuid;
  v_store:=(v_tenant->>'store_id')::uuid;

  select * into v_visit from public.visits v
   where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store
     and v.visit_type='appointment' limit 1;
  if v_visit.id is null then return jsonb_build_object('ok',false,'availability_status','invalid_appointment','slots','[]'::jsonb); end if;
  if v_visit.status<>'booked' or v_visit.scheduled_at<=now() then
    return jsonb_build_object('ok',true,'availability_status','appointment_not_modifiable','visit_status',v_visit.status,'slots','[]'::jsonb);
  end if;

  select
    coalesce(sum(greatest(coalesce(si.estimated_minutes_snapshot,30),1)),60)::integer,
    string_agg(distinct si.service_name_snapshot,' + ' order by si.service_name_snapshot)
  into v_duration,v_service_name
  from public.visit_service_items si
  where si.organization_id=v_org and si.store_id=v_store and si.visit_id=p_visit_id and coalesce(si.status,'')<>'cancelled';
  v_duration:=greatest(coalesce(v_duration,60),1);

  select count(distinct w.employee_id)::integer into v_employee_count
  from public.visit_service_items si
  join public.visit_service_workers w
    on w.organization_id=si.organization_id and w.store_id=si.store_id and w.service_item_id=si.id and w.status='active'
  where si.organization_id=v_org and si.store_id=v_store and si.visit_id=p_visit_id and coalesce(si.status,'')<>'cancelled';
  if coalesce(v_employee_count,0)<>1 then
    return jsonb_build_object('ok',true,'availability_status','complex_booking_requires_human','employee_count',coalesce(v_employee_count,0),'slots','[]'::jsonb);
  end if;

  select e.id,e.name,e.availability_status,e.employment_status into v_employee
  from public.visit_service_items si
  join public.visit_service_workers w
    on w.organization_id=si.organization_id and w.store_id=si.store_id and w.service_item_id=si.id and w.status='active'
  join public.employees e on e.id=w.employee_id and e.organization_id=w.organization_id
  where si.organization_id=v_org and si.store_id=v_store and si.visit_id=p_visit_id
    and coalesce(si.status,'')<>'cancelled' and e.employment_status='active'
    and exists(select 1 from public.employee_stores es where es.organization_id=v_org and es.store_id=v_store and es.employee_id=e.id and es.status='active')
  limit 1;
  if v_employee.id is null then return jsonb_build_object('ok',true,'availability_status','invalid_staff','slots','[]'::jsonb); end if;

  select * into v_settings from public.whatsapp_ai_booking_settings b
   where b.organization_id=v_org and b.store_id=v_store and b.active=true;
  if v_settings.id is not null then
    v_timezone:=coalesce(nullif(v_settings.timezone,''),'Asia/Kuala_Lumpur');
    v_interval:=greatest(coalesce(v_settings.slot_interval_minutes,30),5);
    v_notice:=greatest(coalesce(v_settings.minimum_notice_minutes,30),0);
    v_max_days:=greatest(coalesce(v_settings.max_booking_days_ahead,90),1);
  end if;

  v_now_local:=now() at time zone v_timezone;
  if p_date is null then return jsonb_build_object('ok',true,'availability_status','missing_date','slots','[]'::jsonb); end if;
  if p_date<v_now_local::date then return jsonb_build_object('ok',true,'availability_status','date_in_past','slots','[]'::jsonb); end if;
  if p_date>(v_now_local::date+v_max_days) then
    return jsonb_build_object('ok',true,'availability_status','date_too_far','max_booking_days_ahead',v_max_days,'slots','[]'::jsonb);
  end if;

  select * into v_shift from public.whatsapp_ai_employee_schedules x
   where x.organization_id=v_org and x.store_id=v_store and x.employee_id=v_employee.id
     and x.iso_weekday=extract(isodow from p_date)::int;
  if v_shift.id is null then
    return jsonb_build_object('ok',true,'availability_status','schedule_unconfigured','schedule_required',true,
      'employee',jsonb_build_object('id',v_employee.id,'name',v_employee.name),'date',p_date,'slots','[]'::jsonb);
  end if;
  if not coalesce(v_shift.is_working,false) then return jsonb_build_object('ok',true,'availability_status','employee_off','date',p_date,'slots','[]'::jsonb); end if;
  if v_shift.start_time is null or v_shift.end_time is null then return jsonb_build_object('ok',true,'availability_status','schedule_invalid','slots','[]'::jsonb); end if;

  v_interval:=greatest(coalesce(v_shift.slot_interval_minutes,v_interval),5);
  v_shift_start:=p_date::timestamp+v_shift.start_time;
  v_shift_end:=p_date::timestamp+v_shift.end_time;
  if v_shift_end<=v_shift_start then v_shift_end:=v_shift_end+interval '1 day'; end if;
  if v_shift.break_start is not null and v_shift.break_end is not null then
    v_break_start:=p_date::timestamp+v_shift.break_start;
    v_break_end:=p_date::timestamp+v_shift.break_end;
    if v_break_end<=v_break_start then v_break_end:=v_break_end+interval '1 day'; end if;
  end if;

  v_window_start:=v_shift_start; v_window_end:=v_shift_end;
  if v_period='morning' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '06:00'); v_window_end:=least(v_window_end,p_date::timestamp+time '12:00');
  elsif v_period='afternoon' then
    -- v13.6.9 follows the corrected conversational definition: 13:00-18:00.
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '13:00'); v_window_end:=least(v_window_end,p_date::timestamp+time '18:00');
  elsif v_period='evening' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '18:00'); v_window_end:=least(v_window_end,p_date::timestamp+time '22:00');
  elsif v_period='night' then
    v_window_start:=greatest(v_window_start,p_date::timestamp+time '22:00');
  end if;

  if nullif(trim(coalesce(p_time_iso,'')),'') is not null then
    if trim(p_time_iso)!~'^([01][0-9]|2[0-3]):[0-5][0-9]$' then return jsonb_build_object('ok',true,'availability_status','invalid_time','slots','[]'::jsonb); end if;
    v_exact:=p_date::timestamp+trim(p_time_iso)::time;
    v_window_start:=v_exact; v_window_end:=v_exact+make_interval(mins=>v_duration);
  end if;
  if v_window_end<=v_window_start or v_window_start+make_interval(mins=>v_duration)>v_shift_end then
    return jsonb_build_object('ok',true,'availability_status','outside_shift','date',p_date,'slots','[]'::jsonb);
  end if;

  v_slot:=v_window_start;
  while v_slot+make_interval(mins=>v_duration)<=v_window_end loop
    v_slot_end:=v_slot+make_interval(mins=>v_duration);
    if v_slot<v_now_local+make_interval(mins=>v_notice) then v_slot:=v_slot+make_interval(mins=>v_interval); continue; end if;
    if v_break_start is not null and v_break_end is not null and v_slot<v_break_end and v_slot_end>v_break_start then
      v_slot:=v_slot+make_interval(mins=>v_interval); continue;
    end if;

    select exists(
      select 1 from public.visits v
      where v.organization_id=v_org and v.store_id=v_store and v.id<>p_visit_id
        and v.status in ('booked','arrived','waiting','in_service','paused','ready_for_checkout')
        and exists(
          select 1 from public.visit_service_items si
          join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
          where si.visit_id=v.id and si.organization_id=v_org and si.status<>'cancelled' and w.employee_id=v_employee.id
        )
        and (coalesce(v.scheduled_at,v.started_at,v.created_at) at time zone v_timezone)<v_slot_end
        and ((coalesce(v.scheduled_at,v.started_at,v.created_at) at time zone v_timezone)
          +make_interval(mins=>greatest(30,coalesce((
            select sum(greatest(coalesce(si2.estimated_minutes_snapshot,30),1))::int
            from public.visit_service_items si2
            where si2.visit_id=v.id and si2.organization_id=v_org and si2.status<>'cancelled'
          ),30))))>v_slot
    ) into v_busy;

    if not v_busy then
      v_slots:=v_slots||jsonb_build_array(jsonb_build_object(
        'time',to_char(v_slot,'HH24:MI'),'start_local',to_char(v_slot,'YYYY-MM-DD"T"HH24:MI:SS'),
        'end_local',to_char(v_slot_end,'YYYY-MM-DD"T"HH24:MI:SS'),'duration_minutes',v_duration
      ));
      v_count:=v_count+1; if v_count>=12 then exit; end if;
    end if;
    if v_exact is not null then exit; end if;
    v_slot:=v_slot+make_interval(mins=>v_interval);
  end loop;

  return jsonb_build_object(
    'ok',true,'tool','check_reschedule_availability','tool_version','13.6.9',
    'availability_status',case when jsonb_array_length(v_slots)>0 then 'available' else 'no_slots' end,
    'target_visit_id',p_visit_id,'visit_number',v_visit.visit_number,'date',p_date,'timezone',v_timezone,
    'service_name',coalesce(v_service_name,'预约服务'),'duration_minutes',v_duration,
    'employee',jsonb_build_object('id',v_employee.id,'name',v_employee.name),
    'shift',jsonb_build_object('start',to_char(v_shift.start_time,'HH24:MI'),'end',to_char(v_shift.end_time,'HH24:MI'),
      'break_start',case when v_shift.break_start is null then null else to_char(v_shift.break_start,'HH24:MI') end,
      'break_end',case when v_shift.break_end is null then null else to_char(v_shift.break_end,'HH24:MI') end),
    'slot_interval_minutes',v_interval,'slots',v_slots
  );
end;
$$;
revoke all on function public.v1369_ai_check_reschedule_availability(uuid,uuid,date,text,text) from public,anon,authenticated;
grant execute on function public.v1369_ai_check_reschedule_availability(uuid,uuid,date,text,text) to service_role;

-- -----------------------------------------------------------------------------
-- Prepare or refresh a change draft. Cancel only needs the target appointment;
-- reschedule needs an exact backend-verified new date+time before confirmation.
-- -----------------------------------------------------------------------------
create or replace function public.v1369_ai_prepare_change_draft(
  p_queue_id uuid,
  p_action_type text,
  p_visit_id uuid,
  p_date date default null,
  p_time_iso text default null,
  p_time_period text default 'unspecified'
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_q public.whatsapp_ai_queue%rowtype;
  v_conv public.whatsapp_conversations%rowtype;
  v_visit public.visits%rowtype;
  v_customer_id uuid;
  v_phone text;
  v_action text:=lower(trim(coalesce(p_action_type,'')));
  v_date date:=p_date;
  v_time time;
  v_sched timestamptz;
  v_availability jsonb;
  v_snapshot jsonb;
  v_draft public.whatsapp_ai_appointment_change_drafts%rowtype;
  v_service_name text;
  v_employee_name text;
  v_duration integer:=60;
  v_status text;
begin
  if v_action not in ('cancel','reschedule') then return jsonb_build_object('ok',false,'error','invalid_action_type'); end if;
  select * into v_q from public.whatsapp_ai_queue where id=p_queue_id limit 1;
  if v_q.id is null then return jsonb_build_object('ok',false,'error','queue_not_found'); end if;
  select * into v_conv from public.whatsapp_conversations c
   where c.id=v_q.conversation_id and c.organization_id=v_q.organization_id and c.store_id=v_q.store_id and c.connection_id=v_q.connection_id limit 1;
  if v_conv.id is null then return jsonb_build_object('ok',false,'error','conversation_scope_mismatch'); end if;
  v_phone:=regexp_replace(coalesce(v_conv.customer_phone,''),'[^0-9]','','g');

  select v.* into v_visit from public.visits v
  where v.id=p_visit_id and v.organization_id=v_q.organization_id and v.store_id=v_q.store_id
    and v.visit_type='appointment'
    and exists(select 1 from public.visit_recipients vr where vr.visit_id=v.id and vr.organization_id=v.organization_id
      and vr.recipient_type='primary' and regexp_replace(coalesce(vr.phone_snapshot,''),'[^0-9]','','g')=v_phone)
  limit 1;
  if v_visit.id is null then return jsonb_build_object('ok',false,'error','appointment_not_owned_by_conversation'); end if;
  if v_visit.status<>'booked' or v_visit.scheduled_at<=now() then
    return jsonb_build_object('ok',false,'error','appointment_not_modifiable','visit_status',v_visit.status);
  end if;

  select vr.customer_id into v_customer_id from public.visit_recipients vr
   where vr.visit_id=v_visit.id and vr.organization_id=v_visit.organization_id and vr.recipient_type='primary' limit 1;
  select string_agg(distinct si.service_name_snapshot,' + ' order by si.service_name_snapshot),
         coalesce(sum(greatest(coalesce(si.estimated_minutes_snapshot,30),1)),60)::integer
    into v_service_name,v_duration
  from public.visit_service_items si
  where si.organization_id=v_visit.organization_id and si.store_id=v_visit.store_id and si.visit_id=v_visit.id and coalesce(si.status,'')<>'cancelled';
  select string_agg(distinct e.name,', ' order by e.name) into v_employee_name
  from public.visit_service_items si
  join public.visit_service_workers w on w.organization_id=si.organization_id and w.store_id=si.store_id and w.service_item_id=si.id and w.status='active'
  join public.employees e on e.id=w.employee_id and e.organization_id=w.organization_id
  where si.organization_id=v_visit.organization_id and si.store_id=v_visit.store_id and si.visit_id=v_visit.id and coalesce(si.status,'')<>'cancelled';

  v_snapshot:=jsonb_build_object(
    'visit_id',v_visit.id,'visit_number',v_visit.visit_number,'status',v_visit.status,'scheduled_at',v_visit.scheduled_at,
    'date',to_char(v_visit.scheduled_at at time zone 'Asia/Kuala_Lumpur','YYYY-MM-DD'),
    'time',to_char(v_visit.scheduled_at at time zone 'Asia/Kuala_Lumpur','HH24:MI'),
    'service_name',coalesce(v_service_name,'预约服务'),'employee_name',coalesce(v_employee_name,'理发师'),
    'duration_minutes',greatest(coalesce(v_duration,60),1)
  );

  if v_action='reschedule' then
    if v_date is null then v_date:=(v_visit.scheduled_at at time zone 'Asia/Kuala_Lumpur')::date; end if;
    if nullif(trim(coalesce(p_time_iso,'')),'') is null or trim(p_time_iso)!~'^([01][0-9]|2[0-3]):[0-5][0-9]$' then
      return jsonb_build_object('ok',false,'error','new_time_required','appointment',v_snapshot,'date',v_date);
    end if;
    v_time:=trim(p_time_iso)::time;
    v_availability:=public.v1369_ai_check_reschedule_availability(p_queue_id,p_visit_id,v_date,to_char(v_time,'HH24:MI'),coalesce(p_time_period,'unspecified'));
    if coalesce(v_availability->>'availability_status','')<>'available'
       or not exists(select 1 from jsonb_array_elements(coalesce(v_availability->'slots','[]'::jsonb)) x where x->>'time'=to_char(v_time,'HH24:MI')) then
      return jsonb_build_object('ok',false,'error','slot_not_available','appointment',v_snapshot,'availability',v_availability);
    end if;
    v_sched:=(v_date+v_time) at time zone 'Asia/Kuala_Lumpur';
    v_status:='pending_confirmation';
  else
    v_date:=null; v_time:=null; v_sched:=null; v_status:='pending_confirmation';
  end if;

  select * into v_draft from public.whatsapp_ai_appointment_change_drafts d
   where d.organization_id=v_q.organization_id and d.store_id=v_q.store_id and d.conversation_id=v_q.conversation_id
     and d.status in ('needs_selection','needs_time','needs_reschedule','pending_confirmation')
   order by d.updated_at desc limit 1;
  if v_draft.id is null then
    insert into public.whatsapp_ai_appointment_change_drafts(
      organization_id,store_id,connection_id,conversation_id,customer_id,customer_phone,action_type,target_visit_id,target_visit_number,
      original_snapshot,requested_date,requested_time,requested_scheduled_at,requested_time_period,status,expires_at,last_queue_id,last_message_id,updated_at
    ) values(
      v_q.organization_id,v_q.store_id,v_q.connection_id,v_q.conversation_id,v_customer_id,v_phone,v_action,v_visit.id,v_visit.visit_number,
      v_snapshot,v_date,v_time,v_sched,coalesce(nullif(lower(trim(p_time_period)),''),'unspecified'),v_status,now()+interval '20 minutes',v_q.id,v_q.message_id,now()
    ) returning * into v_draft;
  else
    update public.whatsapp_ai_appointment_change_drafts d set
      customer_id=coalesce(v_customer_id,d.customer_id),customer_phone=v_phone,action_type=v_action,target_visit_id=v_visit.id,target_visit_number=v_visit.visit_number,
      original_snapshot=v_snapshot,requested_date=v_date,requested_time=v_time,requested_scheduled_at=v_sched,
      requested_time_period=coalesce(nullif(lower(trim(p_time_period)),''),'unspecified'),status=v_status,expires_at=now()+interval '20 minutes',
      last_queue_id=v_q.id,last_message_id=v_q.message_id,last_error=null,updated_at=now()
    where d.id=v_draft.id returning * into v_draft;
  end if;

  insert into public.whatsapp_ai_appointment_change_events(organization_id,store_id,change_draft_id,target_visit_id,queue_id,message_id,event_type,event_payload)
  values(v_q.organization_id,v_q.store_id,v_draft.id,v_visit.id,v_q.id,v_q.message_id,'change_draft_prepared',jsonb_build_object(
    'action_type',v_action,'original',v_snapshot,'requested_date',v_date,'requested_time',case when v_time is null then null else to_char(v_time,'HH24:MI') end,
    'requested_scheduled_at',v_sched,'availability',coalesce(v_availability,'{}'::jsonb)
  ));

  return jsonb_build_object(
    'ok',true,'status',v_draft.status,'draft_id',v_draft.id,'action_type',v_action,
    'appointment',v_snapshot,
    'requested',case when v_action='reschedule' then jsonb_build_object('date',v_date,'time',to_char(v_time,'HH24:MI'),'scheduled_at',v_sched,'time_period',v_draft.requested_time_period) else null end,
    'expires_at',v_draft.expires_at
  );
end;
$$;
revoke all on function public.v1369_ai_prepare_change_draft(uuid,text,uuid,date,text,text) from public,anon,authenticated;
grant execute on function public.v1369_ai_prepare_change_draft(uuid,text,uuid,date,text,text) to service_role;

create or replace function public.v1369_ai_cancel_change_draft(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_q public.whatsapp_ai_queue%rowtype; v_draft public.whatsapp_ai_appointment_change_drafts%rowtype;
begin
  select * into v_q from public.whatsapp_ai_queue where id=p_queue_id limit 1;
  if v_q.id is null then return jsonb_build_object('ok',false,'error','queue_not_found'); end if;
  select * into v_draft from public.whatsapp_ai_appointment_change_drafts d
   where d.organization_id=v_q.organization_id and d.store_id=v_q.store_id and d.conversation_id=v_q.conversation_id
     and d.status in ('needs_selection','needs_time','needs_reschedule','pending_confirmation')
   order by d.updated_at desc limit 1;
  if v_draft.id is null then return jsonb_build_object('ok',true,'status','no_active_change_draft'); end if;
  update public.whatsapp_ai_appointment_change_drafts set status='cancelled',last_queue_id=v_q.id,last_message_id=v_q.message_id,updated_at=now()
   where id=v_draft.id returning * into v_draft;
  insert into public.whatsapp_ai_appointment_change_events(organization_id,store_id,change_draft_id,target_visit_id,queue_id,message_id,event_type,event_payload)
  values(v_q.organization_id,v_q.store_id,v_draft.id,v_draft.target_visit_id,v_q.id,v_q.message_id,'change_draft_cancelled',jsonb_build_object('action_type',v_draft.action_type));
  return jsonb_build_object('ok',true,'status','cancelled','draft_id',v_draft.id,'action_type',v_draft.action_type);
end;
$$;
revoke all on function public.v1369_ai_cancel_change_draft(uuid) from public,anon,authenticated;
grant execute on function public.v1369_ai_cancel_change_draft(uuid) to service_role;

-- -----------------------------------------------------------------------------
-- Final mutation. Only this backend RPC may cancel/reschedule an existing visit.
-- -----------------------------------------------------------------------------
create or replace function public.v1369_ai_confirm_change(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_q public.whatsapp_ai_queue%rowtype;
  v_conv public.whatsapp_conversations%rowtype;
  v_draft public.whatsapp_ai_appointment_change_drafts%rowtype;
  v_visit public.visits%rowtype;
  v_phone text;
  v_emp uuid;
  v_availability jsonb;
  v_alternatives jsonb;
  v_old timestamptz;
  v_note text;
begin
  select * into v_q from public.whatsapp_ai_queue where id=p_queue_id limit 1;
  if v_q.id is null then return jsonb_build_object('ok',false,'error','queue_not_found'); end if;
  select * into v_conv from public.whatsapp_conversations c
   where c.id=v_q.conversation_id and c.organization_id=v_q.organization_id and c.store_id=v_q.store_id and c.connection_id=v_q.connection_id limit 1;
  if v_conv.id is null then return jsonb_build_object('ok',false,'error','conversation_scope_mismatch'); end if;
  v_phone:=regexp_replace(coalesce(v_conv.customer_phone,''),'[^0-9]','','g');

  select * into v_draft from public.whatsapp_ai_appointment_change_drafts d
   where d.organization_id=v_q.organization_id and d.store_id=v_q.store_id and d.conversation_id=v_q.conversation_id
     and d.status='pending_confirmation'
   order by d.updated_at desc limit 1 for update;
  if v_draft.id is null then return jsonb_build_object('ok',false,'error','change_draft_not_found'); end if;
  if v_draft.expires_at<=now() then
    update public.whatsapp_ai_appointment_change_drafts set status='expired',updated_at=now() where id=v_draft.id;
    return jsonb_build_object('ok',false,'error','change_draft_expired','draft_id',v_draft.id);
  end if;

  select * into v_visit from public.visits v
   where v.id=v_draft.target_visit_id and v.organization_id=v_q.organization_id and v.store_id=v_q.store_id
     and v.visit_type='appointment'
     and exists(select 1 from public.visit_recipients vr where vr.visit_id=v.id and vr.organization_id=v.organization_id and vr.recipient_type='primary'
       and regexp_replace(coalesce(vr.phone_snapshot,''),'[^0-9]','','g')=v_phone)
   limit 1 for update;
  if v_visit.id is null then return jsonb_build_object('ok',false,'error','appointment_scope_mismatch','draft_id',v_draft.id); end if;
  if v_visit.status<>'booked' or v_visit.scheduled_at<=now() then
    return jsonb_build_object('ok',false,'error','appointment_no_longer_modifiable','visit_status',v_visit.status,'draft_id',v_draft.id);
  end if;
  v_old:=v_visit.scheduled_at;

  if v_draft.action_type='cancel' then
    v_note:=concat_ws(E'\n',nullif(v_visit.notes,''),'WhatsApp AI customer cancellation · Change Draft '||v_draft.id::text);
    update public.visits set status='cancelled',notes=v_note,updated_at=now()
     where id=v_visit.id and organization_id=v_q.organization_id and store_id=v_q.store_id;

    if to_regclass('public.whatsapp_appointment_reminders') is not null then
      update public.whatsapp_appointment_reminders set status='skipped',last_error='appointment_cancelled_by_customer',updated_at=now()
       where visit_id=v_visit.id and organization_id=v_q.organization_id and store_id=v_q.store_id
         and status in ('pending','processing','failed','template_required');
    end if;

    update public.whatsapp_ai_appointment_change_drafts set status='confirmed',confirmed_at=now(),last_queue_id=v_q.id,last_message_id=v_q.message_id,updated_at=now()
     where id=v_draft.id returning * into v_draft;
    insert into public.whatsapp_ai_appointment_change_events(organization_id,store_id,change_draft_id,target_visit_id,queue_id,message_id,event_type,event_payload)
    values(v_q.organization_id,v_q.store_id,v_draft.id,v_visit.id,v_q.id,v_q.message_id,'appointment_cancelled',jsonb_build_object(
      'visit_number',v_visit.visit_number,'scheduled_at',v_old,'customer_phone',v_phone
    ));
    return jsonb_build_object('ok',true,'status','cancelled','action_type','cancel','draft_id',v_draft.id,
      'visit_id',v_visit.id,'visit_number',v_visit.visit_number,'original_scheduled_at',v_old,'appointment',v_draft.original_snapshot);
  end if;

  if v_draft.action_type<>'reschedule' or v_draft.requested_date is null or v_draft.requested_time is null or v_draft.requested_scheduled_at is null then
    return jsonb_build_object('ok',false,'error','reschedule_target_incomplete','draft_id',v_draft.id);
  end if;

  select w.employee_id into v_emp
  from public.visit_service_items si
  join public.visit_service_workers w on w.organization_id=si.organization_id and w.store_id=si.store_id and w.service_item_id=si.id and w.status='active'
  where si.organization_id=v_q.organization_id and si.store_id=v_q.store_id and si.visit_id=v_visit.id and coalesce(si.status,'')<>'cancelled'
  limit 1;
  if v_emp is not null then
    perform pg_advisory_xact_lock(hashtextextended(v_q.organization_id::text||':'||v_q.store_id::text||':'||v_emp::text||':'||v_draft.requested_date::text,0));
  end if;

  v_availability:=public.v1369_ai_check_reschedule_availability(
    p_queue_id,v_visit.id,v_draft.requested_date,to_char(v_draft.requested_time,'HH24:MI'),v_draft.requested_time_period
  );
  if coalesce(v_availability->>'availability_status','')<>'available'
     or not exists(select 1 from jsonb_array_elements(coalesce(v_availability->'slots','[]'::jsonb)) x where x->>'time'=to_char(v_draft.requested_time,'HH24:MI')) then
    v_alternatives:=public.v1369_ai_check_reschedule_availability(p_queue_id,v_visit.id,v_draft.requested_date,null,v_draft.requested_time_period);
    update public.whatsapp_ai_appointment_change_drafts set status='needs_reschedule',last_error='slot_no_longer_available',last_queue_id=v_q.id,last_message_id=v_q.message_id,updated_at=now()
     where id=v_draft.id returning * into v_draft;
    insert into public.whatsapp_ai_appointment_change_events(organization_id,store_id,change_draft_id,target_visit_id,queue_id,message_id,event_type,event_payload)
    values(v_q.organization_id,v_q.store_id,v_draft.id,v_visit.id,v_q.id,v_q.message_id,'reschedule_slot_unavailable',jsonb_build_object('availability',v_availability,'alternatives',v_alternatives));
    return jsonb_build_object('ok',false,'error','slot_no_longer_available','draft_id',v_draft.id,'availability',v_availability,'alternatives',v_alternatives);
  end if;

  v_note:=concat_ws(E'\n',nullif(v_visit.notes,''),'WhatsApp AI customer reschedule · Change Draft '||v_draft.id::text||' · From '||v_old::text);
  update public.visits set scheduled_at=v_draft.requested_scheduled_at,notes=v_note,updated_at=now()
   where id=v_visit.id and organization_id=v_q.organization_id and store_id=v_q.store_id;

  -- A moved appointment needs a fresh reminder at the new time, even if an old reminder was already sent.
  if to_regclass('public.whatsapp_appointment_reminders') is not null then
    update public.whatsapp_appointment_reminders set
      scheduled_at=v_draft.requested_scheduled_at,
      due_at=v_draft.requested_scheduled_at-make_interval(mins=>reminder_minutes_before),
      status='pending',send_mode=null,attempts=0,meta_message_id=null,outbound_message_id=null,last_error=null,sent_at=null,updated_at=now()
    where visit_id=v_visit.id and organization_id=v_q.organization_id and store_id=v_q.store_id;
  end if;
  if to_regprocedure('public.v1368_sync_reminder_queue()') is not null then perform public.v1368_sync_reminder_queue(); end if;

  update public.whatsapp_ai_appointment_change_drafts set status='confirmed',confirmed_at=now(),last_queue_id=v_q.id,last_message_id=v_q.message_id,last_error=null,updated_at=now()
   where id=v_draft.id returning * into v_draft;
  insert into public.whatsapp_ai_appointment_change_events(organization_id,store_id,change_draft_id,target_visit_id,queue_id,message_id,event_type,event_payload)
  values(v_q.organization_id,v_q.store_id,v_draft.id,v_visit.id,v_q.id,v_q.message_id,'appointment_rescheduled',jsonb_build_object(
    'visit_number',v_visit.visit_number,'old_scheduled_at',v_old,'new_scheduled_at',v_draft.requested_scheduled_at,'customer_phone',v_phone
  ));
  return jsonb_build_object(
    'ok',true,'status','rescheduled','action_type','reschedule','draft_id',v_draft.id,'visit_id',v_visit.id,'visit_number',v_visit.visit_number,
    'old_scheduled_at',v_old,'new_scheduled_at',v_draft.requested_scheduled_at,
    'appointment',v_draft.original_snapshot,
    'requested',jsonb_build_object('date',v_draft.requested_date,'time',to_char(v_draft.requested_time,'HH24:MI'),'scheduled_at',v_draft.requested_scheduled_at)
  );
exception when others then
  if v_draft.id is not null then
    begin
      update public.whatsapp_ai_appointment_change_drafts set status='failed',last_error=sqlerrm,updated_at=now() where id=v_draft.id;
      insert into public.whatsapp_ai_appointment_change_events(organization_id,store_id,change_draft_id,target_visit_id,queue_id,message_id,event_type,event_payload)
      values(v_q.organization_id,v_q.store_id,v_draft.id,v_draft.target_visit_id,v_q.id,v_q.message_id,'change_confirm_failed',jsonb_build_object('error',sqlerrm));
    exception when others then null; end;
  end if;
  raise;
end;
$$;
revoke all on function public.v1369_ai_confirm_change(uuid) from public,anon,authenticated;
grant execute on function public.v1369_ai_confirm_change(uuid) to service_role;

-- -----------------------------------------------------------------------------
-- Existing-customer continuity helper: returns safe preference suggestions only.
-- It NEVER changes an appointment by itself and never infers sensitive attributes.
-- -----------------------------------------------------------------------------
create or replace function public.v1369_ai_existing_customer_preferences(p_queue_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_ctx jsonb; v_intel jsonb; v_dom jsonb;
begin
  v_ctx:=public.v1368_ai_prepare_customer_context(p_queue_id);
  v_intel:=coalesce(v_ctx->'customer_intelligence','{}'::jsonb);
  v_dom:=coalesce(v_intel->'dominant_stylist','{}'::jsonb);
  return jsonb_build_object(
    'ok',true,
    'customer_status',coalesce(v_ctx->>'customer_status','unknown'),
    'segment',coalesce(v_ctx->>'customer_segment','new_lead'),
    'completed_visit_count',coalesce((v_intel->>'completed_visit_count')::integer,0),
    'favourite_service',v_intel->>'favourite_service',
    'dominant_stylist',case when nullif(v_dom->>'name','') is null then null else v_dom end,
    'policy','preference_suggestion_only_no_silent_mutation'
  );
end;
$$;
revoke all on function public.v1369_ai_existing_customer_preferences(uuid) from public,anon,authenticated;
grant execute on function public.v1369_ai_existing_customer_preferences(uuid) to service_role;

insert into public.salonos_system_meta(meta_key,meta_value)
values
 ('whatsapp_ai_cancel_reschedule_version','13.6.9'),
 ('whatsapp_ai_existing_customer_continuity_version','13.6.9'),
 ('whatsapp_ai_change_confirmation_policy','explicit_customer_confirmation'),
 ('whatsapp_ai_change_scope_policy','future_booked_same_branch_same_phone'),
 ('whatsapp_ai_reschedule_reminder_rebase_version','13.6.9')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.6.9 CANCEL + RESCHEDULE + EXISTING CUSTOMER READY' as result,
  to_regclass('public.whatsapp_ai_appointment_change_drafts') is not null as change_draft_ok,
  to_regclass('public.whatsapp_ai_appointment_change_events') is not null as change_audit_ok,
  to_regprocedure('public.v1369_ai_find_upcoming_appointments(uuid,text,date,text)') is not null as find_appointments_ok,
  to_regprocedure('public.v1369_ai_check_reschedule_availability(uuid,uuid,date,text,text)') is not null as reschedule_availability_ok,
  to_regprocedure('public.v1369_ai_prepare_change_draft(uuid,text,uuid,date,text,text)') is not null as prepare_change_ok,
  to_regprocedure('public.v1369_ai_confirm_change(uuid)') is not null as confirm_change_ok,
  to_regprocedure('public.v1369_ai_cancel_change_draft(uuid)') is not null as cancel_change_draft_ok,
  to_regprocedure('public.v1369_ai_existing_customer_preferences(uuid)') is not null as existing_customer_preferences_ok;
