

## v13.6.10.60
- Reverted v13.6.10.59 aggressive Service Worker/cache-first performance changes that could mix stale CSS/JS with new HTML and break UI rendering.
- Restored stable v13.6.10.58 static asset loading/i18n behavior.
- Kept in-page category filtering for Services, Inventory, Sales Products and Product Bundles without page reload.
- No UI visual redesign.
## v13.6.10.59 — Navigation Performance + Instant Category Filters

- Kept the current SalonOS visual UI unchanged.
- Static PWA assets are served cache-first from a release-specific cache instead of being re-downloaded with `no-store` on every page transition.
- Navigation Preload reduces Service Worker startup delay for dynamic page requests without caching business HTML.
- Services / Inventory / Sales Products / Product Bundles category switching now filters cards in place with no page reload.
- No SQL and no Edge Function redeploy required.


## v13.6.10.58 — WhatsApp explicit stylist-choice guard

Completed:
- Service/date/time completion no longer authorizes silent system assignment.
- The worker asks whether the customer wants a named stylist or system assignment before checking availability or creating a draft.
- Only explicit phrases such as `系统安排`, `system assign`, `no preference` or `sistem aturkan` authorize the qualified system-assignment path.
- Generic choose-stylist replies abandon an existing unconfirmed draft, clear the old employee/availability state, preserve service/date/time and ask for the stylist name.
- Employee names copied by the model from an older draft are rejected unless the name appears in the latest customer message or is carried from the trusted active transaction.
- Chinese, English and Bahasa Melayu choice/name prompts are context-aware.

Deployment:
- No SQL.
- Redeploy only `supabase/functions/whatsapp-ai-worker/index.ts`.
- All other Edge Functions remain byte-for-byte unchanged from v13.6.10.56.

## v13.6.10.57 — WhatsApp context-aware slot filling

Completed:
- Price/service/staff enquiry context can be promoted into a booking when the customer answers with a short date/time slot.
- Time-only replies fill `time_text/time_iso` without inventing or overwriting `date_text/date_iso`.
- Previously known service and stylist slots survive the continuation; customer-explicit date provenance is retained across factual enquiries.
- Missing-date replies acknowledge the exact time in Chinese, English or Malay and ask only for the date.
- When service + trusted date + exact time are complete and no stylist was named, the existing qualified system-assignment availability path runs directly.
- Numeric clock tokens such as `7pm` inherit the preceding customer language.

Deployment:
- No SQL.
- Redeploy only `supabase/functions/whatsapp-ai-worker/index.ts`.
- All other Edge Functions remain byte-for-byte unchanged from v13.6.10.56.

## v13.6.10.55
Social Inbox tutorial UI + manual source capture.
## v13.6.10.51
Completed: granular settings visibility, role-list modal editor, per-user UI language.

## v13.6.10.37 — WhatsApp Setup UX / Beginner Wizard
Direction:
- Keep the v13.6.10.36 Manual Multi-App backend unchanged.
- Redesign Settings -> WhatsApp Business for non-technical salon owners.

Implemented:
- Beginner-first connection dashboard with clear current status.
- Two connection method cards: Manual Setup now / Connect with Meta later.
- Manual Cloud API onboarding changed into a 5-step wizard.
- Technical instructions moved into tutorial modal windows.
- Separate tutorials for App ID, App Secret, WABA + Phone Number ID, System User Token, and Webhook setup.
- Existing connection page simplified to daily AI/remainder controls.
- Raw Phone ID / WABA / token rotation / template settings moved under Advanced Settings.
- Diagnostics and Webhook URL moved under a collapsed developer section.
- Connected owners no longer land on a wall of technical fields.
- Mobile layout updated for the onboarding wizard and tutorial modals.

Deployment:
1. Upload full v13.6.10.37 over v13.6.10.36.
2. No SQL migration required.
3. No Edge Function re-deploy required.
4. v13.6.10.36 Manual Connect / Webhook / AI worker backend remains unchanged.

Next validation milestone:
- Use a non-technical test owner to complete Manual Setup using only the in-product tutorial modals.

## v13.6.10.36 — Customer-Owned Meta App Manual Cloud API Connect
Direction:
- Keep Embedded Signup as the eventual one-click SaaS onboarding path.
- Until SalonOS can complete Meta Tech Provider verification, allow real customers to connect their own Cloud API stack manually.

Implemented:
- New Manual Cloud API Setup wizard for customer-owned Meta Apps.
- Meta credential/token/app ownership validation.
- WABA/Phone Number ownership validation and `subscribed_apps` subscription.
- Per-customer Meta App Secret storage in service-role-only `whatsapp_connection_secrets`.
- One-time Verify Token generation with only SHA-256 persisted.
- Multi-App webhook HMAC verification with cross-customer isolation.
- Legacy SalonOS-owned Meta App webhook verification remains compatible.
- Manual status progression: webhook_pending -> webhook_verified -> live.
- Customer receives Callback URL + Verify Token only after Meta credential validation succeeds.

Required deployment:
1. Upload full v13.6.10.36.
2. Run `RUN_ONCE_V13_6_10_36_MANUAL_MULTI_APP_WHATSAPP.sql`.
3. Deploy `whatsapp-manual-connect` with JWT ON.
4. Re-deploy `whatsapp-webhook` with JWT OFF.
5. Do not touch the stable `whatsapp-ai-worker`.

Next validation milestone:
- Onboard a second customer-owned Meta App/WABA/Cloud API number, configure its webhook, then prove inbound -> AI reply -> appointment uses only that customer's branch data.

## v13.6.10.35 — Customer WhatsApp Embedded Signup Foundation
Direction confirmed:
- SalonOS must become a multi-customer WhatsApp SaaS integration. Each salon owner connects their own WhatsApp Business number/WABA instead of sharing the developer test number or manually copying temporary tokens.

Implemented:
- Recommended Connect WhatsApp Business card in branch settings.
- Standard Cloud API Embedded Signup flow.
- Existing WhatsApp Business App / Coexistence launch flow using whatsapp_business_app_onboarding.
- New authenticated Edge Function `whatsapp-embedded-signup`.
- Server-side authorization code exchange using Meta App Secret from Supabase Secrets.
- Business-token storage remains branch-scoped in `whatsapp_store_configs`.
- WABA webhook subscription via `/<WABA_ID>/subscribed_apps`.
- WABA/phone ownership validation before binding.
- Cross-tenant Phone Number ID conflict protection.
- Connection/audit metadata without storing OAuth code, App Secret, or business token in audit logs.
- Manual token setup retained as Advanced fallback.

Required platform setup before first customer:
1. Meta Tech Provider/customer onboarding prerequisites + required advanced permissions.
2. Meta Embedded Signup v4 configuration.
3. Deploy new Edge Function and set META_APP_ID / META_APP_SECRET / META_EMBEDDED_SIGNUP_CONFIG_ID.
4. Run the v13.6.10.35 SQL migration.

Next validation milestone:
- Use a second real/test Meta business (not the SalonOS developer test WABA) to complete Embedded Signup end-to-end and confirm inbound webhook + AI reply + appointment creation on that customer's own number.

## v13.6.10.34 — Meta Delivery Failure Isolation
Observed after v13.6.10.33:
- Edge Function invocations at 03:09 and 03:10 returned HTTP 500.
- Supabase raw log showed `meta_send_error:Authentication Error` inside `sendMetaTextMessage`.
- This proves the immediate production failure was outbound Meta authentication, not the v13.6.10.33 relative-date parser.

Confirmed code-level issue:
- `deliverAutoReply()` already treated Meta delivery failure as non-fatal.
- The main inline reply path duplicated sending logic and still executed `throw sendError` after writing `delivery_status=failed`, causing the whole worker invocation to become 500.

Implemented:
- Removed the fatal rethrow from the inline path.
- Added `replyStatus=failed` + `deliveryError` to persisted queue/run diagnostics.
- Kept booking/cancel/reschedule and conversation state finalization running after delivery failure.
- Expanded Meta error text with code/subcode/type/trace/http status when present.
- Left v13.6.10.33 date logic unchanged.

Operational action still required:
1. Verify a valid Meta access token with Meta's own API Setup Send Message test.
2. Update `whatsapp_store_configs.access_token` for the matching connection.
3. Prefer a System User access token for production instead of a temporary dashboard token.

Required deployment:
1. Upload v13.6.10.34 full ZIP.
2. Redeploy `whatsapp-ai-worker`.
3. No new SQL.

Next after delivery is restored:
- Re-run the `今天` -> `明天呢` appointment regression from v13.6.10.33.

## v13.6.10.33 — Relative Date Follow-up Guard
Observed after v13.6.10.32:
- `今天` correctly checked 20/08/2026.
- The immediate follow-up `明天呢` could still show availability on 20/08/2026 instead of 21/08/2026.
- The same follow-up could also lose the earlier exact 15:00 request and fall back to a generic slot list.

Confirmed code-level causes:
- Explicit-date detection and actual date resolution were treated as the same thing.
- When the model omitted `date_iso`, merge logic could donate the previous date and then mislabel it as current-turn `customer_explicit`.
- Normal appointment merge did not preserve prior exact `time_iso` for a date-only continuation.

Implemented:
- Deterministic backend date resolution for today/tomorrow/day-after-tomorrow in Chinese, English and Malay.
- Latest resolved date overrides model/prior date.
- Unresolved explicit date scrubs previous date before merge.
- Date provenance requires real current-turn resolution.
- Date-only continuation preserves prior exact time; an explicit new daypart disables that carry.

Required deployment:
1. Upload v13.6.10.33 full ZIP.
2. Redeploy only `whatsapp-ai-worker`.
3. No new SQL. Meta token unchanged.
4. Regression: after `今天` fails at 3 PM, `明天呢` must check 21/08/2026 and retain 15:00 as the requested time.

Next after this passes:
- Continue end-to-end booking confirmation/data-integrity testing.

## v13.6.10.32 — Fresh Booking Date Provenance Guard
Observed after v13.6.10.31:
- `我要预约下午三点weihong染头发` correctly separated staff/service, but still checked `20/08/2026` even though the customer did not state a date.

Confirmed code-level causes:
- Appointment date from an older active/corrupted state could still be merged into a newly restated booking.
- Intent-model context still contained recent cancelled/older booking messages, so the model could infer today's date from the clock/history.
- Older conversation slots had no provenance marker proving whether a date was actually customer-provided.

Implemented:
- Explicit fresh-booking restart boundary.
- Abandon old unconfirmed draft before handling a fresh booking sentence.
- Context isolation for fresh bookings.
- Strict date provenance guard: current explicit date, authoritative draft, or same-transaction trusted carry only.
- Legacy unproven dates are cleared and re-asked.
- Existing v13.6.10.31 employee/service entity separation preserved.

Required deployment:
1. Upload v13.6.10.32 full ZIP.
2. Redeploy only `whatsapp-ai-worker`.
3. No new SQL. Meta token unchanged.
4. Regression: `我要预约下午三点weihong染头发` must ask for date, not assume 20/08/2026.

Next after this passes:
- Continue end-to-end confirmation/data-integrity tests without changing the stable booking router unless a concrete regression appears.

## v13.6.10.31 — WhatsApp Staff / Service Entity Separation
- Production symptom fixed: `weihong染头发` no longer becomes a service query.
- Staff detection is validated against active employees in the current branch.
- Common multilingual service phrases are repaired independently before tool execution.
- Fresh booking state is isolated from completed cancel/reschedule flows.
- Deployment: upload package + redeploy WhatsApp worker; no new SQL.

## v13.6.10.30 — Manual Booking Staff Integrity
Proactive integrity audit after v13.6.10.29:
- Checked multi-worker service assignment, multi-service orders, assistants, worker reassignment, cancellation slot release, and manual appointment time handling.
- Confirmed manual New Order staff availability was weaker than the stable WhatsApp booking path: the browser sent appointment information, but the backend did not use the selected services + requested time for complete skills/schedule/conflict filtering.
- Confirmed System Assignment could fall back to the first active stylist.

Implemented:
- Canonical manual-booking staff pool with service skills + requested schedule/break + active Visit conflicts.
- Per-service lead/co-stylist pools plus a free assistant pool.
- Server-side preflight before creating customer / Visit rows.
- Validated random/system assignment and duplicate-role avoidance.
- Existing service worker reassignment validates the replacement team before deleting old rows.
- Cancelled/no-show/completed Visit statuses release availability while historical worker records remain.
- Owner appointment datetime-local values are persisted with explicit Asia/Kuala_Lumpur offset.
- Stable WhatsApp AI worker deliberately left unchanged.

Required deployment:
1. Upload v13.6.10.30 full ZIP.
2. Run `RUN_ONCE_V13_6_10_30_MANUAL_BOOKING_STAFF_INTEGRITY.sql` once.
3. Ctrl+F5.
4. Test appointment conflict, Hair Coloring skill filtering, co-stylist, assistant, system assignment, multiple services, cancellation release, and 15:00 MYT persistence.

Next audit after this passes:
- Item-level service progress/completion in multi-service orders and whether one employee can mark the entire Visit ready-for-checkout before other service items are finished.

## v13.6.10.29 — Order Detail Worker Scope Fix
Observed after v13.6.10.28:
- A one-stylist visit could show multiple staff in the Service Board detail summary.
- The same modal could show `待分配` inside SERVICE ITEMS even when the timeline correctly knew the assigned stylist.

Confirmed code-level root cause:
- Owner detail loaded `visit_service_workers` store-wide instead of filtering by the current visit's `visit_service_items`.
- The summary then iterated those unrelated worker rows directly.
- Owner detail items were not hydrated with per-item worker arrays.

Implemented:
- Current visit -> service item IDs -> scoped active worker query.
- Scoped signoff query using the same service item IDs.
- Group + attach workers back onto each service item.
- Summary and item rows now share the same exact assignment source.

Deployment:
1. Upload v13.6.10.29 web package.
2. No SQL.
3. No WhatsApp Edge Function redeploy.

Regression targets:
- One assigned stylist -> exactly one stylist in summary and service item.
- Two assigned workers on one project -> exactly those two only.
- Workers from another visit in the same branch never appear.

## v13.6.10.28 — Booking Staff Follow-up State Machine
Observed after v13.6.10.27:
- Pending-draft date/time revision was fixed.
- Staff-choice follow-ups were still brittle: asking for another stylist could keep the old stylist, and `have another 理发师? / have 谁可以做` could fall into the generic safe fallback.

Confirmed code-level causes:
- `mergeAppointmentEntities()` preserved the previous staff when the new message did not contain a parsed staff name.
- There was no deterministic booking-context router for `another stylist / who can do / random`.
- The generic change router could treat staff/service wording as an existing-booking reschedule.
- Profile collection and broad pending-draft confirmation could swallow or confirm around unresolved booking revisions.
- Specified-staff availability was not protected by the same service-skill qualification gate used by random assignment.

Implemented:
- Deterministic staff-choice state machine for alternative list, random assignment, exclusion of the previous stylist, and selection by name/number.
- Preserve service/date/time while changing only the stylist preference.
- Staff/service/date/time pending-draft revisions outrank stale reschedule continuity.
- Recover recent appointment entities when old safe-fallback state lost context.
- Allow booking revisions during customer-profile collection.
- Cancel unconfirmed drafts globally; confirm only from explicit confirmation states.
- Validate directly specified staff against required service skills before checking availability.
- More actionable no-slot replies: customer can ask for another qualified stylist, random assignment, or another time/date.

Required deployment:
1. Upload v13.6.10.28 full ZIP if updating the web package.
2. No SQL.
3. Redeploy `whatsapp-ai-worker` from the included `index.ts`.
4. Keep the working Meta token unchanged.

Regression targets:
- `换个人做咯不一定要fatchew` -> same service/date/time, exclude fatchew, list qualified alternatives.
- `have another 理发师?` -> list alternatives, not generic safe fallback.
- `have 谁可以做` -> list qualified + available stylists.
- `random / 谁都可以` -> random qualified + available assignment.
- `换成weihong` -> booking staff revision, never existing-appointment reschedule.
- `换去下午3点` -> date/time draft revision still works.

## v13.6.10.27 — Booking Draft Revision Precedence Fix
Observed after v13.6.10.26:
- Meta delivery was working.
- The same chat still returned the exact future-appointment/self-service message.

Confirmed code-level root cause:
- The draft recovery path was actually capable of producing `deterministicDraftRevision` with `intent=appointment`.
- Immediately afterward, the legacy previous-intent continuity rule converted any `appointment`/`other` result back to `reschedule` when the previous state started with `reschedule_`.
- Because the affected chat was already stuck at `reschedule_not_found`, the correct draft-revision intent was overwritten every time.

Implemented:
- Do not inherit stale reschedule continuity when `deterministicDraftRevision` is active.
- Explicitly lock draft revisions with a recoverable pending draft to `intent=appointment`.
- Add a diagnostic flag so future runs can prove which router won.

Required deployment:
1. Upload v13.6.10.27 full ZIP.
2. No SQL.
3. Redeploy whatsapp-ai-worker.
4. Same chat: send `我要换去下午3点`.

Next expected result:
- Updated unconfirmed booking draft or a real skill/availability result; not the existing-appointment not-found message.

# SalonOS Development Progress

Current version: **13.6.10.34**

## v13.6.10.26 — Draft History Recovery + State Preservation
Observed after v13.6.10.25:
- Meta sending was repaired by refreshing the access token, proving the remaining repeated self-service reply is worker routing/state, not Meta delivery.
- The same affected chat still returned the existing-confirmed-appointment `reschedule_not_found` message.

Code audit root cause:
- Generic state persistence wrote `booking_draft: appointmentDraft`; on a misrouted reschedule turn `appointmentDraft` is null.
- Therefore earlier .23/.24/.25 failures could erase `slots.booking_draft`, making the .25 state fallback impossible on the next message.
- Named-column lookup was also unnecessarily schema-sensitive.

Implemented:
- Schema-tolerant `select("*")` latest-draft lookup.
- created_at fallback ordering.
- Recent AI-run snapshot recovery (20 runs / 6 hours), with database revalidation by draft id when available.
- Preserve recoverable pending draft in conversation state across accidental change-intent routing.
- Richer `booking_draft_lookup` diagnostics.

Required deployment:
1. Upload v13.6.10.26 full ZIP.
2. No SQL.
3. Redeploy whatsapp-ai-worker from the included index.ts.
4. In the SAME affected chat send `我要换去下午3点`.

Next expected result:
- Updated unconfirmed draft or real skill/availability result; never the confirmed-appointment not-found message for this draft revision.

## v13.6.10.25 — Draft Lookup Failsafe + Misroute Guard
Observed after v13.6.10.24:
- The user could still receive the same future-appointment self-service message while trying to revise an unconfirmed draft.

Additional root cause fixed:
- The worker's full draft select included later assignment columns but discarded the PostgREST error.
- If the live schema did not expose one of those fields, `data=null` was treated as “no draft”.

Fix:
- Retry with the original v13.6.7 draft columns.
- Recover the durable conversation-state `booking_draft` snapshot as a second fallback.
- Keep terminal DB rows authoritative.
- Preserve random/specified assignment semantics.
- Add diagnostic `booking_draft_lookup` data to AI run snapshots.
- Support Chinese written-number hours such as `下午三点`.
- No new SQL; redeploy `whatsapp-ai-worker`.

Retest:
1. Same affected WhatsApp chat: `我要换去下午3点` (or `我要换去下午三点`).
2. The future-appointment self-service error must not be returned for an unconfirmed draft revision.
3. SalonOS must re-check service skill + staff availability and update the draft or return a real availability result.
4. Then send `confirm`.

## v13.6.10.24 — Stale Booking Draft Recovery
Observed after v13.6.10.23:
- User still received:
  `I couldn't find a future appointment for this WhatsApp number that is still eligible for self-service...`

Confirmed code-level cause:
- v13.6.10.23 pending draft lookup required `expires_at > now()`.
- Draft expiry is only 20 minutes.
- Once the draft crossed that timeout, the worker considered there to be no draft.
- Then `换去下午3点` fell back into the confirmed-appointment reschedule router again.

Fix:
- Read the latest booking transaction, not only unexpired drafts.
- Recover active or recently-expired unconfirmed drafts for up to 24 hours.
- A date/time revision reactivates the same draft and re-runs availability.
- `confirm` on a stale draft is blocked until the user supplies a current time for revalidation.
- Never resurrect an older draft if the latest transaction is confirmed/cancelled/failed.
- No SQL.
- Edge Function redeploy required.

Current test after deployment:
1. In the same affected WhatsApp conversation, send `我要换去下午3点`.
2. It must NOT send the future-appointment self-service error.
3. SalonOS must re-check Hair Coloring skill + full employee availability.
4. It must return an updated booking draft or a genuine no-slot message.
5. Only then send `confirm`.

## v13.6.10.23 — Pending Booking Draft Revision Router Fix
Runtime bug observed:
- AI had already created an UNCONFIRMED Hair Coloring booking draft.
- Customer sent: `我要换去下午3点`.
- Worker incorrectly classified this as `reschedule` of an existing confirmed appointment.
- `v1369_ai_find_upcoming_appointments` correctly found no confirmed self-service appointment, so AI repeatedly replied:
  `I couldn't find a future appointment for this WhatsApp number that is still eligible for self-service...`
- Even `confirm` kept the conversation trapped in the wrong change flow.

Root cause:
- The comment in the worker said draft revisions should fall through to the appointment pipeline.
- But the deterministic reschedule router ran later and interpreted `换去下午3点` as an existing-appointment reschedule.
- Conversation state then changed to `reschedule_not_found`.

Fix:
- Durable pending booking draft is loaded directly from `whatsapp_ai_appointment_drafts`.
- Date/time changes while a draft exists are forced to `appointment` draft revision.
- The same draft is updated; customer profile is preserved.
- Staff/service availability is re-evaluated for the new time.
- Existing bad `reschedule_not_found` state can recover without deleting the draft.
- No SQL.
- Edge Function redeploy required.

Re-test:
1. Deploy v13.6.10.23 `whatsapp-ai-worker`.
2. On the affected WhatsApp chat, send `我要换去下午3点` again.
3. Expected: SalonOS updates the pending draft instead of searching for an existing appointment.
4. If fatchew is busy and another qualified employee is free, new draft should show that employee.
5. Only after the updated draft appears, reply `confirm`.

## v13.6.10.22 — Unified Staff Pool & Service Board Availability
Runtime problem observed:
- WhatsApp request: Hair Coloring tomorrow at 15:00.
- `fatchew` already has a 15:00 Hair Coloring appointment.
- Service Board visibly shows `weihong` as Available.
- AI replied that qualified stylists exist but none are free.

Confirmed cause:
- Old AI availability required `whatsapp_ai_employee_schedules`.
- Service Board availability does not use that hidden table.
- Therefore an employee could be Available on the board but invisible to AI random assignment.

Fix:
- Dedicated AI employee schedule remains authoritative when it exists.
- If it does not exist, AI falls back to the same Service Board operating window 09:00 -> 00:00.
- Real Visit overlap is checked for every qualified employee.
- Random assignment scans the whole qualified pool and can skip a busy stylist.
- Existing skill tags are re-synced to employee_skills.

Important rule retained:
- `weihong` is eligible for Hair Coloring only if the employee has the Hair Coloring / 染发 skill.
- Free/on-duty does not bypass required skill qualification.

Deployment:
1. Upload complete v13.6.10.22.
2. Run RUN_ONCE_V13_6_10_22_UNIFIED_STAFF_POOL.sql once.
3. No Edge Function redeploy.
4. Re-test 20/08/2026 15:00 Hair Coloring with no preferred stylist.

## v13.6.10.21 — Canonical Marketing Lifecycle Sync
Observed after v13.6.10.20:
- CLOSED LOOP HEALTH:
  First Touch = 2
  Customer Linked = 1
  Visit / Booking Linked = 1
  Arrived = 1
  Paid = 1
  BRIDGE READY
- But top Marketing KPI still showed:
  Booked Customers = 0
  Arrived Customers = 0
  Attributed Revenue = RM0.00

Conclusion:
- The database bridge is fully working.
- The old PHP analytics lifecycle joins are not a reliable source under the current RLS/session path.

Fix:
- Added SECURITY DEFINER RPC `v13621_marketing_lifecycle_rows`.
- Returns one canonical lifecycle outcome row per immutable First-Touch phone.
- All source/content ranking calculations use those rows.
- CLOSED LOOP HEALTH and the rest of Marketing Analytics now share the same Visits/Payments truth.
- First-Touch remains immutable.

Deployment:
1. Upload complete v13.6.10.21.
2. Run RUN_ONCE_V13_6_10_21_MARKETING_LIFECYCLE_RPC.sql once.
3. No Edge Function redeploy.
4. Refresh Marketing 来源分析.

## v13.6.10.20 — Closed Loop Summary Carry Fix
Observed:
- Supabase confirmed:
  CLOSED LOOP HEALTH RPC READY
  health_rpc_ok = true
  bridge_version = 13.6.10.18
  health_rpc_version = 13.6.10.19
- Web UI still displayed SQL REQUIRED / Customer Linked 0 / Visit Linked 0.

Confirmed root cause:
- v13.6.10.17 introduced a filtered page-local `$summary`.
- v13.6.10.18/19 correctly populated closed-loop fields inside the dataset summary.
- The page then rebuilt `$summary` and dropped those fields before rendering CLOSED LOOP HEALTH.
- Therefore the database/RPC was correct; only the final rendering summary was wrong.

Fix:
- Carry all closed-loop database health fields into the page-local summary.
- No additional SQL required.
- No Edge Function redeploy required.

Expected after upload + Ctrl+F5:
- BRIDGE READY
- FIRST TOUCH = 2
- CUSTOMER LINKED = 1
- VISIT / BOOKING LINKED = 1
- Arrived/Paid follow the actual linked Visit lifecycle.

## v13.6.10.19 — Closed Loop Health RPC Fix
Observed runtime result:
- v13.6.10.18 SQL returned:
  first_touch_customers = 2
  customer_linked = 1
  visit_linked_customers = 1
- But Marketing CLOSED LOOP HEALTH still showed SQL REQUIRED / 0 / 0.

Root cause:
- The SQL bridge itself was successful.
- The PHP status probe used ordinary REST/RLS against `salonos_system_meta`, so it could fail to see the marker and show a false negative.

Fix:
- Added SECURITY DEFINER RPC `v13619_closed_loop_health`.
- RPC checks Owner/Manager + store access, then reports exact period-scoped counts.
- Marketing UI uses this RPC as the source of truth for Bridge Ready / Customer Linked / Visit Linked / Arrived / Paid.
- First-Touch and Revenue rules remain unchanged.

Deployment:
- Upload full v13.6.10.19.
- Run `RUN_ONCE_V13_6_10_19_CLOSED_LOOP_HEALTH_RPC.sql` once.
- No Edge Function redeploy.

## v13.6.10.18 — Marketing Closed Loop Bridge
Goal:
- Prove and harden the real business chain:
  WhatsApp First Touch -> Customer -> Appointment/Visit -> Arrived -> Paid -> Revenue.
- Booking / Arrived / Revenue must be real SalonOS data, not UI-only counters.

Implemented:
- Added database trigger on `visit_recipients`.
- The same normalized phone automatically links First-Touch to canonical Customer.
- The earliest Marketing Lead stores the first eligible post-touch `visit_id`.
- AI appointments and manual SalonOS visits use the same bridge.
- Visits before First Touch are never retroactively attributed.
- Arrived / Paid / Revenue continue to read canonical visits/payments live.
- Added CLOSED LOOP HEALTH to Marketing 来源分析.
- One SQL migration required; no Edge Function redeploy.

Next runtime test after SQL:
1. Open the current ACTIVE tracked Profile link.
2. Send WhatsApp from a test/customer phone.
3. Complete an AI appointment confirmation.
4. Confirm Marketing CLOSED LOOP shows Customer Linked + Visit/Booking Linked.
5. Mark the visit arrived in SalonOS.
6. Complete checkout/payment.
7. Confirm Arrived and Revenue update automatically.

## v13.6.10.17 — Marketing Filters & Ranking
User-approved goal:
- Add Day / Month / Year analysis plus filters by platform, staff IP and content type.
- Let the owner switch ranking between customers, bookings, arrived, revenue, repeat rate and loyal customers.
- Keep all anti-duplicate and First-Touch rules unchanged.

Implemented:
- Added compact FILTER & RANKING console.
- Platform filter: Instagram / Facebook / TikTok / Google / XHS / any discovered source.
- Staff IP filter uses actual First-Touch source staff names.
- Content filter supports Profile / Reel / Post / Story and other discovered placements.
- Ranking modes: 顾客最多 / 预约最多 / 到店最多 / Revenue 最高 / 回头率最高 / 忠诚客最多.
- Top KPI cards, funnel, Content Performance, Channel Quality, Staff IP, Media Account and source-detail table all recalculate from current filters.
- Link opens stay diagnostic-only.
- No SQL and no Edge Function redeploy required.

## v13.6.10.16 — Content Lifecycle Status
User-approved goal:
- Make it obvious why an OFF Tracking Link can still appear in Marketing Analytics.
- Preserve historical First-Touch attribution while clearly distinguishing current links from historical links.

Implemented:
- Content Performance cards show ACTIVE or OFF · HISTORICAL.
- Small modal has a Current Link Status lifecycle banner.
- OFF · HISTORICAL explains that no new traffic is accepted, while old customers/revenue remain attributed.
- Added First-Touch acquisition time range per link/content.
- No SQL and no Edge Function redeploy required.

Verified expected behavior:
- `fatchew-profile` may remain visible as OFF · HISTORICAL because Jimmy's immutable First-Touch belongs to that link.
- `jimmytiew-profile` remains ACTIVE for future traffic.

## v13.6.10.15 — Content Performance Analytics
User-approved goal:
- Compare which Profile / Reel / Post / Story truly brings customers.
- Keep owner pages concise; click a content card to open a small modal with detail.
- Customer counts must stay based on unique First-Touch WhatsApp phone numbers, never raw link clicks.

Implemented:
- Added per-Tracking-Link / content First-Touch performance aggregation.
- Content cards show unique customers, booked customers, arrived customers and attributed revenue.
- Small modal shows Booked / Arrived / Repeat / Loyal / Revenue plus First-Touch customer list.
- Link opens are visible only as a technical diagnostic inside the modal.
- First-Touch immutability remains unchanged.
- No SQL and no Edge Function redeploy required.

## v13.6.10.14 — Dynamic Version & Cache Busting
User-approved improvement:
- The version shown in the lower-left SalonOS status card must follow the actual package version automatically.
- Future UI/CSS/JS updates should not keep stale cache-busting numbers.

Implemented:
- Central version helper reads `v13/VERSION`.
- Sidebar status uses the helper.
- Main CSS, JavaScript and service-worker registration URLs use the current VERSION automatically.
- Creator status panel reads the same VERSION.
- Service-worker cache key updated so older cached assets are removed after activation.
- No SQL and no Edge Function redeploy required.

Expected after upload:
- `v13/VERSION` = 13.6.10.14
- Lower-left status = `v13.6.10.14 · Supabase Only`

## v13.6.10.13 — Profile Link Duplicate Guard
- Approved rule: same media account can have only 1 active Profile/Bio Tracking Link.
- Reel/Post/Story etc. can have multiple links.
- New/edit/re-enable blocks duplicate active Profile links for the same social_account_id.
- Legacy duplicates are detected but not auto-disabled, protecting historical First-Touch data.
- Owner should keep one official Profile link and use `停用` on extra legacy Profile links.
- No SQL migration and no Edge Function redeploy required.

## v13.6.10.12 — Media Content & Tracking Link Management Center
User requirement:
- Build Profile / Reel / Post / Story tracking inside SalonOS instead of asking the owner to touch Supabase.
- Keep the existing SalonOS small-modal rule for create/edit.
- Make each link easy to copy, test, modify and disable.
- Preserve First-Touch / unique WhatsApp customer rules.

Implemented:
- Replaced the large Tracking Link builder with a compact management center.
- Added one shared small modal for new/edit Tracking Links.
- Media account selection auto-fills platform and source employee.
- Profile / Bio keeps `content_id = NULL`; Reel/Post/Story use `marketing_contents`.
- Added link actions: Copy / Test / Modify / Disable.
- Editing affects future tracking metadata only; historical First-Touch customer attribution remains locked.
- Branch WhatsApp Business number remains the only WhatsApp destination source.

Deployment:
1. Upload full v13.6.10.12 ZIP and extract to `htdocs/v13/`.
2. Confirm `v13/VERSION = 13.6.10.12`.
3. No new SQL required if v13.6.10.9 First-Touch migration is already installed.
4. No Edge Function redeploy required.
5. Open Settings -> Media Accounts & Tracking and test `+ 新增内容 / Link`.

Updated: 2026-08-19 16:17 (Asia/Kuala_Lumpur)

## v13.6.10.11 — Owner Analytics Overview

### User requirement
- 经营分析首页不要越来越复杂，老板应该先一眼看到真正需要判断的数字。
- 深层数据仍然保留，但通过点击卡片的小浮窗或展开详细指标查看。
- 新客、社媒来源、员工 IP、转化、回头、指定理发师忠诚和社媒 Revenue 要能在同一个老板摘要看到。

### Implemented
- Added **OWNER SNAPSHOT** to the top of 经营分析.
- Added 8 clickable owner cards:
  - 本期新客
  - 社媒新客
  - 最佳来源平台
  - 最佳员工 IP
  - 最高到店转化
  - 回头客率
  - 指定理发师转化率
  - 社媒归因 Revenue
- Every owner card opens an existing SalonOS small modal instead of navigating to a large detail page.
- 本期新客 reuses the existing customer-group modal.
- 社媒新客 modal lists customer + first platform/account/staff + age band + gender + ethnicity.
- Source / staff / conversion / lifecycle / social revenue cards have compact comparison modals.
- Existing 10 operational KPI cards are preserved but moved behind a collapsed **经营详细指标** section to reduce clutter.
- L-shaped operating report, service/product performance, 3 customer groups, export and full Marketing Analytics remain available.
- Marketing customer counts still use the v13.6.10.9 First Touch rule: one normalized phone = one customer; repeated messages and later platforms never create duplicates or overwrite the original source.

### Deployment
- Full ZIP only.
- New SQL required: NO (when v13.6.10.9 First Touch SQL is already installed).
- Edge Function redeploy required: NO.

### Next check
- Open 经营分析 with Day / Month / Year filters.
- Confirm OWNER SNAPSHOT appears first.
- Click all 8 cards and confirm each opens a small modal / detail view correctly.

## v13.6.10.10 — Marketing Lifecycle Quality Analytics

### Confirmed before this release
- First-touch unique WhatsApp customer logic: PASS.
- Repeated messages do not increase customer count: PASS.
- Later Facebook / Instagram / TikTok entry does not overwrite the first source: PASS.
- Three customer groups + small-modal demographic/source detail: PASS.
- Marketing first-touch source match: PASS.

### This release
Marketing Analytics is simplified around real customer quality rather than link activity.

The selected period is the period in which the customer FIRST contacted WhatsApp. That customer's later results are continuously attributed back to the first source:
- Unique WhatsApp Customer
- Booked Customer
- Arrived Customer
- Repeat Customer
- Stylist-Loyal Customer
- Attributed Revenue

Additional owner views:
- Customer Journey Funnel
- Channel Quality comparison
- Staff Personal-IP ranking
- Media Account ranking
- First Touch Source Detail with Revenue / Customer

### Anti-spam / attribution rule
- Link opens are diagnostic only.
- One normalized phone = one customer.
- Repeated WhatsApp messages cannot create extra customers.
- Later platform entries cannot replace the original first source.
- Visits before first touch are not retroactively attributed.

### Deployment
- Full ZIP only.
- No new SQL when upgrading from v13.6.10.9.
- No Edge Function redeploy.
- If upgrading from <= v13.6.10.8, v13.6.10.9 first-touch SQL is still required first.

### Next validation
Open Marketing 来源分析 and verify the first-touch test customer appears once while the new lifecycle funnel / rankings render correctly.

---

# SalonOS Development Progress

Current version: **13.6.10.8**
Updated: 2026-08-19 03:33 (Asia/Kuala_Lumpur)

## v13.6.10.8 — Marketing Analytics Employee Scope Fix

### Live test result from v13.6.10.7
- Marketing Attribution backend: **PASS**.
- `fatchew-profile` produced a matched lead with Instagram + social account + source staff attribution.
- Marketing Analytics page: **FAILED TO LOAD** with the generic `RUN_ONCE_V13_5_5_CUMULATIVE_RUNTIME.sql` schema warning.

### Root cause
The new Marketing Analytics dataset queried `employees.store_id`. In the SalonOS schema, `employees` is organization-scoped and branch/store membership is modeled separately. Therefore PostgREST returned a missing-column/schema error and the global handler displayed the old cumulative-runtime warning.

### Fix
- Removed the invalid `employees.store_id` filter.
- Employee name mapping now reads organization employees only; the Marketing links/leads themselves remain strictly filtered by the current organization + store, so cross-branch attribution is not introduced.
- No database migration is required.
- No Edge Function redeploy is required.

### Current test target
Upload this full package and reopen:
`index.php?page=marketing_analytics&period=month&anchor=2026-08-19`

Expected: the page loads and the existing Profile attribution appears as Instagram / jimmy personal ip / fatchew / Profile.

### Next stage after PASS
- Reel / Post / Story content-level attribution tests.
- Marketing outcome segmentation: first visit / returning-random / stylist-loyal customers.

---

# SalonOS Development Progress

Current version: 13.6.10.7

## Latest completed
- Marketing Attribution backend: PASS
- Profile click → unique REF → WhatsApp → Webhook → marketing_leads matched: PASS
- Media/staff account editor uses small modal: PASS
- Marketing Analytics Dashboard UI: DONE
  - Clicks
  - Leads
  - Appointment conversion
  - Arrived conversion
  - Attributed revenue
  - Channel breakdown
  - Account / staff / placement breakdown

## Current test target
Open `index.php?page=marketing_analytics` and verify the successful `fatchew-profile` test appears under Instagram / jimmy personal ip / fatchew / Profile.

## Next planned stage
- Add Reel/Post/Story-specific content tracking test and content-level marketing comparison.
- Add first-visit / returning-random / stylist-loyal customer outcome attribution to Marketing Analytics.

# SalonOS Development Progress

Updated: 2026-08-19 03:03 (Asia/Kuala_Lumpur)
Current full package: **v13.6.10.6 MEDIA ACCOUNT SMALL MODAL FULL**

## Delivery rule
- Every implementation step is delivered as a **complete SalonOS ZIP**, not a small patch ZIP.
- The complete ZIP keeps the existing UI, PHP, PWA, Supabase SQL, Edge Functions, WhatsApp AI, appointment system, analytics and previous hotfixes.
- Each release records what was completed and what is next.
- ZIP structure is a single `v13/` root only; never `v13/v13/`.

## Completed before this release
- WhatsApp Cloud API inbound webhook works.
- WhatsApp outbound replies work with the active Meta token.
- Groq AI intent processing works with JSON-safe fallback.
- Appointment create / confirm / reschedule / cancel flows are implemented.
- Random stylist assignment uses service skill + real availability filtering.
- English skill taxonomy / system assignment layer is included.
- Customer intelligence segmentation is implemented.
- Marketing channel, social account, content, tracking link and click tables exist.
- `v1360_marketing_track()` is available for public short-link attribution.
- A profile-level tracking link can use `content_id = NULL` and still retain channel + social account + staff attribution.

## This release — MKT Profile Attribution Route
Goal: a WhatsApp link placed on a social-media **profile page** must be tracked even when it is not attached to a Reel/Post.

Production flow:
1. Customer opens `/t/<slug>` such as `/t/fatchew-profile`.
2. SalonOS resolves the `tracking_links` row by slug.
3. SalonOS generates a unique `Ref` and inserts a `tracking_clicks` row through `v1360_marketing_track()`.
4. The link redirects to the configured WhatsApp number.
5. The prefilled WhatsApp message contains the generated `Ref`.
6. `whatsapp-webhook` reads the Ref and maps the lead back to the original `tracking_link`.
7. For profile links, `content_id` may remain NULL while attribution still preserves Instagram/Facebook/TikTok + social account + staff.
8. For Reel/Post links, the same route also preserves `content_id`.

## Files added/updated in v13.6.10.3
- `VERSION` -> 13.6.10.3
- `track.php` -> production profile/content attribution route, English default prefill and no-cache/security headers.
- `t/index.php` -> shared-hosting fallback router that delegates to `track.php`.
- `t/.htaccess` -> fallback rewrite for `/t/<slug>`.
- `V13_6_10_3_PROFILE_ATTRIBUTION_GUIDE.txt`
- `BUILD_AUDIT_v13.6.10.3.txt`
- `PACKAGE_MANIFEST_v13.6.10.3.sha256`
- `SALONOS_PROGRESS.md`

## Test for the existing profile link
Use the profile slug already created in Supabase:
`/t/fatchew-profile`

Expected result:
- browser redirects to WhatsApp;
- the WhatsApp prefilled text contains `Ref: ...`;
- a new row appears in `tracking_clicks`;
- after the customer sends the message, the lead can retain Instagram + fatchew attribution even with no Reel/Post content.

## Next development step
MKT-03 — expose attribution cleanly in SalonOS analytics/UI:
- channel;
- social account;
- staff IP;
- placement (profile / reel / post / story / QR etc.);
- content when present;
- first-visit / returning-random / returning-specified customer segments.

## 2026-08-19 02:43 — v13.6.10.4 Tracking Business Phone Fix
Live profile-attribution test result:
- PASS: `/t/fatchew-profile` generated `FATCHEW-PROFILE-E20E` and inserted `tracking_clicks` with Instagram + social account + fatchew.
- FAIL ROOT CAUSE: the redirect opened the customer's own `+60 12-723 1853` self-chat because the existing tracking link stored that number as `destination_phone`.
- CONSEQUENCE: no inbound message reached the Meta WhatsApp Business webhook, so the latest `marketing_leads` row remained the older `ref_missing` record.
- FIX: route WhatsApp tracking links through the branch's active `whatsapp_business_connections.display_phone_number`; repair existing active links; prevent future manual customer-number routing.
- NEXT TEST: open `/t/fatchew-profile` again. It must open the business test number `+1 (555) 668-0561`, send the Ref message, then verify `marketing_leads.attribution_status = matched`.

## 2026-08-19 02:53 — v13.6.10.5 Media Account Edit
User requirement:
- Media/staff social accounts cannot be managed with only a Disable button.
- Owner needs to correct a wrong account name, username, platform, employee mapping, profile URL or account ID without deleting history.

Implemented:
- Added **Modify** button to every social account row, including disabled rows.
- Edit form preloads the selected account.
- Account can be switched between Store / Staff Personal IP / Other.
- Linked employee can be changed.
- Disabled accounts can be re-enabled from the edit form.
- Saving an account correction synchronizes linked `tracking_links.channel_id` and `tracking_links.staff_id` for future attribution.
- Historical `marketing_leads` are preserved and are not rewritten.
- v13.6.10.5 is cumulative over v13.6.10.4. Because v13.6.10.4 was not deployed, the new one-time SQL includes the WhatsApp Business destination repair.

Next test:
1. Upload v13.6.10.5 full ZIP.
2. Run `RUN_ONCE_V13_6_10_5_MEDIA_ACCOUNT_EDIT.sql`.
3. Open Settings -> Media Attribution.
4. Click Modify on the current test social account and correct the account details.
5. Re-test `/t/fatchew-profile` and verify it opens the branch WhatsApp Business number.
6. Send the Ref message and verify the new `marketing_leads` row is `attribution_status = matched`.


## 2026-08-19 03:03 — v13.6.10.6 Media Account Small Modal UX
Correction after UI-rule review:
- v13.6.10.5 exposed Modify correctly, but rendered the editor as a large in-page form.
- SalonOS rule: compact add/edit operations must be modal-first.

Implemented:
- Removed the expanded in-page social-account editor.
- Added `+ Add Account` button -> small modal.
- `Modify` button -> same small modal, prefilled with selected account.
- Modal keeps platform/account/staff/profile/account-ID/active editing.
- Staff selector is shown/required only for Staff Personal IP.
- No `edit_account` page navigation/reload is used.
- Saving behavior remains future-attribution-safe; historical leads are unchanged.

Next test:
1. Upload v13.6.10.6 full ZIP.
2. Run cumulative v13.6.10.6 SQL only if the v13.6.10.5 cumulative SQL has not already been run.
3. Settings -> Media Attribution -> Media / Staff Accounts -> Modify.
4. Confirm a small modal opens on top of the same page.

## 2026-08-19 15:09 — v13.6.10.9 First-Touch Unique Customer Analytics
User requirement:
- Do not let repeated Tracking Link opens or repeated WhatsApp messages inflate customer counts.
- One real WhatsApp phone should appear once in Marketing Dashboard even if the customer sends repeatedly.
- First-touch attribution is immutable: if the same phone first arrives from Instagram and later from Facebook, keep Instagram only.
- The three customer segment cards should be clickable and open a small modal instead of always showing large detail tables.
- Each customer segment modal must show source, age bands, ethnicity, gender, customer list, visit behavior and source employee/account details.
- Customer source should match WhatsApp attribution by phone number.

Implemented:
- Added `marketing_customer_first_touch` with unique `(organization_id, store_id, normalized_phone)`.
- Added database trigger `v136109_lock_marketing_first_touch()` so later refs/platforms cannot rewrite the original source.
- Added Malaysia phone canonicalization so `+60 / 60xxxxxxxxx` and `0xxxxxxxxx` can match SalonOS customer records.
- Marketing Analytics now uses UNIQUE WHATSAPP CUSTOMERS instead of Tracking Clicks as the customer KPI.
- Raw link opens are retained only as a diagnostic note and do not affect conversion or ranking.
- Customer Structure cards are now clickable small modals with source / age band / ethnicity / gender breakdowns and detailed customer rows.
- Source details show first platform + social account + placement + source employee when available.
- Sidebar version now reads the `VERSION` file dynamically instead of being stuck on v13.5.11.

Required deployment:
1. Upload the full v13.6.10.9 ZIP.
2. Run `RUN_ONCE_V13_6_10_9_FIRST_TOUCH_UNIQUE_CUSTOMER_ANALYTICS.sql` once in Supabase SQL Editor.
3. No WhatsApp Edge Function redeploy is required because first-touch locking is enforced in the database.

Next test:
- Repeated messages from the same WhatsApp number -> unique customer count must stay 1.
- Same phone Instagram first, Facebook later -> first source must remain Instagram.
- Open each of the 3 customer segment cards -> small modal must show matching source and demographic details.
