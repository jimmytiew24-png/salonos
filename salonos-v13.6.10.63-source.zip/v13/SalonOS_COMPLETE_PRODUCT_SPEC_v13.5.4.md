# SalonOS Complete Product Specification — v13.5.3

**Status:** Current single source of truth for the v13 line  
**Rule:** Future builds must preserve these confirmed requirements unless the product owner explicitly replaces a rule. Database migrations must not silently simplify, remove, rename, or redesign confirmed workflows.  
**UI baseline:** v12.4.4 Midnight / Gold UI language + v13 Supabase backend.  
**Data source of truth:** Supabase only. InfinityFree/VPS is hosting only.

---

# A. Platform Architecture

## A1. Exactly two PWAs
1. **SalonOS Creator** — platform developer / SaaS administrator only.
2. **SalonOS** — Owner, Manager, Front Desk, Accountant, Stylist, Assistant and custom roles share the same PWA.
3. There is no separate Owner PWA and Staff PWA.
4. SalonOS UI is permission-driven after login.

## A2. Supabase-only business data
- Supabase Auth, PostgreSQL, RLS, Storage, RPC/Functions and appropriate Realtime are the backend.
- InfinityFree/VPS/Evoxt/DigitalOcean hosts PHP/HTML/CSS/JS/PWA/static assets only.
- InfinityFree MySQL is not a fallback for v13 business data.
- All formal records — owners, branches, subscriptions, codes, devices, customers, members, employees, visits, services, products, stock, payments, KPI, commission, reports, appointments, settings, signatures and media metadata — live in Supabase.

## A3. Tenant and branch isolation
- Every owner belongs to an independent `organization_id` tenant.
- Owner A must never read Owner B customers, staff, products, orders, KPI, payments or reports.
- Store-scoped records also carry/use `store_id`.
- RLS + organization membership + store access are mandatory.
- Owner can switch owned branches from the SalonOS top bar.
- Normal staff cannot freely switch into another branch.

---

# B. Creator / SaaS Control Plane

## B1. Creator functions
Creator must support:
- Creator login.
- See all owner accounts and all branches.
- Show Owner Email, branch Email, store name, branch, plan, created time, expiry and status.
- Generate Owner Activation Code.
- Generate Branch Activation Code.
- Generate Device Code.
- Suspend / restore subscription.
- Renew subscription.
- Revoke trusted device.
- View creator audit logs.
- Dashboard should reflect owner / branch changes in near-real time.

## B2. Code rules
- Activation / Branch / Device codes are one-time-use.
- Default validity is about 5 minutes.
- First device requires Device Code.
- Trusted devices remain remembered for a configured period.
- Revoked device must authorize again.

## B3. Subscription pricing
- RM100 / month / account.
- RM1000 / year / account.
- RM2000 / 2 years / account.
- Main owner account = one subscription.
- Each branch login account = one additional subscription at the same price.
- Current commercial flow: payment → Creator confirms → Creator creates Code → owner activates.
- Automated FPX/Card billing is future work, not required for current manual flow.

---

# C. Account, Login and Branches

## C1. New owner onboarding
Target flow:
`Install SalonOS → enter Activation Code → create Owner Auth account → create Organization/Tenant → create main Store → first device authorization → enter SalonOS`.

Owner login:
- Email + password is the current v13 rule.
- First device requires Device Code.
- Trusted device does not require code every login.

## C2. Branch creation
Required fields:
- branch name
- address
- phone
- unique branch Email
- login password

Flow:
`buy extra subscription → Creator creates Branch Code → branch registers → separate branch login account created`.

Rules:
- each branch must have a unique Email.
- branch Email is its login credential.
- each branch has its own subscription.
- owner can still switch among main store / branch A / branch B after owner login.
- branch/store data is isolated by `store_id`.

---

# D. Roles and Permissions

Built-in roles:
- Owner
- Manager
- Front Desk / Receptionist
- Accountant
- Stylist
- Assistant
- Staff
- Owner-defined custom role (planned/required)

Default direction:
- Owner: full access.
- Manager: management permissions chosen by owner.
- Front Desk: appointments, arrival, orders, add-on products, payment and checkout.
- Accountant: order records, commission, finance, reports.
- Stylist/Assistant/Staff: own appointments, own orders, own schedule, own KPI, training, service process.

Permission Center must control visibility/access for customer, order, all-store orders, employees, KPI, training, product, inventory, commission, report, branch, WhatsApp, import and export. Server-side permission checks are required; hiding a menu is not sufficient security.

---

# E. Employee Management and Live Status

Employee fields:
- name
- phone
- position
- age
- gender
- skills
- base salary
- branch
- employee code
- join date
- app role / permission role
- status

Employee account:
- created automatically with employee record.
- phone-only login; no password.
- login must verify phone exists, employee Active, branch mapping active.
- disabling employee immediately blocks future login.
- historical orders, KPI, performance and commission must remain.

Live work status:
- Available
- In Service
- Break
- Off Duty
- Disabled

Employee can start/end break. Management can override status. Status directly affects Walk-in availability.

Salary / compensation is sensitive and should only be visible to appropriate Owner/Manager/Accountant roles, not a public staff directory.

---

# F. Dashboard — v13.5.0 Locked Change

The Dashboard must **not** repeat navigation as a giant “Quick Actions” area.

Instead it shows store operating data as visual metric/icon tiles, for example:
- current store customers
- active staff
- today orders/visits
- ready for checkout
- month revenue
- low-stock alerts
- future additional live store metrics where useful

Switching the active branch must automatically change Dashboard data to the selected store.

---

# G. New Order — Four-Step Wizard

## G1. Step 1 — Arrival Type
Choose:
- Walk-in
- Appointment

Walk-in:
- uses real current time.

Appointment:
- choose date + time.

Then choose:
- customer-specified stylist
- system intelligent assignment

## G2. Real-time availability
Walk-in must exclude staff who are:
- on break
- off duty
- disabled
- currently servicing another customer
- still occupied by a paused unfinished order
- overlapping another active order
- about to collide with an imminent appointment based on estimated service duration

The server must re-check availability when submitting the order to prevent two counters from double-booking at the same time.

Appointment collision uses appointment start + estimated service duration. If Daniel is occupied 15:00–16:30, a conflicting 15:30 booking cannot choose Daniel.

## G3. Step 2 — Customer + Recipients + Projects
Customer lookup does not display the entire member list by default.
Search fuzzily by:
- name
- phone
- member number

Selecting an existing customer/member auto-fills data.

### Returning non-member duplicate prevention — v13.5.0 locked
If staff manually enters a non-member’s name/phone during a new order and that phone has already visited the same store, **reuse the existing customer profile instead of creating another customer card**. Historical duplicate rows are not destructively deleted if linked to history; the directory presents one canonical customer.

New non-member quick order requires at minimum:
- name
- phone

When manually entering a non-member, additionally allow:
- ethnicity
- age

Customer profile may contain:
- name
- phone
- gender
- age
- birthday
- ethnicity
- Email
- ID / Passport
- address
- source platform
- notes

## G4. Companions / multiple recipients
One visit may include child, family, friend, elder or other companion. Each recipient can have separate service projects, staff, assistants and amount.

## G5. Service category-first selection — v13.5.0 locked
Each project selection flow is:
`Service Category → Service inside that category`.
The service dropdown remains filtered to the selected category.

## G6. Multiple staff per service project
Each project can have:
- 1 Lead Stylist
- multiple Co-Stylists
- multiple Assistants
- Contribution % per worker

Contribution total per project must equal 100%.
A RM300 project performed 50/30/20 remains RM300 store revenue; staff performance becomes RM150/RM90/RM60. Revenue is never multiplied to RM900.

## G7. Step 3 — Customer confirmation
Review:
- customer / recipients
- arrival type
- appointment time
- projects
- staff / assistants
- estimated time
- amounts
- total

## G8. Step 4 — electronic signature
Customer signs after review.
If project, staff or price materially changes afterward:
- require re-confirmation / re-signature.
- retain previous confirmation/signature versions rather than overwrite history.

## G9. Draft recovery
New Order auto-saves draft. Refresh/accidental close should allow restoration.

---

# H. Service Board / Live Service Control

This is not a simple order-card list. It is a real-time **Team Appointment Board**.

## H1. Layout
- employees vertically on the left.
- horizontal timeline from **09:00 → 00:00**.
- appointments appear directly on each employee timeline, not in a separate giant appointment card list.
- date controls: previous day, date picker, next day.
- acting on a visit while viewing another date must keep the same board date.

## H2. Color state contract
Yellow:
- booked appointment
- waiting arrival
- arrived/waiting confirmation/signature/start

Red:
- in service
- paused
- service completed but ready for counter checkout

Green:
- completed / checked out

Cancelled remains visible in ALL ORDERS but should not occupy the board like active work.

## H3. Time block content
Compactly show:
- start/end time
- customer
- main service
- multi-service `+N`
- short state / Walk-in or Appointment where useful

## H4. Shared small Modal
Click any timeline block or ALL ORDERS row → same scrollable small Modal. It can show customer, phone, projects, staff, assistants, amount, time, status and payment status.

Actions by state/permission:
- view / modify
- cancel appointment
- verify phone
- customer arrived
- confirm project
- electronic signature
- start service
- pause / resume
- add/edit project
- add co-stylist / assistant
- edit Contribution
- material consumption
- complete service / notify counter
- checkout

## H5. Arrival does not delete appointment
Clicking “Customer Arrived” changes state but keeps the order on the same employee timeline.

## H6. Service complete ≠ checkout
Staff cannot finalize payment. Staff selects “Service completed / notify counter” → Ready for Checkout, still Red until counter completes payment.

## H7. Staff privacy
Owner/Manager/Front Desk may see store-wide board. Ordinary employee sees only own relevant schedule/customer orders.

## H8. ALL ORDERS below board
Fixed list for selected date includes booked, waiting arrival, pending signature, waiting, in service, paused, ready checkout, completed, cancelled and no-show as applicable.

---

# I. Checkout / Payments

Ready-for-checkout Modal supports:
- service subtotal
- paid
- balance
- member wallet
- points
- add single products
- add product bundles

Product fuzzy search starts immediately while typing; no Enter required. Search by:
- product name
- bundle name
- Product Code
- SKU
- Barcode
- category
- Tunaipro ID

Search result should show image, type, code, category, selling price and current stock.

Counter add-on sales default to the current counter salesperson for product performance/commission unless an authorized override chooses another salesperson.

Payments support current/future contract:
- Cash
- Card
- E-Wallet / DuitNow/QR where configured
- member stored value
- mixed/split payment, including partial member wallet + another payment method

Order is finally completed only after full payment. Cash change must calculate correctly. Product stock should be formally reduced only after successful checkout transaction.

Checkout Modal must fit screen, have scrollable content and usable actions on mobile/PWA.

---

# J. Customers and Membership

Customer & Member page supports create, edit, fuzzy search, membership, spend, points, Experience, stored value and visit count.

UI should stay modern; avoid the old cramped narrow-list + giant detail style when a cleaner card/grid layout is available.

Membership:
- starts Level 1.
- spending adds Experience and Points.
- redeeming Points does not reduce Experience.
- member wallet/store balance can pay for services/products.
- owner can configure level names and Experience thresholds.
- system auto-upgrades levels.
- membership top-up does not require salesperson.
- retail product sale may specify salesperson and product commission.

---

# K. KPI — Employee-first v13.5.0

## K1. KPI landing page
Owner enters KPI and first sees **employee cards/names**, not a giant generic KPI table.
Click an employee → employee KPI detail.

## K2. KPI Templates
Owner can maintain reusable KPI types such as:
- service/revenue performance
- product sales
- total sales
- completed service count
- customer count
- average ticket
- requested/customer-specified count
- training completion
- manual KPI

Disable/archive a Template without deleting historical KPI.

## K3. Per-employee KPI tasks
Inside employee KPI detail, owner presses **Set KPI Task** and chooses template/month, target and bonus.
Lifecycle target:
`Active → Achieved → Reviewed → Bonus Paid → Archived/Locked`.
System-computable KPI should auto-achieve once target is reached. Bonus Paid locks historical payroll data from casual editing. Disabled/leaving employees keep KPI history.

---

# L. Training Center — Category + Role + Media v13.5.0

Owner/Manager can create a training course with:
- category
- target positions/roles
- title/topic
- short intro
- course body/content
- video/media URL
- cover / teaching photo
- estimated duration
- version label
- Required flag
- Published / Archived state

Photos use Supabase Storage, not PostgreSQL binary.
Video should normally be external streaming or separate Storage URL; do not store large video binary in database rows.

Employee only sees courses whose target role includes their app role, plus courses targeted to all roles. Employee view groups courses by category.

Progress lifecycle:
`Not Started → In Progress → Completed`, with Started At / Progress % / Completed At.
Training completion can feed KPI.

---

# M. Service Catalog — Folder Categories v13.5.0

Service Project management supports explicit **Service Categories**.
- categories appear as folder-like cards/entries.
- clicking a folder shows services in that category.
- owner can create/edit/disable category.
- service create/edit requires choosing category.
- historical services are retained; disabling category does not erase historical visits.
- New Order uses category-first service selection.

Service fields include name, category, selling price, estimated duration, assistant eligibility, active state and future service metadata where needed.

---

# N. Products & Inventory

The Hub keeps separate concepts/entries:
1. Inventory Items
2. Retail/Sales Products
3. Product Bundles
4. Customer Product Showcase

They must not be collapsed into one confusing table.

## N1. Inventory — v13.5.0 CRUD
Inventory supports:
- **+ Add Inventory** button
- add through small Modal
- edit through small Modal
- stock purchase/adjustment through small Modal
- delete action means safe archive/disable when history exists, not destructive history deletion
- current quantity
- cost
- unit: pcs/ml/g/bottle/tube/etc.
- low-stock/reorder level
- SKU / barcode / category / purpose
- photo

Stock truth is ledger-based, not a single unexplained mutable quantity. Movement examples: Opening, Purchase, Service Usage, Product Sale, Return, Damage, Adjustment, Transfer.

## N2. Image / Storage contract — v13.5.0 locked
- accept JPG / PNG / WebP.
- server attempts resize + WebP compression before upload.
- target max dimension currently 1400px and WebP quality approximately 78 when PHP GD is available.
- compressed object is stored in Supabase **Storage bucket `salonos-media`**.
- PostgreSQL stores only the Storage URL/path; image bytes are not stored in database rows.
- bucket file limit is around 2 MB for current build.
- if host cannot compress, user is asked to upload an image <=2 MB.

This prevents product photos from consuming PostgreSQL database size like binary blobs.

## N3. Inventory materials during service
Employee can search material → quantity → confirm → stock ledger decrement linked to visit/order. Wrong consumption must support Undo/Reverse with audit trail (deep workflow still requires completion QA).

## N4. Sales products
Fields include name, Product Code, category, description, selling price, cost, barcode, image, active state and linked inventory item where applicable.
Customer-facing display must never expose cost.

## N5. Product bundles
Bundle contains multiple component inventory/products with quantities. Selling a bundle deducts components atomically after successful payment. Available bundle quantity should be limited by the scarcest component.

---

# O. Tunaipro Import and Branch Transfer

Tunaipro import remains owner self-service, not developer manual import:
`Upload CSV → Preview → field validation → Confirm Import`.
Types:
- Product
- Package
- Service
- Member

Member import may include name, phone, Join Date, Birthday, Ethnicity, ID/Passport, Email, Address, Source, VIP/VVIP/VVVIP. Invalid legacy data must not be silently written.

Branch migration/export targets products, bundles, inventory, services, members, employees and media references. Preferred package design: ZIP + CSV + Images/Storage mapping.

---

# P. Commission — v13.5.0

## P1. Commission Hub navigation
The Commission Hub **must not contain a duplicate “Employee Performance” shortcut** because Employee Performance already exists in the main sidebar.
Commission Hub contains actual commission management, mainly:
- Performance Commission Tiers
- Employee Monthly Commission

## P2. Performance tiers — v13.5.0
Use **+ Add Stage** button → small Modal.
Each stage fields:
- tier/stage name
- minimum monthly performance
- maximum monthly performance (blank = no upper limit)
- commission %
- active state

Example: RM0–4999 = 5%, RM5000–9999 = 8%, RM10000–14999 = 10%, RM15000+ = 12%.

## P3. Employee monthly commission — v13.5.0
Monthly page shows each employee:
- service commission
- product commission
- base total commission
- optional manual Rate
- final commission amount

Each employee has **Adjust** button → small Modal to set override Rate, final amount and notes for a month. Manual override is stored separately and must not rewrite the underlying ledger.

## P4. Performance vs revenue
Project Contribution allocates employee performance only; it does not change store revenue.
Monthly performance = service performance + attributed product sales.
Commission tiers choose rate by monthly performance. Authorized per-order/manual override must not later be overwritten by automatic recalculation.

Staff can see own performance/estimated commission but cannot edit commission rules.

---

# Q. Employee Performance

Separate sidebar module remains the place to inspect staff performance. It is not duplicated inside Commission Hub.

Target metrics:
- service performance
- product sales
- total performance
- completed orders/projects
- customers served
- requested/customer-specified count
- appointments
- Walk-ins
- product units sold
- estimated/final commission
- KPI

Supports day/month/year where required.

---

# R. Business Analytics / Reports

Business Analytics is an operating report, not a dashboard full of decorative pie charts.
Supports Day / Month / Year + current branch context.

Top metrics include:
- Revenue
- completed orders
- customers
- Avg Ticket
- appointment count
- Walk-in count
- product revenue
- service revenue
- material cost
- product cost

Use L-shaped/table-style operating reports for periods. Further analysis:
- service performance: count, revenue, share
- product performance: quantity, revenue, cost, gross profit, seller
- appointment performance
- employee drilldown

Revenue is counted once regardless of multi-worker Contribution.

Exports:
- KPI
- employee performance
- employee commission
- store operations
- revenue
- appointments
- product sales
- customers
- material cost

Excel/CSV must be professionally arranged, not raw database-column dumps.

---

# S. Order History

- records remain after midnight.
- filters: day/month/year/custom date.
- pagination; no hard maximum of 500 records.
- editing after completion only with permission and audit/version behavior.
- date display is **DD/MM/YYYY** system-wide.

---

# T. WhatsApp Business

Each branch can bind its own WhatsApp Business configuration:
- Phone Number ID
- Access Token
- Template
- enabled state
- reminder minutes

Appointment reminder examples: 30/60/120/custom minutes before.
Delivery log should show sent/failed, time, customer and appointment reference. Real API scheduling remains a deeper integration task until fully wired.

---

# U. Language, PWA and Mobile

Languages:
- Chinese
- English
Only UI labels translate; customer/product/staff user-entered names do not auto-translate.

PWA install:
- Android/Chrome/Edge: custom Install App button invokes native PWA prompt where available.
- iPhone: Safari Share → Add to Home Screen instructions; webpages cannot force silent install.

PWA update:
- users must not need to uninstall/re-add App after update.
- versioned Service Worker cache should refresh static resources.
- avoid auto-refreshing while a form/order is unsaved.

Mobile:
- prevent accidental page zoom.
- input fields should not cause browser zoom.
- use safe-area for notch/Dynamic Island.
- touch targets large enough.
- Modals and Checkout Modal scroll within viewport.

---

# V. Visual / UI Contract

- One coherent UI language across all pages.
- Premium dark, Midnight Navy/black/deep gray, Gold/Silver/Ice Blue accents, restrained Green/Amber/Red status colors.
- modern SaaS, Apple-like depth/glass direction without noisy decoration.
- rounded cards.
- modal-first interactions for inventory, service, checkout, employee management and other compact edits.
- sidebar independently scrolls.
- no sudden large white backgrounds in dark mode.
- v12.4.4 locked CSS/JS baseline must not be casually rewritten during Supabase migrations.
- current app icon is the selected black rounded fluid S/wave icon; do not replace it with the old OS icon without explicit instruction.

---

# W. Runtime / Database Contract Rule

Repeated raw PostgREST errors such as PGRST202/PGRST204 or schema mismatches must be caught before normal business use.
- PHP should call version-stable adapter RPCs when historical RPC signatures differ.
- `system-test.php` must test Runtime Contract before deployment.
- normal users should receive a friendly sync message rather than raw database payload/UUID/failing-row details.
- no automatic fallback to InfinityFree MySQL.
- additive migration patches must preserve business history.

v13.5.0 introduces `v1350_runtime_contract_status()` to validate the new service-category, training-role, inventory-unit, media Storage and monthly commission override contracts.

---

# X. v13.5.0 Current Change Set

The v13.5.0 build specifically implements/integrates these requested changes:
1. Dashboard Quick Actions removed/replaced by store data icon tiles.
2. Returning non-member customer reuse by normalized phone to avoid duplicate directory cards.
3. KPI landing becomes employee-first; owner enters an employee to set KPI tasks.
4. Training gains category, target roles, cover image, video/media URL and role-filtered employee reading.
5. Service categories become folder-like records; New Order chooses category before service.
6. Inventory has Add/Edit/Stock Adjustment/Archive button + small Modal operations.
7. Inventory/Product/Bundle images upload to compressed Supabase Storage rather than PostgreSQL binary.
8. Commission Hub removes duplicate Employee Performance shortcut.
9. Commission Tier page has Add Stage button with min/max/% fields.
10. Employee Monthly Commission adds Adjust controls and monthly override records.
11. v13.5 Runtime Contract and system test cover these new schema dependencies.
12. This Complete Product Specification is packaged with the build as the future reference source.

---

# Y. Important Pending Deep QA / Non-Fake Completion List

The existence of UI/spec does not mean every deep workflow is already production-certified. Before selling the SaaS, complete end-to-end acceptance for at least:
- exact concurrent Walk-in/Appointment collision engine.
- signature revision history after order changes.
- material usage reverse/audit flow.
- true mixed/split payment including wallet.
- bundle component deduction after successful transaction and refund behavior.
- automatic KPI achievement + reviewed/bonus-paid locking.
- final commission payout/locking and refund reversal.
- complete role/custom-role permission matrix.
- WhatsApp real API scheduler/delivery logs.
- image/private media policy review if product/customer photos need privacy rather than public bucket.
- cross-tenant test with Owner A and Owner B proving zero data leakage.
- branch account, Creator code, trusted-device, subscription expiry and PWA mobile acceptance.
- backup/restore, audit, rate limiting and production security review.

**Production gate:** do not call the build sell-ready until these transaction/security tests pass.

---

# Z. v13.5.2 Confirmed Requirement Lock

This section records the latest confirmed behavior so future builds do not require the owner to rewrite the same requirements again.

## Z1. Permission roles / positions
- Permission Center must support **Add Position / Add Role**.
- Owner can create custom permission roles such as Senior Stylist, Supervisor, Cashier, Colorist, etc.
- Custom roles appear in Employee Management under the employee permission-role selector.
- Custom roles can be assigned their own permission matrix.
- Custom roles also appear as target roles in Training Center.
- Custom roles can be deleted.
- Deleting a custom role must not delete employee history. Employees currently using that role are safely reassigned to the base Staff role.
- Core system roles remain protected so the app cannot accidentally destroy required permission structure.
- Phone-login employees must receive the permission matrix for their actual role through the employee-session Supabase contract; permissions must not silently fall back to defaults merely because the employee has no Supabase Auth password.

## Z2. New Order customer search
- A customer visible under **顾客与会员** in the current branch must also be searchable from New Order.
- Search is fuzzy and immediate.
- Search sources: customer name, normalized phone number, membership number, email and ID/passport where available.
- Search uses the same current-store de-duplicated customer dataset as the customer directory.
- Existing non-members are selectable and must not create a second customer profile.
- Search may begin from the first typed character; no Enter key is required.

## Z3. Customer/member save JSON contract
- Customer profile edit, upgrade-to-member and wallet actions that are submitted through AJAX must return JSON to AJAX callers.
- They must not return an HTML redirect page to JavaScript expecting JSON.
- Normal non-AJAX form submissions may still redirect normally.
- The user must never see browser errors such as `Unexpected token '<' ... is not valid JSON`.
- Errors must be returned as readable SalonOS messages, not raw HTML or raw Supabase internals.

## Z4. Delete / archive master data
The system must not force unused configuration records to pile up forever.

### Services
- Service items have an explicit Delete action.
- If a service has never been referenced by historical orders, it can be physically deleted.
- If historical orders reference it, Delete becomes safe archive/disable so old order snapshots remain valid.
- Archived services disappear from the normal service list and from New Order.
- Management may deliberately open an Archived view when needed.

### Products
- Sellable products have an explicit Delete action.
- Unused products may be physically deleted.
- Products referenced by inventory/sales/history are archived instead of destroying ledger/history.
- Archived products disappear from the normal product list and checkout/product search.
- Management may deliberately open an Archived view when needed.

### Inventory
- Inventory already uses Add / Edit / Stock Adjustment / Delete-Archive modal actions.
- Inventory history is ledger-based and must not be destroyed merely to make the list cleaner.

### Product bundles
- Product bundles have an explicit Delete action.
- Deleting a bundle removes the bundle definition and its component mapping without deleting the underlying inventory products.

### Permission roles
- Custom permission roles can be deleted as described in Z1.

## Z5. List cleanliness
- Normal operating lists should show active/usable records.
- Archived/disabled records belong in an explicit Archived view instead of permanently cluttering the main workflow.
- History safety has priority over physical deletion when a record is already referenced by orders, payments, inventory ledger, KPI, commission or other historical records.

## Z6. UI / UX persistence
- All above actions use the established dark Midnight / Gold SalonOS visual language.
- Destructive actions use confirmation Modal flows rather than accidental one-click deletion.
- Mobile Modal scrolling, safe-area behavior and v12.4.4 UI lock remain mandatory.

---

# AA. v13.5.3 Confirmed Customer / Member / Product Flow Lock

This section is additive to all previous requirements. It specifically records the latest confirmed behavior so later database/UI work must not simplify it again.

## AA1. New Order customer/member search must match the directory
- A customer/member shown in **顾客与会员** for the current branch must be discoverable in **新建顾客订单**.
- New Order search uses the same current-store, phone-de-duplicated customer dataset as the customer directory.
- Search is immediate; no Enter key is required.
- Search supports name, normalized phone, member number, Email and ID/Passport where data exists.
- Existing non-members are selectable exactly like members; selecting them must reuse the existing customer ID instead of creating another customer profile.
- The implementation must not accidentally iterate the wrapper object (`customers/summary/levels`) as though it were a customer list. The canonical rows are `dataset['customers']`.

## AA2. Member retail purchase inside 顾客与会员
For an active member, the member workspace includes a real **会员购买门店产品** workflow.

Flow:
1. choose a Product Category folder;
2. fuzzy-search products in that category, or show that category's products immediately;
3. choose a product;
4. show image, name, code/SKU, category, price and current stock;
5. choose quantity;
6. choose how much Member Wallet value to use;
7. pay the remainder by Cash, Card or E-Wallet;
8. confirm purchase;
9. save a member retail sale record and item snapshot;
10. update Wallet / Experience / Points / Inventory only through the Supabase transaction contract.

Rules:
- Full Member Wallet payment is allowed.
- Partial Wallet + Cash/Card/E-Wallet is allowed.
- The external amount must equal the remaining balance.
- Member retail history must show the purchased product name(s), quantity, total, payment split and time instead of showing only an unexplained total.
- Product cost must never be exposed in this customer-facing/member-sales UI.

## AA3. Product category folders
Products & Inventory now has a real product-category folder layer shared by:
- Inventory Items;
- Retail / Sales Products;
- Product Bundles.

Owner/Manager can:
- add a category folder;
- edit category name/description/sort order;
- archive a category safely.

Normal operating screens show active categories. Product selection should behave like Service selection: **choose category first, then choose/search the item inside that category**.

## AA4. Inventory / Retail Product / Bundle modal-first UX
The following pages must not keep a permanent giant create form open on the page:
- Inventory Management;
- Sales Products;
- Product Bundles.

Each page has visible buttons such as **＋ 增加库存 / ＋ 增加产品 / ＋ 增加配套**. Clicking a button opens a small dark SalonOS modal. Edit uses the same modal with existing data populated.

Image rules remain unchanged:
- JPG / PNG / WebP input;
- resize/compress before upload where supported;
- object stored in Supabase Storage `salonos-media`;
- PostgreSQL stores only path/URL metadata, not image binary/Base64.

## AA5. Service Board checkout add-on products
In **服务现场 → order modal → 待结账**:
- product selection is no longer a large native dropdown;
- user chooses a product category, then fuzzy-searches products in that category;
- search supports product name, SKU and Barcode (and category context);
- result suggestions show image/name/code/category/price/current stock;
- selected product preview is visible before adding;
- after adding, the order modal must visibly show a **PRODUCT ITEMS** section with product name, SKU, quantity, unit price and line total;
- the user must never see the order total increase while having no indication which product was added;
- service total + product total form the displayed order amount;
- inventory is formally deducted only after successful payment/checkout, not merely when the product is added to the pending order.

## AA6. Product Bundles management
- Product Bundles retain their own management page and category folder.
- Add/Edit Bundle is button → modal.
- Bundle modal includes name, SKU/code, category, sale price, image and component products/quantities.
- Deleting a bundle definition must not delete its underlying inventory products.
- Full bundle sale/component deduction remains subject to end-to-end transactional QA before production certification.

## AA7. v13.5.3 runtime contract
The current web build expects the additive v13.5.3 contract including:
- `v13_product_categories`;
- `products.category_id`;
- category metadata on product bundles;
- `v13_member_product_sales`;
- `v13_member_product_sale_items`;
- `v1353_member_product_purchase(...)`;
- `v1353_employee_product_search(...)`;
- `v1353_runtime_contract_status()`.

`system-test.php` must detect these dependencies before real use. Missing contract/schema details must be surfaced as a readable SalonOS contract-sync instruction, not raw PGRST/HTML/JSON parser noise.

## AA8. Regression rule
All v13.5.3 changes must retain earlier confirmed architecture:
- only two PWAs: Creator + SalonOS;
- Supabase Only business data;
- strict Organization/Store isolation;
- v12.4.4 UI/UX visual baseline;
- four-step Order Wizard;
- Team Appointment Board 09:00–00:00;
- Services/KPI/Training/Commission/Analytics requirements;
- custom roles and safe delete/archive rules;
- modal scrolling and mobile safe-area behavior;
- no return to InfinityFree MySQL business-data fallback.



# v13.5.4 Employee Workspace / Permission / Performance Addendum

- System default employee roles are not permanent. Owner may delete a default role or a custom role. At least one employee role must remain. Employees assigned to a deleted role are safely moved to another remaining role; historical orders, KPI, performance, commission and training data remain unchanged.
- Employee mobile/PWA workspace does not show the bottom shortcut bar. Navigation is opened from the hamburger side menu only.
- Employee menu entries are permission-driven. A feature appears only when the current role permission matrix grants it. Direct URL access is also blocked when the role lacks permission.
- `顾客与会员` is available in the employee workspace whenever the role has `customers.view` or `customers.manage`. It reads only the current organization + current store through an employee-session RPC; no cross-tenant data is exposed.
- Employee performance is a ranking page, not a plain table. Rank #1/#2/#3 receive podium cards; remaining staff are shown in rank order. Ranking score = service performance contribution + attributable product sales, without duplicating store revenue.
- Performance supports Day / Month / Year filters and an anchor date. Clicking an employee opens detailed period metrics: total performance, service contribution, product sales, estimated commission, services, customers, appointments, Walk-ins, product units and activity detail.
- An employee may upload his/her own avatar. The image is center-cropped and compressed, then uploaded to Supabase Storage `salonos-media`; PostgreSQL stores only the Storage object path. Employee custom sessions receive a 5-minute random upload ticket so anonymous Storage writes are restricted to that exact avatar path.
- The employee avatar in the top-right header is clickable and opens a small profile modal with avatar upload and a clear `退出登录` action.
