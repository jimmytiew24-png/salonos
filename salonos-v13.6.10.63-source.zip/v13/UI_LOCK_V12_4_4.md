# SalonOS v13.4.4 UI LOCK

The visual CSS/UIUX baseline is copied byte-for-byte from SalonOS v12.4.4_PWA_Fixed_Scale_No_Input_Zoom.
Supabase code may add compatibility files, but these locked UI files must not be edited during backend migration.

## Locked files
- `assets/app.css`  SHA256 `348b62b1c485f71ecd767b9cd77202bd85b0dd80679ef105b9ae4e3db1badc2f`
- `assets/luxe.css`  SHA256 `16517f779d6b85b50404d4020c88d484c5b03c30413a0fb34b4ef1f428423617`
- `assets/pwa.css`  SHA256 `eaf90eb76b4de1ddf8c64c8c6b510b11048835c70fc409ddfcd1516a00e0ae14`
- `assets/app.js` starts from v12.4.4 but its order-wizard behavior is intentionally adapted in v13.4.4 so both Walk-in and 预约 use the required 4-step flow.
- `assets/pwa-install.js`  SHA256 `ab6d8f5ecab72a11277a40b8f61e5b04887086b57704dc415da0404eba8cfa0e`
- `creator/assets/creator.css`  SHA256 `7e6298330f66c16f57b8e9be767386b2055fc295eeea6670a1e1d44186c08c58`
- `creator/assets/creator-live.js`  SHA256 `eb372cf8806c1e044867acf861e63b3f2f8884502809df6891b8c43157ceb216`

## Rule
- Database/backend changes go into Supabase PHP/RPC modules.
- New v13-only markup styles go into `assets/v13-supabase-compat.css`.
- Do not patch light/dark surfaces by rewriting the v12.4.4 baseline CSS.
- If a UI change is intentionally requested later, update this lock deliberately.