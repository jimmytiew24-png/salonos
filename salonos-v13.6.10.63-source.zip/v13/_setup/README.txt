SalonOS v13.5.3 setup

Preferred upgrade path from v13.5.2:
RUN_ONCE_V13_5_3_PRODUCT_MEMBER_SEARCH.sql

If you are unsure which earlier v13.5.x database patches were already run, use:
RUN_ONCE_V13_5_3_CUMULATIVE_RUNTIME.sql

The cumulative SQL includes the known v13.4.x runtime contracts, v13.5.0 Product UX contract, v13.5.2 permission-role bridge, and the v13.5.3 Product / Member / Customer Search contract.
It is designed to be additive/idempotent and does not intentionally delete historical business data.

Older SQL files remain in _setup as version history / recovery references. Do not replay them one by one when the v13.5.3 cumulative file is used.

v13.6.6: RUN_ONCE_V13_6_6_AI_REPLY_CONVERSATION_STATE.sql
Adds branch-scoped WhatsApp send config, auto-reply audit, outbound reply linkage and multi-turn appointment reply support.


v13.6.7: RUN_ONCE_V13_6_7_APPOINTMENT_DRAFT_CONFIRM.sql
Adds customer-provided profile collection, durable appointment drafts, explicit confirmation/cancellation, final availability re-check, canonical SalonOS booked-appointment creation, and booking audit history.
Run after v13.6.6.

v13.6.8:
- RUN_ONCE_V13_6_8_LIFECYCLE_INTELLIGENCE_REMINDER.sql
- Deploy whatsapp-reminder-worker and schedule it with Supabase Cron.


v13.6.9:
- RUN_ONCE_V13_6_9_CANCEL_RESCHEDULE_EXISTING_CUSTOMER.sql
- Deploy updated whatsapp-ai-worker only. Existing reminder worker/Cron remain unchanged.
- Adds guarded cancel/reschedule drafts, final availability recheck, reminder rebase/suppression, and returning-customer continuity.

v13.6.9.3:
- No new SQL after v13.6.9.
- Deploy the packaged whatsapp-ai-worker to enable deterministic cancel/reschedule command routing.

v13.6.10.9:
- Run RUN_ONCE_V13_6_10_9_FIRST_TOUCH_UNIQUE_CUSTOMER_ANALYTICS.sql once.
- Adds immutable first-touch WhatsApp customer attribution + unique phone dedupe.
- No Edge Function redeploy required.

v13.6.10.10:
- No new SQL when upgrading from v13.6.10.9.
- No Edge Function redeploy required.
- Marketing Analytics now follows the unique first-touch customer cohort through booking, arrival, repeat, stylist loyalty and attributed revenue.


v13.6.10.11:
- No new SQL when upgrading from v13.6.10.10.
- No Edge Function redeploy required.
- Adds simplified Owner Snapshot + small modal details to 经营分析.
- v13.6.10.9 First Touch SQL remains the database prerequisite.


v13.6.10.12:
- Media Content & Tracking Link Management Center.
- Small modal create/edit for Profile/Reel/Post/Story.
- Copy/Test/Modify/Disable actions.
- No new SQL; no Edge Function redeploy.
