-- SalonOS v13.1.1 FINAL HARDENED ONE-SHOT SUPABASE CUTOVER
-- Run this ONE file in Supabase SQL Editor. It is additive and does NOT delete business data.
-- InfinityFree remains hosting only.

begin;
set local statement_timeout = '0';

DO $$
DECLARE
  req text;
  missing text[] := ARRAY[]::text[];
BEGIN
  FOREACH req IN ARRAY ARRAY[
    'organizations','profiles','organization_members','stores','store_members','customers','membership_levels','memberships',
    'member_wallet_ledger','member_loyalty_ledger','employees','employee_compensation','employee_stores','services','visits',
    'visit_recipients','visit_service_items','visit_service_workers','visit_service_signoffs','payments','payment_items','products',
    'inventory_stock_movements','employee_commission_ledger','service_performance_ledger','service_commission_settings','service_commission_tiers'
  ] LOOP
    IF to_regclass('public.'||req) IS NULL THEN missing := array_append(missing,req); END IF;
  END LOOP;
  IF cardinality(missing)>0 THEN
    RAISE EXCEPTION 'SalonOS base Supabase schema is incomplete. Missing: %',array_to_string(missing,', ');
  END IF;
END $$;

-- -----------------------------------------------------------------------------
-- v13.1.1 compatibility preflight
-- Some earlier SalonOS schemas have UUID primary keys but do not have the
-- redundant composite UNIQUE keys required by later tenant-safe foreign keys.
-- These indexes are safe because id is already globally unique.
-- -----------------------------------------------------------------------------
create unique index if not exists v13_compat_stores_org_id_uidx
  on public.stores(organization_id,id);
create unique index if not exists v13_compat_employees_org_id_uidx
  on public.employees(organization_id,id);
create unique index if not exists v13_compat_products_org_id_uidx
  on public.products(organization_id,id);

create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

-- ===== SUPABASE_V13_FOUNDATION.sql =====
-- SalonOS v13.0.0 · Supabase-Only Foundation
-- Run this entire file once in Supabase Dashboard -> SQL Editor -> New query -> Run.
-- It does NOT delete existing SalonOS business data.

create extension if not exists pgcrypto;

-- -----------------------------------------------------------------------------
-- Creator / SaaS control plane now lives in Supabase too.
-- -----------------------------------------------------------------------------
create table if not exists public.creator_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  status text not null default 'active' check (status in ('active','disabled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.saas_subscriptions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid null,
  subscriber_user_id uuid null references auth.users(id) on delete set null,
  subscription_type text not null default 'owner' check (subscription_type in ('owner','branch')),
  plan_code text not null default 'monthly' check (plan_code in ('monthly','annual','biennial')),
  amount_rm numeric(12,2) not null default 100,
  billing_months integer not null default 1 check (billing_months in (1,12,24)),
  status text not null default 'active' check (status in ('pending','active','past_due','suspended','expired','cancelled')),
  starts_at timestamptz null,
  expires_at timestamptz null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_saas_subscriptions_org_status on public.saas_subscriptions(organization_id,status);
create index if not exists idx_saas_subscriptions_expiry on public.saas_subscriptions(expires_at,status);
create unique index if not exists uniq_saas_owner_subscription
  on public.saas_subscriptions(organization_id, subscription_type)
  where subscription_type='owner' and status in ('pending','active','past_due','suspended');

-- Add same-org store FK after the table exists. Ignore if the exact constraint already exists.
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname='saas_subscriptions_org_store_fkey'
  ) then
    alter table public.saas_subscriptions
      add constraint saas_subscriptions_org_store_fkey
      foreign key (organization_id, store_id)
      references public.stores(organization_id,id)
      on delete cascade;
  end if;
end $$;

create table if not exists public.saas_activation_codes (
  id uuid primary key default gen_random_uuid(),
  purpose text not null check (purpose in ('owner_signup','device_login','branch_signup')),
  code_hash text not null unique,
  code_hint text not null,
  label text,
  target_user_id uuid null references auth.users(id) on delete cascade,
  target_organization_id uuid null references public.organizations(id) on delete cascade,
  target_store_id uuid null,
  target_email text null,
  plan_code text null check (plan_code is null or plan_code in ('monthly','annual','biennial')),
  amount_rm numeric(12,2) null,
  billing_months integer null,
  status text not null default 'pending' check (status in ('pending','used','expired','cancelled')),
  expires_at timestamptz not null,
  used_at timestamptz null,
  used_by_user_id uuid null references auth.users(id) on delete set null,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);
create index if not exists idx_saas_codes_purpose_status_expiry on public.saas_activation_codes(purpose,status,expires_at);

create table if not exists public.saas_trusted_devices (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid null,
  user_id uuid not null references auth.users(id) on delete cascade,
  device_id text not null,
  device_name text,
  token_hash text not null,
  user_agent text,
  status text not null default 'active' check (status in ('active','revoked')),
  first_authorized_at timestamptz not null default now(),
  last_seen_at timestamptz null,
  revoked_at timestamptz null,
  created_at timestamptz not null default now(),
  unique(user_id,device_id)
);
create index if not exists idx_saas_devices_org_status on public.saas_trusted_devices(organization_id,status);

create table if not exists public.creator_audit_logs (
  id bigint generated always as identity primary key,
  creator_user_id uuid null references auth.users(id) on delete set null,
  organization_id uuid null references public.organizations(id) on delete set null,
  action_name text not null,
  detail text,
  ip_address text,
  created_at timestamptz not null default now()
);
create index if not exists idx_creator_audit_created on public.creator_audit_logs(created_at desc);

-- -----------------------------------------------------------------------------
-- Helper functions
-- -----------------------------------------------------------------------------
create or replace function public.is_creator_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1 from public.creator_admins ca
    where ca.user_id = auth.uid() and ca.status='active'
  );
$$;

revoke all on function public.is_creator_admin() from public;
grant execute on function public.is_creator_admin() to authenticated;

create or replace function public.salonos_plan_months(p_plan text)
returns integer
language sql
immutable
as $$
  select case lower(coalesce(p_plan,''))
    when 'annual' then 12
    when 'biennial' then 24
    else 1
  end;
$$;

create or replace function public.salonos_plan_amount(p_plan text)
returns numeric
language sql
immutable
as $$
  select case lower(coalesce(p_plan,''))
    when 'annual' then 1000::numeric
    when 'biennial' then 2000::numeric
    else 100::numeric
  end;
$$;

create or replace function public.salonos_plan_expiry(p_plan text, p_start timestamptz default now())
returns timestamptz
language sql
stable
as $$
  select p_start + make_interval(months => public.salonos_plan_months(p_plan));
$$;

create or replace function public.salonos_new_code(p_prefix text)
returns text
language plpgsql
volatile
as $$
declare
  raw text;
begin
  raw := upper(substr(encode(gen_random_bytes(8),'hex'),1,8));
  return upper(p_prefix) || '-' || substr(raw,1,4) || '-' || substr(raw,5,4);
end;
$$;

-- -----------------------------------------------------------------------------
-- Creator actions
-- -----------------------------------------------------------------------------
create or replace function public.creator_generate_owner_code(
  p_plan_code text default 'monthly',
  p_label text default null
)
returns table(code text, expires_at timestamptz, amount_rm numeric, billing_months integer)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_code text;
  v_exp timestamptz := now() + interval '5 minutes';
  v_amount numeric;
  v_months integer;
begin
  if auth.uid() is null or not public.is_creator_admin() then
    raise exception 'Creator permission required';
  end if;
  if lower(coalesce(p_plan_code,'')) not in ('monthly','annual','biennial') then
    raise exception 'Invalid plan';
  end if;
  v_code := public.salonos_new_code('ACT');
  v_amount := public.salonos_plan_amount(p_plan_code);
  v_months := public.salonos_plan_months(p_plan_code);

  insert into public.saas_activation_codes(
    purpose,code_hash,code_hint,label,plan_code,amount_rm,billing_months,status,expires_at,created_by
  ) values (
    'owner_signup',encode(digest(upper(v_code),'sha256'),'hex'),right(v_code,4),nullif(trim(p_label),''),
    lower(p_plan_code),v_amount,v_months,'pending',v_exp,auth.uid()
  );

  insert into public.creator_audit_logs(creator_user_id,action_name,detail)
  values(auth.uid(),'owner_code.generated',coalesce(p_label,'') || ' · ' || lower(p_plan_code));

  return query select v_code,v_exp,v_amount,v_months;
end;
$$;
revoke all on function public.creator_generate_owner_code(text,text) from public;
grant execute on function public.creator_generate_owner_code(text,text) to authenticated;

create or replace function public.creator_generate_device_code(
  p_target_user_id uuid,
  p_label text default null
)
returns table(code text, expires_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_code text;
  v_exp timestamptz := now() + interval '5 minutes';
  v_org uuid;
begin
  if auth.uid() is null or not public.is_creator_admin() then
    raise exception 'Creator permission required';
  end if;

  select om.organization_id into v_org
  from public.organization_members om
  where om.user_id=p_target_user_id and om.status='active'
    and om.role in ('owner','manager')
  order by case when om.role='owner' then 0 else 1 end
  limit 1;
  if v_org is null then raise exception 'Target owner is not active'; end if;

  v_code := public.salonos_new_code('DVC');
  insert into public.saas_activation_codes(
    purpose,code_hash,code_hint,label,target_user_id,target_organization_id,status,expires_at,created_by
  ) values (
    'device_login',encode(digest(upper(v_code),'sha256'),'hex'),right(v_code,4),nullif(trim(p_label),''),
    p_target_user_id,v_org,'pending',v_exp,auth.uid()
  );

  insert into public.creator_audit_logs(creator_user_id,organization_id,action_name,detail)
  values(auth.uid(),v_org,'device_code.generated',p_target_user_id::text);

  return query select v_code,v_exp;
end;
$$;
revoke all on function public.creator_generate_device_code(uuid,text) from public;
grant execute on function public.creator_generate_device_code(uuid,text) to authenticated;

create or replace function public.creator_generate_branch_code(
  p_organization_id uuid,
  p_branch_name text,
  p_login_email text,
  p_plan_code text default 'monthly'
)
returns table(code text, expires_at timestamptz, amount_rm numeric, billing_months integer)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_code text;
  v_exp timestamptz := now() + interval '5 minutes';
  v_amount numeric;
  v_months integer;
begin
  if auth.uid() is null or not public.is_creator_admin() then
    raise exception 'Creator permission required';
  end if;
  if not exists(select 1 from public.organizations where id=p_organization_id) then
    raise exception 'Organization not found';
  end if;
  if trim(coalesce(p_branch_name,''))='' then raise exception 'Branch name required'; end if;
  if trim(coalesce(p_login_email,''))='' then raise exception 'Branch login email required'; end if;
  if lower(coalesce(p_plan_code,'')) not in ('monthly','annual','biennial') then raise exception 'Invalid plan'; end if;

  v_code := public.salonos_new_code('BRN');
  v_amount := public.salonos_plan_amount(p_plan_code);
  v_months := public.salonos_plan_months(p_plan_code);

  insert into public.saas_activation_codes(
    purpose,code_hash,code_hint,label,target_organization_id,target_email,plan_code,amount_rm,billing_months,status,expires_at,created_by
  ) values (
    'branch_signup',encode(digest(upper(v_code),'sha256'),'hex'),right(v_code,4),trim(p_branch_name),
    p_organization_id,lower(trim(p_login_email)),lower(p_plan_code),v_amount,v_months,'pending',v_exp,auth.uid()
  );

  insert into public.creator_audit_logs(creator_user_id,organization_id,action_name,detail)
  values(auth.uid(),p_organization_id,'branch_code.generated',trim(p_branch_name)||' · '||lower(trim(p_login_email)));

  return query select v_code,v_exp,v_amount,v_months;
end;
$$;
revoke all on function public.creator_generate_branch_code(uuid,text,text,text) from public;
grant execute on function public.creator_generate_branch_code(uuid,text,text,text) to authenticated;

-- -----------------------------------------------------------------------------
-- Owner signup: Supabase becomes the ONLY source of truth.
-- -----------------------------------------------------------------------------
create or replace function public.redeem_owner_activation_code(
  p_code text,
  p_organization_name text,
  p_full_name text,
  p_phone text default null
)
returns table(organization_id uuid, store_id uuid, subscription_id uuid)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_code public.saas_activation_codes%rowtype;
  v_org uuid;
  v_store uuid;
  v_sub uuid;
  v_start timestamptz := now();
begin
  if v_user is null then raise exception 'Login required before redeeming ACT code'; end if;
  if trim(coalesce(p_organization_name,''))='' then raise exception 'Organization name required'; end if;
  if trim(coalesce(p_full_name,''))='' then raise exception 'Owner name required'; end if;
  if exists(select 1 from public.organization_members where user_id=v_user and status='active') then
    raise exception 'This account already belongs to an active SalonOS organization';
  end if;

  select * into v_code
  from public.saas_activation_codes
  where purpose='owner_signup'
    and code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex')
    and status='pending'
    and used_at is null
    and expires_at>=now()
  for update;
  if v_code.id is null then raise exception 'ACT code is invalid, used or expired'; end if;

  insert into public.organizations(name,status)
  values(trim(p_organization_name),'active')
  returning id into v_org;

  insert into public.profiles(id,full_name,phone)
  values(v_user,trim(p_full_name),nullif(trim(coalesce(p_phone,'')),''))
  on conflict(id) do update set full_name=excluded.full_name,phone=coalesce(excluded.phone,public.profiles.phone),updated_at=now();

  insert into public.organization_members(organization_id,user_id,role,status)
  values(v_org,v_user,'owner','active');

  insert into public.stores(organization_id,name,code,is_main,status,email)
  values(v_org,trim(p_organization_name),'HQ',true,'active',(select email from auth.users where id=v_user))
  returning id into v_store;

  insert into public.store_members(organization_id,store_id,user_id,is_primary,status)
  values(v_org,v_store,v_user,true,'active');

  insert into public.saas_subscriptions(
    organization_id,store_id,subscriber_user_id,subscription_type,plan_code,amount_rm,billing_months,status,starts_at,expires_at
  ) values (
    v_org,null,v_user,'owner',coalesce(v_code.plan_code,'monthly'),coalesce(v_code.amount_rm,100),coalesce(v_code.billing_months,1),
    'active',v_start,public.salonos_plan_expiry(coalesce(v_code.plan_code,'monthly'),v_start)
  ) returning id into v_sub;

  -- Seed only the minimum settings; no fake business catalog data.
  if to_regclass('public.membership_levels') is not null then
    insert into public.membership_levels(organization_id,level_number,name,min_experience,discount_percent,points_multiplier,active)
    values(v_org,1,'等级 1',0,0,1,true)
    on conflict do nothing;
  end if;
  if to_regclass('public.service_commission_settings') is not null then
    insert into public.service_commission_settings(organization_id,mode,fixed_rate)
    values(v_org,'fixed',0)
    on conflict(organization_id) do nothing;
  end if;

  update public.saas_activation_codes
  set status='used',used_at=now(),used_by_user_id=v_user,target_user_id=v_user,target_organization_id=v_org
  where id=v_code.id;

  insert into public.creator_audit_logs(creator_user_id,organization_id,action_name,detail)
  values(v_code.created_by,v_org,'owner_signup.redeemed',v_user::text);

  return query select v_org,v_store,v_sub;
end;
$$;
revoke all on function public.redeem_owner_activation_code(text,text,text,text) from public;
grant execute on function public.redeem_owner_activation_code(text,text,text,text) to authenticated;

-- -----------------------------------------------------------------------------
-- Device authorization. Staff accounts will NOT use this flow.
-- -----------------------------------------------------------------------------
create or replace function public.redeem_device_activation_code(
  p_code text,
  p_device_id text,
  p_token_hash text,
  p_device_name text default null,
  p_user_agent text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_code public.saas_activation_codes%rowtype;
  v_device uuid;
begin
  if v_user is null then raise exception 'Login required'; end if;
  if trim(coalesce(p_device_id,''))='' or trim(coalesce(p_token_hash,''))='' then raise exception 'Device identity missing'; end if;

  select * into v_code
  from public.saas_activation_codes
  where purpose='device_login'
    and target_user_id=v_user
    and code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex')
    and status='pending' and used_at is null and expires_at>=now()
  for update;
  if v_code.id is null then raise exception 'DVC code is invalid, used or expired'; end if;

  insert into public.saas_trusted_devices(
    organization_id,user_id,device_id,device_name,token_hash,user_agent,status,first_authorized_at,last_seen_at,revoked_at
  ) values (
    v_code.target_organization_id,v_user,trim(p_device_id),nullif(trim(coalesce(p_device_name,'')),''),trim(p_token_hash),
    nullif(trim(coalesce(p_user_agent,'')),''),'active',now(),now(),null
  )
  on conflict(user_id,device_id) do update set
    organization_id=excluded.organization_id,
    device_name=excluded.device_name,
    token_hash=excluded.token_hash,
    user_agent=excluded.user_agent,
    status='active',first_authorized_at=now(),last_seen_at=now(),revoked_at=null
  returning id into v_device;

  update public.saas_activation_codes
  set status='used',used_at=now(),used_by_user_id=v_user
  where id=v_code.id;

  return v_device;
end;
$$;
revoke all on function public.redeem_device_activation_code(text,text,text,text,text) from public;
grant execute on function public.redeem_device_activation_code(text,text,text,text,text) to authenticated;

create or replace function public.check_owner_trusted_device(p_device_id text,p_token_hash text)
returns table(authorized boolean,organization_id uuid,device_id uuid)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row public.saas_trusted_devices%rowtype;
begin
  if auth.uid() is null then return query select false,null::uuid,null::uuid; return; end if;
  select * into v_row
  from public.saas_trusted_devices d
  where d.user_id=auth.uid() and d.device_id=p_device_id and d.token_hash=p_token_hash and d.status='active'
  limit 1;
  if v_row.id is null then return query select false,null::uuid,null::uuid; return; end if;
  update public.saas_trusted_devices set last_seen_at=now() where id=v_row.id;
  return query select true,v_row.organization_id,v_row.id;
end;
$$;
revoke all on function public.check_owner_trusted_device(text,text) from public;
grant execute on function public.check_owner_trusted_device(text,text) to authenticated;

create or replace function public.creator_revoke_device(p_device_record_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org uuid;
begin
  if auth.uid() is null or not public.is_creator_admin() then raise exception 'Creator permission required'; end if;
  update public.saas_trusted_devices
  set status='revoked',revoked_at=now()
  where id=p_device_record_id
  returning organization_id into v_org;
  if v_org is null then return false; end if;
  insert into public.creator_audit_logs(creator_user_id,organization_id,action_name,detail)
  values(auth.uid(),v_org,'device.revoked',p_device_record_id::text);
  return true;
end;
$$;
revoke all on function public.creator_revoke_device(uuid) from public;
grant execute on function public.creator_revoke_device(uuid) to authenticated;

-- -----------------------------------------------------------------------------
-- RLS
-- -----------------------------------------------------------------------------
alter table public.creator_admins enable row level security;
alter table public.saas_subscriptions enable row level security;
alter table public.saas_activation_codes enable row level security;
alter table public.saas_trusted_devices enable row level security;
alter table public.creator_audit_logs enable row level security;

drop policy if exists creator_admin_self_read on public.creator_admins;
create policy creator_admin_self_read on public.creator_admins
for select to authenticated
using (user_id=auth.uid());

drop policy if exists creator_reads_subscriptions on public.saas_subscriptions;
create policy creator_reads_subscriptions on public.saas_subscriptions
for select to authenticated
using (public.is_creator_admin());

drop policy if exists org_members_read_subscriptions on public.saas_subscriptions;
create policy org_members_read_subscriptions on public.saas_subscriptions
for select to authenticated
using (public.is_organization_member(organization_id));

drop policy if exists creator_reads_codes on public.saas_activation_codes;
create policy creator_reads_codes on public.saas_activation_codes
for select to authenticated
using (public.is_creator_admin());

drop policy if exists creator_reads_devices on public.saas_trusted_devices;
create policy creator_reads_devices on public.saas_trusted_devices
for select to authenticated
using (public.is_creator_admin());

drop policy if exists owner_reads_own_devices on public.saas_trusted_devices;
create policy owner_reads_own_devices on public.saas_trusted_devices
for select to authenticated
using (user_id=auth.uid());

drop policy if exists creator_reads_audit on public.creator_audit_logs;
create policy creator_reads_audit on public.creator_audit_logs
for select to authenticated
using (public.is_creator_admin());

-- Creator must be able to see all organizations/stores/members for its dashboard.
drop policy if exists creator_views_all_organizations on public.organizations;
create policy creator_views_all_organizations on public.organizations
for select to authenticated
using (public.is_creator_admin());

drop policy if exists creator_views_all_stores on public.stores;
create policy creator_views_all_stores on public.stores
for select to authenticated
using (public.is_creator_admin());

drop policy if exists creator_views_all_org_members on public.organization_members;
create policy creator_views_all_org_members on public.organization_members
for select to authenticated
using (public.is_creator_admin());

drop policy if exists creator_views_all_profiles on public.profiles;
create policy creator_views_all_profiles on public.profiles
for select to authenticated
using (public.is_creator_admin());

-- -----------------------------------------------------------------------------
-- v13 marker
-- -----------------------------------------------------------------------------
create table if not exists public.salonos_system_meta (
  meta_key text primary key,
  meta_value text not null,
  updated_at timestamptz not null default now()
);
insert into public.salonos_system_meta(meta_key,meta_value)
values('backend_version','13.0.0-supabase-only-foundation')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

select 'SalonOS v13 Supabase foundation ready' as result;


-- ===== SUPABASE_V13_0_1_UI_BRIDGE.sql =====
-- SalonOS v13.0.1 · Original UI -> Supabase Control Plane Bridge
-- Run AFTER SUPABASE_V13_FOUNDATION.sql.
-- No InfinityFree/MySQL business data is read or written by these Creator/registration RPCs.

create or replace function public.creator_dashboard_snapshot()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  result jsonb;
begin
  if auth.uid() is null or not public.is_creator_admin() then
    raise exception 'Creator permission required';
  end if;

  select jsonb_build_object(
    'counts', jsonb_build_object(
      'tenants', (select count(*) from public.saas_subscriptions s where s.subscription_type='owner'),
      'active', (select count(*) from public.saas_subscriptions s where s.subscription_type='owner' and s.status='active' and (s.expires_at is null or s.expires_at>=now())),
      'branches', (select count(*) from public.saas_subscriptions s where s.subscription_type='branch' and s.status in ('pending','active','suspended','expired')),
      'unmanaged', 0,
      'devices', (select count(*) from public.saas_trusted_devices d where d.status='active'),
      'codes', (select count(*) from public.saas_activation_codes c where c.status='pending' and c.used_at is null and c.expires_at>=now())
    ),
    'owners', coalesce((
      select jsonb_agg(x order by x.created_at desc) from (
        select
          o.id organization_id,
          o.name business_name,
          o.status,
          om.user_id owner_user_id,
          coalesce(p.full_name,'') owner_name,
          coalesce(u.email,'') owner_email,
          coalesce(p.phone,'') owner_phone,
          s.id subscription_id,
          coalesce(s.status,'pending') subscription_status,
          coalesce(s.plan_code,'monthly') plan_code,
          coalesce(s.amount_rm,100) amount_rm,
          s.starts_at,
          s.expires_at,
          o.created_at,
          (select count(*) from public.saas_trusted_devices d where d.organization_id=o.id and d.status='active') device_count,
          (select count(*) from public.saas_subscriptions bs where bs.organization_id=o.id and bs.subscription_type='branch' and bs.status in ('pending','active','suspended','expired')) branch_count
        from public.organizations o
        join public.organization_members om on om.organization_id=o.id and om.role='owner' and om.status='active'
        left join public.profiles p on p.id=om.user_id
        left join auth.users u on u.id=om.user_id
        left join lateral (
          select s1.* from public.saas_subscriptions s1
          where s1.organization_id=o.id and s1.subscription_type='owner'
          order by s1.created_at desc limit 1
        ) s on true
      ) x
    ), '[]'::jsonb),
    'branches', coalesce((
      select jsonb_agg(x order by x.created_at desc) from (
        select
          s.id subscription_id,
          s.organization_id,
          o.name business_name,
          s.store_id,
          coalesce(st.name,'等待激活') branch_name,
          coalesce(u.email,'') login_email,
          s.plan_code,
          s.amount_rm,
          s.billing_months,
          s.status,
          s.starts_at,
          s.expires_at,
          s.subscriber_user_id,
          s.created_at
        from public.saas_subscriptions s
        join public.organizations o on o.id=s.organization_id
        left join public.stores st on st.id=s.store_id and st.organization_id=s.organization_id
        left join auth.users u on u.id=s.subscriber_user_id
        where s.subscription_type='branch'
      ) x
    ), '[]'::jsonb),
    'codes', coalesce((
      select jsonb_agg(x order by x.created_at desc) from (
        select c.id,c.purpose,c.code_hint,c.label,c.target_user_id,c.target_organization_id,c.target_email,
               c.plan_code,c.amount_rm,c.billing_months,c.status,c.expires_at,c.used_at,c.created_at,
               coalesce(o.name,'') business_name
        from public.saas_activation_codes c
        left join public.organizations o on o.id=c.target_organization_id
        order by c.created_at desc
        limit 100
      ) x
    ), '[]'::jsonb),
    'devices', coalesce((
      select jsonb_agg(x order by x.created_at desc) from (
        select d.id,d.organization_id,o.name business_name,d.user_id,coalesce(u.email,'') owner_email,
               d.device_id,d.device_name,d.user_agent,d.status,d.first_authorized_at,d.last_seen_at,d.revoked_at,d.created_at
        from public.saas_trusted_devices d
        join public.organizations o on o.id=d.organization_id
        left join auth.users u on u.id=d.user_id
        order by d.created_at desc
        limit 200
      ) x
    ), '[]'::jsonb),
    'logs', coalesce((
      select jsonb_agg(x order by x.created_at desc) from (
        select l.id,l.creator_user_id,l.organization_id,coalesce(o.name,'') business_name,
               l.action_name,l.detail,l.ip_address,l.created_at
        from public.creator_audit_logs l
        left join public.organizations o on o.id=l.organization_id
        order by l.created_at desc
        limit 100
      ) x
    ), '[]'::jsonb)
  ) into result;

  return result;
end;
$$;
revoke all on function public.creator_dashboard_snapshot() from public;
grant execute on function public.creator_dashboard_snapshot() to authenticated;

create or replace function public.creator_renew_subscription(p_subscription_id uuid,p_plan_code text)
returns table(subscription_id uuid,status text,expires_at timestamptz,amount_rm numeric,billing_months integer)
language plpgsql
security definer
set search_path=public
as $$
declare
  v public.saas_subscriptions%rowtype;
  v_start timestamptz;
  v_exp timestamptz;
begin
  if auth.uid() is null or not public.is_creator_admin() then raise exception 'Creator permission required'; end if;
  if lower(coalesce(p_plan_code,'')) not in ('monthly','annual','biennial') then raise exception 'Invalid plan'; end if;
  select * into v from public.saas_subscriptions where id=p_subscription_id for update;
  if v.id is null then raise exception 'Subscription not found'; end if;
  v_start := greatest(coalesce(v.expires_at,now()),now());
  v_exp := public.salonos_plan_expiry(lower(p_plan_code),v_start);
  update public.saas_subscriptions
  set plan_code=lower(p_plan_code),amount_rm=public.salonos_plan_amount(p_plan_code),billing_months=public.salonos_plan_months(p_plan_code),
      status='active',starts_at=coalesce(starts_at,now()),expires_at=v_exp,updated_at=now()
  where id=v.id;
  if v.subscription_type='owner' then update public.organizations set status='active',updated_at=now() where id=v.organization_id; end if;
  insert into public.creator_audit_logs(creator_user_id,organization_id,action_name,detail)
  values(auth.uid(),v.organization_id,'subscription.renewed',v.id::text||' · '||lower(p_plan_code)||' · '||v_exp::text);
  return query select v.id,'active'::text,v_exp,public.salonos_plan_amount(p_plan_code),public.salonos_plan_months(p_plan_code);
end;
$$;
revoke all on function public.creator_renew_subscription(uuid,text) from public;
grant execute on function public.creator_renew_subscription(uuid,text) to authenticated;

create or replace function public.creator_set_subscription_status(p_subscription_id uuid,p_status text)
returns boolean
language plpgsql
security definer
set search_path=public
as $$
declare v public.saas_subscriptions%rowtype;
begin
  if auth.uid() is null or not public.is_creator_admin() then raise exception 'Creator permission required'; end if;
  if lower(coalesce(p_status,'')) not in ('active','suspended','cancelled') then raise exception 'Invalid status'; end if;
  select * into v from public.saas_subscriptions where id=p_subscription_id for update;
  if v.id is null then raise exception 'Subscription not found'; end if;
  update public.saas_subscriptions set status=lower(p_status),updated_at=now() where id=v.id;
  if v.subscription_type='owner' then
    update public.organizations set status=case lower(p_status) when 'active' then 'active' when 'cancelled' then 'cancelled' else 'suspended' end,updated_at=now() where id=v.organization_id;
  end if;
  insert into public.creator_audit_logs(creator_user_id,organization_id,action_name,detail)
  values(auth.uid(),v.organization_id,'subscription.status_changed',v.id::text||' · '||lower(p_status));
  return true;
end;
$$;
revoke all on function public.creator_set_subscription_status(uuid,text) from public;
grant execute on function public.creator_set_subscription_status(uuid,text) to authenticated;

create or replace function public.creator_cancel_activation_code(p_code_id uuid)
returns boolean
language plpgsql
security definer
set search_path=public
as $$
declare v_org uuid;
begin
  if auth.uid() is null or not public.is_creator_admin() then raise exception 'Creator permission required'; end if;
  update public.saas_activation_codes set status='cancelled'
  where id=p_code_id and status='pending' and used_at is null
  returning target_organization_id into v_org;
  if not found then return false; end if;
  insert into public.creator_audit_logs(creator_user_id,organization_id,action_name,detail)
  values(auth.uid(),v_org,'activation_code.cancelled',p_code_id::text);
  return true;
end;
$$;
revoke all on function public.creator_cancel_activation_code(uuid) from public;
grant execute on function public.creator_cancel_activation_code(uuid) to authenticated;

create or replace function public.validate_owner_activation_code(p_code text)
returns table(valid boolean,plan_code text,amount_rm numeric,billing_months integer,expires_at timestamptz,label text)
language plpgsql
security definer
set search_path=public
as $$
declare c public.saas_activation_codes%rowtype;
begin
  select * into c from public.saas_activation_codes
  where purpose='owner_signup' and code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex')
    and status='pending' and used_at is null and expires_at>=now()
  limit 1;
  if c.id is null then return query select false,null::text,null::numeric,null::integer,null::timestamptz,null::text; return; end if;
  return query select true,c.plan_code,c.amount_rm,c.billing_months,c.expires_at,c.label;
end;
$$;
revoke all on function public.validate_owner_activation_code(text) from public;
grant execute on function public.validate_owner_activation_code(text) to anon,authenticated;

create or replace function public.redeem_owner_activation_code_v2(
  p_code text,
  p_organization_name text,
  p_full_name text,
  p_phone text default null,
  p_store_phone text default null,
  p_store_address text default null
)
returns table(organization_id uuid,store_id uuid,subscription_id uuid)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_user uuid := auth.uid();
  v_code public.saas_activation_codes%rowtype;
  v_org uuid; v_store uuid; v_sub uuid; v_start timestamptz := now();
begin
  if v_user is null then raise exception 'Login required before redeeming ACT code'; end if;
  if trim(coalesce(p_organization_name,''))='' then raise exception 'Organization name required'; end if;
  if trim(coalesce(p_full_name,''))='' then raise exception 'Owner name required'; end if;
  if exists(select 1 from public.organization_members where user_id=v_user and status='active') then raise exception 'This account already belongs to an active SalonOS organization'; end if;

  select * into v_code from public.saas_activation_codes
  where purpose='owner_signup' and code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex')
    and status='pending' and used_at is null and expires_at>=now()
  for update;
  if v_code.id is null then raise exception 'ACT code is invalid, used or expired'; end if;

  insert into public.organizations(name,status) values(trim(p_organization_name),'active') returning id into v_org;
  insert into public.profiles(id,full_name,phone) values(v_user,trim(p_full_name),nullif(trim(coalesce(p_phone,'')),''))
  on conflict(id) do update set full_name=excluded.full_name,phone=coalesce(excluded.phone,public.profiles.phone),updated_at=now();
  insert into public.organization_members(organization_id,user_id,role,status) values(v_org,v_user,'owner','active');
  insert into public.stores(organization_id,name,code,is_main,status,email,phone,address)
  values(v_org,trim(p_organization_name),'HQ',true,'active',(select email from auth.users where id=v_user),nullif(trim(coalesce(p_store_phone,'')),''),nullif(trim(coalesce(p_store_address,'')),''))
  returning id into v_store;
  insert into public.store_members(organization_id,store_id,user_id,is_primary,status) values(v_org,v_store,v_user,true,'active');
  insert into public.saas_subscriptions(organization_id,store_id,subscriber_user_id,subscription_type,plan_code,amount_rm,billing_months,status,starts_at,expires_at)
  values(v_org,null,v_user,'owner',coalesce(v_code.plan_code,'monthly'),coalesce(v_code.amount_rm,100),coalesce(v_code.billing_months,1),'active',v_start,public.salonos_plan_expiry(coalesce(v_code.plan_code,'monthly'),v_start))
  returning id into v_sub;

  if to_regclass('public.membership_levels') is not null then
    insert into public.membership_levels(organization_id,level_number,name,min_experience,discount_percent,points_multiplier,active)
    values(v_org,1,'等级 1',0,0,1,true) on conflict do nothing;
  end if;
  if to_regclass('public.service_commission_settings') is not null then
    insert into public.service_commission_settings(organization_id,mode,fixed_rate) values(v_org,'fixed',0) on conflict(organization_id) do nothing;
  end if;

  update public.saas_activation_codes set status='used',used_at=now(),used_by_user_id=v_user,target_user_id=v_user,target_organization_id=v_org where id=v_code.id;
  insert into public.creator_audit_logs(creator_user_id,organization_id,action_name,detail) values(v_code.created_by,v_org,'owner_signup.redeemed',v_user::text);
  return query select v_org,v_store,v_sub;
end;
$$;
revoke all on function public.redeem_owner_activation_code_v2(text,text,text,text,text,text) from public;
grant execute on function public.redeem_owner_activation_code_v2(text,text,text,text,text,text) to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values('backend_version','13.0.1-original-ui-control-plane')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

select 'SalonOS v13.0.1 original UI control plane bridge ready' as result;


-- ===== SUPABASE_V13_0_2_CUSTOMERS_MEMBERS.sql =====
-- SalonOS v13.0.2 · Customers + Memberships -> Supabase
-- Idempotent safety/verification setup. No business records are deleted.

DO $$
BEGIN
  IF to_regclass('public.customers') IS NULL THEN RAISE EXCEPTION 'Missing public.customers'; END IF;
  IF to_regclass('public.memberships') IS NULL THEN RAISE EXCEPTION 'Missing public.memberships'; END IF;
  IF to_regclass('public.membership_levels') IS NULL THEN RAISE EXCEPTION 'Missing public.membership_levels'; END IF;
  IF to_regclass('public.member_wallet_ledger') IS NULL THEN RAISE EXCEPTION 'Missing public.member_wallet_ledger'; END IF;
  IF to_regclass('public.member_loyalty_ledger') IS NULL THEN RAISE EXCEPTION 'Missing public.member_loyalty_ledger'; END IF;
END $$;

-- Every existing organization needs an initial member level.
insert into public.membership_levels(
  organization_id, level_number, name, min_experience,
  discount_percent, points_multiplier, active
)
select o.id, 1, '等级 1', 0, 0, 1, true
from public.organizations o
where not exists (
  select 1 from public.membership_levels ml
  where ml.organization_id=o.id and ml.level_number=1
)
on conflict do nothing;

insert into public.salonos_system_meta(meta_key,meta_value)
values('backend_version','13.0.2-customers-members-supabase')
on conflict(meta_key) do update
set meta_value=excluded.meta_value, updated_at=now();

select 'SalonOS v13.0.2 customers + memberships Supabase bridge ready' as result;


-- ===== SUPABASE_V13_1_0_COMPLETE_CUTOVER.sql =====
-- SalonOS v13.1.1 COMPLETE SUPABASE CUTOVER
-- One-shot additive installer. It does NOT delete business data.
-- InfinityFree is hosting only. All v13 business state lives in Supabase.

create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

-- Supabase installs pgcrypto in the extensions schema. Older v13 functions were
-- created with search_path=public, which caused gen_random_bytes()/digest() errors.
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    select n.nspname schema_name,p.proname,pg_get_function_identity_arguments(p.oid) args
    from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname in (
      'salonos_new_code','creator_generate_owner_code','creator_generate_device_code','creator_generate_branch_code',
      'redeem_owner_activation_code','redeem_owner_activation_code_v2','redeem_device_activation_code','validate_owner_activation_code'
    )
  LOOP
    EXECUTE format('alter function %I.%I(%s) set search_path=public,extensions',r.schema_name,r.proname,r.args);
  END LOOP;
END $$;

-- -----------------------------------------------------------------------------
-- Existing table compatibility additions
-- -----------------------------------------------------------------------------
alter table public.employees
  add column if not exists app_role text not null default 'staff',
  add column if not exists last_login_at timestamptz;

alter table public.products
  add column if not exists reorder_level numeric not null default 0,
  add column if not exists purpose text,
  add column if not exists retail_enabled boolean not null default true,
  add column if not exists stock_enabled boolean not null default true;

alter table public.visit_service_signoffs
  add column if not exists signature_data text;

-- -----------------------------------------------------------------------------
-- v13 settings / KPI / training / product bundles
-- -----------------------------------------------------------------------------
create table if not exists public.v13_organization_settings (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  general jsonb not null default '{}'::jsonb,
  role_permissions jsonb not null default '{}'::jsonb,
  whatsapp jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.v13_kpi_rules (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  metric_type text not null check (metric_type in ('service_performance','product_sales','total_sales','service_count','customer_count')),
  target_value numeric not null default 0,
  bonus_amount numeric not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists v13_kpi_rules_org_idx on public.v13_kpi_rules(organization_id,active);

create table if not exists public.v13_kpi_assignments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  employee_id uuid not null,
  rule_id uuid not null references public.v13_kpi_rules(id) on delete cascade,
  effective_from date not null default current_date,
  effective_to date,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(employee_id,rule_id,effective_from),
  foreign key (organization_id,employee_id) references public.employees(organization_id,id) on delete cascade
);

create table if not exists public.v13_training_courses (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  title text not null,
  description text,
  content text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.v13_training_progress (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  employee_id uuid not null,
  course_id uuid not null references public.v13_training_courses(id) on delete cascade,
  progress_percent integer not null default 0 check (progress_percent between 0 and 100),
  status text not null default 'not_started' check (status in ('not_started','in_progress','completed')),
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  unique(employee_id,course_id),
  foreign key (organization_id,employee_id) references public.employees(organization_id,id) on delete cascade
);

create table if not exists public.v13_product_bundles (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null,
  name text not null,
  sku text,
  sale_price numeric not null default 0,
  image_path text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (organization_id,store_id) references public.stores(organization_id,id) on delete cascade,
  unique(organization_id,store_id,sku)
);

create table if not exists public.v13_product_bundle_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  bundle_id uuid not null references public.v13_product_bundles(id) on delete cascade,
  product_id uuid not null,
  quantity numeric not null default 1 check (quantity > 0),
  created_at timestamptz not null default now(),
  foreign key (organization_id,product_id) references public.products(organization_id,id) on delete cascade,
  unique(bundle_id,product_id)
);

-- -----------------------------------------------------------------------------
-- Employee custom sessions (phone-only login)
-- -----------------------------------------------------------------------------
create table if not exists public.employee_login_sessions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  token_hash text not null unique,
  device_id text,
  user_agent text,
  issued_at timestamptz not null default now(),
  expires_at timestamptz not null,
  last_seen_at timestamptz not null default now(),
  revoked_at timestamptz
);
create index if not exists employee_login_sessions_employee_idx on public.employee_login_sessions(employee_id,expires_at desc);

-- -----------------------------------------------------------------------------
-- RLS
-- -----------------------------------------------------------------------------
alter table public.v13_organization_settings enable row level security;
alter table public.v13_kpi_rules enable row level security;
alter table public.v13_kpi_assignments enable row level security;
alter table public.v13_training_courses enable row level security;
alter table public.v13_training_progress enable row level security;
alter table public.v13_product_bundles enable row level security;
alter table public.v13_product_bundle_items enable row level security;
alter table public.employee_login_sessions enable row level security;

-- recreate policies idempotently
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT schemaname,tablename,policyname FROM pg_policies
    WHERE schemaname='public' AND policyname like 'v13_%'
  LOOP
    EXECUTE format('drop policy if exists %I on %I.%I',r.policyname,r.schemaname,r.tablename);
  END LOOP;
END $$;

create policy v13_settings_member_read on public.v13_organization_settings for select to authenticated
  using (public.is_organization_member(organization_id));
create policy v13_settings_manage on public.v13_organization_settings for all to authenticated
  using (public.has_organization_role(organization_id,array['owner','manager']))
  with check (public.has_organization_role(organization_id,array['owner','manager']));

create policy v13_kpi_rules_read on public.v13_kpi_rules for select to authenticated
  using (public.is_organization_member(organization_id));
create policy v13_kpi_rules_manage on public.v13_kpi_rules for all to authenticated
  using (public.has_organization_role(organization_id,array['owner','manager']))
  with check (public.has_organization_role(organization_id,array['owner','manager']));

create policy v13_kpi_assign_read on public.v13_kpi_assignments for select to authenticated
  using (public.is_organization_member(organization_id));
create policy v13_kpi_assign_manage on public.v13_kpi_assignments for all to authenticated
  using (public.has_organization_role(organization_id,array['owner','manager']))
  with check (public.has_organization_role(organization_id,array['owner','manager']));

create policy v13_training_courses_read on public.v13_training_courses for select to authenticated
  using (public.is_organization_member(organization_id));
create policy v13_training_courses_manage on public.v13_training_courses for all to authenticated
  using (public.has_organization_role(organization_id,array['owner','manager']))
  with check (public.has_organization_role(organization_id,array['owner','manager']));

create policy v13_training_progress_read on public.v13_training_progress for select to authenticated
  using (public.is_organization_member(organization_id));
create policy v13_training_progress_manage on public.v13_training_progress for all to authenticated
  using (public.has_organization_role(organization_id,array['owner','manager']))
  with check (public.has_organization_role(organization_id,array['owner','manager']));

create policy v13_bundles_read on public.v13_product_bundles for select to authenticated
  using (public.can_access_store(store_id));
create policy v13_bundles_manage on public.v13_product_bundles for all to authenticated
  using (public.has_organization_role(organization_id,array['owner','manager']))
  with check (public.has_organization_role(organization_id,array['owner','manager']));

create policy v13_bundle_items_read on public.v13_product_bundle_items for select to authenticated
  using (public.is_organization_member(organization_id));
create policy v13_bundle_items_manage on public.v13_product_bundle_items for all to authenticated
  using (public.has_organization_role(organization_id,array['owner','manager']))
  with check (public.has_organization_role(organization_id,array['owner','manager']));

-- -----------------------------------------------------------------------------
-- Robust employee RPCs: JSON return avoids PL/pgSQL output-column ambiguity.
-- -----------------------------------------------------------------------------
create or replace function public.v13_employee_directory(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_org uuid; v_result jsonb;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id;
  if v_org is null then raise exception '找不到门店。'; end if;
  if not public.has_organization_role(v_org,array['owner','manager','accountant']) then raise exception '你没有查看员工资料的权限。'; end if;
  if not public.can_access_store(p_store_id) then raise exception '你没有这个门店的权限。'; end if;

  select coalesce(jsonb_agg(x order by (x->>'employment_status'='active') desc,x->>'name'),'[]'::jsonb)
    into v_result
  from (
    select jsonb_build_object(
      'id',e.id,'employee_code',e.employee_code,'name',e.name,'phone',e.phone,'position',e.position,
      'age',e.age,'gender',e.gender,'skill_tags',e.skill_tags,'app_role',e.app_role,
      'base_salary',coalesce(ec.base_salary,0),'joined_at',e.joined_at,'employment_status',e.employment_status,
      'is_on_duty',e.is_on_duty,'availability_status',e.availability_status,'last_login_at',e.last_login_at,
      'order_count',(select count(distinct vv.id) from public.visit_service_workers w
         join public.visit_service_items si on si.id=w.service_item_id and si.organization_id=e.organization_id
         join public.visits vv on vv.id=si.visit_id and vv.organization_id=e.organization_id
         where w.employee_id=e.id and w.organization_id=e.organization_id)
    ) x
    from public.employees e
    join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id and es.store_id=p_store_id and es.status='active'
    left join public.employee_compensation ec on ec.employee_id=e.id and ec.organization_id=e.organization_id
    where e.organization_id=v_org
  ) q;
  return v_result;
end; $$;
revoke all on function public.v13_employee_directory(uuid) from public;
grant execute on function public.v13_employee_directory(uuid) to authenticated;

-- v13.1.2 compatibility cleanup:
-- v13.0.4 exposed these RPCs as RETURNS TABLE, while v13.1.x returns JSONB.
-- PostgreSQL cannot change an existing function return type with CREATE OR REPLACE,
-- so drop the old signatures inside this transaction and recreate them below.
drop function if exists public.employee_phone_login(text,text,text);
drop function if exists public.employee_session_context(text);

create or replace function public.employee_phone_login(p_phone text,p_device_id text default null,p_user_agent text default null)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_phone text:=regexp_replace(coalesce(p_phone,''),'[^0-9]','','g');
  v_e public.employees%rowtype; v_s public.stores%rowtype; v_o public.organizations%rowtype;
  v_count integer; v_token text:=encode(gen_random_bytes(32),'hex'); v_exp timestamptz:=now()+interval '30 days';
begin
  if length(v_phone)<8 then raise exception '请输入有效的员工手机号码。'; end if;
  select count(*) into v_count from public.employees e
   where regexp_replace(coalesce(e.phone,''),'[^0-9]','','g')=v_phone and e.employment_status='active'
     and exists(select 1 from public.employee_stores es join public.stores s on s.id=es.store_id
                join public.organizations o on o.id=e.organization_id
                where es.employee_id=e.id and es.organization_id=e.organization_id and es.status='active' and s.status='active' and o.status in ('active','trialing'));
  if v_count=0 then raise exception '手机号未登记、员工已停用，或所在门店不可使用。'; end if;
  if v_count>1 then raise exception '这个手机号关联多个员工账号，请让老板修改重复号码。'; end if;

  select e.* into v_e from public.employees e
   where regexp_replace(coalesce(e.phone,''),'[^0-9]','','g')=v_phone and e.employment_status='active' limit 1;
  select o.* into v_o from public.organizations o where o.id=v_e.organization_id and o.status in ('active','trialing');
  select s.* into v_s from public.employee_stores es join public.stores s on s.id=es.store_id and s.organization_id=es.organization_id
   where es.employee_id=v_e.id and es.organization_id=v_e.organization_id and es.status='active' and s.status='active'
   order by (s.id=v_e.primary_store_id) desc,es.is_primary desc,s.is_main desc limit 1;
  if v_o.id is null or v_s.id is null then raise exception '员工所属门店目前不可使用。'; end if;

  insert into public.employee_login_sessions(organization_id,store_id,employee_id,token_hash,device_id,user_agent,expires_at)
  values(v_e.organization_id,v_s.id,v_e.id,encode(digest(v_token,'sha256'),'hex'),nullif(trim(coalesce(p_device_id,'')),''),left(p_user_agent,250),v_exp);
  update public.employees set last_login_at=now(),updated_at=now() where id=v_e.id;
  return jsonb_build_object('session_token',v_token,'employee_id',v_e.id,'employee_name',v_e.name,'employee_role',v_e.app_role,
    'organization_id',v_o.id,'organization_name',v_o.name,'store_id',v_s.id,'store_name',v_s.name,'expires_at',v_exp);
end; $$;
revoke all on function public.employee_phone_login(text,text,text) from public;
grant execute on function public.employee_phone_login(text,text,text) to anon,authenticated;

create or replace function public.employee_session_context(p_session_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_h text:=encode(digest(coalesce(p_session_token,''),'sha256'),'hex'); v_ls public.employee_login_sessions%rowtype; v_result jsonb;
begin
  select ls.* into v_ls from public.employee_login_sessions ls where ls.token_hash=v_h and ls.revoked_at is null and ls.expires_at>now() limit 1;
  if v_ls.id is null then raise exception '员工登录已过期，请重新输入手机号。'; end if;
  select jsonb_build_object('employee_id',e.id,'employee_code',e.employee_code,'employee_name',e.name,'employee_phone',e.phone,
      'employee_position',e.position,'employee_role',e.app_role,'organization_id',o.id,'organization_name',o.name,
      'store_id',s.id,'store_name',s.name,'expires_at',v_ls.expires_at)
   into v_result
   from public.employees e join public.organizations o on o.id=e.organization_id
   join public.stores s on s.id=v_ls.store_id and s.organization_id=e.organization_id
   join public.employee_stores es on es.employee_id=e.id and es.organization_id=e.organization_id and es.store_id=s.id and es.status='active'
   where e.id=v_ls.employee_id and e.employment_status='active' and o.status in ('active','trialing') and s.status='active';
  if v_result is null then update public.employee_login_sessions set revoked_at=now() where id=v_ls.id; raise exception '员工账号已停用或门店不可使用。'; end if;
  update public.employee_login_sessions set last_seen_at=now() where id=v_ls.id;
  return v_result;
end; $$;
revoke all on function public.employee_session_context(text) from public;
grant execute on function public.employee_session_context(text) to anon,authenticated;

create or replace function public.employee_session_logout(p_session_token text)
returns void language sql security definer set search_path=public,extensions as $$
 update public.employee_login_sessions set revoked_at=coalesce(revoked_at,now())
 where token_hash=encode(digest(coalesce(p_session_token,''),'sha256'),'hex');
$$;
revoke all on function public.employee_session_logout(text) from public;
grant execute on function public.employee_session_logout(text) to anon,authenticated;

-- -----------------------------------------------------------------------------
-- Employee API for custom sessions (no Supabase Auth password required)
-- -----------------------------------------------------------------------------
create or replace function public.v13_employee_api(p_session_token text,p_action text,p_payload jsonb default '{}'::jsonb)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_action text:=lower(coalesce(p_action,'')); v_result jsonb;
  v_item uuid; v_status text; v_signature text;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid; v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid; v_role:=coalesce(v_ctx->>'employee_role','staff');

  if v_action='dashboard' then
    return jsonb_build_object('context',v_ctx,
      'today_visits',(select count(*) from public.visits v where v.organization_id=v_org and v.store_id=v_store and coalesce(v.scheduled_at,v.created_at)::date=current_date and v.status not in ('cancelled','no_show')),
      'assigned_open',(select count(distinct si.visit_id) from public.visit_service_workers w join public.visit_service_items si on si.id=w.service_item_id where w.organization_id=v_org and w.store_id=v_store and w.employee_id=v_e and w.status='active' and si.status not in ('completed','cancelled')));
  elsif v_action='visits' then
    select coalesce(jsonb_agg(row_to_json(q)::jsonb order by q.sort_at),'[]'::jsonb) into v_result from (
      select v.id,v.visit_number,v.visit_type,v.status,v.scheduled_at,v.arrived_at,v.started_at,v.service_completed_at,v.notes,
        coalesce(v.scheduled_at,v.created_at) sort_at,
        (select string_agg(r.name_snapshot,', ') from public.visit_recipients r where r.visit_id=v.id and r.organization_id=v_org) customers,
        (select coalesce(sum(si.line_total),0) from public.visit_service_items si where si.visit_id=v.id and si.organization_id=v_org and si.status<>'cancelled') total
      from public.visits v
      where v.organization_id=v_org and v.store_id=v_store and v.status not in ('completed','cancelled','no_show')
        and (v_role in ('manager','receptionist') or exists(select 1 from public.visit_service_items si join public.visit_service_workers w on w.service_item_id=si.id where si.visit_id=v.id and w.employee_id=v_e and w.status='active'))
    ) q;
    return v_result;
  elsif v_action='performance' then
    return jsonb_build_object('service_performance',coalesce((select sum(sp.performance_amount) from public.service_performance_ledger sp join public.payments p on p.id=sp.payment_id where sp.organization_id=v_org and sp.store_id=v_store and sp.employee_id=v_e and p.status='paid' and date_trunc('month',p.paid_at)=date_trunc('month',now())),0),
      'product_commission',coalesce((select sum(c.commission_amount) from public.employee_commission_ledger c where c.organization_id=v_org and c.store_id=v_store and c.employee_id=v_e and c.source_type='product' and date_trunc('month',c.created_at)=date_trunc('month',now())),0));
  elsif v_action='training' then
    select coalesce(jsonb_agg(jsonb_build_object('id',c.id,'title',c.title,'description',c.description,'content',c.content,'progress_percent',coalesce(p.progress_percent,0),'status',coalesce(p.status,'not_started')) order by c.created_at desc),'[]'::jsonb)
      into v_result from public.v13_training_courses c left join public.v13_training_progress p on p.course_id=c.id and p.employee_id=v_e
      where c.organization_id=v_org and c.active;
    return v_result;
  elsif v_action='training_progress' then
    v_item:=(p_payload->>'course_id')::uuid;
    insert into public.v13_training_progress(organization_id,employee_id,course_id,progress_percent,status,completed_at)
    values(v_org,v_e,v_item,least(100,greatest(0,coalesce((p_payload->>'progress_percent')::int,0))),
      case when coalesce((p_payload->>'progress_percent')::int,0)>=100 then 'completed' when coalesce((p_payload->>'progress_percent')::int,0)>0 then 'in_progress' else 'not_started' end,
      case when coalesce((p_payload->>'progress_percent')::int,0)>=100 then now() else null end)
    on conflict(employee_id,course_id) do update set progress_percent=excluded.progress_percent,status=excluded.status,completed_at=excluded.completed_at,updated_at=now();
    return jsonb_build_object('ok',true);
  elsif v_action='catalog' then
    return jsonb_build_object(
      'services',coalesce((select jsonb_agg(jsonb_build_object('id',s.id,'category',s.category,'name',s.name,'price',s.default_price,'minutes',s.estimated_minutes) order by s.category,s.name) from public.services s where s.organization_id=v_org and s.store_id=v_store and s.active),'[]'::jsonb),
      'employees',coalesce((select jsonb_agg(jsonb_build_object('id',e.id,'name',e.name,'position',e.position) order by e.name) from public.employees e where e.organization_id=v_org and e.employment_status='active' and exists(select 1 from public.employee_stores es where es.employee_id=e.id and es.store_id=v_store and es.status='active')),'[]'::jsonb)
    );
  elsif v_action='visit_detail' then
    v_item:=(p_payload->>'visit_id')::uuid;
    if not exists(select 1 from public.visits v where v.id=v_item and v.organization_id=v_org and v.store_id=v_store) then raise exception '找不到订单。'; end if;
    return jsonb_build_object(
      'visit',(select to_jsonb(v) from public.visits v where v.id=v_item),
      'recipients',coalesce((select jsonb_agg(to_jsonb(r)) from public.visit_recipients r where r.organization_id=v_org and r.visit_id=v_item),'[]'::jsonb),
      'items',coalesce((select jsonb_agg(jsonb_build_object('id',si.id,'name',si.service_name_snapshot,'category',si.service_category_snapshot,'line_total',si.line_total,'status',si.status,'assigned_to_me',exists(select 1 from public.visit_service_workers w where w.service_item_id=si.id and w.employee_id=v_e and w.status='active'),'signed_by_me',exists(select 1 from public.visit_service_signoffs sg where sg.service_item_id=si.id and sg.employee_id=v_e)) order by si.created_at) from public.visit_service_items si where si.organization_id=v_org and si.visit_id=v_item),'[]'::jsonb)
    );
  elsif v_action='create_visit' then
    declare
      v_visit uuid:=gen_random_uuid(); v_rec uuid:=gen_random_uuid(); v_customer uuid; v_name text:=trim(coalesce(p_payload->>'customer_name','')); v_phone text:=trim(coalesce(p_payload->>'customer_phone',''));
      v_type text:=case when p_payload->>'visit_type'='appointment' then 'appointment' else 'walk_in' end; v_sched timestamptz; v_line jsonb; v_sid uuid; v_wid uuid; v_aid uuid; v_sv public.services%rowtype; v_si uuid;
    begin
      if v_name='' or v_phone='' then raise exception '顾客姓名与电话必填。'; end if;
      select c.id into v_customer from public.customers c where c.organization_id=v_org and c.store_id=v_store and regexp_replace(coalesce(c.phone,''),'[^0-9]','','g')=regexp_replace(v_phone,'[^0-9]','','g') order by c.created_at desc limit 1;
      if v_customer is null then insert into public.customers(organization_id,store_id,name,phone,gender) values(v_org,v_store,v_name,v_phone,'unspecified') returning id into v_customer; end if;
      if v_type='appointment' and nullif(p_payload->>'scheduled_at','') is not null then v_sched:=(p_payload->>'scheduled_at')::timestamptz; end if;
      insert into public.visits(id,organization_id,store_id,visit_number,visit_type,status,scheduled_at,arrived_at,notes)
      values(v_visit,v_org,v_store,'V'||to_char(now(),'YYMMDDHH24MISS')||'-'||upper(substr(encode(gen_random_bytes(3),'hex'),1,4)),v_type,case when v_type='appointment' then 'booked' else 'arrived' end,v_sched,case when v_type='walk_in' then now() else null end,nullif(p_payload->>'notes',''));
      insert into public.visit_recipients(id,organization_id,visit_id,customer_id,name_snapshot,phone_snapshot,recipient_type) values(v_rec,v_org,v_visit,v_customer,v_name,v_phone,'primary');
      for v_line in select * from jsonb_array_elements(coalesce(p_payload->'services','[]'::jsonb)) loop
        v_sid:=(v_line->>'service_id')::uuid; v_wid:=coalesce(nullif(v_line->>'worker_id','')::uuid,v_e); v_aid:=nullif(v_line->>'assistant_id','')::uuid;
        select s.* into v_sv from public.services s where s.id=v_sid and s.organization_id=v_org and s.store_id=v_store and s.active;
        if v_sv.id is null then continue; end if;
        if not exists(select 1 from public.employees ee where ee.id=v_wid and ee.organization_id=v_org and ee.employment_status='active' and exists(select 1 from public.employee_stores es where es.employee_id=ee.id and es.store_id=v_store and es.status='active')) then v_wid:=v_e; end if;
        insert into public.visit_service_items(organization_id,store_id,visit_id,recipient_id,service_id,service_name_snapshot,service_category_snapshot,unit_price,quantity,estimated_minutes_snapshot,status)
        values(v_org,v_store,v_visit,v_rec,v_sv.id,v_sv.name,v_sv.category,v_sv.default_price,1,v_sv.estimated_minutes,'waiting') returning id into v_si;
        if v_aid=v_wid or not exists(select 1 from public.employees ae where ae.id=v_aid and ae.organization_id=v_org and ae.employment_status='active' and exists(select 1 from public.employee_stores aes where aes.employee_id=ae.id and aes.store_id=v_store and aes.status='active')) then v_aid:=null; end if;
        insert into public.visit_service_workers(organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status) values(v_org,v_store,v_si,v_wid,'primary',case when v_aid is null then 100 else 80 end,'active');
        if v_aid is not null then insert into public.visit_service_workers(organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status) values(v_org,v_store,v_si,v_aid,'assistant',20,'active'); end if;
      end loop;
      if not exists(select 1 from public.visit_service_items si where si.visit_id=v_visit) then raise exception '请至少选择一个服务项目。'; end if;
      return jsonb_build_object('visit_id',v_visit);
    end;
  elsif v_action='visit_status' then
    v_item:=(p_payload->>'visit_id')::uuid; v_status:=p_payload->>'status';
    if v_status not in ('arrived','waiting','in_service','paused','ready_for_checkout') then raise exception '不允许的订单状态。'; end if;
    if not exists(select 1 from public.visits v where v.id=v_item and v.organization_id=v_org and v.store_id=v_store) then raise exception '找不到订单。'; end if;
    update public.visits set status=v_status,
      arrived_at=case when v_status='arrived' then coalesce(arrived_at,now()) else arrived_at end,
      started_at=case when v_status='in_service' then coalesce(started_at,now()) else started_at end,
      updated_at=now() where id=v_item;
    return jsonb_build_object('ok',true);
  elsif v_action='signoff' then
    v_item:=(p_payload->>'service_item_id')::uuid; v_signature:=coalesce(p_payload->>'signature_data','');
    if length(v_signature)<20 then raise exception '请先完成顾客签名。'; end if;
    if not exists(select 1 from public.visit_service_workers w where w.organization_id=v_org and w.store_id=v_store and w.service_item_id=v_item and w.employee_id=v_e and w.status='active') then raise exception '你不是这个服务项目的负责员工。'; end if;
    insert into public.visit_service_signoffs(organization_id,store_id,service_item_id,employee_id,employee_name_snapshot,signature_data,signed_at,notes)
    select v_org,v_store,v_item,v_e,e.name,v_signature,now(),'v13 customer signoff' from public.employees e where e.id=v_e
    on conflict(service_item_id,employee_id) do update set signature_data=excluded.signature_data,signed_at=now(),employee_name_snapshot=excluded.employee_name_snapshot;
    return jsonb_build_object('ok',true);
  end if;
  raise exception 'Unsupported employee action: %',p_action;
end; $$;
revoke all on function public.v13_employee_api(text,text,jsonb) from public;
grant execute on function public.v13_employee_api(text,text,jsonb) to anon,authenticated;

-- -----------------------------------------------------------------------------
-- Owner employee write RPCs (JSON return; no output-column ambiguity)
-- -----------------------------------------------------------------------------
create or replace function public.v13_save_employee(
  p_store_id uuid,p_employee_id uuid,p_name text,p_phone text,p_position text,p_age integer,p_gender text,p_skill_tags text,p_base_salary numeric,p_joined_at date,p_app_role text
) returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare v_org uuid; v_id uuid:=p_employee_id; v_phone text:=regexp_replace(coalesce(p_phone,''),'[^0-9]','','g'); v_code text;
begin
 select s.organization_id into v_org from public.stores s where s.id=p_store_id and s.status='active';
 if v_org is null then raise exception '找不到 active 门店。'; end if;
 if not public.has_organization_role(v_org,array['owner','manager']) then raise exception '你没有管理员工的权限。'; end if;
 if not public.can_access_store(p_store_id) then raise exception '你没有这个门店的权限。'; end if;
 if trim(coalesce(p_name,''))='' or trim(coalesce(p_position,''))='' then raise exception '员工姓名和职位必填。'; end if;
 if length(v_phone)<8 then raise exception '请输入有效的员工手机号。'; end if;
 if exists(select 1 from public.employees e where regexp_replace(coalesce(e.phone,''),'[^0-9]','','g')=v_phone and (v_id is null or e.id<>v_id)) then raise exception '这个手机号码已经属于另一位员工。'; end if;
 if v_id is null then
   v_id:=gen_random_uuid(); v_code:='EMP-'||upper(substr(replace(v_id::text,'-',''),1,8));
   insert into public.employees(id,organization_id,primary_store_id,employee_code,name,phone,position,age,gender,skill_tags,app_role,is_on_duty,employment_status,joined_at,created_at,updated_at)
   values(v_id,v_org,p_store_id,v_code,trim(p_name),v_phone,trim(p_position),p_age,case when p_gender in ('male','female','unspecified') then p_gender else 'unspecified' end,nullif(trim(coalesce(p_skill_tags,'')),''),case when p_app_role in ('manager','receptionist','accountant','stylist','assistant','staff') then p_app_role else 'staff' end,true,'active',coalesce(p_joined_at,current_date),now(),now());
 else
   update public.employees e set primary_store_id=p_store_id,name=trim(p_name),phone=v_phone,position=trim(p_position),age=p_age,gender=case when p_gender in ('male','female','unspecified') then p_gender else 'unspecified' end,skill_tags=nullif(trim(coalesce(p_skill_tags,'')),''),app_role=case when p_app_role in ('manager','receptionist','accountant','stylist','assistant','staff') then p_app_role else 'staff' end,joined_at=coalesce(p_joined_at,e.joined_at),updated_at=now() where e.id=v_id and e.organization_id=v_org;
   if not found then raise exception '找不到员工资料。'; end if;
 end if;
 insert into public.employee_stores(organization_id,employee_id,store_id,is_primary,status) values(v_org,v_id,p_store_id,true,'active') on conflict(employee_id,store_id) do update set is_primary=true,status='active',updated_at=now();
 insert into public.employee_compensation(organization_id,employee_id,base_salary,default_commission_rate,effective_from,created_at,updated_at) values(v_org,v_id,greatest(coalesce(p_base_salary,0),0),0,coalesce(p_joined_at,current_date),now(),now()) on conflict(employee_id) do update set base_salary=excluded.base_salary,effective_from=excluded.effective_from,updated_at=now();
 return jsonb_build_object('employee_id',v_id);
end; $$;
revoke all on function public.v13_save_employee(uuid,uuid,text,text,text,integer,text,text,numeric,date,text) from public;
grant execute on function public.v13_save_employee(uuid,uuid,text,text,text,integer,text,text,numeric,date,text) to authenticated;

create or replace function public.v13_toggle_employee(p_employee_id uuid,p_target_status text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_target text:=case when p_target_status='active' then 'active' else 'inactive' end;
begin
 select e.organization_id into v_org from public.employees e where e.id=p_employee_id;
 if v_org is null then raise exception '找不到员工资料。'; end if;
 if not public.has_organization_role(v_org,array['owner','manager']) then raise exception '你没有修改员工状态的权限。'; end if;
 if v_target='inactive' then
   update public.employees e set employment_status='inactive',is_on_duty=false,left_at=current_date,updated_at=now() where e.id=p_employee_id;
   update public.employee_login_sessions ls set revoked_at=coalesce(ls.revoked_at,now()) where ls.employee_id=p_employee_id and ls.revoked_at is null;
   return jsonb_build_object('message','员工已停用；手机号登录立即失效，历史资料全部保留。');
 else
   update public.employees e set employment_status='active',is_on_duty=true,left_at=null,updated_at=now() where e.id=p_employee_id;
   return jsonb_build_object('message','员工与手机号登录已经重新启用。');
 end if;
end; $$;
revoke all on function public.v13_toggle_employee(uuid,text) from public;
grant execute on function public.v13_toggle_employee(uuid,text) to authenticated;

-- -----------------------------------------------------------------------------
-- Owner dashboard / health JSON RPCs
-- -----------------------------------------------------------------------------
create or replace function public.v13_owner_dashboard(p_store_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_result jsonb;
begin
 select s.organization_id into v_org from public.stores s where s.id=p_store_id;
 if v_org is null or not public.can_access_store(p_store_id) then raise exception '门店权限无效。'; end if;
 return jsonb_build_object(
  'customers',(select count(*) from public.customers c where c.organization_id=v_org and c.store_id=p_store_id),
  'active_employees',(select count(*) from public.employees e where e.organization_id=v_org and e.employment_status='active' and exists(select 1 from public.employee_stores es where es.employee_id=e.id and es.store_id=p_store_id and es.status='active')),
  'today_visits',(select count(*) from public.visits v where v.organization_id=v_org and v.store_id=p_store_id and coalesce(v.scheduled_at,v.created_at)::date=current_date and v.status not in ('cancelled','no_show')),
  'ready_checkout',(select count(*) from public.visits v where v.organization_id=v_org and v.store_id=p_store_id and v.status='ready_for_checkout'),
  'month_revenue',coalesce((select sum(p.grand_total) from public.payments p where p.organization_id=v_org and p.store_id=p_store_id and p.status='paid' and date_trunc('month',p.paid_at)=date_trunc('month',now())),0),
  'inventory_value',coalesce((select sum(coalesce(b.quantity,0)*coalesce(pr.cost_price,0)) from public.products pr left join public.inventory_balances b on b.product_id=pr.id and b.organization_id=pr.organization_id and b.store_id=pr.store_id where pr.organization_id=v_org and pr.store_id=p_store_id and pr.active),0)
 );
end; $$;
revoke all on function public.v13_owner_dashboard(uuid) from public;
grant execute on function public.v13_owner_dashboard(uuid) to authenticated;

-- -----------------------------------------------------------------------------
-- Branch activation: separate Supabase Auth account can redeem Creator BRN code.
-- -----------------------------------------------------------------------------
create or replace function public.redeem_branch_activation_code(p_code text,p_branch_name text,p_phone text default null,p_address text default null)
returns jsonb
language plpgsql security definer set search_path=public,extensions
as $$
declare v_user uuid:=auth.uid(); v_email text; v_code public.saas_activation_codes%rowtype; v_store uuid; v_sub uuid; v_start timestamptz:=now();
begin
 if v_user is null then raise exception '请先建立并登录分行 Supabase 账号。'; end if;
 select lower(email) into v_email from auth.users where id=v_user;
 select c.* into v_code from public.saas_activation_codes c where c.purpose='branch_signup' and c.code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex') and c.status='pending' and c.expires_at>=now() for update;
 if v_code.id is null then raise exception 'BRN Code 无效、已使用或已过期。'; end if;
 if v_code.target_email is not null and lower(v_code.target_email)<>v_email then raise exception '这个 BRN Code 不是发给当前 Email。'; end if;
 if trim(coalesce(p_branch_name,''))='' then p_branch_name:=coalesce(v_code.label,'SalonOS Branch'); end if;
 insert into public.profiles(id,full_name,phone) values(v_user,coalesce(v_code.label,p_branch_name),nullif(trim(coalesce(p_phone,'')),'')) on conflict(id) do update set phone=coalesce(excluded.phone,public.profiles.phone),updated_at=now();
 insert into public.organization_members(organization_id,user_id,role,status) values(v_code.target_organization_id,v_user,'manager','active') on conflict(organization_id,user_id) do update set role='manager',status='active',updated_at=now();
 insert into public.stores(organization_id,name,code,is_main,status,email,phone,address)
 values(v_code.target_organization_id,trim(p_branch_name),'BR-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,6)),false,'active',v_email,nullif(trim(coalesce(p_phone,'')),''),nullif(trim(coalesce(p_address,'')),'')) returning id into v_store;
 insert into public.store_members(organization_id,store_id,user_id,is_primary,status) values(v_code.target_organization_id,v_store,v_user,true,'active');
 insert into public.saas_subscriptions(organization_id,store_id,subscriber_user_id,subscription_type,plan_code,amount_rm,billing_months,status,starts_at,expires_at)
 values(v_code.target_organization_id,v_store,v_user,'branch',coalesce(v_code.plan_code,'monthly'),coalesce(v_code.amount_rm,100),coalesce(v_code.billing_months,1),'active',v_start,public.salonos_plan_expiry(coalesce(v_code.plan_code,'monthly'),v_start)) returning id into v_sub;
 update public.saas_activation_codes set status='used',used_at=now(),used_by_user_id=v_user,target_user_id=v_user,target_store_id=v_store where id=v_code.id;
 return jsonb_build_object('organization_id',v_code.target_organization_id,'store_id',v_store,'subscription_id',v_sub);
end; $$;
revoke all on function public.redeem_branch_activation_code(text,text,text,text) from public;
grant execute on function public.redeem_branch_activation_code(text,text,text,text) to authenticated;

-- -----------------------------------------------------------------------------
-- Health check
-- -----------------------------------------------------------------------------
create or replace function public.v13_healthcheck()
returns jsonb language sql stable security definer set search_path=public as $$
 select jsonb_build_object(
  'version','13.1.1',
  'auth_uid',auth.uid(),
  'organizations_table',to_regclass('public.organizations') is not null,
  'customers_table',to_regclass('public.customers') is not null,
  'employees_table',to_regclass('public.employees') is not null,
  'services_table',to_regclass('public.services') is not null,
  'visits_table',to_regclass('public.visits') is not null,
  'payments_table',to_regclass('public.payments') is not null,
  'products_table',to_regclass('public.products') is not null,
  'employee_sessions',to_regclass('public.employee_login_sessions') is not null,
  'kpi',to_regclass('public.v13_kpi_rules') is not null,
  'training',to_regclass('public.v13_training_courses') is not null,
  'bundles',to_regclass('public.v13_product_bundles') is not null
 );
$$;
revoke all on function public.v13_healthcheck() from public;
grant execute on function public.v13_healthcheck() to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values('backend_version','13.1.2-supabase-only-complete')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

-- Make sure PostgREST notices new/changed RPCs immediately.
notify pgrst,'reload schema';

select 'SalonOS v13.1.1 COMPLETE Supabase cutover installed' as status;


-- Final compatibility repair for every code function that uses pgcrypto.
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    select n.nspname schema_name,p.proname,pg_get_function_identity_arguments(p.oid) args
    from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname in (
      'salonos_new_code','creator_generate_owner_code','creator_generate_device_code','creator_generate_branch_code',
      'redeem_owner_activation_code','redeem_owner_activation_code_v2','redeem_device_activation_code','validate_owner_activation_code',
      'redeem_branch_activation_code','employee_phone_login','employee_session_context','employee_session_logout','v13_employee_api'
    )
  LOOP
    EXECUTE format('alter function %I.%I(%s) set search_path=public,extensions',r.schema_name,r.proname,r.args);
  END LOOP;
END $$;

-- Seed only safe defaults for existing organizations. No fake customers/employees/orders/products are created.
insert into public.membership_levels(organization_id,level_number,name,min_experience,discount_percent,points_multiplier,active)
select o.id,1,'等级 1',0,0,1,true from public.organizations o
where not exists(select 1 from public.membership_levels ml where ml.organization_id=o.id and ml.level_number=1)
on conflict do nothing;

insert into public.service_commission_settings(organization_id,mode,fixed_rate)
select o.id,'fixed',0 from public.organizations o
where not exists(select 1 from public.service_commission_settings cs where cs.organization_id=o.id)
on conflict(organization_id) do nothing;

insert into public.salonos_system_meta(meta_key,meta_value)
values('backend_version','13.1.2-supabase-only-complete')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

notify pgrst,'reload schema';

-- v13.1.2 pre-commit compatibility verification
do $$
declare
  v_phone_return text;
  v_context_return text;
begin
  select pg_get_function_result('public.employee_phone_login(text,text,text)'::regprocedure) into v_phone_return;
  select pg_get_function_result('public.employee_session_context(text)'::regprocedure) into v_context_return;
  if lower(v_phone_return) <> 'jsonb' then
    raise exception 'employee_phone_login return type is %, expected jsonb', v_phone_return;
  end if;
  if lower(v_context_return) <> 'jsonb' then
    raise exception 'employee_session_context return type is %, expected jsonb', v_context_return;
  end if;
end $$;

commit;

select 'SalonOS v13.1.2 FINAL HARDENED CUTOVER READY' as status;
select public.v13_healthcheck() as healthcheck;
-- SalonOS v13.2.0 · v12.4.1 Feature Bridge patch
-- Run ONCE in Supabase Dashboard -> SQL Editor after v13.1.2.
-- Additive/idempotent. It does not delete business data.
-- Purpose:
--   1) Fix v13.1.2 dashboard inventory error (b.quantity does not exist / 42703)
--   2) Expose a stable inventory snapshot based on the stock movement ledger
--   3) Mark the v12.4.1 feature-bridge runtime version

begin;
set local statement_timeout = '0';

-- Stock truth in the existing Supabase migration is inventory_stock_movements.quantity_delta.
-- Do not depend on the column names of inventory_balances, which differed between schema builds.
create or replace function public.v132_inventory_snapshot(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org uuid;
  v_result jsonb;
begin
  select s.organization_id into v_org
  from public.stores s
  where s.id = p_store_id;

  if v_org is null or not public.can_access_store(p_store_id) then
    raise exception '门店权限无效。';
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'product_id', x.product_id,
        'quantity', x.quantity
      )
      order by x.product_id
    ),
    '[]'::jsonb
  )
  into v_result
  from (
    select
      p.id as product_id,
      coalesce(sum(m.quantity_delta),0)::numeric as quantity
    from public.products p
    left join public.inventory_stock_movements m
      on m.product_id = p.id
    where p.organization_id = v_org
      and p.store_id = p_store_id
    group by p.id
  ) x;

  return coalesce(v_result,'[]'::jsonb);
end;
$$;

revoke all on function public.v132_inventory_snapshot(uuid) from public;
grant execute on function public.v132_inventory_snapshot(uuid) to authenticated;

-- Replace the v13.1.2 dashboard function so it no longer reads b.quantity.
create or replace function public.v13_owner_dashboard(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org uuid;
  v_inventory jsonb;
begin
  select s.organization_id into v_org
  from public.stores s
  where s.id = p_store_id;

  if v_org is null or not public.can_access_store(p_store_id) then
    raise exception '门店权限无效。';
  end if;

  v_inventory := public.v132_inventory_snapshot(p_store_id);

  return jsonb_build_object(
    'customers',(
      select count(*) from public.customers c
      where c.organization_id=v_org and c.store_id=p_store_id
    ),
    'active_employees',(
      select count(*) from public.employees e
      where e.organization_id=v_org
        and e.employment_status='active'
        and exists(
          select 1 from public.employee_stores es
          where es.employee_id=e.id and es.store_id=p_store_id and es.status='active'
        )
    ),
    'today_visits',(
      select count(*) from public.visits v
      where v.organization_id=v_org
        and v.store_id=p_store_id
        and coalesce(v.scheduled_at,v.created_at)::date=current_date
        and v.status not in ('cancelled','no_show')
    ),
    'ready_checkout',(
      select count(*) from public.visits v
      where v.organization_id=v_org and v.store_id=p_store_id and v.status='ready_for_checkout'
    ),
    'month_revenue',coalesce((
      select sum(p.grand_total) from public.payments p
      where p.organization_id=v_org
        and p.store_id=p_store_id
        and p.status='paid'
        and date_trunc('month',p.paid_at)=date_trunc('month',now())
    ),0),
    'inventory_value',coalesce((
      select sum(coalesce((item->>'quantity')::numeric,0) * coalesce(pr.cost_price,0))
      from jsonb_array_elements(v_inventory) item
      join public.products pr on pr.id=(item->>'product_id')::uuid
      where pr.organization_id=v_org and pr.store_id=p_store_id and pr.active
    ),0)
  );
end;
$$;

revoke all on function public.v13_owner_dashboard(uuid) from public;
grant execute on function public.v13_owner_dashboard(uuid) to authenticated;

-- Healthcheck version follows the deployed bridge, fixing the old 13.1.1/13.1.2 mismatch.
create or replace function public.v13_healthcheck()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
 select jsonb_build_object(
  'version','13.2.0',
  'auth_uid',auth.uid(),
  'organizations_table',to_regclass('public.organizations') is not null,
  'customers_table',to_regclass('public.customers') is not null,
  'employees_table',to_regclass('public.employees') is not null,
  'services_table',to_regclass('public.services') is not null,
  'visits_table',to_regclass('public.visits') is not null,
  'payments_table',to_regclass('public.payments') is not null,
  'products_table',to_regclass('public.products') is not null,
  'employee_sessions',to_regclass('public.employee_login_sessions') is not null,
  'kpi',to_regclass('public.v13_kpi_rules') is not null,
  'training',to_regclass('public.v13_training_courses') is not null,
  'bundles',to_regclass('public.v13_product_bundles') is not null,
  'inventory_snapshot',to_regprocedure('public.v132_inventory_snapshot(uuid)') is not null
 );
$$;
revoke all on function public.v13_healthcheck() from public;
grant execute on function public.v13_healthcheck() to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values
  ('backend_version','13.2.0-supabase-only-v12-feature-bridge'),
  ('ui_bridge_version','12.4.1-feature-map')
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

notify pgrst,'reload schema';
commit;

select 'SalonOS v13.2.0 PATCH READY' as status;
