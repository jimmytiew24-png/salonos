-- SalonOS v13.2.0 · v12.4.1 Feature Bridge patch
-- Run ONCE in Supabase Dashboard -> SQL Editor after v13.1.2.
-- Additive/idempotent. It does not delete business data.
-- Purpose:
--   1) Fix v13.1.2 dashboard inventory error (b.quantity does not exist / 42703)
--   2) Expose a stable inventory snapshot based on the stock movement ledger
--   3) Mark the v12.4.1 feature-bridge runtime version

begin;
set local statement_timeout = '0';

-- Stock truth in the existing Supabase migration is inventory_stock_movements.quantity_delta.
-- Do not depend on the column names of inventory_balances, which differed between schema builds.
create or replace function public.v132_inventory_snapshot(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org uuid;
  v_result jsonb;
begin
  select s.organization_id into v_org
  from public.stores s
  where s.id = p_store_id;

  if v_org is null or not public.can_access_store(p_store_id) then
    raise exception '门店权限无效。';
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'product_id', x.product_id,
        'quantity', x.quantity
      )
      order by x.product_id
    ),
    '[]'::jsonb
  )
  into v_result
  from (
    select
      p.id as product_id,
      coalesce(sum(m.quantity_delta),0)::numeric as quantity
    from public.products p
    left join public.inventory_stock_movements m
      on m.product_id = p.id
    where p.organization_id = v_org
      and p.store_id = p_store_id
    group by p.id
  ) x;

  return coalesce(v_result,'[]'::jsonb);
end;
$$;

revoke all on function public.v132_inventory_snapshot(uuid) from public;
grant execute on function public.v132_inventory_snapshot(uuid) to authenticated;

-- Replace the v13.1.2 dashboard function so it no longer reads b.quantity.
create or replace function public.v13_owner_dashboard(p_store_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org uuid;
  v_inventory jsonb;
begin
  select s.organization_id into v_org
  from public.stores s
  where s.id = p_store_id;

  if v_org is null or not public.can_access_store(p_store_id) then
    raise exception '门店权限无效。';
  end if;

  v_inventory := public.v132_inventory_snapshot(p_store_id);

  return jsonb_build_object(
    'customers',(
      select count(*) from public.customers c
      where c.organization_id=v_org and c.store_id=p_store_id
    ),
    'active_employees',(
      select count(*) from public.employees e
      where e.organization_id=v_org
        and e.employment_status='active'
        and exists(
          select 1 from public.employee_stores es
          where es.employee_id=e.id and es.store_id=p_store_id and es.status='active'
        )
    ),
    'today_visits',(
      select count(*) from public.visits v
      where v.organization_id=v_org
        and v.store_id=p_store_id
        and coalesce(v.scheduled_at,v.created_at)::date=current_date
        and v.status not in ('cancelled','no_show')
    ),
    'ready_checkout',(
      select count(*) from public.visits v
      where v.organization_id=v_org and v.store_id=p_store_id and v.status='ready_for_checkout'
    ),
    'month_revenue',coalesce((
      select sum(p.grand_total) from public.payments p
      where p.organization_id=v_org
        and p.store_id=p_store_id
        and p.status='paid'
        and date_trunc('month',p.paid_at)=date_trunc('month',now())
    ),0),
    'inventory_value',coalesce((
      select sum(coalesce((item->>'quantity')::numeric,0) * coalesce(pr.cost_price,0))
      from jsonb_array_elements(v_inventory) item
      join public.products pr on pr.id=(item->>'product_id')::uuid
      where pr.organization_id=v_org and pr.store_id=p_store_id and pr.active
    ),0)
  );
end;
$$;

revoke all on function public.v13_owner_dashboard(uuid) from public;
grant execute on function public.v13_owner_dashboard(uuid) to authenticated;

-- Healthcheck version follows the deployed bridge, fixing the old 13.1.1/13.1.2 mismatch.
create or replace function public.v13_healthcheck()
returns jsonb
language sql
stable
security definer
set search_path=public
as $$
 select jsonb_build_object(
  'version','13.2.0',
  'auth_uid',auth.uid(),
  'organizations_table',to_regclass('public.organizations') is not null,
  'customers_table',to_regclass('public.customers') is not null,
  'employees_table',to_regclass('public.employees') is not null,
  'services_table',to_regclass('public.services') is not null,
  'visits_table',to_regclass('public.visits') is not null,
  'payments_table',to_regclass('public.payments') is not null,
  'products_table',to_regclass('public.products') is not null,
  'employee_sessions',to_regclass('public.employee_login_sessions') is not null,
  'kpi',to_regclass('public.v13_kpi_rules') is not null,
  'training',to_regclass('public.v13_training_courses') is not null,
  'bundles',to_regclass('public.v13_product_bundles') is not null,
  'inventory_snapshot',to_regprocedure('public.v132_inventory_snapshot(uuid)') is not null
 );
$$;
revoke all on function public.v13_healthcheck() from public;
grant execute on function public.v13_healthcheck() to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values
  ('backend_version','13.2.0-supabase-only-v12-feature-bridge'),
  ('ui_bridge_version','12.4.1-feature-map')
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

notify pgrst,'reload schema';
commit;

select 'SalonOS v13.2.0 PATCH READY' as status;
