-- SalonOS v13.3.1 · 4-step order wizard + Supabase confirmation
-- Run ONCE in Supabase Dashboard -> SQL Editor -> New query -> Run.
-- Additive: does not delete existing SalonOS business data.

begin;
set local statement_timeout='0';
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.v13_visit_confirmations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  visit_id uuid not null unique references public.visits(id) on delete cascade,
  customer_name text not null,
  signature_data text not null,
  order_snapshot jsonb not null default '{}'::jsonb,
  signed_at timestamptz not null default now(),
  created_by_user_id uuid null references auth.users(id) on delete set null,
  created_by_employee_id uuid null references public.employees(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists v13_visit_confirmations_org_store_idx on public.v13_visit_confirmations(organization_id,store_id,signed_at desc);

alter table public.v13_visit_confirmations enable row level security;
drop policy if exists v1331_confirmation_read on public.v13_visit_confirmations;
create policy v1331_confirmation_read on public.v13_visit_confirmations
for select to authenticated using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v1331_confirmation_manage on public.v13_visit_confirmations;
create policy v1331_confirmation_manage on public.v13_visit_confirmations
for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));
grant select,insert,update on public.v13_visit_confirmations to authenticated;

create or replace function public.v1331_employee_customer_search(p_session_token text,p_query text)
returns jsonb
language plpgsql security definer set search_path=public,extensions
as $$
declare v_ctx jsonb; v_org uuid; v_store uuid; v_q text:=lower(trim(coalesce(p_query,''))); v_result jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid;
  if length(v_q)<2 then return '[]'::jsonb; end if;
  select coalesce(jsonb_agg(x order by x->>'name'),'[]'::jsonb) into v_result from (
    select jsonb_build_object(
      'id',c.id,'name',c.name,'phone',c.phone,
      'member_number',m.member_number,'member_level',ml.name,'level_number',ml.level_number
    ) x
    from public.customers c
    left join public.memberships m on m.customer_id=c.id and m.organization_id=c.organization_id and m.status='active'
    left join public.membership_levels ml on ml.id=m.current_level_id and ml.organization_id=c.organization_id
    where c.organization_id=v_org and c.store_id=v_store
      and lower(coalesce(c.name,'')||' '||coalesce(c.phone,'')||' '||coalesce(m.member_number,'')) like '%'||v_q||'%'
    order by c.created_at desc limit 20
  ) q;
  return v_result;
end; $$;
revoke all on function public.v1331_employee_customer_search(text,text) from public;
grant execute on function public.v1331_employee_customer_search(text,text) to anon,authenticated;

create or replace function public.v1331_employee_create_visit(p_session_token text,p_payload jsonb)
returns jsonb
language plpgsql security definer set search_path=public,extensions
as $$
declare
  v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid;
  v_visit uuid:=gen_random_uuid(); v_customer uuid; v_rec uuid:=gen_random_uuid();
  v_name text:=trim(coalesce(p_payload->>'customer_name','')); v_phone text:=trim(coalesce(p_payload->>'customer_phone',''));
  v_type text:=case when p_payload->>'visit_type'='appointment' then 'appointment' else 'walk_in' end;
  v_assignment text:=case when p_payload->>'assignment_type'='system' then 'system' else 'specified' end;
  v_sched timestamptz; v_recmap jsonb:= '{}'::jsonb; v_r jsonb; v_key text; v_rel text; v_rid uuid;
  v_line jsonb; v_sid uuid; v_sv public.services%rowtype; v_si uuid; v_target_rec uuid; v_price numeric;
  v_lead uuid; v_emp uuid; v_role text; v_co jsonb; v_as jsonb; v_co_count int; v_as_count int; v_pct numeric;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid; v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid;

  if nullif(p_payload->>'customer_id','') is not null then
    v_customer:=(p_payload->>'customer_id')::uuid;
    select c.name,c.phone into v_name,v_phone from public.customers c where c.id=v_customer and c.organization_id=v_org and c.store_id=v_store;
    if v_name is null then raise exception '选择的顾客不存在或不属于当前分行。'; end if;
  else
    if v_name='' or v_phone='' then raise exception '顾客姓名与电话必填。'; end if;
    select c.id into v_customer from public.customers c
      where c.organization_id=v_org and c.store_id=v_store and regexp_replace(coalesce(c.phone,''),'[^0-9]','','g')=regexp_replace(v_phone,'[^0-9]','','g')
      order by c.created_at desc limit 1;
    if v_customer is null then
      insert into public.customers(organization_id,store_id,name,phone,gender,ethnicity)
      values(v_org,v_store,v_name,v_phone,'unspecified',nullif(trim(coalesce(p_payload->>'customer_ethnicity','')),'')) returning id into v_customer;
    end if;
  end if;

  if v_type='appointment' then
    if nullif(p_payload->>'scheduled_at','') is null then raise exception '预约订单必须填写预约日期与时间。'; end if;
    v_sched:=(p_payload->>'scheduled_at')::timestamptz;
  end if;

  insert into public.visits(id,organization_id,store_id,visit_number,visit_type,status,scheduled_at,arrived_at,notes)
  values(v_visit,v_org,v_store,'V'||to_char(now(),'YYMMDDHH24MISS')||'-'||upper(substr(encode(extensions.gen_random_bytes(3),'hex'),1,4)),v_type,
    case when v_type='appointment' then 'booked' else 'arrived' end,v_sched,case when v_type='walk_in' then now() else null end,nullif(p_payload->>'notes',''));

  insert into public.visit_recipients(id,organization_id,visit_id,customer_id,name_snapshot,phone_snapshot,recipient_type)
  values(v_rec,v_org,v_visit,v_customer,v_name,v_phone,'primary');
  v_recmap:=jsonb_set(v_recmap,array['self'],to_jsonb(v_rec::text),true);

  for v_r in select * from jsonb_array_elements(coalesce(p_payload->'recipients','[]'::jsonb)) loop
    v_key:=trim(coalesce(v_r->>'key','')); if v_key='' or trim(coalesce(v_r->>'name',''))='' then continue; end if;
    v_rel:=trim(coalesce(v_r->>'relationship','同行者')); v_rid:=gen_random_uuid();
    insert into public.visit_recipients(id,organization_id,visit_id,customer_id,name_snapshot,phone_snapshot,recipient_type,notes)
    values(v_rid,v_org,v_visit,null,trim(v_r->>'name'),null,
      case v_rel when '孩子' then 'child' when '长辈' then 'family' when '家人' then 'family' when '朋友' then 'friend' when '同行者' then 'friend' else 'other' end,
      v_rel||case when nullif(v_r->>'age','') is not null then ' · Age: '||(v_r->>'age') else '' end);
    v_recmap:=jsonb_set(v_recmap,array[v_key],to_jsonb(v_rid::text),true);
  end loop;

  for v_line in select * from jsonb_array_elements(coalesce(p_payload->'items','[]'::jsonb)) loop
    if nullif(v_line->>'service_id','') is null then continue; end if;
    v_sid:=(v_line->>'service_id')::uuid;
    select s.* into v_sv from public.services s where s.id=v_sid and s.organization_id=v_org and s.store_id=v_store and s.active;
    if v_sv.id is null then continue; end if;
    v_key:=coalesce(nullif(v_line->>'recipient_key',''),'self');
    v_target_rec:=coalesce(nullif(v_recmap->>v_key,'')::uuid,v_rec);
    v_price:=coalesce(nullif(v_line->>'price','')::numeric,v_sv.default_price);
    insert into public.visit_service_items(organization_id,store_id,visit_id,recipient_id,service_id,service_name_snapshot,service_category_snapshot,unit_price,quantity,estimated_minutes_snapshot,status)
    values(v_org,v_store,v_visit,v_target_rec,v_sv.id,v_sv.name,v_sv.category,greatest(0,v_price),1,v_sv.estimated_minutes,'waiting') returning id into v_si;

    if v_assignment='system' or nullif(v_line->>'lead_employee_id','') is null then v_lead:=v_e; else v_lead:=(v_line->>'lead_employee_id')::uuid; end if;
    if not exists(select 1 from public.employees ee join public.employee_stores es on es.employee_id=ee.id and es.organization_id=ee.organization_id
      where ee.id=v_lead and ee.organization_id=v_org and ee.employment_status='active' and es.store_id=v_store and es.status='active') then
      if v_assignment='specified' then raise exception '指定的主理发师无效。'; else v_lead:=v_e; end if;
    end if;

    v_co:=coalesce(v_line->'co_stylists','[]'::jsonb); v_as:=coalesce(v_line->'assistants','[]'::jsonb);
    select count(*) into v_co_count from (select distinct value from jsonb_array_elements_text(v_co) where value<>'' and value<>v_lead::text) x;
    select count(*) into v_as_count from (select distinct value from jsonb_array_elements_text(v_as) where value<>'' and value<>v_lead::text) x;
    v_pct:=case when v_co_count>0 and v_as_count>0 then 60 when v_co_count>0 then 75 when v_as_count>0 then 80 else 100 end;
    insert into public.visit_service_workers(organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status)
    values(v_org,v_store,v_si,v_lead,'primary',v_pct,'active');

    if v_co_count>0 then
      for v_emp in select distinct value::uuid from jsonb_array_elements_text(v_co) where value<>'' and value<>v_lead::text loop
        if exists(select 1 from public.employees ee join public.employee_stores es on es.employee_id=ee.id and es.organization_id=ee.organization_id where ee.id=v_emp and ee.organization_id=v_org and ee.employment_status='active' and es.store_id=v_store and es.status='active') then
          insert into public.visit_service_workers(organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status)
          values(v_org,v_store,v_si,v_emp,'support',25.0/v_co_count,'active') on conflict do nothing;
        end if;
      end loop;
    end if;
    if v_as_count>0 then
      for v_emp in select distinct value::uuid from jsonb_array_elements_text(v_as) where value<>'' and value<>v_lead::text loop
        if not exists(select 1 from public.visit_service_workers w where w.service_item_id=v_si and w.employee_id=v_emp) and exists(select 1 from public.employees ee join public.employee_stores es on es.employee_id=ee.id and es.organization_id=ee.organization_id where ee.id=v_emp and ee.organization_id=v_org and ee.employment_status='active' and es.store_id=v_store and es.status='active') then
          insert into public.visit_service_workers(organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status)
          values(v_org,v_store,v_si,v_emp,'assistant',(case when v_co_count>0 then 15.0 else 20.0 end)/v_as_count,'active') on conflict do nothing;
        end if;
      end loop;
    end if;
  end loop;

  if not exists(select 1 from public.visit_service_items si where si.visit_id=v_visit) then raise exception '请至少选择一个服务项目。'; end if;
  return jsonb_build_object('visit_id',v_visit);
end; $$;
revoke all on function public.v1331_employee_create_visit(text,jsonb) from public;
grant execute on function public.v1331_employee_create_visit(text,jsonb) to anon,authenticated;

create or replace function public.v1331_employee_order_review(p_session_token text,p_visit_id uuid)
returns jsonb
language plpgsql security definer set search_path=public,extensions
as $$
declare v_ctx jsonb; v_org uuid; v_store uuid; v_result jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid;
  if not exists(select 1 from public.visits v where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store) then raise exception '找不到订单。'; end if;
  return jsonb_build_object(
    'visit',(select to_jsonb(v) from public.visits v where v.id=p_visit_id),
    'recipients',coalesce((select jsonb_agg(to_jsonb(r) order by r.created_at) from public.visit_recipients r where r.organization_id=v_org and r.visit_id=p_visit_id),'[]'::jsonb),
    'items',coalesce((select jsonb_agg(jsonb_build_object(
      'id',si.id,'recipient_id',si.recipient_id,'service_id',si.service_id,'service_name_snapshot',si.service_name_snapshot,'service_category_snapshot',si.service_category_snapshot,
      'unit_price',si.unit_price,'quantity',si.quantity,'line_total',si.line_total,'estimated_minutes_snapshot',si.estimated_minutes_snapshot,'status',si.status,
      'workers',coalesce((select jsonb_agg(jsonb_build_object('employee_id',w.employee_id,'employee_name',e.name,'worker_role',w.worker_role,'contribution_percent',w.contribution_percent) order by case w.worker_role when 'primary' then 1 when 'support' then 2 else 3 end,e.name)
        from public.visit_service_workers w join public.employees e on e.id=w.employee_id where w.service_item_id=si.id and w.organization_id=v_org and w.status='active'),'[]'::jsonb)
    ) order by si.created_at) from public.visit_service_items si where si.organization_id=v_org and si.visit_id=p_visit_id and si.status<>'cancelled'),'[]'::jsonb)
  );
end; $$;
revoke all on function public.v1331_employee_order_review(text,uuid) from public;
grant execute on function public.v1331_employee_order_review(text,uuid) to anon,authenticated;

create or replace function public.v1331_employee_confirm_visit(p_session_token text,p_visit_id uuid,p_customer_name text,p_signature_data text)
returns jsonb
language plpgsql security definer set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_type text; v_snapshot jsonb;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid; v_org:=(v_ctx->>'organization_id')::uuid; v_store:=(v_ctx->>'store_id')::uuid;
  if length(coalesce(p_signature_data,''))<40 then raise exception '请先完成顾客签名。'; end if;
  select v.visit_type into v_type from public.visits v where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store;
  if v_type is null then raise exception '找不到订单。'; end if;
  v_snapshot:=public.v1331_employee_order_review(p_session_token,p_visit_id);
  insert into public.v13_visit_confirmations(organization_id,store_id,visit_id,customer_name,signature_data,order_snapshot,signed_at,created_by_employee_id,updated_at)
  values(v_org,v_store,p_visit_id,coalesce(nullif(trim(p_customer_name),''),'顾客'),p_signature_data,v_snapshot,now(),v_e,now())
  on conflict(visit_id) do update set customer_name=excluded.customer_name,signature_data=excluded.signature_data,order_snapshot=excluded.order_snapshot,signed_at=now(),created_by_employee_id=excluded.created_by_employee_id,updated_at=now();
  if v_type='walk_in' then update public.visits set status='waiting',updated_at=now() where id=p_visit_id; end if;
  return jsonb_build_object('ok',true,'visit_id',p_visit_id);
end; $$;
revoke all on function public.v1331_employee_confirm_visit(text,uuid,text,text) from public;
grant execute on function public.v1331_employee_confirm_visit(text,uuid,text,text) to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values('order_wizard_version','13.3.1-four-step-supabase')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
select 'SalonOS v13.3.1 ORDER WIZARD READY' as result;
