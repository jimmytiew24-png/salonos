-- SalonOS v13.4.1 MASTER SPEC PATCH
-- Run AFTER the existing v13.3.1 order-wizard SQL.
-- Additive only: no business data is deleted.
-- Focus: appointment stylist preference + explicit multi-worker Contribution % + employee-side 4-step order parity.

begin;
set local statement_timeout = '0';

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.appointment_employee_preferences (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  visit_id uuid not null references public.visits(id) on delete cascade,
  preference_type text not null default 'random' check (preference_type in ('random','specified')),
  employee_id uuid null references public.employees(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(visit_id)
);

create index if not exists appointment_employee_preferences_org_store_idx
  on public.appointment_employee_preferences(organization_id,store_id,created_at desc);
create index if not exists appointment_employee_preferences_employee_idx
  on public.appointment_employee_preferences(employee_id,created_at desc);

alter table public.appointment_employee_preferences enable row level security;

drop policy if exists appointment_preference_read on public.appointment_employee_preferences;
create policy appointment_preference_read on public.appointment_employee_preferences
for select to authenticated
using (public.is_organization_member(organization_id));

drop policy if exists appointment_preference_manage on public.appointment_employee_preferences;
create policy appointment_preference_manage on public.appointment_employee_preferences
for all to authenticated
using (public.has_organization_role(organization_id,array['owner','manager','receptionist']))
with check (public.has_organization_role(organization_id,array['owner','manager','receptionist']));

create or replace function public.v134_employee_create_visit(p_session_token text,p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_ctx jsonb;
  v_e uuid;
  v_org uuid;
  v_store uuid;

  v_visit uuid:=gen_random_uuid();
  v_customer uuid;
  v_rec uuid:=gen_random_uuid();

  v_name text:=trim(coalesce(p_payload->>'customer_name',''));
  v_phone text:=trim(coalesce(p_payload->>'customer_phone',''));
  v_gender text:=case when p_payload->>'customer_gender' in ('male','female','unspecified') then p_payload->>'customer_gender' else 'unspecified' end;
  v_ethnicity text:=nullif(trim(coalesce(p_payload->>'customer_ethnicity','')),'');
  v_birth_date date;
  v_age text:=trim(coalesce(p_payload->>'customer_age',''));

  v_type text:=case when p_payload->>'visit_type'='appointment' then 'appointment' else 'walk_in' end;
  v_assignment text:=case when p_payload->>'assignment_type'='system' then 'system' else 'specified' end;
  v_appointment_assignment text:=case when p_payload->>'appointment_assignment_type'='specified' then 'specified' else 'system' end;
  v_appointment_employee uuid;
  v_sched timestamptz;

  v_recmap jsonb:='{}'::jsonb;
  v_r jsonb;
  v_key text;
  v_rel text;
  v_rid uuid;

  v_line jsonb;
  v_sid uuid;
  v_sv public.services%rowtype;
  v_si uuid;
  v_target_rec uuid;
  v_price numeric;

  v_lead uuid;
  v_emp uuid;
  v_co jsonb;
  v_as jsonb;
  v_co_pct jsonb;
  v_as_pct jsonb;
  v_co_count int;
  v_as_count int;
  v_default_lead numeric;
  v_default_co_pool numeric;
  v_default_as_pool numeric;
  v_lead_pct numeric;
  v_one_pct numeric;
  v_total_pct numeric;
  v_ord bigint;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;

  if nullif(p_payload->>'customer_birth_date','') is not null then
    begin
      v_birth_date:=(p_payload->>'customer_birth_date')::date;
    exception when others then
      raise exception '顾客出生日期格式无效。';
    end;
  end if;

  if nullif(p_payload->>'customer_id','') is not null then
    v_customer:=(p_payload->>'customer_id')::uuid;
    select c.name,c.phone into v_name,v_phone
      from public.customers c
      where c.id=v_customer and c.organization_id=v_org and c.store_id=v_store;
    if v_name is null then raise exception '选择的顾客不存在或不属于当前分行。'; end if;
  else
    if v_name='' or v_phone='' then raise exception '顾客姓名与电话必填。'; end if;
    select c.id into v_customer
      from public.customers c
      where c.organization_id=v_org
        and c.store_id=v_store
        and regexp_replace(coalesce(c.phone,''),'[^0-9]','','g')=regexp_replace(v_phone,'[^0-9]','','g')
      order by c.created_at desc
      limit 1;

    if v_customer is null then
      insert into public.customers(organization_id,store_id,name,phone,gender,birth_date,ethnicity,notes)
      values(
        v_org,v_store,v_name,v_phone,v_gender,v_birth_date,v_ethnicity,
        case when v_age ~ '^[0-9]+$' then 'Order intake age: '||greatest(0,least(120,v_age::int))::text else null end
      )
      returning id into v_customer;
    end if;
  end if;

  if v_type='appointment' then
    if nullif(p_payload->>'scheduled_at','') is null then
      raise exception '预约订单必须填写预约日期与时间。';
    end if;
    v_sched:=(p_payload->>'scheduled_at')::timestamptz;

    if v_appointment_assignment='specified' then
      if nullif(p_payload->>'appointment_employee_id','') is null then
        raise exception '请选择预约指定理发师。';
      end if;
      v_appointment_employee:=(p_payload->>'appointment_employee_id')::uuid;
      if not exists(
        select 1
        from public.employees ee
        join public.employee_stores es
          on es.employee_id=ee.id and es.organization_id=ee.organization_id
        where ee.id=v_appointment_employee
          and ee.organization_id=v_org
          and ee.employment_status='active'
          and es.store_id=v_store
          and es.status='active'
      ) then
        raise exception '预约指定的理发师无效或已停用。';
      end if;
    end if;
  end if;

  insert into public.visits(
    id,organization_id,store_id,visit_number,visit_type,status,scheduled_at,arrived_at,notes
  )
  values(
    v_visit,v_org,v_store,
    'V'||to_char(now(),'YYMMDDHH24MISS')||'-'||upper(substr(encode(extensions.gen_random_bytes(3),'hex'),1,4)),
    v_type,
    case when v_type='appointment' then 'booked' else 'arrived' end,
    v_sched,
    case when v_type='walk_in' then now() else null end,
    nullif(p_payload->>'notes','')
  );

  if v_type='appointment' then
    insert into public.appointment_employee_preferences(
      organization_id,store_id,visit_id,preference_type,employee_id,updated_at
    )
    values(
      v_org,v_store,v_visit,
      case when v_appointment_assignment='specified' then 'specified' else 'random' end,
      case when v_appointment_assignment='specified' then v_appointment_employee else null end,
      now()
    )
    on conflict(visit_id) do update set
      preference_type=excluded.preference_type,
      employee_id=excluded.employee_id,
      updated_at=now();
  end if;

  insert into public.visit_recipients(
    id,organization_id,visit_id,customer_id,name_snapshot,phone_snapshot,recipient_type
  )
  values(v_rec,v_org,v_visit,v_customer,v_name,v_phone,'primary');
  v_recmap:=jsonb_set(v_recmap,array['self'],to_jsonb(v_rec::text),true);

  for v_r in
    select * from jsonb_array_elements(coalesce(p_payload->'recipients','[]'::jsonb))
  loop
    v_key:=trim(coalesce(v_r->>'key',''));
    if v_key='' or trim(coalesce(v_r->>'name',''))='' then continue; end if;
    v_rel:=trim(coalesce(v_r->>'relationship','同行者'));
    v_rid:=gen_random_uuid();

    insert into public.visit_recipients(
      id,organization_id,visit_id,customer_id,name_snapshot,phone_snapshot,recipient_type,notes
    )
    values(
      v_rid,v_org,v_visit,null,trim(v_r->>'name'),null,
      case v_rel
        when '孩子' then 'child'
        when '长辈' then 'family'
        when '家人' then 'family'
        when '朋友' then 'friend'
        when '同行者' then 'friend'
        else 'other'
      end,
      v_rel||case when nullif(v_r->>'age','') is not null then ' · Age: '||(v_r->>'age') else '' end
    );
    v_recmap:=jsonb_set(v_recmap,array[v_key],to_jsonb(v_rid::text),true);
  end loop;

  for v_line in
    select * from jsonb_array_elements(coalesce(p_payload->'items','[]'::jsonb))
  loop
    if nullif(v_line->>'service_id','') is null then continue; end if;
    v_sid:=(v_line->>'service_id')::uuid;

    select s.* into v_sv
      from public.services s
      where s.id=v_sid
        and s.organization_id=v_org
        and s.store_id=v_store
        and s.active;
    if v_sv.id is null then continue; end if;

    v_key:=coalesce(nullif(v_line->>'recipient_key',''),'self');
    v_target_rec:=coalesce(nullif(v_recmap->>v_key,'')::uuid,v_rec);
    v_price:=coalesce(nullif(v_line->>'price','')::numeric,v_sv.default_price);

    insert into public.visit_service_items(
      organization_id,store_id,visit_id,recipient_id,service_id,
      service_name_snapshot,service_category_snapshot,unit_price,quantity,
      estimated_minutes_snapshot,status
    )
    values(
      v_org,v_store,v_visit,v_target_rec,v_sv.id,v_sv.name,v_sv.category,
      greatest(0,v_price),1,v_sv.estimated_minutes,'waiting'
    )
    returning id into v_si;

    if v_assignment='system' or nullif(v_line->>'lead_employee_id','') is null then
      v_lead:=coalesce(v_appointment_employee,v_e);
    else
      v_lead:=(v_line->>'lead_employee_id')::uuid;
    end if;

    if not exists(
      select 1
      from public.employees ee
      join public.employee_stores es
        on es.employee_id=ee.id and es.organization_id=ee.organization_id
      where ee.id=v_lead
        and ee.organization_id=v_org
        and ee.employment_status='active'
        and es.store_id=v_store
        and es.status='active'
    ) then
      if v_assignment='specified' then
        raise exception '指定的主理发师无效。';
      else
        v_lead:=v_e;
      end if;
    end if;

    v_co:=coalesce(v_line->'co_stylists','[]'::jsonb);
    v_as:=coalesce(v_line->'assistants','[]'::jsonb);
    v_co_pct:=coalesce(v_line->'co_contributions','[]'::jsonb);
    v_as_pct:=coalesce(v_line->'assistant_contributions','[]'::jsonb);

    select count(*) into v_co_count
      from (
        select distinct value
        from jsonb_array_elements_text(v_co)
        where value<>'' and value<>v_lead::text
      ) x;

    select count(*) into v_as_count
      from (
        select distinct value
        from jsonb_array_elements_text(v_as)
        where value<>'' and value<>v_lead::text
      ) x;

    if v_co_count>0 and v_as_count>0 then
      v_default_lead:=60; v_default_co_pool:=25; v_default_as_pool:=15;
    elsif v_co_count>0 then
      v_default_lead:=75; v_default_co_pool:=25; v_default_as_pool:=0;
    elsif v_as_count>0 then
      v_default_lead:=80; v_default_co_pool:=0; v_default_as_pool:=20;
    else
      v_default_lead:=100; v_default_co_pool:=0; v_default_as_pool:=0;
    end if;

    v_lead_pct:=coalesce(nullif(v_line->>'lead_contribution','')::numeric,v_default_lead);
    if v_lead_pct<0 or v_lead_pct>100 then raise exception 'Contribution %% 必须介于 0 到 100。'; end if;
    v_total_pct:=v_lead_pct;

    insert into public.visit_service_workers(
      organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status
    )
    values(v_org,v_store,v_si,v_lead,'primary',round(v_lead_pct,2),'active');

    if v_co_count>0 then
      for v_emp,v_ord in
        select value::uuid,ord
        from jsonb_array_elements_text(v_co) with ordinality as t(value,ord)
        where value<>'' and value<>v_lead::text
      loop
        if exists(select 1 from public.visit_service_workers w where w.service_item_id=v_si and w.employee_id=v_emp) then
          raise exception '同一位员工不能在同一个项目重复担任多个角色。';
        end if;
        if not exists(
          select 1 from public.employees ee
          join public.employee_stores es on es.employee_id=ee.id and es.organization_id=ee.organization_id
          where ee.id=v_emp and ee.organization_id=v_org and ee.employment_status='active'
            and es.store_id=v_store and es.status='active'
        ) then
          raise exception '共同理发师无效或已停用。';
        end if;

        v_one_pct:=coalesce(
          nullif(v_co_pct->>((v_ord-1)::int),'')::numeric,
          case when v_co_count>0 then v_default_co_pool/v_co_count else 0 end
        );
        if v_one_pct<0 or v_one_pct>100 then raise exception 'Contribution %% 必须介于 0 到 100。'; end if;
        v_total_pct:=v_total_pct+v_one_pct;

        insert into public.visit_service_workers(
          organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status
        )
        values(v_org,v_store,v_si,v_emp,'support',round(v_one_pct,2),'active');
      end loop;
    end if;

    if v_as_count>0 then
      for v_emp,v_ord in
        select value::uuid,ord
        from jsonb_array_elements_text(v_as) with ordinality as t(value,ord)
        where value<>'' and value<>v_lead::text
      loop
        if exists(select 1 from public.visit_service_workers w where w.service_item_id=v_si and w.employee_id=v_emp) then
          raise exception '同一位员工不能在同一个项目重复担任多个角色。';
        end if;
        if not exists(
          select 1 from public.employees ee
          join public.employee_stores es on es.employee_id=ee.id and es.organization_id=ee.organization_id
          where ee.id=v_emp and ee.organization_id=v_org and ee.employment_status='active'
            and es.store_id=v_store and es.status='active'
        ) then
          raise exception '助理无效或已停用。';
        end if;

        v_one_pct:=coalesce(
          nullif(v_as_pct->>((v_ord-1)::int),'')::numeric,
          case when v_as_count>0 then v_default_as_pool/v_as_count else 0 end
        );
        if v_one_pct<0 or v_one_pct>100 then raise exception 'Contribution %% 必须介于 0 到 100。'; end if;
        v_total_pct:=v_total_pct+v_one_pct;

        insert into public.visit_service_workers(
          organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status
        )
        values(v_org,v_store,v_si,v_emp,'assistant',round(v_one_pct,2),'active');
      end loop;
    end if;

    if abs(v_total_pct-100)>0.05 then
      raise exception '每个服务项目的 Contribution %% 总和必须为 100，目前为 %。',round(v_total_pct,2);
    end if;
  end loop;

  if not exists(select 1 from public.visit_service_items si where si.visit_id=v_visit) then
    raise exception '请至少选择一个服务项目。';
  end if;

  return jsonb_build_object('visit_id',v_visit);
end;
$$;

revoke all on function public.v134_employee_create_visit(text,jsonb) from public;
grant execute on function public.v134_employee_create_visit(text,jsonb) to anon,authenticated;

insert into public.salonos_system_meta(meta_key,meta_value)
values('order_wizard_version','13.4.0-master-spec-four-step')
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

insert into public.salonos_system_meta(meta_key,meta_value)
values('master_spec_version','13.4.1')
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

commit;

select 'SalonOS v13.4.1 MASTER SPEC PATCH READY' as result;
