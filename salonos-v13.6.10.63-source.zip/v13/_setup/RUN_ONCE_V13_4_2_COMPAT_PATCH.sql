-- SalonOS v13.4.2 · compatibility patch
-- Safe/additive. Does not delete business data.
-- Fixes employee_stores.updated_at mismatch seen by the v13 employee save RPC.

begin;
set local statement_timeout='0';

alter table public.employee_stores
  add column if not exists updated_at timestamptz not null default now();

-- The active v13 UI already understands these live availability values. Add the
-- column only when an older base schema does not have it yet.
alter table public.employees
  add column if not exists availability_status text not null default 'available';

DO $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid='public.employees'::regclass
      and conname='employees_availability_status_check'
  ) then
    alter table public.employees
      add constraint employees_availability_status_check
      check (availability_status in ('available','break','off_duty','in_service','busy','disabled','inactive'));
  end if;
end $$;

insert into public.salonos_system_meta(meta_key,meta_value)
values('compat_patch_version','13.4.2')
on conflict(meta_key) do update
set meta_value=excluded.meta_value,updated_at=now();

commit;

select 'SalonOS v13.4.2 COMPAT PATCH READY' as result;
