-- SalonOS v13.4.3 · Schema Contract Sync
-- Additive/idempotent: safe to run more than once. Does not delete business data.
-- Fixes PGRST204 for visit_service_items.service_category_snapshot and keeps
-- the previous v13.4.2 employee compatibility fixes in one cumulative patch.

begin;
set local statement_timeout='0';

-- v13.4.2 compatibility: employee-store mapping timestamp.
alter table public.employee_stores
  add column if not exists updated_at timestamptz not null default now();

-- v13.4.2 compatibility: employee live availability state.
alter table public.employees
  add column if not exists availability_status text not null default 'available';

-- Normalize any legacy/unexpected value before installing the constraint.
update public.employees
set availability_status='available'
where availability_status is null
   or availability_status not in ('available','break','off_duty','in_service','busy','disabled','inactive');

DO $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid='public.employees'::regclass
      and conname='employees_availability_status_check'
  ) then
    alter table public.employees
      add constraint employees_availability_status_check
      check (availability_status in ('available','break','off_duty','in_service','busy','disabled','inactive'));
  end if;
end $$;

-- v13 order/service-item schema contract.
-- Current v13 PHP + RPCs persist the service category snapshot so old orders
-- keep the category that was true at the time the order was created.
alter table public.visit_service_items
  add column if not exists service_category_snapshot text;

-- Backfill the snapshot for existing rows where the original service still exists.
update public.visit_service_items si
set service_category_snapshot = s.category
from public.services s
where si.service_category_snapshot is null
  and si.service_id = s.id
  and si.organization_id = s.organization_id
  and (si.store_id is null or si.store_id = s.store_id);

-- Record the applied compatibility level when SalonOS metadata is present.
DO $$
begin
  if to_regclass('public.salonos_system_meta') is not null then
    insert into public.salonos_system_meta(meta_key,meta_value)
    values('compat_patch_version','13.4.3')
    on conflict(meta_key) do update
    set meta_value=excluded.meta_value,updated_at=now();
  end if;
end $$;

commit;

-- Ask Supabase PostgREST to refresh its schema cache immediately.
notify pgrst, 'reload schema';

select
  'SalonOS v13.4.3 SCHEMA CONTRACT READY' as result,
  exists(
    select 1 from information_schema.columns
    where table_schema='public' and table_name='visit_service_items' and column_name='service_category_snapshot'
  ) as visit_service_category_snapshot_ok,
  exists(
    select 1 from information_schema.columns
    where table_schema='public' and table_name='employee_stores' and column_name='updated_at'
  ) as employee_stores_updated_at_ok;
