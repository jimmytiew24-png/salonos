-- SalonOS v13.4.5.1 · CUMULATIVE RUNTIME CONTRACT HOTFIX + SERVICE BOARD
-- Additive/idempotent. Safe to run again. Does NOT delete business data.
-- Purpose: prevent PHP/Database version drift from turning a whole module into a raw PGRST202/PGRST204 error.

begin;
set local statement_timeout='0';

create table if not exists public.salonos_system_meta (
  meta_key text primary key,
  meta_value text not null,
  updated_at timestamptz not null default now()
);

-- Cumulative compatibility contract from v13.4.2 / v13.4.3.
alter table public.employee_stores add column if not exists updated_at timestamptz not null default now();
alter table public.employees add column if not exists availability_status text not null default 'available';
alter table public.employees add column if not exists is_on_duty boolean not null default true;
alter table public.employees add column if not exists updated_at timestamptz not null default now();
alter table public.visit_service_items add column if not exists service_category_snapshot text;
alter table public.visits add column if not exists started_at timestamptz;
alter table public.visits add column if not exists service_completed_at timestamptz;
alter table public.visits add column if not exists checked_out_at timestamptz;
alter table public.visits add column if not exists updated_at timestamptz not null default now();

update public.employees set availability_status='available'
where availability_status is null or availability_status not in ('available','break','off_duty','in_service','busy','disabled','inactive');

do $$ begin
  if not exists (select 1 from pg_constraint where conrelid='public.employees'::regclass and conname='employees_availability_status_check') then
    alter table public.employees add constraint employees_availability_status_check
      check (availability_status in ('available','break','off_duty','in_service','busy','disabled','inactive'));
  end if;
end $$;

update public.visit_service_items si set service_category_snapshot=s.category
from public.services s
where si.service_category_snapshot is null and si.service_id=s.id and si.organization_id=s.organization_id
  and (si.store_id is null or si.store_id=s.store_id);

-- v13.4.4 referenced this table but older Supabase schemas never created it.
-- Define it here before any Service Board function can reference it.
create table if not exists public.visit_product_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  store_id uuid not null,
  visit_id uuid not null,
  product_id uuid,
  bundle_id uuid,
  item_type text not null default 'product',
  product_name_snapshot text not null default '',
  sku_snapshot text,
  unit_price numeric(12,2) not null default 0,
  cost_price_snapshot numeric(12,2) not null default 0,
  quantity numeric(12,3) not null default 1,
  salesperson_employee_id uuid,
  commission_rate_snapshot numeric(8,3) not null default 0,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.visit_product_items add column if not exists bundle_id uuid;
alter table public.visit_product_items add column if not exists item_type text not null default 'product';
alter table public.visit_product_items add column if not exists product_name_snapshot text not null default '';
alter table public.visit_product_items add column if not exists sku_snapshot text;
alter table public.visit_product_items add column if not exists unit_price numeric(12,2) not null default 0;
alter table public.visit_product_items add column if not exists cost_price_snapshot numeric(12,2) not null default 0;
alter table public.visit_product_items add column if not exists quantity numeric(12,3) not null default 1;
alter table public.visit_product_items add column if not exists salesperson_employee_id uuid;
alter table public.visit_product_items add column if not exists commission_rate_snapshot numeric(8,3) not null default 0;
alter table public.visit_product_items add column if not exists status text not null default 'active';
alter table public.visit_product_items add column if not exists created_at timestamptz not null default now();
alter table public.visit_product_items add column if not exists updated_at timestamptz not null default now();
create index if not exists visit_product_items_visit_idx on public.visit_product_items(organization_id,store_id,visit_id);
create index if not exists visit_product_items_product_idx on public.visit_product_items(organization_id,store_id,product_id);

-- line_total compatibility:
-- Some older SalonOS schemas define line_total as GENERATED ALWAYS, while newer compatibility
-- builds may have it as a normal numeric column. Never UPDATE or assign to a generated column.
alter table public.visit_product_items add column if not exists line_total numeric(14,2);

create or replace function public.v135_visit_product_line_total_sync()
returns trigger language plpgsql set search_path=public as $$
begin
  new.line_total:=round((coalesce(new.unit_price,0)*coalesce(new.quantity,0))::numeric,2);
  new.updated_at:=now();
  return new;
end; $$;

do $$
declare v_generated text;
begin
  select a.attgenerated into v_generated
  from pg_attribute a
  where a.attrelid='public.visit_product_items'::regclass
    and a.attname='line_total'
    and a.attnum>0
    and not a.attisdropped;

  drop trigger if exists trg_v135_visit_product_line_total_sync on public.visit_product_items;

  if coalesce(v_generated,'')='' then
    update public.visit_product_items
      set line_total=round((coalesce(unit_price,0)*coalesce(quantity,0))::numeric,2)
      where line_total is null;
    execute 'create trigger trg_v135_visit_product_line_total_sync before insert or update of unit_price,quantity on public.visit_product_items for each row execute function public.v135_visit_product_line_total_sync()';
  end if;
end $$;

-- Core module contract fields: additive only; old pages keep working if they do not use them yet.
alter table public.products add column if not exists stock_unit text not null default 'pcs';
alter table public.products add column if not exists tunaipro_id text;
do $$ begin
  if to_regclass('public.v13_training_courses') is not null then
    execute 'alter table public.v13_training_courses add column if not exists category text';
    execute 'alter table public.v13_training_courses add column if not exists target_roles jsonb not null default ''[]''::jsonb';
    execute 'alter table public.v13_training_courses add column if not exists content_url text';
    execute 'alter table public.v13_training_courses add column if not exists estimated_minutes integer not null default 0';
    execute 'alter table public.v13_training_courses add column if not exists version_label text';
    execute 'alter table public.v13_training_courses add column if not exists required boolean not null default false';
    execute 'alter table public.v13_training_courses add column if not exists publication_status text not null default ''published''';
  end if;
  if to_regclass('public.v13_kpi_assignments') is not null then
    execute 'alter table public.v13_kpi_assignments add column if not exists target_value numeric';
    execute 'alter table public.v13_kpi_assignments add column if not exists bonus_amount numeric';
    execute 'alter table public.v13_kpi_assignments add column if not exists status text not null default ''active''';
    execute 'alter table public.v13_kpi_assignments add column if not exists achieved_at timestamptz';
    execute 'alter table public.v13_kpi_assignments add column if not exists reviewed_at timestamptz';
    execute 'alter table public.v13_kpi_assignments add column if not exists paid_at timestamptz';
    execute 'alter table public.v13_kpi_assignments add column if not exists locked_at timestamptz';
  end if;
end $$;

-- Shared internal board snapshot. Not directly executable by clients.
create or replace function public.v1344_board_snapshot_internal(
  p_organization_id uuid,
  p_store_id uuid,
  p_employee_id uuid,
  p_can_see_all boolean,
  p_board_date date
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result jsonb;
begin
  select jsonb_build_object(
    'board_date', p_board_date,
    'can_see_all', p_can_see_all,
    'employees', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',e.id,
        'employee_code',e.employee_code,
        'name',e.name,
        'position',e.position,
        'availability_status',coalesce(e.availability_status,'available'),
        'is_on_duty',coalesce(e.is_on_duty,true),
        'employment_status',e.employment_status
      ) order by e.name)
      from public.employees e
      join public.employee_stores es
        on es.employee_id=e.id
       and es.organization_id=e.organization_id
       and es.store_id=p_store_id
       and es.status='active'
      where e.organization_id=p_organization_id
        and e.employment_status='active'
        and (p_can_see_all or e.id=p_employee_id)
    ), '[]'::jsonb),
    'visits', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',v.id,
        'visit_number',v.visit_number,
        'visit_type',v.visit_type,
        'status',v.status,
        'scheduled_at',v.scheduled_at,
        'arrived_at',v.arrived_at,
        'started_at',v.started_at,
        'service_completed_at',v.service_completed_at,
        'checked_out_at',v.checked_out_at,
        'created_at',v.created_at,
        'sort_at',coalesce(v.scheduled_at,v.created_at),
        'customer_name',coalesce((
          select r.name_snapshot from public.visit_recipients r
          where r.visit_id=v.id and r.organization_id=p_organization_id
          order by case when r.recipient_type='primary' then 0 else 1 end, r.id
          limit 1
        ),'顾客'),
        'customer_phone',coalesce((
          select r.phone_snapshot from public.visit_recipients r
          where r.visit_id=v.id and r.organization_id=p_organization_id
          order by case when r.recipient_type='primary' then 0 else 1 end, r.id
          limit 1
        ),''),
        'member_number',(
          select m.member_number
          from public.visit_recipients r
          join public.memberships m on m.customer_id=r.customer_id and m.organization_id=p_organization_id and m.status='active'
          where r.visit_id=v.id and r.organization_id=p_organization_id and r.customer_id is not null
          order by case when r.recipient_type='primary' then 0 else 1 end, m.created_at desc
          limit 1
        ),
        'services',coalesce((
          select string_agg(distinct si.service_name_snapshot,'、')
          from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),'尚未加入项目'),
        'service_count',coalesce((
          select count(*) from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),0),
        'estimated_minutes',greatest(30,coalesce((
          select sum(greatest(coalesce(si.estimated_minutes_snapshot,30),1))
          from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),30)),
        'workers',coalesce((
          select jsonb_agg(jsonb_build_object(
            'employee_id',x.employee_id,
            'employee_name',x.employee_name,
            'worker_role',x.worker_role,
            'contribution_percent',x.contribution_percent
          ) order by x.employee_name,x.worker_role)
          from (
            select distinct w.employee_id,e.name employee_name,w.worker_role,w.contribution_percent
            from public.visit_service_items si
            join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
            join public.employees e on e.id=w.employee_id
            where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
          ) x
        ),'[]'::jsonb),
        'employees',coalesce((
          select string_agg(distinct e.name,'、')
          from public.visit_service_items si
          join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
          join public.employees e on e.id=w.employee_id
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),'待分配'),
        'service_total',coalesce((
          select sum(coalesce(si.line_total,0)) from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),0),
        'product_total',coalesce((
          select sum(coalesce(pi.line_total,0)) from public.visit_product_items pi
          where pi.visit_id=v.id and pi.organization_id=p_organization_id and pi.store_id=p_store_id and pi.status='active'
        ),0),
        'total_amount',coalesce((
          select p.grand_total from public.payments p
          where p.visit_id=v.id and p.organization_id=p_organization_id and p.store_id=p_store_id
          order by p.paid_at desc nulls last,p.id desc limit 1
        ),
          coalesce((select sum(coalesce(si.line_total,0)) from public.visit_service_items si where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'),0)
          + coalesce((select sum(coalesce(pi.line_total,0)) from public.visit_product_items pi where pi.visit_id=v.id and pi.organization_id=p_organization_id and pi.store_id=p_store_id and pi.status='active'),0)
        ),
        'payment_status',coalesce((
          select p.status from public.payments p
          where p.visit_id=v.id and p.organization_id=p_organization_id and p.store_id=p_store_id
          order by p.paid_at desc nulls last,p.id desc limit 1
        ),'unpaid')
      ) order by coalesce(v.scheduled_at,v.created_at),v.id)
      from public.visits v
      where v.organization_id=p_organization_id
        and v.store_id=p_store_id
        and ((coalesce(v.scheduled_at,v.created_at) at time zone 'Asia/Kuala_Lumpur')::date=p_board_date)
        and (
          p_can_see_all
          or exists(
            select 1
            from public.visit_service_items si
            join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
            where si.visit_id=v.id and si.organization_id=p_organization_id and w.employee_id=p_employee_id
          )
        )
    ), '[]'::jsonb)
  ) into v_result;
  return v_result;
end;
$$;
revoke all on function public.v1344_board_snapshot_internal(uuid,uuid,uuid,boolean,date) from public;

create or replace function public.v1344_owner_service_board(p_store_id uuid,p_board_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_org uuid;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id and s.status='active';
  if v_org is null or not public.can_access_store(p_store_id) then raise exception '门店权限无效。'; end if;
  return public.v1344_board_snapshot_internal(v_org,p_store_id,null,true,coalesce(p_board_date,(now() at time zone 'Asia/Kuala_Lumpur')::date));
end;
$$;
revoke all on function public.v1344_owner_service_board(uuid,date) from public;
grant execute on function public.v1344_owner_service_board(uuid,date) to authenticated;

create or replace function public.v1344_employee_service_board(p_session_token text,p_board_date date)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_all boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_all:=v_role in ('manager','receptionist');
  return public.v1344_board_snapshot_internal(v_org,v_store,v_e,v_all,coalesce(p_board_date,(now() at time zone 'Asia/Kuala_Lumpur')::date));
end;
$$;
revoke all on function public.v1344_employee_service_board(text,date) from public;
grant execute on function public.v1344_employee_service_board(text,date) to anon,authenticated;

create or replace function public.v1344_employee_visit_detail(p_session_token text,p_visit_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_all boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_all:=v_role in ('manager','receptionist');

  if not exists(
    select 1 from public.visits v
    where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store
      and (v_all or exists(
        select 1 from public.visit_service_items si
        join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
        where si.visit_id=v.id and w.employee_id=v_e
      ))
  ) then raise exception '你没有权限查看这笔订单。'; end if;

  return jsonb_build_object(
    'visit',(select to_jsonb(v) from public.visits v where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store),
    'recipients',coalesce((select jsonb_agg(to_jsonb(r) order by case when r.recipient_type='primary' then 0 else 1 end,r.id) from public.visit_recipients r where r.organization_id=v_org and r.visit_id=p_visit_id),'[]'::jsonb),
    'items',coalesce((select jsonb_agg(jsonb_build_object(
      'id',si.id,'recipient_id',si.recipient_id,'service_id',si.service_id,
      'service_name_snapshot',si.service_name_snapshot,'service_category_snapshot',si.service_category_snapshot,
      'unit_price',si.unit_price,'quantity',si.quantity,'line_total',si.line_total,
      'estimated_minutes_snapshot',si.estimated_minutes_snapshot,'status',si.status,
      'assigned_to_me',exists(select 1 from public.visit_service_workers wm where wm.service_item_id=si.id and wm.employee_id=v_e and wm.status='active'),
      'signed_by_me',exists(select 1 from public.visit_service_signoffs sg where sg.service_item_id=si.id and sg.employee_id=v_e),
      'workers',coalesce((select jsonb_agg(jsonb_build_object('employee_id',w.employee_id,'employee_name',e.name,'worker_role',w.worker_role,'contribution_percent',w.contribution_percent) order by e.name) from public.visit_service_workers w join public.employees e on e.id=w.employee_id where w.service_item_id=si.id and w.status='active'),'[]'::jsonb)
    ) order by si.id) from public.visit_service_items si where si.organization_id=v_org and si.visit_id=p_visit_id and si.status<>'cancelled'),'[]'::jsonb),
    'product_items',coalesce((select jsonb_agg(to_jsonb(pi) order by pi.id) from public.visit_product_items pi where pi.organization_id=v_org and pi.store_id=v_store and pi.visit_id=p_visit_id and pi.status='active'),'[]'::jsonb),
    'payments',coalesce((select jsonb_agg(to_jsonb(p) order by p.paid_at desc nulls last,p.id desc) from public.payments p where p.organization_id=v_org and p.store_id=v_store and p.visit_id=p_visit_id),'[]'::jsonb)
  );
end;
$$;
revoke all on function public.v1344_employee_visit_detail(text,uuid) from public;
grant execute on function public.v1344_employee_visit_detail(text,uuid) to anon,authenticated;

create or replace function public.v1344_employee_set_availability(p_session_token text,p_status text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_status text:=lower(coalesce(p_status,''));
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  if v_status not in ('available','break') then raise exception '员工状态无效。'; end if;
  update public.employees set availability_status=v_status,updated_at=now() where id=v_e and organization_id=v_org and employment_status='active';
  return jsonb_build_object('ok',true,'availability_status',v_status);
end;
$$;
revoke all on function public.v1344_employee_set_availability(text,text) from public;
grant execute on function public.v1344_employee_set_availability(text,text) to anon,authenticated;

create or replace function public.v1344_employee_set_visit_status(p_session_token text,p_visit_id uuid,p_status text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_status text:=lower(coalesce(p_status,'')); v_all boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_all:=v_role in ('manager','receptionist');

  if v_all then
    if v_status not in ('arrived','waiting','in_service','paused','ready_for_checkout','cancelled','no_show') then raise exception '不允许的订单状态。'; end if;
  else
    if v_status not in ('waiting','in_service','paused','ready_for_checkout') then raise exception '这个员工角色不能执行该状态操作。'; end if;
    if not exists(
      select 1 from public.visit_service_items si
      join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
      where si.visit_id=p_visit_id and si.organization_id=v_org and w.employee_id=v_e
    ) then raise exception '你不是这笔订单的负责员工。'; end if;
  end if;

  update public.visits set
    status=v_status,
    arrived_at=case when v_status='arrived' then coalesce(arrived_at,now()) else arrived_at end,
    started_at=case when v_status='in_service' then coalesce(started_at,now()) else started_at end,
    service_completed_at=case when v_status='ready_for_checkout' then coalesce(service_completed_at,now()) else service_completed_at end,
    updated_at=now()
  where id=p_visit_id and organization_id=v_org and store_id=v_store;
  if not found then raise exception '找不到订单。'; end if;
  return jsonb_build_object('ok',true,'status',v_status);
end;
$$;
revoke all on function public.v1344_employee_set_visit_status(text,uuid,text) from public;
grant execute on function public.v1344_employee_set_visit_status(text,uuid,text) to anon,authenticated;



-- RLS for the add-on product table. Employee sessions still go through SECURITY DEFINER RPCs;
-- authenticated Owner/Manager REST access is tenant-scoped.
alter table public.visit_product_items enable row level security;
drop policy if exists v135_visit_product_items_read on public.visit_product_items;
create policy v135_visit_product_items_read on public.visit_product_items for select to authenticated
  using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v135_visit_product_items_manage on public.visit_product_items;
create policy v135_visit_product_items_manage on public.visit_product_items for all to authenticated
  using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
  with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('compat_patch_version','13.4.5.1'),
 ('service_board_version','13.4.5.1'),
 ('runtime_contract_version','13.4.5.1')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.4.5.1 RUNTIME CONTRACT READY' as result,
  to_regprocedure('public.v1344_owner_service_board(uuid,date)') is not null as owner_service_board_rpc_ok,
  to_regprocedure('public.v1344_employee_service_board(text,date)') is not null as employee_service_board_rpc_ok,
  to_regclass('public.visit_product_items') is not null as visit_product_items_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='visit_service_items' and column_name='service_category_snapshot') as service_category_snapshot_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='employee_stores' and column_name='updated_at') as employee_store_timestamp_ok;
