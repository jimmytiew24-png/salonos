-- SalonOS v13.4.7 · CHECKOUT PAYMENT-LINE CONTRACT FIX
-- Additive / idempotent. Does NOT delete business data.
-- Fixes legacy checkout_visit builds that read payment JSON keys such as "method"
-- while the current PHP sends "payment_method". The adapter now sends BOTH names
-- (plus other safe aliases) so payment_items.payment_method can never become NULL
-- merely because two SalonOS schema generations used different JSON field names.

begin;
set local statement_timeout='0';

create or replace function public.v1347_normalize_payment_lines(
  p_payments jsonb,
  p_membership_id uuid default null
)
returns jsonb
language plpgsql
immutable
set search_path=public
as $$
declare
  v_line jsonb;
  v_out jsonb := '[]'::jsonb;
  v_method text;
  v_amount numeric;
  v_reference text;
  v_notes text;
begin
  if p_payments is null then p_payments := '[]'::jsonb; end if;
  if jsonb_typeof(p_payments) <> 'array' then
    raise exception '付款资料格式无效：payments 必须是 JSON array。';
  end if;

  for v_line in select value from jsonb_array_elements(p_payments)
  loop
    if jsonb_typeof(v_line) <> 'object' then
      raise exception '付款资料格式无效：每个 payment line 必须是 JSON object。';
    end if;

    v_method := lower(trim(coalesce(
      nullif(v_line->>'payment_method',''),
      nullif(v_line->>'method',''),
      nullif(v_line->>'payment_type',''),
      nullif(v_line->>'type',''),
      nullif(v_line->>'payment_channel',''),
      nullif(v_line->>'payment_method_code',''),
      nullif(v_line->>'method_code',''),
      nullif(v_line->>'mode',''),
      nullif(v_line->>'channel',''),
      nullif(v_line->>'paymentMethod',''),
      'cash'
    )));

    v_method := case v_method
      when 'e-wallet' then 'ewallet'
      when 'e_wallet' then 'ewallet'
      when 'bank transfer' then 'bank_transfer'
      when 'bank-transfer' then 'bank_transfer'
      when 'banktransfer' then 'bank_transfer'
      when 'wallet' then 'member_wallet'
      when 'member wallet' then 'member_wallet'
      else v_method
    end;

    if v_method not in ('cash','card','ewallet','bank_transfer','member_wallet','other') then
      raise exception '不支持的付款方式：%',v_method;
    end if;

    v_amount := coalesce(
      nullif(v_line->>'amount','')::numeric,
      nullif(v_line->>'paid_amount','')::numeric,
      nullif(v_line->>'payment_amount','')::numeric,
      nullif(v_line->>'value','')::numeric,
      0
    );
    if v_amount <= 0 then raise exception '每一笔付款金额必须大于 0。'; end if;

    v_reference := nullif(trim(coalesce(
      v_line->>'reference_number',
      v_line->>'reference',
      v_line->>'ref',
      v_line->>'transaction_reference',
      ''
    )), '');
    v_notes := nullif(trim(coalesce(v_line->>'notes',v_line->>'note','')), '');

    -- Keep the caller payload, then add a compatibility envelope containing every
    -- payment-key spelling used by historical SalonOS checkout functions.
    v_line := v_line || jsonb_build_object(
      'payment_method',v_method,
      'method',v_method,
      'payment_type',v_method,
      'type',v_method,
      'payment_channel',v_method,
      'payment_method_code',v_method,
      'method_code',v_method,
      'mode',v_method,
      'channel',v_method,
      'paymentMethod',v_method,
      'amount',round(v_amount,2),
      'paid_amount',round(v_amount,2),
      'payment_amount',round(v_amount,2),
      'paid',round(v_amount,2),
      'total',round(v_amount,2),
      'line_total',round(v_amount,2),
      'value',round(v_amount,2),
      'reference_number',v_reference,
      'reference',v_reference,
      'ref',v_reference,
      'transaction_reference',v_reference,
      'notes',v_notes,
      'note',v_notes,
      'membership_id',p_membership_id,
      'loyalty_membership_id',p_membership_id
    );

    v_out := v_out || jsonb_build_array(jsonb_strip_nulls(v_line));
  end loop;

  if jsonb_array_length(v_out)=0 then raise exception '请至少提供一笔付款。'; end if;
  return v_out;
end;
$$;

revoke all on function public.v1347_normalize_payment_lines(jsonb,uuid) from public;
grant execute on function public.v1347_normalize_payment_lines(jsonb,uuid) to authenticated;

create or replace function public.v1347_checkout_visit(
  p_visit_id uuid,
  p_payments jsonb,
  p_discount_total numeric default 0,
  p_tax_total numeric default 0,
  p_membership_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_payments jsonb;
  v_out jsonb;
begin
  if p_visit_id is null then raise exception '订单 ID 不能为空。'; end if;

  v_payments := public.v1347_normalize_payment_lines(p_payments,p_membership_id);

  if to_regprocedure('public.v1346_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is null then
    raise exception 'SalonOS v13.4.6 基础结账 Adapter 尚未安装。请运行 v13.4.7 累计补丁。';
  end if;

  v_out := public.v1346_checkout_visit(
    p_visit_id,
    v_payments,
    greatest(coalesce(p_discount_total,0),0),
    greatest(coalesce(p_tax_total,0),0),
    p_membership_id
  );

  return coalesce(v_out,jsonb_build_object('ok',true));
end;
$$;

revoke all on function public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid) from public;
grant execute on function public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid) to authenticated;

create or replace function public.v1347_runtime_contract_status()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_base jsonb := '{}'::jsonb;
  v_sample jsonb;
  v_line jsonb;
  v_alias_ok boolean := false;
begin
  if to_regprocedure('public.v1346_runtime_contract_status()') is not null then
    begin
      v_base := public.v1346_runtime_contract_status();
    exception when others then
      v_base := jsonb_build_object('ok',false,'base_contract_error',sqlerrm);
    end;
  end if;

  v_sample := public.v1347_normalize_payment_lines('[{"payment_method":"cash","amount":1}]'::jsonb,null);
  v_line := v_sample->0;
  v_alias_ok := coalesce(v_line->>'payment_method','')='cash'
    and coalesce(v_line->>'method','')='cash'
    and coalesce(v_line->>'payment_type','')='cash'
    and coalesce(v_line->>'type','')='cash'
    and coalesce((v_line->>'amount')::numeric,0)=1;

  return jsonb_build_object(
    'version','13.4.7',
    'ok',coalesce((v_base->>'ok')::boolean,false)
      and to_regprocedure('public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null
      and v_alias_ok,
    'base_contract',v_base,
    'required_rpc_count',coalesce((v_base->>'required_rpc_count')::integer,0),
    'present_rpc_count',coalesce((v_base->>'present_rpc_count')::integer,0),
    'missing_rpc_names',coalesce(v_base->'missing_rpc_names','[]'::jsonb),
    'checkout_signature_ok',coalesce((v_base->>'checkout_signature_ok')::boolean,false),
    'stock_signature_ok',coalesce((v_base->>'stock_signature_ok')::boolean,false),
    'checkout_adapter_ok',to_regprocedure('public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null,
    'payment_alias_contract_ok',v_alias_ok,
    'payment_items_table_ok',to_regclass('public.payment_items') is not null,
    'payment_method_column_ok',exists(
      select 1 from information_schema.columns
      where table_schema='public' and table_name='payment_items' and column_name='payment_method'
    ),
    'schema_cache_marker','v13.4.7'
  );
end;
$$;

revoke all on function public.v1347_runtime_contract_status() from public;
grant execute on function public.v1347_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('compat_patch_version','13.4.7'),
 ('service_board_version','13.4.7'),
 ('runtime_contract_version','13.4.7'),
 ('rpc_contract_version','13.4.7'),
 ('checkout_payment_contract_version','13.4.7')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.4.7 CHECKOUT PAYMENT CONTRACT READY' as result,
  to_regprocedure('public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null as checkout_adapter_ok,
  to_regprocedure('public.v1347_normalize_payment_lines(jsonb,uuid)') is not null as payment_normalizer_ok,
  (public.v1347_runtime_contract_status()->>'payment_alias_contract_ok')::boolean as payment_alias_contract_ok,
  (public.v1347_runtime_contract_status()->>'payment_method_column_ok')::boolean as payment_method_column_ok;
