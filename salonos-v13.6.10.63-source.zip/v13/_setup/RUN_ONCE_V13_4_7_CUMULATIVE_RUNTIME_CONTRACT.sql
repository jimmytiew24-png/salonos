-- SalonOS v13.4.5.1 · CUMULATIVE RUNTIME CONTRACT HOTFIX + SERVICE BOARD
-- Additive/idempotent. Safe to run again. Does NOT delete business data.
-- Purpose: prevent PHP/Database version drift from turning a whole module into a raw PGRST202/PGRST204 error.

begin;
set local statement_timeout='0';

create table if not exists public.salonos_system_meta (
  meta_key text primary key,
  meta_value text not null,
  updated_at timestamptz not null default now()
);

-- Cumulative compatibility contract from v13.4.2 / v13.4.3.
alter table public.employee_stores add column if not exists updated_at timestamptz not null default now();
alter table public.employees add column if not exists availability_status text not null default 'available';
alter table public.employees add column if not exists is_on_duty boolean not null default true;
alter table public.employees add column if not exists updated_at timestamptz not null default now();
alter table public.visit_service_items add column if not exists service_category_snapshot text;
alter table public.visits add column if not exists started_at timestamptz;
alter table public.visits add column if not exists service_completed_at timestamptz;
alter table public.visits add column if not exists checked_out_at timestamptz;
alter table public.visits add column if not exists updated_at timestamptz not null default now();

update public.employees set availability_status='available'
where availability_status is null or availability_status not in ('available','break','off_duty','in_service','busy','disabled','inactive');

do $$ begin
  if not exists (select 1 from pg_constraint where conrelid='public.employees'::regclass and conname='employees_availability_status_check') then
    alter table public.employees add constraint employees_availability_status_check
      check (availability_status in ('available','break','off_duty','in_service','busy','disabled','inactive'));
  end if;
end $$;

update public.visit_service_items si set service_category_snapshot=s.category
from public.services s
where si.service_category_snapshot is null and si.service_id=s.id and si.organization_id=s.organization_id
  and (si.store_id is null or si.store_id=s.store_id);

-- v13.4.4 referenced this table but older Supabase schemas never created it.
-- Define it here before any Service Board function can reference it.
create table if not exists public.visit_product_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  store_id uuid not null,
  visit_id uuid not null,
  product_id uuid,
  bundle_id uuid,
  item_type text not null default 'product',
  product_name_snapshot text not null default '',
  sku_snapshot text,
  unit_price numeric(12,2) not null default 0,
  cost_price_snapshot numeric(12,2) not null default 0,
  quantity numeric(12,3) not null default 1,
  salesperson_employee_id uuid,
  commission_rate_snapshot numeric(8,3) not null default 0,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.visit_product_items add column if not exists bundle_id uuid;
alter table public.visit_product_items add column if not exists item_type text not null default 'product';
alter table public.visit_product_items add column if not exists product_name_snapshot text not null default '';
alter table public.visit_product_items add column if not exists sku_snapshot text;
alter table public.visit_product_items add column if not exists unit_price numeric(12,2) not null default 0;
alter table public.visit_product_items add column if not exists cost_price_snapshot numeric(12,2) not null default 0;
alter table public.visit_product_items add column if not exists quantity numeric(12,3) not null default 1;
alter table public.visit_product_items add column if not exists salesperson_employee_id uuid;
alter table public.visit_product_items add column if not exists commission_rate_snapshot numeric(8,3) not null default 0;
alter table public.visit_product_items add column if not exists status text not null default 'active';
alter table public.visit_product_items add column if not exists created_at timestamptz not null default now();
alter table public.visit_product_items add column if not exists updated_at timestamptz not null default now();
create index if not exists visit_product_items_visit_idx on public.visit_product_items(organization_id,store_id,visit_id);
create index if not exists visit_product_items_product_idx on public.visit_product_items(organization_id,store_id,product_id);

-- line_total compatibility:
-- Some older SalonOS schemas define line_total as GENERATED ALWAYS, while newer compatibility
-- builds may have it as a normal numeric column. Never UPDATE or assign to a generated column.
alter table public.visit_product_items add column if not exists line_total numeric(14,2);

create or replace function public.v135_visit_product_line_total_sync()
returns trigger language plpgsql set search_path=public as $$
begin
  new.line_total:=round((coalesce(new.unit_price,0)*coalesce(new.quantity,0))::numeric,2);
  new.updated_at:=now();
  return new;
end; $$;

do $$
declare v_generated text;
begin
  select a.attgenerated into v_generated
  from pg_attribute a
  where a.attrelid='public.visit_product_items'::regclass
    and a.attname='line_total'
    and a.attnum>0
    and not a.attisdropped;

  drop trigger if exists trg_v135_visit_product_line_total_sync on public.visit_product_items;

  if coalesce(v_generated,'')='' then
    update public.visit_product_items
      set line_total=round((coalesce(unit_price,0)*coalesce(quantity,0))::numeric,2)
      where line_total is null;
    execute 'create trigger trg_v135_visit_product_line_total_sync before insert or update of unit_price,quantity on public.visit_product_items for each row execute function public.v135_visit_product_line_total_sync()';
  end if;
end $$;

-- Core module contract fields: additive only; old pages keep working if they do not use them yet.
alter table public.products add column if not exists stock_unit text not null default 'pcs';
alter table public.products add column if not exists tunaipro_id text;
do $$ begin
  if to_regclass('public.v13_training_courses') is not null then
    execute 'alter table public.v13_training_courses add column if not exists category text';
    execute 'alter table public.v13_training_courses add column if not exists target_roles jsonb not null default ''[]''::jsonb';
    execute 'alter table public.v13_training_courses add column if not exists content_url text';
    execute 'alter table public.v13_training_courses add column if not exists estimated_minutes integer not null default 0';
    execute 'alter table public.v13_training_courses add column if not exists version_label text';
    execute 'alter table public.v13_training_courses add column if not exists required boolean not null default false';
    execute 'alter table public.v13_training_courses add column if not exists publication_status text not null default ''published''';
  end if;
  if to_regclass('public.v13_kpi_assignments') is not null then
    execute 'alter table public.v13_kpi_assignments add column if not exists target_value numeric';
    execute 'alter table public.v13_kpi_assignments add column if not exists bonus_amount numeric';
    execute 'alter table public.v13_kpi_assignments add column if not exists status text not null default ''active''';
    execute 'alter table public.v13_kpi_assignments add column if not exists achieved_at timestamptz';
    execute 'alter table public.v13_kpi_assignments add column if not exists reviewed_at timestamptz';
    execute 'alter table public.v13_kpi_assignments add column if not exists paid_at timestamptz';
    execute 'alter table public.v13_kpi_assignments add column if not exists locked_at timestamptz';
  end if;
end $$;

-- Shared internal board snapshot. Not directly executable by clients.
create or replace function public.v1344_board_snapshot_internal(
  p_organization_id uuid,
  p_store_id uuid,
  p_employee_id uuid,
  p_can_see_all boolean,
  p_board_date date
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result jsonb;
begin
  select jsonb_build_object(
    'board_date', p_board_date,
    'can_see_all', p_can_see_all,
    'employees', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',e.id,
        'employee_code',e.employee_code,
        'name',e.name,
        'position',e.position,
        'availability_status',coalesce(e.availability_status,'available'),
        'is_on_duty',coalesce(e.is_on_duty,true),
        'employment_status',e.employment_status
      ) order by e.name)
      from public.employees e
      join public.employee_stores es
        on es.employee_id=e.id
       and es.organization_id=e.organization_id
       and es.store_id=p_store_id
       and es.status='active'
      where e.organization_id=p_organization_id
        and e.employment_status='active'
        and (p_can_see_all or e.id=p_employee_id)
    ), '[]'::jsonb),
    'visits', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',v.id,
        'visit_number',v.visit_number,
        'visit_type',v.visit_type,
        'status',v.status,
        'scheduled_at',v.scheduled_at,
        'arrived_at',v.arrived_at,
        'started_at',v.started_at,
        'service_completed_at',v.service_completed_at,
        'checked_out_at',v.checked_out_at,
        'created_at',v.created_at,
        'sort_at',coalesce(v.scheduled_at,v.created_at),
        'customer_name',coalesce((
          select r.name_snapshot from public.visit_recipients r
          where r.visit_id=v.id and r.organization_id=p_organization_id
          order by case when r.recipient_type='primary' then 0 else 1 end, r.id
          limit 1
        ),'顾客'),
        'customer_phone',coalesce((
          select r.phone_snapshot from public.visit_recipients r
          where r.visit_id=v.id and r.organization_id=p_organization_id
          order by case when r.recipient_type='primary' then 0 else 1 end, r.id
          limit 1
        ),''),
        'member_number',(
          select m.member_number
          from public.visit_recipients r
          join public.memberships m on m.customer_id=r.customer_id and m.organization_id=p_organization_id and m.status='active'
          where r.visit_id=v.id and r.organization_id=p_organization_id and r.customer_id is not null
          order by case when r.recipient_type='primary' then 0 else 1 end, m.created_at desc
          limit 1
        ),
        'services',coalesce((
          select string_agg(distinct si.service_name_snapshot,'、')
          from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),'尚未加入项目'),
        'service_count',coalesce((
          select count(*) from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),0),
        'estimated_minutes',greatest(30,coalesce((
          select sum(greatest(coalesce(si.estimated_minutes_snapshot,30),1))
          from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),30)),
        'workers',coalesce((
          select jsonb_agg(jsonb_build_object(
            'employee_id',x.employee_id,
            'employee_name',x.employee_name,
            'worker_role',x.worker_role,
            'contribution_percent',x.contribution_percent
          ) order by x.employee_name,x.worker_role)
          from (
            select distinct w.employee_id,e.name employee_name,w.worker_role,w.contribution_percent
            from public.visit_service_items si
            join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
            join public.employees e on e.id=w.employee_id
            where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
          ) x
        ),'[]'::jsonb),
        'employees',coalesce((
          select string_agg(distinct e.name,'、')
          from public.visit_service_items si
          join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
          join public.employees e on e.id=w.employee_id
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),'待分配'),
        'service_total',coalesce((
          select sum(coalesce(si.line_total,0)) from public.visit_service_items si
          where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'
        ),0),
        'product_total',coalesce((
          select sum(coalesce(pi.line_total,0)) from public.visit_product_items pi
          where pi.visit_id=v.id and pi.organization_id=p_organization_id and pi.store_id=p_store_id and pi.status='active'
        ),0),
        'total_amount',coalesce((
          select p.grand_total from public.payments p
          where p.visit_id=v.id and p.organization_id=p_organization_id and p.store_id=p_store_id
          order by p.paid_at desc nulls last,p.id desc limit 1
        ),
          coalesce((select sum(coalesce(si.line_total,0)) from public.visit_service_items si where si.visit_id=v.id and si.organization_id=p_organization_id and si.status<>'cancelled'),0)
          + coalesce((select sum(coalesce(pi.line_total,0)) from public.visit_product_items pi where pi.visit_id=v.id and pi.organization_id=p_organization_id and pi.store_id=p_store_id and pi.status='active'),0)
        ),
        'payment_status',coalesce((
          select p.status from public.payments p
          where p.visit_id=v.id and p.organization_id=p_organization_id and p.store_id=p_store_id
          order by p.paid_at desc nulls last,p.id desc limit 1
        ),'unpaid')
      ) order by coalesce(v.scheduled_at,v.created_at),v.id)
      from public.visits v
      where v.organization_id=p_organization_id
        and v.store_id=p_store_id
        and ((coalesce(v.scheduled_at,v.created_at) at time zone 'Asia/Kuala_Lumpur')::date=p_board_date)
        and (
          p_can_see_all
          or exists(
            select 1
            from public.visit_service_items si
            join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
            where si.visit_id=v.id and si.organization_id=p_organization_id and w.employee_id=p_employee_id
          )
        )
    ), '[]'::jsonb)
  ) into v_result;
  return v_result;
end;
$$;
revoke all on function public.v1344_board_snapshot_internal(uuid,uuid,uuid,boolean,date) from public;

create or replace function public.v1344_owner_service_board(p_store_id uuid,p_board_date date)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare v_org uuid;
begin
  select s.organization_id into v_org from public.stores s where s.id=p_store_id and s.status='active';
  if v_org is null or not public.can_access_store(p_store_id) then raise exception '门店权限无效。'; end if;
  return public.v1344_board_snapshot_internal(v_org,p_store_id,null,true,coalesce(p_board_date,(now() at time zone 'Asia/Kuala_Lumpur')::date));
end;
$$;
revoke all on function public.v1344_owner_service_board(uuid,date) from public;
grant execute on function public.v1344_owner_service_board(uuid,date) to authenticated;

create or replace function public.v1344_employee_service_board(p_session_token text,p_board_date date)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_all boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_all:=v_role in ('manager','receptionist');
  return public.v1344_board_snapshot_internal(v_org,v_store,v_e,v_all,coalesce(p_board_date,(now() at time zone 'Asia/Kuala_Lumpur')::date));
end;
$$;
revoke all on function public.v1344_employee_service_board(text,date) from public;
grant execute on function public.v1344_employee_service_board(text,date) to anon,authenticated;

create or replace function public.v1344_employee_visit_detail(p_session_token text,p_visit_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_all boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_all:=v_role in ('manager','receptionist');

  if not exists(
    select 1 from public.visits v
    where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store
      and (v_all or exists(
        select 1 from public.visit_service_items si
        join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
        where si.visit_id=v.id and w.employee_id=v_e
      ))
  ) then raise exception '你没有权限查看这笔订单。'; end if;

  return jsonb_build_object(
    'visit',(select to_jsonb(v) from public.visits v where v.id=p_visit_id and v.organization_id=v_org and v.store_id=v_store),
    'recipients',coalesce((select jsonb_agg(to_jsonb(r) order by case when r.recipient_type='primary' then 0 else 1 end,r.id) from public.visit_recipients r where r.organization_id=v_org and r.visit_id=p_visit_id),'[]'::jsonb),
    'items',coalesce((select jsonb_agg(jsonb_build_object(
      'id',si.id,'recipient_id',si.recipient_id,'service_id',si.service_id,
      'service_name_snapshot',si.service_name_snapshot,'service_category_snapshot',si.service_category_snapshot,
      'unit_price',si.unit_price,'quantity',si.quantity,'line_total',si.line_total,
      'estimated_minutes_snapshot',si.estimated_minutes_snapshot,'status',si.status,
      'assigned_to_me',exists(select 1 from public.visit_service_workers wm where wm.service_item_id=si.id and wm.employee_id=v_e and wm.status='active'),
      'signed_by_me',exists(select 1 from public.visit_service_signoffs sg where sg.service_item_id=si.id and sg.employee_id=v_e),
      'workers',coalesce((select jsonb_agg(jsonb_build_object('employee_id',w.employee_id,'employee_name',e.name,'worker_role',w.worker_role,'contribution_percent',w.contribution_percent) order by e.name) from public.visit_service_workers w join public.employees e on e.id=w.employee_id where w.service_item_id=si.id and w.status='active'),'[]'::jsonb)
    ) order by si.id) from public.visit_service_items si where si.organization_id=v_org and si.visit_id=p_visit_id and si.status<>'cancelled'),'[]'::jsonb),
    'product_items',coalesce((select jsonb_agg(to_jsonb(pi) order by pi.id) from public.visit_product_items pi where pi.organization_id=v_org and pi.store_id=v_store and pi.visit_id=p_visit_id and pi.status='active'),'[]'::jsonb),
    'payments',coalesce((select jsonb_agg(to_jsonb(p) order by p.paid_at desc nulls last,p.id desc) from public.payments p where p.organization_id=v_org and p.store_id=v_store and p.visit_id=p_visit_id),'[]'::jsonb)
  );
end;
$$;
revoke all on function public.v1344_employee_visit_detail(text,uuid) from public;
grant execute on function public.v1344_employee_visit_detail(text,uuid) to anon,authenticated;

create or replace function public.v1344_employee_set_availability(p_session_token text,p_status text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_status text:=lower(coalesce(p_status,''));
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  if v_status not in ('available','break') then raise exception '员工状态无效。'; end if;
  update public.employees set availability_status=v_status,updated_at=now() where id=v_e and organization_id=v_org and employment_status='active';
  return jsonb_build_object('ok',true,'availability_status',v_status);
end;
$$;
revoke all on function public.v1344_employee_set_availability(text,text) from public;
grant execute on function public.v1344_employee_set_availability(text,text) to anon,authenticated;

create or replace function public.v1344_employee_set_visit_status(p_session_token text,p_visit_id uuid,p_status text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare v_ctx jsonb; v_e uuid; v_org uuid; v_store uuid; v_role text; v_status text:=lower(coalesce(p_status,'')); v_all boolean;
begin
  v_ctx:=public.employee_session_context(p_session_token);
  v_e:=(v_ctx->>'employee_id')::uuid;
  v_org:=(v_ctx->>'organization_id')::uuid;
  v_store:=(v_ctx->>'store_id')::uuid;
  v_role:=coalesce(v_ctx->>'employee_role','staff');
  v_all:=v_role in ('manager','receptionist');

  if v_all then
    if v_status not in ('arrived','waiting','in_service','paused','ready_for_checkout','cancelled','no_show') then raise exception '不允许的订单状态。'; end if;
  else
    if v_status not in ('waiting','in_service','paused','ready_for_checkout') then raise exception '这个员工角色不能执行该状态操作。'; end if;
    if not exists(
      select 1 from public.visit_service_items si
      join public.visit_service_workers w on w.service_item_id=si.id and w.status='active'
      where si.visit_id=p_visit_id and si.organization_id=v_org and w.employee_id=v_e
    ) then raise exception '你不是这笔订单的负责员工。'; end if;
  end if;

  update public.visits set
    status=v_status,
    arrived_at=case when v_status='arrived' then coalesce(arrived_at,now()) else arrived_at end,
    started_at=case when v_status='in_service' then coalesce(started_at,now()) else started_at end,
    service_completed_at=case when v_status='ready_for_checkout' then coalesce(service_completed_at,now()) else service_completed_at end,
    updated_at=now()
  where id=p_visit_id and organization_id=v_org and store_id=v_store;
  if not found then raise exception '找不到订单。'; end if;
  return jsonb_build_object('ok',true,'status',v_status);
end;
$$;
revoke all on function public.v1344_employee_set_visit_status(text,uuid,text) from public;
grant execute on function public.v1344_employee_set_visit_status(text,uuid,text) to anon,authenticated;



-- RLS for the add-on product table. Employee sessions still go through SECURITY DEFINER RPCs;
-- authenticated Owner/Manager REST access is tenant-scoped.
alter table public.visit_product_items enable row level security;
drop policy if exists v135_visit_product_items_read on public.visit_product_items;
create policy v135_visit_product_items_read on public.visit_product_items for select to authenticated
  using (public.is_organization_member(organization_id) and public.can_access_store(store_id));
drop policy if exists v135_visit_product_items_manage on public.visit_product_items;
create policy v135_visit_product_items_manage on public.visit_product_items for all to authenticated
  using (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id))
  with check (public.has_organization_role(organization_id,array['owner','manager']) and public.can_access_store(store_id));

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('compat_patch_version','13.4.5.1'),
 ('service_board_version','13.4.5.1'),
 ('runtime_contract_version','13.4.5.1')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.4.5.1 RUNTIME CONTRACT READY' as result,
  to_regprocedure('public.v1344_owner_service_board(uuid,date)') is not null as owner_service_board_rpc_ok,
  to_regprocedure('public.v1344_employee_service_board(text,date)') is not null as employee_service_board_rpc_ok,
  to_regclass('public.visit_product_items') is not null as visit_product_items_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='visit_service_items' and column_name='service_category_snapshot') as service_category_snapshot_ok,
  exists(select 1 from information_schema.columns where table_schema='public' and table_name='employee_stores' and column_name='updated_at') as employee_store_timestamp_ok;


-- =============================================================================
-- SalonOS v13.4.6 · COMPLETE RPC CONTRACT ADAPTER
-- This block intentionally does not replace the existing checkout/inventory business
-- functions. It creates stable v13.4.6 adapters around the historical signatures so
-- PHP and Supabase cannot drift merely because argument names changed between builds.
-- =============================================================================

begin;
set local statement_timeout='0';

create or replace function public.v1346_checkout_visit(
  p_visit_id uuid,
  p_payments jsonb,
  p_discount_total numeric default 0,
  p_tax_total numeric default 0,
  p_membership_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_names text[];
  v_out jsonb;
begin
  select p.proargnames into v_names
  from pg_proc p
  join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='public' and p.proname='checkout_visit' and p.pronargs=5
  order by p.oid desc
  limit 1;

  if v_names is null then
    raise exception 'SalonOS 基础结账 RPC checkout_visit 不存在。请先安装完整 Supabase Core Schema。';
  end if;

  if v_names @> array['target_visit_id','payment_lines','discount_amount','tax_amount','loyalty_membership_id']::text[] then
    execute 'select coalesce(to_jsonb(x),''{}''::jsonb) from public.checkout_visit(discount_amount => $1, loyalty_membership_id => $2, payment_lines => $3, target_visit_id => $4, tax_amount => $5) x limit 1'
      into v_out
      using coalesce(p_discount_total,0),p_membership_id,coalesce(p_payments,'[]'::jsonb),p_visit_id,coalesce(p_tax_total,0);
  elsif v_names @> array['p_visit_id','p_payments','p_discount_total','p_tax_total','p_membership_id']::text[] then
    execute 'select coalesce(to_jsonb(x),''{}''::jsonb) from public.checkout_visit(p_visit_id => $1, p_payments => $2, p_discount_total => $3, p_tax_total => $4, p_membership_id => $5) x limit 1'
      into v_out
      using p_visit_id,coalesce(p_payments,'[]'::jsonb),coalesce(p_discount_total,0),coalesce(p_tax_total,0),p_membership_id;
  else
    raise exception 'checkout_visit 参数签名与 SalonOS v13.4.6 不兼容：%',array_to_string(v_names,', ');
  end if;

  return coalesce(v_out,jsonb_build_object('ok',true));
end;
$$;
revoke all on function public.v1346_checkout_visit(uuid,jsonb,numeric,numeric,uuid) from public;
grant execute on function public.v1346_checkout_visit(uuid,jsonb,numeric,numeric,uuid) to authenticated;

create or replace function public.v1346_add_product_stock(
  p_product_id uuid,
  p_quantity_delta numeric,
  p_unit_cost numeric default 0,
  p_notes text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_names text[];
  v_out jsonb;
begin
  select p.proargnames into v_names
  from pg_proc p
  join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='public' and p.proname='add_product_stock' and p.pronargs=4
  order by p.oid desc
  limit 1;

  if v_names is null then
    raise exception 'SalonOS 基础库存 RPC add_product_stock 不存在。请先安装完整 Supabase Core Schema。';
  end if;

  if v_names @> array['product_id','quantity_delta','unit_cost','notes']::text[] then
    execute 'select coalesce(to_jsonb(x),''{}''::jsonb) from public.add_product_stock(product_id => $1, quantity_delta => $2, unit_cost => $3, notes => $4) x limit 1'
      into v_out using p_product_id,p_quantity_delta,coalesce(p_unit_cost,0),p_notes;
  elsif v_names @> array['p_product_id','p_quantity_delta','p_unit_cost','p_notes']::text[] then
    execute 'select coalesce(to_jsonb(x),''{}''::jsonb) from public.add_product_stock(p_product_id => $1, p_quantity_delta => $2, p_unit_cost => $3, p_notes => $4) x limit 1'
      into v_out using p_product_id,p_quantity_delta,coalesce(p_unit_cost,0),p_notes;
  else
    -- Most historical stock functions kept the same positional order even when the
    -- argument names differed. Only use this fallback when exactly one 4-arg overload exists.
    if (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='add_product_stock' and p.pronargs=4)=1 then
      execute 'select coalesce(to_jsonb(x),''{}''::jsonb) from public.add_product_stock($1,$2,$3,$4) x limit 1'
        into v_out using p_product_id,p_quantity_delta,coalesce(p_unit_cost,0),p_notes;
    else
      raise exception 'add_product_stock 参数签名与 SalonOS v13.4.6 不兼容：%',array_to_string(v_names,', ');
    end if;
  end if;

  return coalesce(v_out,jsonb_build_object('ok',true));
end;
$$;
revoke all on function public.v1346_add_product_stock(uuid,numeric,numeric,text) from public;
grant execute on function public.v1346_add_product_stock(uuid,numeric,numeric,text) to authenticated;

create or replace function public.v1346_runtime_contract_status()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_required text[]:=array[
    'check_owner_trusted_device','creator_cancel_activation_code','creator_dashboard_snapshot','creator_renew_subscription',
    'creator_revoke_device','creator_set_subscription_status','employee_phone_login','employee_session_context','employee_session_logout',
    'redeem_branch_activation_code','redeem_device_activation_code','redeem_owner_activation_code_v2','validate_owner_activation_code',
    'v132_inventory_snapshot','v1331_employee_confirm_visit','v1331_employee_customer_search','v1331_employee_order_review',
    'v1344_employee_service_board','v1344_employee_set_availability','v1344_employee_set_visit_status','v1344_employee_visit_detail',
    'v1344_owner_service_board','v134_employee_create_visit','v13_employee_api','v13_employee_directory','v13_healthcheck',
    'v13_owner_dashboard','v13_save_employee','v13_toggle_employee','v1346_checkout_visit','v1346_add_product_stock'
  ];
  v_missing text[]:=array[]::text[];
  v_name text;
  v_checkout_names text[];
  v_stock_names text[];
  v_checkout_ok boolean:=false;
  v_stock_ok boolean:=false;
begin
  foreach v_name in array v_required loop
    if not exists(
      select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname=v_name
    ) then v_missing:=array_append(v_missing,v_name); end if;
  end loop;

  select p.proargnames into v_checkout_names
  from pg_proc p join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='public' and p.proname='checkout_visit' and p.pronargs=5
  order by p.oid desc limit 1;
  v_checkout_ok:=v_checkout_names is not null and (
    v_checkout_names @> array['target_visit_id','payment_lines','discount_amount','tax_amount','loyalty_membership_id']::text[]
    or v_checkout_names @> array['p_visit_id','p_payments','p_discount_total','p_tax_total','p_membership_id']::text[]
  );

  select p.proargnames into v_stock_names
  from pg_proc p join pg_namespace n on n.oid=p.pronamespace
  where n.nspname='public' and p.proname='add_product_stock' and p.pronargs=4
  order by p.oid desc limit 1;
  v_stock_ok:=v_stock_names is not null;

  return jsonb_build_object(
    'version','13.4.6',
    'ok',cardinality(v_missing)=0 and v_checkout_ok and v_stock_ok,
    'required_rpc_count',cardinality(v_required),
    'present_rpc_count',cardinality(v_required)-cardinality(v_missing),
    'missing_rpc_names',to_jsonb(v_missing),
    'checkout_signature_ok',v_checkout_ok,
    'checkout_argument_names',to_jsonb(coalesce(v_checkout_names,array[]::text[])),
    'stock_signature_ok',v_stock_ok,
    'stock_argument_names',to_jsonb(coalesce(v_stock_names,array[]::text[])),
    'service_board_rpc_ok',exists(select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='v1344_owner_service_board'),
    'schema_cache_marker','v13.4.6'
  );
end;
$$;
revoke all on function public.v1346_runtime_contract_status() from public;
grant execute on function public.v1346_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('compat_patch_version','13.4.6'),
 ('service_board_version','13.4.6'),
 ('runtime_contract_version','13.4.6'),
 ('rpc_contract_version','13.4.6')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.4.6 RPC CONTRACT COMPLETE' as result,
  to_regprocedure('public.v1346_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null as checkout_adapter_ok,
  to_regprocedure('public.v1346_add_product_stock(uuid,numeric,numeric,text)') is not null as stock_adapter_ok,
  to_regprocedure('public.v1346_runtime_contract_status()') is not null as contract_probe_ok,
  (select (public.v1346_runtime_contract_status()->>'checkout_signature_ok')::boolean) as legacy_checkout_signature_ok,
  (select (public.v1346_runtime_contract_status()->>'stock_signature_ok')::boolean) as legacy_stock_signature_ok;

-- SalonOS v13.4.7 · CHECKOUT PAYMENT-LINE CONTRACT FIX
-- Additive / idempotent. Does NOT delete business data.
-- Fixes legacy checkout_visit builds that read payment JSON keys such as "method"
-- while the current PHP sends "payment_method". The adapter now sends BOTH names
-- (plus other safe aliases) so payment_items.payment_method can never become NULL
-- merely because two SalonOS schema generations used different JSON field names.

begin;
set local statement_timeout='0';

create or replace function public.v1347_normalize_payment_lines(
  p_payments jsonb,
  p_membership_id uuid default null
)
returns jsonb
language plpgsql
immutable
set search_path=public
as $$
declare
  v_line jsonb;
  v_out jsonb := '[]'::jsonb;
  v_method text;
  v_amount numeric;
  v_reference text;
  v_notes text;
begin
  if p_payments is null then p_payments := '[]'::jsonb; end if;
  if jsonb_typeof(p_payments) <> 'array' then
    raise exception '付款资料格式无效：payments 必须是 JSON array。';
  end if;

  for v_line in select value from jsonb_array_elements(p_payments)
  loop
    if jsonb_typeof(v_line) <> 'object' then
      raise exception '付款资料格式无效：每个 payment line 必须是 JSON object。';
    end if;

    v_method := lower(trim(coalesce(
      nullif(v_line->>'payment_method',''),
      nullif(v_line->>'method',''),
      nullif(v_line->>'payment_type',''),
      nullif(v_line->>'type',''),
      nullif(v_line->>'payment_channel',''),
      nullif(v_line->>'payment_method_code',''),
      nullif(v_line->>'method_code',''),
      nullif(v_line->>'mode',''),
      nullif(v_line->>'channel',''),
      nullif(v_line->>'paymentMethod',''),
      'cash'
    )));

    v_method := case v_method
      when 'e-wallet' then 'ewallet'
      when 'e_wallet' then 'ewallet'
      when 'bank transfer' then 'bank_transfer'
      when 'bank-transfer' then 'bank_transfer'
      when 'banktransfer' then 'bank_transfer'
      when 'wallet' then 'member_wallet'
      when 'member wallet' then 'member_wallet'
      else v_method
    end;

    if v_method not in ('cash','card','ewallet','bank_transfer','member_wallet','other') then
      raise exception '不支持的付款方式：%',v_method;
    end if;

    v_amount := coalesce(
      nullif(v_line->>'amount','')::numeric,
      nullif(v_line->>'paid_amount','')::numeric,
      nullif(v_line->>'payment_amount','')::numeric,
      nullif(v_line->>'value','')::numeric,
      0
    );
    if v_amount <= 0 then raise exception '每一笔付款金额必须大于 0。'; end if;

    v_reference := nullif(trim(coalesce(
      v_line->>'reference_number',
      v_line->>'reference',
      v_line->>'ref',
      v_line->>'transaction_reference',
      ''
    )), '');
    v_notes := nullif(trim(coalesce(v_line->>'notes',v_line->>'note','')), '');

    -- Keep the caller payload, then add a compatibility envelope containing every
    -- payment-key spelling used by historical SalonOS checkout functions.
    v_line := v_line || jsonb_build_object(
      'payment_method',v_method,
      'method',v_method,
      'payment_type',v_method,
      'type',v_method,
      'payment_channel',v_method,
      'payment_method_code',v_method,
      'method_code',v_method,
      'mode',v_method,
      'channel',v_method,
      'paymentMethod',v_method,
      'amount',round(v_amount,2),
      'paid_amount',round(v_amount,2),
      'payment_amount',round(v_amount,2),
      'paid',round(v_amount,2),
      'total',round(v_amount,2),
      'line_total',round(v_amount,2),
      'value',round(v_amount,2),
      'reference_number',v_reference,
      'reference',v_reference,
      'ref',v_reference,
      'transaction_reference',v_reference,
      'notes',v_notes,
      'note',v_notes,
      'membership_id',p_membership_id,
      'loyalty_membership_id',p_membership_id
    );

    v_out := v_out || jsonb_build_array(jsonb_strip_nulls(v_line));
  end loop;

  if jsonb_array_length(v_out)=0 then raise exception '请至少提供一笔付款。'; end if;
  return v_out;
end;
$$;

revoke all on function public.v1347_normalize_payment_lines(jsonb,uuid) from public;
grant execute on function public.v1347_normalize_payment_lines(jsonb,uuid) to authenticated;

create or replace function public.v1347_checkout_visit(
  p_visit_id uuid,
  p_payments jsonb,
  p_discount_total numeric default 0,
  p_tax_total numeric default 0,
  p_membership_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_payments jsonb;
  v_out jsonb;
begin
  if p_visit_id is null then raise exception '订单 ID 不能为空。'; end if;

  v_payments := public.v1347_normalize_payment_lines(p_payments,p_membership_id);

  if to_regprocedure('public.v1346_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is null then
    raise exception 'SalonOS v13.4.6 基础结账 Adapter 尚未安装。请运行 v13.4.7 累计补丁。';
  end if;

  v_out := public.v1346_checkout_visit(
    p_visit_id,
    v_payments,
    greatest(coalesce(p_discount_total,0),0),
    greatest(coalesce(p_tax_total,0),0),
    p_membership_id
  );

  return coalesce(v_out,jsonb_build_object('ok',true));
end;
$$;

revoke all on function public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid) from public;
grant execute on function public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid) to authenticated;

create or replace function public.v1347_runtime_contract_status()
returns jsonb
language plpgsql
stable
security definer
set search_path=public
as $$
declare
  v_base jsonb := '{}'::jsonb;
  v_sample jsonb;
  v_line jsonb;
  v_alias_ok boolean := false;
begin
  if to_regprocedure('public.v1346_runtime_contract_status()') is not null then
    begin
      v_base := public.v1346_runtime_contract_status();
    exception when others then
      v_base := jsonb_build_object('ok',false,'base_contract_error',sqlerrm);
    end;
  end if;

  v_sample := public.v1347_normalize_payment_lines('[{"payment_method":"cash","amount":1}]'::jsonb,null);
  v_line := v_sample->0;
  v_alias_ok := coalesce(v_line->>'payment_method','')='cash'
    and coalesce(v_line->>'method','')='cash'
    and coalesce(v_line->>'payment_type','')='cash'
    and coalesce(v_line->>'type','')='cash'
    and coalesce((v_line->>'amount')::numeric,0)=1;

  return jsonb_build_object(
    'version','13.4.7',
    'ok',coalesce((v_base->>'ok')::boolean,false)
      and to_regprocedure('public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null
      and v_alias_ok,
    'base_contract',v_base,
    'required_rpc_count',coalesce((v_base->>'required_rpc_count')::integer,0),
    'present_rpc_count',coalesce((v_base->>'present_rpc_count')::integer,0),
    'missing_rpc_names',coalesce(v_base->'missing_rpc_names','[]'::jsonb),
    'checkout_signature_ok',coalesce((v_base->>'checkout_signature_ok')::boolean,false),
    'stock_signature_ok',coalesce((v_base->>'stock_signature_ok')::boolean,false),
    'checkout_adapter_ok',to_regprocedure('public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null,
    'payment_alias_contract_ok',v_alias_ok,
    'payment_items_table_ok',to_regclass('public.payment_items') is not null,
    'payment_method_column_ok',exists(
      select 1 from information_schema.columns
      where table_schema='public' and table_name='payment_items' and column_name='payment_method'
    ),
    'schema_cache_marker','v13.4.7'
  );
end;
$$;

revoke all on function public.v1347_runtime_contract_status() from public;
grant execute on function public.v1347_runtime_contract_status() to authenticated;

insert into public.salonos_system_meta(meta_key,meta_value) values
 ('compat_patch_version','13.4.7'),
 ('service_board_version','13.4.7'),
 ('runtime_contract_version','13.4.7'),
 ('rpc_contract_version','13.4.7'),
 ('checkout_payment_contract_version','13.4.7')
on conflict(meta_key) do update set meta_value=excluded.meta_value,updated_at=now();

commit;
notify pgrst,'reload schema';

select
  'SalonOS v13.4.7 CHECKOUT PAYMENT CONTRACT READY' as result,
  to_regprocedure('public.v1347_checkout_visit(uuid,jsonb,numeric,numeric,uuid)') is not null as checkout_adapter_ok,
  to_regprocedure('public.v1347_normalize_payment_lines(jsonb,uuid)') is not null as payment_normalizer_ok,
  (public.v1347_runtime_contract_status()->>'payment_alias_contract_ok')::boolean as payment_alias_contract_ok,
  (public.v1347_runtime_contract_status()->>'payment_method_column_ok')::boolean as payment_method_column_ok;
