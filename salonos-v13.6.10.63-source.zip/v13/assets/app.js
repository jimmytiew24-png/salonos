document.addEventListener('DOMContentLoaded', () => {
  const menuButton = document.querySelector('[data-menu]');
  const menuClose = document.querySelector('[data-menu-close]');
  const sidebar = document.querySelector('.sidebar');
  const sidebarOverlay = document.querySelector('[data-sidebar-overlay]');

  const setMenu = (open) => {
    sidebar?.classList.toggle('open', open);
    sidebarOverlay?.classList.toggle('show', open);
    document.body.classList.toggle('menu-open', open);
  };

  menuButton?.addEventListener('click', () => setMenu(!sidebar?.classList.contains('open')));
  menuClose?.addEventListener('click', () => setMenu(false));
  sidebarOverlay?.addEventListener('click', () => setMenu(false));
  sidebar?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => setMenu(false)));

  document.querySelector('[data-password-toggle]')?.addEventListener('click', (event) => {
    const button = event.currentTarget;
    const input = button.closest('.input-shell')?.querySelector('input');
    if (!input) return;
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    button.textContent = show ? '隐藏' : '查看';
  });

  clearSubmittedVisitDraft();
  setupVisitEditor();
  setupSignaturePad();
  setupUtilityPanels();
  setupCommissionAllocation(document);
  setupCommissionModal();
  setupCommissionTierEditor();
  setupMemberModal();
  setupCheckoutModal();
  setupServiceBoardModal();
  setupMembershipLevelEditor();
  setupInventoryStockModal();
  setupEmployeeManager();
  setupInventoryItemModal();
  setupBranchEditor();
  setupInventoryDeleteModal();
  setupOrderMaterialModal();
  setupServiceManagement();
  setupLocalizedDateInputs();
  setupCatalogImagePreviews();
  setupCatalogImageViewer();
  setupTunaiproImportOptions();
  setupDashboardLive();
  setupServiceBoardLive();


  function setupLocalizedDateInputs() {
    const formatDateValue = (value, includeTime = false) => {
      if (!value) return '';
      const [datePart, timePart = ''] = String(value).split('T');
      const [year, month, day] = datePart.split('-');
      if (!year || !month || !day) return '';
      const dateText = `${day}/${month}/${year}`;
      return includeTime && timePart ? `${dateText} ${timePart.slice(0, 5)}` : dateText;
    };

    const enhance = (input) => {
      if (!(input instanceof HTMLInputElement) || input.dataset.localizedDate === '1') return;
      if (!['date', 'datetime-local'].includes(input.type)) return;
      input.dataset.localizedDate = '1';
      const includeTime = input.type === 'datetime-local';

      const wrapper = document.createElement('div');
      wrapper.className = 'localized-date-control';
      const display = document.createElement('input');
      display.type = 'text';
      display.className = `${input.className || 'input'} localized-date-display`;
      display.placeholder = includeTime ? 'DD/MM/YYYY HH:MM' : 'DD/MM/YYYY';
      display.readOnly = true;
      display.autocomplete = 'off';
      display.inputMode = 'none';
      display.setAttribute('aria-label', includeTime ? '日期与时间，格式日月年' : '日期，格式日月年');

      const actions = document.createElement('span');
      actions.className = 'localized-date-actions';
      const clear = document.createElement('button');
      clear.type = 'button';
      clear.className = 'localized-date-clear';
      clear.setAttribute('aria-label', '清除日期');
      clear.textContent = '×';
      const calendar = document.createElement('button');
      calendar.type = 'button';
      calendar.className = 'localized-date-calendar';
      calendar.setAttribute('aria-label', '打开日历');
      calendar.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3v3M17 3v3M4 9h16M5 5h14a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Z"/></svg>';
      actions.append(clear, calendar);

      input.parentNode?.insertBefore(wrapper, input);
      wrapper.append(display, input, actions);
      input.classList.add('localized-date-native');
      input.lang = 'en-GB';
      input.tabIndex = -1;

      const sync = () => {
        display.value = formatDateValue(input.value, includeTime);
        clear.hidden = !input.value;
        display.classList.remove('localized-date-invalid');
      };
      input._syncLocalizedDate = sync;

      const openPicker = () => {
        sync();
        try {
          input.focus({ preventScroll: true });
        } catch { input.focus(); }
        try {
          if (typeof input.showPicker === 'function') input.showPicker();
          else input.click();
        } catch {
          // The native input now overlays the visible field on mobile/PWA, so a direct
          // tap remains available even when a browser refuses programmatic showPicker().
          try { input.click(); } catch {}
        }
      };

      display.addEventListener('click', openPicker);
      calendar.addEventListener('click', openPicker);
      clear.addEventListener('click', () => {
        input.value = '';
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        sync();
      });
      input.addEventListener('input', sync);
      input.addEventListener('change', sync);
      input.addEventListener('invalid', (event) => {
        event.preventDefault();
        display.classList.add('localized-date-invalid');
        display.focus();
      });
      input.form?.addEventListener('reset', () => setTimeout(sync, 0));
      sync();
    };

    const scan = (root = document) => {
      if (root instanceof HTMLInputElement) enhance(root);
      root.querySelectorAll?.('input[type="date"], input[type="datetime-local"]').forEach(enhance);
    };

    scan(document);
    const syncAll = () => document.querySelectorAll('input[data-localized-date="1"]').forEach((input) => input._syncLocalizedDate?.());
    document.addEventListener('click', () => setTimeout(syncAll, 0));
    document.addEventListener('focusin', syncAll);
    new MutationObserver((records) => {
      records.forEach((record) => record.addedNodes.forEach((node) => {
        if (node instanceof Element) scan(node);
      }));
    }).observe(document.body, { childList: true, subtree: true });
  }

  function clearSubmittedVisitDraft() {
    const marker = document.querySelector('[data-clear-visit-draft]');
    const key = marker?.dataset.clearVisitDraft;
    if (key) localStorage.removeItem(key);
  }

  function setupUtilityPanels() {
    document.querySelectorAll('[data-toggle-panel]').forEach((button) => {
      button.addEventListener('click', () => {
        const panel = document.getElementById(button.dataset.togglePanel || '');
        if (!panel) return;
        panel.hidden = !panel.hidden;
        if (!panel.hidden) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    });

    const template = document.querySelector('[data-kpi-template]');
    const target = document.querySelector('[data-kpi-target]');
    const reward = document.querySelector('[data-kpi-reward]');
    template?.addEventListener('change', () => {
      const option = template.selectedOptions[0];
      if (target) target.value = option?.dataset.target || '';
      if (reward) reward.value = option?.dataset.reward || '';
    });
  }

  function setupVisitEditor() {
    const form = document.querySelector('#visit-wizard');
    if (!form) return;

    const serviceRows = form.querySelector('#service-rows');
    const serviceTemplate = form.querySelector('#service-template');
    const recipientRows = form.querySelector('#recipient-rows');
    const recipientTemplate = form.querySelector('#recipient-template');
    const recipientEmpty = form.querySelector('[data-recipient-empty]');
    const draftKey = form.dataset.draftKey || 'salonos.visit.draft';
    const draftStatus = document.querySelector('[data-draft-status]');
    const recovery = document.querySelector('[data-draft-recovery]');
    const recoveryTime = recovery?.querySelector('[data-draft-recovery-time]');
    const initialCustomerNode = form.querySelector('#initial-customer-data');
    let selectedCustomer = safeJsonParse(initialCustomerNode?.textContent || 'null', null);
    let currentStep = 1;
    let recipientCounter = 0;
    let saveTimer = null;
    let suppressSave = true;

    bindRecipientEditor();
    bindServiceEditor();
    setupCustomerSearch();
    setupWizard();
    setupStylistAvailability();
    syncAll();
    setupDraftRecovery();
    suppressSave = false;

    form.addEventListener('input', (event) => {
      if (event.target.matches('.contribution-input')) event.target.dataset.manual = '1';
      syncAll();
      scheduleDraftSave();
    });
    form.addEventListener('change', () => {
      syncAll();
      scheduleDraftSave();
    });
    window.addEventListener('beforeunload', () => saveDraft(true));

    function bindRecipientEditor() {
      form.querySelector('[data-add-recipient]')?.addEventListener('click', () => {
        if (!recipientTemplate || !recipientRows) return;
        recipientRows.appendChild(recipientTemplate.content.cloneNode(true));
        const row = recipientRows.lastElementChild;
        ensureRecipientKey(row);
        syncAll();
        scheduleDraftSave();
        row?.querySelector('[data-recipient-field="name"]')?.focus();
        row?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });

      recipientRows?.addEventListener('click', (event) => {
        const button = event.target.closest('[data-remove-recipient]');
        if (!button) return;
        const row = button.closest('[data-recipient-row]');
        const key = row?.querySelector('[data-recipient-field="key"]')?.value;
        row?.remove();
        if (key) {
          serviceRows?.querySelectorAll('.recipient-select').forEach((select) => {
            if (select.value === key) select.value = 'self';
          });
        }
        syncAll();
        scheduleDraftSave();
      });
    }

    function bindServiceEditor() {
      form.querySelector('[data-add-service]')?.addEventListener('click', () => {
        if (!serviceTemplate || !serviceRows) return;
        serviceRows.appendChild(serviceTemplate.content.cloneNode(true));
        syncAll();
        scheduleDraftSave();
        serviceRows.lastElementChild?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });

      serviceRows?.addEventListener('click', (event) => {
        const removeService = event.target.closest('[data-remove-service]');
        if (removeService) {
          if (serviceRows.children.length <= 1) resetServiceRow(removeService.closest('.service-row'));
          else removeService.closest('.service-row')?.remove();
          syncAll();
          scheduleDraftSave();
          return;
        }

        const addWorker = event.target.closest('[data-add-worker]');
        if (addWorker) {
          const row = addWorker.closest('.service-row');
          const role = addWorker.dataset.addWorker;
          const template = row?.querySelector(`template[data-worker-template="${role}"]`);
          const list = row?.querySelector(`[data-worker-list="${role}"]`);
          if (template && list) {
            list.appendChild(template.content.cloneNode(true));
            setDefaultContributions(row, true);
            syncAll();
            scheduleDraftSave();
            list.lastElementChild?.querySelector('select')?.focus();
          }
          return;
        }

        const autoContribution = event.target.closest('[data-auto-contribution]');
        if (autoContribution) {
          const row = autoContribution.closest('.service-row');
          setDefaultContributions(row, true);
          syncAll();
          scheduleDraftSave();
          return;
        }

        const removeWorker = event.target.closest('[data-remove-worker]');
        if (removeWorker) {
          const row = removeWorker.closest('.service-row');
          removeWorker.closest('[data-worker-row]')?.remove();
          setDefaultContributions(row, true);
          syncAll();
          scheduleDraftSave();
        }
      });

      const applyServiceCategory = (row, preserveService = '') => {
        if (!row) return;
        const category = row.querySelector('.service-category-select');
        const service = row.querySelector('.service-select');
        if (!category || !service) return;
        const selectedCategory = category.value || '';
        let firstVisible = null;
        [...service.options].forEach((option, index) => {
          if (index === 0) return;
          const visible = selectedCategory !== '' && option.dataset.categoryId === selectedCategory;
          option.hidden = !visible;
          option.disabled = !visible;
          if (visible && !firstVisible) firstVisible = option;
        });
        service.disabled = selectedCategory === '';
        const target = preserveService || service.value;
        if (target && [...service.options].some((option) => !option.disabled && option.value === target)) service.value = target;
        else service.value = '';
        service.options[0].textContent = selectedCategory ? '选择分类内服务' : '先选择分类';
        updateServiceVisuals(row);
      };

      serviceRows?.addEventListener('change', (event) => {
        const row = event.target.closest('.service-row');
        if (event.target.matches('.service-category-select')) {
          applyServiceCategory(row);
          scheduleDraftSave();
          return;
        }
        if (!event.target.matches('.service-select')) return;
        const option = event.target.selectedOptions[0];
        const price = row?.querySelector('.price-input');
        if (price) price.value = option?.dataset.price || '0';
        updateServiceVisuals(row);
      });

      document.querySelectorAll('input[name="assignment_type"]').forEach((radio) => {
        radio.addEventListener('change', syncAssignmentMode);
      });
    }

    function resetServiceRow(row) {
      if (!row) return;
      row.querySelectorAll('select').forEach((select) => { select.selectedIndex = 0; });
      row.querySelectorAll('[data-worker-row]').forEach((worker) => worker.remove());
      const price = row.querySelector('.price-input');
      if (price) price.value = '0';
      const leadContribution = row.querySelector('[data-lead-contribution]');
      if (leadContribution) leadContribution.value = '100';
      updateServiceVisuals(row);
    }

    function ensureRecipientKey(row) {
      const keyInput = row?.querySelector('[data-recipient-field="key"]');
      if (!keyInput) return '';
      if (!keyInput.value) {
        recipientCounter += 1;
        keyInput.value = `r_${Date.now()}_${recipientCounter}`;
      }
      return keyInput.value;
    }

    function syncAll() {
      syncRecipients();
      syncServiceRows();
      syncAssignmentMode();
      calculateTotals();
      if (currentStep === 3) buildReview();
    }

    function syncRecipients() {
      const recipients = [];
      recipientRows?.querySelectorAll('[data-recipient-row]').forEach((row, index) => {
        const key = ensureRecipientKey(row);
        row.querySelectorAll('[data-recipient-field]').forEach((input) => {
          input.name = `recipients[${index}][${input.dataset.recipientField}]`;
        });
        const name = row.querySelector('[data-recipient-field="name"]')?.value.trim() || `同行者 ${index + 1}`;
        const relationship = row.querySelector('[data-recipient-field="relationship"]')?.value || '同行者';
        const label = row.querySelector('[data-recipient-index]');
        if (label) label.textContent = `同行者 ${index + 1}`;
        recipients.push({ key, name, relationship });
      });
      if (recipientEmpty) recipientEmpty.hidden = recipients.length > 0;

      serviceRows?.querySelectorAll('.recipient-select').forEach((select) => {
        const current = select.value || 'self';
        select.querySelectorAll('option[data-dynamic-recipient]').forEach((option) => option.remove());
        recipients.forEach((recipient) => {
          const option = document.createElement('option');
          option.value = recipient.key;
          option.dataset.dynamicRecipient = '1';
          option.textContent = `${recipient.name} · ${recipient.relationship}`;
          select.appendChild(option);
        });
        select.value = [...select.options].some((option) => option.value === current) ? current : 'self';
      });
    }

    function syncServiceRows() {
      serviceRows?.querySelectorAll('.service-row').forEach((row, index) => {
        row.querySelectorAll('[data-field]').forEach((input) => {
          input.name = `items[${index}][${input.dataset.field}]`;
        });
        row.querySelectorAll('[data-worker-role="co_stylist"]').forEach((select, workerIndex) => {
          select.name = `items[${index}][co_stylists][]`;
          const share = select.closest('[data-worker-row]')?.querySelector('[data-worker-contribution]');
          if (share) share.name = `items[${index}][co_contributions][]`;
        });
        row.querySelectorAll('[data-worker-role="assistant"]').forEach((select, workerIndex) => {
          select.name = `items[${index}][assistants][]`;
          const share = select.closest('[data-worker-row]')?.querySelector('[data-worker-contribution]');
          if (share) share.name = `items[${index}][assistant_contributions][]`;
        });
        const indexLabel = row.querySelector('.service-index');
        if (indexLabel) indexLabel.textContent = `项目 ${index + 1}`;
        updateServiceVisuals(row);
      });
    }

    function contributionSummary(row) {
      const values = [
        Number(row.querySelector('[data-lead-contribution]')?.value || 0),
        ...[...row.querySelectorAll('[data-worker-contribution]')].map((input) => Number(input.value || 0))
      ];
      return values.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);
    }

    function setDefaultContributions(row, force = false) {
      if (!row) return;
      const lead = row.querySelector('[data-lead-contribution]');
      const co = [...row.querySelectorAll('[data-worker-list="co_stylist"] [data-worker-contribution]')];
      const assistants = [...row.querySelectorAll('[data-worker-list="assistant"] [data-worker-contribution]')];
      if (!force && [lead, ...co, ...assistants].some((input) => input?.dataset.manual === '1')) return;

      let leadPct = 100;
      let coPool = 0;
      let assistantPool = 0;
      if (co.length && assistants.length) { leadPct = 60; coPool = 25; assistantPool = 15; }
      else if (co.length) { leadPct = 75; coPool = 25; }
      else if (assistants.length) { leadPct = 80; assistantPool = 20; }

      if (lead) { lead.value = String(leadPct); delete lead.dataset.manual; }
      co.forEach((input) => { input.value = String(Number((coPool / co.length).toFixed(2))); delete input.dataset.manual; });
      assistants.forEach((input) => { input.value = String(Number((assistantPool / assistants.length).toFixed(2))); delete input.dataset.manual; });
    }

    function updateServiceVisuals(row) {
      if (!row) return;
      const service = row.querySelector('.service-select');
      const option = service?.selectedOptions[0];
      const summary = row.querySelector('[data-service-summary]');
      const duration = row.querySelector('[data-duration-text]');
      if (summary) summary.textContent = service?.value ? option?.textContent || '服务项目' : '请选择服务项目';
      if (duration) duration.textContent = `${Number(option?.dataset.minutes || 0)} 分钟`;
      const total = contributionSummary(row);
      const note = row.querySelector('[data-contribution-note]');
      if (note) {
        note.textContent = `Contribution 合计 ${total.toFixed(2)}%${Math.abs(total - 100) <= 0.05 ? ' · 正确' : ' · 必须调整为 100%'}`;
        note.classList.toggle('invalid', Math.abs(total - 100) > 0.05);
      }
    }

    function syncAssignmentMode() {
      const systemMode = form.querySelector('input[name="assignment_type"]:checked')?.value === 'system';
      serviceRows?.querySelectorAll('.lead-select').forEach((select) => {
        select.disabled = systemMode;
        select.closest('.field')?.classList.toggle('field-disabled', systemMode);
      });
    }

    function calculateTotals() {
      let total = 0;
      let minutes = 0;
      serviceRows?.querySelectorAll('.service-row').forEach((row) => {
        const service = row.querySelector('.service-select');
        if (!service?.value) return;
        total += Number(row.querySelector('.price-input')?.value || 0);
        minutes += Number(service.selectedOptions[0]?.dataset.minutes || 0);
      });
      document.querySelectorAll('[data-order-total]').forEach((target) => { target.textContent = `RM ${total.toFixed(2)}`; });
      document.querySelectorAll('[data-order-minutes]').forEach((target) => { target.textContent = `${minutes} 分钟`; });
    }

    function setupWizard() {
      const panels = [...form.querySelectorAll('[data-wizard-panel]')];
      const indicators = [...document.querySelectorAll('[data-step-indicator]')];
      const progress = document.querySelector('[data-wizard-progress]');
      const progressFill = progress?.querySelector('[data-progress-fill]');
      const prevButton = form.querySelector('[data-wizard-prev]');
      const nextButton = form.querySelector('[data-wizard-next]');
      const submitButton = form.querySelector('[data-wizard-submit]');
      const counter = form.querySelector('[data-step-counter]');
      const errorBox = form.querySelector('[data-wizard-error]');
      const appointmentField = form.querySelector('[data-appointment-field]');
      const appointmentInput = form.querySelector('[data-appointment-input]');
      const appointmentStylistField = form.querySelector('[data-appointment-stylist-field]');
      const appointmentStylistSelect = form.querySelector('.appointment-preferred-select');
      const flowTitle = form.querySelector('[data-review-flow-title]');
      const flowText = form.querySelector('[data-review-flow-text]');
      const stepFourLabel = document.querySelector('[data-step-indicator="4"] .wizard-step-label');
      const maxEditableStep = 3;
      const isAppointmentBooking = () => form.querySelector('input[name="visit_type"]:checked')?.value === 'appointment'; // v13.5.8: appointments are booked first; signature unlocks only after arrival
      const syncAppointmentMode = () => {
        const isAppointment = form.querySelector('input[name="visit_type"]:checked')?.value === 'appointment';
        const appointmentSpecified = form.querySelector('input[name="appointment_assignment_type"]:checked')?.value === 'specified';
        if (appointmentField) appointmentField.hidden = !isAppointment;
        if (appointmentInput) appointmentInput.required = isAppointment;
        if (appointmentStylistField) appointmentStylistField.hidden = !(isAppointment && appointmentSpecified);
        if (appointmentStylistSelect) appointmentStylistSelect.required = isAppointment && appointmentSpecified;
        if (!isAppointment && appointmentStylistSelect) appointmentStylistSelect.value = '';

        if (isAppointment && appointmentSpecified && appointmentStylistSelect?.value) {
          serviceRows?.querySelectorAll('.lead-select').forEach((select) => {
            if (!select.value && [...select.options].some((option) => option.value === appointmentStylistSelect.value)) {
              select.value = appointmentStylistSelect.value;
            }
          });
        }

        const booking = isAppointmentBooking();
        if (stepFourLabel) stepFourLabel.textContent = isAppointment ? '到店后签名' : '电子签名';
        const stepFourIndicator = document.querySelector('[data-step-indicator="4"]');
        if (stepFourIndicator) stepFourIndicator.hidden = isAppointment;
        if (submitButton && currentStep === 3) submitButton.textContent = isAppointment ? '建立预约 →' : (form.dataset.editing === '1' ? '保存修改并进入签名 →' : (submitButton.dataset.defaultLabel || '建立订单并进入签名 →'));
        if (flowTitle) flowTitle.textContent = isAppointment ? '建立预约' : (form.dataset.editing === '1' ? '更正规则' : '下一步');
        if (flowText) flowText.textContent = isAppointment ? '现在只建立预约，不会要求顾客签名。顾客到店后，在服务现场点击「顾客已到达」才开放签名。' : (form.dataset.editing === '1' ? '保存修改后，当前内容必须重新让顾客确认并签名。' : '建立 Supabase 订单后直接进入第 4 步电子签名。');
      };
      form.querySelectorAll('input[name="visit_type"],input[name="appointment_assignment_type"]').forEach((radio)=>radio.addEventListener('change',()=>{syncAppointmentMode();scheduleDraftSave();}));
      appointmentStylistSelect?.addEventListener('change',()=>{syncAppointmentMode();scheduleDraftSave();});

      nextButton?.addEventListener('click', () => {
        if (!validateStep(currentStep)) return;
        goToStep(Math.min(maxEditableStep, currentStep + 1));
      });
      prevButton?.addEventListener('click', () => goToStep(Math.max(1, currentStep - 1)));
      indicators.forEach((indicator) => indicator.addEventListener('click', () => {
        const requested = Number(indicator.dataset.stepIndicator);
        if (requested < currentStep && requested <= maxEditableStep) goToStep(requested);
      }));

      form.addEventListener('submit', (event) => {
        if (currentStep !== 3) {
          event.preventDefault();
          if (validateStep(currentStep)) goToStep(Math.min(3, currentStep + 1));
          return;
        }
        if (!validateStep(2)) {
          event.preventDefault();
          goToStep(2);
          return;
        }
        syncAll();
        saveDraft(true);
        if (submitButton) {
          submitButton.disabled = true;
          submitButton.textContent = isAppointmentBooking() ? '正在上传预约到柜台…' : (form.dataset.editing === '1' ? '正在保存修改…' : '正在建立订单…');
        }
      });

      function goToStep(step) {
        currentStep = step;
        panels.forEach((panel) => panel.classList.toggle('active', Number(panel.dataset.wizardPanel) === currentStep));
        indicators.forEach((indicator) => {
          const number = Number(indicator.dataset.stepIndicator);
          const circle = indicator.querySelector('.wizard-step-number');
          indicator.classList.remove('done', 'current', 'upcoming');
          if (number < currentStep) { indicator.classList.add('done'); if (circle) circle.textContent = '✓'; }
          else if (number === currentStep) { indicator.classList.add('current'); if (circle) circle.textContent = String(number); }
          else { indicator.classList.add('upcoming'); if (circle) circle.textContent = String(number); }
        });
        const bookingFlow = isAppointmentBooking();
        const percent = bookingFlow ? ((currentStep - 1) / 2) * 100 : ((currentStep - 1) / 3) * 100;
        if (progress) progress.style.setProperty('--wizard-progress', `${percent}%`);
        if (progressFill) progressFill.style.width = `${percent}%`;
        if (counter) counter.textContent = bookingFlow ? `预约建立第 ${currentStep} / 3 步` : `第 ${currentStep} / 4 步`;
        if (prevButton) prevButton.hidden = currentStep === 1;
        if (nextButton) nextButton.hidden = currentStep === maxEditableStep;
        if (submitButton) submitButton.hidden = currentStep !== maxEditableStep;
        syncAppointmentMode();
        clearError();
        if (currentStep === 3) buildReview();
        scheduleDraftSave();
        if (currentStep > 1) progress?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }

      function validateStep(step) {
        clearError();
        if (step === 1) {
          if (!form.querySelector('input[name="visit_type"]:checked')) return fail('请选择到店方式。');
          if (form.querySelector('input[name="visit_type"]:checked')?.value === 'appointment') {
            if (!appointmentInput?.value) { appointmentInput?.focus(); return fail('请填写预约日期与时间。'); }
            if (form.querySelector('input[name="appointment_assignment_type"]:checked')?.value === 'specified' && !appointmentStylistSelect?.value) {
              appointmentStylistSelect?.focus();
              return fail('预约选择“指定理发师”时，请先选择理发师。');
            }
          }
          return true;
        }
        if (step === 2) {
          if (!form.querySelector('input[name="assignment_type"]:checked')) return fail('请选择理发师安排方式。');
          const customerId = form.querySelector('#customer-id')?.value;
          const customerName = form.querySelector('#visit-customer-name')?.value.trim();
          const customerPhone = form.querySelector('#visit-customer-phone')?.value.trim();
          if (!customerId && !customerName) {
            form.querySelector('#visit-customer-name')?.focus();
            return fail('请填写顾客姓名，第一次到店不需要先办理会员。');
          }
          if (!customerId && !customerPhone) {
            form.querySelector('#visit-customer-phone')?.focus();
            return fail('请填写顾客电话号码。');
          }
          for (const recipient of form.querySelectorAll('[data-recipient-row]')) {
            const name = recipient.querySelector('[data-recipient-field="name"]');
            if (!name?.value.trim()) { name?.focus(); return fail('已增加同行者，请填写同行者姓名。'); }
          }
          const activeRows = [...form.querySelectorAll('.service-row')].filter((row) => row.querySelector('.service-select')?.value);
          if (!activeRows.length) { form.querySelector('.service-select')?.focus(); return fail('请至少添加一个服务项目。'); }
          const assignment = form.querySelector('input[name="assignment_type"]:checked')?.value;
          for (const row of activeRows) {
            const lead = row.querySelector('.lead-select');
            if (assignment === 'specified' && !lead?.value) { lead?.focus(); return fail('指定模式下，每个项目都必须选择主理发师。'); }
            const price = Number(row.querySelector('.price-input')?.value || 0);
            if (price < 0) return fail('项目价格不能小于 0。');
            const ids = [lead?.value, ...[...row.querySelectorAll('.worker-select')].map((select) => select.value)].filter(Boolean);
            if (new Set(ids).size !== ids.length) return fail('同一个项目中，同一位员工不能重复担任多个角色。');
            if ([...row.querySelectorAll('.worker-select')].some((select) => !select.value)) return fail('已增加人员栏位，请选择员工或删除空栏位。');
            const contributionTotal = contributionSummary(row);
            if (Math.abs(contributionTotal - 100) > 0.05) {
              row.querySelector('[data-lead-contribution]')?.focus();
              return fail(`每个项目的 Contribution % 总和必须是 100%。目前是 ${contributionTotal.toFixed(2)}%。`);
            }
          }
          return true;
        }
        return true;
      }

      function fail(message) {
        if (errorBox) {
          errorBox.hidden = false;
          errorBox.textContent = message;
          errorBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else alert(message);
        return false;
      }
      function clearError() { if (errorBox) { errorBox.hidden = true; errorBox.textContent = ''; } }
      form.goToVisitStep = goToStep;
      goToStep(1);
    }

    function buildReview() {
      const visitType = form.querySelector('input[name="visit_type"]:checked')?.closest('label')?.querySelector('b')?.textContent || '—';
      const assignment = form.querySelector('input[name="assignment_type"]:checked')?.closest('label')?.querySelector('b')?.textContent || '—';
      const manualCustomerName = form.querySelector('#visit-customer-name')?.value.trim() || '';
      const manualCustomerPhone = form.querySelector('#visit-customer-phone')?.value.trim() || '';
      setText('[data-review-customer]', selectedCustomer?.name || manualCustomerName || '尚未填写');
      setText('[data-review-customer-meta]', selectedCustomer
        ? `${selectedCustomer.phone || ''}${selectedCustomer.member_number ? ` · ${selectedCustomer.member_level || ''} 会员` : ' · 已有非会员顾客'}`
        : `${manualCustomerPhone || '未填写电话'} · 新顾客／非会员`);
      setText('[data-review-visit-type]', visitType);
      const appointmentAt = form.querySelector('[data-appointment-input]')?.value || '';
      const appointmentType = form.querySelector('input[name="appointment_assignment_type"]:checked')?.value || 'system';
      const appointmentStylist = form.querySelector('.appointment-preferred-select')?.selectedOptions[0]?.textContent || '';
      const appointmentMeta = appointmentAt && form.querySelector('input[name="visit_type"]:checked')?.value === 'appointment'
        ? `${appointmentAt.replace('T',' ')} · ${appointmentType === 'specified' ? `预约指定：${appointmentStylist || '未选择'}` : '预约系统分配'} · 项目：${assignment}`
        : assignment;
      setText('[data-review-assignment]', appointmentMeta);

      const recipientMap = { self: '顾客本人' };
      form.querySelectorAll('[data-recipient-row]').forEach((row) => {
        const key = row.querySelector('[data-recipient-field="key"]')?.value;
        const name = row.querySelector('[data-recipient-field="name"]')?.value.trim();
        if (key) recipientMap[key] = name || '未命名同行者';
      });
      let total = 0;
      let minutes = 0;
      const list = form.querySelector('[data-review-items]');
      list?.replaceChildren();
      [...form.querySelectorAll('.service-row')].filter((row) => row.querySelector('.service-select')?.value).forEach((row) => {
        const service = row.querySelector('.service-select');
        const option = service.selectedOptions[0];
        const price = Number(row.querySelector('.price-input')?.value || 0);
        const itemMinutes = Number(option?.dataset.minutes || 0);
        total += price;
        minutes += itemMinutes;
        const recipient = recipientMap[row.querySelector('.recipient-select')?.value || 'self'] || '顾客本人';
        const leadSelect = row.querySelector('.lead-select');
        const lead = leadSelect?.value ? leadSelect.selectedOptions[0]?.textContent : '系统智能安排';
        const leadPct = Number(row.querySelector('[data-lead-contribution]')?.value || 0);
        const co = [...row.querySelectorAll('[data-worker-role="co_stylist"]')].filter((select) => select.value).map((select) => ({
          name: select.selectedOptions[0]?.textContent,
          pct: Number(select.closest('[data-worker-row]')?.querySelector('[data-worker-contribution]')?.value || 0)
        }));
        const assistants = [...row.querySelectorAll('[data-worker-role="assistant"]')].filter((select) => select.value).map((select) => ({
          name: select.selectedOptions[0]?.textContent,
          pct: Number(select.closest('[data-worker-row]')?.querySelector('[data-worker-contribution]')?.value || 0)
        }));
        if (list) {
          const item = document.createElement('div');
          item.className = 'review-item';
          const info = document.createElement('div');
          const title = document.createElement('strong');
          title.textContent = option?.textContent || '未选择项目';
          const meta = document.createElement('small');
          const team = [`主理：${lead} ${leadPct.toFixed(2)}%`];
          co.forEach((worker) => team.push(`共同：${worker.name} ${worker.pct.toFixed(2)}%`));
          assistants.forEach((worker) => team.push(`助理：${worker.name} ${worker.pct.toFixed(2)}%`));
          meta.textContent = `服务对象：${recipient} · ${team.join(' · ')} · 约 ${itemMinutes} 分钟`;
          info.append(title, meta);
          const amount = document.createElement('div');
          amount.className = 'review-item-price';
          amount.textContent = `RM ${price.toFixed(2)}`;
          item.append(info, amount);
          list.appendChild(item);
        }
      });
      setText('[data-review-minutes]', `${minutes} 分钟`);
      setText('[data-review-total]', `RM ${total.toFixed(2)}`);
    }

    function setText(selector, value) {
      const target = form.querySelector(selector);
      if (target) target.textContent = value;
    }

    function setupCustomerSearch() {
      const input = form.querySelector('#customer-search');
      const hiddenId = form.querySelector('#customer-id');
      const nameInput = form.querySelector('#visit-customer-name');
      const phoneInput = form.querySelector('#visit-customer-phone');
      const resultBox = form.querySelector('#customer-results');
      const spinner = form.querySelector('[data-customer-spinner]');
      const selectedBox = form.querySelector('#selected-customer');
      const clearButton = form.querySelector('[data-clear-customer]');
      const guestExtra = form.querySelector('[data-guest-extra-fields]');
      const guestInputs = guestExtra ? [...guestExtra.querySelectorAll('input,select,textarea')] : [];
      let timer = null;
      let controller = null;
      if (!input || !hiddenId || !nameInput || !phoneInput || !resultBox || !selectedBox) return;

      const syncGuestExtra = () => {
        const manualMode = !hiddenId.value;
        if (guestExtra) guestExtra.hidden = !manualMode;
        guestInputs.forEach((input) => { input.disabled = !manualMode; if (!manualMode) input.classList.remove('localized-date-invalid'); });
      };

      const setManualMode = (clearValues = false) => {
        selectedCustomer = null;
        hiddenId.value = '';
        selectedBox.hidden = true;
        nameInput.readOnly = false;
        phoneInput.readOnly = false;
        if (clearValues) {
          nameInput.value = '';
          phoneInput.value = '';
          guestInputs.forEach((input) => { input.value = ''; });
        }
        syncGuestExtra();
      };

      if (hiddenId.value) {
        nameInput.readOnly = true;
        phoneInput.readOnly = true;
      }
      syncGuestExtra();

      input.addEventListener('input', () => {
        if (hiddenId.value) setManualMode(true);
        clearTimeout(timer);
        controller?.abort();
        const query = input.value.trim();
        if (query.length < 1) { resultBox.hidden = true; resultBox.replaceChildren(); return; }
        timer = setTimeout(() => searchCustomers(query), 260);
      });
      clearButton?.addEventListener('click', () => {
        setManualMode(true);
        input.value = '';
        resultBox.hidden = true;
        nameInput.focus();
        scheduleDraftSave();
      });
      document.addEventListener('click', (event) => { if (!event.target.closest('.customer-search-box')) resultBox.hidden = true; });

      async function searchCustomers(query) {
        controller = new AbortController();
        if (spinner) spinner.hidden = false;
        try {
          const response = await fetch(`index.php?action=search_customers&q=${encodeURIComponent(query)}&t=${Date.now()}`, { headers: { Accept: 'application/json' }, signal: controller.signal, credentials: 'same-origin', cache: 'no-store' });
          const raw = await response.text();
          let payload;
          try { payload = JSON.parse(raw); } catch { throw new Error('顾客搜索接口返回了非 JSON 内容，请刷新页面后重试。'); }
          if (!response.ok) throw new Error(payload?.error || '顾客搜索失败');
          renderResults(payload);
        } catch (error) {
          if (error.name !== 'AbortError') renderMessage('暂时无法搜索顾客，请直接填写姓名和电话号码。');
        } finally { if (spinner) spinner.hidden = true; }
      }
      function renderResults(customers) {
        resultBox.replaceChildren();
        if (!Array.isArray(customers) || !customers.length) { renderMessage('没有找到资料，可直接在右边填写新顾客姓名和电话。'); return; }
        customers.forEach((customer) => {
          const button = document.createElement('button');
          button.type = 'button';
          button.className = 'customer-result';
          button.innerHTML = `<span class="customer-result-avatar"></span><span><strong></strong><small></small></span><span class="badge"></span>`;
          button.querySelector('.customer-result-avatar').textContent = (customer.name || '客').slice(0, 1);
          button.querySelector('strong').textContent = customer.name || '未命名顾客';
          button.querySelector('small').textContent = customer.phone || '无电话号码';
          const badge = button.querySelector('.badge');
          badge.classList.add(customer.member_number ? 'badge-gold' : 'badge-gray');
          badge.textContent = customer.member_number ? `${customer.member_level || ''} 会员` : '已有非会员';
          button.addEventListener('click', () => selectCustomer(customer));
          resultBox.appendChild(button);
        });
        resultBox.hidden = false;
      }
      function renderMessage(message) {
        resultBox.replaceChildren();
        const empty = document.createElement('div');
        empty.className = 'customer-empty';
        empty.textContent = message;
        resultBox.appendChild(empty);
        resultBox.hidden = false;
      }
      function selectCustomer(customer) {
        selectedCustomer = customer;
        hiddenId.value = String(customer.id);
        input.value = customer.name || customer.phone || '';
        nameInput.value = customer.name || '';
        phoneInput.value = customer.phone || '';
        nameInput.readOnly = true;
        phoneInput.readOnly = true;
        syncGuestExtra();
        resultBox.hidden = true;
        selectedBox.querySelector('[data-selected-initial]').textContent = (customer.name || '客').slice(0, 1);
        selectedBox.querySelector('[data-selected-name]').textContent = customer.name || '未命名顾客';
        selectedBox.querySelector('[data-selected-meta]').textContent = customer.member_number ? `${customer.phone} · ${customer.member_level || ''} 会员 · ${customer.member_number}` : `${customer.phone} · 已有非会员顾客`;
        selectedBox.hidden = false;
        scheduleDraftSave();
      }
      form.setSelectedCustomer = selectCustomer;
      form.setGuestCustomer = (customer = {}) => {
        setManualMode(false);
        input.value = '';
        nameInput.value = customer.name || '';
        phoneInput.value = customer.phone || '';
      };
    }

    function setupStylistAvailability() {
      const appointmentInput = form.querySelector('[data-appointment-input]');
      const visitId = form.querySelector('input[name="visit_id"]')?.value || '';
      let controller = null;
      let refreshTimer = null;
      let lastPayload = { common: [], by_service: {}, assistant_pool: [] };

      const selectedServiceIds = () => [...new Set(
        [...(serviceRows?.querySelectorAll('.service-select') || [])]
          .map((select) => String(select.value || '').trim())
          .filter(Boolean)
      )];

      const replaceOptions = (select, rows, mode = 'lead') => {
        if (!select) return;
        rows = Array.isArray(rows) ? rows : [];
        const current = String(select.value || '');
        const first = document.createElement('option');
        first.value = '';
        if (mode === 'preferred') first.textContent = rows.length ? '请选择理发师' : '目前没有符合技能且有空的理发师';
        else if (mode === 'assistant') first.textContent = rows.length ? '请选择员工' : '目前没有有空的协助员工';
        else if (mode === 'co') first.textContent = rows.length ? '请选择理发师' : '目前没有符合技能且有空的理发师';
        else first.textContent = rows.length ? '由系统智能建议' : '目前没有符合技能且有空的理发师';
        const fragment = document.createDocumentFragment();
        fragment.appendChild(first);
        rows.forEach((employee) => {
          const option = document.createElement('option');
          option.value = String(employee.id || '');
          option.textContent = `${employee.name || '员工'} · ${employee.position || '员工'}${employee.availability_reason ? ` · ${employee.availability_reason}` : ''}`;
          fragment.appendChild(option);
        });
        select.replaceChildren(fragment);
        if (current && rows.some((employee) => String(employee.id) === current)) select.value = current;
        else if (current) select.value = '';
      };

      const applyPayload = (payload) => {
        if (Array.isArray(payload)) payload = { common: payload, by_service: {}, assistant_pool: payload };
        lastPayload = payload && typeof payload === 'object' ? payload : { common: [], by_service: {}, assistant_pool: [] };
        const common = Array.isArray(lastPayload.common) ? lastPayload.common : [];
        const byService = lastPayload.by_service && typeof lastPayload.by_service === 'object' ? lastPayload.by_service : {};
        const assistants = Array.isArray(lastPayload.assistant_pool) ? lastPayload.assistant_pool : [];

        replaceOptions(form.querySelector('.appointment-preferred-select'), common, 'preferred');
        serviceRows?.querySelectorAll('.service-row').forEach((row) => {
          const sid = String(row.querySelector('.service-select')?.value || '');
          const eligible = Array.isArray(byService[sid]) ? byService[sid] : common;
          replaceOptions(row.querySelector('.lead-select'), eligible, 'lead');
          row.querySelectorAll('[data-worker-role="co_stylist"]').forEach((select) => replaceOptions(select, eligible, 'co'));
          row.querySelectorAll('[data-worker-role="assistant"]').forEach((select) => replaceOptions(select, assistants, 'assistant'));
        });
      };

      const refresh = async () => {
        const visitType = form.querySelector('input[name="visit_type"]:checked')?.value || 'walk_in';
        const appointmentAt = appointmentInput?.value || '';
        if (visitType === 'appointment' && !appointmentAt) return;
        controller?.abort();
        controller = new AbortController();
        const params = new URLSearchParams({
          action: 'available_stylists',
          visit_type: visitType,
          service_ids: selectedServiceIds().join(','),
        });
        if (appointmentAt) params.set('appointment_at', appointmentAt);
        if (visitId) params.set('visit_id', visitId);
        try {
          const response = await fetch(`index.php?${params.toString()}`, { credentials: 'same-origin', signal: controller.signal, cache:'no-store' });
          const payload = await response.json();
          if (!response.ok || payload?.ok === false) throw new Error(payload?.error || 'availability failed');
          applyPayload(payload);
        } catch (error) {
          if (error.name !== 'AbortError') console.warn('Unable to refresh stylist availability', error);
        }
      };

      const scheduleRefresh = () => {
        clearTimeout(refreshTimer);
        refreshTimer = setTimeout(refresh, 100);
      };

      form.querySelectorAll('input[name="visit_type"],input[name="appointment_assignment_type"]').forEach((radio) => radio.addEventListener('change', scheduleRefresh));
      appointmentInput?.addEventListener('change', scheduleRefresh);
      appointmentInput?.addEventListener('input', scheduleRefresh);
      serviceRows?.addEventListener('change', (event) => {
        if (event.target.closest('.service-select')) scheduleRefresh();
      });
      serviceRows?.addEventListener('click', (event) => {
        if (event.target.closest('[data-add-worker]')) setTimeout(() => applyPayload(lastPayload), 0);
      });
      form.querySelector('[data-add-service]')?.addEventListener('click', () => setTimeout(() => { applyPayload(lastPayload); scheduleRefresh(); }, 0));
      refresh();
    }

    function setupDraftRecovery() {
      const draft = safeJsonParse(localStorage.getItem(draftKey), null);
      const isFresh = draft?.savedAt && Date.now() - Number(draft.savedAt) < 14 * 24 * 60 * 60 * 1000;
      if (draft && isFresh && recovery) {
        recovery.hidden = false;
        if (recoveryTime) recoveryTime.textContent = `上次保存：${formatSavedTime(draft.savedAt)} · 可恢复顾客、同行者、项目与工作人员`;
      } else if (draft) localStorage.removeItem(draftKey);

      recovery?.querySelector('[data-restore-draft]')?.addEventListener('click', () => {
        const saved = safeJsonParse(localStorage.getItem(draftKey), null);
        if (!saved) return;
        suppressSave = true;
        restoreDraft(saved);
        suppressSave = false;
        recovery.hidden = true;
        setDraftStatus('草稿已恢复');
        scheduleDraftSave();
      });
      recovery?.querySelector('[data-discard-draft]')?.addEventListener('click', () => {
        localStorage.removeItem(draftKey);
        recovery.hidden = true;
        setDraftStatus(form.dataset.editing === '1' ? '修改草稿' : '新订单草稿');
      });
    }

    function collectDraft() {
      return {
        schema: 3,
        requestId: form.elements.namedItem('order_request_id')?.value || '',
        savedAt: Date.now(),
        currentStep,
        visitType: form.querySelector('input[name="visit_type"]:checked')?.value || 'walk_in',
        appointmentAt: form.querySelector('[data-appointment-input]')?.value || '',
        appointmentAssignmentType: form.querySelector('input[name="appointment_assignment_type"]:checked')?.value || 'system',
        appointmentEmployeeId: form.querySelector('.appointment-preferred-select')?.value || '',
        assignmentType: form.querySelector('input[name="assignment_type"]:checked')?.value || 'specified',
        customer: selectedCustomer || {
          id: form.querySelector('#customer-id')?.value || '',
          name: form.querySelector('#visit-customer-name')?.value || '',
          phone: form.querySelector('#visit-customer-phone')?.value || '',
          gender: form.querySelector('[name="customer_gender"]')?.value || 'unspecified',
          ethnicity: form.querySelector('[name="customer_ethnicity"]')?.value || '',
          age: form.querySelector('[name="customer_age"]')?.value || '',
          birthDate: form.querySelector('[name="customer_birth_date"]')?.value || '',
          member_number: null,
          member_level: null
        },
        recipients: [...form.querySelectorAll('[data-recipient-row]')].map((row) => ({
          key: row.querySelector('[data-recipient-field="key"]')?.value || '',
          name: row.querySelector('[data-recipient-field="name"]')?.value || '',
          relationship: row.querySelector('[data-recipient-field="relationship"]')?.value || '同行者',
          age: row.querySelector('[data-recipient-field="age"]')?.value || ''
        })),
        items: [...form.querySelectorAll('.service-row')].map((row) => ({
          categoryId: row.querySelector('.service-category-select')?.value || '',
          serviceId: row.querySelector('.service-select')?.value || '',
          recipientKey: row.querySelector('.recipient-select')?.value || 'self',
          price: row.querySelector('.price-input')?.value || '0',
          leadId: row.querySelector('.lead-select')?.value || '',
          leadContribution: row.querySelector('[data-lead-contribution]')?.value || '100',
          coStylists: [...row.querySelectorAll('[data-worker-role="co_stylist"]')].map((select) => ({
            id: select.value,
            pct: select.closest('[data-worker-row]')?.querySelector('[data-worker-contribution]')?.value || '0'
          })),
          assistants: [...row.querySelectorAll('[data-worker-role="assistant"]')].map((select) => ({
            id: select.value,
            pct: select.closest('[data-worker-row]')?.querySelector('[data-worker-contribution]')?.value || '0'
          }))
        }))
      };
    }

    function restoreDraft(draft) {
      const request = form.elements.namedItem('order_request_id');
      if (request && /^[0-9a-f-]{36}$/i.test(draft.requestId || '')) request.value = draft.requestId;
      const visitRadio = form.querySelector(`input[name="visit_type"][value="${cssEscape(draft.visitType || 'walk_in')}"]`);
      const assignmentRadio = form.querySelector(`input[name="assignment_type"][value="${cssEscape(draft.assignmentType || 'specified')}"]`);
      const appointmentAssignmentRadio = form.querySelector(`input[name="appointment_assignment_type"][value="${cssEscape(draft.appointmentAssignmentType || 'system')}"]`);
      if (visitRadio) visitRadio.checked = true;
      if (assignmentRadio) assignmentRadio.checked = true;
      if (appointmentAssignmentRadio) appointmentAssignmentRadio.checked = true;
      const appointmentInput = form.querySelector('[data-appointment-input]');
      const appointmentEmployee = form.querySelector('.appointment-preferred-select');
      if (appointmentInput) appointmentInput.value = draft.appointmentAt || appointmentInput.value || '';
      if (appointmentEmployee) appointmentEmployee.value = draft.appointmentEmployeeId || '';
      form.querySelector('input[name="visit_type"]:checked')?.dispatchEvent(new Event('change',{bubbles:true}));
      if (draft.customer?.id && form.setSelectedCustomer) form.setSelectedCustomer(draft.customer);
      else if (draft.customer && form.setGuestCustomer) {
        form.setGuestCustomer(draft.customer);
        const gender = form.querySelector('[name="customer_gender"]'); if (gender) gender.value = draft.customer.gender || 'unspecified';
        const ethnicity = form.querySelector('[name="customer_ethnicity"]'); if (ethnicity) ethnicity.value = draft.customer.ethnicity || '';
        const age = form.querySelector('[name="customer_age"]'); if (age) age.value = draft.customer.age || '';
        const birthDate = form.querySelector('[name="customer_birth_date"]'); if (birthDate) birthDate.value = draft.customer.birthDate || '';
      }

      recipientRows?.replaceChildren();
      (draft.recipients || []).forEach((recipient) => {
        recipientRows.appendChild(recipientTemplate.content.cloneNode(true));
        const row = recipientRows.lastElementChild;
        row.querySelector('[data-recipient-field="key"]').value = recipient.key || '';
        row.querySelector('[data-recipient-field="name"]').value = recipient.name || '';
        row.querySelector('[data-recipient-field="relationship"]').value = recipient.relationship || '同行者';
        row.querySelector('[data-recipient-field="age"]').value = recipient.age || '';
      });
      syncRecipients();

      serviceRows?.replaceChildren();
      const items = draft.items?.length ? draft.items : [{}];
      items.forEach((item) => {
        serviceRows.appendChild(serviceTemplate.content.cloneNode(true));
        const row = serviceRows.lastElementChild;
        const serviceSelect = row.querySelector('.service-select');
        const categorySelect = row.querySelector('.service-category-select');
        let categoryId = item.categoryId || '';
        if (!categoryId && item.serviceId && serviceSelect) {
          const option = [...serviceSelect.options].find((opt) => opt.value === item.serviceId);
          categoryId = option?.dataset.categoryId || '';
        }
        if (categorySelect) categorySelect.value = categoryId;
        if (categorySelect) categorySelect.dispatchEvent(new Event('change',{bubbles:true}));
        if (serviceSelect) serviceSelect.value = item.serviceId || '';
        row.querySelector('.price-input').value = item.price || '0';
        syncRecipients();
        row.querySelector('.recipient-select').value = item.recipientKey || 'self';
        row.querySelector('.lead-select').value = item.leadId || '';
        const leadContribution = row.querySelector('[data-lead-contribution]');
        if (leadContribution) { leadContribution.value = item.leadContribution || '100'; leadContribution.dataset.manual = '1'; }
        addRestoredWorkers(row, 'co_stylist', item.coStylists || []);
        addRestoredWorkers(row, 'assistant', item.assistants || []);
      });
      syncAll();
      form.goToVisitStep?.(Math.max(1, Math.min(3, Number(draft.currentStep || 1))));
    }

    function addRestoredWorkers(row, role, workers) {
      const list = row.querySelector(`[data-worker-list="${role}"]`);
      const template = row.querySelector(`template[data-worker-template="${role}"]`);
      (workers || []).map((worker) => typeof worker === 'object' ? worker : ({ id: worker, pct: '' })).filter((worker) => worker.id).forEach((worker) => {
        list.appendChild(template.content.cloneNode(true));
        const restoredRow = list.lastElementChild;
        restoredRow.querySelector('select').value = String(worker.id);
        const share = restoredRow.querySelector('[data-worker-contribution]');
        if (share) { share.value = String(worker.pct ?? '0'); share.dataset.manual = '1'; }
      });
    }

    function scheduleDraftSave() {
      if (suppressSave) return;
      setDraftStatus('正在自动保存…');
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => saveDraft(false), 480);
    }

    function saveDraft(immediate) {
      if (suppressSave) return;
      if (!immediate && document.visibilityState === 'hidden') return;
      try {
        const draft = collectDraft();
        localStorage.setItem(draftKey, JSON.stringify(draft));
        setDraftStatus(`已自动保存 ${new Date(draft.savedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`);
      } catch (error) {
        setDraftStatus('自动保存失败');
      }
    }

    function setDraftStatus(text) { if (draftStatus) draftStatus.textContent = text; }
  }


  function setupCommissionAllocation(root = document) {
    root.querySelectorAll('[data-commission-form]').forEach((form) => {
      if (form.dataset.boundCommission === '1') return;
      form.dataset.boundCommission = '1';
      const items = [...form.querySelectorAll('[data-allocation-item]')];
      const grandTotal = form.closest('[data-commission-modal-content], .commission-modal-inner, main')?.querySelector('[data-commission-grand-total]') || document.querySelector('[data-commission-grand-total]');
      const moneyText = (value) => `RM ${Number(value || 0).toFixed(2)}`;

      const syncOverrideRow = (row) => {
        const checkbox = row.querySelector('[data-rate-override]');
        const rateInput = row.querySelector('[data-commission-rate]');
        if (!checkbox || !rateInput) return;
        rateInput.disabled = !checkbox.checked;
        if (!checkbox.checked) rateInput.value = Number(rateInput.dataset.autoRate || 0).toFixed(2);
        row.classList.toggle('has-rate-override', checkbox.checked);
      };

      const systemShares = (item) => {
        const rows = [...item.querySelectorAll('[data-allocation-worker]')];
        const lead = rows.filter((row) => row.dataset.role === 'lead');
        const co = rows.filter((row) => row.dataset.role === 'co_stylist');
        const assistants = rows.filter((row) => row.dataset.role === 'assistant');
        let leadPool = 100, coPool = 0, assistantPool = 0;
        if (co.length && assistants.length) { leadPool = 60; coPool = 25; assistantPool = 15; }
        else if (co.length) { leadPool = 75; coPool = 25; }
        else if (assistants.length) { leadPool = 80; assistantPool = 20; }
        const apply = (group, pool) => group.forEach((row, index) => {
          const input = row.querySelector('[data-share-input]');
          if (!input) return;
          const even = pool / Math.max(1, group.length);
          input.value = index === group.length - 1 ? (pool - even * (group.length - 1)).toFixed(2) : even.toFixed(2);
        });
        apply(lead, leadPool); apply(co, coPool); apply(assistants, assistantPool);
      };

      const equalShares = (item) => {
        const rows = [...item.querySelectorAll('[data-allocation-worker]')];
        const even = 100 / Math.max(1, rows.length);
        rows.forEach((row, index) => {
          const input = row.querySelector('[data-share-input]');
          if (!input) return;
          input.value = index === rows.length - 1 ? (100 - even * (rows.length - 1)).toFixed(2) : even.toFixed(2);
        });
      };

      const recalculate = () => {
        let overallCommission = 0;
        let allValid = true;
        items.forEach((item) => {
          const price = Number(item.dataset.price || 0);
          const rows = [...item.querySelectorAll('[data-allocation-worker]')];
          let sum = 0;
          let itemCommission = 0;
          rows.forEach((row) => {
            syncOverrideRow(row);
            const shareInput = row.querySelector('[data-share-input]');
            const rateInput = row.querySelector('[data-commission-rate]');
            const share = Math.max(0, Math.min(100, Number(shareInput?.value || 0)));
            const rate = Math.max(0, Math.min(100, Number(rateInput?.value || 0)));
            const contribution = price * share / 100;
            const commission = contribution * rate / 100;
            sum += share;
            itemCommission += commission;
            row.querySelector('[data-contribution-amount]')?.replaceChildren(document.createTextNode(moneyText(contribution)));
            row.querySelector('[data-commission-amount]')?.replaceChildren(document.createTextNode(moneyText(commission)));
          });
          const valid = Math.abs(sum - 100) < 0.011;
          allValid = allValid && valid;
          item.classList.toggle('allocation-invalid', !valid);
          const sumNode = item.querySelector('[data-allocation-sum]');
          const message = item.querySelector('[data-allocation-message]');
          const itemTotal = item.querySelector('[data-item-commission]');
          if (sumNode) sumNode.textContent = `${sum.toFixed(2)}%`;
          if (message) message.textContent = valid ? '分配正确' : `还差 ${(100 - sum).toFixed(2)}%`;
          if (itemTotal) itemTotal.textContent = moneyText(itemCommission);
          overallCommission += itemCommission;
        });
        if (grandTotal) grandTotal.textContent = moneyText(overallCommission);
        const submit = form.querySelector('[data-save-allocation]');
        if (submit) submit.disabled = !allValid;
        return allValid;
      };

      form.addEventListener('input', recalculate);
      form.addEventListener('change', (event) => {
        const row = event.target.closest('[data-allocation-worker]');
        if (row) syncOverrideRow(row);
        recalculate();
      });
      form.addEventListener('click', (event) => {
        const system = event.target.closest('[data-allocation-system]');
        const equal = event.target.closest('[data-allocation-equal]');
        const item = event.target.closest('[data-allocation-item]');
        if (!item || (!system && !equal)) return;
        if (system) systemShares(item); else equalShares(item);
        recalculate();
      });
      form.addEventListener('submit', async (event) => {
        if (!recalculate()) {
          event.preventDefault();
          form.querySelector('.allocation-invalid')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
          showToast('每个项目的负责占比合计都必须刚好是 100%。', 'error');
          return;
        }
        if (form.dataset.ajaxCommission !== '1') return;
        event.preventDefault();
        const button = form.querySelector('[data-save-allocation]');
        const status = form.querySelector('[data-commission-modal-status]');
        if (button) { button.disabled = true; button.textContent = '保存中…'; }
        if (status) status.textContent = '正在保存分配资料…';
        try {
          const response = await fetch(form.action || 'index.php', { method: 'POST', body: new FormData(form), credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
          const data = await response.json();
          if (!response.ok || !data.success) throw new Error(data.message || '保存失败');
          const row = document.querySelector(`[data-commission-order-row="${data.visit_id}"]`);
          if (row) {
            const total = row.querySelector('[data-order-commission-total]');
            const badge = row.querySelector('[data-order-commission-status]');
            if (total) total.textContent = data.commission_total_text;
            if (badge) { badge.textContent = '已调负责占比'; badge.className = 'badge badge-green'; }
          }
          showToast(data.message || '抽成分配已经保存。', 'success');
          window.closeCommissionModal?.();
        } catch (error) {
          if (status) status.textContent = error.message || '保存失败，请重试。';
          showToast(error.message || '保存失败，请重试。', 'error');
          if (button) { button.disabled = false; button.textContent = '保存分配 →'; }
        }
      });
      items.forEach((item) => item.querySelectorAll('[data-allocation-worker]').forEach(syncOverrideRow));
      recalculate();
    });
  }

  function setupCommissionModal() {
    const modal = document.querySelector('[data-commission-modal]');
    if (!modal) return;
    const content = modal.querySelector('[data-commission-modal-content]');
    const loading = modal.querySelector('[data-commission-modal-loading]');
    let controller = null;

    window.closeCommissionModal = () => {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden','true');
      document.body.classList.remove('commission-modal-open');
      controller?.abort();
      setTimeout(() => { modal.hidden = true; if (content) content.innerHTML = ''; }, 220);
    };

    const openModal = async (visitId) => {
      controller?.abort();
      controller = new AbortController();
      modal.hidden = false;
      modal.setAttribute('aria-hidden','false');
      document.body.classList.add('commission-modal-open');
      if (content) content.innerHTML = '';
      if (loading) loading.hidden = false;
      requestAnimationFrame(() => modal.classList.add('is-open'));
      try {
        const response = await fetch(`index.php?action=commission_modal&id=${encodeURIComponent(visitId)}`, { credentials: 'same-origin', signal: controller.signal });
        const html = await response.text();
        if (!response.ok) throw new Error('无法载入订单抽成资料。');
        if (content) content.innerHTML = html;
        if (loading) loading.hidden = true;
        setupCommissionAllocation(content || modal);
      } catch (error) {
        if (error.name === 'AbortError') return;
        if (loading) loading.hidden = true;
        if (content) content.innerHTML = `<div class="commission-modal-error"><strong>载入失败</strong><span>${escapeHtml(error.message || '请稍后重试。')}</span><button class="btn btn-light" type="button" data-commission-modal-close>关闭</button></div>`;
      }
    };

    document.addEventListener('click', (event) => {
      const opener = event.target.closest('[data-commission-open]');
      if (opener) {
        event.preventDefault();
        openModal(opener.dataset.visitId);
        return;
      }
      if (event.target.closest('[data-commission-modal-close]')) window.closeCommissionModal();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !modal.hidden) { window.closeCommissionModal(); return; }
      if ((event.key === 'Enter' || event.key === ' ') && event.target.matches('[data-commission-order-row][data-commission-open]')) {
        event.preventDefault();
        openModal(event.target.dataset.visitId);
      }
    });
  }

  function setupCommissionTierEditor() {
    const editor = document.querySelector('[data-commission-tier-editor]');
    if (!editor) return;
    const list = editor.querySelector('[data-tier-list]');
    const template = editor.querySelector('[data-tier-template]');
    const renumber = () => {
      [...list.querySelectorAll('[data-tier-row]')].forEach((row,index) => {
        const number = row.querySelector('.tier-index');
        if (number) number.textContent = String(index+1).padStart(2,'0');
        row.querySelectorAll('[data-name]').forEach((input) => { input.name = `tiers[${index}][${input.dataset.name}]`; });
      });
    };
    editor.querySelector('[data-add-tier]')?.addEventListener('click', () => {
      const fragment = template.content.cloneNode(true);
      list.appendChild(fragment);
      renumber();
      list.lastElementChild?.scrollIntoView({ behavior:'smooth', block:'center' });
    });
    editor.addEventListener('click', (event) => {
      const remove = event.target.closest('[data-remove-tier]');
      if (!remove) return;
      const rows = list.querySelectorAll('[data-tier-row]');
      if (rows.length <= 1) { showToast('至少要保留一个抽成等级。','error'); return; }
      remove.closest('[data-tier-row]')?.remove();
      renumber();
    });
    document.querySelectorAll('[data-clear-rate]').forEach((button) => button.addEventListener('click', () => {
      const input = button.closest('.manual-rate-input')?.querySelector('[data-employee-rate-input]');
      if (input) input.value = '';
    }));
    renumber();
  }

  function setupMemberModal() {
    const modal = document.querySelector('[data-member-modal]');
    if (!modal) return;
    const content = modal.querySelector('[data-member-modal-content]');
    const loading = modal.querySelector('[data-member-modal-loading]');
    let controller = null;
    const close = () => {
      modal.classList.remove('is-open'); modal.setAttribute('aria-hidden','true'); document.body.classList.remove('commission-modal-open'); controller?.abort();
      setTimeout(() => { modal.hidden = true; if (content) content.innerHTML=''; },220);
    };
    const bindForms = () => {
      content?.querySelectorAll('[data-member-ajax-form]').forEach((form) => form.addEventListener('submit', async (event) => {
        if (event.defaultPrevented) return;
        event.preventDefault(); const button=form.querySelector('button[type="submit"],button:not([type])'); const old=button?.textContent;
        if(button){button.disabled=true;button.textContent='处理中…';}
        try { const response=await fetch('index.php',{method:'POST',body:new FormData(form),credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}}); const raw=await response.text(); let data; try{data=JSON.parse(raw);}catch{throw new Error('服务器没有返回 JSON，请刷新后重试。');} if(!response.ok||!data.success) throw new Error(data.message||'操作失败'); showToast(data.message,'success'); close(); setTimeout(()=>location.reload(),250); }
        catch(error){showToast(error.message||'操作失败','error'); if(button){button.disabled=false;button.textContent=old;}}
      }));
    };
    const open = async (id) => {
      controller?.abort(); controller=new AbortController(); modal.hidden=false; modal.setAttribute('aria-hidden','false'); document.body.classList.add('commission-modal-open'); if(content)content.innerHTML=''; if(loading)loading.hidden=false; requestAnimationFrame(()=>modal.classList.add('is-open'));
      try { const response=await fetch(`index.php?action=member_modal&id=${encodeURIComponent(id)}`,{credentials:'same-origin',signal:controller.signal}); const html=await response.text(); if(!response.ok)throw new Error('无法载入会员资料'); if(content)content.innerHTML=html; if(loading)loading.hidden=true; initProductSearchForms(content || document); bindForms(); }
      catch(error){ if(error.name==='AbortError')return; if(loading)loading.hidden=true; if(content)content.innerHTML=`<div class="commission-modal-error"><strong>载入失败</strong><span>${escapeHtml(error.message)}</span><button class="btn btn-light" type="button" data-member-modal-close>关闭</button></div>`; }
    };
    document.addEventListener('click',(event)=>{ const opener=event.target.closest('[data-member-open]'); if(opener){event.preventDefault();event.stopPropagation();open(opener.dataset.customerId||opener.closest('[data-customer-id]')?.dataset.customerId);return;} if(event.target.closest('[data-member-modal-close]'))close(); });
    document.addEventListener('keydown',(event)=>{ if(event.key==='Escape'&&!modal.hidden)close(); if((event.key==='Enter'||event.key===' ')&&event.target.matches('[data-member-open][data-customer-id]')){event.preventDefault();open(event.target.dataset.customerId);} });
  }

  function setupCheckoutModal() {
    const modal=document.querySelector('[data-checkout-modal]'); if(!modal)return;
    const content=modal.querySelector('[data-checkout-modal-content]'); const loading=modal.querySelector('[data-checkout-modal-loading]'); let controller=null;
    const close=()=>{modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('commission-modal-open');controller?.abort();setTimeout(()=>{modal.hidden=true;if(content)content.innerHTML='';},220);};
    const bind=()=>{ const calculator=content?.querySelector('[data-checkout-calculator]'); const form=content?.querySelector('[data-checkout-form]'); if(!calculator||!form)return; const total=Number(calculator.dataset.total||0); const walletMax=Number(calculator.dataset.wallet||0); const wallet=form.querySelector('[data-wallet-payment]'); const other=form.querySelector('[data-other-payment]'); const sync=()=>{let w=Math.max(0,Math.min(Number(wallet?.value||0),walletMax,total)); if(wallet)wallet.value=w.toFixed(2); if(other)other.value=Math.max(0,total-w).toFixed(2);}; wallet?.addEventListener('input',sync); sync(); form.addEventListener('submit',async(event)=>{event.preventDefault();const button=form.querySelector('button[type="submit"],button:not([type])');const old=button?.textContent;if(button){button.disabled=true;button.textContent='结账中…';}try{const response=await fetch('index.php',{method:'POST',body:new FormData(form),credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}});const data=await response.json();if(!response.ok||!data.success)throw new Error(data.message||'结账失败');showToast(data.message,'success');close();setTimeout(()=>location.reload(),300);}catch(error){showToast(error.message||'结账失败','error');if(button){button.disabled=false;button.textContent=old;}}}); };
    const open=async(id)=>{controller?.abort();controller=new AbortController();modal.hidden=false;modal.setAttribute('aria-hidden','false');document.body.classList.add('commission-modal-open');if(content)content.innerHTML='';if(loading)loading.hidden=false;requestAnimationFrame(()=>modal.classList.add('is-open'));try{const boardDate=new URL(window.location.href).searchParams.get('board_date')||'';const checkoutUrl=`index.php?action=checkout_modal&id=${encodeURIComponent(id)}${boardDate?`&board_date=${encodeURIComponent(boardDate)}`:''}`;const response=await fetch(checkoutUrl,{credentials:'same-origin',signal:controller.signal});const html=await response.text();if(!response.ok)throw new Error('无法载入结账资料');if(content){content.innerHTML=html;content.scrollTop=0;}if(loading)loading.hidden=true;initProductSearchForms(content || document);bind();}catch(error){if(error.name==='AbortError')return;if(loading)loading.hidden=true;if(content)content.innerHTML=`<div class="commission-modal-error"><strong>载入失败</strong><span>${escapeHtml(error.message)}</span><button class="btn btn-light" type="button" data-checkout-modal-close>关闭</button></div>`;}};
    document.addEventListener('click',(event)=>{const opener=event.target.closest('[data-checkout-open]');if(opener){event.preventDefault();open(opener.dataset.visitId);return;}if(event.target.closest('[data-checkout-modal-close]'))close();}); document.addEventListener('keydown',(event)=>{if(event.key==='Escape'&&!modal.hidden)close();});
  }

  function setupServiceBoardModal() {
    const modal = document.querySelector('[data-service-board-modal]');
    if (!modal) return;
    const content = modal.querySelector('[data-service-board-modal-content]');
    const loading = modal.querySelector('[data-service-board-modal-loading]');

    const close = () => {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('commission-modal-open');
      setTimeout(() => {
        modal.hidden = true;
        if (content) content.innerHTML = '';
      }, 220);
    };

    document.addEventListener('click', async (event) => {
      const trigger = event.target.closest('[data-service-board-open]');
      if (trigger) {
        event.preventDefault();
        const visitId = trigger.dataset.visitId;
        if (!visitId || !content) return;
        modal.hidden = false;
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('commission-modal-open');
        if (loading) loading.hidden = false;
        content.innerHTML = '';
        requestAnimationFrame(() => modal.classList.add('is-open'));
        try {
          const currentBoardDate = new URL(window.location.href).searchParams.get('board_date') || '';
          const modalUrl = `index.php?action=service_board_modal&id=${encodeURIComponent(visitId)}${currentBoardDate ? `&board_date=${encodeURIComponent(currentBoardDate)}` : ''}`;
          const response = await fetch(`${modalUrl}&t=${Date.now()}`, { credentials: 'same-origin', cache:'no-store' });
          const html = await response.text();
          content.innerHTML = html;
          // v13.5.9: order add-on products use the category-first v13.5.3 search UI.
          // The modal is loaded dynamically, so initialize it after injecting the HTML.
          if (typeof window.SalonOSInitV1353ProductSearch === 'function') {
            window.SalonOSInitV1353ProductSearch(content);
          } else {
            initProductSearchForms(content);
          }
        } catch (error) {
          content.innerHTML = '<div class="commission-modal-error"><strong>无法打开预约详情</strong><span>请稍后再试。</span></div>';
        } finally {
          if (loading) loading.hidden = true;
        }
      }

      if (event.target.closest('[data-service-board-modal-close]')) {
        close();
      }

      if (event.target.closest('[data-service-board-launch-checkout]')) {
        close();
      }
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !modal.hidden) close();
    });
  }

  function setupOrderMaterialModal() {
    const modal = document.querySelector('[data-order-material-modal]');
    if (!modal) return;
    const content = modal.querySelector('[data-order-material-modal-content]');
    const loading = modal.querySelector('[data-order-material-modal-loading]');
    let controller = null;
    let currentVisitId = '';

    const close = () => {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('commission-modal-open');
      controller?.abort();
      const needsRefresh = modal.dataset.needsRefresh === '1';
      setTimeout(() => {
        modal.hidden = true;
        if (content) content.innerHTML = '';
        modal.dataset.needsRefresh = '0';
        if (needsRefresh) window.location.reload();
      }, 220);
    };

    const bindContent = () => {
      const root = content?.querySelector('[data-order-material-modal-inner]');
      if (!root) return;
      const form = root.querySelector('[data-material-consume-form]');
      const search = root.querySelector('[data-material-search]');
      const results = root.querySelector('[data-material-search-results]');
      const hiddenId = root.querySelector('[data-material-inventory-id]');
      const selected = root.querySelector('[data-material-selected]');
      const selectedName = root.querySelector('[data-material-selected-name]');
      const selectedMeta = root.querySelector('[data-material-selected-meta]');
      const selectedStock = root.querySelector('[data-material-selected-stock]');
      const quantity = root.querySelector('[data-material-quantity]');
      const unit = root.querySelector('[data-material-unit]');
      const submit = root.querySelector('[data-material-submit]');
      let searchController = null;
      const materialSearchCache = new Map();

      const clearSelection = () => {
        if (hiddenId) hiddenId.value = '';
        if (selected) selected.hidden = true;
        if (quantity) { quantity.value = ''; quantity.disabled = true; quantity.removeAttribute('max'); }
        if (unit) unit.textContent = '单位';
        if (submit) submit.disabled = true;
      };

      const selectMaterial = (button) => {
        const stock = Number(button.dataset.stock || 0);
        if (hiddenId) hiddenId.value = button.dataset.id || '';
        if (selectedName) selectedName.textContent = button.dataset.name || '库存材料';
        if (selectedMeta) selectedMeta.textContent = `${button.dataset.sku || ''} · ${button.dataset.category || '其他'} · ${button.dataset.typeLabel || ''}`;
        if (selectedStock) selectedStock.textContent = `${button.dataset.stockText || stock} `;
        if (unit) unit.textContent = button.dataset.unit || '件';
        if (selected) selected.hidden = false;
        if (quantity) {
          quantity.disabled = stock <= 0;
          quantity.max = String(stock);
          quantity.value = stock > 0 ? '1' : '';
          quantity.focus();
        }
        if (submit) submit.disabled = stock <= 0;
        if (results) { results.hidden = true; results.innerHTML = ''; }
      };

      const renderResults = (rows) => {
        if (!results) return;
        if (!rows.length) {
          results.innerHTML = '<div class="material-search-empty">没有找到库存材料，检查名称、SKU 或分类。</div>';
          results.hidden = false;
          return;
        }
        results.innerHTML = rows.map((row) => {
          const disabled = Number(row.stock_quantity || 0) <= 0;
          return `<button type="button" class="material-search-result ${disabled ? 'is-out' : ''}" data-material-result
            data-id="${escapeHtml(row.id)}" data-name="${escapeHtml(row.name)}" data-sku="${escapeHtml(row.sku)}"
            data-category="${escapeHtml(row.category || '')}" data-type-label="${escapeHtml(row.type_label || '')}"
            data-unit="${escapeHtml(row.unit)}" data-stock="${escapeHtml(row.stock_quantity)}" data-stock-text="${escapeHtml(row.stock_text)}" ${disabled ? 'disabled' : ''}>
            <span class="material-result-icon">${row.image_url ? `<img src="${escapeHtml(row.image_url)}" alt="">` : escapeHtml(String(row.name || '').slice(0,1))}</span>
            <span><strong>${escapeHtml(row.name)}</strong><small>${escapeHtml(row.sku)} · ${escapeHtml(row.category || '其他')} · ${escapeHtml(row.type_label || '')}</small></span>
            <span class="material-result-stock"><small>库存</small><strong>${escapeHtml(row.stock_text)}</strong></span>
          </button>`;
        }).join('');
        results.hidden = false;
      };

      const runSearch = debounce(async () => {
        const query = search?.value.trim() || '';
        if (query.length < 1) { if (results) { results.hidden = true; results.innerHTML = ''; } return; }
        searchController?.abort();
        searchController = new AbortController();
        try {
          const cacheKey=query.toLocaleLowerCase();
          if(materialSearchCache.has(cacheKey)){renderResults(materialSearchCache.get(cacheKey));return;}
          const response = await fetch(`index.php?action=search_inventory_materials&q=${encodeURIComponent(query)}`, { credentials: 'same-origin', signal: searchController.signal });
          const rows = await response.json();
          materialSearchCache.set(cacheKey,rows);
          if (!response.ok) throw new Error('无法搜索库存');
          renderResults(rows);
        } catch (error) {
          if (error.name === 'AbortError') return;
          if (results) { results.innerHTML = `<div class="material-search-empty">${escapeHtml(error.message || '搜索失败')}</div>`; results.hidden = false; }
        }
      }, 90);

      search?.addEventListener('input', runSearch);
      results?.addEventListener('click', (event) => {
        const button = event.target.closest('[data-material-result]');
        if (button && !button.disabled) selectMaterial(button);
      });
      root.querySelector('[data-material-clear]')?.addEventListener('click', () => {
        clearSelection();
        if (search) { search.value = ''; search.focus(); }
      });

      form?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const button = form.querySelector('[data-material-submit]');
        const original = button?.innerHTML;
        try {
          if (!hiddenId?.value) throw new Error('请先搜索并选择库存材料。');
          if (button) { button.disabled = true; button.innerHTML = '正在扣库存…'; }
          const response = await fetch('index.php', { method: 'POST', body: new FormData(form), credentials: 'same-origin' });
          const payload = await response.json();
          if (!response.ok || !payload.success) throw new Error(payload.message || '扣除库存失败');
          modal.dataset.needsRefresh = '1';
          showToast(payload.message || '材料已经扣除。');
          await load(currentVisitId, false);
        } catch (error) {
          showToast(error.message || '操作失败', 'error');
          if (button) { button.disabled = false; button.innerHTML = original || '确认扣除库存 →'; }
        }
      });

      root.querySelectorAll('[data-material-reverse-form]').forEach((reverseForm) => {
        reverseForm.addEventListener('submit', async (event) => {
          event.preventDefault();
          if (!confirm('确定撤销这笔耗材吗？库存会自动加回。')) return;
          const button = reverseForm.querySelector('button');
          try {
            if (button) { button.disabled = true; button.textContent = '撤销中…'; }
            const response = await fetch('index.php', { method: 'POST', body: new FormData(reverseForm), credentials: 'same-origin' });
            const payload = await response.json();
            if (!response.ok || !payload.success) throw new Error(payload.message || '撤销失败');
            modal.dataset.needsRefresh = '1';
            showToast(payload.message || '耗材已经撤销。');
            await load(currentVisitId, false);
          } catch (error) {
            showToast(error.message || '撤销失败', 'error');
            if (button) { button.disabled = false; button.textContent = '撤销'; }
          }
        });
      });
    };

    const load = async (visitId, animate = true) => {
      currentVisitId = String(visitId || '');
      controller?.abort();
      controller = new AbortController();
      modal.hidden = false;
      modal.setAttribute('aria-hidden', 'false');
      document.body.classList.add('commission-modal-open');
      if (content) content.innerHTML = '';
      if (loading) loading.hidden = false;
      if (animate) requestAnimationFrame(() => modal.classList.add('is-open'));
      try {
        const response = await fetch(`index.php?action=order_material_modal&id=${encodeURIComponent(currentVisitId)}`, { credentials: 'same-origin', signal: controller.signal });
        const html = await response.text();
        if (!response.ok) throw new Error('无法载入订单材料');
        if (content) content.innerHTML = html;
        if (loading) loading.hidden = true;
        bindContent();
      } catch (error) {
        if (error.name === 'AbortError') return;
        if (loading) loading.hidden = true;
        if (content) content.innerHTML = `<div class="commission-modal-error"><strong>载入失败</strong><span>${escapeHtml(error.message || '请稍后重试')}</span><button class="btn btn-light" type="button" data-order-material-modal-close>关闭</button></div>`;
      }
    };

    document.addEventListener('click', (event) => {
      const opener = event.target.closest('[data-order-material-open]');
      if (opener) { event.preventDefault(); load(opener.dataset.visitId); return; }
      if (event.target.closest('[data-order-material-modal-close]')) close();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !modal.hidden) close();
    });
  }


  function setupInventoryStockModal() {
    const modal = document.querySelector('[data-inventory-stock-modal]');
    if (!modal) return;
    const form = modal.querySelector('[data-inventory-stock-form]');
    const idInput = modal.querySelector('[data-inventory-modal-id]');
    const title = modal.querySelector('[data-inventory-modal-title]');
    const subtitle = modal.querySelector('[data-inventory-modal-subtitle]');
    const current = modal.querySelector('[data-inventory-modal-current]');
    const unitNodes = modal.querySelectorAll('[data-inventory-modal-unit], [data-inventory-modal-unit-suffix]');
    const costInput = modal.querySelector('[data-inventory-modal-cost]');
    const movement = modal.querySelector('[data-inventory-movement-type]');
    const quantity = modal.querySelector('[data-inventory-quantity-input]');
    const quantityLabel = modal.querySelector('[data-inventory-quantity-label]');
    const quantityHelp = modal.querySelector('[data-inventory-quantity-help]');
    const costField = modal.querySelector('[data-inventory-cost-field]');

    const formatQuantity = (value) => {
      const number = Number(value || 0);
      return Number.isInteger(number) ? String(number) : number.toFixed(3).replace(/0+$/,'').replace(/\.$/,'');
    };
    const syncType = () => {
      const type = movement?.value || 'purchase';
      const config = {
        purchase: ['进货数量','输入本次进货数量，系统会自动增加库存。',true,true],
        usage: ['使用数量','输入本次使用数量，系统会自动从库存扣除。',true,false],
        return: ['退回数量','输入退回门店库存的数量，系统会自动增加库存。',true,false],
        adjustment: ['变动数量','盘点增加请输入正数，减少请输入负数，例如 3 或 -2。',false,false],
      }[type];
      if (quantityLabel) quantityLabel.textContent = config[0];
      if (quantityHelp) quantityHelp.textContent = config[1];
      if (quantity) {
        quantity.value = '';
        if (config[2]) quantity.setAttribute('min','0.001'); else quantity.removeAttribute('min');
        quantity.placeholder = type === 'adjustment' ? '例如 3 或 -2' : '例如 10';
      }
      if (costField) costField.hidden = !config[3];
    };
    const close = () => {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden','true');
      document.body.classList.remove('commission-modal-open');
      setTimeout(() => { modal.hidden = true; form?.reset(); }, 220);
    };
    const open = (button) => {
      if (!button || !form) return;
      const name = button.dataset.inventoryName || '库存货品';
      const unit = button.dataset.inventoryUnit || '件';
      if (idInput) idInput.value = button.dataset.inventoryId || '';
      if (title) title.textContent = `${name} · 进货与调整`;
      if (subtitle) subtitle.textContent = `当前库存 ${formatQuantity(button.dataset.inventoryStock)} ${unit}`;
      if (current) current.textContent = formatQuantity(button.dataset.inventoryStock);
      unitNodes.forEach((node) => { node.textContent = unit; });
      if (costInput) costInput.value = Number(button.dataset.inventoryCost || 0).toFixed(2);
      if (movement) movement.value = 'purchase';
      syncType();
      modal.hidden = false;
      modal.setAttribute('aria-hidden','false');
      document.body.classList.add('commission-modal-open');
      requestAnimationFrame(() => modal.classList.add('is-open'));
      setTimeout(() => quantity?.focus(), 220);
    };
    movement?.addEventListener('change', syncType);
    document.addEventListener('click', (event) => {
      const opener = event.target.closest('[data-inventory-adjust-open]');
      if (opener) { event.preventDefault(); open(opener); return; }
      if (event.target.closest('[data-inventory-stock-modal-close]')) close();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !modal.hidden) close();
    });
  }

  function setupInventoryItemModal() {
    const modal = document.querySelector('[data-inventory-item-modal]');
    if (!modal) return;
    const form = modal.querySelector('[data-inventory-item-form]');
    const idInput = modal.querySelector('[data-inventory-item-id]');
    const kicker = modal.querySelector('[data-inventory-item-kicker]');
    const title = modal.querySelector('[data-inventory-item-title]');
    const subtitle = modal.querySelector('[data-inventory-item-subtitle]');
    const sku = modal.querySelector('[data-inventory-item-sku]');
    const name = modal.querySelector('[data-inventory-item-name]');
    const category = modal.querySelector('[data-inventory-item-category]');
    const type = modal.querySelector('[data-inventory-item-type]');
    const unit = modal.querySelector('[data-inventory-item-unit]');
    const cost = modal.querySelector('[data-inventory-item-cost]');
    const retail = modal.querySelector('[data-inventory-item-retail]');
    const reorder = modal.querySelector('[data-inventory-item-reorder]');
    const opening = modal.querySelector('[data-inventory-item-opening]');
    const openingField = modal.querySelector('[data-inventory-opening-field]');
    const active = modal.querySelector('[data-inventory-item-active]');
    const submit = modal.querySelector('[data-inventory-item-submit]');
    const imagePreview = modal.querySelector('[data-inventory-image-preview]');
    const imageInput = modal.querySelector('[data-catalog-image-input]');
    const removeImage = modal.querySelector('[data-inventory-remove-image]');
    const removeImageWrap = modal.querySelector('[data-inventory-remove-image-wrap]');

    const resetForm = () => {
      form?.reset();
      if (idInput) idInput.value = '';
      if (kicker) kicker.textContent = 'NEW ITEM';
      if (title) title.textContent = '新增库存货品';
      if (subtitle) subtitle.textContent = '在这里建立新的库存货品资料。';
      if (type) type.value = 'consumable';
      if (unit) unit.value = '件';
      if (cost) cost.value = '0.00';
      if (retail) retail.value = '0.00';
      if (reorder) reorder.value = '0';
      if (opening) opening.value = '0';
      if (active) active.checked = true;
      if (openingField) openingField.hidden = false;
      if (submit) submit.textContent = '保存库存货品';
      if (imageInput) imageInput.value = '';
      if (removeImage) removeImage.checked = false;
      if (removeImageWrap) removeImageWrap.hidden = true;
      setCatalogPreview(imagePreview, '');
    };
    const close = () => {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('commission-modal-open');
      setTimeout(() => { modal.hidden = true; resetForm(); }, 220);
    };
    const open = (button) => {
      resetForm();
      const isEdit = !!button?.dataset.inventoryId;
      if (isEdit) {
        if (idInput) idInput.value = button.dataset.inventoryId || '';
        if (kicker) kicker.textContent = 'EDIT ITEM';
        if (title) title.textContent = '修改库存货品';
        if (subtitle) subtitle.textContent = '修改基础资料；真实库存变动请用进货／调整浮窗。';
        if (sku) sku.value = button.dataset.inventorySku || '';
        if (name) name.value = button.dataset.inventoryName || '';
        if (category) category.value = button.dataset.inventoryCategory || '';
        if (type) type.value = button.dataset.inventoryType || 'consumable';
        if (unit) unit.value = button.dataset.inventoryUnit || '件';
        if (cost) cost.value = Number(button.dataset.inventoryCost || 0).toFixed(2);
        if (retail) retail.value = Number(button.dataset.inventoryRetail || 0).toFixed(2);
        if (reorder) reorder.value = String(button.dataset.inventoryReorder || '0');
        if (active) active.checked = String(button.dataset.inventoryActive || '1') === '1';
        if (openingField) openingField.hidden = true;
        if (submit) submit.textContent = '保存修改';
        const imageUrl = button.dataset.inventoryImage || '';
        setCatalogPreview(imagePreview, imageUrl);
        if (removeImageWrap) removeImageWrap.hidden = !imageUrl;
      }
      modal.hidden = false;
      modal.setAttribute('aria-hidden', 'false');
      document.body.classList.add('commission-modal-open');
      requestAnimationFrame(() => modal.classList.add('is-open'));
      setTimeout(() => sku?.focus(), 220);
    };
    document.addEventListener('click', (event) => {
      const opener = event.target.closest('[data-inventory-item-open]');
      if (opener) { event.preventDefault(); open(opener); return; }
      if (event.target.closest('[data-inventory-item-modal-close]')) close();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !modal.hidden) close();
    });
  }

  function setupInventoryDeleteModal() {
    const modal = document.querySelector('[data-inventory-delete-modal]');
    if (!modal) return;
    const idInput = modal.querySelector('[data-inventory-delete-id]');
    const nameNode = modal.querySelector('[data-inventory-delete-name]');
    const metaNode = modal.querySelector('[data-inventory-delete-meta]');
    const close = () => {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('commission-modal-open');
      setTimeout(() => { modal.hidden = true; if (idInput) idInput.value=''; }, 220);
    };
    const open = (button) => {
      if (idInput) idInput.value = button.dataset.inventoryId || '';
      if (nameNode) nameNode.textContent = button.dataset.inventoryName || '库存货品';
      if (metaNode) metaNode.textContent = `${button.dataset.inventorySku || ''} · 当前库存 ${button.dataset.inventoryStock || '0'} ${button.dataset.inventoryUnit || '件'}`;
      modal.hidden = false;
      modal.setAttribute('aria-hidden', 'false');
      document.body.classList.add('commission-modal-open');
      requestAnimationFrame(() => modal.classList.add('is-open'));
    };
    document.addEventListener('click', (event) => {
      const opener = event.target.closest('[data-inventory-delete-open]');
      if (opener) { event.preventDefault(); open(opener); return; }
      if (event.target.closest('[data-inventory-delete-modal-close]')) close();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !modal.hidden) close();
    });
  }


  function setupServiceManagement() {
    const itemModal = document.querySelector('[data-service-item-modal]');
    const deleteModal = document.querySelector('[data-service-delete-modal]');
    const filter = document.querySelector('[data-service-filter]');
    const rows = [...document.querySelectorAll('[data-service-row]')];
    const empty = document.querySelector('[data-service-filter-empty]');

    filter?.addEventListener('input', () => {
      const query = filter.value.trim().toLowerCase();
      let visible = 0;
      rows.forEach((row) => {
        const show = !query || (row.dataset.serviceSearch || '').includes(query);
        row.hidden = !show;
        if (show) visible += 1;
      });
      if (empty) empty.hidden = visible > 0;
    });

    if (itemModal) {
      const form = itemModal.querySelector('[data-service-item-form]');
      const id = itemModal.querySelector('[data-service-item-id]');
      const kicker = itemModal.querySelector('[data-service-item-kicker]');
      const title = itemModal.querySelector('[data-service-item-title]');
      const subtitle = itemModal.querySelector('[data-service-item-subtitle]');
      const category = itemModal.querySelector('[data-service-item-category]');
      const name = itemModal.querySelector('[data-service-item-name]');
      const price = itemModal.querySelector('[data-service-item-price]');
      const minutes = itemModal.querySelector('[data-service-item-minutes]');
      const assistant = itemModal.querySelector('[data-service-item-assistant]');
      const active = itemModal.querySelector('[data-service-item-active]');
      const submit = itemModal.querySelector('[data-service-item-submit]');

      const reset = () => {
        form?.reset();
        if (id) id.value = '';
        if (kicker) kicker.textContent = 'NEW SERVICE';
        if (title) title.textContent = '新增服务项目';
        if (subtitle) subtitle.textContent = '设定名称、价格、预计时间与助理规则。';
        if (price) price.value = '0.00';
        if (minutes) minutes.value = '60';
        if (assistant) assistant.checked = false;
        if (active) active.checked = true;
        if (submit) submit.textContent = '保存服务项目';
      };
      const close = () => {
        itemModal.classList.remove('is-open');
        itemModal.setAttribute('aria-hidden','true');
        document.body.classList.remove('commission-modal-open');
        setTimeout(() => { itemModal.hidden = true; reset(); }, 220);
      };
      const open = (button) => {
        reset();
        const editing = !!button?.dataset.serviceId;
        if (editing) {
          if (id) id.value = button.dataset.serviceId || '';
          if (kicker) kicker.textContent = 'EDIT SERVICE';
          if (title) title.textContent = '修改服务项目';
          if (subtitle) subtitle.textContent = '调整服务资料、价格、时间与启用状态。';
          if (category) category.value = button.dataset.serviceCategory || '';
          if (name) name.value = button.dataset.serviceName || '';
          if (price) price.value = Number(button.dataset.servicePrice || 0).toFixed(2);
          if (minutes) minutes.value = button.dataset.serviceMinutes || '60';
          if (assistant) assistant.checked = String(button.dataset.serviceAssistant || '0') === '1';
          if (active) active.checked = String(button.dataset.serviceActive || '1') === '1';
          if (submit) submit.textContent = '保存修改';
        const imageUrl = button.dataset.inventoryImage || '';
        setCatalogPreview(imagePreview, imageUrl);
        if (removeImageWrap) removeImageWrap.hidden = !imageUrl;
        }
        itemModal.hidden = false;
        itemModal.setAttribute('aria-hidden','false');
        document.body.classList.add('commission-modal-open');
        requestAnimationFrame(() => itemModal.classList.add('is-open'));
        setTimeout(() => category?.focus(), 220);
      };
      document.addEventListener('click', (event) => {
        const opener = event.target.closest('[data-service-item-open]');
        if (opener) { event.preventDefault(); open(opener); return; }
        if (event.target.closest('[data-service-item-modal-close]')) close();
      });
      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !itemModal.hidden) close();
      });
    }

    if (deleteModal) {
      const id = deleteModal.querySelector('[data-service-delete-id]');
      const name = deleteModal.querySelector('[data-service-delete-name]');
      const meta = deleteModal.querySelector('[data-service-delete-meta]');
      const warning = deleteModal.querySelector('[data-service-delete-warning]');
      const footerTitle = deleteModal.querySelector('[data-service-delete-footer-title]');
      const footerNote = deleteModal.querySelector('[data-service-delete-footer-note]');
      const submit = deleteModal.querySelector('[data-service-delete-submit]');
      const close = () => {
        deleteModal.classList.remove('is-open');
        deleteModal.setAttribute('aria-hidden','true');
        document.body.classList.remove('commission-modal-open');
        setTimeout(() => { deleteModal.hidden = true; if (id) id.value=''; }, 220);
      };
      const open = (button) => {
        const usage = Number(button.dataset.serviceUsage || 0);
        if (id) id.value = button.dataset.serviceId || '';
        if (name) name.textContent = button.dataset.serviceName || '服务项目';
        if (meta) meta.textContent = `${button.dataset.serviceCategory || '未分类'} · 历史使用 ${usage} 次`;
        if (submit) {
          submit.disabled = usage > 0;
          submit.textContent = usage > 0 ? '已有历史订单，不能删除' : '确认删除';
        }
        if (warning) warning.classList.toggle('is-blocked', usage > 0);
        if (footerTitle) footerTitle.textContent = usage > 0 ? '这个项目不能删除' : '确认删除这个服务项目？';
        if (footerNote) footerNote.textContent = usage > 0 ? '请关闭浮窗后进入修改，把项目设为停用。' : '若只是暂时不用，建议在修改浮窗里关闭“启用”。';
        deleteModal.hidden = false;
        deleteModal.setAttribute('aria-hidden','false');
        document.body.classList.add('commission-modal-open');
        requestAnimationFrame(() => deleteModal.classList.add('is-open'));
      };
      document.addEventListener('click', (event) => {
        const opener = event.target.closest('[data-service-delete-open]');
        if (opener) { event.preventDefault(); open(opener); return; }
        if (event.target.closest('[data-service-delete-modal-close]')) close();
      });
      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !deleteModal.hidden) close();
      });
    }
  }



  function setupEmployeeManager() {
    const editorModal = document.querySelector('[data-employee-modal]');
    const statusModal = document.querySelector('[data-employee-status-modal]');
    const resetModal = document.querySelector('[data-employee-reset-modal]');
    const credentialsModal = document.querySelector('[data-employee-credentials-modal]');
    const modals = [editorModal,statusModal,resetModal,credentialsModal].filter(Boolean);
    if (!modals.length) return;

    const openModal = (modal) => {
      if (!modal) return;
      modal.hidden = false;
      modal.setAttribute('aria-hidden','false');
      document.body.classList.add('commission-modal-open');
      requestAnimationFrame(() => modal.classList.add('is-open'));
    };
    const closeModal = (modal) => {
      if (!modal) return;
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden','true');
      setTimeout(() => {
        modal.hidden = true;
        if (!modals.some((item) => item && !item.hidden)) document.body.classList.remove('commission-modal-open');
      },220);
    };

    const search = document.querySelector('[data-employee-search]');
    const cards = [...document.querySelectorAll('[data-employee-card]')];
    const empty = document.querySelector('[data-employee-empty]');
    const filterCards = () => {
      const q=(search?.value||'').trim().toLowerCase();
      let shown=0;
      cards.forEach((card)=>{
        const match=!q||(card.dataset.employeeSearchText||'').includes(q);
        card.hidden=!match;
        if(match) shown++;
      });
      if(empty) empty.hidden=shown!==0;
    };
    search?.addEventListener('input',filterCards);

    if (editorModal) {
      const form=editorModal.querySelector('[data-employee-form]');
      const fields={
        id:editorModal.querySelector('[data-employee-id]'),
        name:editorModal.querySelector('[data-employee-name]'),
        phone:editorModal.querySelector('[data-employee-phone]'),
        position:editorModal.querySelector('[data-employee-position]'),
        age:editorModal.querySelector('[data-employee-age]'),
        gender:editorModal.querySelector('[data-employee-gender]'),
        skills:editorModal.querySelector('[data-employee-skills]'),
        salary:editorModal.querySelector('[data-employee-salary]'),
        joined:editorModal.querySelector('[data-employee-joined]'),
        role:editorModal.querySelector('[data-employee-role]'),
        attendanceEnabled:editorModal.querySelector('[data-employee-attendance-enabled]'),
        attendanceStart:editorModal.querySelector('[data-employee-attendance-start]'),
        attendanceEnd:editorModal.querySelector('[data-employee-attendance-end]'),
        attendanceGrace:editorModal.querySelector('[data-employee-attendance-grace]'),
      };
      const title=editorModal.querySelector('[data-employee-title]');
      const kicker=editorModal.querySelector('[data-employee-kicker]');
      const submit=editorModal.querySelector('[data-employee-submit]');
      const footerTitle=editorModal.querySelector('[data-employee-footer-title]');
      const reset=()=>{
        form?.reset();
        if(fields.id) fields.id.value='';
        if(fields.gender) fields.gender.value='unspecified';
        if(fields.role) fields.role.value='stylist';
        if(fields.salary) fields.salary.value='0.00';
        if(fields.joined) fields.joined.value=new Date().toISOString().slice(0,10);
        if(fields.attendanceEnabled) fields.attendanceEnabled.checked=true;
        if(fields.attendanceStart) fields.attendanceStart.value='09:00';
        if(fields.attendanceEnd) fields.attendanceEnd.value='18:00';
        if(fields.attendanceGrace) fields.attendanceGrace.value='10';
        if(title) title.textContent='新增员工';
        if(kicker) kicker.textContent='NEW EMPLOYEE';
        if(submit) submit.textContent='建立员工';
        if(footerTitle) footerTitle.textContent='建立员工与登录账号';
      };
      const open=(button)=>{
        reset();
        const editing=!!button?.dataset.employeeId;
        if(editing){
          if(fields.id) fields.id.value=button.dataset.employeeId||'';
          if(fields.name) fields.name.value=button.dataset.employeeName||'';
          if(fields.phone) fields.phone.value=button.dataset.employeePhone||'';
          if(fields.position) fields.position.value=button.dataset.employeePosition||'';
          if(fields.age) fields.age.value=button.dataset.employeeAge||'';
          if(fields.gender) fields.gender.value=button.dataset.employeeGender||'unspecified';
          if(fields.skills) fields.skills.value=button.dataset.employeeSkills||'';
          if(fields.salary) fields.salary.value=Number(button.dataset.employeeSalary||0).toFixed(2);
          if(fields.joined) fields.joined.value=button.dataset.employeeJoined||'';
          if(fields.role) fields.role.value=button.dataset.employeeRole||'stylist';
          if(fields.attendanceEnabled) fields.attendanceEnabled.checked=(button.dataset.employeeAttendanceEnabled||'1')==='1';
          if(fields.attendanceStart) fields.attendanceStart.value=button.dataset.employeeAttendanceStart||'09:00';
          if(fields.attendanceEnd) fields.attendanceEnd.value=button.dataset.employeeAttendanceEnd||'18:00';
          if(fields.attendanceGrace) fields.attendanceGrace.value=button.dataset.employeeAttendanceGrace||'10';
          if(title) title.textContent='修改员工资料';
          if(kicker) kicker.textContent='EDIT EMPLOYEE';
          if(submit) submit.textContent='保存修改';
          if(footerTitle) footerTitle.textContent='更新员工与账号权限';
        }
        openModal(editorModal);
        setTimeout(()=>fields.name?.focus(),220);
      };
      document.addEventListener('click',(event)=>{
        const opener=event.target.closest('[data-employee-open]');
        if(opener){event.preventDefault();open(opener);return;}
        if(event.target.closest('[data-employee-modal-close]')) closeModal(editorModal);
      });
    }

    if(statusModal){
      const id=statusModal.querySelector('[data-employee-status-id]');
      const target=statusModal.querySelector('[data-employee-status-target]');
      const title=statusModal.querySelector('[data-employee-status-title]');
      const copy=statusModal.querySelector('[data-employee-status-copy]');
      const name=statusModal.querySelector('[data-employee-status-name]');
      const detail=statusModal.querySelector('[data-employee-status-detail]');
      const submit=statusModal.querySelector('[data-employee-status-submit]');
      document.addEventListener('click',(event)=>{
        const opener=event.target.closest('[data-employee-status-open]');
        if(opener){
          event.preventDefault();
          const isActive=opener.dataset.employeeTarget==='active';
          if(id) id.value=opener.dataset.employeeId||'';
          if(target) target.value=isActive?'active':'inactive';
          if(name) name.textContent=opener.dataset.employeeName||'员工';
          if(title) title.textContent=isActive?'重新启用员工':'离职／停用员工';
          if(copy) copy.textContent=isActive?'恢复员工端账号，让员工可以再次登录。':'员工将无法继续登录，但所有历史资料都会保留。';
          if(detail) detail.textContent=isActive?'若旧员工尚未有员工端账号，系统会自动建立手机号免密码登录账号。':'订单、顾客、业绩、抽成、库存操作和培训记录都不会被删除。';
          if(submit){submit.textContent=isActive?'确认重新启用':'确认停用';submit.className=`btn ${isActive?'btn-primary':'btn-danger-soft'}`;}
          openModal(statusModal);
          return;
        }
        if(event.target.closest('[data-employee-status-close]')) closeModal(statusModal);
      });
    }

    if(resetModal){
      const id=resetModal.querySelector('[data-employee-reset-id]');
      const name=resetModal.querySelector('[data-employee-reset-name]');
      const phone=resetModal.querySelector('[data-employee-reset-phone]');
      document.addEventListener('click',(event)=>{
        const opener=event.target.closest('[data-employee-reset-open]');
        if(opener){event.preventDefault();if(id)id.value=opener.dataset.employeeId||'';if(name)name.textContent=opener.dataset.employeeName||'员工';if(phone)phone.textContent=`登录手机号：${opener.dataset.employeePhone||'—'}`;openModal(resetModal);return;}
        if(event.target.closest('[data-employee-reset-close]')) closeModal(resetModal);
      });
    }

    if(credentialsModal){
      document.addEventListener('click',async(event)=>{
        if(event.target.closest('[data-employee-credentials-close]')){closeModal(credentialsModal);return;}
        if(event.target.closest('[data-copy-credentials]')){
          const phone=credentialsModal.querySelector('[data-copy-phone]')?.textContent?.trim()||'';
          const password=credentialsModal.querySelector('[data-copy-password]')?.textContent?.trim()||'';
          const text=`SalonOS 员工端\n登录手机号：${phone}\n老板启用账号后可直接登录，不需要密码。`;
          try{await navigator.clipboard.writeText(text);showToast('登录资料已复制。');}
          catch(_){window.prompt('复制以下登录资料：',text);}
        }
      });
      if(credentialsModal.hasAttribute('data-auto-open')) openModal(credentialsModal);
    }

    document.addEventListener('keydown',(event)=>{
      if(event.key!=='Escape') return;
      [...modals].reverse().find((modal)=>modal&&!modal.hidden)&&closeModal([...modals].reverse().find((modal)=>modal&&!modal.hidden));
    });
  }


  function setupBranchEditor() {
    const modal=document.querySelector('[data-branch-modal]'); if(!modal)return;
    const form=modal.querySelector('[data-branch-form]');
    const close=()=>{modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('commission-modal-open');setTimeout(()=>{modal.hidden=true;form?.reset();},220);};
    const open=(button)=>{form?.reset();const edit=!!button.dataset.branchId;modal.querySelector('[data-branch-id]').value=button.dataset.branchId||'';modal.querySelector('[data-branch-name]').value=button.dataset.branchName||'';modal.querySelector('[data-branch-address]').value=button.dataset.branchAddress||'';modal.querySelector('[data-branch-phone]').value=button.dataset.branchPhone||'';modal.querySelector('[data-branch-active]').checked=(button.dataset.branchActive||'1')==='1';modal.querySelector('[data-branch-kicker]').textContent=edit?'EDIT BRANCH':'NEW BRANCH';modal.querySelector('[data-branch-title]').textContent=edit?'修改分行资料':'创建新分行';modal.hidden=false;modal.setAttribute('aria-hidden','false');document.body.classList.add('commission-modal-open');requestAnimationFrame(()=>modal.classList.add('is-open'));setTimeout(()=>modal.querySelector('[data-branch-name]')?.focus(),200);};
    document.addEventListener('click',(event)=>{const opener=event.target.closest('[data-branch-open]');if(opener){event.preventDefault();open(opener);return;}if(event.target.closest('[data-branch-close]'))close();});
    document.addEventListener('keydown',(event)=>{if(event.key==='Escape'&&!modal.hidden)close();});
  }

  function setCatalogPreview(container, src) {
    if (!container) return;
    const image = container.querySelector('img');
    const placeholder = container.querySelector('span');
    if (image) { image.src = src || ''; image.hidden = !src; }
    if (placeholder) placeholder.hidden = !!src;
  }

  function setupCatalogImagePreviews() {
    document.querySelectorAll('[data-catalog-image-input]').forEach((input) => {
      if (input.dataset.imagePreviewBound === '1') return;
      input.dataset.imagePreviewBound = '1';
      input.addEventListener('change', () => {
        const file = input.files?.[0];
        const editor = input.closest('.catalog-image-editor');
        const preview = editor?.querySelector('[data-catalog-image-preview], [data-inventory-image-preview]');
        if (!file) return;
        if (!['image/jpeg','image/png','image/webp'].includes(file.type)) { alert('图片只支持 JPG、PNG 或 WebP。'); input.value=''; return; }
        if (file.size > 5 * 1024 * 1024) { alert('图片必须小于 5MB。'); input.value=''; return; }
        const url = URL.createObjectURL(file);
        setCatalogPreview(preview, url);
        const img = preview?.querySelector('img');
        img?.addEventListener('load', () => URL.revokeObjectURL(url), { once:true });
      });
    });
  }

  function setupCatalogImageViewer() {
    const modal = document.querySelector('[data-catalog-image-viewer]');
    if (!modal) return;
    const image = modal.querySelector('[data-catalog-image-full]');
    const title = modal.querySelector('[data-catalog-image-title]');
    const subtitle = modal.querySelector('[data-catalog-image-subtitle]');
    const close = () => {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden','true');
      document.body.classList.remove('commission-modal-open');
      setTimeout(() => { modal.hidden=true; if(image)image.src=''; },220);
    };
    document.addEventListener('click',(event)=>{
      const opener=event.target.closest('[data-catalog-image-view]');
      if(opener){
        event.preventDefault();
        const src=opener.dataset.imageSrc||'';
        if(!src)return;
        if(image){image.src=src;image.alt=opener.dataset.imageTitle||'产品图片';}
        if(title)title.textContent=opener.dataset.imageTitle||'产品图片';
        if(subtitle)subtitle.textContent=opener.dataset.imageSubtitle||'';
        modal.hidden=false;modal.setAttribute('aria-hidden','false');document.body.classList.add('commission-modal-open');requestAnimationFrame(()=>modal.classList.add('is-open'));
        return;
      }
      if(event.target.closest('[data-catalog-image-close]'))close();
    });
    document.addEventListener('keydown',(event)=>{if(event.key==='Escape'&&!modal.hidden)close();});
  }


  function setupMembershipLevelEditor() {
    const editor=document.querySelector('[data-membership-level-editor]'); if(!editor)return; const list=editor.querySelector('[data-membership-level-list]'); const template=editor.querySelector('[data-membership-level-template]');
    const renumber=()=>{[...list.querySelectorAll('[data-membership-level-row]')].forEach((row,index)=>{row.querySelector('.level-number').textContent=`LV${index+1}`;row.querySelectorAll('[data-level-field]').forEach((input)=>input.name=`levels[${index}][${input.dataset.levelField}]`);});};
    editor.querySelector('[data-add-membership-level]')?.addEventListener('click',()=>{list.appendChild(template.content.cloneNode(true));renumber();list.lastElementChild?.scrollIntoView({behavior:'smooth',block:'center'});});
    editor.addEventListener('click',(event)=>{const remove=event.target.closest('[data-remove-membership-level]');if(!remove||remove.disabled)return;remove.closest('[data-membership-level-row]')?.remove();renumber();});renumber();
  }

  function showToast(message, type = 'success') {
    const toast = document.querySelector('[data-app-toast]');
    if (!toast) { alert(message); return; }
    toast.textContent = message;
    toast.className = `app-toast is-visible ${type === 'error' ? 'is-error' : 'is-success'}`;
    toast.hidden = false;
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => { toast.classList.remove('is-visible'); setTimeout(() => { toast.hidden = true; },180); }, 2600);
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char]));
  }

  function setupSignaturePad() {
    const canvas = document.querySelector('#signature-pad');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const hidden = document.querySelector('#signature-data');
    let drawing = false;
    let hasInk = false;

    const resize = () => {
      const ratio = Math.max(window.devicePixelRatio || 1, 1);
      const rect = canvas.getBoundingClientRect();
      const snapshot = hasInk ? canvas.toDataURL('image/png') : null;
      canvas.width = Math.max(1, Math.floor(rect.width * ratio));
      canvas.height = Math.max(1, Math.floor(rect.height * ratio));
      ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
      ctx.lineWidth = 2.3;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.strokeStyle = '#ffffff';
      if (snapshot) {
        const image = new Image();
        image.onload = () => ctx.drawImage(image, 0, 0, rect.width, rect.height);
        image.src = snapshot;
      }
    };
    const point = (event) => {
      const rect = canvas.getBoundingClientRect();
      return [event.clientX - rect.left, event.clientY - rect.top];
    };
    const start = (event) => {
      if (event.button !== undefined && event.button !== 0) return;
      drawing = true;
      hasInk = true;
      ctx.beginPath();
      ctx.moveTo(...point(event));
      canvas.setPointerCapture?.(event.pointerId);
      event.preventDefault();
    };
    const move = (event) => {
      if (!drawing) return;
      ctx.lineTo(...point(event));
      ctx.stroke();
      event.preventDefault();
    };
    const end = (event) => {
      if (!drawing) return;
      drawing = false;
      canvas.releasePointerCapture?.(event.pointerId);
      if (hidden) hidden.value = canvas.toDataURL('image/png');
    };
    resize();
    canvas.addEventListener('pointerdown', start);
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
    window.addEventListener('resize', debounce(resize, 180));
    document.querySelector('[data-clear-signature]')?.addEventListener('click', () => {
      const rect = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, rect.width, rect.height);
      hasInk = false;
      if (hidden) hidden.value = '';
    });
    canvas.closest('form')?.addEventListener('submit', (event) => {
      if (!hidden?.value || !hasInk) {
        event.preventDefault();
        alert('请先让顾客完成签名。');
      }
    });
  }


  function initProductSearchForms(root = document) {
    root.querySelectorAll('[data-product-purchase]').forEach((form) => {
      if (form.dataset.productSearchBound === '1') return;
      form.dataset.productSearchBound = '1';
      const input=form.querySelector('[data-product-search]');
      const results=form.querySelector('[data-product-results]');
      const productId=form.querySelector('[data-product-id]');
      const selected=form.querySelector('[data-selected-product]');
      const nameEl=form.querySelector('[data-selected-product-name]');
      const stockEl=form.querySelector('[data-selected-product-stock]');
      const priceEl=form.querySelector('[data-selected-product-price]');
      const imageEl=form.querySelector('[data-selected-product-image]');
      const imagePlaceholder=form.querySelector('[data-selected-product-placeholder]');
      const descriptionEl=form.querySelector('[data-selected-product-description]');
      const qty=form.querySelector('[data-product-quantity]');
      const total=form.querySelector('[data-product-total]');
      let chosen=null, controller=null;
      const productSearchCache=new Map();
      const money=(value)=>`RM ${Number(value||0).toFixed(2)}`;
      const updateTotal=()=>{ const count=Math.max(1,Number(qty?.value||1)); if(total) total.value=money((chosen?.price||0)*count); if(qty&&chosen) qty.max=String(Math.max(1,chosen.available)); };
      const choose=(product)=>{chosen=product;if(productId)productId.value=product.id;if(input)input.value=product.name;if(selected)selected.hidden=false;if(nameEl)nameEl.textContent=product.name;if(stockEl)stockEl.textContent=`${product.category} · ${product.stock_text}`;if(descriptionEl)descriptionEl.textContent=product.description||'';if(priceEl)priceEl.textContent=product.price_text;if(imageEl){imageEl.src=product.image_url||'';imageEl.hidden=!product.image_url;}if(imagePlaceholder){imagePlaceholder.hidden=!!product.image_url;imagePlaceholder.textContent=String(product.name||'P').slice(0,1);}if(qty){qty.value='1';qty.max=String(Math.max(1,product.available));}if(results)results.hidden=true;updateTotal();};
      let activeIndex=-1;
      const optionButtons=()=>results?[...results.querySelectorAll('[data-product-option]:not(:disabled)')]:[];
      const setActive=(index)=>{const buttons=optionButtons();buttons.forEach((button)=>button.classList.remove('is-active'));if(!buttons.length){activeIndex=-1;return;}activeIndex=Math.max(0,Math.min(index,buttons.length-1));buttons[activeIndex].classList.add('is-active');buttons[activeIndex].scrollIntoView({block:'nearest'});};
      const render=(items)=>{if(!results)return;const visible=Array.isArray(items)?items.slice(0,12):[];activeIndex=-1;results.innerHTML=visible.length?`<div class="product-search-result-head"><span>即时搜索结果</span><strong>${visible.length} 个</strong></div>`+visible.map((p)=>`<button type="button" class="product-search-option" data-product-option data-product='${escapeHtml(JSON.stringify(p))}' ${p.available<=0?'disabled':''}><span class="product-search-thumb">${p.image_url?`<img src="${escapeHtml(p.image_url)}" alt="">`:`<b>${escapeHtml(String(p.name||'P').slice(0,1))}</b>`}</span><span class="product-search-main"><strong>${escapeHtml(p.name)}</strong><small><b class="product-type-pill ${p.type==='bundle'?'is-bundle':'is-single'}">${escapeHtml(p.type_text||'销售产品')}</b> · ${escapeHtml(p.code)} · ${escapeHtml(p.category)}</small>${p.description?`<small>${escapeHtml(p.description)}</small>`:''}</span><span><strong>${escapeHtml(p.price_text)}</strong><small>${escapeHtml(p.stock_text)}</small></span></button>`).join(''):'<div class="product-search-empty">没有找到可销售的产品或配套。</div>';results.hidden=false;};
      const showSearching=()=>{if(!results)return;activeIndex=-1;results.hidden=false;results.innerHTML='<div class="product-search-empty product-search-loading">正在搜索产品 / 配套…</div>';};
      const runSearch=debounce(async()=>{const q=input?.value.trim()||'';chosen=null;if(productId)productId.value='';if(selected)selected.hidden=true;if(q.length<1){if(results){results.hidden=true;results.innerHTML='';}return;}const key=q.toLocaleLowerCase();if(productSearchCache.has(key)){render(productSearchCache.get(key));return;}controller?.abort();controller=new AbortController();try{const response=await fetch(`index.php?action=search_products&q=${encodeURIComponent(q)}&t=${Date.now()}`,{signal:controller.signal,credentials:'same-origin',cache:'no-store'});if(!response.ok)throw new Error(`search failed ${response.status}`);const rows=await response.json();productSearchCache.set(key,rows);render(rows);}catch(error){if(error.name!=='AbortError'&&results){activeIndex=-1;results.hidden=false;results.innerHTML='<div class="product-search-empty">搜索暂时失败，请再输入一次。</div>';}}},90);
      input?.addEventListener('input',()=>{const q=input.value.trim();if(q.length<1){if(results){results.hidden=true;results.innerHTML='';}return;}showSearching();runSearch();});
      input?.addEventListener('focus',()=>{const q=input.value.trim().toLocaleLowerCase();if(q&&productSearchCache.has(q))render(productSearchCache.get(q));else if(q)runSearch();});
      input?.addEventListener('keydown',(event)=>{if(results?.hidden)return;const buttons=optionButtons();if(!buttons.length)return;if(event.key==='ArrowDown'){event.preventDefault();setActive(activeIndex+1);}else if(event.key==='ArrowUp'){event.preventDefault();setActive(activeIndex<=0?buttons.length-1:activeIndex-1);}else if(event.key==='Enter'&&activeIndex>=0){event.preventDefault();buttons[activeIndex]?.click();}else if(event.key==='Escape'){results.hidden=true;}});
      results?.addEventListener('click',(event)=>{const button=event.target.closest('[data-product-option]');if(!button||button.disabled)return;try{choose(JSON.parse(button.dataset.product));activeIndex=-1;}catch{}});
      document.addEventListener('click',(event)=>{if(results&&!form.contains(event.target))results.hidden=true;});
      qty?.addEventListener('input',updateTotal);
      form.addEventListener('submit',(event)=>{if(!productId?.value){event.preventDefault();alert('请先搜索并选择一个产品或配套。');return;}if(chosen&&Number(qty?.value||1)>chosen.available){event.preventDefault();alert(`库存不足，最多可购买 ${chosen.available} 份。`);}});
    });
  }

  function initCatalogListFilters() {
    document.querySelectorAll('[data-catalog-filter-root]').forEach((root) => {
      const input=root.querySelector('[data-catalog-list-search]');
      if(!input||input.dataset.filterBound==='1')return;
      input.dataset.filterBound='1';
      const count=root.querySelector('[data-catalog-filter-count]');
      const normalize=(value)=>String(value||'').toLocaleLowerCase().replace(/[\s\-_.\\/(),+&]+/g,'');
      const filter=()=>{
        const query=normalize(input.value);
        let visible=0;
        const siblingList=root.nextElementSibling?.matches?.('[data-catalog-filter-list]')?root.nextElementSibling:null;
        const scope=root.querySelector('[data-catalog-filter-list]')||siblingList||root;
        scope.querySelectorAll('[data-catalog-filter-item]').forEach((item)=>{
          const match=!query||normalize(item.dataset.search||item.textContent).includes(query);
          item.hidden=!match;
          if(match)visible++;
        });
        if(count)count.textContent=`${visible} 个结果`;
      };
      input.addEventListener('input',filter);
      filter();
    });
  }

  function initProductEditor() {
    const editor=document.querySelector('[data-product-editor]'); if(!editor)return;
    const list=editor.querySelector('[data-product-component-list]'); const template=editor.querySelector('[data-product-component-template]'); const type=editor.querySelector('[data-product-type]');
    const renumber=()=>{[...list.querySelectorAll('[data-product-component-row]')].forEach((row,index)=>{row.querySelectorAll('[data-component-field]').forEach((field)=>field.name=`components[${index}][${field.dataset.componentField}]`);});};
    editor.querySelector('[data-add-product-component]')?.addEventListener('click',()=>{if(type?.value==='single'&&list.children.length>=1){alert('单一产品只能连接一个库存货品；请改成产品配套。');return;}list.appendChild(template.content.cloneNode(true));renumber();});
    editor.addEventListener('click',(event)=>{const remove=event.target.closest('[data-remove-product-component]');if(!remove)return;if(list.children.length<=1){alert('至少保留一个库存货品。');return;}remove.closest('[data-product-component-row]')?.remove();renumber();});
    type?.addEventListener('change',()=>{if(type.value==='single'&&list.children.length>1)alert('单一产品保存时只能保留一个库存货品。');});renumber();
  }

  initProductSearchForms();
  initProductEditor();
  initCatalogListFilters();

  // v13.6.10.44 · Customer directory master-detail navigation.
  // Selecting a customer updates only the right-side workspace instead of reloading the entire page.
  let customerWorkspaceController = null;
  const customerWorkspaceDetail = () => document.querySelector('.customer-directory-detail');
  const setCustomerWorkspaceLoading = (loading) => {
    const detail = customerWorkspaceDetail();
    if (!detail) return;
    detail.classList.toggle('is-customer-loading', !!loading);
    let overlay = detail.querySelector(':scope > [data-customer-detail-loader]');
    if (loading && !overlay) {
      overlay = document.createElement('div');
      overlay.className = 'customer-detail-loader';
      overlay.setAttribute('data-customer-detail-loader', '');
      overlay.setAttribute('role', 'status');
      overlay.setAttribute('aria-live', 'polite');
      overlay.innerHTML = '<span class="customer-detail-loader-spinner" aria-hidden="true"></span><div><strong>正在载入顾客资料…</strong><small>已收到你的选择，不需要重复点击</small></div>';
      detail.prepend(overlay);
    }
    if (!loading && overlay) overlay.remove();
  };
  const setActiveCustomerDirectoryItem = (customerId) => {
    document.querySelectorAll('[data-customer-ajax]').forEach((item) => {
      const active = String(item.dataset.customerId || '') === String(customerId || '');
      item.classList.toggle('active', active);
      item.setAttribute('aria-current', active ? 'true' : 'false');
    });
  };
  const loadCustomerWorkspace = async (urlLike, options = {}) => {
    const detail = customerWorkspaceDetail();
    if (!detail) {
      window.location.href = String(urlLike);
      return false;
    }
    const url = new URL(String(urlLike), window.location.href);
    const customerId = url.searchParams.get('customer_id') || '';
    const previousId = document.querySelector('[data-customer-ajax].active')?.dataset.customerId || '';
    customerWorkspaceController?.abort();
    customerWorkspaceController = new AbortController();
    setActiveCustomerDirectoryItem(customerId);
    setCustomerWorkspaceLoading(true);
    try {
      const response = await fetch(url.toString(), {
        credentials: 'same-origin',
        cache: 'no-store',
        signal: customerWorkspaceController.signal,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      });
      if (!response.ok) throw new Error(`无法载入顾客资料 (${response.status})`);
      const html = await response.text();
      const parsed = new DOMParser().parseFromString(html, 'text/html');
      const nextDetail = parsed.querySelector('.customer-directory-detail');
      if (!nextDetail) throw new Error('服务器没有返回顾客资料区域。');
      detail.innerHTML = nextDetail.innerHTML;
      setActiveCustomerDirectoryItem(customerId);
      if (options.history !== false) history.pushState({ salonosCustomerId: customerId }, '', url.toString());
      initMemberWorkspaceForms();
      initProductSearchForms(detail);
      if (options.scrollIntoView && window.matchMedia('(max-width: 900px)').matches) {
        detail.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      return true;
    } catch (error) {
      if (error?.name === 'AbortError') return false;
      setActiveCustomerDirectoryItem(previousId);
      const existing = detail.querySelector('[data-customer-detail-error]');
      existing?.remove();
      const notice = document.createElement('div');
      notice.className = 'customer-detail-error';
      notice.setAttribute('data-customer-detail-error', '');
      notice.innerHTML = `<strong>顾客资料载入失败</strong><span>${escapeHtml(error?.message || '请稍后再试。')}</span>`;
      detail.prepend(notice);
      setTimeout(() => notice.remove(), 5000);
      return false;
    } finally {
      setCustomerWorkspaceLoading(false);
    }
  };
  const initCustomerDirectoryAjax = () => {
    const directory = document.querySelector('.customer-directory-list');
    if (!directory || directory.dataset.customerAjaxBound === '1') return;
    directory.dataset.customerAjaxBound = '1';
    directory.addEventListener('click', (event) => {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const link = event.target.closest('[data-customer-ajax]');
      if (!link || !directory.contains(link)) return;
      event.preventDefault();
      if (link.classList.contains('active')) return;
      loadCustomerWorkspace(link.href, { history: true, scrollIntoView: true });
    });
    window.addEventListener('popstate', () => {
      if (!document.querySelector('.customer-directory-layout')) return;
      loadCustomerWorkspace(window.location.href, { history: false, scrollIntoView: false });
    });
  };
  initCustomerDirectoryAjax();

  function initMemberWorkspaceForms() {
    document.querySelectorAll('[data-member-workspace] [data-member-ajax-form]').forEach((form) => {
      if (form.dataset.ajaxBound === '1') return;
      form.dataset.ajaxBound = '1';
      form.addEventListener('submit', async (event) => {
        if (event.defaultPrevented) return;
        event.preventDefault();
        const submitter = form.querySelector('button[type="submit"]');
        const original = submitter?.innerHTML;
        const workspace = form.closest('[data-member-workspace]');
        const currentCustomerId = workspace?.dataset.customerId || form.querySelector('[name="customer_id"]')?.value || '';
        try {
          if (submitter) { submitter.disabled = true; submitter.innerHTML = '处理中...'; }
          const response = await fetch('index.php', { method: 'POST', body: new FormData(form), credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' } });
          const raw = await response.text();
          let payload;
          try { payload = JSON.parse(raw); } catch { throw new Error('服务器没有返回 JSON。请刷新页面后再保存，系统不会重复建立顾客。'); }
          if (!response.ok || !payload.success) throw new Error(payload.message || '保存失败');
          const url = new URL(window.location.href);
          url.searchParams.set('page', 'customers');
          url.searchParams.set('customer_id', String(payload.customer_id || currentCustomerId));
          const refreshed = await loadCustomerWorkspace(url.toString(), { history: false, scrollIntoView: false });
          if (!refreshed) window.location.href = url.toString();
        } catch (error) {
          alert(error.message || '操作失败，请稍后再试。');
        } finally {
          if (submitter) { submitter.disabled = false; submitter.innerHTML = original || '提交'; }
        }
      });
    });
  }

  initMemberWorkspaceForms();

  function safeJsonParse(value, fallback) {
    try { return JSON.parse(value); } catch { return fallback; }
  }

  function formatSavedTime(timestamp) {
    return new Date(Number(timestamp)).toLocaleString([], { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
  }

  function cssEscape(value) {
    if (window.CSS?.escape) return CSS.escape(String(value));
    return String(value).replace(/["\\]/g, '\\$&');
  }

  // v13.5.0 generic modal controller used by inventory, service, KPI, training and commission editors.
  const closeV1350Modal = (modal) => {
    if (!modal) return;
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden','true');
    document.body.classList.remove('commission-modal-open');
    setTimeout(() => { modal.hidden = true; }, 180);
  };
  document.addEventListener('click', (event) => {
    const opener = event.target.closest('[data-v1350-modal-open]');
    if (opener) {
      const name = opener.getAttribute('data-v1350-modal-open');
      const modal = document.querySelector(`[data-v1350-modal="${cssEscape(name)}"]`);
      if (!modal) return;
      const form = modal.querySelector('form');
      if (form) form.reset();
      modal.querySelectorAll('[data-bind]').forEach((input) => {
        const key = input.dataset.bind;
        if (!Object.prototype.hasOwnProperty.call(opener.dataset, key)) return;
        const raw = opener.dataset[key] ?? '';
        if (input.type === 'checkbox') input.checked = raw === '1' || raw === 'true';
        else input.value = raw;
      });
      modal.querySelectorAll('[data-v1350-copy]').forEach((node) => {
        const key = node.getAttribute('data-v1350-copy');
        if (key && Object.prototype.hasOwnProperty.call(opener.dataset, key)) node.textContent = opener.dataset[key] || '';
      });
      modal.hidden = false;
      modal.setAttribute('aria-hidden','false');
      document.body.classList.add('commission-modal-open');
      const scrollPane = modal.querySelector('.commission-modal-content');
      if (scrollPane) scrollPane.scrollTop = 0;
      modal.querySelectorAll('[data-v1351-image-input]').forEach((input) => {
        const box = input.closest('[data-v1351-media-upload]');
        const preview = box?.querySelector('[data-v1351-image-preview]');
        const empty = box?.querySelector('[data-v1351-image-empty]');
        if (preview) { preview.removeAttribute('src'); preview.hidden = true; }
        if (empty) empty.hidden = false;
      });
      requestAnimationFrame(() => modal.classList.add('is-open'));
      setTimeout(() => modal.querySelector('input:not([type="hidden"]):not([type="file"]),select,textarea')?.focus({preventScroll:true}), 120);
      return;
    }
    const closer = event.target.closest('[data-v1350-modal-close]');
    if (closer) closeV1350Modal(closer.closest('[data-v1350-modal]'));
  });
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    document.querySelectorAll('[data-v1350-modal].is-open').forEach(closeV1350Modal);
  });

  // v13.5.1 image preview for long modal forms. The file itself is uploaded only on submit.
  document.addEventListener('change', (event) => {
    const input = event.target.closest?.('[data-v1351-image-input]');
    if (!input) return;
    const box = input.closest('[data-v1351-media-upload]');
    const preview = box?.querySelector('[data-v1351-image-preview]');
    const empty = box?.querySelector('[data-v1351-image-empty]');
    const file = input.files?.[0];
    if (!preview) return;
    if (!file) { preview.removeAttribute('src'); preview.hidden = true; if (empty) empty.hidden = false; return; }
    if (!/^image\/(jpeg|png|webp)$/i.test(file.type)) { input.value=''; alert('只支持 JPG / PNG / WebP 图片。'); return; }
    const url = URL.createObjectURL(file);
    preview.onload = () => URL.revokeObjectURL(url);
    preview.src = url;
    preview.hidden = false;
    if (empty) empty.hidden = true;
  });

  function setupServiceBoardLive() {
    const root = document.querySelector('[data-service-board-live-root]');
    if (!root) return;
    const status = document.querySelector('[data-service-board-live-status]');
    const boardDate = root.dataset.boardDate || new URL(window.location.href).searchParams.get('board_date') || '';
    let signature = root.dataset.serviceBoardSignature || '';
    let controller = null;
    let stopped = false;
    let reloading = false;
    let timer = null;

    const modalIsOpen = () => {
      const modal = document.querySelector('[data-service-board-modal]');
      return Boolean(modal && !modal.hidden);
    };
    const setStatus = (text, mode = 'green') => {
      if (!status) return;
      status.textContent = text;
      status.classList.remove('badge-green','badge-red','badge-gold');
      status.classList.add(mode === 'red' ? 'badge-red' : (mode === 'gold' ? 'badge-gold' : 'badge-green'));
    };
    const reloadFresh = () => {
      if (reloading) return;
      reloading = true;
      setStatus('数据已更新 · 同步中…', 'gold');
      const url = new URL(window.location.href);
      url.searchParams.set('_live', String(Date.now()));
      window.location.replace(url.toString());
    };
    const refresh = async () => {
      if (stopped || document.hidden || reloading || controller) return;
      const current = new AbortController();
      controller = current;
      try {
        const params = new URLSearchParams({ action:'service_board_live_v13696', board_date:boardDate, t:String(Date.now()) });
        const response = await fetch(`index.php?${params.toString()}`, {
          cache:'no-store',
          credentials:'same-origin',
          signal:current.signal,
          headers:{'Accept':'application/json'}
        });
        const payload = await response.json();
        if (controller !== current) return;
        if (!response.ok || !payload.ok || !payload.signature) throw new Error(payload.error || '服务现场同步失败');
        setStatus(`实时同步 · ${payload.updated_at || ''}`);
        if (!signature) {
          signature = payload.signature;
          root.dataset.serviceBoardSignature = signature;
          return;
        }
        if (payload.signature !== signature) {
          if (modalIsOpen()) {
            setStatus('数据已更新 · 关闭窗口后同步', 'gold');
            return;
          }
          signature = payload.signature;
          root.dataset.serviceBoardSignature = signature;
          reloadFresh();
        }
      } catch (error) {
        if (error.name === 'AbortError' || controller !== current) return;
        setStatus('实时同步重试中', 'red');
      } finally {
        if (controller === current) controller = null;
      }
    };

    // The first snapshot is rendered by PHP; don't request it again immediately.
    const resume = () => {
      stopped = false;
      reloading = false;
      if (timer === null) timer = window.setInterval(refresh, 5000);
    };
    resume();
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
    window.addEventListener('focus', refresh);
    document.addEventListener('click', (event) => {
      if (event.target.closest?.('[data-service-board-modal-close]')) window.setTimeout(refresh, 250);
    });
    window.addEventListener('pagehide', () => {
      stopped = true;
      controller?.abort();
      controller = null;
      clearInterval(timer);
      timer = null;
    });
    window.addEventListener('pageshow', (event) => { if (event.persisted) { resume(); refresh(); } });
  }

  function setupDashboardLive() {
    const root = document.querySelector('[data-dashboard-live-root]');
    if (!root) return;
    const status = document.querySelector('[data-dashboard-live-status]');
    let controller = null;
    let stopped = false;
    let timer = null;
    const apply = (payload) => {
      root.querySelectorAll('[data-dashboard-live]').forEach((node) => {
        const key = node.dataset.dashboardLive;
        if (key && Object.prototype.hasOwnProperty.call(payload, key)) node.textContent = String(payload[key]);
      });
      if (status) {
        status.textContent = `实时同步 · ${payload.updated_at || new Date().toLocaleTimeString('zh-MY',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}`;
        status.classList.remove('badge-red');
        status.classList.add('badge-green');
      }
    };
    const refresh = async () => {
      if (stopped || document.hidden || controller) return;
      const current = new AbortController();
      controller = current;
      try {
        const response = await fetch('index.php?action=dashboard_live_v1358', { cache:'no-store', signal:current.signal, headers:{'Accept':'application/json'} });
        const payload = await response.json();
        if (controller !== current) return;
        if (!response.ok || payload.error) throw new Error(payload.error || '同步失败');
        apply(payload);
      } catch (error) {
        if (error.name === 'AbortError' || controller !== current) return;
        if (status) {
          status.textContent = '同步重试中';
          status.classList.remove('badge-green');
          status.classList.add('badge-red');
        }
      } finally {
        if (controller === current) controller = null;
      }
    };
    const resume = () => {
      stopped = false;
      if (timer === null) timer = window.setInterval(refresh, 3000);
    };
    resume();
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
    window.addEventListener('focus', refresh);
    window.addEventListener('pagehide', () => {
      stopped = true;
      controller?.abort();
      controller = null;
      clearInterval(timer);
      timer = null;
    });
    window.addEventListener('pageshow', (event) => { if (event.persisted) { resume(); refresh(); } });
  }

  function debounce(fn, delay) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), delay);
    };
  }
});


function setupTunaiproImportOptions() {
  const form = document.querySelector('[data-tunaipro-import-form]');
  if (!form) return;
  const select = form.querySelector('[data-tunaipro-import-type]');
  const options = Array.from(form.querySelectorAll('[data-tunaipro-option]'));
  const refresh = () => {
    const type = select?.value || 'product';
    options.forEach((node) => { node.hidden = node.getAttribute('data-tunaipro-option') !== type; });
  };
  select?.addEventListener('change', refresh);
  refresh();
}

// v13.6.0 Media Attribution helpers
(() => {
  const initMarketingAttribution = () => {
    document.querySelectorAll('[data-copy-text]').forEach((button) => {
      if (button.dataset.copyBound === '1') return;
      button.dataset.copyBound = '1';
      button.addEventListener('click', async () => {
        const text = button.getAttribute('data-copy-text') || '';
        try {
          await navigator.clipboard.writeText(text);
          const old = button.textContent;
          button.textContent = '已复制';
          setTimeout(() => { button.textContent = old || '复制链接'; }, 1200);
        } catch {
          window.prompt('复制这个 Tracking Link：', text);
        }
      });
    });
    const syncMarketingAccountType = (select) => {
      if (!select) return;
      const form = select.closest('form');
      const field = form?.querySelector('[data-marketing-staff-field]');
      const staff = field?.querySelector('select');
      const show = select.value === 'staff';
      if (field) field.hidden = !show;
      if (staff) staff.required = show;
    };
    document.querySelectorAll('[data-marketing-account-type]').forEach((select) => {
      if (select.dataset.marketingBound === '1') return;
      select.dataset.marketingBound = '1';
      select.addEventListener('change', () => syncMarketingAccountType(select));
      syncMarketingAccountType(select);
    });
    if (document.body.dataset.marketingAccountModalBound !== '1') {
      document.body.dataset.marketingAccountModalBound = '1';
      document.addEventListener('click', (event) => {
        const opener = event.target.closest?.('[data-v1350-modal-open="marketing-account-editor"]');
        if (!opener) return;
        // The generic modal controller above resets and data-binds the form first.
        // Re-run the Staff field rule after those values have been injected.
        setTimeout(() => {
          const modal = document.querySelector('[data-v1350-modal="marketing-account-editor"]');
          syncMarketingAccountType(modal?.querySelector('[data-marketing-account-type]'));
        }, 0);
      });
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initMarketingAttribution);
  else initMarketingAttribution();
})();


// v13.6.10.12 Media Content + Tracking Link modal manager
(() => {
  const slugifyMarketing = (value) => String(value || '')
    .toLowerCase()
    .trim()
    .replace(/^@+/, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);

  const initMarketingTrackingCenter = () => {
    const modal = document.querySelector('[data-v1350-modal="marketing-tracking-editor"]');
    if (!modal || modal.dataset.trackingCenterBound === '1') return;
    modal.dataset.trackingCenterBound = '1';

    const form = modal.querySelector('[data-marketing-tracking-form]');
    if (!form) return;
    const account = form.querySelector('[data-marketing-tracking-account]');
    const channel = form.querySelector('[data-marketing-tracking-channel]');
    const staff = form.querySelector('[data-marketing-tracking-staff]');
    const type = form.querySelector('[data-marketing-content-type]');
    const label = form.querySelector('[data-marketing-content-label]');
    const slug = form.querySelector('[data-marketing-slug]');
    const slugPreview = form.querySelector('[data-marketing-slug-preview]');
    const destination = form.querySelector('[data-marketing-destination-type]');
    const contentFields = Array.from(form.querySelectorAll('[data-marketing-content-field]'));
    const whatsappFields = Array.from(form.querySelectorAll('[data-marketing-whatsapp-field]'));
    const urlFields = Array.from(form.querySelectorAll('[data-marketing-url-field]'));
    let slugTouched = false;

    const isEditing = () => Boolean(form.querySelector('[name="tracking_link_id"]')?.value);

    const selectedAccount = () => account?.selectedOptions?.[0] || null;

    const makeSuggestedSlug = () => {
      if (isEditing() || slugTouched || !slug) return;
      const opt = selectedAccount();
      const seed = opt?.dataset.accountSeed || opt?.textContent || '';
      const placement = type?.value || 'profile';
      const suffix = placement === 'profile' ? 'profile' : (label?.value || placement);
      const suggested = slugifyMarketing(`${seed}-${suffix}`);
      if (suggested) slug.value = suggested;
      if (slugPreview) slugPreview.textContent = slug.value || '...';
    };

    const syncAccount = () => {
      const opt = selectedAccount();
      if (!opt || !opt.value) return;
      if (opt.dataset.channelId && channel) channel.value = opt.dataset.channelId;
      if (opt.dataset.staffId && staff) staff.value = opt.dataset.staffId;
      makeSuggestedSlug();
    };

    const syncType = () => {
      const isProfile = (type?.value || 'profile') === 'profile';
      contentFields.forEach((node) => { node.hidden = isProfile; });
      if (label) label.required = !isProfile;
      makeSuggestedSlug();
    };

    const syncDestination = () => {
      const isWhatsapp = (destination?.value || 'whatsapp') === 'whatsapp';
      whatsappFields.forEach((node) => { node.hidden = !isWhatsapp; });
      urlFields.forEach((node) => { node.hidden = isWhatsapp; });
      const url = form.querySelector('[name="destination_url"]');
      if (url) url.required = !isWhatsapp;
    };

    account?.addEventListener('change', syncAccount);
    type?.addEventListener('change', syncType);
    label?.addEventListener('input', makeSuggestedSlug);
    destination?.addEventListener('change', syncDestination);
    slug?.addEventListener('input', () => {
      slugTouched = true;
      if (slugPreview) slugPreview.textContent = slug.value || '...';
    });

    document.addEventListener('click', (event) => {
      const opener = event.target.closest?.('[data-v1350-modal-open="marketing-tracking-editor"]');
      if (!opener) return;
      slugTouched = Boolean(opener.dataset.slug);
      setTimeout(() => {
        syncType();
        syncDestination();
        if (!isEditing()) syncAccount();
        if (slugPreview) slugPreview.textContent = slug?.value || '...';
      }, 0);
    });
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initMarketingTrackingCenter);
  else initMarketingTrackingCenter();
})();

// SalonOS v13.6.10.38 · In-page branch creation wizard.
(() => {
  const branchModal = () => document.querySelector('[data-v1338-branch-modal]');
  const formOf = (modal) => modal?.querySelector('[data-v1338-branch-form]');
  const fieldsForStep = (section) => Array.from(section?.querySelectorAll('input,select,textarea') || []).filter((el) => !el.disabled && el.type !== 'hidden');

  const updateSummary = (form) => {
    if (!form) return;
    form.querySelectorAll('[data-v1338-summary]').forEach((node) => {
      const name = node.getAttribute('data-v1338-summary');
      const field = form.elements.namedItem(name);
      const value = typeof field?.value === 'string' ? field.value.trim() : '';
      node.textContent = value || '—';
    });
  };

  const goStep = (modal, step) => {
    if (!modal) return;
    const form = formOf(modal);
    const normalized = Math.min(3, Math.max(1, Number(step) || 1));
    if (normalized === 1) {
      const confirmCheck = form?.querySelector('[data-v1338-confirm-check]');
      const submit = form?.querySelector('[data-v1338-branch-submit]');
      if (confirmCheck) confirmCheck.checked = false;
      if (submit) { submit.disabled = true; submit.textContent = '确认并建立分行'; }
    }
    modal.querySelectorAll('[data-v1338-branch-step]').forEach((section) => {
      section.hidden = Number(section.getAttribute('data-v1338-branch-step')) !== normalized;
    });
    modal.querySelectorAll('[data-v1338-step-dot]').forEach((dot) => {
      const n = Number(dot.getAttribute('data-v1338-step-dot'));
      dot.classList.toggle('is-active', n === normalized);
      dot.classList.toggle('is-done', n < normalized);
    });
    modal.dataset.v1338CurrentStep = String(normalized);
    if (normalized === 3) updateSummary(form);
    const scrollPane = modal.querySelector('.commission-modal-content');
    if (scrollPane) scrollPane.scrollTop = 0;
    setTimeout(() => modal.querySelector(`[data-v1338-branch-step="${normalized}"] input:not([type="hidden"]), [data-v1338-branch-step="${normalized}"] textarea`)?.focus({preventScroll:true}), 50);
  };

  const validateCurrent = (modal) => {
    const step = Number(modal?.dataset.v1338CurrentStep || '1');
    const section = modal?.querySelector(`[data-v1338-branch-step="${step}"]`);
    for (const field of fieldsForStep(section)) {
      if (field.type === 'checkbox') continue;
      if (!field.checkValidity()) { field.reportValidity(); field.focus(); return false; }
    }
    if (step === 2) {
      const form = formOf(modal);
      const password = form?.elements.namedItem('password')?.value || '';
      const confirm = form?.elements.namedItem('password_confirm')?.value || '';
      if (password !== confirm) {
        const target = form?.elements.namedItem('password_confirm');
        target?.setCustomValidity('两次输入的密码不一致。');
        target?.reportValidity();
        setTimeout(() => target?.setCustomValidity(''), 0);
        target?.focus();
        return false;
      }
    }
    return true;
  };

  document.addEventListener('click', (event) => {
    const opener = event.target.closest?.('[data-v1350-modal-open="branch-create"]');
    if (opener) setTimeout(() => goStep(branchModal(), 1), 0);

    const next = event.target.closest?.('[data-v1338-branch-next]');
    if (next) {
      const modal = next.closest('[data-v1338-branch-modal]');
      if (!validateCurrent(modal)) return;
      goStep(modal, Number(modal.dataset.v1338CurrentStep || '1') + 1);
      return;
    }
    const prev = event.target.closest?.('[data-v1338-branch-prev]');
    if (prev) {
      const modal = prev.closest('[data-v1338-branch-modal]');
      goStep(modal, Number(modal.dataset.v1338CurrentStep || '1') - 1);
      return;
    }
    const help = event.target.closest?.('[data-v1338-help-toggle]');
    if (help) {
      const field = help.closest('.field');
      const panel = field?.querySelector('[data-v1338-help-panel]');
      if (panel) {
        panel.hidden = !panel.hidden;
        help.setAttribute('aria-expanded', panel.hidden ? 'false' : 'true');
      }
    }
  });

  document.addEventListener('change', (event) => {
    if (event.target?.matches?.('[data-v1338-confirm-check]')) {
      const modal = event.target.closest('[data-v1338-branch-modal]');
      const submit = modal?.querySelector('[data-v1338-branch-submit]');
      if (submit) submit.disabled = !event.target.checked;
    }
  });

  document.addEventListener('submit', (event) => {
    const form = event.target.closest?.('[data-v1338-branch-form]');
    if (!form) return;
    const modal = form.closest('[data-v1338-branch-modal]');
    if (!form.checkValidity()) { event.preventDefault(); form.reportValidity(); return; }
    const password = form.elements.namedItem('password')?.value || '';
    const confirm = form.elements.namedItem('password_confirm')?.value || '';
    if (password !== confirm) { event.preventDefault(); goStep(modal,2); const target=form.elements.namedItem('password_confirm'); target?.setCustomValidity('两次输入的密码不一致。'); target?.reportValidity(); setTimeout(()=>target?.setCustomValidity(''),0); return; }
    const btn = form.querySelector('[data-v1338-branch-submit]');
    if (btn) { btn.disabled = true; btn.textContent = '正在建立分行…'; }
  });

  document.addEventListener('DOMContentLoaded', () => {
    const auto = document.querySelector('[data-v1338-auto-open-branch]');
    if (auto) auto.click();
    const modal = branchModal();
    const submit = modal?.querySelector('[data-v1338-branch-submit]');
    if (submit) submit.disabled = true;
  });
})();

// SalonOS v13.6.10.42 · Global navigation / submit loading guard.
(() => {
  const state = { visible: false, timer: null };
  const ensureLoader = () => {
    let loader = document.querySelector('[data-salonos-page-loader]');
    if (loader) return loader;
    loader = document.createElement('div');
    loader.className = 'salonos-page-loader';
    loader.setAttribute('data-salonos-page-loader', '');
    loader.setAttribute('aria-hidden', 'true');
    loader.innerHTML = '<div class="salonos-page-loader-card" role="status" aria-live="polite"><div class="salonos-page-loader-spinner" aria-hidden="true"></div><strong data-salonos-loader-title>正在载入…</strong><span data-salonos-loader-note>请稍候，不需要重复点击</span></div>';
    document.body.appendChild(loader);
    return loader;
  };
  const show = (title = '正在载入…', note = '请稍候，不需要重复点击') => {
    if (state.visible) return;
    const loader = ensureLoader();
    loader.querySelector('[data-salonos-loader-title]').textContent = title;
    loader.querySelector('[data-salonos-loader-note]').textContent = note;
    loader.setAttribute('aria-hidden', 'false');
    state.visible = true;
    requestAnimationFrame(() => loader.classList.add('is-visible'));
  };
  const hide = () => {
    const loader = document.querySelector('[data-salonos-page-loader]');
    if (!loader) return;
    loader.classList.remove('is-visible');
    loader.setAttribute('aria-hidden', 'true');
    state.visible = false;
    document.querySelectorAll('.salonos-nav-pending').forEach((node) => {
      node.classList.remove('salonos-nav-pending');
      node.removeAttribute('aria-disabled');
    });
  };
  const isPlainPrimaryClick = (event) => event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey;
  const shouldNavigate = (anchor) => {
    if (!anchor || anchor.hasAttribute('download') || anchor.target === '_blank') return false;
    if (anchor.dataset.noPageLoader !== undefined) return false;
    const raw = anchor.getAttribute('href') || '';
    if (!raw || raw.startsWith('#') || raw.startsWith('javascript:') || raw.startsWith('mailto:') || raw.startsWith('tel:')) return false;
    try {
      const url = new URL(anchor.href, location.href);
      if (url.origin !== location.origin) return false;
      if (url.href === location.href) return false;
      if (url.pathname === location.pathname && url.search === location.search && url.hash) return false;
      return true;
    } catch (_) { return false; }
  };
  document.addEventListener('click', (event) => {
    if (!isPlainPrimaryClick(event) || event.defaultPrevented) return;
    const anchor = event.target.closest?.('a[href]');
    if (!shouldNavigate(anchor)) return;
    anchor.classList.add('salonos-nav-pending');
    anchor.setAttribute('aria-disabled', 'true');
    show('正在切换页面…', '已收到你的操作，请不要重复点击');
  }, true);
  document.addEventListener('submit', (event) => {
    if (event.defaultPrevented) return;
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || form.dataset.noPageLoader !== undefined) return;
    if (form.target && form.target !== '_self') return;
    // AJAX-enhanced forms should opt out with data-no-page-loader.
    const submitter = event.submitter;
    if (submitter) {
      submitter.classList.add('salonos-nav-pending');
      submitter.setAttribute('aria-disabled', 'true');
    }
    show('正在处理…', '请稍候，不需要重复提交');
  }, false);
  window.addEventListener('pageshow', hide);
  window.addEventListener('pagehide', () => { if (state.timer) clearTimeout(state.timer); });
  window.addEventListener('load', hide, { once: true });
  window.SalonOSPageLoader = { show, hide };
})();

/* v13.6.10.54 · Social Inbox guided wizard */
(()=>{
  const root=document.querySelector('[data-social-hub]');
  if(!root)return;
  const wizard=document.querySelector('[data-v1350-modal="social-connect-wizard"]');
  let step=1, platform='instagram';
  const render=()=>{
    if(!wizard)return;
    wizard.querySelectorAll('[data-social-step]').forEach(el=>el.classList.toggle('is-active',Number(el.dataset.socialStep)===step));
    wizard.querySelectorAll('[data-social-step-button]').forEach(el=>el.classList.toggle('is-active',Number(el.dataset.socialStepButton)===step));
    const prev=wizard.querySelector('[data-social-prev]'),next=wizard.querySelector('[data-social-next]');
    if(prev)prev.disabled=step===1;
    if(next){next.disabled=step===5;next.textContent=step===5?'完成':'下一步';}
  };
  const setPlatform=(nextPlatform)=>{
    platform=nextPlatform==='facebook'?'facebook':'instagram';step=1;
    if(!wizard)return;
    const title=wizard.querySelector('[data-social-wizard-title]');if(title)title.textContent=platform==='facebook'?'连接 Facebook Messenger':'连接 Instagram Direct';
    const input=wizard.querySelector('[data-social-platform-input]');if(input)input.value=platform;
    const label=wizard.querySelector('[data-social-external-label]');if(label)label.textContent=platform==='facebook'?'Facebook Page ID *':'IG Business Account ID *';
    wizard.querySelectorAll('[data-social-copy]').forEach(el=>el.hidden=el.dataset.socialCopy!==platform);
    render();
  };
  document.querySelectorAll('[data-social-platform]').forEach(btn=>btn.addEventListener('click',()=>setPlatform(btn.dataset.socialPlatform)));
  wizard?.querySelectorAll('[data-social-step-button]').forEach(btn=>btn.addEventListener('click',()=>{step=Math.max(1,Math.min(5,Number(btn.dataset.socialStepButton)||1));render();}));
  wizard?.querySelector('[data-social-prev]')?.addEventListener('click',()=>{step=Math.max(1,step-1);render();});
  wizard?.querySelector('[data-social-next]')?.addEventListener('click',()=>{step=Math.min(5,step+1);render();});
  wizard?.querySelector('[data-social-open-tutorial]')?.addEventListener('click',()=>{
    const target=platform==='facebook'?'social-tutorial-facebook':'social-tutorial-instagram';
    wizard.querySelector('[data-v1350-modal-close]')?.click();
    setTimeout(()=>document.querySelector(`[data-v1350-modal-open="${target}"]`)?.click(),80);
  });
  document.addEventListener('click',async(e)=>{
    const btn=e.target.closest('[data-copy-text]');if(!btn)return;
    try{await navigator.clipboard.writeText(btn.dataset.copyText||'');const old=btn.textContent;btn.textContent='已复制';setTimeout(()=>btn.textContent=old,1200);}catch{btn.textContent='复制失败';}
  });
  render();
})();

// Remove only the specific local draft that the server confirmed.
(() => {
  const { completedVisitRequest: requestId, completedVisitDraft: key } = document.body?.dataset || {};
  if (!requestId || !key) return;
  try {
    const draft = JSON.parse(localStorage.getItem(key) || 'null');
    if (draft?.requestId === requestId) localStorage.removeItem(key);
    const url = new URL(location.href);
    url.searchParams.delete('order_created');
    history.replaceState(history.state, '', url.toString());
  } catch (_) {}
})();

/* v13.6.10.59 · Instant in-page category filtering (no layout change, no reload). */
(() => {
  const initInlineCategoryFilters = () => {
    document.querySelectorAll('[data-inline-category-nav]').forEach((nav) => {
      if (nav.dataset.inlineCategoryReady === '1') return;
      nav.dataset.inlineCategoryReady = '1';
      const group = nav.dataset.inlineCategoryNav || '';
      const content = document.querySelector(`[data-inline-category-content="${CSS.escape(group)}"]`);
      if (!content) return;
      const links = [...nav.querySelectorAll('[data-inline-category-filter]')];
      const items = [...content.querySelectorAll('[data-inline-category-item]')];
      const empty = content.querySelector('[data-inline-category-empty]');
      const title = content.querySelector('[data-inline-category-title]');
      const count = content.querySelector('[data-inline-category-count]');

      const apply = (categoryId, { updateUrl = false } = {}) => {
        const category = String(categoryId || '');
        let visible = 0;
        for (const item of items) {
          const matches = category === '' || String(item.dataset.inlineCategoryItem || '') === category;
          item.hidden = !matches;
          if (matches) visible += 1;
        }
        links.forEach((link) => link.classList.toggle('active', String(link.dataset.inlineCategoryFilter || '') === category));
        if (empty) empty.hidden = visible !== 0;
        if (count) count.textContent = document.documentElement.lang === 'en' ? `${visible} items` : `${visible} 项`;
        if (title) title.textContent = category === '' ? (title.dataset.titleAll || title.textContent) : (title.dataset.titleFiltered || title.textContent);
        if (updateUrl) {
          const active = links.find((link) => String(link.dataset.inlineCategoryFilter || '') === category);
          if (active?.href) history.pushState({ salonosInlineCategory: category }, '', active.href);
        }
      };

      nav.addEventListener('click', (event) => {
        const link = event.target.closest?.('[data-inline-category-filter]');
        if (!link || !nav.contains(link) || event.defaultPrevented) return;
        if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        apply(link.dataset.inlineCategoryFilter || '', { updateUrl: true });
      });

      const initial = new URL(location.href).searchParams.get('category_id') || '';
      apply(initial);
      window.addEventListener('popstate', () => {
        const next = new URL(location.href).searchParams.get('category_id') || '';
        apply(next);
      });
    });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initInlineCategoryFilters, { once: true });
  else initInlineCategoryFilters();
})();
