(() => {
  const scriptUrl = new URL(document.currentScript.src);
  const dictionaryUrl = new URL('i18n-en.json', scriptUrl);
  dictionaryUrl.search = scriptUrl.search;
  const ignoredTags = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'CODE', 'PRE', 'TEXTAREA']);
  const translatedAttributes = ['placeholder', 'title', 'aria-label', 'data-label', 'alt'];
  const cjk = /[\u3400-\u9fff]/;
  let exact = new Map();
  let phrases = [];

  const normalize = (value) => String(value ?? '').replace(/\u00a0/g, ' ');

  const translate = (value) => {
    const raw = normalize(value);
    if (!raw || !cjk.test(raw) || !exact.size) return raw;

    const leading = raw.match(/^\s*/)?.[0] || '';
    const trailing = raw.match(/\s*$/)?.[0] || '';
    const core = raw.slice(leading.length, raw.length - trailing.length);
    if (!core) return raw;

    // Prefer whole-string translations. This avoids the old v13.6.10.47 issue where
    // single Chinese characters were replaced one by one and produced mixed-language UI.
    const direct = exact.get(core);
    if (direct) return leading + direct + trailing;

    let output = core;
    for (const [source, target] of phrases) {
      if (output.includes(source)) output = output.split(source).join(target);
    }
    return leading + output + trailing;
  };

  const translateElementAttributes = (element) => {
    if (!(element instanceof Element) || ignoredTags.has(element.tagName)) return;
    if (element.closest('[data-i18n-skip]')) return;
    translatedAttributes.forEach((name) => {
      const value = element.getAttribute(name);
      if (value && cjk.test(value)) element.setAttribute(name, translate(value));
    });
    if (element instanceof HTMLInputElement && ['button', 'submit', 'reset'].includes(element.type)) {
      element.value = translate(element.value);
    }
  };

  const translateNode = (node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const parent = node.parentElement;
      if (!parent || ignoredTags.has(parent.tagName) || parent.closest('[data-i18n-skip]')) return;
      const translated = translate(node.nodeValue || '');
      if (translated !== node.nodeValue) node.nodeValue = translated;
      return;
    }
    if (!(node instanceof Element) || ignoredTags.has(node.tagName) || node.closest('[data-i18n-skip]')) return;
    translateElementAttributes(node);
    const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    let current = walker.currentNode;
    while (current) {
      if (current.nodeType === Node.TEXT_NODE) {
        const parent = current.parentElement;
        if (parent && !ignoredTags.has(parent.tagName) && !parent.closest('[data-i18n-skip]')) {
          const translated = translate(current.nodeValue || '');
          if (translated !== current.nodeValue) current.nodeValue = translated;
        }
      } else if (current instanceof Element) {
        translateElementAttributes(current);
      }
      current = walker.nextNode();
    }
  };

  const installDialogTranslation = () => {
    const nativeAlert = window.alert.bind(window);
    const nativeConfirm = window.confirm.bind(window);
    const nativePrompt = window.prompt.bind(window);
    window.alert = (message) => nativeAlert(translate(String(message ?? '')));
    window.confirm = (message) => nativeConfirm(translate(String(message ?? '')));
    window.prompt = (message, defaultValue) => nativePrompt(translate(String(message ?? '')), defaultValue);
    window.SalonI18n = { translate, refresh: () => translateNode(document.documentElement) };
  };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  fetch(dictionaryUrl, { credentials: 'same-origin', signal: controller.signal })
    .then((response) => {
      if (!response.ok) throw new Error('Unable to load language dictionary.');
      return response.json();
    })
    .then((dictionary) => {
      const pairs = Object.entries(dictionary).filter(([source, target]) =>
        source && target && cjk.test(source) && !cjk.test(String(target))
      );
      if (!pairs.length) throw new Error('Language dictionary is empty.');
      exact = new Map(pairs.map(([source, target]) => [source.trim(), String(target)]));
      // Phrase fallback is only for 2+ character Chinese phrases. Never translate isolated
      // characters because that was the main cause of mixed Chinese/English fragments.
      phrases = pairs
        .filter(([source]) => source.trim().length >= 2)
        .map(([source, target]) => [source, String(target)])
        .sort((a, b) => b[0].length - a[0].length);

      document.documentElement.lang = 'en';
      installDialogTranslation();
      translateNode(document.documentElement);
      const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (mutation.type === 'characterData') translateNode(mutation.target);
          if (mutation.type === 'attributes') translateElementAttributes(mutation.target);
          mutation.addedNodes.forEach(translateNode);
        }
      });
      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: translatedAttributes,
      });
      document.documentElement.classList.replace('i18n-booting', 'i18n-en-ready');
    })
    .catch((error) => {
      document.documentElement.classList.add('i18n-error');
      console.warn('[SalonOS i18n]', error);
    })
    .finally(() => clearTimeout(timeout));
})();
