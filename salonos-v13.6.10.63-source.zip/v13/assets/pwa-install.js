(() => {
  const script = document.currentScript;
  const config = {
    name: script?.dataset.pwaName || 'SalonOS',
    sw: script?.dataset.pwaSw || 'sw.js',
    scope: script?.dataset.pwaScope || './',
    icon: script?.dataset.pwaIcon || 'assets/icons/icon-192.png',
    theme: script?.dataset.pwaTheme || 'app',
    versionUrl: script?.dataset.pwaVersionUrl || 'version.php'
  };

  const start = () => {
    document.body.dataset.pwaTheme = config.theme;
    const standalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;

    // SalonOS behaves like an app when installed: keep one-finger scrolling,
    // but block pinch/double-tap page zoom. This only activates in standalone PWA mode.
    if (standalone) {
      document.documentElement.classList.add('pwa-standalone');
      const preventGesture = (event) => event.preventDefault();
      document.addEventListener('gesturestart', preventGesture, { passive: false });
      document.addEventListener('gesturechange', preventGesture, { passive: false });
      document.addEventListener('gestureend', preventGesture, { passive: false });
      document.addEventListener('touchmove', (event) => {
        if (event.touches && event.touches.length > 1) event.preventDefault();
      }, { passive: false });
      let lastTouchEnd = 0;
      document.addEventListener('touchend', (event) => {
        const now = Date.now();
        if (now - lastTouchEnd <= 300) event.preventDefault();
        lastTouchEnd = now;
      }, { passive: false });
    }

    if ('serviceWorker' in navigator) {
      let reloadingForUpdate = false;
      let dirty = false;
      const markDirty = (event) => {
        const target = event.target;
        if (target && target.closest && target.closest('form')) dirty = true;
      };
      document.addEventListener('input', markDirty, true);
      document.addEventListener('change', markDirty, true);
      document.addEventListener('submit', () => { dirty = false; }, true);

      const safeToReload = () => !dirty && !document.querySelector('[data-prevent-auto-update="1"]');
      const versionUrl = new URL(config.versionUrl, document.baseURI).toString();
      let registration = null;
      let lastFingerprint = localStorage.getItem('salonos-build-fingerprint') || '';
      let lastVersion = localStorage.getItem('salonos-build-version') || '';
      let pendingFingerprint = '';
      let pendingVersion = '';
      const transitionKey = 'salonos-version-update-transition';

      const ensureUpdateUi = () => {
        let layer = document.getElementById('salonos-version-update-layer');
        if (layer) return layer;
        const style = document.createElement('style');
        style.id = 'salonos-version-update-style';
        style.textContent = `
          #salonos-version-update-layer{position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;padding:max(22px,env(safe-area-inset-top)) 22px max(22px,env(safe-area-inset-bottom));background:rgba(3,8,13,.88);backdrop-filter:blur(18px) saturate(1.15);-webkit-backdrop-filter:blur(18px) saturate(1.15);font-family:inherit;color:#f7f8fb}
          #salonos-version-update-layer[hidden]{display:none!important}
          .salonos-update-card{width:min(430px,100%);border:1px solid rgba(233,190,116,.22);border-radius:28px;padding:28px;background:linear-gradient(145deg,rgba(17,27,38,.98),rgba(8,14,21,.98));box-shadow:0 30px 100px rgba(0,0,0,.55),0 0 52px rgba(221,171,89,.10);text-align:center}
          .salonos-update-mark{width:64px;height:64px;margin:0 auto 19px;border-radius:20px;display:grid;place-items:center;background:linear-gradient(135deg,#b97b2e,#ffd793);box-shadow:0 14px 38px rgba(220,163,72,.26);color:#111820;font-size:30px;font-weight:900}
          .salonos-update-kicker{font-size:11px;letter-spacing:.2em;text-transform:uppercase;color:#e5b667;font-weight:800;margin-bottom:9px}
          .salonos-update-card h2{margin:0;font-size:24px;line-height:1.2;color:#fff}
          .salonos-update-card p{margin:12px auto 0;color:#9eabb9;font-size:14px;line-height:1.7;max-width:340px}
          .salonos-update-version{display:flex;justify-content:center;align-items:center;gap:10px;margin:20px 0 18px;font-size:12px;color:#738190}
          .salonos-update-version strong{color:#f0c77e;font-size:13px}
          .salonos-update-progress{height:5px;overflow:hidden;border-radius:999px;background:rgba(255,255,255,.07);position:relative}
          .salonos-update-progress::after{content:"";position:absolute;inset:0 auto 0 -35%;width:35%;border-radius:inherit;background:linear-gradient(90deg,transparent,#efbd6c,#fff0c8,transparent);animation:salonos-update-slide 1.15s ease-in-out infinite}
          .salonos-update-note{margin-top:15px!important;font-size:12px!important;color:#758391!important}
          @keyframes salonos-update-slide{0%{left:-35%}100%{left:105%}}
          @media(max-width:520px){.salonos-update-card{border-radius:24px;padding:24px 20px}.salonos-update-card h2{font-size:22px}}
          @media(prefers-reduced-motion:reduce){.salonos-update-progress::after{animation-duration:2.5s}}
        `;
        document.head.appendChild(style);
        layer = document.createElement('div');
        layer.id = 'salonos-version-update-layer';
        layer.hidden = true;
        layer.setAttribute('role','status');
        layer.setAttribute('aria-live','polite');
        layer.innerHTML = `<section class="salonos-update-card">
          <div class="salonos-update-mark">↻</div>
          <div class="salonos-update-kicker">SYSTEM UPDATE</div>
          <h2 data-update-title>SalonOS 正在更新</h2>
          <p data-update-copy>检测到新版本，正在同步最新界面与系统文件。</p>
          <div class="salonos-update-version"><span data-update-from></span><span data-update-arrow>→</span><strong data-update-to></strong></div>
          <div class="salonos-update-progress" aria-hidden="true"></div>
          <p class="salonos-update-note" data-update-note>请稍候，不需要重复点击或重新打开 App。</p>
        </section>`;
        document.body.appendChild(layer);
        return layer;
      };

      const showUpdateUi = (fromVersion = '', toVersion = '', completing = false) => {
        const layer = ensureUpdateUi();
        const english = (document.documentElement.lang || '').toLowerCase().startsWith('en');
        const title = layer.querySelector('[data-update-title]');
        const copy = layer.querySelector('[data-update-copy]');
        const note = layer.querySelector('[data-update-note]');
        const from = layer.querySelector('[data-update-from]');
        const to = layer.querySelector('[data-update-to]');
        const arrow = layer.querySelector('[data-update-arrow]');
        if (title) title.textContent = english ? (completing ? 'Finishing update' : 'Updating SalonOS') : (completing ? '正在完成版本更新' : 'SalonOS 正在更新');
        if (copy) copy.textContent = english ? 'Syncing the latest interface and system files.' : '检测到新版本，正在同步最新界面与系统文件。';
        if (note) note.textContent = english ? 'Please wait. No need to tap again or reopen the app.' : '请稍候，不需要重复点击或重新打开 App。';
        if (from) from.textContent = fromVersion || '';
        if (to) to.textContent = toVersion || (english ? 'Latest' : '最新版');
        const showPair = Boolean(fromVersion || toVersion);
        if (from) from.hidden = !showPair;
        if (to) to.hidden = !showPair;
        if (arrow) arrow.hidden = !showPair;
        layer.hidden = false;
        document.documentElement.setAttribute('data-salonos-updating','1');
      };

      const hideUpdateUi = () => {
        const layer = document.getElementById('salonos-version-update-layer');
        if (layer) layer.hidden = true;
        document.documentElement.removeAttribute('data-salonos-updating');
      };

      // If the previous page initiated an update, keep visible feedback across the reload.
      try {
        const transition = JSON.parse(sessionStorage.getItem(transitionKey) || 'null');
        if (transition && transition.startedAt && Date.now() - Number(transition.startedAt) < 45000) {
          showUpdateUi(String(transition.from || ''), String(transition.to || ''), true);
          window.addEventListener('load', () => {
            window.setTimeout(() => {
              sessionStorage.removeItem(transitionKey);
              hideUpdateUi();
            }, 900);
          }, { once:true });
        } else {
          sessionStorage.removeItem(transitionKey);
        }
      } catch (_) { sessionStorage.removeItem(transitionKey); }

      const beginVersionTransition = (fromVersion, toVersion) => {
        if (!safeToReload() || reloadingForUpdate) return false;
        reloadingForUpdate = true;
        showUpdateUi(fromVersion, toVersion, false);
        try {
          sessionStorage.setItem(transitionKey, JSON.stringify({from:fromVersion || '', to:toVersion || '', startedAt:Date.now()}));
        } catch (_) {}
        return true;
      };

      const applyUpdateWhenSafe = async () => {
        if ((!pendingFingerprint && !pendingVersion) || !safeToReload() || reloadingForUpdate) return;
        const fromVersion = lastVersion;
        const toVersion = pendingVersion || lastVersion;
        if (!beginVersionTransition(fromVersion, toVersion)) return;
        if (pendingFingerprint) localStorage.setItem('salonos-build-fingerprint', pendingFingerprint);
        if (pendingVersion) localStorage.setItem('salonos-build-version', pendingVersion);
        lastFingerprint = pendingFingerprint || lastFingerprint;
        lastVersion = pendingVersion || lastVersion;
        try { await registration?.update(); } catch (_) {}
        if (registration?.waiting) {
          try { registration.waiting.postMessage({type:'SKIP_WAITING'}); } catch (_) {}
        }
        // Give a newly installed worker a short moment to activate, but never leave the user waiting indefinitely.
        window.setTimeout(() => window.location.reload(), 650);
      };

      const checkBuild = async () => {
        try {
          const response = await fetch(versionUrl + '?ts=' + Date.now(), {cache:'no-store', credentials:'same-origin'});
          if (!response.ok) return;
          const info = await response.json();
          const fingerprint = String(info.fingerprint || '');
          const version = String(info.version || '');
          if (!fingerprint && !version) return;

          // First run after this update mechanism was introduced: preserve an old fingerprint if one exists,
          // so an already-updated client can still detect the release currently on the server.
          if (!lastFingerprint && !lastVersion) {
            lastFingerprint = fingerprint;
            lastVersion = version;
            if (fingerprint) localStorage.setItem('salonos-build-fingerprint', fingerprint);
            if (version) localStorage.setItem('salonos-build-version', version);
            return;
          }

          const changed = (fingerprint && fingerprint !== lastFingerprint) || (version && lastVersion && version !== lastVersion);
          if (changed) {
            pendingFingerprint = fingerprint;
            pendingVersion = version;
            if (registration?.waiting) registration.waiting.postMessage({type:'SKIP_WAITING'});
            await applyUpdateWhenSafe();
            return;
          }

          // Migration path for clients coming from the older silent-update mechanism.
          // The legacy script may already have stored the new fingerprint before this script loads,
          // so show one short completion state once instead of making the first UX upgrade invisible.
          if (!lastVersion && version) {
            const legacyHadFingerprint = Boolean(lastFingerprint);
            lastVersion = version;
            localStorage.setItem('salonos-build-version', version);
            if (legacyHadFingerprint && !sessionStorage.getItem('salonos-version-ui-migrated')) {
              sessionStorage.setItem('salonos-version-ui-migrated','1');
              showUpdateUi('', version, true);
              window.setTimeout(hideUpdateUi, 1100);
            }
          }
        } catch (_) {}
      };

      navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (reloadingForUpdate || !safeToReload()) return;
        if (!beginVersionTransition(lastVersion, pendingVersion || '')) return;
        window.setTimeout(() => window.location.reload(), 450);
      });

      navigator.serviceWorker.register(config.sw, { scope: config.scope, updateViaCache:'none' }).then((reg) => {
        registration = reg;
        reg.update().catch(() => {});
        reg.addEventListener('updatefound', () => {
          const worker = reg.installing;
          if (!worker) return;
          worker.addEventListener('statechange', () => {
            if (worker.state === 'installed' && navigator.serviceWorker.controller) {
              try { worker.postMessage({type:'SKIP_WAITING'}); } catch (_) {}
              // checkBuild owns the reload so the user gets a visible release transition instead of a silent refresh.
              checkBuild();
            }
          });
        });
        checkBuild();
        window.setInterval(() => { reg.update().catch(() => {}); checkBuild(); }, 120000);
        window.addEventListener('focus', () => { reg.update().catch(() => {}); checkBuild(); applyUpdateWhenSafe(); });
        document.addEventListener('visibilitychange', () => {
          if (!document.hidden) { reg.update().catch(() => {}); checkBuild(); applyUpdateWhenSafe(); }
        });
      }).catch((error) => {
        console.warn('SalonOS PWA service worker registration failed:', error);
      });
    }

    if (standalone) return;

    const lang = (document.documentElement.lang || 'zh').toLowerCase();
    const english = lang.startsWith('en');
    const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const text = english ? {
      eyebrow: 'INSTALL APP', title: `Install ${config.name}`, body: 'Open the system from your home screen with a full-screen app experience.',
      fast: 'Faster access', fastSub: 'Launch directly from the icon', secure: 'Same secure login', secureSub: 'Roles and device authorization remain active', updates: 'Automatic updates', updatesSub: 'New interface files refresh automatically',
      install: 'Install app', later: 'Not now', trigger: 'Install', iosTitle: 'Add to the iPhone home screen', ios1: 'Tap the Share button in Safari.', ios2: 'Choose “Add to Home Screen”.', ios3: 'Tap “Add” in the top-right corner.',
      generic: 'Use the browser menu and choose Install app or Add to Home Screen.', note: 'The browser and device will always ask for your confirmation. The website cannot install silently.'
    } : {
      eyebrow: '安装 APP', title: `安装 ${config.name}`, body: '从主屏幕图标直接打开，以全屏 App 方式使用系统。',
      fast: '更快进入', fastSub: '点击图标直接启动', secure: '保留安全登录', secureSub: '角色与设备授权继续生效', updates: '自动更新', updatesSub: '新版界面文件会自动刷新',
      install: '安装 App', later: '稍后再说', trigger: '安装 App', iosTitle: '添加到 iPhone 主屏幕', ios1: '在 Safari 底部点击“分享”按钮。', ios2: '选择“添加到主屏幕”。', ios3: '点击右上角“添加”。',
      generic: '请打开浏览器菜单，选择“安装应用”或“添加到主屏幕”。', note: '浏览器与手机系统仍会要求本人确认，网页不会静默安装。'
    };

    let deferredPrompt = null;
    let mode = isIOS ? 'ios' : 'generic';
    const autoInviteKey = `salonos-pwa-invite-${config.theme}`;
    let shown = sessionStorage.getItem(autoInviteKey) === '1';

    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'pwa-install-trigger';
    trigger.innerHTML = `<img src="${config.icon}" alt=""><span>${text.trigger}</span>`;
    trigger.hidden = true;

    const layer = document.createElement('div');
    layer.className = 'pwa-install-layer';
    layer.hidden = true;
    layer.innerHTML = `
      <section class="pwa-install-sheet" role="dialog" aria-modal="true" aria-labelledby="pwa-install-title">
        <div class="pwa-install-hero">
          <img class="pwa-install-icon" src="${config.icon}" alt="${config.name}">
          <div class="pwa-install-copy"><span>${text.eyebrow}</span><h2 id="pwa-install-title">${text.title}</h2><p>${text.body}</p></div>
          <button class="pwa-install-close" type="button" aria-label="Close">×</button>
        </div>
        <div class="pwa-install-benefits">
          <div><strong>${text.fast}</strong><small>${text.fastSub}</small></div>
          <div><strong>${text.secure}</strong><small>${text.secureSub}</small></div>
          <div><strong>${text.updates}</strong><small>${text.updatesSub}</small></div>
        </div>
        <div class="pwa-install-ios" hidden><h3>${text.iosTitle}</h3><ol><li>${text.ios1}</li><li>${text.ios2}</li><li>${text.ios3}</li></ol></div>
        <div class="pwa-install-actions"><button class="pwa-install-secondary" type="button">${text.later}</button><button class="pwa-install-primary" type="button">${text.install}</button></div>
        <div class="pwa-install-note">${text.note}</div>
      </section>`;

    const close = () => {
      layer.hidden = true;
      document.documentElement.style.overflow = '';
      trigger.hidden = false;
    };

    const open = (nextMode = mode) => {
      mode = nextMode;
      const iosPanel = layer.querySelector('.pwa-install-ios');
      const primary = layer.querySelector('.pwa-install-primary');
      if (iosPanel) iosPanel.hidden = mode !== 'ios';
      if (primary) primary.textContent = mode === 'ios' ? (english ? 'Show steps' : '查看安装步骤') : text.install;
      layer.hidden = false;
      trigger.hidden = true;
      document.documentElement.style.overflow = 'hidden';
      shown = true;
      sessionStorage.setItem(autoInviteKey, '1');
    };

    layer.querySelector('.pwa-install-close')?.addEventListener('click', close);
    layer.querySelector('.pwa-install-secondary')?.addEventListener('click', close);
    layer.addEventListener('click', (event) => { if (event.target === layer) close(); });
    trigger.addEventListener('click', () => open(mode));

    layer.querySelector('.pwa-install-primary')?.addEventListener('click', async () => {
      if (deferredPrompt) {
        const prompt = deferredPrompt;
        deferredPrompt = null;
        await prompt.prompt();
        const result = await prompt.userChoice;
        if (result.outcome === 'accepted') {
          layer.hidden = true;
          trigger.hidden = true;
          document.documentElement.style.overflow = '';
        } else {
          close();
        }
        return;
      }
      if (mode === 'ios') {
        layer.querySelector('.pwa-install-ios')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      window.alert(text.generic);
    });

    document.body.append(trigger, layer);

    window.addEventListener('beforeinstallprompt', (event) => {
      event.preventDefault();
      deferredPrompt = event;
      mode = 'native';
      trigger.hidden = false;
      if (!shown) setTimeout(() => open('native'), 450);
    });

    window.addEventListener('appinstalled', () => {
      deferredPrompt = null;
      layer.hidden = true;
      trigger.hidden = true;
      document.documentElement.style.overflow = '';
    });

    // iOS cannot invoke a native install prompt, so immediately show the visual tutorial.
    if (isIOS) {
      trigger.hidden = false;
      setTimeout(() => { if (!shown) open('ios'); }, 700);
    } else {
      // Firefox/Safari desktop and Chromium devices that do not emit the event still get a useful invitation.
      setTimeout(() => {
        if (!shown && !deferredPrompt) {
          trigger.hidden = false;
          open('generic');
        }
      }, 1700);
    }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();
