(() => {
  const state = {
    ready: false,
    session: null,
    context: null,
    lastTest: null
  };

  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  async function getClient(timeoutMs = 7000) {
    const started = Date.now();
    while (!window.salonSupabase && Date.now() - started < timeoutMs) {
      await wait(60);
    }
    if (!window.salonSupabase) throw new Error('Supabase client is unavailable.');
    state.ready = true;
    return window.salonSupabase;
  }

  function setStatus(text, kind = '') {
    document.querySelectorAll('[data-supabase-status]').forEach((node) => {
      node.textContent = text;
      node.dataset.state = kind;
    });
  }

  async function refreshSession() {
    try {
      const client = await getClient();
      const { data, error } = await client.auth.getSession();
      if (error) throw error;
      state.session = data.session || null;
      if (state.session?.user?.email) {
        setStatus(`Supabase 已登录：${state.session.user.email}`, 'connected');
      } else {
        state.context = null;
        window.SalonOSContext = null;
        setStatus('Supabase 尚未登录', 'idle');
      }
      return state.session;
    } catch (error) {
      setStatus('Supabase 暂时不可用', 'error');
      console.warn('[SalonOS Supabase] Session check failed:', error);
      return null;
    }
  }

  async function loadUserContext() {
    const client = await getClient();
    const session = state.session || await refreshSession();
    const user = session?.user;
    if (!user?.id) throw new Error('Supabase session is missing.');

    const memberResult = await client
      .from('organization_members')
      .select('organization_id,role,status')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .limit(1)
      .maybeSingle();
    if (memberResult.error) throw memberResult.error;
    if (!memberResult.data) throw new Error('这个账号没有有效的 SalonOS Organization 权限。');

    const organizationId = memberResult.data.organization_id;
    const [organizationResult, storesResult, profileResult] = await Promise.all([
      client.from('organizations').select('id,name,status').eq('id', organizationId).maybeSingle(),
      client.from('stores').select('id,organization_id,name,code,is_main,status').eq('organization_id', organizationId).eq('status', 'active').order('is_main', { ascending: false }).order('name'),
      client.from('profiles').select('id,full_name,phone').eq('id', user.id).maybeSingle()
    ]);

    const errors = [organizationResult.error, storesResult.error, profileResult.error].filter(Boolean);
    if (errors.length) throw errors[0];
    if (!organizationResult.data) throw new Error('找不到 SalonOS Organization。');

    const context = {
      user: { id: user.id, email: user.email || '' },
      membership: memberResult.data,
      organization: organizationResult.data,
      stores: storesResult.data || [],
      profile: profileResult.data || null,
      primaryStore: (storesResult.data || [])[0] || null
    };

    state.context = context;
    window.SalonOSContext = context;
    console.info('[SalonOS Supabase] User context ready:', context);
    return context;
  }

  async function signInOwner(email, password) {
    const client = await getClient();
    const { data, error } = await client.auth.signInWithPassword({ email, password });
    if (error) throw error;
    state.session = data.session || null;
    if (!state.session) throw new Error('Supabase 没有返回登录 Session。');

    // Public Creator-code registrations authenticate with Supabase, but their
    // Organization/tenant mapping is authoritative in the SalonOS Creator control DB.
    // Do NOT block the browser here just because organization_members has no row.
    // PHP will verify the access token again server-side and resolve either the
    // Supabase organization membership OR the Creator-controlled public owner record.
    let context = null;
    try {
      context = await loadUserContext();
      if (context?.membership?.role && context.membership.role !== 'owner') {
        await client.auth.signOut().catch(() => {});
        state.session = null;
        state.context = null;
        throw new Error(`老板入口只允许 Owner。当前角色：${context.membership.role}`);
      }
      setStatus(`Supabase Owner 已验证：${context?.organization?.name || email}`, 'connected');
    } catch (contextError) {
      console.info('[SalonOS Supabase] No browser organization context; handing authenticated session to Creator-controlled PHP validation.', contextError);
      context = {
        user: { id: data.user?.id || '', email: data.user?.email || email },
        membership: null,
        organization: null,
        stores: [],
        profile: null,
        primaryStore: null,
        creatorControlled: true
      };
      state.context = context;
      window.SalonOSContext = context;
      setStatus('Supabase 身份已验证，正在由 SalonOS Creator 验证老板权限…', 'connected');
    }

    return { ...data, context };
  }

  async function signOut() {
    const client = await getClient();
    const { error } = await client.auth.signOut();
    if (error) throw error;
    state.session = null;
    state.context = null;
    window.SalonOSContext = null;
    setStatus('Supabase 已退出', 'idle');
  }

  async function testTenantIsolation() {
    const client = await getClient();
    const [organizations, stores, customers] = await Promise.all([
      client.from('organizations').select('id,name,status').order('name'),
      client.from('stores').select('id,organization_id,name,code,is_main,status').order('name'),
      client.from('customers').select('id,organization_id,store_id,name,phone,gender').order('name')
    ]);

    const errors = [organizations.error, stores.error, customers.error].filter(Boolean);
    if (errors.length) throw errors[0];

    const result = {
      organizations: organizations.data || [],
      stores: stores.data || [],
      customers: customers.data || []
    };
    state.lastTest = result;
    console.info('[SalonOS Supabase] RLS test result:', result);
    return result;
  }

  function postSessionToPhp(form, session) {
    const tokenInput = form.querySelector('[data-supabase-access-token]');
    const actionInput = form.querySelector('[data-owner-login-action]');
    if (!tokenInput || !actionInput) throw new Error('Owner login form is missing Supabase fields.');
    if (!session?.access_token) throw new Error('Supabase access token is missing.');

    tokenInput.value = session.access_token;
    actionInput.value = 'supabase_owner_login';
    form.dataset.supabaseSubmitReady = '1';
    HTMLFormElement.prototype.submit.call(form);
  }

  function wireOwnerLogin() {
    const form = document.querySelector('.owner-login-form');
    if (!form || form.dataset.supabaseBridgeBound === '1') return;
    form.dataset.supabaseBridgeBound = '1';

    form.addEventListener('submit', async (event) => {
      if (form.dataset.supabaseSubmitReady === '1') return;
      event.preventDefault();

      const email = form.querySelector('input[name="identifier"]')?.value?.trim() || '';
      const password = form.querySelector('input[name="password"]')?.value || '';
      const button = form.querySelector('button[type="submit"]');
      const originalText = button?.textContent || '老板登录 →';

      if (!email || !password) {
        setStatus('请输入老板邮箱和密码。', 'error');
        return;
      }

      if (button) {
        button.disabled = true;
        button.textContent = '正在验证 Supabase…';
      }
      setStatus('正在通过 Supabase 验证 Owner 身份…', 'loading');

      try {
        const result = await signInOwner(email, password);
        if (button) button.textContent = 'Owner 已验证，正在进入…';
        postSessionToPhp(form, result.session);
      } catch (error) {
        console.error('[SalonOS Supabase] Owner login failed:', error);
        const message = error?.message || 'Supabase 登录失败';
        setStatus(`Supabase 登录失败：${message}`, 'error');
        if (button) {
          button.disabled = false;
          button.textContent = originalText;
        }
      }
    });
  }

  function wireLogout() {
    document.querySelectorAll('[data-supabase-logout]').forEach((link) => {
      if (link.dataset.supabaseLogoutBound === '1') return;
      link.dataset.supabaseLogoutBound = '1';
      link.addEventListener('click', async (event) => {
        event.preventDefault();
        const href = link.href;
        try {
          await Promise.race([
            signOut(),
            new Promise((resolve) => setTimeout(resolve, 2500))
          ]);
        } catch (error) {
          console.warn('[SalonOS Supabase] Browser sign-out failed; local logout will continue.', error);
        }
        window.location.href = href;
      });
    });
  }

  async function handleSignedOutReturn() {
    const url = new URL(window.location.href);
    if (url.searchParams.get('signed_out') !== '1') return false;
    try {
      await signOut();
    } catch (error) {
      console.warn('[SalonOS Supabase] Sign-out cleanup skipped:', error);
    }
    url.searchParams.delete('signed_out');
    history.replaceState({}, '', `${url.pathname}${url.search}${url.hash}`);
    return true;
  }

  async function autoHandoffExistingOwnerSession() {
    const form = document.querySelector('.owner-login-form');
    if (!form) return;
    const url = new URL(window.location.href);
    if (url.searchParams.get('supabase_error') === '1') return;

    const session = await refreshSession();
    if (!session?.access_token) return;

    try {
      const context = await loadUserContext();
      if (context.membership?.role !== 'owner') return;
      setStatus(`已找到 Owner Session：${context.organization?.name || session.user?.email || ''}，正在进入…`, 'connected');
      postSessionToPhp(form, session);
    } catch (error) {
      console.warn('[SalonOS Supabase] Existing session handoff skipped:', error);
      setStatus(`现有 Supabase Session 无法进入：${error?.message || 'unknown error'}`, 'warning');
    }
  }

  window.SalonOSSupabase = {
    state,
    getClient,
    getSession: refreshSession,
    loadUserContext,
    signInOwner,
    signOut,
    testTenantIsolation
  };

  document.addEventListener('DOMContentLoaded', async () => {
    wireOwnerLogin();
    wireLogout();

    const justSignedOut = await handleSignedOutReturn();
    if (justSignedOut) return;

    const session = await refreshSession();
    if (session) {
      loadUserContext().catch((error) => {
        console.warn('[SalonOS Supabase] Context load failed:', error);
      });
    }

    autoHandoffExistingOwnerSession();
  });
})();
