(() => {
  const config = window.SALONOS_SUPABASE_CONFIG;

  function fail(message, detail) {
    console.warn('[SalonOS Supabase]', message, detail || '');
    window.salonSupabase = null;
    window.dispatchEvent(new CustomEvent('salonos:supabase-ready', {
      detail: { ok: false, message, detail }
    }));
  }

  if (!config || !config.url || !config.publishableKey) {
    fail('Supabase config is missing.');
    return;
  }

  if (!window.supabase || typeof window.supabase.createClient !== 'function') {
    fail('Supabase JS library did not load. The local SalonOS app will continue to work, but cloud sync is unavailable.');
    return;
  }

  try {
    window.salonSupabase = window.supabase.createClient(
      config.url,
      config.publishableKey,
      {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true,
          storageKey: 'salonos-supabase-auth'
        }
      }
    );

    window.dispatchEvent(new CustomEvent('salonos:supabase-ready', {
      detail: { ok: true }
    }));
    console.info('[SalonOS Supabase] Client ready.');
  } catch (error) {
    fail('Failed to initialize Supabase client.', error);
  }
})();
