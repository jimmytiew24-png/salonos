// SalonOS Supabase browser configuration.
// Publishable keys are designed for client-side use; never put a secret/service-role key here.
window.SALONOS_SUPABASE_CONFIG = Object.freeze({
  url: 'https://YOUR_PROJECT.supabase.co',
  publishableKey: 'YOUR_PUBLISHABLE_KEY'
});
