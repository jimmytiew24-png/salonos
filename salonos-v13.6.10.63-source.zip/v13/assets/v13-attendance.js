(()=>{
  'use strict';
  const root=document.querySelector('[data-attendance-root]');
  if(!root)return;
  const csrf=root.dataset.csrf||'';
  let scanner=null,scanBusy=false,qrTimer=null,countTimer=null,qrAction='in',countdown=15;
  const post=async(payload)=>{
    const body=new URLSearchParams({csrf,action:'attendance_ajax_v1361039',...payload});
    const res=await fetch('index.php?page=attendance',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8','X-Requested-With':'XMLHttpRequest'},body:body.toString(),credentials:'same-origin'});
    const data=await res.json().catch(()=>({success:false,message:'服务器返回无法解析。'}));
    if(!res.ok||!data.success)throw new Error(data.message||'操作失败');return data.data||data;
  };
  const toast=(text,bad=false)=>{if(typeof window.showToast==='function')window.showToast(text,bad?'error':'success');else alert(text);};
  const tokenFromText=(text)=>{try{const u=new URL(text,location.href);return u.searchParams.get('scan_token')||text;}catch(_){return text.replace(/^SALONOS-ATTENDANCE:/,'').trim();}};

  const station=document.querySelector('[data-attendance-qr-station]');
  const box=document.querySelector('[data-attendance-qr-box]');
  const kind=document.querySelector('[data-attendance-qr-kind]');
  const count=document.querySelector('[data-attendance-countdown]');
  async function refreshQr(){
    if(!station||!box)return;
    try{
      const data=await post({attendance_op:'qr',qr_action:qrAction});
      const url=new URL('index.php',location.href);url.searchParams.set('page','attendance');url.searchParams.set('scan_token',data.token||'');
      box.innerHTML='';
      if(window.QRCode){new QRCode(box,{text:url.toString(),width:300,height:300,correctLevel:QRCode.CorrectLevel.M});}
      else{box.innerHTML='<div class="attendance-qr-loading">二维码组件仍在载入，稍后自动重试…</div>';setTimeout(refreshQr,800);return;}
      if(kind)kind.textContent=qrAction==='in'?'上班签到':'下班签退';
      countdown=15;if(count)count.textContent=String(countdown);
    }catch(err){box.innerHTML=`<div class="attendance-qr-loading">${err.message}</div>`;}
  }
  function startStation(){
    if(!station)return;refreshQr();
    clearInterval(qrTimer);qrTimer=setInterval(refreshQr,15000);
    clearInterval(countTimer);countTimer=setInterval(()=>{countdown=Math.max(0,countdown-1);if(count)count.textContent=String(countdown);},1000);
  }
  document.querySelectorAll('[data-attendance-qr-action]').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('[data-attendance-qr-action]').forEach(x=>x.classList.remove('is-active'));btn.classList.add('is-active');qrAction=btn.dataset.attendanceQrAction==='out'?'out':'in';refreshQr();}));
  document.querySelector('[data-attendance-refresh]')?.addEventListener('click',refreshQr);

  const modal=document.querySelector('[data-attendance-scanner]');
  const msg=document.querySelector('[data-attendance-scan-message]');
  const openModal=()=>{if(!modal)return;modal.hidden=false;modal.setAttribute('aria-hidden','false');document.body.classList.add('commission-modal-open');requestAnimationFrame(()=>modal.classList.add('is-open'));};
  const closeModal=async()=>{if(scanner){try{await scanner.stop();}catch(_){}try{scanner.clear();}catch(_){}scanner=null;}if(modal){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('commission-modal-open');setTimeout(()=>modal.hidden=true,180);}};
  async function clock(token){
    if(scanBusy)return;scanBusy=true;if(msg)msg.textContent='正在确认打卡…';
    try{const data=await post({attendance_op:'clock',qr_token:tokenFromText(token)});toast(data.message||'打卡成功。');if(msg)msg.textContent=data.message||'打卡成功。';setTimeout(()=>location.reload(),650);}
    catch(err){toast(err.message,true);if(msg)msg.textContent=err.message;scanBusy=false;}
  }
  async function startCamera(){
    if(!window.Html5Qrcode){if(msg)msg.textContent='扫码组件仍在载入，请稍后再按一次。';return;}
    try{scanner=new Html5Qrcode('attendance-qr-reader');await scanner.start({facingMode:'environment'},{fps:10,qrbox:{width:230,height:230}},text=>{if(!scanBusy)clock(text)},()=>{});if(msg)msg.textContent='相机已开启，请对准柜台二维码。';}
    catch(err){if(msg)msg.textContent='无法启动相机：'+(err?.message||err);scanner=null;}
  }
  document.querySelector('[data-attendance-scan-open]')?.addEventListener('click',openModal);
  document.querySelectorAll('[data-attendance-scan-close]').forEach(x=>x.addEventListener('click',closeModal));
  document.querySelector('[data-attendance-camera-start]')?.addEventListener('click',startCamera);
  document.querySelector('[data-attendance-list-refresh]')?.addEventListener('click',()=>location.reload());


  const leaveModal=document.querySelector('[data-leave-modal]');
  const leaveOpen=()=>{if(!leaveModal)return;leaveModal.hidden=false;leaveModal.setAttribute('aria-hidden','false');document.body.classList.add('commission-modal-open');requestAnimationFrame(()=>leaveModal.classList.add('is-open'));};
  const leaveClose=()=>{if(!leaveModal)return;leaveModal.classList.remove('is-open');leaveModal.setAttribute('aria-hidden','true');document.body.classList.remove('commission-modal-open');setTimeout(()=>leaveModal.hidden=true,180);};
  document.querySelectorAll('[data-leave-open]').forEach(x=>x.addEventListener('click',leaveOpen));
  document.querySelectorAll('[data-leave-close]').forEach(x=>x.addEventListener('click',leaveClose));
  document.querySelector('[data-leave-submit]')?.addEventListener('click',async(e)=>{
    const btn=e.currentTarget,start=document.querySelector('[data-leave-start]')?.value||'',end=document.querySelector('[data-leave-end]')?.value||'',reason=document.querySelector('[data-leave-reason]')?.value?.trim()||'';
    if(!start||!end||!reason){toast('请选择请假日期并填写原因。',true);return;}
    btn.disabled=true;btn.textContent='正在提交…';
    try{const data=await post({attendance_op:'leave_submit',start_date:start,end_date:end,reason});toast(data.message||'请假申请已提交。');setTimeout(()=>location.reload(),500);}
    catch(err){toast(err.message,true);btn.disabled=false;btn.textContent='提交申请';}
  });
  document.querySelectorAll('[data-leave-cancel]').forEach(btn=>btn.addEventListener('click',async()=>{
    if(!confirm('确定撤回这份待审批的请假申请？'))return;
    btn.disabled=true;
    try{const data=await post({attendance_op:'leave_cancel',request_id:btn.dataset.leaveCancel||''});toast(data.message||'请假申请已撤回。');setTimeout(()=>location.reload(),450);}
    catch(err){toast(err.message,true);btn.disabled=false;}
  }));
  document.querySelectorAll('[data-leave-review]').forEach(btn=>btn.addEventListener('click',async()=>{
    const decision=btn.dataset.leaveReview||'',row=btn.closest('[data-leave-owner-row]'),note=row?.querySelector('[data-leave-note]')?.value?.trim()||'';
    const verb=decision==='approved'?'批准':'拒绝';
    if(!confirm(`确定${verb}这份请假申请？`))return;
    row?.querySelectorAll('[data-leave-review]').forEach(x=>x.disabled=true);
    try{const data=await post({attendance_op:'leave_review',request_id:btn.dataset.requestId||'',decision,manager_note:note});toast(data.message||'审批完成。');setTimeout(()=>location.reload(),450);}
    catch(err){toast(err.message,true);row?.querySelectorAll('[data-leave-review]').forEach(x=>x.disabled=false);}
  }));

  startStation();
  const auto=root.dataset.autoToken||'';if(auto && root.dataset.isOwner!=='1')clock(auto);

  // v13.6.10.53 · authorized counter/owner manual attendance fallback.
  const manualModal=document.querySelector('[data-attendance-manual-modal]');
  const manualName=manualModal?.querySelector('[data-attendance-manual-name]');
  const manualEmployee=manualModal?.querySelector('[data-attendance-manual-employee]');
  const manualAction=manualModal?.querySelector('[data-attendance-manual-action]');
  const manualNote=manualModal?.querySelector('[data-attendance-manual-note]');
  const openManual=(btn)=>{if(!manualModal)return;if(manualName)manualName.value=btn.dataset.employeeName||'员工';if(manualEmployee)manualEmployee.value=btn.dataset.employeeId||'';if(manualAction)manualAction.value=(btn.dataset.clockedIn==='1'&&btn.dataset.clockedOut!=='1')?'out':'in';if(manualNote)manualNote.value='';manualModal.hidden=false;manualModal.setAttribute('aria-hidden','false');document.body.classList.add('commission-modal-open');requestAnimationFrame(()=>manualModal.classList.add('is-open'));};
  const closeManual=()=>{if(!manualModal)return;manualModal.classList.remove('is-open');manualModal.setAttribute('aria-hidden','true');document.body.classList.remove('commission-modal-open');setTimeout(()=>manualModal.hidden=true,180);};
  document.addEventListener('click',async(e)=>{const btn=e.target.closest('[data-attendance-manual-open]');if(btn){openManual(btn);return;}if(e.target.closest('[data-attendance-manual-close]')){closeManual();return;}const submit=e.target.closest('[data-attendance-manual-submit]');if(submit){const employeeId=manualEmployee?.value||'';const action=manualAction?.value||'in';const note=(manualNote?.value||'').trim();if(!note){toast('请填写代打卡原因。',false);manualNote?.focus();return;}submit.disabled=true;const old=submit.textContent;submit.textContent='处理中…';try{const data=await post({attendance_op:'manual_clock',employee_id:employeeId,clock_action:action,note});toast(data.message||'员工打卡已处理。');closeManual();setTimeout(()=>location.reload(),500);}catch(err){toast(err.message||'代打卡失败。',false);submit.disabled=false;submit.textContent=old;}}});
})();
