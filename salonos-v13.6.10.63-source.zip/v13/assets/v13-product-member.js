(() => {
  'use strict';

  const debounce = (fn, wait = 120) => { let timer; return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), wait); }; };
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>'"]/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char]));
  const money = (value) => `RM ${Number(value || 0).toFixed(2)}`;

  function initV1353ProductSearch(root = document) {
    root.querySelectorAll('[data-v1353-product-purchase]').forEach((form) => {
      if (form.dataset.v1353ProductBound === '1') return;
      form.dataset.v1353ProductBound = '1';

      const category = form.querySelector('[data-product-category]');
      const input = form.querySelector('[data-product-search]');
      const results = form.querySelector('[data-product-results]');
      const productId = form.querySelector('[data-product-id]');
      const selected = form.querySelector('[data-selected-product]');
      const nameEl = form.querySelector('[data-selected-product-name]');
      const stockEl = form.querySelector('[data-selected-product-stock]');
      const priceEl = form.querySelector('[data-selected-product-price]');
      const imageEl = form.querySelector('[data-selected-product-image]');
      const imagePlaceholder = form.querySelector('[data-selected-product-placeholder]');
      const descriptionEl = form.querySelector('[data-selected-product-description]');
      const qty = form.querySelector('[data-product-quantity]');
      const total = form.querySelector('[data-product-total]');
      let chosen = null;
      let controller = null;
      let activeIndex = -1;
      const cache = new Map();

      const clearChosen = (clearText = false) => {
        chosen = null;
        if (productId) productId.value = '';
        if (selected) selected.hidden = true;
        if (clearText && input) input.value = '';
        if (total) { total.value = 'RM 0.00'; total.dataset.amount = '0'; }
        form.dispatchEvent(new CustomEvent('salonos:product-total', { detail: { amount: 0, product: null } }));
      };

      const updateTotal = () => {
        const count = Math.max(0.01, Number(qty?.value || 1));
        const amount = Number(((chosen?.price || 0) * count).toFixed(2));
        if (total) { total.value = money(amount); total.dataset.amount = String(amount); }
        if (qty && chosen && Number.isFinite(Number(chosen.available)) && chosen.available < 999999) qty.max = String(Math.max(0.01, Number(chosen.available)));
        form.dispatchEvent(new CustomEvent('salonos:product-total', { detail: { amount, product: chosen } }));
      };

      const choose = (product) => {
        chosen = product;
        if (productId) productId.value = product.id || '';
        if (input) input.value = product.name || '';
        if (selected) selected.hidden = false;
        if (nameEl) nameEl.textContent = product.name || '产品';
        if (stockEl) stockEl.textContent = `${product.category || '未分类'} · ${product.stock_text || ''}`;
        if (descriptionEl) descriptionEl.textContent = product.description || '';
        if (priceEl) priceEl.textContent = product.price_text || money(product.price);
        if (imageEl) { imageEl.src = product.image_url || ''; imageEl.hidden = !product.image_url; imageEl.onerror = () => { imageEl.hidden = true; if (imagePlaceholder) imagePlaceholder.hidden = false; }; }
        if (imagePlaceholder) { imagePlaceholder.hidden = !!product.image_url; imagePlaceholder.textContent = String(product.name || 'P').slice(0, 1); }
        if (qty) qty.value = '1';
        if (results) results.hidden = true;
        updateTotal();
      };

      const optionButtons = () => results ? [...results.querySelectorAll('[data-v1353-product-option]:not(:disabled)')] : [];
      const setActive = (index) => {
        const buttons = optionButtons();
        buttons.forEach((button) => button.classList.remove('is-active'));
        if (!buttons.length) { activeIndex = -1; return; }
        activeIndex = Math.max(0, Math.min(index, buttons.length - 1));
        buttons[activeIndex].classList.add('is-active');
        buttons[activeIndex].scrollIntoView({ block: 'nearest' });
      };

      const render = (items) => {
        if (!results) return;
        const visible = Array.isArray(items) ? items.slice(0, 20) : [];
        activeIndex = -1;
        results.innerHTML = visible.length
          ? `<div class="product-search-result-head"><span>销售产品</span><strong>${visible.length} 个结果</strong></div>` + visible.map((p) => `
            <button type="button" class="product-search-option" data-v1353-product-option data-product='${escapeHtml(JSON.stringify(p))}' ${Number(p.available) <= 0 ? 'disabled' : ''}>
              <span class="product-search-thumb">${p.image_url ? `<img src="${escapeHtml(p.image_url)}" alt="${escapeHtml(p.name || '产品')}" data-product-thumb><b hidden data-product-thumb-fallback>${escapeHtml(String(p.name || 'P').slice(0,1))}</b>` : `<b>${escapeHtml(String(p.name || 'P').slice(0,1))}</b>`}</span>
              <span class="product-search-main"><strong>${escapeHtml(p.name)}</strong><small>${escapeHtml(p.code || '')}${p.code ? ' · ' : ''}${escapeHtml(p.category || '未分类')}</small>${p.description ? `<small>${escapeHtml(p.description)}</small>` : ''}</span>
              <span><strong>${escapeHtml(p.price_text || money(p.price))}</strong><small>${escapeHtml(p.stock_text || '')}</small></span>
            </button>`).join('')
          : '<div class="product-search-empty">这个分类没有找到可销售产品。</div>';
        results.hidden = false;
        results.querySelectorAll('img[data-product-thumb]').forEach((img) => {
          img.addEventListener('error', () => {
            img.hidden = true;
            const fallback = img.parentElement?.querySelector('[data-product-thumb-fallback]');
            if (fallback) fallback.hidden = false;
          }, { once: true });
        });
      };

      const showSearching = () => {
        if (!results) return;
        results.hidden = false;
        results.innerHTML = '<div class="product-search-empty product-search-loading">正在读取销售产品…</div>';
      };

      const runSearch = debounce(async () => {
        const q = input?.value.trim() || '';
        const categoryId = category?.value || '';
        const categoryName = category?.selectedOptions?.[0]?.textContent?.trim() || '';
        clearChosen(false);
        if (!categoryId) {
          if (results) { results.hidden = false; results.innerHTML = '<div class="product-search-empty">请先选择产品分类，再搜索分类里的销售产品。</div>'; }
          return;
        }
        const key = `${categoryId}|${q.toLocaleLowerCase()}`;
        if (cache.has(key)) { render(cache.get(key)); return; }
        controller?.abort();
        controller = new AbortController();
        try {
          const response = await fetch(`index.php?action=search_products&q=${encodeURIComponent(q)}&category_id=${encodeURIComponent(categoryId)}&category_name=${encodeURIComponent(categoryName)}&t=${Date.now()}`, {
            signal: controller.signal, credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' }
          });
          const raw = await response.text();
          let rows;
          try { rows = JSON.parse(raw); } catch { throw new Error('产品搜索接口返回非 JSON'); }
          if (!response.ok) throw new Error(rows?.error || `search failed ${response.status}`);
          cache.set(key, rows);
          render(rows);
        } catch (error) {
          if (error.name !== 'AbortError' && results) {
            results.hidden = false;
            results.innerHTML = `<div class="product-search-empty">${escapeHtml(error.message || '产品搜索暂时失败，请重试。')}</div>`;
          }
        }
      }, 100);

      input?.addEventListener('input', () => { showSearching(); runSearch(); });
      input?.addEventListener('focus', () => { runSearch(); });
      category?.addEventListener('change', () => { clearChosen(true); showSearching(); runSearch(); input?.focus(); });
      input?.addEventListener('keydown', (event) => {
        if (results?.hidden) return;
        const buttons = optionButtons();
        if (!buttons.length) return;
        if (event.key === 'ArrowDown') { event.preventDefault(); setActive(activeIndex + 1); }
        else if (event.key === 'ArrowUp') { event.preventDefault(); setActive(activeIndex <= 0 ? buttons.length - 1 : activeIndex - 1); }
        else if (event.key === 'Enter' && activeIndex >= 0) { event.preventDefault(); buttons[activeIndex]?.click(); }
        else if (event.key === 'Escape') results.hidden = true;
      });
      results?.addEventListener('click', (event) => {
        const button = event.target.closest('[data-v1353-product-option]');
        if (!button || button.disabled) return;
        try { choose(JSON.parse(button.dataset.product || '{}')); activeIndex = -1; } catch {}
      });
      document.addEventListener('click', (event) => { if (results && !form.contains(event.target)) results.hidden = true; });
      qty?.addEventListener('input', updateTotal);
      form.addEventListener('submit', (event) => {
        if (!category?.value) { event.preventDefault(); alert('请先选择产品分类。'); return; }
        if (!productId?.value) { event.preventDefault(); alert('请从这个分类里搜索并选择一个销售产品。'); return; }
        const requested = Number(qty?.value || 1);
        if (chosen && Number(chosen.available) < 999999 && requested > Number(chosen.available)) {
          event.preventDefault(); alert(`库存不足，最多可购买 ${chosen.available}。`);
        }
      });

      if (category?.value) runSearch();
    });
  }

  function initMemberPayment() {
    document.querySelectorAll('[data-member-product-payment]').forEach((form) => {
      if (form.dataset.memberPaymentBound === '1') return;
      form.dataset.memberPaymentBound = '1';
      const wallet = form.querySelector('[data-member-wallet-amount]');
      const external = form.querySelector('[data-member-external-amount]');
      const method = form.querySelector('[data-member-external-method]');
      const maxWallet = Math.max(0, Number(form.dataset.walletMax || 0));
      let totalAmount = Number(form.querySelector('[data-product-total]')?.dataset.amount || 0);

      const recalc = () => {
        let walletValue = Math.max(0, Number(wallet?.value || 0));
        walletValue = Math.min(walletValue, maxWallet, totalAmount);
        if (wallet) wallet.value = walletValue.toFixed(2);
        const remainder = Math.max(0, Number((totalAmount - walletValue).toFixed(2)));
        if (external) external.value = remainder.toFixed(2);
        if (method) {
          if (remainder <= 0.001) method.value = 'none';
          else if (method.value === 'none') method.value = 'cash';
        }
      };
      form.addEventListener('salonos:product-total', (event) => { totalAmount = Math.max(0, Number(event.detail?.amount || 0)); recalc(); });
      wallet?.addEventListener('input', recalc);
      method?.addEventListener('change', recalc);
      recalc();
    });
  }


  function initMemberProductAjax() {
    document.querySelectorAll('[data-member-product-ajax]').forEach((form) => {
      if (form.dataset.memberProductAjaxBound === '1') return;
      form.dataset.memberProductAjaxBound = '1';
      form.addEventListener('submit', async (event) => {
        if (event.defaultPrevented) return;
        const productId = form.querySelector('[data-product-id]')?.value || '';
        if (!form.querySelector('[data-product-category]')?.value) { event.preventDefault(); alert('请先选择产品分类。'); return; }
        if (!productId) { event.preventDefault(); alert('请从这个分类里搜索并选择一个销售产品。'); return; }
        event.preventDefault();
        const button = form.querySelector('button[type="submit"]');
        const original = button?.innerHTML || '';
        try {
          if (button) { button.disabled = true; button.innerHTML = '购买处理中…'; }
          const response = await fetch('index.php', {
            method: 'POST', body: new FormData(form), credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json' }
          });
          const raw = await response.text();
          let payload;
          try { payload = JSON.parse(raw); } catch { throw new Error('服务器没有返回 JSON，请刷新页面后再试。'); }
          if (!response.ok || !payload.success) throw new Error(payload.message || '产品购买失败');
          const url = new URL(window.location.href);
          url.searchParams.set('page','customers');
          if (payload.customer_id) url.searchParams.set('customer_id', String(payload.customer_id));
          window.location.href = url.toString();
        } catch (error) {
          alert(error.message || '产品购买失败，请重试。');
        } finally {
          if (button) { button.disabled = false; button.innerHTML = original || '确认购买产品'; }
        }
      });
    });
  }

  function populateBundleEditor(opener) {
    if (!opener?.matches?.('[data-v1350-modal-open="bundle-item"]')) return;
    const modal = document.querySelector('[data-v1350-modal="bundle-item"]');
    if (!modal) return;
    const productSelects = [...modal.querySelectorAll('[data-bundle-product]')];
    const quantityInputs = [...modal.querySelectorAll('[data-bundle-quantity]')];
    productSelects.forEach((select) => { select.value = ''; });
    quantityInputs.forEach((input) => { input.value = '1'; });
    let items = [];
    const raw = opener.getAttribute('data-items_json') || opener.dataset.items_json || '';
    if (raw) { try { items = JSON.parse(raw); } catch {} }
    if (!Array.isArray(items)) items = [];
    items.slice(0, productSelects.length).forEach((item, index) => {
      productSelects[index].value = String(item.product_id || '');
      quantityInputs[index].value = String(item.quantity || 1);
    });
  }

  document.addEventListener('click', (event) => {
    const opener = event.target.closest('[data-v1350-modal-open="bundle-item"]');
    if (opener) setTimeout(() => populateBundleEditor(opener), 0);
  });

  // v13.5.10: category search supports legacy text categories and product thumbnails.
  // Expose the category-first product search initializer so dynamic order content can bind it too.
  window.SalonOSInitV1353ProductSearch = initV1353ProductSearch;

  const boot = () => { initV1353ProductSearch(); initMemberPayment(); initMemberProductAjax(); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
