(()=>{
  'use strict';
  const body=document.body;
  const open=()=>body.classList.add('creator-menu-open');
  const close=()=>body.classList.remove('creator-menu-open');
  document.addEventListener('click',e=>{if(e.target.closest('[data-creator-menu]'))open();if(e.target.closest('[data-creator-menu-close]'))close();if(e.target.closest('.sidebar .nav a'))close();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
})();

// SalonOS v13.6.10.42 · Creator navigation / submit loading guard.
(() => {
  let visible = false;
  const ensure = () => {
    let el = document.querySelector('[data-creator-page-loader]');
    if (el) return el;
    el = document.createElement('div');
    el.className = 'creator-page-loader';
    el.setAttribute('data-creator-page-loader','');
    el.innerHTML = '<div role="status" aria-live="polite"><i aria-hidden="true"></i><strong data-creator-loader-title>正在载入…</strong><span>已收到操作，请不要重复点击</span></div>';
    document.body.appendChild(el);
    return el;
  };
  const show = (title='正在载入…') => { if (visible) return; const el=ensure(); el.querySelector('[data-creator-loader-title]').textContent=title; visible=true; requestAnimationFrame(()=>el.classList.add('is-visible')); };
  const hide = () => { const el=document.querySelector('[data-creator-page-loader]'); if(el)el.classList.remove('is-visible'); visible=false; document.querySelectorAll('.creator-nav-pending').forEach(n=>n.classList.remove('creator-nav-pending')); };
  document.addEventListener('click',(e)=>{ if(e.defaultPrevented||e.button!==0||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return; const a=e.target.closest?.('a[href]'); if(!a||a.target==='_blank'||a.hasAttribute('download'))return; const raw=a.getAttribute('href')||''; if(!raw||raw.startsWith('#')||raw.startsWith('javascript:')||raw.startsWith('mailto:')||raw.startsWith('tel:'))return; try{const u=new URL(a.href,location.href);if(u.origin!==location.origin||u.href===location.href)return;}catch(_){return;} a.classList.add('creator-nav-pending');show('正在切换页面…');},true);
  document.addEventListener('submit',(e)=>{if(e.defaultPrevented)return;const f=e.target;if(!(f instanceof HTMLFormElement)||f.dataset.noPageLoader!==undefined)return;show('正在处理…');},false);
  addEventListener('pageshow',hide);addEventListener('load',hide,{once:true});
})();
