<?php
declare(strict_types=1);
function creator_app_version(): string {
    clearstatcache(true, dirname(__DIR__) . '/VERSION');
    $v = trim((string)@file_get_contents(dirname(__DIR__) . '/VERSION'));
    return $v !== '' ? $v : '13';
}
session_name('salonos_creator_session');
session_start();
require_once dirname(__DIR__) . '/v13_supabase.php';

function creator_escape(string $v): string { return htmlspecialchars($v,ENT_QUOTES,'UTF-8'); }
function creator_csrf(): string { $_SESSION['creator_csrf'] ??= bin2hex(random_bytes(24)); return (string)$_SESSION['creator_csrf']; }
function creator_verify_csrf(): void { if(!hash_equals((string)($_SESSION['creator_csrf']??''),(string)($_POST['csrf']??'')))throw new RuntimeException('页面已过期，请刷新后再试。'); }
function creator_flash(string $type,string $message): void { $_SESSION['creator_flash']=['type'=>$type,'message'=>$message]; }
function creator_redirect(string $url='index.php'): never { header('Location: '.$url); exit; }
function creator_user(): ?array { return is_array($_SESSION['v13_creator_user']??null)?$_SESSION['v13_creator_user']:null; }
function creator_plan(string $code): array { return match(strtolower($code)){ 'annual'=>['code'=>'annual','label'=>'1年','amount'=>3000,'months'=>12], 'biennial'=>['code'=>'biennial','label'=>'2年','amount'=>6000,'months'=>24], default=>['code'=>'monthly','label'=>'1个月','amount'=>300,'months'=>1]}; }
function creator_dt(?string $v): string { if(!$v)return '—'; $t=strtotime($v); return $t?date('d/m/Y H:i',$t):$v; }
function creator_code_status(array $c): string { if(!empty($c['used_at'])||($c['status']??'')==='used')return 'used'; if(($c['status']??'')==='cancelled')return 'cancelled'; if(!empty($c['expires_at'])&&strtotime((string)$c['expires_at'])<time())return 'expired'; return 'active'; }
function creator_rpc_row(string $name,array $args,string $token): array { return v13_first_rpc_row(v13_rpc($name,$args,$token)); }

$action=(string)($_POST['action']??$_GET['action']??'');
if($action==='login' && $_SERVER['REQUEST_METHOD']==='POST'){
    try{
        creator_verify_csrf();
        $email=strtolower(trim((string)($_POST['email']??'')));
        $password=(string)($_POST['password']??'');
        $auth=v13_auth_password($email,$password);
        $token=v13_access_token_from_auth($auth); $refresh=v13_refresh_token_from_auth($auth);
        if($token==='')throw new RuntimeException('Supabase 没有返回 Creator Session。');
        $user=v13_creator_verify($token);
        session_regenerate_id(true);
        $_SESSION['v13_creator_access_token']=$token;
        $_SESSION['v13_creator_refresh_token']=$refresh;
        $_SESSION['v13_creator_user']=$user;
        creator_redirect();
    }catch(Throwable $e){ creator_flash('error',$e->getMessage()); creator_redirect(); }
}
if($action==='logout'){
    $token=v13_creator_token();
    if($token!==''){ try{ salonos_supabase_request('auth/v1/logout',$token,'POST',[]); }catch(Throwable $e){} }
    $_SESSION=[]; session_destroy(); creator_redirect();
}

if(!creator_user()){
    $flash=$_SESSION['creator_flash']??null; unset($_SESSION['creator_flash']);
    ?>
<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>Creator 登录</title><link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#111318"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="OS Creator"><link rel="apple-touch-icon" href="../assets/icons/apple-touch-icon.png"><link rel="icon" href="../assets/icons/favicon.ico"><link rel="stylesheet" href="assets/creator.css"><link rel="stylesheet" href="../assets/pwa.css"><link rel="stylesheet" href="../assets/luxe.css?v=13.5.3"></head>
<body class="creator-login"><main class="creator-card"><div class="creator-logo"><img src="../assets/icons/icon-96.png" alt="S" style="width:100%;height:100%;border-radius:18px"></div><div class="eyebrow" style="margin-top:18px">CREATOR SECURITY CONTROL</div><h1>SalonOS 创作者主系统</h1><p class="muted">管理老板账号、开户 Code、分行订阅、设备授权和系统停用。数据源：Supabase。</p>
<?php if($flash): ?><div class="alert alert-<?=creator_escape((string)$flash['type'])?>"><?=creator_escape((string)$flash['message'])?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="login"><div class="field"><label>Creator 邮箱</label><input class="input" type="email" name="email" value="jimmytiew24@gmail.com" required></div><div class="field"><label>密码</label><input class="input" type="password" name="password" required></div><button class="btn btn-dark btn-block">进入主控 Dashboard</button></form><p class="small muted" style="margin-top:18px">Creator 登录现在直接使用 Supabase Auth，不再读取 InfinityFree Control Database。</p></main><script src="../assets/pwa-install.js?v=13.6.10.46" data-pwa-name="SalonOS Creator" data-pwa-sw="sw.js?v=13.6.10.46" data-pwa-scope="./" data-pwa-icon="../assets/icons/icon-192.png" data-pwa-theme="creator" data-pwa-version-url="../version.php"></script></body></html>
<?php exit; }

$token=v13_creator_token();
if($token===''){
    $_SESSION=[]; session_destroy(); session_name('salonos_creator_session'); session_start(); creator_flash('error','Creator 登录已过期，请重新登录。'); creator_redirect();
}
try{ $_SESSION['v13_creator_user']=v13_creator_verify($token); }catch(Throwable $e){ $_SESSION=[]; session_destroy(); session_name('salonos_creator_session'); session_start(); creator_flash('error',$e->getMessage()); creator_redirect(); }

if($_SERVER['REQUEST_METHOD']==='POST' && $action!=='login'){
    try{
        creator_verify_csrf();
        if($action==='generate_activation_code'){
            $plan=creator_plan((string)($_POST['plan_code']??'monthly'));
            $row=creator_rpc_row('creator_generate_owner_code',['p_plan_code'=>$plan['code'],'p_label'=>trim((string)($_POST['label']??''))],$token);
            $_SESSION['creator_generated_code']=['purpose'=>'owner_signup']+$row;
            creator_flash('success','开户 Code 已生成：'.$plan['label'].' / RM'.number_format((float)$plan['amount'],2).'。');
        }elseif($action==='generate_branch_code'){
            $plan=creator_plan((string)($_POST['plan_code']??'monthly'));
            $row=creator_rpc_row('creator_generate_branch_code',[
                'p_organization_id'=>(string)($_POST['organization_id']??''),
                'p_plan_code'=>$plan['code'],
            ],$token);
            $_SESSION['creator_generated_code']=['purpose'=>'branch_signup']+$row;
            creator_flash('success','分行 Code 已生成：'.$plan['label'].' / RM'.number_format((float)$plan['amount'],2).'。');
        }elseif($action==='generate_device_code'){
            $row=creator_rpc_row('creator_generate_device_code',['p_target_user_id'=>(string)($_POST['owner_user_id']??''),'p_label'=>trim((string)($_POST['label']??''))],$token);
            $_SESSION['creator_generated_code']=['purpose'=>'device_login']+$row;
            creator_flash('success','设备 DVC Code 已生成，5 分钟内使用。');
        }elseif($action==='renew_subscription'){
            $plan=creator_plan((string)($_POST['plan_code']??'monthly'));
            v13_rpc('creator_renew_subscription',['p_subscription_id'=>(string)($_POST['subscription_id']??''),'p_plan_code'=>$plan['code']],$token);
            creator_flash('success','订阅已续费：'.$plan['label'].'。');
        }elseif($action==='set_subscription_status'){
            $status=(string)($_POST['status']??'suspended');
            v13_rpc('creator_set_subscription_status',['p_subscription_id'=>(string)($_POST['subscription_id']??''),'p_status'=>$status],$token);
            creator_flash('success',$status==='active'?'授权已恢复。':'授权状态已更新为 '.$status.'。');
        }elseif($action==='revoke_device'){
            v13_rpc('creator_revoke_device',['p_device_record_id'=>(string)($_POST['device_id']??'')],$token);
            creator_flash('success','设备权限已撤销。');
        }elseif($action==='cancel_code'){
            v13_rpc('creator_cancel_activation_code',['p_code_id'=>(string)($_POST['code_id']??'')],$token);
            creator_flash('success','未使用 Code 已取消。');
        }elseif($action==='change_password'){
            $current=(string)($_POST['current_password']??''); $new=(string)($_POST['new_password']??'');
            if(strlen($new)<10)throw new RuntimeException('新密码至少需要 10 个字符。');
            if($new!==(string)($_POST['confirm_password']??''))throw new RuntimeException('两次新密码不一致。');
            v13_auth_password((string)creator_user()['email'],$current);
            salonos_supabase_request('auth/v1/user',$token,'PUT',['password'=>$new]);
            creator_flash('success','Creator Supabase 密码已经修改。');
        }
    }catch(Throwable $e){ creator_flash('error',$e->getMessage()); }
    creator_redirect('index.php?page='.urlencode((string)($_POST['return_page']??'dashboard')));
}

$page=(string)($_GET['page']??'dashboard');
$allowed=['dashboard','owners','branches','codes','devices','security']; if(!in_array($page,$allowed,true))$page='dashboard';
$flash=$_SESSION['creator_flash']??null; unset($_SESSION['creator_flash']);
$generated=$_SESSION['creator_generated_code']??null; unset($_SESSION['creator_generated_code']);
try{ $snapshot=v13_creator_snapshot($token); }catch(Throwable $e){ $snapshot=[]; $flash=['type'=>'error','message'=>$e->getMessage()]; }
$counts=is_array($snapshot['counts']??null)?$snapshot['counts']:[];
foreach(['tenants','active','branches','unmanaged','devices','codes'] as $k){ $counts[$k]=(int)($counts[$k]??0); }
$tenants=is_array($snapshot['owners']??null)?$snapshot['owners']:[];
$branchSubscriptions=is_array($snapshot['branches']??null)?$snapshot['branches']:[];
$codes=is_array($snapshot['codes']??null)?$snapshot['codes']:[];
$devices=is_array($snapshot['devices']??null)?$snapshot['devices']:[];
$logs=is_array($snapshot['logs']??null)?$snapshot['logs']:[];
$titles=['dashboard'=>'总览','owners'=>'老板账号','branches'=>'分行订阅','codes'=>'授权 Code','devices'=>'已授权设备','security'=>'安全设置'];
?>
<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title><?=creator_escape($titles[$page])?> · SalonOS Creator Control</title><link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#111318"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="OS Creator"><link rel="apple-touch-icon" href="../assets/icons/apple-touch-icon.png"><link rel="icon" href="../assets/icons/favicon.ico"><link rel="stylesheet" href="assets/creator.css"><link rel="stylesheet" href="../assets/pwa.css"><link rel="stylesheet" href="../assets/luxe.css?v=13.5.3"></head><body>
<div class="creator-app"><button class="creator-sidebar-overlay" type="button" data-creator-menu-close aria-label="关闭菜单"></button><aside class="sidebar" data-creator-sidebar><button class="creator-sidebar-close" type="button" data-creator-menu-close aria-label="关闭菜单">×</button><div class="brand"><div class="creator-logo"><img src="../assets/icons/icon-72.png" alt="S" style="width:100%;height:100%;border-radius:14px"></div><div><strong>SalonOS Creator</strong><small>License Control</small></div></div><nav class="nav"><a class="<?=$page==='dashboard'?'active':''?>" href="?page=dashboard">总览</a><a class="<?=$page==='owners'?'active':''?>" href="?page=owners">老板账号</a><a class="<?=$page==='branches'?'active':''?>" href="?page=branches">分行订阅</a><a class="<?=$page==='codes'?'active':''?>" href="?page=codes">授权 Code</a><a class="<?=$page==='devices'?'active':''?>" href="?page=devices">已授权设备</a><a class="<?=$page==='security'?'active':''?>" href="?page=security">安全设置</a></nav><div class="sidebar-footer"><div class="small muted"><?=creator_escape((string)creator_user()['email'])?></div><a class="btn btn-light" style="width:100%;margin-top:10px" href="?action=logout">退出</a></div></aside>
<main class="main"><header class="topbar"><div class="creator-topbar-title"><button class="creator-menu-btn" type="button" data-creator-menu aria-label="打开 Creator 菜单">☰</button><div><div class="eyebrow">CREATOR MASTER SYSTEM</div><h1><?=creator_escape($titles[$page])?></h1></div></div><div class="badge badge-active" id="v13-live">实时同步 · Supabase</div></header>
<?php if($flash): ?><div class="alert alert-<?=creator_escape((string)$flash['type'])?>"><?=creator_escape((string)$flash['message'])?></div><?php endif; ?>
<?php if($generated): ?><section class="panel"><h2>刚生成的 <?=($generated['purpose']??'')==='owner_signup'?'开户':(($generated['purpose']??'')==='branch_signup'?'分行':'设备登录')?> Code</h2><p class="muted">请立即发给对应老板。Code 只生效 5 分钟，Supabase 只保存 Hash。</p><div class="code-box"><div class="code" id="generated-code"><?=creator_escape((string)($generated['code']??''))?></div><div class="code-meta">到期：<?=creator_escape(creator_dt((string)($generated['expires_at']??'')))?></div><button class="btn btn-light" type="button" style="margin-top:12px" onclick="navigator.clipboard.writeText(document.getElementById('generated-code').textContent).then(()=>this.textContent='已复制 Code')">复制 Code</button></div></section><?php endif; ?>

<?php if($page==='dashboard'): ?>
<div class="grid stats"><div class="stat"><span class="muted">老板账号</span><strong><?=$counts['tenants']?></strong></div><div class="stat"><span class="muted">正常授权</span><strong><?=$counts['active']?></strong></div><div class="stat"><span class="muted">付费分行</span><strong><?=$counts['branches']?></strong></div><div class="stat"><span class="muted">未纳管分行</span><strong><?=$counts['unmanaged']?></strong></div><div class="stat"><span class="muted">可信设备</span><strong><?=$counts['devices']?></strong></div><div class="stat"><span class="muted">未过期 Code</span><strong><?=$counts['codes']?></strong></div></div>
<div class="grid two-col"><section class="panel"><div class="tenant-head"><div><h2>最近老板账号</h2><p class="muted">查看系统状态和最后订阅。</p></div><a class="btn btn-light" href="?page=owners">全部老板</a></div><div class="table-wrap"><table class="table"><thead><tr><th>门店 / 老板</th><th>状态</th><th>设备</th><th>到期</th></tr></thead><tbody><?php foreach(array_slice($tenants,0,6) as $t): ?><tr><td><strong><?=creator_escape((string)$t['business_name'])?></strong><br><span class="small muted"><?=creator_escape((string)$t['owner_name'])?> · <?=creator_escape((string)$t['owner_email'])?></span></td><td><span class="badge badge-<?=creator_escape((string)$t['subscription_status'])?>"><?=creator_escape((string)$t['subscription_status'])?></span></td><td><?=(int)$t['device_count']?></td><td><?=creator_escape(creator_dt($t['expires_at']??null))?></td></tr><?php endforeach; ?><?php if(!$tenants): ?><tr><td colspan="4" class="muted">还没有老板账号</td></tr><?php endif; ?></tbody></table></div></section>
<section class="panel"><h2>生成老板开户 Code</h2><p class="muted">每个老板账号都必须购买独立订阅。Code 5 分钟内使用。</p><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="generate_activation_code"><input type="hidden" name="return_page" value="dashboard"><div class="field"><label>订阅方案</label><select class="input" name="plan_code"><option value="monthly">1个月 · RM300</option><option value="annual">1年 · RM3000</option><option value="biennial">2年 · RM6000</option></select></div><div class="field"><label>客户备注</label><input class="input" name="label" placeholder="例如：GIP Hair Salon / 已付款"></div><button class="btn btn-dark btn-block">生成订阅开户 Code</button></form></section></div>

<?php elseif($page==='owners'): ?>
<section class="panel"><h2>老板账号</h2><p class="muted">这里读取 Supabase Organizations、Owner Membership 与 Subscription；不再读取 InfinityFree Control DB。</p><div class="table-wrap"><table class="table"><thead><tr><th>门店 / 老板</th><th>方案 / 到期</th><th>状态</th><th>设备 / 分行</th><th>控制</th></tr></thead><tbody><?php foreach($tenants as $t): ?><tr><td><strong><?=creator_escape((string)$t['business_name'])?></strong><br><span class="small muted"><?=creator_escape((string)$t['owner_name'])?> · <?=creator_escape((string)$t['owner_email'])?></span></td><td><?=creator_escape(creator_plan((string)$t['plan_code'])['label'])?> · RM<?=number_format((float)$t['amount_rm'],2)?><br><span class="small muted"><?=creator_escape(creator_dt($t['expires_at']??null))?></span></td><td><span class="badge badge-<?=creator_escape((string)$t['subscription_status'])?>"><?=creator_escape((string)$t['subscription_status'])?></span></td><td><?=(int)$t['device_count']?> 设备 · <?=(int)$t['branch_count']?> 分行</td><td><div class="actions"><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="generate_device_code"><input type="hidden" name="owner_user_id" value="<?=creator_escape((string)$t['owner_user_id'])?>"><input type="hidden" name="return_page" value="owners"><button class="btn btn-light">生成设备 Code</button></form><?php foreach(['monthly'=>'续1月','annual'=>'续1年','biennial'=>'续2年'] as $pc=>$pl): ?><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="renew_subscription"><input type="hidden" name="subscription_id" value="<?=creator_escape((string)$t['subscription_id'])?>"><input type="hidden" name="plan_code" value="<?=$pc?>"><input type="hidden" name="return_page" value="owners"><button class="btn btn-light"><?=$pl?></button></form><?php endforeach; ?><?php if(($t['subscription_status']??'')==='active'): ?><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="set_subscription_status"><input type="hidden" name="subscription_id" value="<?=creator_escape((string)$t['subscription_id'])?>"><input type="hidden" name="status" value="suspended"><input type="hidden" name="return_page" value="owners"><button class="btn btn-danger">停用</button></form><?php else: ?><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="set_subscription_status"><input type="hidden" name="subscription_id" value="<?=creator_escape((string)$t['subscription_id'])?>"><input type="hidden" name="status" value="active"><input type="hidden" name="return_page" value="owners"><button class="btn btn-success">恢复</button></form><?php endif; ?></div></td></tr><?php endforeach; ?></tbody></table></div></section>

<?php elseif($page==='branches'): ?>
<div class="grid two-col creator-branch-simple"><section class="panel"><span class="eyebrow">BRANCH CODE ONLY</span><h2>生成分行 Code</h2><p class="muted">Creator 不需要知道分行名称或登录 Email。只选择客户与订阅方案，把 5 分钟 BRN Code 发给老板即可；老板建立分行后，真实分行资料会自动出现在下方记录。</p><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="generate_branch_code"><input type="hidden" name="return_page" value="branches"><div class="field"><label>这个 Code 属于哪位客户？</label><select class="input" name="organization_id" required><?php foreach($tenants as $t): ?><option value="<?=creator_escape((string)$t['organization_id'])?>"><?=creator_escape((string)$t['business_name'])?> · <?=creator_escape((string)$t['owner_email'])?></option><?php endforeach; ?></select></div><div class="field"><label>订阅方案</label><select class="input" name="plan_code"><option value="monthly">1个月 · RM300</option><option value="annual">1年 · RM3000</option><option value="biennial">2年 · RM6000</option></select></div><button class="btn btn-dark btn-block">生成 5 分钟 BRN Code</button></form></section><section class="panel creator-branch-rule"><span class="eyebrow">HOW IT WORKS</span><h2>Creator 只负责授权</h2><div class="creator-steps"><span><b>1</b> 选择老板</span><span><b>2</b> 生成 BRN Code</span><span><b>3</b> 客户自己建立分行</span><span><b>4</b> 分行资料自动同步回来</span></div><div class="code-box"><div class="small">当前已激活</div><div class="code"><?=number_format($counts['branches'])?> 个分行订阅</div><div class="code-meta">每个分行账号独立订阅 · 月费 RM300</div></div></section></div>
<section class="panel" style="margin-top:18px"><div class="tenant-head"><div><h2>已建立的分行</h2><p class="muted">这里显示客户真正建立成功后的分行资料；Creator 不需要预先输入。</p></div></div><div class="table-wrap"><table class="table"><thead><tr><th>所属老板 / 分行</th><th>登录 Email</th><th>方案 / 到期</th><th>状态</th><th>控制</th></tr></thead><tbody><?php foreach($branchSubscriptions as $bs): ?><tr><td><strong><?=creator_escape((string)$bs['business_name'])?></strong><br><span class="small muted"><?=creator_escape((string)$bs['branch_name'])?></span></td><td><?=creator_escape((string)$bs['login_email'])?></td><td><?=creator_escape(creator_plan((string)$bs['plan_code'])['label'])?> · RM<?=number_format((float)$bs['amount_rm'],2)?><br><span class="small muted"><?=creator_escape(creator_dt($bs['expires_at']??null))?></span></td><td><span class="badge badge-<?=creator_escape((string)$bs['status'])?>"><?=creator_escape((string)$bs['status'])?></span></td><td><div class="actions"><?php foreach(['monthly'=>'续1月','annual'=>'续1年','biennial'=>'续2年'] as $pc=>$pl): ?><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="renew_subscription"><input type="hidden" name="subscription_id" value="<?=creator_escape((string)$bs['subscription_id'])?>"><input type="hidden" name="plan_code" value="<?=$pc?>"><input type="hidden" name="return_page" value="branches"><button class="btn btn-light"><?=$pl?></button></form><?php endforeach; ?></div></td></tr><?php endforeach; ?><?php if(!$branchSubscriptions): ?><tr><td colspan="5" class="muted">还没有客户建立成功的分行。生成 BRN Code 后，把 Code 发给老板即可。</td></tr><?php endif; ?></tbody></table></div></section>

<?php elseif($page==='codes'): ?>
<div class="grid two-col"><section class="panel"><h2>生成主账号开户 Code</h2><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="generate_activation_code"><input type="hidden" name="return_page" value="codes"><div class="field"><label>订阅方案</label><select class="input" name="plan_code"><option value="monthly">1个月 · RM300</option><option value="annual">1年 · RM3000</option><option value="biennial">2年 · RM6000</option></select></div><div class="field"><label>客户备注</label><input class="input" name="label" placeholder="门店名、订单号或付款备注"></div><button class="btn btn-dark btn-block">生成开户 Code</button></form></section><section class="panel"><h2>生成分行 BRN Code</h2><p class="muted">不预填分行资料；客户建立后自动同步。</p><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="generate_branch_code"><input type="hidden" name="return_page" value="codes"><div class="field"><label>所属老板</label><select class="input" name="organization_id" required><?php foreach($tenants as $t): ?><option value="<?=creator_escape((string)$t['organization_id'])?>"><?=creator_escape((string)$t['business_name'])?> · <?=creator_escape((string)$t['owner_email'])?></option><?php endforeach; ?></select></div><div class="field"><label>订阅方案</label><select class="input" name="plan_code"><option value="monthly">1个月 · RM300</option><option value="annual">1年 · RM3000</option><option value="biennial">2年 · RM6000</option></select></div><button class="btn btn-dark btn-block">生成 BRN Code</button></form></section></div>
<section class="panel" style="margin-top:18px"><h2>最近 Code 记录</h2><div class="table-wrap"><table class="table"><thead><tr><th>类型</th><th>提示／备注</th><th>门店 / Email</th><th>状态</th><th>建立／到期</th><th>操作</th></tr></thead><tbody><?php foreach($codes as $c): $cs=creator_code_status($c); ?><tr><td><?=creator_escape(($c['purpose']??'')==='owner_signup'?'开户':(($c['purpose']??'')==='branch_signup'?'分行':'设备登录'))?></td><td class="mono">••••-<?=creator_escape((string)$c['code_hint'])?><br><span class="small muted"><?=creator_escape((string)($c['label']??''))?></span></td><td><?=creator_escape((string)($c['business_name']?:($c['target_email']??'尚未绑定')))?></td><td><span class="badge badge-<?=creator_escape($cs)?>"><?=creator_escape($cs)?></span></td><td><?=creator_escape(creator_dt($c['created_at']??null))?><br><span class="small muted"><?=creator_escape(creator_dt($c['expires_at']??null))?></span></td><td><?php if($cs==='active'): ?><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="cancel_code"><input type="hidden" name="code_id" value="<?=creator_escape((string)$c['id'])?>"><input type="hidden" name="return_page" value="codes"><button class="btn btn-danger">取消</button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div></section>

<?php elseif($page==='devices'): ?>
<section class="panel"><h2>老板可信设备</h2><p class="muted">撤销后，这台设备必须重新取得 Creator DVC Code。员工手机号登录不使用这里的设备授权。</p><div class="table-wrap"><table class="table"><thead><tr><th>门店／老板</th><th>设备</th><th>状态</th><th>授权／最后使用</th><th>操作</th></tr></thead><tbody><?php foreach($devices as $d): ?><tr><td><strong><?=creator_escape((string)$d['business_name'])?></strong><br><span class="small muted"><?=creator_escape((string)$d['owner_email'])?></span></td><td><?=creator_escape((string)($d['device_name']?:'未命名设备'))?><br><span class="small mono"><?=creator_escape((string)$d['device_id'])?></span></td><td><span class="badge badge-<?=creator_escape((string)$d['status'])?>"><?=creator_escape((string)$d['status'])?></span></td><td><?=creator_escape(creator_dt($d['first_authorized_at']??null))?><br><span class="small muted"><?=creator_escape(creator_dt($d['last_seen_at']??null))?></span></td><td><?php if(($d['status']??'')==='active'): ?><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="revoke_device"><input type="hidden" name="device_id" value="<?=creator_escape((string)$d['id'])?>"><input type="hidden" name="return_page" value="devices"><button class="btn btn-danger">撤销设备</button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div></section>

<?php else: ?>
<div class="grid two-col"><section class="panel"><h2>修改 Creator 密码</h2><form method="post"><input type="hidden" name="csrf" value="<?=creator_csrf()?>"><input type="hidden" name="action" value="change_password"><input type="hidden" name="return_page" value="security"><div class="field"><label>当前密码</label><input class="input" type="password" name="current_password" required></div><div class="field"><label>新密码</label><input class="input" type="password" name="new_password" minlength="10" required></div><div class="field"><label>再次输入新密码</label><input class="input" type="password" name="confirm_password" minlength="10" required></div><button class="btn btn-dark btn-block">保存新密码</button></form></section><section class="panel"><h2>v13 数据源状态</h2><p class="muted">Creator、订阅、ACT / BRN / DVC 与可信设备全部直接读取 Supabase。InfinityFree 在这个 Creator 中只负责 PHP Hosting。</p><div class="code-box"><div class="small">Control Plane</div><div class="mono">SUPABASE ONLY</div><div class="code-meta">v<?=htmlspecialchars(creator_app_version(), ENT_QUOTES, 'UTF-8')?> · v12.4.4 UI Lock · Supabase Only</div></div></section></div>
<section class="panel" style="margin-top:18px"><h2>安全记录</h2><div class="table-wrap"><table class="table"><thead><tr><th>时间</th><th>动作</th><th>门店</th><th>详情</th></tr></thead><tbody><?php foreach($logs as $l): ?><tr><td><?=creator_escape(creator_dt($l['created_at']??null))?></td><td><?=creator_escape((string)$l['action_name'])?></td><td><?=creator_escape((string)($l['business_name']??'-'))?></td><td><?=creator_escape((string)($l['detail']??''))?></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php endif; ?>
</main></div><script src="assets/creator-live.js?v=13.6.10.46"></script><script>setInterval(()=>{const el=document.getElementById('v13-live');if(el)el.textContent='实时同步 · '+new Date().toLocaleTimeString('zh-MY',{hour:'2-digit',minute:'2-digit',second:'2-digit'});},1000);</script><script src="../assets/pwa-install.js?v=13.6.10.46" data-pwa-name="SalonOS Creator" data-pwa-sw="sw.js?v=13.6.10.46" data-pwa-scope="./" data-pwa-icon="../assets/icons/icon-192.png" data-pwa-theme="creator" data-pwa-version-url="../version.php"></script></body></html>
