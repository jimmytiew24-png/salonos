const CACHE_NAME = 'salonos-creator-v13.6.10.46-version-update-feedback';
const OFFLINE_URL = new URL('./offline.html', self.location.href).pathname;
const STATIC_FILES = [
  './offline.html',
  './assets/creator.css',
  './assets/creator-live.js',
  '../assets/pwa.css',
  '../assets/luxe.css',
  '../assets/brand-wave.svg',
  '../assets/pwa-install.js',
  '../assets/icons/icon-192.png',
  '../assets/icons/icon-512.png',
  '../assets/icons/icon-maskable-512.png',
  '../assets/icons/apple-touch-icon.png',
  '../assets/icons/favicon.ico'
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key.startsWith('salonos-creator-') && key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.match(OFFLINE_URL)));
    return;
  }

  const isStatic = /\.(?:css|js|json|png|jpg|jpeg|webp|svg|ico|webmanifest)$/i.test(url.pathname);
  if (!isStatic) return;

  event.respondWith(
    fetch(new Request(request, { cache: 'no-store' })).then((response) => {
      if (response && response.ok) {
        const responseForCache = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(request, responseForCache)).catch(() => {});
      }
      return response;
    }).catch(() => caches.match(request))
  );
});

// SalonOS v11.3.5 schema auto-repair release
