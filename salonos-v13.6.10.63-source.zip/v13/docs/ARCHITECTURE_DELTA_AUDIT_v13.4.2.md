# SalonOS v13.4.4 — Old Architecture vs Master Spec vs Current ZIP Audit

This audit exists so older confirmed requirements are not silently lost while the v13 Supabase migration continues.

## A. Older requirements that are already represented in the newer Master Specification

- Exactly 2 PWAs: SalonOS Creator + SalonOS shared by Owner/Manager/Counter/Accountant/Staff.
- Supabase is the only source of truth; InfinityFree is hosting only.
- Organization tenant isolation + Store/Branch isolation.
- Creator ACT / BRN / DVC code model and subscription pricing.
- Owner/branch Supabase Auth and employee phone-only login.
- Role-based sidebar / permission direction.
- 4-step order wizard.
- Existing-customer/member search instead of loading the full list by default.
- Non-member quick order intake.
- Multiple recipients, multiple projects, multiple stylists/assistants and Contribution %.
- Draft auto-save.
- Appointment shown on service timeline, timeline until 24:00, status colors, staff-only own schedule.
- Ready-for-checkout separation; Staff cannot perform final checkout.
- Product / inventory / bundle separation.
- Membership XP / Points / Wallet direction.
- KPI / commission / training direction.
- Order-history pagination and DD/MM/YYYY direction.
- Tunaipro import, reports/export, WhatsApp reminder direction.
- PWA install/update, safe-area and mobile input-zoom requirements.
- v12 UI/UX + Supabase backend rule.

## B. Confirmed older details that were NOT explicit enough in the newer Master Specification

These should be treated as retained requirements unless intentionally superseded later.

1. **Employee live work-state model**
   - Available / In Service / Break / Off Duty / Disabled.
   - Employee can start/end break themselves.
   - Management can override work state.

2. **Walk-in exact availability engine**
   - Use the real current time.
   - Exclude break/off-duty/disabled/in-service staff.
   - Exclude staff occupied by paused unfinished jobs.
   - Exclude staff with an overlapping active order.
   - Exclude staff whose imminent appointment would collide with the estimated service duration.
   - Re-check on the server when the order is submitted to prevent simultaneous double booking.

3. **Appointment collision engine**
   - Availability must use appointment start + estimated service duration.
   - Overlap must block that stylist from being selected.

4. **Re-confirm / re-sign after material order changes**
   - If project, worker or price changes after confirmation, require confirmation/signature again.
   - Keep previous confirmation/signature versions instead of overwriting history.

5. **Detailed service-board status mapping**
   - Yellow: appointment / waiting for arrival / waiting for confirmation/start.
   - Red: in service / paused / service finished but awaiting counter checkout.
   - Green: completed / checked out.

6. **Service-board modal actions**
   - Customer/phone/projects/workers/time/amount/current status/payment status.
   - Arrive / start / pause / resume / complete / edit project / material use / checkout.

7. **Material-consumption reversal**
   - Wrong material consumption must be reversible with an audit trail.

8. **Checkout product fuzzy search detail**
   - Search name, bundle name, product code, SKU, barcode, category and Tunaipro ID.
   - Results should show image, type, code, category, price and live stock.
   - No Enter key required.

9. **Counter add-on product attribution**
   - Product added by the counter during checkout defaults to that counter employee for sales performance/commission, with controlled override when permitted.

10. **Mixed Member Wallet payment**
    - Allow partial Member Wallet + Cash/Card/E-Wallet for the remaining balance.

11. **Membership tier administration**
    - Owner can edit tier names and XP thresholds, not only rely on fixed levels.

12. **Inventory unit**
    - Inventory item has a unit field (pcs/ml/g/tube/etc.) for operational clarity.

13. **WhatsApp delivery log**
    - Sent / failed status, timestamp, customer and appointment reference must be visible.

14. **Custom roles**
    - Beyond built-in roles, permission center must support owner-defined roles.

15. **Explicit branch credential fields**
    - Branch setup includes unique branch Email and login password. The current `register-branch.php` already contains these fields; keep this rule in the consolidated spec.

## C. Older-vs-newer rule conflicts that should NOT be silently merged

1. **Owner login identifier**
   - Older architecture says Email / phone + password.
   - Newer Master Spec says Owner uses Email + password, while employee uses phone-only.
   - Current v13 follows the newer Email + password owner rule. Keep it unless a deliberate product decision changes it.

2. **Icon wording**
   - Older notes call it the Softnoise Studio SN black icon.
   - Newer Master Spec describes the selected black rounded icon with a gold/silver/ice-blue fluid S/wave.
   - Current asset is the fluid S/wave icon with no OS text. Do not replace it automatically.

## D. What the current v13.4.1 ZIP still did NOT fully implement

- Service现场 is still card-based rather than the required employee-by-time timeline.
- Exact Walk-in and future appointment conflict engine is not production-complete.
- No complete staff self-service Available/Break/Off-duty control UI.
- Project signature modal had an open-state bug (fixed in v13.4.4), but versioned re-sign history is still pending.
- Service-process project editing + audit trail is incomplete.
- Material consumption + reversal is incomplete.
- Ready-checkout product selector is still a normal select, not the required fuzzy search result UI.
- Counter add-on product does not yet automatically attribute salesperson to the logged-in counter.
- Checkout is not yet a complete mixed-payment engine.
- Product bundle sale -> component stock deduction needs full end-to-end QA.
- Membership tier administration needs deeper alignment.
- Inventory unit support is not complete across UI/import/export.
- Custom role builder is not complete.
- WhatsApp real sending + delivery logs are not complete.
- Full L-shaped analytics/report exports are not complete.
- Product image ZIP+CSV+Images transfer needs full end-to-end implementation.
- Realtime service board / Creator / appointment sync is not complete.

## E. v13.4.4 targeted fixes included now

- Fix project-signature modal so it actually opens (`.is-open` state + body scroll lock).
- Responsive/high-DPI signature canvas with Pointer Events.
- White signature stroke on a dark canvas.
- Clear / cancel / Escape / backdrop-close behavior.
- Prevent submit when no signature was drawn.
- Fix `employee_stores.updated_at` compatibility mismatch through an additive SQL patch.
- Add `employees.availability_status` only if an older schema is missing it, so the retained live-work-state model has a compatible field.
- Keep the v12.4.4 visual baseline files untouched; signature styles live in `v13-supabase-compat.css`.

## F. Recommended implementation order after this build

1. Employee work-state RPC + staff/manager UI.
2. Real Walk-in + appointment overlap engine, server recheck included.
3. Employee-by-time service timeline + detailed modal.
4. Versioned order confirmation/signature history.
5. Material consumption + reversal.
6. Checkout fuzzy product/bundle search + cashier attribution.
7. Mixed payment.
8. Membership tiers + inventory units.
9. Custom roles.
10. WhatsApp send/log system.
11. Production reports/export and final two-owner tenant-isolation QA.
