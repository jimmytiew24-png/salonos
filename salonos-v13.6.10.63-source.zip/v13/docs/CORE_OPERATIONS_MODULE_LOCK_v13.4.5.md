# SalonOS v13.4.5 — Core Operations Module Lock

This file is a regression guard. Future Supabase migrations must not simplify these modules into unrelated generic cards/tables or remove the business links between them.

## Closed-loop rule
Service Board -> Employee Performance -> Commission -> KPI -> Business Analytics.
Material usage and checkout product sales -> Product & Inventory -> cost/performance/analytics.
Store revenue is counted once. Contribution % allocates employee performance; it never multiplies store revenue.

## Business Analytics
- Day / month / year + current Store context.
- Summary: Revenue, Completed Orders, Customers, Avg Ticket, Appointments, Walk-ins, Product Sales, Service Revenue, Material Cost, Product Cost.
- L-shaped report: month view by day; year view by month.
- Service performance, product performance, appointment performance.
- Employee drill-down: service performance, product sales, total performance, completed customers/orders, requested count, appointments, walk-ins, product units, estimated commission.
- Professional Excel/CSV export; never raw database-field dump.

## KPI
- KPI Template and Employee KPI are separate concepts.
- Automatic metrics: revenue, service count, customers, avg ticket, requested count, product sales, training completion; manual KPI supported.
- Template deactivation never removes historical KPI.
- Employee KPI lifecycle: Active -> Achieved -> Reviewed -> Bonus Paid/Locked/Archived.
- Bonus-paid KPI must be immutable history.

## Training
- Manager course fields: title, category, target roles, description/content, URL/video, estimated time, version, required flag, Published/Archived.
- Employee only sees courses relevant to their role.
- Progress: Not Started -> In Progress -> Completed with started/progress/completed timestamps.
- Training completion can feed KPI automatically.

## Product & Inventory
- Product & Inventory is a Hub with separate Inventory / Sellable Products / Bundles / Customer Showcase / Tunaipro / Branch Transfer entries.
- Inventory carries quantity, unit, cost, reorder level and a movement ledger explaining every increase/decrease.
- Material consumption is tied to Visit/Service and supports reversal/audit.
- Sellable Product has Product Code/SKU, barcode, category, description, sale price, cost, image, active state and inventory mapping.
- Bundle sells multiple components and stock availability determines how many sets can be sold.
- JPG/PNG/WebP images appear in management, fuzzy search, checkout and customer showcase; cost is never exposed to customer showcase.
- Checkout search is instant fuzzy search by name, package, Product Code, SKU, barcode, category and Tunaipro ID.
- Tunaipro import: Upload -> Preview -> Validate -> Confirm for Product / Package / Service / Member.
- Branch transfer: ZIP + CSV/data + images with image mapping retained.

## Commission
- Project Contribution % allocates employee performance while store Revenue remains one copy only.
- Monthly employee performance = Service Performance + Product Sales.
- Tier engine maps monthly performance ranges to commission rate.
- Single-order manual override is final for that order and must not be overwritten by monthly automatic recomputation.
- Checkout add-on product defaults to the current counter employee as salesperson unless a permitted override is chosen.
- Three clear entries: Commission Overview / Monthly Employee Commission / Commission Tiers.
- Employee can see only own performance/estimated commission; only management can edit rules/overrides.

## Runtime contract rule
A PHP deploy must never assume a new Supabase RPC/column exists without a compatibility path. v13.4.5 introduces a runtime-contract version marker and Service Board fallback specifically to prevent raw PGRST202/PGRST204 module crashes when website files and database migrations are temporarily out of sync.
