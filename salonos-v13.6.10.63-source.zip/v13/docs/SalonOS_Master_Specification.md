# SalonOS Master Specification

**当前目标版本：v13 系列**
 **核心原则：原本功能与 UI/UX 保留，后端统一 Supabase，InfinityFree 只负责公网 Hosting。**

---

# 1. 系统定位

SalonOS 是给 Hair Salon / Barber / 美业门店使用的完整 SaaS 营运系统。

系统需要同时处理：

-  顾客 
-  会员 
-  Walk-in 
-  预约 
-  服务现场 
-  员工 
-  员工业绩 
-  KPI 
-  抽成 
-  服务项目 
-  产品 
-  库存 
-  产品配套 
-  付款 
-  订单记录 
-  经营分析 
-  分行 
-  权限 
-  订阅 
-  Creator 总控 
-  WhatsApp 通知 
-  报表 
-  CSV / Excel Import & Export 
-  PWA 
-  手机员工端 

---

# 2. 最终技术架构【最新，必须遵守】

## 数据库只有一套

最终必须是：

```
```

```
InfinityFree / VPS / DigitalOcean / Evoxt
            │
            │ 只负责
            │ PHP / HTML / CSS / JS / PWA
            ▼
         Supabase
            │
            ├── Authentication
            ├── PostgreSQL Database
            ├── RLS
            ├── Storage
            ├── RPC / Functions
            └── Realtime（适合的位置）
```

### Supabase 是唯一 Source of Truth

所有正式资料只能存在 Supabase：

```
```

```
老板
Creator
分行
订阅
Code
可信设备
顾客
会员
员工
服务
订单
产品
库存
付款
KPI
抽成
报表数据
预约
设置
签名
图片
```

### InfinityFree 以后只负责

```
```

```
公网网址
PHP
HTML
CSS
JavaScript
PWA
静态资源
```

**不能再把 SalonOS 正式业务数据存在 InfinityFree MySQL。**

---

# 3. 必须彻底数据隔离

这是整个系统最重要的底层规则之一。

每一家老板：

```
```

```
Organization A
Organization B
Organization C
```

必须完全隔离。

每张业务表原则上必须有：

```
```

```
organization_id
```

需要门店隔离的再有：

```
```

```
store_id
```

例如：

```
```

```
customers
employees
services
products
visits
payments
memberships
inventory
kpi
commission
```

全部必须通过：

```
```

```
Supabase Auth
+
organization_members
+
store_members
+
RLS
```

限制。

### 绝对不能再次发生

```
```

```
老板 A
看到老板 B 员工 ❌

老板 A
看到老板 B 历史订单 ❌

老板 A
看到老板 B 产品 ❌

老板 A
看到老板 B 顾客 ❌

老板 A
看到老板 B KPI ❌
```

即使前端代码被人修改，也必须由数据库 RLS 拦截。

---

# 4. PWA 架构

最终只有 **两个 PWA**。

## PWA 1 — SalonOS Creator

只给系统 Creator / SaaS 管理者。

负责：

```
```

```
老板账号
订阅
分行订阅
ACT Code
BRN Code
DVC Code
可信设备
系统安全
SaaS 总览
```

## PWA 2 — SalonOS

老板、经理、柜台、会计、员工共用一个 App。

登录以后根据角色：

```
```

```
Owner
Manager
Receptionist
Accountant
Staff
```

动态控制：

```
```

```
可以看到什么
可以操作什么
Sidebar 显示什么
可以修改什么
```

不是每个角色做一个 App。

---

# 5. Creator Master System

Creator UI 必须保留你原本那套完整设计，不要再次做成简陋 Preview 页面。

左侧：

```
```

```
SalonOS Creator
License Control
```

导航：

```
```

```
总览
老板账号
分行订阅
授权 Code
已授权设备
安全设置
```

---

# 6. Creator 总览 Dashboard

需要实时显示：

```
```

```
老板账号数量
正常授权数量
付费分行数量
未纳管分行
可信设备数量
未过期 Code 数量
```

并显示最近老板：

```
```

```
门店名称
老板
Email
Subscription status
设备数量
分行数量
最后上线时间
```

数据必须直接来自 Supabase。

不能出现：

```
```

```
Supabase 有两个 Owner
Creator 只显示一个
```

这种不同步情况。

---

# 7. SaaS 订阅规则

最新价格：

```
```

```
1个月      RM100
1年        RM1000
2年        RM2000
```

这是**每一个账号 / 分行独立订阅**。

例如：

```
```

```
Salon A 主店      RM100/月
Salon A 分店 1    RM100/月
Salon A 分店 2    RM100/月
```

不能因为同老板就免费共享。

Creator 可以：

```
```

```
查看订阅
续 1 个月
续 1 年
续 2 年
暂停
恢复
查看到期日
```

付费历史以后要保留。

---

# 8. Code 系统

至少分成：

## ACT Code

老板开户 / 注册使用。

```
```

```
Creator
↓
生成 ACT Code
↓
5 分钟有效
↓
只能使用一次
↓
老板完成注册
```

---

## BRN Code

创建付费分行使用。

```
```

```
老板购买分行订阅
↓
Creator 生成 BRN Code
↓
老板输入新分行资料
↓
验证
↓
建立分行
```

分行必须在 Creator 的：

```
```

```
分行订阅
```

里面出现。

---

## DVC Code

老板新设备授权。

```
```

```
老板 Email + Password
↓
新设备
↓
要求 DVC
↓
Creator 生成
↓
输入 DVC
↓
设备成为 Trusted Device
```

可信设备大约记住：

```
```

```
1个月
```

之后再要求重新授权。

---

# 9. 老板注册

登录页必须有：

```
```

```
还没有老板账号？
使用 Creator 开户 Code 注册 →
```

注册页：

```
```

```
Creator ACT Code
老板姓名
老板手机号
老板 Email
密码
再次输入密码
第一家门店名称
```

完成后自动建立：

```
```

```
Supabase Auth User
Organization
organization_members = owner
Main Store
Subscription
```

**不能再建立 InfinityFree tenant database。**

---

# 10. 老板登录

老板使用：

```
```

```
Email
Password
```

通过：

```
```

```
Supabase Auth
```

登录。

新设备才要求：

```
```

```
DVC Code
```

已授权设备直接进入。

---

# 11. 员工登录【非常重要】

员工只使用：

```
```

```
手机号码
```

### 不需要

```
```

```
密码 ❌
Email ❌
DVC Code ❌
Creator 授权设备 ❌
```

老板建立并启用该员工后：

```
```

```
手机号
↓
验证员工 active
↓
验证所属 Organization / Store
↓
建立安全 Employee Session
↓
进入员工端
```

老板停用员工：

```
```

```
员工状态 inactive / disabled
↓
现有 Session 作废
↓
员工马上无法继续进入
```

不能只是匿名 API 直接凭手机号读取 employee 表。

---

# 12. 角色权限

至少：

```
```

```
Owner
Manager
Receptionist / Counter
Accountant
Staff
```

老板可以在：

```
```

```
系统设置
→ 权限管理
```

决定不同角色可以看到哪些入口。

### Staff

员工基本规则：

可以处理：

```
```

```
自己的预约
自己的服务
订单确认
服务进度
顾客确认
相关签名
```

但是：

```
```

```
最终结账 ❌
```

最终 Checkout 由：

```
```

```
柜台 / Owner / Manager
```

完成。

---

# 13. 主 SalonOS Layout

Desktop 基本排版继续保持目前的结构：

```
```

```
┌──────── Sidebar ───────┬──────────── Main App ────────────┐
│ SalonOS Logo           │ Top Header                      │
│ 店名                   │ Page Name       Branch  User    │
│                        ├──────────────────────────────────┤
│ 工作台                 │                                  │
│ 新建顾客订单           │                                  │
│ 服务现场               │          Page Content            │
│ 顾客与会员             │                                  │
│ 员工业绩               │                                  │
│ ...                    │                                  │
│                        │                                  │
└────────────────────────┴──────────────────────────────────┘
```

顶部包含：

```
```

```
当前页面名称
门店切换
当前用户
角色
退出
```

---

# 14. Sidebar

Sidebar 要：

-  暗色 
-  固定整体设计 
-  图标统一 
-  当前页面有金色 Highlight 
-  项目很多时 Sidebar 自己滚动 
-  不能整个页面被 Sidebar 撑长 
-  分类可以展开 / 收起 

主要导航：

```
```

```
工作台
新建顾客订单
服务现场
顾客与会员
员工业绩

成长与管理
员工管理
订单记录
经营分析
KPI 管理
培训中心
服务项目
产品与库存
抽成管理
分行管理
系统设置
```

根据角色隐藏无权限项目。

---

# 15. UI 总视觉【必须统一】

最新视觉以你现在这个 App Icon 为基础：

-  黑色 
-  深灰 
-  Midnight Navy 
-  金色 
-  银色 
-  冰蓝色 
-  少量绿色状态色 

整体必须：

```
```

```
Premium
Dark
Modern
Apple-like
Glass / depth
Low-noise
Professional
```

不能像普通后台 Bootstrap。

---

# 16. 当前建议设计色系

视觉方向大概：

```
```

```
Main Background
#05090D / 接近黑色

Surface
#09131D
#0D1822
#111D27

Border
低透明度灰蓝 / 银色

Gold
#D6A24F
#EDBC69
#F6CE8A

Ice Blue
#85CDF4
#AFE2FF

Text Primary
接近白色

Text Secondary
灰蓝

Success
Emerald Green

Warning
Gold / Amber

Error
Muted Red
```

重点不是一定锁死 Hex，而是**全系统必须同一设计语言**。

---

# 17. 禁止白底【你重复强调很多次】

整个 SalonOS 暗色主题下，**不能突然冒出大块白色区域**。

包括：

```
```

```
时间表 ❌ 白底
员工卡 ❌ 白底
顾客卡 ❌ 白底
KPI mini cards ❌ 白底
Analytics table ❌ 白底
产品配套 ❌ 白底
库存卡片 ❌ 白底
设置卡片 ❌ 白底
分行统计 ❌ 白底
新建订单 form ❌ 白底
搜索区域 ❌ 白底
提示框 ❌ 白底
```

不是只修你截图的地方。

要求是：

> **扫描全部 PHP / HTML / CSS 代码，把所有与 Dark Theme 不一致的白色 Surface 找出来统一修复。**

输入框也用暗色。

---

# 18. 按钮设计

Primary CTA：

```
```

```
Gold gradient / warm gold
Dark text
soft glow
rounded corners
```

例如：

```
```

```
新增员工
下一步
确认订单
生成 Code
结账
进货
```

Secondary：

```
```

```
Dark surface
Silver/blue border
White text
```

Danger：

```
```

```
暗红
```

不能大量使用纯白按钮。

---

# 19. 卡片设计

Card：

```
```

```
深色 Surface
轻微 Border
圆角
细微 Shadow
微弱 Glass feeling
```

不能：

```
```

```
纯白卡片 + 黑色字
```

---

# 20. 小浮窗 / Modal

你要求很多操作不要跳完整新页面，而是统一使用小浮窗。

例如：

```
```

```
编辑库存
进货
库存调整
修改服务
修改员工
调整抽成
确认预约
订单状态
追加产品
```

统一 Dark Modal。

---

# 21. 工作台

Dashboard 要快速显示：

```
```

```
当天经营
当前订单
预约
待服务
进行中
待结账
营业额
员工状态
关键库存提醒
```

不能过度复杂。

---

# 22. 顾客资料

字段包括：

```
```

```
姓名
电话
性别
年龄 / 出生日期
种族
身份证 / Identification（需要时）
Email
地址
来源平台
备注
```

种族选择：

```
```

```
华人
马来人
印度人
其他
```

---

# 23. 新顾客 / 非会员

非会员下单最低要求：

```
```

```
姓名 *
电话 *
```

然后额外可以填写：

```
```

```
种族
年龄
性别
```

不能强迫顾客先成为会员才可以下单。

---

# 24. 顾客搜索

默认不要一次显示全部会员。

输入：

```
```

```
姓名
手机号
会员编号
```

至少几个字后开始：

```
```

```
模糊搜索
即时建议
```

选择已有会员后：

```
```

```
自动带入资料
```

不能重复创建。

---

# 25. 会员系统

会员从：

```
```

```
Level 1
```

开始。

基本逻辑：

```
```

```
消费金额 = Experience
消费金额 = Points
```

例如：

```
```

```
RM100
→ +100 Experience
→ +100 Points
```

等级可以根据 Experience 自动升级。

---

# 26. 会员储值 Wallet

会员可以：

```
```

```
充值
查看余额
使用余额付款
查看历史
```

余额可用于：

```
```

```
服务
产品
```

充值不需要指定推销员。

---

# 27. 会员积分

积分可以累计。

未来：

```
```

```
Points redemption
```

继续扩充。

兑换记录必须保留 Ledger。

---

# 28. 顾客与会员 UI

会员列表需要现代、清晰、响应式。

你之前不喜欢那种：

```
```

```
很窄左栏列表
+
右边挤一个巨大 Detail
```

造成空间不平衡的设计。

应该根据 Desktop / Mobile 使用：

```
```

```
Cards
Table
Expandable Profile
Modal / Detail
```

合理排版。

---

# 29. 最新新建订单流程【重点】

**必须是明确 4 步。**

顶部显示：

```
```

```
①
②
③
④
```

当前步骤 Gold Highlight。

---

# 30. Step 1 — 到店方式

第一步先问：

```
```

```
Walk-in
或
预约
```

### Walk-in

自动：

```
```

```
当前日期
当前时间
```

### 预约

可选择：

```
```

```
日期
时间
```

并可以指定：

```
```

```
理发师
或
系统分配
```

---

# 31. Step 2 — 顾客 + 服务项目

这里才填写 / 搜索：

```
```

```
顾客资料
会员
服务项目
理发师
助理
```

### 先搜索已有顾客

可以：

```
```

```
姓名
手机号
会员编号
```

没有再直接建立新顾客。

---

# 32. 一个订单允许多个服务项目

例如：

```
```

```
Haircut
Color
Treatment
Wash
```

每一个 Project 独立。

---

# 33. 一个 Project 可以多个工作人员

一个项目不是只能一个理发师。

例如：

```
```

```
Hair Coloring
├─ Stylist A  60%
├─ Stylist B  30%
└─ Assistant C 10%
```

可以：

```
```

```
多个理发师
多个助理
Contribution %
```

---

# 34. 理发师可用状态

Walk-in / 预约选择员工时：

如果员工：

```
```

```
休息中
正在服务
停用
离职
```

不能继续指定。

---

# 35. 随机 / 指定理发师

顾客可以：

```
```

```
指定理发师
系统分配 / Random
```

需要记录顾客指定次数，供员工业绩分析。

---

# 36. 同行服务对象

一个订单可以：

```
```

```
+ 增加同行者
```

例如：

```
```

```
孩子
家人
朋友
```

每个人可以有自己的：

```
```

```
服务项目
工作人员
```

而不是强迫建立多个完全独立订单。

---

# 37. 材料消耗

服务过程中可以直接选择：

```
```

```
染发膏
药水
耗材
```

从 Inventory 扣。

支持：

```
```

```
搜索库存
选择
填写使用数量
```

这个功能不能再次丢失。

---

# 38. Step 3 — 顾客确认订单

给顾客确认：

```
```

```
顾客姓名
服务对象
服务项目
理发师
助理
预计时间
价格
总金额
```

这一步是 Customer Confirmation。

---

# 39. Step 4 — 电子签名

顾客确认后签名。

签名区域必须：

```
```

```
Dark Background
White Signature Stroke
```

因为之前暗色背景却画黑色签名看不到。

需要：

```
```

```
清除签名
重新签
确认
```

---

# 40. 自动保存 Draft

新订单还没有正式提交时：

```
```

```
自动保存草稿
```

避免：

```
```

```
误关
换页面
手机跳出
```

导致整个订单消失。

---

# 41. 服务中允许修改

订单进入服务后：

```
```

```
可以增加服务
修改服务
增加工作人员
改变工作人员
添加材料
```

完成后有权限的管理层仍可修改记录。

历史资料不能直接消失。

---

# 42. 预约完整流程

目标流程：

```
```

```
建立预约
↓
显示在员工时间表
↓
顾客到店
↓
确认到达
↓
进入 Waiting / In Service
↓
员工处理
↓
完成服务
↓
顾客确认 / 签名
↓
Ready for Checkout
↓
柜台结账
```

顾客点击：

```
```

```
确认到达
```

之后预约**不能突然从系统消失**。

---

# 43. 服务现场 / 时间表

这是重要页面。

不要另做一个独立的巨大预约列表。

预约应该直接出现在对应员工的时间表。

---

# 44. 时间表 Layout

类似：

```
```

```
           09  10  11  12  13 ... 23  24
员工 A
员工 B
员工 C
```

### 显示时间

必须一直显示到：

```
```

```
00:00 / 24:00
```

不能只到晚上 9 点。

---

# 45. 时间表颜色

最新：

```
```

```
黄色 = 预约
红色 = 服务中
绿色 = 完成
```

状态一眼可见。

---

# 46. 时间表操作

柜台点击某个预约 Block：

```
```

```
弹出小浮窗
```

可以：

```
```

```
查看资料
确认到达
开始服务
确认进度
完成
进入待结账
```

---

# 47. 员工端时间表

员工只看到：

```
```

```
自己的 Schedule
自己的预约
自己的服务
```

不能看到其他不该看的员工资料。

---

# 48. 时间表日期

可以：

```
```

```
前一天
后一天
选择日期
```

不能永远只看今天。

---

# 49. 时间表下方

需要显示：

```
```

```
当天全部订单
```

包括：

```
```

```
预约
等待
进行中
待结账
完成
取消
```

---

# 50. 待结账

服务完成后：

```
```

```
Ready for Checkout
```

进入柜台待结账。

---

# 51. 待结账可以追加产品

顾客到柜台时可以：

```
```

```
购买产品
购买配套
```

直接加到当前订单。

---

# 52. 产品搜索

不要要求完整名字。

输入：

```
```

```
几个字
SKU
Barcode
```

立即：

```
```

```
模糊搜索
```

显示建议。

---

# 53. 产品销售员工

产品购买可以指定：

```
```

```
销售员工
```

用于：

```
```

```
Product Commission
员工业绩
```

---

# 54. 结账

Checkout 只有：

```
```

```
Owner
Manager
Receptionist / Counter
```

可以完成。

Staff 不做最终结账。

---

# 55. Payment

至少支持：

```
```

```
Cash
Card
E-Wallet
Bank Transfer
Member Wallet
Other
```

支持混合付款结构。

---

# 56. Cash Change

例如：

```
```

```
总额 RM85
顾客给 RM100
找零 RM15
```

必须正确。

---

# 57. 库存扣减时机

必须：

```
```

```
Payment 成功
↓
才正式扣库存
```

避免 Checkout 失败但库存已经被扣。

---

# 58. 员工管理

字段：

```
```

```
姓名
手机号
职位
年龄
性别
技能
底薪
员工编号
加入日期
权限角色
状态
```

操作：

```
```

```
新增
修改
停用
重新启用
离职
```

---

# 59. 员工停用

停用后：

```
```

```
不能员工端登录
不能在指定理发师出现
旧订单继续保留
KPI 历史保留
业绩历史保留
抽成历史保留
```

不能 DELETE 掉历史。

---

# 60. 员工底薪隐私

底薪 / Compensation 不应该跟公开 Employee Directory 混在一起。

权限仅：

```
```

```
Owner
Manager
Accountant
```

适当可见。

普通 Staff 不应读取全部人的薪资。

---

# 61. 员工业绩

支持：

```
```

```
日
月
年
```

查看。

主要指标：

```
```

```
服务贡献
产品销售
总贡献
完成项目
预约顾客
顾客指定
预计抽成
```

---

# 62. 多人项目业绩分配

项目 RM100：

```
```

```
Employee A 70%
Employee B 30%
```

则业绩：

```
```

```
A RM70
B RM30
```

不是把 RM100 两个人都完整计算一次。

---

# 63. 服务抽成

支持：

```
```

```
固定抽成率
或
阶梯抽成率
```

老板可以全局设定。

---

# 64. 阶梯抽成

按照员工当月 Performance：

```
```

```
Tier 1
Tier 2
Tier 3
...
```

自动决定 Rate。

---

# 65. 单订单细调

即使有 Global Rate，老板仍可：

```
```

```
点击订单
→ 小浮窗
→ 调整员工占比 / 抽成
```

---

# 66. Product Commission

产品销售单独记录：

```
```

```
Salesperson
Product Sale
Commission Rate
Commission Amount
```

---

# 67. 月度员工抽成

需要独立入口：

```
```

```
员工月度业绩抽成
```

显示：

```
```

```
Service Performance
Service Rate
Service Commission
Product Sales
Product Commission
KPI Bonus
Manual Adjustment
Total Payout
```

---

# 68. 已发抽成锁定

老板正式发放后：

```
```

```
历史记录锁定
```

不能随便修改过去发过的钱。

这也是为什么之前 Supabase 有：

```
```

```
Paid commission history is locked
```

这个保护逻辑。

---

# 69. KPI 管理

老板可以：

```
```

```
新增 KPI
修改 KPI
删除 KPI
分配员工
```

---

# 70. KPI 应该以员工为中心

不要全部员工 KPI 堆在一页非常乱。

流程：

```
```

```
选择员工
↓
进入该员工 KPI 页面
↓
新增 / 管理 KPI
```

---

# 71. KPI 自动达成

当系统数据达到：

```
```

```
目标值
```

自动：

```
```

```
已达成
```

不需要老板手动勾。

---

# 72. KPI 奖金

KPI 可以配置：

```
```

```
Bonus
```

Dashboard 可以显示：

```
```

```
进行中 KPI
已达成
预计奖金池
```

---

# 73. KPI 发放后锁定

奖金发放以后：

```
```

```
历史记录保留
不可随意改变过去结果
```

---

# 74. 服务项目管理

独立：

```
```

```
服务项目
```

支持：

```
```

```
新增
修改
停用
删除（没有历史关联时）
类别
默认价格
预计分钟
是否允许助理
```

编辑尽量使用统一小浮窗。

---

# 75. 产品与库存

是一个 Hub，但里面分开：

```
```

```
库存货品
销售产品
产品配套
```

不能三种资料全部混在一张表。

---

# 76. 库存管理

Inventory 支持：

```
```

```
新增
修改
停用
删除
进货
库存调整
成本
建议售价
最低库存线
图片
```

---

# 77. 库存操作统一 Modal

例如：

```
```

```
进货
修改
调整
```

尽量不要跳整页。

---

# 78. 销售产品

Product 有：

```
```

```
SKU
Barcode
名称
分类
售价
成本
默认抽成
图片
启用状态
```

---

# 79. 产品图片

产品 / 库存都支持图片。

最终图片不要依赖 InfinityFree 文件夹。

使用：

```
```

```
Supabase Storage
```

例如：

```
```

```
organizations/{organization_id}/products/
organizations/{organization_id}/inventory/
```

---

# 80. Product Bundle / 配套

独立入口：

```
```

```
产品配套
```

多个库存货品组成一个配套。

例如：

```
```

```
Bundle A
├─ Shampoo x1
├─ Wax x1
└─ Treatment x1
```

卖出配套：

```
```

```
自动扣对应库存
```

---

# 81. 库存低量提醒

需要：

```
```

```
Low Stock
Reorder line
```

显示。

---

# 82. 订单记录

过午夜后订单自然进入历史。

订单记录支持：

```
```

```
日
月
年
日期范围
状态
员工
顾客
```

筛选。

---

# 83. 订单历史不能只有 500 条

以前最多 500 条的限制：

```
```

```
取消
```

需要 Pagination / 查询，而不是硬砍历史。

---

# 84. 日期格式

主要显示：

```
```

```
DD/MM/YYYY
```

不要美国式：

```
```

```
MM/DD/YYYY
```

---

# 85. 历史订单编辑

有权限角色可以打开历史订单重新查看 / 修改。

但应保留数据一致性。

---

# 86. 经营分析

门店经营分析要做成你要求的：

```
```

```
L 型 / 矩阵式报表
```

例如：

```
```

```
指标        01/08 02/08 03/08 ... 合计
营业额
订单
顾客
预约
会员销售
材料成本
...
```

支持：

```
```

```
日
月
年
```

---

# 87. 员工分析

包含：

```
```

```
服务贡献
完成项目
产品销售
预约顾客
被顾客指定次数
预计抽成
```

---

# 88. Excel / CSV Export

门店可以导出：

```
```

```
经营数据
员工业绩
员工 KPI
会员
服务
产品
库存
配套
员工
订单
```

Excel 排版要参考你之前给的截图结构。

你强调的是：

> **排版方式参考，不是把截图里的重复“喷漆”内容照抄。**

---

# 89. Product 图片导出

产品导出时，希望可以：

```
```

```
CSV + 图片
```

以后再导入回来。

---

# 90. Tunaipro Import

设置里保留：

```
```

```
Tunaipro CSV 导入
```

类型：

```
```

```
Product
Package
Service
Member
```

---

# 91. Member Import

会员还需要明显独立 Import 入口。

---

# 92. Import UX

需要：

```
```

```
选择文件
预览
字段检查
确认
再写数据库
```

不能一上传就直接把坏数据写进去。

---

# 93. 分行管理

老板可以创建 / 管理多个 Branch。

字段：

```
```

```
门店名称
地址
电话
Email
```

---

# 94. 新分行需要独立订阅

创建分行不是免费。

流程：

```
```

```
老板申请
↓
Creator 创建 BRN Code
↓
新分行 Email
↓
订阅
↓
建立 Store
```

---

# 95. 分行切换

顶部 Selector：

```
```

```
SalonOS Main
SalonOS Bukit Jalil
...
```

老板可以切换门店查看资料。

切换后所有数据自动限定：

```
```

```
store_id
```

---

# 96. Creator 必须看到 Branch

分行创建成功后：

Creator：

```
```

```
分行订阅
```

必须实时出现。

不能只有老板端有分店而 Creator 没有记录。

---

# 97. 设置中心

至少：

```
```

```
门店通用设置
员工权限角色
WhatsApp Business
数据导入
分行资料迁移
分行管理
Database Isolation 状态
语言
```

---

# 98. 权限设置

老板控制：

```
```

```
员工
柜台
会计
经理
```

能看到哪些功能。

Sidebar 也按权限变化。

---

# 99. 语言

系统支持：

```
```

```
中文
English
```

切换。

---

# 100. WhatsApp Business

老板可以绑定：

```
```

```
门店自己的 WhatsApp Business
```

用于：

```
```

```
预约提醒
通知
以后密码 / 业务通知
```

---

# 101. 预约提醒

默认可以：

```
```

```
预约前 1 小时
```

提醒顾客。

老板可以自定义：

```
```

```
提前多久
```

例如：

```
```

```
30 分钟
1 小时
2 小时
```

真正发送需要 Meta / WhatsApp Business 正式 API 凭证。

---

# 102. 报表导出

设置 / 报表入口可以导出：

```
```

```
员工 KPI
员工业绩
门店经营数据
```

---

# 103. PWA 自动更新【重点】

客户安装成 PWA 后：

开发者更新代码：

```
```

```
v13.1
↓
v13.2
```

客户**不应该要：**

```
```

```
F5 ❌
清 Cache ❌
删除 PWA ❌
重新添加主屏幕 ❌
```

Service Worker 要自动发现新版本。

---

# 104. PWA Update 策略

需要：

```
```

```
versioned cache
skipWaiting
clientsClaim
cache invalidation
HTML network-first / appropriate strategy
asset versioning
```

让新版本自动接管。

---

# 105. Android 安装

可以显示：

```
```

```
安装 App
```

按钮 / Install Prompt。

---

# 106. iPhone

因为 iOS 限制，提供：

```
```

```
Safari
→ Share
→ Add to Home Screen
```

教学。

不能假装可以静默安装。

---

# 107. 手机禁止页面缩放

PWA 使用时：

```
```

```
不能 pinch zoom
不能双击乱放大
不能像网页一样整个 Layout 被拉大
```

---

# 108. iPhone 输入框不要自动 Zoom

所有 mobile form：

```
```

```
input
select
textarea
```

字体至少：

```
```

```
16px
```

避免 iOS focus 自动放大。

---

# 109. 手机刘海 / Dynamic Island

顶部必须使用：

```
```

```
safe-area-inset-top
safe-area-inset-left
safe-area-inset-right
```

避免：

```
```

```
刘海
Dynamic Island
状态栏
```

挡住内容。

---

# 110. Mobile Layout

手机不是 Desktop 强行缩小。

需要：

```
```

```
响应式卡片
适合点击的按钮
合理 bottom spacing
safe area
可滚动 Sidebar / Navigation
表格可以合理横滑
```

不能整个网页出现失控的横向缩放。

---

# 111. Signature UX

所有需要顾客签名的位置：

```
```

```
Canvas 深色
笔迹白色
```

签名应保存为：

```
```

```
Supabase Storage
+
数据库记录
```

不是只存在浏览器。

---

# 112. Storage 隔离

例如：

```
```

```
organizations/
  {organization_id}/
    product-images/
    inventory-images/
    signatures/
```

不同老板不能直接拿 URL 访问别人的私有文件。

---

# 113. Realtime

适合实时同步的地方包括：

```
```

```
Creator 老板状态
服务现场
预约
订单状态
员工服务状态
```

不应该每次一定 F5 才看到变化。

---

# 114. 状态保留

删除 / 停用原则：

业务历史资料尽量：

```
```

```
soft delete
status
inactive
disabled
```

而不是直接 DELETE。

特别：

```
```

```
员工
会员
历史订单
抽成
KPI
Payment
```

不能随便物理删除。

---

# 115. Training Center

培训中心入口保留。

目前详细课程逻辑还没有最终完全定义，所以：

```
```

```
模块保留
Supabase 架构预留
后续再继续扩充
```

不要自己乱发明一整套 LMS 导致原系统变复杂。

---

# 116. Creator / SalonOS Icon

现在最新版使用你后来指定的这个：

**黑色圆角方形 + 金银蓝流体 S / 波纹形 Icon。**

这个 Icon 用于：

```
```

```
PWA
Login
Sidebar
Creator
Install App
Manifest
favicon
```

UI 配色也围绕它设计。

---

# 117. 品牌显示

App 可以显示：

```
```

```
SalonOS
SalonOS Creator
```

Icon 本身不需要硬塞：

```
```

```
SalonOS 文字
Soft Noise Studio 文字
```

保持高级、简洁。

---

# 118. Creator UI 不准再次简化

之前 v13 曾经做成：

```
```

```
一个很简单的网页
SalonOS Creator
几张基础 Card
```

这不是正式 UI。

正式 v13 必须继续使用你原来的完整 Creator Master System 设计。

---

# 119. 主系统 UI 也不准重新设计成另一套

原则：

```
```

```
v12 UI / UX
      +
Supabase backend
      =
v13
```

不是：

```
```

```
换 Supabase
=
整个界面重做
```

---

# 120. 公网部署

现在阶段：

```
```

```
InfinityFree = Demo Hosting
```

因为成本低，可以拿来实机演示。

将来有正式客户：

```
```

```
InfinityFree
↓
VPS / Evoxt / DigitalOcean 等
```

只搬代码即可。

因为数据已经在：

```
```

```
Supabase
```

所以不需要再搬客户 Database。

---

# 121. Demo 与正式环境原则

InfinityFree MySQL 现在只属于：

```
```

```
旧 v12 / 旧 Demo
```

最终 v13：

```
```

```
不能依赖它
```

等 Supabase v13 完整测试通过之后：

```
```

```
salonos_control
salonos_tenant1
salonos_tenant2
```

就可以正式退出运行架构。

---

# 122. 不再迁旧测试数据

之前 MySQL / Supabase 有很多：

```
```

```
Owner1
Owner2
Test Salon
Test Staff
TNP1 products
测试订单
```

你已经明确：

> 那些只是测试资料，我不需要浪费时间完整迁移。

所以现在方向是：

```
```

```
建立干净正式 Supabase 架构
```

而不是继续修旧测试数据 Migration。

---

# 123. 当前要废弃的旧规则

这些**以后不要再实现回来**：

```
```

```
❌ 每个老板一个 InfinityFree MySQL Tenant Database

❌ SalonOS Control Database 放 InfinityFree

❌ Supabase 一套 + MySQL 一套双写

❌ MySQL → Supabase 自动同步

❌ Creator 从 MySQL 读老板资料

❌ Products 一份 Supabase、一份 MySQL

❌ 员工需要设备授权

❌ 员工密码登录

❌ v13 简化版 Creator UI

❌ 大块白色 Card / Table / Form

❌ PWA 更新后要求客户 F5

❌ 每次更新要求删 App 重装

❌ 顾客必须先成为会员才能下单

❌ 一个服务只能一个理发师

❌ Staff 可以最终 Checkout

❌ 预约确认到达后从系统消失

❌ 时间表只显示到晚上 9 点

❌ 订单历史最多 500 条
```

---

# 124. 当前最终开发顺序

如果现在从代码角度重新整理，正确顺序应该是：

```
```

```
1. Supabase Core Schema
2. RLS / Tenant Isolation
3. Auth
4. Creator
5. Subscription / ACT / BRN / DVC
6. Organization / Store / Branch

7. Customer
8. Membership
9. Employee
10. Employee Phone Session

11. Services
12. New Order 4-Step Wizard
13. Appointment
14. Service Timeline
15. Signature
16. Checkout / Payment

17. Products
18. Inventory
19. Product Bundle
20. Material Consumption

21. Performance
22. Commission
23. KPI

24. Order History
25. Analytics
26. Report Export

27. Settings / Permissions
28. WhatsApp
29. Storage
30. PWA Auto Update
31. Mobile QA
32. Full RLS Cross-Tenant QA
33. Production Cutover
```

---

# 125. 最终验收标准

在正式给第一位客户前，至少要测试两个完全不同老板：

```
```

```
Owner A
Organization A

Owner B
Organization B
```

分别建立：

```
```

```
员工
顾客
会员
服务
订单
产品
库存
KPI
预约
付款
```

然后确认：

```
```

```
A 看不到 B
B 看不到 A
```

同时测试：

```
```

```
Creator 可以看到 A/B SaaS 资料
但不会混业务 Tenant 数据

Branch 隔离正常
员工权限正常
Employee Phone Login 正常
DVC 正常
订阅正常
Checkout 正常
库存正常
签名正常
PWA 自动更新正常
Mobile 正常
```

通过后，才叫真正可以卖给老板用的 **SalonOS v13 Production**。