<?php
declare(strict_types=1);

session_name('salonos_v13_business');
if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params([
        'lifetime'=>0,
        'path'=>'/v13/',
        'secure'=>$secure,
        'httponly'=>true,
        'samesite'=>'Lax',
    ]);
    session_start();
}

require_once __DIR__ . '/v13_supabase.php';
require_once __DIR__ . '/supabase_customers.php';
require_once __DIR__ . '/supabase_employees.php';
require_once __DIR__ . '/supabase_all_modules.php';
require_once __DIR__ . '/supabase_attendance.php';
require_once __DIR__ . '/v12_feature_bridge.php';
require_once __DIR__ . '/workflow_v1361062.php';

const SALONOS_V13_SUPABASE_ONLY = true;
const SALONOS_V13_SUPABASE_CUSTOMERS = true;
const SALONOS_V13_SUPABASE_EMPLOYEES = true;

function e(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
function salonos_app_version(): string {
    static $version = null;
    if ($version !== null) return $version;
    clearstatcache(true, __DIR__ . '/VERSION');
    $raw = @file_get_contents(__DIR__ . '/VERSION');
    $version = trim((string)$raw);
    return $version !== '' ? $version : '13';
}
function salonos_asset_version(): string { return rawurlencode(salonos_app_version()); }
function money(float|int|string|null $v): string { return 'RM ' . number_format((float)$v, 2); }
function app_date(string $v, bool $time=false): string {
    $t = strtotime($v); if (!$t) return $v;
    return date($time ? 'd/m/Y H:i' : 'd/m/Y', $t);
}
function csrf_token(): string { $_SESSION['v13_csrf'] ??= bin2hex(random_bytes(24)); return (string)$_SESSION['v13_csrf']; }
function verify_csrf(): void {
    if (!hash_equals((string)($_SESSION['v13_csrf'] ?? ''), (string)($_POST['csrf'] ?? ''))) throw new RuntimeException('页面已过期，请刷新后再试。');
}
function flash(string $type, string $message): void { $_SESSION['flash']=['type'=>$type,'message'=>$message]; }
function redirect(string $url='index.php'): never { header('Location: '.$url); exit; }
function v1352_is_ajax_request(): bool {
    return (string)($_POST['ajax'] ?? '') === '1'
        || strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
}
function v1352_json_response(array $payload, int $status=200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
function salonos_public_mode(): bool { return true; }
function user(): ?array { return is_array($_SESSION['v13_business_user'] ?? null) ? $_SESSION['v13_business_user'] : null; }
function v13_actor_mode(): string { return trim((string)($_SESSION['supabase_access_token'] ?? ''))!=='' ? 'owner' : 'employee'; }
function v13_is_owner(): bool { return v13_actor_mode()==='owner'; }

function v13_business_token(): string {
    $token = trim((string)($_SESSION['supabase_access_token'] ?? ''));
    $refresh = trim((string)($_SESSION['supabase_refresh_token'] ?? ''));
    // The live GET has already checked the token with the session locked.
    // Avoid rotating it again after the session is no longer writable.
    if (defined('SALONOS_LIVE_SESSION_CLOSED')) return $token;
    if ($token === '' || (v13_jwt_exp($token) > 0 && v13_jwt_exp($token) < time()+90)) {
        if ($refresh === '') return '';
        try {
            $auth = salonos_supabase_request('auth/v1/token?grant_type=refresh_token','', 'POST', ['refresh_token'=>$refresh]);
            $token = v13_access_token_from_auth($auth);
            $newRefresh = v13_refresh_token_from_auth($auth);
            if ($token !== '') $_SESSION['supabase_access_token']=$token;
            if ($newRefresh !== '') $_SESSION['supabase_refresh_token']=$newRefresh;
        } catch (Throwable $e) {
            unset($_SESSION['supabase_access_token'], $_SESSION['supabase_refresh_token'], $_SESSION['supabase_identity'], $_SESSION['v13_business_user']);
            return '';
        }
    }
    return $token;
}

function v1361061_close_live_session(): void {
    define('SALONOS_LIVE_SESSION_CLOSED', true);
    session_write_close();
}

function v13_device_cookie(string $name): string { return 'salonos_v13_'.$name; }
function v13_device_identity(): array {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $deviceId = trim((string)($_COOKIE[v13_device_cookie('device_id')] ?? ''));
    $secret = trim((string)($_COOKIE[v13_device_cookie('device_secret')] ?? ''));
    if ($deviceId === '' || $secret === '') {
        $deviceId = 'DEV-'.strtoupper(bin2hex(random_bytes(8)));
        $secret = bin2hex(random_bytes(24));
        setcookie(v13_device_cookie('device_id'), $deviceId, [
            'expires'=>time()+86400*365, 'path'=>'/v13/', 'secure'=>$secure, 'httponly'=>true, 'samesite'=>'Lax'
        ]);
        setcookie(v13_device_cookie('device_secret'), $secret, [
            'expires'=>time()+86400*365, 'path'=>'/v13/', 'secure'=>$secure, 'httponly'=>true, 'samesite'=>'Lax'
        ]);
        $_COOKIE[v13_device_cookie('device_id')]=$deviceId;
        $_COOKIE[v13_device_cookie('device_secret')]=$secret;
    }
    return [$deviceId, hash('sha256',$secret)];
}

function v13_device_authorized(string $token): bool {
    [$deviceId,$tokenHash] = v13_device_identity();
    $result = v13_rpc('check_owner_trusted_device', ['p_device_id'=>$deviceId,'p_token_hash'=>$tokenHash], $token);
    $row = v13_first_rpc_row($result);
    return !empty($row['authorized']);
}

function v13_business_login(string $email,string $password): void {
    $auth = v13_auth_password($email,$password);
    $token = v13_access_token_from_auth($auth);
    if ($token === '') throw new RuntimeException('Supabase 没有返回登录 Session。');
    $identity = salonos_supabase_owner_context($token);
    if (!in_array((string)($identity['role'] ?? ''), ['owner','manager'], true)) throw new RuntimeException('这个入口只允许老板或分行管理员账号登录。');
    $_SESSION['pending_supabase_access_token']=$token;
    $_SESSION['pending_supabase_refresh_token']=v13_refresh_token_from_auth($auth);
    $_SESSION['pending_supabase_identity']=$identity;
    if (!v13_device_authorized($token)) {
        $_SESSION['v13_needs_device_code']=true;
        return;
    }
    v13_finish_business_login();
}

function v13_finish_business_login(): void {
    $identity = is_array($_SESSION['pending_supabase_identity'] ?? null) ? $_SESSION['pending_supabase_identity'] : null;
    $token = trim((string)($_SESSION['pending_supabase_access_token'] ?? ''));
    if (!$identity || $token === '') throw new RuntimeException('老板登录 Session 已过期，请重新登录。');
    $_SESSION['supabase_identity']=$identity;
    $_SESSION['supabase_access_token']=$token;
    $_SESSION['supabase_refresh_token']=(string)($_SESSION['pending_supabase_refresh_token'] ?? '');
    $_SESSION['v13_business_user']=[
        'id'=>(string)($identity['user_id']??''),
        'email'=>(string)($identity['email']??''),
        'employee_name'=>(string)($identity['profile']['full_name'] ?? '') ?: (string)($identity['email']??'Owner'),
        'role'=>(string)($identity['role'] ?? 'owner'),
        'role_label'=>(($identity['role'] ?? 'owner')==='manager'?'分行管理员':'老板 / 系统管理员'),
        'avatar_path'=>(string)($identity['profile']['avatar_path'] ?? ''),
    ];
    $stores = is_array($identity['stores'] ?? null) ? $identity['stores'] : [];
    if (empty($_SESSION['v13_current_store_uuid'])) $_SESSION['v13_current_store_uuid']=(string)($identity['primary_store_id'] ?? ($stores[0]['id'] ?? ''));
    unset($_SESSION['pending_supabase_identity'],$_SESSION['pending_supabase_access_token'],$_SESSION['pending_supabase_refresh_token'],$_SESSION['v13_needs_device_code']);
    session_regenerate_id(true);
}

function v13_business_logout(): void {
    if (v13_is_owner()) {
        $token = v13_business_token();
        if ($token !== '') { try { salonos_supabase_request('auth/v1/logout',$token,'POST',[]); } catch(Throwable $e) {} }
    } else {
        salonos_v13_employee_logout();
    }
    $_SESSION=[];
    session_destroy();
}

function current_store(): array {
    $identity = salonos_supabase_identity();
    $stores = is_array($identity['stores'] ?? null) ? $identity['stores'] : [];
    $selected = trim((string)($_SESSION['v13_current_store_uuid'] ?? ''));
    foreach ($stores as $s) if ((string)($s['id']??'') === $selected) return $s;
    return $stores[0] ?? ['id'=>'','name'=>'SalonOS','code'=>'HQ','is_main'=>true];
}

function v136_safe_message_text(string $m): string {
    $low=strtolower($m);
    if(str_contains($low,'pgrst202') || str_contains($low,'could not find the function')) return 'Supabase Runtime Contract 尚未同步。请运行 RUN_ONCE_V13_5_5_CUMULATIVE_RUNTIME.sql 后刷新页面。';
    if(str_contains($low,'pgrst204') || str_contains($low,'schema cache') || str_contains($low,'42703') || str_contains($low,'column') && str_contains($low,'does not exist') || str_contains($low,'42p01')) return 'Supabase 数据表结构尚未同步。请运行 RUN_ONCE_V13_5_5_CUMULATIVE_RUNTIME.sql 后刷新页面。';
    if((str_contains($low,'23502') || str_contains($low,'not-null constraint')) && str_contains($low,'payment_items') && str_contains($low,'payment_method')) return '结账付款方式契约未同步：payment_method 不应为空。请运行 v13.5.5 累计 SQL 后再结账。';
    if(str_contains($low,'payment_items') && str_contains($low,'payment_method') && str_contains($low,'null value')) return '结账付款方式契约未同步：payment_method 不应为空。请运行 v13.5.5 累计 SQL 后再结账。';
    return $m;
}
function v136_user_error(Throwable $e): string {
    if($e instanceof SalonosSupabaseHttpException){
        $code=strtoupper((string)($e->payload['code']??''));
        $blob=strtolower(json_encode($e->payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?: '');
        if($code==='PGRST202') return 'Supabase Runtime Contract 尚未同步。请运行 RUN_ONCE_V13_5_5_CUMULATIVE_RUNTIME.sql 后刷新页面。';
        if(in_array($code,['PGRST204','42703','42P01','428C9'],true)) return 'Supabase 数据表结构尚未同步。请运行 RUN_ONCE_V13_5_5_CUMULATIVE_RUNTIME.sql 后刷新页面。';
        if($code==='23502' && str_contains($blob,'payment_items') && str_contains($blob,'payment_method')) return '结账付款方式契约未同步：payment_method 不应为空。请运行 v13.5.5 累计 SQL 后再结账。';
        if($code==='23514' && str_contains($blob,'payment')) return '付款资料没有通过数据库规则检查，请确认付款方式与金额后重试。';
        if($code==='23502') return '这项操作有必填资料没有正确写入数据库。请先运行 v13.5.5 系统自检；如果 Contract 已 PASS，再重新提交一次。';
        if($code==='23503') return '这笔操作关联的资料已经不存在或不属于当前门店，请刷新后重试。';
        if($code==='23505') return '这笔资料已经存在，请不要重复提交。';
        if($code==='42501') return '当前账号没有执行这项操作的权限。';
    }
    return v136_safe_message_text($e->getMessage());
}

function ui_icon(string $name): string {
    $paths = [
        'home'=>'<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V20h13v-9.5"/><path d="M9.5 20v-6h5v6"/>',
        'plus'=>'<path d="M12 5v14M5 12h14"/>',
        'clock'=>'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'attendance'=>'<path d="M7 3h10v4H7z"/><path d="M5 7h14v14H5z"/><path d="M8 12h8M8 16h5"/>',
        'users'=>'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
        'chart'=>'<path d="M4 19V9M10 19V5M16 19v-7M22 19H2"/>',
        'analytics'=>'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M7 16v-4M12 16V8M17 16v-7"/>',
        'target'=>'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
        'book'=>'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V4H6.5A2.5 2.5 0 0 0 4 6.5z"/><path d="M4 6.5v13"/>',
        'menu'=>'<path d="M4 7h16M4 12h16M4 17h16"/>',
        'x'=>'<path d="m6 6 12 12M18 6 6 18"/>',
        'search'=>'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
        'award'=>'<circle cx="12" cy="8" r="5"/><path d="m8.5 12-1 9 4.5-2 4.5 2-1-9"/>',
        'box'=>'<path d="m3 7 9-4 9 4-9 4z"/><path d="M3 7v10l9 4 9-4V7"/><path d="M12 11v10"/>',
        'scissors'=>'<circle cx="6" cy="7" r="3"/><circle cx="6" cy="17" r="3"/><path d="m8.5 8.5 11 8.5M8.5 15.5 19.5 7"/>',
        'settings'=>'<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"/>',
        'branch'=>'<path d="M4 21V8l8-4 8 4v13"/><path d="M8 21v-5h8v5"/>',
        'employee'=>'<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2.5"/><path d="M5.5 17c.8-2.2 2-3.2 3.5-3.2s2.7 1 3.5 3.2M15 9h3M15 13h3"/>',
        'receipt'=>'<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6M9 16h4"/>',
    ];
    $path=$paths[$name] ?? $paths['home'];
    return '<svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'.$path.'</svg>';
}

$action=(string)($_POST['action'] ?? $_GET['action'] ?? '');

if ($action==='logout') { v13_business_logout(); redirect('index.php'); }
if ($action==='export_transfer_v132' && user() && v13_is_owner()) { v132_export_transfer_package(); }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        verify_csrf();
        if ($action==='supabase_owner_login') {
            v13_business_login(strtolower(trim((string)($_POST['identifier']??''))), (string)($_POST['password']??''));
            if (!empty($_SESSION['v13_needs_device_code'])) redirect('index.php?device_authorization=1');
            flash('success','老板已通过 Supabase 登录。');
            redirect('index.php?page=dashboard');
        }
        if ($action==='authorize_owner_device') {
            $token=trim((string)($_SESSION['pending_supabase_access_token']??''));
            if ($token==='') throw new RuntimeException('老板登录确认已过期，请重新登录。');
            [$deviceId,$tokenHash]=v13_device_identity();
            v13_rpc('redeem_device_activation_code',[
                'p_code'=>trim((string)($_POST['device_code']??'')),
                'p_device_id'=>$deviceId,
                'p_token_hash'=>$tokenHash,
                'p_device_name'=>substr((string)($_SERVER['HTTP_USER_AGENT']??'Browser'),0,120),
                'p_user_agent'=>substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,250),
            ],$token);
            v13_finish_business_login();
            flash('success','这台设备已经获得老板登录权限。');
            redirect('index.php?page=dashboard');
        }
        if ($action==='employee_login') {
            salonos_v13_employee_login((string)($_POST['identifier']??''));
            flash('success','员工已通过 Supabase 手机号 Session 登录。');
            redirect('index.php?page=dashboard');
        }
        if (!user()) throw new RuntimeException('请先登录。');
        if ($action==='attendance_ajax_v1361039') { salonos_v1361039_ajax(); }
        if ($action==='switch_store') {
            $id=trim((string)($_POST['store_id']??''));
            $stores=is_array(salonos_supabase_identity()['stores']??null)?salonos_supabase_identity()['stores']:[];
            $allowed=false; foreach($stores as $s) if((string)($s['id']??'')===$id)$allowed=true;
            if(!$allowed)throw new RuntimeException('这个分行不属于当前 Organization。');
            $_SESSION['v13_current_store_uuid']=$id;
            redirect('index.php?page='.rawurlencode((string)($_POST['return_page']??'customers')));
        }
        if ($action==='create_branch_modal_v1338') {
            if(!v13_is_owner()) throw new RuntimeException('只有老板可以建立新分行。');
            $code=trim((string)($_POST['branch_code']??''));
            $email=strtolower(trim((string)($_POST['email']??'')));
            $password=(string)($_POST['password']??'');
            $confirm=(string)($_POST['password_confirm']??'');
            $name=trim((string)($_POST['branch_name']??''));
            $phone=trim((string)($_POST['phone']??''));
            $address=trim((string)($_POST['address']??''));
            if($code==='' || $name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<8){
                throw new RuntimeException('请完整填写 BRN Code、分行名称、Email 和至少 8 位密码。');
            }
            if(!hash_equals($password,$confirm)) throw new RuntimeException('两次输入的密码不一致。');
            try{
                $auth=v13_auth_signup($email,$password,['full_name'=>$name,'salonos_role'=>'branch']);
            }catch(SalonosSupabaseHttpException $e){
                $m=strtolower($e->getMessage());
                if(str_contains($m,'already')||str_contains($m,'registered')||str_contains($m,'exists')) $auth=v13_auth_password($email,$password);
                else throw $e;
            }
            $token=v13_access_token_from_auth($auth);
            if($token===''){
                try{$auth=v13_auth_password($email,$password);$token=v13_access_token_from_auth($auth);}catch(Throwable $ignored){}
            }
            if($token==='') throw new RuntimeException('Supabase 没有返回分行账号 Session；请确认 Email 验证设置后再试。');
            $result=v13_rpc('redeem_branch_activation_code',[
                'p_code'=>$code,
                'p_branch_name'=>$name,
                'p_phone'=>$phone,
                'p_address'=>$address,
            ],$token);
            if(empty($result['store_id'])) throw new RuntimeException('分行建立失败，请确认 BRN Code 尚未过期并且资料与 Creator 生成时一致。');
            flash('success','分行账号已建立并加入当前 Organization。');
            redirect('index.php?page=branches');
        }
        if ($action==='save_employee') {
            $result=salonos_v13_save_employee_data();
            flash('success',!empty($result['created'])?'新员工与 Supabase 手机号登录已经建立。':'员工资料已经更新。');
            redirect('index.php?page=employees');
        }
        if ($action==='toggle_employee_status') {
            $message=salonos_v13_toggle_employee_status_data();
            flash('success',$message);
            redirect('index.php?page=employees');
        }
        if ($action==='employee_avatar_upload_v1354') {
            salonos_v1354_employee_avatar_upload();
            flash('success','员工头像已经更新。');
            $return=trim((string)($_POST['return_page']??'dashboard'))?:'dashboard';
            redirect('index.php?page='.rawurlencode($return));
        }
        if ($action==='owner_avatar_upload_v1361055') {
            salonos_v1361055_owner_avatar_upload();
            flash('success','老板头像已经更新。');
            $return=trim((string)($_POST['return_page']??'dashboard'))?:'dashboard';
            redirect('index.php?page='.rawurlencode($return));
        }
        if ($action==='create_customer') {
            $r=salonos_supabase_create_customer_data();
            if(v1352_is_ajax_request()) v1352_json_response(['success'=>true]+$r);
            flash('success',(string)$r['message']); redirect('index.php?page=customers&customer_id='.rawurlencode((string)$r['customer_id']));
        }
        if ($action==='update_customer') {
            $r=salonos_supabase_update_customer_data();
            if(v1352_is_ajax_request()) v1352_json_response(['success'=>true]+$r);
            flash('success',(string)$r['message']); redirect('index.php?page=customers&customer_id='.rawurlencode((string)$r['customer_id']));
        }
        if ($action==='topup_member_wallet') {
            $r=salonos_supabase_topup_member_wallet_data();
            if(v1352_is_ajax_request()) v1352_json_response(['success'=>true]+$r);
            flash('success',(string)$r['message']); redirect('index.php?page=customers&customer_id='.rawurlencode((string)$r['customer_id']));
        }
        if ($action==='member_product_purchase_v1353') {
            $r=salonos_supabase_member_product_purchase_data();
            if(v1352_is_ajax_request()) v1352_json_response(['success'=>true]+$r);
            flash('success',(string)$r['message']); redirect('index.php?page=customers&customer_id='.rawurlencode((string)$r['customer_id']));
        }
        if ($action==='save_membership_rules') {
            salonos_supabase_save_membership_rules_data(); flash('success','会员等级已更新。'); redirect('index.php?page=customers');
        }
        if ($action==='refund_receipt_v1361062') {
            $result=v1361062_workflow_rpc('v1361062_refund_receipt',[
                'p_payment_id'=>v1361062_required_uuid($_POST['payment_id']??null),
                'p_reason'=>trim((string)($_POST['reason']??'')),
                'p_external_confirmed'=>!empty($_POST['external_confirmed']),
                'p_external_reference'=>trim((string)($_POST['external_reference']??''))?:null,
                'p_stock_return_confirmed'=>!empty($_POST['stock_return_confirmed']),
            ]);
            flash('success',!empty($result['replayed'])?'该收据已经完成退款，没有重复冲销。':'已登记全额退款，库存与相关流水已冲销。');
            redirect(v1361062_receipt_url((string)$result['visit_id']));
        }
        if ($action==='review_operation_v1361062') {
            v1361062_workflow_rpc('v1361062_review_operation',[
                'p_kind'=>(string)($_POST['kind']??''),'p_subject_id'=>v1361062_required_uuid($_POST['subject_id']??null),
                'p_note'=>trim((string)($_POST['note']??'')),'p_pause_ai'=>!empty($_POST['pause_ai']),
            ]);
            flash('success','处理记录已保存。'); redirect('index.php?page=operations');
        }
        if ($action==='resume_conversation_v1361062') {
            v1361062_workflow_rpc('v1361062_resume_conversation',['p_conversation_id'=>v1361062_required_uuid($_POST['conversation_id']??null)]);
            flash('success','已恢复此对话的新消息自动回复，旧任务仍然跳过。'); redirect('index.php?page=operations');
        }
        if (($bridgePage = v132_handle_action($action)) !== null) {
            redirect('index.php?page='.rawurlencode($bridgePage));
        }
        if (v13_handle_full_action($action)) {
            if (in_array($action,['create_visit_v13','employee_create_visit_v13'],true)) {
                $createdId=trim((string)($_SESSION['v1331_last_visit_id']??''));
                unset($_SESSION['v1331_last_visit_id']);
                if($createdId==='') throw new RuntimeException('订单已建立，但无法取得订单编号。');
                $request=(string)($_POST['order_request_id']??'');
                $completed=$action==='create_visit_v13'&&v1361062_is_uuid($request)?'&order_created='.rawurlencode($request):'';
                if((string)($_POST['visit_type']??'walk_in')==='appointment'){
                    $raw=trim((string)($_POST['appointment_at']??$_POST['scheduled_at']??''));
                    $boardDate=preg_match('/^(\d{4}-\d{2}-\d{2})/',$raw,$m)?$m[1]:date('Y-m-d');
                    redirect('index.php?page=orders&board_date='.rawurlencode($boardDate).$completed);
                }
                redirect('index.php?page=confirm&id='.rawurlencode($createdId).$completed);
            }
            if($action==='board_arrive_v1344'){
                $visitId=trim((string)($_POST['visit_id']??''));
                if($visitId!=='') redirect('index.php?page=confirm&id='.rawurlencode($visitId));
            }
            $actionPages=[
              'save_service'=>'services','visit_status_v13'=>'orders','board_arrive_v1344'=>'orders','board_employee_status_v1344'=>'orders','employee_availability_v1344'=>'orders','assign_service_workers_v13'=>'orders','add_visit_product_v13'=>'orders','remove_visit_product_v13'=>'orders','employee_visit_status_v13'=>'orders','employee_signoff_v13'=>'orders','confirm_visit_v1331'=>'orders','checkout_v13'=>'orders',
              'save_product_v13'=>'products','adjust_stock_v13'=>'inventory','save_bundle_v13'=>'product_bundles','save_kpi_v13'=>'kpi','save_training_v13'=>'training','employee_training_v13'=>'training','save_settings_v13'=>'settings','save_commission_v13'=>'commission_tiers',
              'save_service_category_v1350'=>'services','archive_service_category_v1350'=>'services','delete_service_v1352'=>'services','save_inventory_v1350'=>'inventory','archive_inventory_v1350'=>'inventory','delete_product_v1352'=>'products','delete_bundle_v1352'=>'product_bundles','assign_kpi_v1350'=>'kpi_employee','save_commission_tier_v1350'=>'commission_tiers','archive_commission_tier_v1350'=>'commission_tiers','save_monthly_commission_override_v1350'=>'commission_monthly','add_role_v1352'=>'settings_roles','delete_role_v1352'=>'settings_roles','save_product_category_v1353'=>'stock_hub','archive_product_category_v1353'=>'stock_hub'
            ];
            $returnPage=trim((string)($_POST['return_page']??''));
            $allowedPages=array_keys(v132_titles());
            $target=($returnPage!=='' && in_array($returnPage,$allowedPages,true))?$returnPage:($actionPages[$action]??'dashboard');
            if($target==='training_course' && !empty($_POST['course_id'])) $target.='&id='.rawurlencode((string)$_POST['course_id']);
            if($target==='kpi_employee' && !empty($_POST['employee_id'])) $target.='&id='.rawurlencode((string)$_POST['employee_id']);
            if($target==='commission_monthly' && preg_match('/^\d{4}-\d{2}$/',(string)($_POST['month']??''))) $target.='&month='.rawurlencode((string)$_POST['month']);
            $redirectUrl='index.php?page='.$target;
            $boardDate=trim((string)($_POST['board_date']??''));
            if(str_starts_with($target,'orders') && preg_match('/^\d{4}-\d{2}-\d{2}$/',$boardDate)) $redirectUrl.='&board_date='.rawurlencode($boardDate);
            redirect($redirectUrl);
        }
    } catch(Throwable $err) {
        if(v1352_is_ajax_request()) v1352_json_response(['success'=>false,'message'=>v136_user_error($err)],422);
        flash('error',v136_user_error($err));
        if($action==='refund_receipt_v1361062' && v1361062_is_uuid($_POST['visit_id']??null)) redirect(v1361062_receipt_url((string)$_POST['visit_id']));
        if(in_array($action,['review_operation_v1361062','resume_conversation_v1361062'],true))redirect('index.php?page=operations');
        $requestedPage=(string)($_GET['page']??$_POST['return_page']??'');
        if($action==='save_employee'||$action==='toggle_employee_status')$requestedPage='employees';
        elseif($action==='create_branch_modal_v1338')$requestedPage='branches';
        elseif(in_array($action,['create_customer','update_customer','topup_member_wallet','member_product_purchase_v1353','save_membership_rules'],true))$requestedPage='customers';
        else {
            $map=['save_service'=>'services','create_visit_v13'=>'new_visit','employee_create_visit_v13'=>'new_visit','visit_status_v13'=>'orders','board_arrive_v1344'=>'orders','board_employee_status_v1344'=>'orders','employee_availability_v1344'=>'orders','assign_service_workers_v13'=>'orders','add_visit_product_v13'=>'orders','remove_visit_product_v13'=>'orders','employee_visit_status_v13'=>'orders','employee_signoff_v13'=>'orders','confirm_visit_v1331'=>'confirm','checkout_v13'=>'orders','save_product_v13'=>'products','adjust_stock_v13'=>'inventory','save_bundle_v13'=>'product_bundles','save_kpi_v13'=>'kpi','save_training_v13'=>'training','employee_training_v13'=>'training','save_settings_v13'=>'settings','save_commission_v13'=>'commission_tiers','save_service_category_v1350'=>'services','archive_service_category_v1350'=>'services','delete_service_v1352'=>'services','save_inventory_v1350'=>'inventory','archive_inventory_v1350'=>'inventory','delete_product_v1352'=>'products','delete_bundle_v1352'=>'product_bundles','assign_kpi_v1350'=>'kpi_employee','save_commission_tier_v1350'=>'commission_tiers','archive_commission_tier_v1350'=>'commission_tiers','save_monthly_commission_override_v1350'=>'commission_monthly','add_role_v1352'=>'settings_roles','delete_role_v1352'=>'settings_roles','save_product_category_v1353'=>'stock_hub','archive_product_category_v1353'=>'stock_hub'];
            if(isset($map[$action]))$requestedPage=$map[$action];
        }
        $back = !user() ? 'index.php' : 'index.php?page='.rawurlencode($requestedPage!==''?$requestedPage:(v13_is_owner()?'customers':'dashboard'));
        $boardDate=trim((string)($_POST['board_date']??$_GET['board_date']??''));
        if($requestedPage==='orders' && preg_match('/^\d{4}-\d{2}-\d{2}$/',$boardDate)) $back.='&board_date='.rawurlencode($boardDate);
        if($requestedPage==='kpi_employee' && !empty($_POST['employee_id'])) $back.='&id='.rawurlencode((string)$_POST['employee_id']);
        if($requestedPage==='commission_monthly' && preg_match('/^\d{4}-\d{2}$/',(string)($_POST['month']??''))) $back.='&month='.rawurlencode((string)$_POST['month']);
        if($action==='create_branch_modal_v1338' && user()) $back.='&new_branch=1';
        redirect($back);
    }
}

if (user()) {
    if (v13_is_owner()) {
        $token=v13_business_token();
        if ($token==='') { $_SESSION=[]; session_destroy(); session_name('salonos_v13_business'); session_start(); flash('error','Supabase 登录已过期，请重新登录。'); redirect('index.php'); }
        try { $_SESSION['supabase_identity']=salonos_supabase_owner_context($token); }
        catch(Throwable $e){ flash('error',v136_user_error($e)); v13_business_logout(); redirect('index.php'); }
    } else {
        try { salonos_v13_refresh_employee_context(); }
        catch(Throwable $e){ flash('error',v136_user_error($e)); v13_business_logout(); redirect('index.php'); }
    }
}


if (user() && $_SERVER['REQUEST_METHOD']==='GET' && $action==='export_analytics_v135') {
    try { v135_export_analytics_csv(); }
    catch(Throwable $e){ flash('error',v136_user_error($e)); redirect('index.php?page=analytics'); }
}

if (user() && $_SERVER['REQUEST_METHOD']==='GET' && $action==='dashboard_live_v1358') {
    // Identity/token refresh has finished. Let navigation use the PHP session
    // while this read-only snapshot is waiting on Supabase.
    v1361061_close_live_session();
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    try { echo json_encode(v1358_dashboard_live_payload(),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
    catch(Throwable $e){ http_response_code(500); echo json_encode(['error'=>v136_user_error($e)],JSON_UNESCAPED_UNICODE); exit; }
}

if (user() && $_SERVER['REQUEST_METHOD']==='GET' && $action==='search_customers') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $q=trim((string)($_GET['q']??''));
        if(mb_strlen($q)<1){echo '[]';exit;}
        if(v13_is_owner()){
            $rows=salonos_supabase_customer_search_rows($q,20);
            $rows=array_map(static fn($c)=>[
                'id'=>(string)($c['id']??''),'name'=>(string)($c['name']??''),'phone'=>(string)($c['phone']??''),
                'member_number'=>$c['member_number']??null,'member_level'=>$c['member_level']??null,'level_number'=>$c['level_number']??null
            ],$rows);
        } else {
            $session=trim((string)($_SESSION['v13_employee_session_token']??''));
            $rows=v13_rpc_json('v1331_employee_customer_search',['p_session_token'=>$session,'p_query'=>$q],'');
            if(!array_is_list($rows))$rows=is_array($rows['rows']??null)?$rows['rows']:[];
        }
        echo json_encode($rows,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
    } catch(Throwable $e){http_response_code(500);echo json_encode(['error'=>v136_user_error($e)],JSON_UNESCAPED_UNICODE);exit;}
}

if (user() && $_SERVER['REQUEST_METHOD']==='GET' && $action==='search_products') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    try {
        $q=trim((string)($_GET['q']??''));
        $categoryId=trim((string)($_GET['category_id']??''));
        $categoryName=trim((string)($_GET['category_name']??''));
        if(v13_is_owner()){
            $rows=v1353_sellable_product_catalog($q,$categoryId,$categoryName);
        }else{
            $session=trim((string)($_SESSION['v13_employee_session_token']??''));
            if($session==='') throw new RuntimeException('员工登录已过期。');
            // Do not hard-filter category_id inside the RPC: legacy imported products may only
            // have the old text category. Query safe retail fields first, then match UUID OR category name.
            $args=['p_session_token'=>$session,'p_query'=>$q,'p_category_id'=>null];
            $rows=v13_rpc_json('v1353_employee_product_search',$args,'');
            if(!array_is_list($rows)) $rows=is_array($rows['rows']??null)?$rows['rows']:[];
            $categoryNeedle=mb_strtolower($categoryName,'UTF-8');
            if($categoryId!==''){
                $rows=array_values(array_filter($rows,static function($row) use($categoryId,$categoryNeedle){
                    $rowCategoryId=trim((string)($row['category_id']??''));
                    $rowCategoryName=mb_strtolower(trim((string)($row['category']??'')),'UTF-8');
                    return ($rowCategoryId!=='' && $rowCategoryId===$categoryId) || ($categoryNeedle!=='' && $rowCategoryName===$categoryNeedle);
                }));
            }
            foreach($rows as &$row){
                $row['image_url']=v13510_product_image_url((string)($row['image_url']??''));
            }
            unset($row);
            $rows=array_slice($rows,0,50);
        }
        echo json_encode($rows,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
    } catch(Throwable $e){http_response_code(500);echo json_encode(['error'=>v136_user_error($e)],JSON_UNESCAPED_UNICODE);exit;}
}

if (user() && $_SERVER['REQUEST_METHOD']==='GET' && $action==='available_stylists') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $visitType=((string)($_GET['visit_type']??'walk_in')==='appointment')?'appointment':'walk_in';
        $rawServiceIds=trim((string)($_GET['service_ids']??''));
        $serviceIds=array_values(array_unique(array_filter(array_map('trim',$rawServiceIds===''?[]:explode(',',$rawServiceIds)))));
        $appointmentAt=trim((string)($_GET['appointment_at']??''));
        $visitId=trim((string)($_GET['visit_id']??''));
        $pool=v1361030_staff_pool_runtime($serviceIds,$visitType,$appointmentAt,$visitId);
        $payload=[
            'ok'=>true,
            'validated'=>!empty($pool['validated']),
            'visit_type'=>$visitType,
            'common'=>is_array($pool['common']??null)?$pool['common']:[],
            'by_service'=>is_array($pool['by_service']??null)?$pool['by_service']:[],
            'assistant_pool'=>is_array($pool['assistant_pool']??null)?$pool['assistant_pool']:[],
            'total_duration_minutes'=>(int)($pool['total_duration_minutes']??30),
        ];
        echo json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
    } catch(Throwable $e){http_response_code(500);echo json_encode(['ok'=>false,'error'=>v136_user_error($e)],JSON_UNESCAPED_UNICODE);exit;}
}


if (user() && $_SERVER['REQUEST_METHOD']==='GET' && $action==='service_board_live_v13696') {
    v1361061_close_live_session();
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    try {
        $boardDate=v1344_board_date($_GET['board_date']??null);
        echo json_encode(v13696_service_board_live_payload($boardDate),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        exit;
    } catch(Throwable $e) {
        http_response_code(500);
        echo json_encode(['ok'=>false,'error'=>v136_user_error($e)],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        exit;
    }
}

if (user() && $_SERVER['REQUEST_METHOD']==='GET' && $action==='service_board_modal') {
    header('Content-Type: text/html; charset=utf-8');
    try {
        $visitId=trim((string)($_GET['id']??''));
        if($visitId==='') throw new RuntimeException('找不到订单。');
        $boardDate=v1344_board_date($_GET['board_date']??null);
        echo v1344_service_board_modal_content($visitId,$boardDate);
        exit;
    } catch(Throwable $e) {
        http_response_code(403);
        echo '<div class="commission-modal-error"><strong>无法打开订单</strong><span>'.e(v136_user_error($e)).'</span><button class="btn btn-light" type="button" data-service-board-modal-close>关闭</button></div>';
        exit;
    }
}

function render_login_v13(): void {
    $flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
    ?>
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
  <title>登录 · SalonOS</title>
  <link rel="manifest" href="manifest.webmanifest">
  <meta name="theme-color" content="#070b10">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="SalonOS">
  <link rel="apple-touch-icon" href="assets/icons/apple-touch-icon.png">
  <link rel="icon" href="assets/icons/favicon.ico">
  <link rel="stylesheet" href="assets/app.css?v=<?=e(salonos_asset_version())?>">
  <link rel="stylesheet" href="assets/pwa.css?v=<?=e(salonos_asset_version())?>">
  <link rel="stylesheet" href="assets/luxe.css?v=<?=e(salonos_asset_version())?>">
  <link rel="stylesheet" href="assets/v13-supabase-compat.css?v=<?=e(salonos_asset_version())?>">
  <link rel="stylesheet" href="assets/v13-attendance.css?v=<?=e(salonos_asset_version())?>">
</head>
<body class="login-body">
<main class="login-shell">
  <span class="login-decoration login-decoration-a" aria-hidden="true"></span>
  <span class="login-decoration login-decoration-b" aria-hidden="true"></span>
  <span class="login-decoration login-decoration-c" aria-hidden="true"></span>

  <section class="login-brand-showcase" aria-hidden="true">
    <img src="assets/icons/icon-192.png" alt="">
    <span>CREATOR MASTER SYSTEM</span>
    <h2>SalonOS</h2>
    <p>美业智能运营系统 · 数据驱动 · 安全隔离 · 云端协同</p>
  </section>

  <section class="login-card login-card-passwordless">
    <div class="login-brand"><span class="brand-mark">S</span><strong>SalonOS</strong></div>
    <div class="login-heading">
      <span class="eyebrow">SALON OPERATING SYSTEM · SUPABASE ONLY</span>
      <h1>员工手机号登录</h1>
      <p class="sub">老板启用账号后，员工不需要密码</p>
    </div>

    <?php if($flash): ?><div class="alert alert-<?=e((string)$flash['type'])?>"><?=e(v136_safe_message_text((string)$flash['message']))?></div><?php endif; ?>

    <form method="post" class="employee-phone-login-form">
      <input type="hidden" name="csrf" value="<?=csrf_token()?>">
      <input type="hidden" name="action" value="employee_login">
      <div class="field">
        <label for="employee-login-phone">员工手机号码</label>
        <div class="input-shell"><span class="input-icon" aria-hidden="true">☎</span><input id="employee-login-phone" class="input" name="identifier" type="tel" inputmode="tel" autocomplete="tel" placeholder="例如 0123308891" required autofocus></div>
        <small class="field-help">账号必须由老板在员工管理中启用；停用后登录会立即失效。</small>
      </div>
      <button class="btn btn-primary btn-block login-submit">进入员工端 <span>→</span></button>
    </form>

    <details class="owner-login-panel">
      <summary>老板登录（Supabase）</summary>
      <form method="post" class="owner-login-form">
        <input type="hidden" name="csrf" value="<?=csrf_token()?>">
        <input type="hidden" name="action" value="supabase_owner_login">
        <div class="field"><label for="owner-login-email">老板电子邮箱</label><input id="owner-login-email" class="input" name="identifier" type="email" autocomplete="username" required></div>
        <div class="field"><label for="owner-login-password">密码</label><div class="input-shell"><span class="input-icon" aria-hidden="true">⌑</span><input id="owner-login-password" class="input" name="password" type="password" autocomplete="current-password" required><button class="password-toggle" type="button" data-password-toggle aria-label="显示或隐藏密码">查看</button></div></div>
        <button class="btn btn-light btn-block" type="submit">老板登录 →</button>
      </form>
      <small class="field-help" style="display:block;margin-top:10px">老板身份、Organization、分行和设备授权全部由 Supabase 验证。</small>
    </details>

    <a class="owner-register-link" href="register.php"><strong>还没有老板账号？</strong><span>使用 Creator 开户 Code 注册 →</span></a>
    <div class="demo-box"><div class="demo-icon">◎</div><div><strong>v12.4.4 UI · v13 Supabase</strong><span>界面锁定使用 v12.4.4；业务数据只使用 Supabase。</span></div></div>
  </section>
  <footer class="login-footer">Salon operating system · Malaysia</footer>
</main>
<script src="assets/app.js?v=<?=e(salonos_asset_version())?>"></script>
<script src="assets/v13-product-member.js?v=<?=e(salonos_asset_version())?>"></script>
<script src="assets/v13-attendance.js?v=<?=e(salonos_asset_version())?>"></script>
<script src="assets/pwa-install.js?v=<?=e(salonos_asset_version())?>" data-pwa-name="SalonOS" data-pwa-sw="sw.js?v=<?=e(salonos_asset_version())?>" data-pwa-scope="./" data-pwa-icon="assets/icons/icon-192.png" data-pwa-theme="app" data-pwa-version-url="version.php"></script>
</body></html>
<?php }

function render_device_auth_v13(): void {
    $flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
    $identity=is_array($_SESSION['pending_supabase_identity']??null)?$_SESSION['pending_supabase_identity']:[];
    ?>
<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>授权新设备 · SalonOS</title><link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#070b10"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><link rel="apple-touch-icon" href="assets/icons/apple-touch-icon.png"><link rel="icon" href="assets/icons/favicon.ico"><link rel="stylesheet" href="assets/app.css?v=<?=e(salonos_asset_version())?>"><link rel="stylesheet" href="assets/pwa.css?v=<?=e(salonos_asset_version())?>"><link rel="stylesheet" href="assets/luxe.css?v=<?=e(salonos_asset_version())?>"><link rel="stylesheet" href="assets/v13-supabase-compat.css?v=<?=e(salonos_asset_version())?>">
  <link rel="stylesheet" href="assets/v13-attendance.css?v=<?=e(salonos_asset_version())?>"></head>
<body class="login-body"><main class="login-shell"><section class="login-card owner-device-card"><div class="device-shield">✓</div><div class="login-heading"><span class="eyebrow">FIRST DEVICE AUTHORIZATION</span><h1>这是老板／分行老板的新设备</h1><p class="sub"><?=e((string)($identity['organization_name']??'SalonOS'))?> · 请向 Creator 取得 5 分钟 DVC Code。</p></div><?php if($flash): ?><div class="alert alert-<?=e((string)$flash['type'])?>"><?=e(v136_safe_message_text((string)$flash['message']))?></div><?php endif; ?><div class="device-flow"><div><span>1</span><p><strong>联系 SalonOS 创作者</strong><small>由 Creator 为这个老板账号生成设备 Code。</small></p></div><div><span>2</span><p><strong>5 分钟内输入</strong><small>成功后这台浏览器／PWA 会成为可信设备。</small></p></div></div><form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="authorize_owner_device"><div class="field"><label>设备登录 Code</label><input class="input license-code-input" name="device_code" placeholder="DVC-XXXX-XXXX" autocomplete="one-time-code" required autofocus></div><button class="btn btn-primary btn-block login-submit">授权这台设备 <span>→</span></button></form><a class="device-cancel-link" href="index.php?action=logout">返回重新登录</a><div class="demo-box"><div class="demo-icon">◎</div><div><strong>Supabase Trusted Device</strong><span>Creator 撤销设备后会要求重新取得 DVC Code。</span></div></div></section></main><script src="assets/app.js?v=<?=e(salonos_asset_version())?>"></script>
<script src="assets/v13-product-member.js?v=<?=e(salonos_asset_version())?>"></script>
<script src="assets/v13-attendance.js?v=<?=e(salonos_asset_version())?>"></script></body></html>
<?php }

function salonos_shell_title(string $title,string $language): string {
    if($language!=='en' || !preg_match('/[\x{3400}-\x{9fff}]/u',$title)) return $title;
    $dictionary=json_decode((string)@file_get_contents(__DIR__.'/assets/i18n-en.json'),true);
    return (string)($dictionary[$title]??'SalonOS');
}

function render_shell_start(string $title,string $page): void {
    $flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
    $activePage=v132_nav_active_page($page);
    $navPrimary=[['dashboard','home','工作台'],['new_visit','plus','新建顾客订单'],['orders','clock','服务现场'],['attendance','attendance','员工打卡'],['customers','users','顾客与会员'],['performance','chart','员工业绩']];
    $navManage=[['employees','employee','员工管理'],['order_history','receipt','订单记录'],['analytics','analytics','经营分析'],['kpi','target','KPI 管理'],['training','book','培训中心'],['services','scissors','服务项目'],['stock_hub','box','产品与库存'],['commission','award','抽成管理'],['branches','branch','分行管理'],['settings','settings','系统设置']];
    $primaryPermissionMap=['dashboard'=>['dashboard.view'],'new_visit'=>['visits.create'],'orders'=>['orders.view','orders.manage'],'attendance'=>['attendance.scan','attendance.team.view','attendance.station'],'customers'=>['customers.view','customers.manage'],'performance'=>['performance.view']];
    $managePermissionMap=['employees'=>['employees.manage'],'order_history'=>['order_history.view'],'analytics'=>['analytics.view'],'marketing_analytics'=>['analytics.view'],'kpi'=>['kpi.manage','kpi.view'],'training'=>['training.manage','training.view'],'services'=>['services.view','services.manage'],'stock_hub'=>['inventory.view','inventory.manage','products.view','products.manage'],'commission'=>['commission.manage','commission.view'],'settings'=>['settings.view']];
    $identity=salonos_supabase_identity()??[];
    $stores=is_array($identity['stores']??null)?$identity['stores']:[];
    $roleLabel=can_manage()?'老板 / 系统管理员':((string)(user()['position']??'员工').' · '.(string)(user()['role_label']??'员工'));
    $roleChip=can_manage()?'OWNER':strtoupper((string)(user()['role']??'STAFF'));
    $uiLanguage=v1361051_effective_ui_language();
    ?>
<!doctype html>
<html lang="<?=$uiLanguage==='en'?'en':'zh-CN'?>" data-ui-language="<?=e($uiLanguage)?>" class="<?=$uiLanguage==='en'?'i18n-booting':''?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
  <meta name="theme-color" content="#070b10">
  <title><?=e(salonos_shell_title($title,$uiLanguage))?> · <?=e(system_setting('business_name','SalonOS'))?></title>
<?php if($uiLanguage==='en'): ?>
  <style>
    html.i18n-booting{background:#070b10;color:#f5f1e8}
    html.i18n-booting body>:not(.i18n-status){visibility:hidden!important;opacity:0!important}
    .i18n-status,.i18n-status-error,.i18n-status-noscript{display:none}
    html.i18n-booting .i18n-status{display:grid;position:fixed;inset:0;z-index:2147483647;place-content:center;text-align:center;padding:24px;background:#070b10;color:#f4c978;font:700 15px/1.5 system-ui,sans-serif}
    .i18n-status a{color:inherit;text-decoration:underline}
    .i18n-status-loading{animation:salonos-language-wait .01s .2s backwards}
    @keyframes salonos-language-wait{from{opacity:0}to{opacity:1}}
    html.i18n-error .i18n-status-loading{display:none}
    html.i18n-error .i18n-status-error{display:block}
  </style>
  <link rel="preload" href="assets/i18n-en.json?v=<?=e(salonos_asset_version())?>" as="fetch" crossorigin="anonymous">
  <script defer src="assets/i18n.js?v=<?=e(salonos_asset_version())?>" onerror="document.documentElement.classList.add('i18n-error')"></script>
  <noscript><style>.i18n-status-loading{display:none}.i18n-status-noscript{display:block}</style></noscript>
<?php endif; ?>
  <link rel="manifest" href="manifest.webmanifest">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="SalonOS">
  <link rel="apple-touch-icon" href="assets/icons/apple-touch-icon.png">
  <link rel="icon" href="assets/icons/favicon.ico">
  <link rel="stylesheet" href="assets/app.css?v=<?=e(salonos_asset_version())?>">
  <link rel="stylesheet" href="assets/pwa.css?v=<?=e(salonos_asset_version())?>">
  <link rel="stylesheet" href="assets/luxe.css?v=<?=e(salonos_asset_version())?>">
  <link rel="stylesheet" href="assets/v13-supabase-compat.css?v=<?=e(salonos_asset_version())?>">
  <link rel="stylesheet" href="assets/v13-attendance.css?v=<?=e(salonos_asset_version())?>">
</head>
<body class="<?=v13_is_owner()?'owner-shell':'employee-shell'?>"<?php if(v13_is_owner()&&v1361062_is_uuid($_GET['order_created']??null)):?> data-completed-visit-request="<?=e((string)$_GET['order_created'])?>" data-completed-visit-draft="<?=e(v1361062_draft_key())?>"<?php endif;?>>
<?php if($uiLanguage==='en'): ?>
  <div class="i18n-status">
    <span class="i18n-status-loading" role="status">Loading SalonOS…</span>
    <div class="i18n-status-error" role="alert">The English interface could not load. <a href="">Reload page</a></div>
    <div class="i18n-status-noscript">Enable JavaScript to load the English interface.</div>
  </div>
<?php endif; ?>
<div class="app">
  <div class="sidebar-overlay" data-sidebar-overlay></div>
  <aside class="sidebar" aria-label="主菜单">
    <div class="sidebar-brand-row"><div class="brand"><span class="brand-mark">S</span><span><?=e(system_setting('business_name','SalonOS'))?></span></div><button class="sidebar-close" type="button" data-menu-close aria-label="关闭菜单"><?=ui_icon('x')?></button></div>
    <div class="nav-label">门店运营</div>
    <nav class="nav">
      <?php foreach($navPrimary as $item): if(isset($primaryPermissionMap[$item[0]])&&!has_any_permission($primaryPermissionMap[$item[0]]))continue; ?>
        <a class="<?=$activePage===$item[0]?'active':''?>" href="index.php?page=<?=$item[0]?>"><?=ui_icon($item[1])?><span><?=$item[2]?></span></a>
      <?php endforeach; ?>
      <div class="nav-label">成长与管理</div>
      <?php foreach($navManage as $item): if(isset($managePermissionMap[$item[0]])&&!has_any_permission($managePermissionMap[$item[0]]))continue; ?>
        <a class="<?=$activePage===$item[0]?'active':''?>" href="index.php?page=<?=$item[0]?>"><?=ui_icon($item[1])?><span><?=$item[2]?></span></a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot"><span class="system-dot"></span><div><strong><?=e((string)(current_store()['name']??'SalonOS'))?></strong><small>v<?=e(salonos_app_version())?> · Supabase Only</small></div></div>
  </aside>

  <section class="main">
    <header class="topbar">
      <div class="topbar-title"><button class="menu-btn" type="button" data-menu aria-label="打开菜单"><?=ui_icon('menu')?></button><div><small><?=can_manage()?'MANAGEMENT CONSOLE':'EMPLOYEE WORKSPACE'?></small><strong><?=e($title)?></strong></div></div>
      <?php if(can_manage() && count($stores)>1): ?>
      <form class="topbar-store-switch" method="post" data-store-switch-form><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="switch_store"><input type="hidden" name="return_page" value="<?=e($page)?>"><span><?=ui_icon('branch')?></span><select name="store_id" class="select" onchange="this.form.submit()" aria-label="切换分行"><?php foreach($stores as $store): ?><option value="<?=e((string)$store['id'])?>" <?=((string)(current_store()['id']??'')===(string)$store['id'])?'selected':''?>><?=e((string)$store['name'])?></option><?php endforeach; ?></select></form>
      <?php endif; ?>
      <?php if(v13_is_owner()):$ownerAvatar=salonos_v1361055_owner_avatar_url();?><button class="user-chip v1354-profile-trigger" type="button" data-v1350-modal-open="owner-profile" aria-label="打开老板个人资料"><div class="avatar v1354-avatar"><?php if($ownerAvatar!==''):?><img src="<?=e($ownerAvatar)?>" alt="老板头像"><?php else:?><?=e(mb_substr((string)(user()['employee_name']??'U'),0,1))?><?php endif;?></div><div class="user-chip-copy"><strong><?=e((string)(user()['employee_name']??user()['email']??'User'))?></strong><small><?=e($roleLabel)?> · 点头像打开个人菜单</small><small class="supabase-identity-chip">Supabase · <?=e((string)($identity['organization_name']??'SalonOS'))?> · <?=e($roleChip)?></small></div></button><?php else:$employeeAvatar=salonos_v1354_employee_avatar_url();?><button class="user-chip v1354-profile-trigger" type="button" data-v1350-modal-open="employee-profile" aria-label="打开员工个人资料"><div class="avatar v1354-avatar"><?php if($employeeAvatar!==''):?><img src="<?=e($employeeAvatar)?>" alt="员工头像"><?php else:?><?=e(mb_substr((string)(user()['employee_name']??'U'),0,1))?><?php endif;?></div><div class="user-chip-copy"><strong><?=e((string)(user()['employee_name']??'员工'))?></strong><small><?=e($roleLabel)?> · 点头像打开个人菜单</small><small class="supabase-identity-chip">Supabase · <?=e((string)($identity['organization_name']??'SalonOS'))?></small></div></button><?php endif;?>
    </header>
    <?php if(v13_is_owner()):$ownerAvatar=salonos_v1361055_owner_avatar_url();?><div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="owner-profile"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1354-profile-modal"><div class="commission-modal-header"><div><span class="card-kicker">MY PROFILE</span><h3>老板个人资料</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><div class="v1354-profile-hero"><div class="v1354-profile-avatar"><?php if($ownerAvatar!==''):?><img src="<?=e($ownerAvatar)?>" alt="老板头像"><?php else:?><?=e(mb_substr((string)(user()['employee_name']??'U'),0,1))?><?php endif;?></div><div><h2><?=e((string)(user()['employee_name']??'老板'))?></h2><p><?=e($roleLabel)?> · <?=e((string)(user()['email']??''))?></p></div></div><form method="post" enctype="multipart/form-data" class="v1354-avatar-form"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="owner_avatar_upload_v1361055"><input type="hidden" name="return_page" value="<?=e($page)?>"><div class="v1351-media-upload" data-v1351-media-upload><div class="v1351-media-preview"><?php if($ownerAvatar!==''):?><img src="<?=e($ownerAvatar)?>" alt="头像预览" data-v1351-image-preview><span hidden data-v1351-image-empty>尚未选择头像</span><?php else:?><img hidden alt="头像预览" data-v1351-image-preview><span data-v1351-image-empty>尚未选择头像</span><?php endif;?></div><div class="v1351-media-control"><strong>更换头像</strong><input class="input" type="file" name="avatar_file" accept="image/jpeg,image/png,image/webp" data-v1351-image-input required><small>头像会裁切为方形并压缩后保存到 Supabase Storage。</small></div></div><button class="btn btn-primary btn-block">保存头像</button></form><a class="btn btn-danger-soft btn-block v1354-logout-button" href="index.php?action=logout">退出登录</a></div></section></div><?php endif;?>
    <?php if(!v13_is_owner()):$employeeAvatar=salonos_v1354_employee_avatar_url();?><div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="employee-profile"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1354-profile-modal"><div class="commission-modal-header"><div><span class="card-kicker">MY PROFILE</span><h3>员工个人资料</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><div class="v1354-profile-hero"><div class="v1354-profile-avatar"><?php if($employeeAvatar!==''):?><img src="<?=e($employeeAvatar)?>" alt="员工头像"><?php else:?><?=e(mb_substr((string)(user()['employee_name']??'U'),0,1))?><?php endif;?></div><div><h2><?=e((string)(user()['employee_name']??'员工'))?></h2><p><?=e((string)(user()['position']??''))?> · <?=e(v132_role_label((string)(user()['role']??'staff')))?></p></div></div><form method="post" enctype="multipart/form-data" class="v1354-avatar-form"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="employee_avatar_upload_v1354"><input type="hidden" name="return_page" value="<?=e($page)?>"><div class="v1351-media-upload" data-v1351-media-upload><div class="v1351-media-preview"><?php if($employeeAvatar!==''):?><img src="<?=e($employeeAvatar)?>" alt="头像预览" data-v1351-image-preview><span hidden data-v1351-image-empty>尚未选择头像</span><?php else:?><img hidden alt="头像预览" data-v1351-image-preview><span data-v1351-image-empty>尚未选择头像</span><?php endif;?></div><div class="v1351-media-control"><strong>更换头像</strong><input class="input" type="file" name="avatar_file" accept="image/jpeg,image/png,image/webp" data-v1351-image-input required><small>系统会裁切为方形并压缩后放到 Supabase Storage，不把照片塞进数据库。</small></div></div><button class="btn btn-primary btn-block">保存头像</button></form><a class="btn btn-danger-soft btn-block v1354-logout-button" href="index.php?action=logout">退出登录</a></div></section></div><?php endif;?>
    <main class="content">
      <?php if($flash): ?><div class="alert alert-<?=e((string)$flash['type'])?>"><?=e(v136_safe_message_text((string)$flash['message']))?></div><?php endif; ?>
      <?php if(v13_is_owner()): $contract=v135_runtime_contract_info(); if(empty($contract['ok'])): ?><div class="alert alert-warning runtime-contract-banner"><strong>数据库版本契约尚未同步到 v13.5.5。</strong> 网站会尽量使用兼容模式继续显示，不会因为单个新 RPC 缺失就把整页服务现场打掉。请在 Supabase SQL Editor 运行 <code>RUN_ONCE_V13_5_5_CUMULATIVE_RUNTIME.sql</code>，然后刷新页面。</div><?php endif; endif; ?>
<?php }

function render_shell_end(): void {
    ?>
    </main>
  </section>
</div>
<script src="assets/app.js?v=<?=e(salonos_asset_version())?>"></script>
<script src="assets/v13-product-member.js?v=<?=e(salonos_asset_version())?>"></script>
<script src="assets/v13-attendance.js?v=<?=e(salonos_asset_version())?>"></script>
<script src="assets/pwa-install.js?v=<?=e(salonos_asset_version())?>" data-pwa-name="SalonOS" data-pwa-sw="sw.js?v=<?=e(salonos_asset_version())?>" data-pwa-scope="./" data-pwa-icon="assets/icons/icon-192.png" data-pwa-theme="app" data-pwa-version-url="version.php"></script>
</body></html>
<?php }

if (!user()) {
    if (!empty($_SESSION['v13_needs_device_code']) && ($_GET['device_authorization']??'')==='1') render_device_auth_v13(); else render_login_v13();
    exit;
}

$page=(string)($_GET['page']??'dashboard');
if($page==='orders'){
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}
$titles=v132_titles();
$titles['operations']='待处理事项';
$titles['receipt']='收据与退款';
$title=$titles[$page]??'SalonOS';
render_shell_start($title,$page);
try {
    $pagePermissionMap=['dashboard'=>['dashboard.view'],'new_visit'=>['visits.create'],'orders'=>['orders.view','orders.manage'],'attendance'=>['attendance.scan','attendance.team.view','attendance.station'],'customers'=>['customers.view','customers.manage'],'performance'=>['performance.view'],'performance_employee'=>['performance.view'],'order_history'=>['order_history.view'],'analytics'=>['analytics.view'],'marketing_analytics'=>['analytics.view','marketing.view'],'kpi'=>['kpi.view','kpi.manage'],'kpi_employee'=>['kpi.view','kpi.manage'],'training'=>['training.view','training.manage'],'training_course'=>['training.view','training.manage'],'services'=>['services.view','services.manage'],'stock_hub'=>['inventory.view','inventory.manage','products.view','products.manage'],'products'=>['products.view','products.manage'],'inventory'=>['inventory.view','inventory.manage'],'product_bundles'=>['products.view','products.manage'],'product_showcase'=>['products.view'],'commission'=>['commission.view','commission.manage'],'commission_monthly'=>['commission.view','commission.manage'],'commission_tiers'=>['commission.view','commission.manage'],'branches'=>['branches.view','branches.manage'],'settings'=>['settings.view'],'settings_general'=>['settings.general.view'],'settings_roles'=>['settings.roles.view'],'settings_whatsapp'=>['settings.whatsapp.view'],'settings_marketing'=>['settings.marketing.view'],'data_import'=>['settings.data_import.view'],'data_transfer'=>['settings.data_transfer.view']];
    if(!v13_is_owner() && isset($pagePermissionMap[$page]) && !has_any_permission($pagePermissionMap[$page])) { echo '<section class="card empty-state"><h3>没有这个功能的权限</h3><p>这个入口不会显示在员工菜单里；请让老板到「员工权限角色」为你的职位开启权限。</p></section>'; }
    elseif ($page==='customers' && v13_is_owner()) page_customers_supabase();
    elseif ($page==='customers') page_customers_employee_v1354();
    elseif ($page==='employees' && v13_is_owner()) page_employees_supabase();
    elseif ($page==='attendance') page_attendance_v1361039();
    elseif (v132_render_page($page)) {}
    elseif (!v13_render_full_page($page)) echo '<section class="card" style="padding:24px"><h2>找不到页面</h2></section>';
} catch(Throwable $pageError) {
    $msg=$pageError->getMessage(); $low=strtolower($msg); $safeMsg=v136_user_error($pageError);
    if(str_contains($low,'pgrst202')||str_contains($low,'pgrst204')||str_contains($low,'schema cache')){
        echo '<section class="card runtime-contract-error" style="padding:24px"><span class="eyebrow">DATABASE CONTRACT MISMATCH</span><h2>网站版本与 Supabase Schema 尚未同步</h2><div class="alert alert-warning">请运行 <strong>RUN_ONCE_V13_5_5_CUMULATIVE_RUNTIME.sql</strong>。这个累计补丁会补齐当前 v13.5.5 已知字段、表、Storage 与业务 RPC，并要求 PostgREST 刷新 Schema Cache。</div><p class="muted">系统不会自动改用 InfinityFree MySQL。提示：'.e($safeMsg).'</p><a class="btn btn-light" href="system-test.php">打开完整系统自检 →</a></section>';
    }else{
        echo '<section class="card" style="padding:24px"><span class="eyebrow">SUPABASE MODULE ERROR</span><h2>这个模块暂时无法读取</h2><div class="alert alert-error">'.e($safeMsg).'</div><p class="muted">请打开系统设置 → 完整系统自检；v13 不会回退读取 InfinityFree MySQL。</p></section>';
    }
}
render_shell_end();
