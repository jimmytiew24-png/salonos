<?php
declare(strict_types=1);
session_start(); require __DIR__.'/v13_supabase.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  try{
    $code=trim((string)($_POST['branch_code']??''));$email=strtolower(trim((string)($_POST['email']??'')));$password=(string)($_POST['password']??'');$confirm=(string)($_POST['password_confirm']??'');$name=trim((string)($_POST['branch_name']??''));$phone=trim((string)($_POST['phone']??''));$address=trim((string)($_POST['address']??''));
    if($code===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<8||$name==='')throw new RuntimeException('请完整填写 BRN Code、分行名称、Email 和至少 8 位密码。');
    if(!hash_equals($password,$confirm))throw new RuntimeException('两次密码不一致。');
    try{$auth=v13_auth_signup($email,$password,['full_name'=>$name,'salonos_role'=>'branch']);}catch(SalonosSupabaseHttpException $e){$m=strtolower($e->getMessage());if(str_contains($m,'already')||str_contains($m,'registered')||str_contains($m,'exists'))$auth=v13_auth_password($email,$password);else throw $e;}
    $token=v13_access_token_from_auth($auth);if($token===''){try{$auth=v13_auth_password($email,$password);$token=v13_access_token_from_auth($auth);}catch(Throwable $e){}}
    if($token==='')throw new RuntimeException('Supabase 没有返回登录 Session；请确认 Email 验证设置。');
    $r=v13_rpc('redeem_branch_activation_code',['p_code'=>$code,'p_branch_name'=>$name,'p_phone'=>$phone,'p_address'=>$address],$token);
    if(empty($r['store_id']))throw new RuntimeException('分行建立失败。');
    $_SESSION['flash']=['type'=>'success','message'=>'分行账号、Store 与独立订阅已经建立在 Supabase。'];header('Location:index.php');exit;
  }catch(Throwable $e){$error=$e->getMessage();}
}
function br_e(string $v):string{return htmlspecialchars($v,ENT_QUOTES,'UTF-8');}
?><!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>注册分行 · SalonOS</title><link rel="stylesheet" href="assets/app.css?v=13.4.4"><link rel="stylesheet" href="assets/luxe.css?v=13.4.4"><link rel="stylesheet" href="assets/v13-supabase-compat.css?v=13.4.4"></head><body class="login-body"><main class="register-shell"><section class="register-intro"><div class="login-brand"><span class="brand-mark">S</span><strong>SalonOS</strong></div><span class="eyebrow">BRANCH SUBSCRIPTION</span><h1>注册分行账号</h1><p>BRN Code 必须由 Creator 为指定 Organization、分行名称和 Email 生成。每个分行有自己的订阅。</p></section><section class="login-card register-card"><div class="login-heading"><span class="eyebrow">NEW BRANCH</span><h2>建立分行</h2><p class="sub"><a href="index.php">返回登录</a></p></div><?php if($error):?><div class="alert alert-error"><?=br_e($error)?></div><?php endif;?><form method="post"><div class="field"><label>BRN Code *</label><input class="input license-code-input" name="branch_code" placeholder="BRN-XXXX-XXXX" required></div><div class="field"><label>分行名称 *</label><input class="input" name="branch_name" required></div><div class="field"><label>分行 Email *</label><input class="input" type="email" name="email" required></div><div class="form-grid"><div class="field"><label>密码 *</label><input class="input" type="password" name="password" minlength="8" required></div><div class="field"><label>再次输入 *</label><input class="input" type="password" name="password_confirm" minlength="8" required></div><div class="field"><label>电话</label><input class="input" name="phone"></div><div class="field span-2"><label>地址</label><textarea class="input" name="address"></textarea></div></div><button class="btn btn-primary btn-block">验证 BRN Code 并建立分行 →</button></form></section></main></body></html>
