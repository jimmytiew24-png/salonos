<?php
declare(strict_types=1);
session_start();
require __DIR__ . '/v13_supabase.php';

$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        $code=trim((string)($_POST['activation_code']??''));
        $ownerName=trim((string)($_POST['owner_name']??''));
        $ownerEmail=strtolower(trim((string)($_POST['owner_email']??'')));
        $ownerPhone=trim((string)($_POST['owner_phone']??''));
        $password=(string)($_POST['password']??'');
        $confirm=(string)($_POST['password_confirm']??'');
        $businessName=trim((string)($_POST['business_name']??''));
        $businessPhone=trim((string)($_POST['business_phone']??''));
        $businessAddress=trim((string)($_POST['business_address']??''));
        if($ownerName===''||!filter_var($ownerEmail,FILTER_VALIDATE_EMAIL)||strlen($password)<8||$businessName===''||$code===''){
            throw new RuntimeException('请完整填写开户 Code、老板资料、至少 8 位密码和门店名称。');
        }
        if(!hash_equals($password,$confirm))throw new RuntimeException('两次输入的密码不一致。');

        $valid=v13_first_rpc_row(v13_rpc('validate_owner_activation_code',['p_code'=>$code],''));
        if(empty($valid['valid']))throw new RuntimeException('Creator 开户 Code 无效、已使用或已经过期。');

        $auth=[];
        try{
            $auth=v13_auth_signup($ownerEmail,$password,['full_name'=>$ownerName,'phone'=>$ownerPhone,'salonos_role'=>'owner']);
        }catch(SalonosSupabaseHttpException $e){
            $msg=strtolower($e->getMessage());
            if(str_contains($msg,'already')||str_contains($msg,'registered')||str_contains($msg,'exists')){
                $auth=v13_auth_password($ownerEmail,$password);
            }else{ throw $e; }
        }
        $token=v13_access_token_from_auth($auth);
        if($token===''){
            try{ $auth=v13_auth_password($ownerEmail,$password); $token=v13_access_token_from_auth($auth); }catch(Throwable $e){}
        }
        if($token==='')throw new RuntimeException('Supabase 已建立账号，但目前没有登录 Session。请确认 Authentication → Sign In / Providers → Confirm email 已关闭，或先完成 Email 验证。');

        $result=v13_first_rpc_row(v13_rpc('redeem_owner_activation_code_v2',[
            'p_code'=>$code,
            'p_organization_name'=>$businessName,
            'p_full_name'=>$ownerName,
            'p_phone'=>$ownerPhone,
            'p_store_phone'=>$businessPhone,
            'p_store_address'=>$businessAddress,
        ],$token));
        if(empty($result['organization_id']))throw new RuntimeException('Supabase 没有完成 Organization 开户。');

        $_SESSION['flash']=['type'=>'success','message'=>'老板账号已经建立在 Supabase：Organization、主店与订阅均已创建。'];
        header('Location: index.php'); exit;
    } catch (Throwable $e) {
        $error=$e->getMessage();
    }
}
function reg_e(string $v): string { return htmlspecialchars($v,ENT_QUOTES,'UTF-8'); }
?>
<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>注册老板账号 · SalonOS</title>
<link rel="stylesheet" href="assets/app.css?v=13.4.4"><link rel="stylesheet" href="assets/pwa.css?v=13.4.4"><link rel="stylesheet" href="assets/luxe.css?v=13.4.4"><link rel="icon" href="assets/icons/favicon.ico"><link rel="stylesheet" href="assets/v13-supabase-compat.css?v=13.4.4"></head>
<body class="login-body"><main class="register-shell">
<section class="register-intro"><div class="login-brand"><span class="brand-mark"><img src="assets/icons/icon-72.png" alt="S" style="width:100%;height:100%;border-radius:14px"></span><strong>SalonOS</strong></div><span class="eyebrow">CREATOR CONTROLLED SIGNUP</span><h1>注册老板账号</h1><p>老板不能自由建立付费账号。先向 SalonOS Creator 取得 5 分钟开户 Code，再在这里完成注册。</p>
<div class="register-flow"><div><b>1</b><span><strong>Creator 生成 Code</strong><small>订阅方案由 Creator 控制</small></span></div><div><b>2</b><span><strong>老板注册 Supabase 登录</strong><small>Email 与密码以后用于公网/PWA 登录</small></span></div><div><b>3</b><span><strong>建立 Supabase Organization</strong><small>Organization + RLS 隔离，不再建立 InfinityFree Tenant DB</small></span></div></div></section>
<section class="login-card register-card"><div class="login-heading"><span class="eyebrow">NEW OWNER ACCOUNT</span><h2>开始使用 SalonOS</h2><p class="sub">已有账号？<a href="index.php">返回登录</a></p></div>
<?php if($error!==''): ?><div class="alert alert-error"><?=reg_e($error)?></div><?php endif; ?>
<form method="post" autocomplete="on"><div class="field"><label>Creator 开户 Code *</label><input class="input license-code-input" name="activation_code" placeholder="ACT-XXXX-XXXX" required autofocus><small class="field-help">Code 只生效 5 分钟，而且只能使用一次。</small></div>
<div class="form-grid"><div class="field"><label>老板姓名 *</label><input class="input" name="owner_name" value="<?=reg_e((string)($_POST['owner_name']??''))?>" required></div><div class="field"><label>老板手机号</label><input class="input" name="owner_phone" inputmode="tel" value="<?=reg_e((string)($_POST['owner_phone']??''))?>"></div><div class="field span-2"><label>老板 Email *</label><input class="input" type="email" name="owner_email" autocomplete="email" value="<?=reg_e((string)($_POST['owner_email']??''))?>" required></div><div class="field"><label>登录密码 *</label><input class="input" type="password" name="password" minlength="8" autocomplete="new-password" required></div><div class="field"><label>再次输入密码 *</label><input class="input" type="password" name="password_confirm" minlength="8" autocomplete="new-password" required></div></div>
<hr class="license-divider"><div class="form-grid"><div class="field span-2"><label>第一家门店名称 *</label><input class="input" name="business_name" value="<?=reg_e((string)($_POST['business_name']??''))?>" required></div><div class="field"><label>门店电话</label><input class="input" name="business_phone" inputmode="tel" value="<?=reg_e((string)($_POST['business_phone']??''))?>"></div><div class="field span-2"><label>门店地址</label><textarea class="input license-textarea" name="business_address"><?=reg_e((string)($_POST['business_address']??''))?></textarea></div></div>
<button class="btn btn-primary btn-block login-submit" type="submit">验证 Code 并注册老板账号 →</button></form></section>
</main><script src="assets/pwa-install.js?v=13.6.10.46" data-pwa-name="SalonOS" data-pwa-sw="sw.js?v=13.6.10.46" data-pwa-scope="./" data-pwa-icon="assets/icons/icon-192.png" data-pwa-theme="app"></script></body></html>
