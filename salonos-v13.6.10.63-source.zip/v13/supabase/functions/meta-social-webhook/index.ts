import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors={"content-type":"application/json; charset=utf-8"};
const enc=new TextEncoder();
const hex=(buf:ArrayBuffer)=>Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,"0")).join("");
const sha256=async(s:string)=>hex(await crypto.subtle.digest("SHA-256",enc.encode(s)));
const hmac=async(secret:string,body:string)=>{const key=await crypto.subtle.importKey("raw",enc.encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);return hex(await crypto.subtle.sign("HMAC",key,enc.encode(body)));};
const safeEq=(a:string,b:string)=>{if(a.length!==b.length)return false;let x=0;for(let i=0;i<a.length;i++)x|=a.charCodeAt(i)^b.charCodeAt(i);return x===0;};

Deno.serve(async(req)=>{
  const url=new URL(req.url); const supabase=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const connectionId=url.searchParams.get("connection_id")||"";
  if(req.method==="GET"){
    const mode=url.searchParams.get("hub.mode")||""; const token=url.searchParams.get("hub.verify_token")||""; const challenge=url.searchParams.get("hub.challenge")||"";
    if(mode!=="subscribe"||!connectionId||!token)return new Response("Forbidden",{status:403});
    const {data:secret}=await supabase.from("social_inbox_connection_secrets").select("verify_token_hash").eq("connection_id",connectionId).maybeSingle();
    if(!secret||!safeEq(await sha256(token),String(secret.verify_token_hash||"")))return new Response("Forbidden",{status:403});
    return new Response(challenge,{status:200,headers:{"content-type":"text/plain"}});
  }
  if(req.method!=="POST")return new Response("Method not allowed",{status:405});
  const raw=await req.text(); let payload:any={}; try{payload=JSON.parse(raw)}catch{return new Response("Bad JSON",{status:400})}
  const entries=Array.isArray(payload?.entry)?payload.entry:[]; const object=String(payload?.object||"");
  for(const entry of entries){
    const externalAccountId=String(entry?.id||""); if(!externalAccountId)continue;
    let q=supabase.from("social_inbox_connections").select("id,organization_id,store_id,social_account_id,platform,enabled").eq("external_account_id",externalAccountId).eq("enabled",true);
    if(connectionId)q=q.eq("id",connectionId); const {data:conn}=await q.maybeSingle(); if(!conn)continue;
    const {data:secret}=await supabase.from("social_inbox_connection_secrets").select("app_secret").eq("connection_id",conn.id).maybeSingle(); if(!secret)continue;
    const sig=(req.headers.get("x-hub-signature-256")||"").replace(/^sha256=/,""); if(!sig||!safeEq(sig,await hmac(String(secret.app_secret),raw)))return new Response("Bad signature",{status:401});
    const events=Array.isArray(entry?.messaging)?entry.messaging:[];
    for(const ev of events){
      const sender=String(ev?.sender?.id||""); const msg=ev?.message; if(!sender||!msg||msg?.is_echo)continue;
      const mid=String(msg?.mid||"")||`${sender}:${ev?.timestamp||Date.now()}`; const text=typeof msg?.text==="string"?msg.text:"";
      const now=new Date(Number(ev?.timestamp||Date.now())).toISOString();
      const {data:contactRows}=await supabase.from("social_inbox_contacts").upsert({organization_id:conn.organization_id,store_id:conn.store_id,connection_id:conn.id,social_account_id:conn.social_account_id,platform:conn.platform,external_user_id:sender,last_message_at:now,updated_at:new Date().toISOString()},{onConflict:"connection_id,external_user_id"}).select("id").limit(1);
      const contactId=contactRows?.[0]?.id||null;
      await supabase.from("social_inbox_messages").upsert({organization_id:conn.organization_id,store_id:conn.store_id,connection_id:conn.id,contact_id:contactId,platform:conn.platform,external_message_id:mid,direction:"inbound",message_text:text||null,raw_payload:ev,received_at:now},{onConflict:"connection_id,external_message_id",ignoreDuplicates:true});
      await supabase.from("social_inbox_connections").update({last_webhook_at:new Date().toISOString(),connection_status:"live",last_error:null,updated_at:new Date().toISOString()}).eq("id",conn.id);
    }
  }
  return new Response(JSON.stringify({ok:true,object}),{status:200,headers:cors});
});
