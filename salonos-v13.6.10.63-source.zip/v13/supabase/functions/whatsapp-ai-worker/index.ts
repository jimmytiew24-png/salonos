import { createClient } from "npm:@supabase/supabase-js@2";

type Json = Record<string, unknown>;

type IntentResult = {
  intent:
    | "appointment"
    | "reschedule"
    | "cancel"
    | "price_enquiry"
    | "service_enquiry"
    | "staff_enquiry"
    | "opening_hours"
    | "complaint"
    | "membership"
    | "points"
    | "human_request"
    | "other";
  confidence: number;
  language: "zh" | "en" | "ms" | "mixed" | "other";
  entities: {
    service_text: string | null;
    service_search_terms: string[];
    staff_name: string | null;
    staff_preference: "specified" | "no_preference" | "unknown";
    date_text: string | null;
    date_iso: string | null;
    time_text: string | null;
    time_iso: string | null;
    time_period: "morning" | "afternoon" | "evening" | "night" | "unspecified";
    appointment_reference: string | null;
    complaint_summary: string | null;
    membership_topic: string | null;
  };
};

const INTENTS = new Set([
  "appointment", "reschedule", "cancel", "price_enquiry", "service_enquiry", "staff_enquiry",
  "opening_hours", "complaint", "membership", "points", "human_request", "other",
]);

const INTENT_SCHEMA = {
  type: "object",
  properties: {
    intent: {
      type: "string",
      enum: [
        "appointment", "reschedule", "cancel", "price_enquiry", "service_enquiry", "staff_enquiry",
        "opening_hours", "complaint", "membership", "points", "human_request", "other",
      ],
    },
    confidence: { type: "number", minimum: 0, maximum: 1 },
    language: { type: "string", enum: ["zh", "en", "ms", "mixed", "other"] },
    entities: {
      type: "object",
      properties: {
        service_text: { type: ["string", "null"] },
        service_search_terms: { type: "array", items: { type: "string" } },
        staff_name: { type: ["string", "null"] },
        staff_preference: { type: "string", enum: ["specified", "no_preference", "unknown"] },
        date_text: { type: ["string", "null"] },
        date_iso: { type: ["string", "null"] },
        time_text: { type: ["string", "null"] },
        time_iso: { type: ["string", "null"] },
        time_period: { type: "string", enum: ["morning", "afternoon", "evening", "night", "unspecified"] },
        appointment_reference: { type: ["string", "null"] },
        complaint_summary: { type: ["string", "null"] },
        membership_topic: { type: ["string", "null"] },
      },
      required: [
        "service_text", "service_search_terms", "staff_name", "staff_preference", "date_text", "date_iso", "time_text", "time_iso", "time_period",
        "appointment_reference", "complaint_summary", "membership_topic",
      ],
      additionalProperties: false,
    },
  },
  required: ["intent", "confidence", "language", "entities"],
  additionalProperties: false,
};

function env(name: string): string {
  return (Deno.env.get(name) ?? "").trim();
}

function serviceKey(): string {
  const legacy = env("SUPABASE_SERVICE_ROLE_KEY");
  if (legacy) return legacy;
  try {
    const keys = JSON.parse(env("SUPABASE_SECRET_KEYS") || "{}") as Record<string, string>;
    return (keys.default ?? Object.values(keys)[0] ?? "").trim();
  } catch {
    return "";
  }
}

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function errorText(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  try { return JSON.stringify(error); } catch { return "unknown_error"; }
}

function localNow(timeZone = "Asia/Kuala_Lumpur"): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23",
  }).formatToParts(new Date());
  const p = Object.fromEntries(parts.map((x) => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}`;
}

function pendingAction(intent: string): string {
  switch (intent) {
    case "appointment": return "resolve_service_staff_and_check_availability";
    case "reschedule": return "find_existing_appointment_for_reschedule";
    case "cancel": return "find_existing_appointment_for_cancel";
    case "price_enquiry": return "resolve_service_and_get_price";
    case "service_enquiry": return "resolve_service_and_get_details";
    case "staff_enquiry": return "resolve_staff_and_get_details";
    case "opening_hours": return "get_branch_opening_hours";
    case "complaint": return "handoff_complaint";
    case "membership": return "get_membership_details";
    case "points": return "get_member_points";
    case "human_request": return "handoff_to_human";
    default: return "no_backend_action_yet";
  }
}

function extractOutputText(body: Json): string {
  if (typeof body.output_text === "string" && body.output_text.trim()) return body.output_text.trim();
  const output = Array.isArray(body.output) ? body.output as unknown[] : [];
  for (const itemRaw of output) {
    const item = (itemRaw ?? {}) as Json;
    if (String(item.type ?? "") !== "message") continue;
    const content = Array.isArray(item.content) ? item.content as unknown[] : [];
    for (const partRaw of content) {
      const part = (partRaw ?? {}) as Json;
      if (String(part.type ?? "") === "output_text" && typeof part.text === "string") return part.text.trim();
    }
  }
  return "";
}

function validateIntent(value: unknown): IntentResult {
  const data = (value ?? {}) as Json;
  const intent = String(data.intent ?? "");
  const confidence = Number(data.confidence);
  const language = String(data.language ?? "other");
  const entities = (data.entities ?? {}) as Json;
  if (!INTENTS.has(intent)) throw new Error(`invalid_intent:${intent}`);
  if (!Number.isFinite(confidence) || confidence < 0 || confidence > 1) throw new Error("invalid_confidence");
  if (!["zh", "en", "ms", "mixed", "other"].includes(language)) throw new Error("invalid_language");
  const timePeriod = String(entities.time_period ?? "unspecified");
  if (!["morning", "afternoon", "evening", "night", "unspecified"].includes(timePeriod)) {
    throw new Error("invalid_time_period");
  }
  const staffPreference = String(entities.staff_preference ?? "unknown");
  if (!["specified", "no_preference", "unknown"].includes(staffPreference)) {
    throw new Error("invalid_staff_preference");
  }
  const nullable = (key: string): string | null => {
    const v = entities[key];
    return typeof v === "string" && v.trim() ? v.trim() : null;
  };
  return {
    intent: intent as IntentResult["intent"],
    confidence,
    language: language as IntentResult["language"],
    entities: {
      service_text: nullable("service_text"),
      service_search_terms: Array.isArray(entities.service_search_terms)
        ? (entities.service_search_terms as unknown[]).filter((v) => typeof v === "string" && v.trim()).slice(0, 5).map((v) => String(v).trim())
        : [],
      staff_name: nullable("staff_name"),
      staff_preference: staffPreference as IntentResult["entities"]["staff_preference"],
      date_text: nullable("date_text"),
      date_iso: nullable("date_iso"),
      time_text: nullable("time_text"),
      time_iso: nullable("time_iso"),
      time_period: timePeriod as IntentResult["entities"]["time_period"],
      appointment_reference: nullable("appointment_reference"),
      complaint_summary: nullable("complaint_summary"),
      membership_topic: nullable("membership_topic"),
    },
  };
}

function isoDateAddDays(localDateTime: string, days: number): string {
  const datePart = String(localDateTime || "").split("T")[0] || "";
  const m = datePart.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  const base = m
    ? new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])))
    : new Date();
  base.setUTCDate(base.getUTCDate() + days);
  return `${base.getUTCFullYear()}-${String(base.getUTCMonth() + 1).padStart(2, "0")}-${String(base.getUTCDate()).padStart(2, "0")}`;
}

function detectLanguageDeterministic(text: string): IntentResult["language"] {
  if (/[\u3400-\u9fff]/.test(text)) return "zh";
  if (/\b(saya|nak|mahu|boleh|tak|tidak|harga|berapa|servis|rambut|potong|warna|buat|ada|kosong|bila|esok|lusa|hari ini|tukar|ubah|batal|tempahan|janji temu|pukul|petang|malam|pagi)\b/i.test(text)) return "ms";
  if (/[a-z]/i.test(text)) return "en";
  return "other";
}

function isLanguageNeutralTemporalReply(textRaw: string): boolean {
  const text = String(textRaw || "").normalize("NFKC").trim();
  if (!text || text.length > 24) return false;
  // Numeric clock replies do not establish a new language. For example, "7pm"
  // after a Chinese conversation must not switch the reply to English merely
  // because the clock suffix uses Latin letters.
  return /^\d{1,2}(?::[0-5]\d)?\s*(?:a\.?m\.?|p\.?m\.?)?\s*[?.!！。？]*$/i.test(text);
}

function parseNaturalHourToken(tokenRaw: string): number | null {
  const token = String(tokenRaw || "").trim();
  if (/^\d{1,2}$/.test(token)) {
    const n = Number(token);
    return Number.isInteger(n) ? n : null;
  }
  const direct: Record<string, number> = {
    "一": 1, "二": 2, "两": 2, "兩": 2, "三": 3, "四": 4, "五": 5, "六": 6,
    "七": 7, "八": 8, "九": 9, "十": 10, "十一": 11, "十二": 12,
  };
  return Object.prototype.hasOwnProperty.call(direct, token) ? direct[token] : null;
}


function hasDraftRevisionSignal(textRaw: string): boolean {
  const text = String(textRaw || "").trim();
  if (!text) return false;

  const changeVerb = /改到|改成|改去|换到|換到|换成|換成|换去|換去|改.*时间|改.*時間|换.*时间|換.*時間|change\s+(?:it\s+)?to|change\s+(?:the\s+)?time|make\s+it|move\s+(?:it\s+)?to|switch\s+to|tukar.*(?:masa|waktu)|ubah.*(?:masa|waktu)/i.test(text);
  const timeOrDate = /(?:上午|早上|早晨|下午|午后|午後|傍晚|晚上|夜晚)?\s*(?:\d{1,2}|[一二两兩三四五六七八九十]{1,3})\s*(?:点|點|時|时)|\b\d{1,2}(?::[0-5]\d)?\s*(?:am|pm)\b|\b(?:today|tomorrow|day after tomorrow)\b|今天|明天|后天|後天|\besok\b|\blusa\b|\b20\d{2}[-/.]\d{1,2}[-/.]\d{1,2}\b|\b\d{1,2}[/.]\d{1,2}[/.]20\d{2}\b/i.test(text);

  // While an unconfirmed booking draft exists, a short standalone date/time reply
  // is also a draft revision even when the customer omits "change".
  const shortTimeReply = text.length <= 32 && timeOrDate;
  return (changeVerb && timeOrDate) || shortTimeReply;
}

function pendingDraftRevisionIntent(
  textRaw: string,
  currentLocalDateTime: string,
  draft: Json | null,
): IntentResult | null {
  const d = asJson(draft);
  if (!Object.keys(d).length || !hasDraftRevisionSignal(textRaw)) return null;

  // Reuse SalonOS's deterministic reschedule date/time parser, but reinterpret
  // the result as a revision of the UNCONFIRMED booking draft.
  const parsed = deterministicChangeCommand(`change my appointment ${String(textRaw || "")}`, currentLocalDateTime);
  if (!parsed) return null;

  const assignmentType = String(d.assignment_type ?? "").toLowerCase();
  const assignmentStrategy = String(d.assignment_strategy ?? "").toLowerCase();
  const systemAssigned = assignmentType === "random" || assignmentStrategy.includes("random");

  const serviceName = nullableString(d.service_name_snapshot);
  const employeeName = nullableString(d.employee_name_snapshot);
  const draftDate = nullableString(d.appointment_date);
  const draftTimeRaw = nullableString(d.appointment_time);
  const draftTime = draftTimeRaw ? draftTimeRaw.slice(0, 5) : null;

  return {
    intent: "appointment",
    confidence: 0.999,
    language: detectLanguageDeterministic(String(textRaw || "")),
    entities: {
      service_text: serviceName,
      service_search_terms: serviceName ? [serviceName] : [],
      staff_name: systemAssigned ? null : employeeName,
      staff_preference: systemAssigned ? "no_preference" : (employeeName ? "specified" : "unknown"),
      date_text: parsed.entities.date_text,
      date_iso: parsed.entities.date_iso ?? draftDate,
      time_text: parsed.entities.time_text,
      time_iso: parsed.entities.time_iso ?? draftTime,
      time_period: parsed.entities.time_period,
      appointment_reference: null,
      complaint_summary: null,
      membership_topic: null,
    },
  };
}



type AppointmentStaffChoiceMode = "random_assign" | "list_alternatives";

type AppointmentStaffChoiceSignal = {
  mode: AppointmentStaffChoiceMode;
  excludePrevious: boolean;
  reason: string;
};

type AppointmentStaffFollowupCommand = {
  result: IntentResult;
  mode: AppointmentStaffChoiceMode;
  excludeStaffName: string | null;
  sourceStaffName: string | null;
  reason: string;
};

function hasNamedStaffRevisionSignal(textRaw: string): boolean {
  const text = String(textRaw || "").trim();
  if (!text) return false;
  return /(?:换成|換成|改成|换去|換去|指定|我要|我想要|找|book\s+with|switch\s+to|change\s+(?:the\s+)?stylist\s+to|want\s+)(?:.{0,24})(?:理发师|理髮師|发型师|髮型師|stylist|hairdresser|barber)?/i.test(text)
    && /(?:理发师|理髮師|发型师|髮型師|stylist|hairdresser|barber|换成|換成|改成|book\s+with|switch\s+to)/i.test(text);
}

function hasServiceRevisionSignal(textRaw: string): boolean {
  const text = String(textRaw || "").trim();
  if (!text) return false;
  const change = /(?:改做|换做|換做|改成|换成|換成|不要.*(?:改|换|換)|change\s+(?:the\s+)?service|switch\s+(?:the\s+)?service|do\s+.*instead)/i.test(text);
  const service = /(?:hair\s*(?:color|colour|coloring|colouring|dye)|haircut|hair\s*cut|perm|rebond|straighten|treatment|scalp|highlight|bleach|wash|shampoo|blow\s*dry|染发|染髮|剪发|剪髮|理发|理髮|烫发|燙髮|护理|護理|漂发|漂髮)/i.test(text);
  return change && service;
}

function appointmentStaffChoiceSignal(textRaw: string): AppointmentStaffChoiceSignal | null {
  const text = String(textRaw || "").trim();
  if (!text) return null;

  const randomSignal = /(?:没有指定|沒指定|不指定|随便|隨便|谁都可以|誰都可以|谁都行|誰都行|都可以|都行|你安排|你决定|你決定|随机|隨機|任何理发师|任何理髮師|任何人|任意理发师|任意理髮師|anyone|any\s*stylist|no\s*preference|no\s*preferred\s*stylist|you\s*choose|you\s*decide|assign\s*(?:me\s*)?(?:someone|anyone)|random\s*stylist|whoever\s*(?:is\s*)?available|mana[- ]?mana|sesiapa|awak\s*pilih|anda\s*pilih)/i.test(text);
  const listSignal = /(?:谁可以做|誰可以做|谁能做|誰能做|谁有空|誰有空|谁可以|誰可以|还有谁|還有誰|有谁可以|有誰可以|哪位可以|哪个理发师|哪個理髮師|其他理发师|其他理髮師|别的理发师|別的理髮師|换个理发师|換個理髮師|换一个理发师|換一個理髮師|换个人|換個人|换一个人|換一個人|其他人|別人|别人|another\b|other\s*stylist|other\s*hairdresser|someone\s*else|different\s*stylist|who\s*can\s*(?:do|take|handle)|who(?:'s|\s+is)\s*available|which\s*stylist|have\s+.*(?:stylist|理发师|理髮師)|stylist\s*lain|orang\s*lain|siapa\s*(?:boleh|available))/i.test(text);
  const moveAwaySignal = /(?:换个人|換個人|换一个人|換一個人|换个理发师|換個理髮師|换一个理发师|換一個理髮師|其他人|别人|別人|其他理发师|其他理髮師|别的理发师|別的理髮師|不一定要|不一定找|不用一定|不要他|不要她|不要这位|不要這位|another\b|other\s*stylist|other\s*hairdresser|someone\s*else|different\s*stylist|not\s+necessarily|stylist\s*lain|orang\s*lain)/i.test(text);

  if (listSignal) return { mode: "list_alternatives", excludePrevious: moveAwaySignal, reason: "ask_or_change_alternative_staff" };
  if (randomSignal) return { mode: "random_assign", excludePrevious: false, reason: "explicit_random_or_no_preference" };
  return null;
}

function appointmentAlternativeSelectionIntent(textRaw: string, previousState: Json | null): IntentResult | null {
  const text = String(textRaw || "").trim();
  if (!text) return null;
  const prev = asJson(previousState);
  const slots = asJson(prev.slots);
  const tools = asJson(slots.appointment_tools);
  const candidates = Array.isArray(tools.staff_alternatives)
    ? (tools.staff_alternatives as unknown[]).map(asJson)
    : [];
  if (!candidates.length) return null;
  if (String(prev.active_intent ?? "") !== "appointment" && String(prev.state ?? "") !== "appointment_staff_alternatives") return null;

  let selected: Json | null = null;
  const idx = parseAppointmentSelection(text, candidates.length);
  if (idx != null && candidates[idx]) selected = candidates[idx];
  if (!selected) {
    const normalizedText = text.toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, "");
    selected = candidates.find((candidate) => {
      const name = nullableString(candidate.name);
      if (!name) return false;
      const key = name.toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, "");
      return normalizedText === key || (key.length >= 3 && normalizedText.includes(key));
    }) ?? null;
  }
  const staffName = nullableString(selected?.name);
  if (!staffName) return null;

  const serviceName = nullableString(slots.service_text)
    ?? nullableString(asJson(asJson(tools.resolve_service).service).name);
  const serviceTerms = Array.isArray(slots.service_search_terms)
    ? (slots.service_search_terms as unknown[]).filter((x) => typeof x === "string" && String(x).trim()).map(String).slice(0, 5)
    : (serviceName ? [serviceName] : []);
  const periodRaw = String(slots.time_period ?? "unspecified");
  const period = ["morning", "afternoon", "evening", "night"].includes(periodRaw)
    ? periodRaw as IntentResult["entities"]["time_period"] : "unspecified";

  return {
    intent: "appointment",
    confidence: 1,
    language: detectLanguageDeterministic(text),
    entities: {
      service_text: serviceName,
      service_search_terms: serviceTerms,
      staff_name: staffName,
      staff_preference: "specified",
      date_text: nullableString(slots.date_text),
      date_iso: nullableString(slots.date_iso),
      time_text: nullableString(slots.time_text),
      time_iso: nullableString(slots.selected_time) ?? nullableString(slots.time_iso),
      time_period: period,
      appointment_reference: null,
      complaint_summary: null,
      membership_topic: null,
    },
  };
}

function appointmentStaffFollowupCommand(
  textRaw: string,
  currentLocalDateTime: string,
  previousState: Json | null,
  draft: Json | null,
): AppointmentStaffFollowupCommand | null {
  const prev = asJson(previousState);
  const prevSlots = asJson(prev.slots);
  const d = asJson(draft);
  const hasDraft = Object.keys(d).length > 0;
  const hasAppointmentContext = hasDraft || String(prev.active_intent ?? "") === "appointment"
    || String(prev.state ?? "").startsWith("appointment_")
    || String(prev.state ?? "").startsWith("awaiting_")
    || String(prev.state ?? "").startsWith("collecting_customer_");
  if (!hasAppointmentContext) return null;

  const parsed = deterministicChangeCommand(`change my appointment ${String(textRaw || "")}`, currentLocalDateTime);
  const parsedEntities = parsed?.entities;
  const tools = asJson(prevSlots.appointment_tools);
  const serviceFromTools = nullableString(asJson(asJson(tools.resolve_service).service).name);
  const staffFromTools = nullableString(asJson(asJson(tools.resolve_staff).staff).name);

  const serviceName = nullableString(d.service_name_snapshot)
    ?? nullableString(prevSlots.service_text)
    ?? serviceFromTools;
  const serviceTerms = Array.isArray(prevSlots.service_search_terms)
    ? (prevSlots.service_search_terms as unknown[]).filter((x) => typeof x === "string" && String(x).trim()).map(String).slice(0, 5)
    : (serviceName ? [serviceName] : []);
  const sourceStaffName = nullableString(d.employee_name_snapshot)
    ?? nullableString(prevSlots.staff_name)
    ?? staffFromTools;
  const priorExcluded = nullableString(prevSlots.excluded_staff_name);

  // Context-aware rejection of the previously selected stylist. Customers often
  // say only "不一定要fatchew / 不要fatchew / not fatchew / anyone except fatchew"
  // without using the word stylist. In an active booking this is still a clear
  // request to move away from the previous employee, so show alternatives.
  let signal = appointmentStaffChoiceSignal(textRaw);
  if (!signal && sourceStaffName) {
    const text = String(textRaw || "").trim();
    const escapedName = sourceStaffName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const namesPrevious = new RegExp(escapedName, "i").test(text);
    const rejectsPrevious = /(?:不一定要|不一定找|不要|不想要|不用|换掉|換掉|除了|除外|not\s+necessarily|don['’]?t\s+want|do\s+not\s+want|not\s+|except\s+|anyone\s+except)/i.test(text);
    if (namesPrevious && rejectsPrevious) {
      signal = { mode: "list_alternatives", excludePrevious: true, reason: "reject_previous_staff_by_name" };
    }
  }
  if (!signal) return null;

  const draftDate = nullableString(d.appointment_date);
  const draftTimeRaw = nullableString(d.appointment_time);
  const draftTime = draftTimeRaw ? draftTimeRaw.slice(0, 5) : null;
  const prevPeriodRaw = String(prevSlots.time_period ?? "unspecified");
  const prevPeriod = ["morning", "afternoon", "evening", "night"].includes(prevPeriodRaw)
    ? prevPeriodRaw as IntentResult["entities"]["time_period"]
    : "unspecified";
  const parsedPeriod = parsedEntities && parsedEntities.time_period !== "unspecified" ? parsedEntities.time_period : null;

  const dateIso = parsedEntities?.date_iso ?? draftDate ?? nullableString(prevSlots.date_iso);
  const timeIso = parsedEntities?.time_iso ?? draftTime ?? nullableString(prevSlots.selected_time) ?? nullableString(prevSlots.time_iso);
  const timePeriod = parsedPeriod ?? prevPeriod;
  const excludeStaffName = signal.excludePrevious ? sourceStaffName : (signal.mode === "random_assign" ? priorExcluded : null);

  return {
    result: {
      intent: "appointment",
      confidence: 0.999,
      language: detectLanguageDeterministic(String(textRaw || "")),
      entities: {
        service_text: serviceName,
        service_search_terms: serviceTerms,
        staff_name: null,
        staff_preference: "no_preference",
        date_text: parsedEntities?.date_text ?? nullableString(prevSlots.date_text),
        date_iso: dateIso,
        time_text: parsedEntities?.time_text ?? nullableString(prevSlots.time_text),
        time_iso: timeIso,
        time_period: timePeriod,
        appointment_reference: null,
        complaint_summary: null,
        membership_topic: null,
      },
    },
    mode: signal.mode,
    excludeStaffName,
    sourceStaffName,
    reason: signal.reason,
  };
}

function deterministicChangeCommand(textRaw: string, currentLocalDateTime: string): IntentResult | null {
  const text = String(textRaw || "").trim();
  if (!text) return null;
  const lower = text.toLowerCase();

  // Only route explicit appointment-change commands here. Confirmation/selection
  // states are handled earlier by the state machine, so this router has no write authority.
  const explicitReschedule = /改期|改.*时间|改.*時間|换.*时间|換.*時間|reschedul|move\s+(?:my\s+)?(?:appointment|booking)|change\s+(?:my\s+)?(?:appointment|booking)|tukar.*(?:masa|waktu|tempahan|janji)|ubah.*(?:masa|waktu|tempahan|janji)/i.test(text);
  const temporalTarget = /(?:上午|早上|早晨|下午|午后|午後|傍晚|晚上|夜晚)?\s*(?:\d{1,2}|[一二两兩三四五六七八九十]{1,3})\s*(?:点|點|時|时)|\b\d{1,2}(?::[0-5]\d)?\s*(?:am|pm)\b|今天|明天|后天|後天|today|tomorrow|day after tomorrow|\besok\b|\blusa\b|\b20\d{2}[-\/.]\d{1,2}[-\/.]\d{1,2}\b|\b\d{1,2}[\/.]\d{1,2}[\/.]20\d{2}\b/i.test(text);
  const temporalChange = /改到|改成|改去|换到|換到|换成|換成|换去|換去|move\s+to|change\s+to|switch\s+to/i.test(text) && temporalTarget;
  const isReschedule = explicitReschedule || temporalChange;
  const isCancel = /取消预约|取消預約|取消.*(?:预约|預約)|(?:预约|預約).*取消|(?:预约|預約).*(?:不要了|不用了|不去了)|(?:不要了|不用了|不去了).*(?:预约|預約)|cancel\s+(?:my\s+)?(?:appointment|booking)|batal.*(?:tempahan|janji)/i.test(text);
  if (!isReschedule && !isCancel) return null;

  let dateText: string | null = null;
  let dateIso: string | null = null;
  if (/后天|後天|day after tomorrow|\blusa\b/i.test(text)) {
    dateText = text.match(/后天|後天|day after tomorrow|\blusa\b/i)?.[0] ?? null;
    dateIso = isoDateAddDays(currentLocalDateTime, 2);
  } else if (/明天|tomorrow|\besok\b/i.test(text)) {
    dateText = text.match(/明天|tomorrow|\besok\b/i)?.[0] ?? null;
    dateIso = isoDateAddDays(currentLocalDateTime, 1);
  } else if (/今天|today|hari ini/i.test(text)) {
    dateText = text.match(/今天|today|hari ini/i)?.[0] ?? null;
    dateIso = isoDateAddDays(currentLocalDateTime, 0);
  } else {
    const iso = text.match(/\b(20\d{2})[-\/.](\d{1,2})[-\/.](\d{1,2})\b/);
    const dmy = text.match(/\b(\d{1,2})[\/.](\d{1,2})[\/.](20\d{2})\b/);
    if (iso) {
      const [, y, mo, d] = iso;
      dateText = iso[0];
      dateIso = `${y}-${String(Number(mo)).padStart(2, "0")}-${String(Number(d)).padStart(2, "0")}`;
    } else if (dmy) {
      const [, d, mo, y] = dmy;
      dateText = dmy[0];
      dateIso = `${y}-${String(Number(mo)).padStart(2, "0")}-${String(Number(d)).padStart(2, "0")}`;
    }
  }

  let timePeriod: IntentResult["entities"]["time_period"] = "unspecified";
  if (/下午|午后|午後|afternoon|petang/i.test(text)) timePeriod = "afternoon";
  else if (/上午|早上|早晨|morning|pagi/i.test(text)) timePeriod = "morning";
  else if (/晚上|夜晚|傍晚|evening|night|malam/i.test(text)) timePeriod = "evening";

  let timeText: string | null = null;
  let timeIso: string | null = null;
  let hour: number | null = null;
  let minute = 0;
  let meridiem: string | null = null;

  // Chinese clock parsing must understand natural phrases such as “下午4点半”.
  // v13.6.9.4 matched only the “4点” prefix, silently turning 4:30 PM into 4:00 PM.
  // Keep this deterministic so explicit booking changes do not depend on the LLM.
  const zhTime = text.match(/(?:上午|早上|早晨|下午|午后|午後|傍晚|晚上|夜晚)?\s*(\d{1,2}|[一二两兩三四五六七八九十]{1,3})\s*(?:点|點|時|时)\s*(?:(半)|([0-5]?\d)\s*分?)?/);
  const zhColonTime = text.match(/(?:上午|早上|早晨|下午|午后|午後|傍晚|晚上|夜晚)?\s*(\d{1,2})[:：]([0-5]\d)/);
  const ampmTime = text.match(/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/i);
  const colonTime = text.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/);
  const malayTime = text.match(/\bpukul\s+(\d{1,2})(?::(\d{2}))?\b/i);

  if (ampmTime) {
    timeText = ampmTime[0];
    hour = Number(ampmTime[1]);
    minute = Number(ampmTime[2] ?? 0);
    meridiem = ampmTime[3].toLowerCase();
  } else if (zhTime) {
    timeText = zhTime[0].trim();
    hour = parseNaturalHourToken(zhTime[1]);
    minute = zhTime[2] ? 30 : Number(zhTime[3] ?? 0);
  } else if (zhColonTime) {
    timeText = zhColonTime[0].trim();
    hour = Number(zhColonTime[1]);
    minute = Number(zhColonTime[2]);
  } else if (colonTime) {
    timeText = colonTime[0];
    hour = Number(colonTime[1]);
    minute = Number(colonTime[2]);
  } else if (malayTime) {
    timeText = malayTime[0];
    hour = Number(malayTime[1]);
    minute = Number(malayTime[2] ?? 0);
  }

  if (hour != null && Number.isFinite(hour) && Number.isFinite(minute) && minute >= 0 && minute <= 59) {
    if (meridiem === "pm" && hour >= 1 && hour <= 11) hour += 12;
    if (meridiem === "am" && hour === 12) hour = 0;
    if (!meridiem && timePeriod === "afternoon" && hour >= 1 && hour <= 6) hour += 12;
    if (!meridiem && timePeriod === "evening" && hour >= 1 && hour <= 11) hour += 12;
    if (!meridiem && timePeriod === "morning" && hour === 12) hour = 0;
    if (hour >= 0 && hour <= 23) timeIso = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
  }

  const ref = text.match(/\bV[A-Z0-9-]{6,}\b/i)?.[0] ?? null;
  const emptyEntities: IntentResult["entities"] = {
    service_text: null,
    service_search_terms: [],
    staff_name: null,
    staff_preference: "unknown",
    date_text: dateText,
    date_iso: dateIso,
    time_text: timeText,
    time_iso: timeIso,
    time_period: timePeriod,
    appointment_reference: ref,
    complaint_summary: null,
    membership_topic: null,
  };

  return {
    intent: isReschedule ? "reschedule" : "cancel",
    confidence: 0.995,
    language: detectLanguageDeterministic(text),
    entities: emptyEntities,
  };
}

type AppointmentTemporalHint = {
  entities: IntentResult["entities"];
  has_explicit_date: boolean;
  has_exact_time: boolean;
  has_time_period: boolean;
  is_time_only: boolean;
  is_short_followup: boolean;
};

function deterministicAppointmentTemporalHint(
  textRaw: string,
  currentLocalDateTime: string,
): AppointmentTemporalHint | null {
  const text = String(textRaw || "").normalize("NFKC").trim();
  if (!text) return null;

  // Reuse the battle-tested deterministic clock parser without treating this as
  // a real reschedule command. The prefixed command gives the parser permission
  // to extract slots only; the caller still owns intent and state transitions.
  const parsed = deterministicChangeCommand(`change my appointment ${text}`, currentLocalDateTime);
  if (!parsed) return null;
  const deterministicDate = deterministicAppointmentDateHint(text, currentLocalDateTime);
  const entities: IntentResult["entities"] = {
    ...parsed.entities,
    date_text: deterministicDate?.date_text ?? parsed.entities.date_text,
    date_iso: deterministicDate?.date_iso ?? parsed.entities.date_iso,
  };
  const hasExplicitDate = Boolean(deterministicDate);
  const hasExactTime = Boolean(entities.time_text && entities.time_iso);
  const hasTimePeriod = entities.time_period !== "unspecified";
  if (!hasExplicitDate && !hasExactTime && !hasTimePeriod) return null;

  const explicitChange = /(?:改期|改.*(?:时间|時間)|换.*(?:时间|時間)|取消|reschedul|\bchange\b|\bmove\b|\bcancel\b|tukar|ubah|batal)/i.test(text);
  return {
    entities,
    has_explicit_date: hasExplicitDate,
    has_exact_time: hasExactTime,
    has_time_period: hasTimePeriod,
    is_time_only: hasExactTime && !hasExplicitDate,
    is_short_followup: text.length <= 64 && !explicitChange,
  };
}

function isInformationalAppointmentSlotFollowup(
  textRaw: string,
  previousState: Json | null,
  temporalHint: AppointmentTemporalHint | null,
): boolean {
  if (!temporalHint?.is_short_followup) return false;
  const previousIntent = String(previousState?.active_intent ?? "");
  if (!["price_enquiry", "service_enquiry", "staff_enquiry"].includes(previousIntent)) return false;
  const previousSlots = asJson(previousState?.slots);
  const previousTools = asJson(previousSlots.appointment_tools);
  const knownService = nullableString(previousSlots.service_text)
    ?? nullableString(asJson(asJson(previousTools.resolve_service).service).name);
  const knownStaff = nullableString(previousSlots.staff_name)
    ?? nullableString(asJson(asJson(previousTools.resolve_staff).staff).name);
  return Boolean(knownService || knownStaff);
}

async function detectIntentOpenAI(openAiKey: string, model: string, payload: Json): Promise<{ result: IntentResult; raw: Json; responseId: string | null }> {
  const systemPrompt = [
    "You are SalonOS Intent Router for a salon WhatsApp AI agent.",
    "Your job is ONLY to understand the latest customer's intent and extract what the customer explicitly said.",
    "Do NOT answer the customer. Do NOT invent prices, availability, staff IDs, service IDs, membership balances, appointment IDs, or salon facts.",
    "Use recent conversation/state to understand short follow-ups such as '3点' after an appointment discussion. If the previous appointment context is afternoon and the customer says an ambiguous hour like 3点, interpret it as 15:00; preserve prior service/staff/date when the latest message only changes one field.",
    "A message asking whether a stylist is available for a service/date/time is appointment intent, not staff_enquiry.",
    "For reschedule, date_iso/time_iso/time_period describe the NEW requested date/time; appointment_reference identifies the existing booking when stated. Do not invent a booking reference.",
    "For cancel, date/time/reference may identify the EXISTING appointment to cancel. Never treat cancel as cancelling a draft unless conversation state explicitly says it is only a draft.",
    "Use complaint for dissatisfaction/service complaints. Use human_request only when the customer explicitly asks for a human/staff person.",
    "Resolve relative dates (today/tomorrow/明天/esok) to date_iso only when sufficiently clear from current_local_datetime and timezone.",
    "time_iso must be HH:MM only when an exact time is stated; otherwise leave it null and use time_period.",
    "service_text and staff_name are raw customer wording/names, not canonical database matches.",
    "Keep employee names separate from service wording even when the customer types them without spaces. Example: 'weihong染头发' means staff_name='weihong' and service_text='染头发'; never use 'weihong染头发' as the service name.",
    "staff_preference must be specified when the customer explicitly names/wants a stylist, no_preference when they say anyone/no preference/you choose/random/随便/没有指定/都可以/mana-mana, otherwise unknown.",
    "If staff_preference is no_preference, staff_name MUST be null. Never invent a stylist name.",
    "In an active booking conversation, phrases like 'another stylist', 'who can do it', 'who is available', '换个人', '谁可以做', '还有谁' are appointment follow-ups, not generic staff_enquiry. Preserve the known service/date/time, clear the previous staff_name, and set staff_preference=no_preference.",
    "service_search_terms contains up to 5 short search aliases for the same requested service, including useful Chinese/English/Malay synonyms or translations. Never put a service ID there.",
    "Return only the required structured result.",
  ].join("\n");

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "authorization": `Bearer ${openAiKey}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model,
      input: [
        { role: "system", content: systemPrompt },
        { role: "user", content: JSON.stringify(payload) },
      ],
      text: {
        format: {
          type: "json_schema",
          name: "salonos_whatsapp_intent_v13610",
          strict: false,
          schema: INTENT_SCHEMA,
        },
      },
      max_output_tokens: 700,
    }),
  });

  let body: Json = {};
  try { body = await response.json() as Json; } catch { /* handled below */ }
  if (!response.ok) {
    const apiError = ((body.error as Json | undefined)?.message ?? `HTTP ${response.status}`);
    throw new Error(`openai_api_error:${String(apiError)}`);
  }
  const text = extractOutputText(body);
  if (!text) throw new Error(`openai_empty_output:status=${String(body.status ?? "unknown")}`);
  let parsed: unknown;
  try { parsed = JSON.parse(text); } catch { throw new Error("openai_invalid_json"); }
  return { result: validateIntent(parsed), raw: body, responseId: typeof body.id === "string" ? body.id : null };
}

async function detectIntentGroq(groqKey: string, model: string, payload: Json): Promise<{ result: IntentResult; raw: Json; responseId: string | null }> {
  const systemPrompt = [
    "You are SalonOS Intent Router for a salon WhatsApp AI agent.",
    "Your job is ONLY to understand the latest customer's intent and extract what the customer explicitly said.",
    "Do NOT answer the customer. Do NOT invent prices, availability, staff IDs, service IDs, membership balances, appointment IDs, or salon facts.",
    "Use recent conversation/state to understand short follow-ups such as '3点' after an appointment discussion. If the previous appointment context is afternoon and the customer says an ambiguous hour like 3点, interpret it as 15:00; preserve prior service/staff/date when the latest message only changes one field.",
    "A message asking whether a stylist is available for a service/date/time is appointment intent, not staff_enquiry.",
    "For reschedule, date_iso/time_iso/time_period describe the NEW requested date/time; appointment_reference identifies the existing booking when stated. Do not invent a booking reference.",
    "For cancel, date/time/reference may identify the EXISTING appointment to cancel. Never treat cancel as cancelling a draft unless conversation state explicitly says it is only a draft.",
    "Use complaint for dissatisfaction/service complaints. Use human_request only when the customer explicitly asks for a human/staff person.",
    "Resolve relative dates (today/tomorrow/明天/esok) to date_iso only when sufficiently clear from current_local_datetime and timezone.",
    "time_iso must be HH:MM only when an exact time is stated; otherwise leave it null and use time_period.",
    "service_text and staff_name are raw customer wording/names, not canonical database matches.",
    "Keep employee names separate from service wording even when the customer types them without spaces. Example: 'weihong染头发' means staff_name='weihong' and service_text='染头发'; never use 'weihong染头发' as the service name.",
    "staff_preference must be specified when the customer explicitly names/wants a stylist, no_preference when they say anyone/no preference/you choose/random/随便/没有指定/都可以/mana-mana, otherwise unknown.",
    "If staff_preference is no_preference, staff_name MUST be null. Never invent a stylist name.",
    "In an active booking conversation, phrases like 'another stylist', 'who can do it', 'who is available', '换个人', '谁可以做', '还有谁' are appointment follow-ups, not generic staff_enquiry. Preserve the known service/date/time, clear the previous staff_name, and set staff_preference=no_preference.",
    "service_search_terms contains up to 5 short search aliases for the same requested service, including useful Chinese/English/Malay synonyms or translations. Never put a service ID there.",
    "Return one valid JSON object only. Do not use markdown or code fences.",
  ].join("\n");

  type GroqAttempt = { response: Response; body: Json; mode: string };

  const callGroq = async (responseFormat: Json | null, mode: string): Promise<GroqAttempt> => {
    const requestBody: Json = {
      model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: JSON.stringify(payload) },
      ],
      // GPT-OSS is a reasoning model. Keep reasoning out of the returned payload and
      // give it enough completion budget so JSON generation is not starved/truncated.
      include_reasoning: false,
      reasoning_effort: "low",
      temperature: 0,
      max_completion_tokens: 2048,
    };
    if (responseFormat) requestBody.response_format = responseFormat;

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "authorization": `Bearer ${groqKey}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(requestBody),
    });

    let body: Json = {};
    try { body = await response.json() as Json; } catch { /* handled by caller */ }
    return { response, body, mode };
  };

  const parseBody = (attempt: GroqAttempt): { result: IntentResult; raw: Json; responseId: string | null } => {
    const body = attempt.body;
    const choices = Array.isArray(body.choices) ? body.choices as unknown[] : [];
    const first = (choices[0] ?? {}) as Json;
    const message = (first.message ?? {}) as Json;
    const content = message.content;
    let text = "";
    if (typeof content === "string") text = content.trim();
    else if (content && typeof content === "object") text = JSON.stringify(content);
    if (!text) throw new Error(`groq_empty_output:${attempt.mode}`);

    // Tolerate markdown fences and a small amount of accidental prose in plain mode.
    text = text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
    if (!text.startsWith("{") || !text.endsWith("}")) {
      const firstBrace = text.indexOf("{");
      const lastBrace = text.lastIndexOf("}");
      if (firstBrace >= 0 && lastBrace > firstBrace) text = text.slice(firstBrace, lastBrace + 1);
    }
    let parsed: unknown;
    try { parsed = JSON.parse(text); } catch { throw new Error(`groq_invalid_json:${attempt.mode}`); }
    return {
      result: validateIntent(parsed),
      raw: { ...body, salonos_groq_mode: attempt.mode },
      responseId: typeof body.id === "string" ? body.id : null,
    };
  };

  const errors: string[] = [];
  const runAttempt = async (responseFormat: Json | null, mode: string): Promise<{ result: IntentResult; raw: Json; responseId: string | null } | null> => {
    const attempt = await callGroq(responseFormat, mode);
    if (!attempt.response.ok) {
      const apiError = String(((attempt.body.error as Json | undefined)?.message ?? `HTTP ${attempt.response.status}`));
      errors.push(`${mode}:${apiError}`);
      return null;
    }
    try {
      return parseBody(attempt);
    } catch (error) {
      errors.push(`${mode}:${errorText(error)}`);
      return null;
    }
  };

  // Attempt 1: schema guidance (best-effort on GPT-OSS 20B).
  const schemaAttempt = await runAttempt({
    type: "json_schema",
    json_schema: {
      name: "salonos_whatsapp_intent_v13610_2",
      strict: false,
      schema: INTENT_SCHEMA,
    },
  }, "json_schema");
  if (schemaAttempt) return schemaAttempt;

  // Attempt 2: JSON Object Mode. Groq guarantees only JSON syntax here, so SalonOS
  // still performs the authoritative schema/domain validation locally.
  const jsonAttempt = await runAttempt({ type: "json_object" }, "json_object");
  if (jsonAttempt) return jsonAttempt;

  // Attempt 3: provider-side JSON validation is bypassed entirely. This is useful
  // when Groq itself rejects a generation with `failed_generation` even in JSON mode.
  // We still parse and validate the returned object locally before accepting it.
  const plainAttempt = await runAttempt(null, "plain_json_prompt");
  if (plainAttempt) return plainAttempt;

  // Final safety net: never turn a transient Groq formatting failure into an HTTP 500.
  // Explicit cancel/reschedule stays deterministic, and a clear booking request can
  // continue through SalonOS's deterministic service/staff/availability tool layer.
  const latest = asJson(payload.latest_message);
  const latestText = String(latest.text ?? "").trim();
  const nowLocal = String(payload.current_local_datetime ?? localNow("Asia/Kuala_Lumpur"));
  const deterministicChange = deterministicChangeCommand(latestText, nowLocal);
  if (deterministicChange) {
    return {
      result: deterministicChange,
      raw: { deterministic: true, router: "groq_failure_change_fallback_v13610_2", groq_errors: errors },
      responseId: null,
    };
  }

  const lower = latestText.toLowerCase();
  const bookingSignal = /\b(book|booking|appointment|reserve|reservation)\b|预约|預約|约个|約個|tempah|janji\s*temu/i.test(latestText);
  const serviceSignal = /hair\s*(?:color|colour|coloring|colouring|dye)|haircut|hair\s*cut|cut\s*hair|perm|rebond|straighten|treatment|scalp|highlight|bleach|wash|shampoo|blow\s*dry|染发|染髮|剪发|剪髮|理发|理髮|烫发|燙髮|护理|護理|漂发|漂髮/i.test(latestText);
  const timeSignal = /\b\d{1,2}(?::\d{2})?\s*(?:am|pm)\b|\b(?:today|tomorrow|day after tomorrow)\b|今天|明天|后天|後天|\besok\b|\blusa\b/i.test(latestText);

  if (bookingSignal || (serviceSignal && timeSignal)) {
    let dateText: string | null = null;
    let dateIso: string | null = null;
    if (/day after tomorrow|后天|後天|\blusa\b/i.test(latestText)) {
      dateText = latestText.match(/day after tomorrow|后天|後天|\blusa\b/i)?.[0] ?? null;
      dateIso = isoDateAddDays(nowLocal, 2);
    } else if (/tomorrow|明天|\besok\b/i.test(latestText)) {
      dateText = latestText.match(/tomorrow|明天|\besok\b/i)?.[0] ?? null;
      dateIso = isoDateAddDays(nowLocal, 1);
    } else if (/today|今天|hari ini/i.test(latestText)) {
      dateText = latestText.match(/today|今天|hari ini/i)?.[0] ?? null;
      dateIso = isoDateAddDays(nowLocal, 0);
    }

    let timeText: string | null = null;
    let timeIso: string | null = null;
    let timePeriod: IntentResult["entities"]["time_period"] = "unspecified";
    if (/afternoon|下午|午后|午後|petang/i.test(latestText)) timePeriod = "afternoon";
    else if (/morning|上午|早上|pagi/i.test(latestText)) timePeriod = "morning";
    else if (/evening|night|晚上|夜晚|malam/i.test(latestText)) timePeriod = "evening";

    const ampm = latestText.match(/\b(\d{1,2})(?::([0-5]\d))?\s*(am|pm)\b/i);
    const colon = latestText.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/);
    const zh = latestText.match(/(?:上午|早上|下午|午后|午後|晚上)?\s*(\d{1,2})\s*(?:点|點|時|时)\s*(?:(半)|([0-5]?\d)\s*分?)?/);
    if (ampm) {
      timeText = ampm[0];
      let hour = Number(ampm[1]);
      const minute = Number(ampm[2] ?? 0);
      const meridiem = ampm[3].toLowerCase();
      if (meridiem === "pm" && hour >= 1 && hour <= 11) hour += 12;
      if (meridiem === "am" && hour === 12) hour = 0;
      if (hour >= 0 && hour <= 23) timeIso = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
      timePeriod = hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening";
    } else if (zh) {
      timeText = zh[0].trim();
      let hour = Number(zh[1]);
      const minute = zh[2] ? 30 : Number(zh[3] ?? 0);
      if (timePeriod === "afternoon" && hour >= 1 && hour <= 6) hour += 12;
      if (timePeriod === "evening" && hour >= 1 && hour <= 11) hour += 12;
      if (hour >= 0 && hour <= 23) timeIso = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
    } else if (colon) {
      timeText = colon[0];
      const hour = Number(colon[1]);
      const minute = Number(colon[2]);
      timeIso = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
      timePeriod = hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening";
    }

    let serviceText: string | null = null;
    let serviceTerms: string[] = [];
    const serviceRules: Array<[RegExp, string, string[]]> = [
      [/hair\s*(?:color|colour|coloring|colouring|dye)|染发|染髮/i, "hair coloring", ["hair coloring", "hair colour", "hair color", "dye", "染发"]],
      [/haircut|hair\s*cut|cut\s*hair|剪发|剪髮|理发|理髮/i, "haircut", ["haircut", "hair cut", "cut", "剪发", "理发"]],
      [/perm|烫发|燙髮/i, "perm", ["perm", "perming", "烫发"]],
      [/rebond|straighten/i, "hair straightening", ["rebonding", "hair straightening", "straighten"]],
      [/highlight/i, "highlights", ["highlights", "highlight", "hair highlights"]],
      [/bleach|漂发|漂髮/i, "hair bleaching", ["bleach", "hair bleaching", "漂发"]],
      [/scalp/i, "scalp treatment", ["scalp treatment", "scalp care", "scalp"]],
      [/treatment|护理|護理/i, "hair treatment", ["hair treatment", "treatment", "hair care", "护理"]],
      [/wash|shampoo/i, "hair wash", ["hair wash", "shampoo", "wash"]],
      [/blow\s*dry/i, "blow dry", ["blow dry", "blowdry"]],
    ];
    for (const [pattern, canonical, terms] of serviceRules) {
      if (pattern.test(latestText)) { serviceText = canonical; serviceTerms = terms.slice(0, 5); break; }
    }

    let staffPreference: IntentResult["entities"]["staff_preference"] = "unknown";
    const explicitPreference = explicitStaffPreference(latestText);
    if (explicitPreference === "no_preference") staffPreference = "no_preference";
    else if (explicitPreference === "specified") staffPreference = "specified";

    return {
      result: {
        intent: "appointment",
        confidence: 0.78,
        language: detectLanguageDeterministic(latestText),
        entities: {
          service_text: serviceText,
          service_search_terms: serviceTerms,
          staff_name: null,
          staff_preference: staffPreference,
          date_text: dateText,
          date_iso: dateIso,
          time_text: timeText,
          time_iso: timeIso,
          time_period: timePeriod,
          appointment_reference: null,
          complaint_summary: null,
          membership_topic: null,
        },
      },
      raw: { deterministic: true, router: "groq_failure_booking_fallback_v13610_2", groq_errors: errors, source_text: latestText, lower },
      responseId: null,
    };
  }

  // Unknown fuzzy text should not crash the worker. It stays conservative and is
  // handled as `other` instead of inventing a business action.
  return {
    result: {
      intent: "other",
      confidence: 0.2,
      language: detectLanguageDeterministic(latestText),
      entities: {
        service_text: null,
        service_search_terms: [],
        staff_name: null,
        staff_preference: "unknown",
        date_text: null,
        date_iso: null,
        time_text: null,
        time_iso: null,
        time_period: "unspecified",
        appointment_reference: null,
        complaint_summary: null,
        membership_topic: null,
      },
    },
    raw: { deterministic: true, router: "groq_failure_safe_other_v13610_2", groq_errors: errors, source_text: latestText },
    responseId: null,
  };
}

type ProfileResult = {
  name: string | null;
  reported_age: number | null;
  age_range: string | null;
  skip_age: boolean;
  ethnicity: "华人" | "马来人" | "印度人" | "其他" | "不愿透露" | null;
  skip_ethnicity: boolean;
  language: "zh" | "en" | "ms" | "mixed" | "other";
};

const PROFILE_SCHEMA = {
  type: "object",
  properties: {
    name: { type: ["string", "null"] },
    reported_age: { type: ["integer", "null"] },
    age_range: { type: ["string", "null"] },
    skip_age: { type: "boolean" },
    ethnicity: { type: ["string", "null"], enum: ["华人", "马来人", "印度人", "其他", "不愿透露", null] },
    skip_ethnicity: { type: "boolean" },
    language: { type: "string", enum: ["zh", "en", "ms", "mixed", "other"] },
  },
  required: ["name", "reported_age", "age_range", "skip_age", "ethnicity", "skip_ethnicity", "language"],
  additionalProperties: false,
};

function validateProfile(value: unknown): ProfileResult {
  const data = asJson(value);
  const name = nullableString(data.name);
  const rawAge = data.reported_age;
  const age = rawAge === null || rawAge === undefined ? null : Number(rawAge);
  if (age !== null && (!Number.isInteger(age) || age < 1 || age > 120)) throw new Error("invalid_reported_age");
  const range = nullableString(data.age_range);
  const ethnicityRaw = nullableString(data.ethnicity);
  const allowed = new Set(["华人", "马来人", "印度人", "其他", "不愿透露"]);
  if (ethnicityRaw && !allowed.has(ethnicityRaw)) throw new Error("invalid_ethnicity");
  const language = String(data.language ?? "other");
  if (!["zh", "en", "ms", "mixed", "other"].includes(language)) throw new Error("invalid_profile_language");
  return {
    name,
    reported_age: age,
    age_range: range,
    skip_age: data.skip_age === true,
    ethnicity: ethnicityRaw as ProfileResult["ethnicity"],
    skip_ethnicity: data.skip_ethnicity === true,
    language: language as ProfileResult["language"],
  };
}


function detectProfileLanguage(text: string): ProfileResult["language"] {
  if (/[\u3400-\u9fff]/.test(text)) return "zh";
  if (/\b(?:nama|saya|umur|tahun|bangsa|melayu|cina|india|tak|tidak|rahsia|boleh)\b/i.test(text)) return "ms";
  if (/[A-Za-z]/.test(text)) return "en";
  return "other";
}

function emptyProfileResult(text: string): ProfileResult {
  return {
    name: null, reported_age: null, age_range: null, skip_age: false,
    ethnicity: null, skip_ethnicity: false, language: detectProfileLanguage(text),
  };
}

function extractProfileDeterministic(requestedField: string, latestText: string): ProfileResult {
  const result = emptyProfileResult(latestText);
  const raw = latestText.trim();
  if (!raw) return result;
  const compact = raw.toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, "");

  if (requestedField === "name") {
    if (/^(?:跳过|不想说|不方便说|保密|skip|prefernot|noname)$/i.test(compact)) return result;
    let name = raw
      .replace(/^(?:我叫|叫我|我的名字是|名字是|称呼我|请叫我)\s*/i, "")
      .replace(/^(?:my\s+name\s+is|name\s+is|call\s+me|i\s*am|i['’]?m|nama\s+saya|panggil\s+saya)\s+/i, "")
      .trim()
      .replace(/^["'“”‘’]+|["'“”‘’。.!！?？]+$/g, "")
      .trim();
    if (name.length >= 1 && name.length <= 80 && !/[\r\n]/.test(name)) result.name = name;
    return result;
  }

  if (requestedField === "age") {
    if (/(?:跳过|不愿透露|不想说|不方便|保密|skip|prefer\s*not|rather\s*not|tak\s*nak|tidak\s*mahu)/i.test(raw)) {
      result.skip_age = true;
      return result;
    }
    const range = raw.match(/(?:^|\D)(\d{1,3})\s*(?:-|–|—|~|至|到|to)\s*(\d{1,3})(?:\D|$)/i);
    if (range) {
      const a = Number(range[1]), b = Number(range[2]);
      if (a >= 1 && a <= 120 && b >= 1 && b <= 120 && a <= b) result.age_range = `${a}-${b}`;
      return result;
    }
    const exact = raw.match(/(?:^|\D)(\d{1,3})(?:\s*(?:岁|歲|years?\s*old|yo|tahun))?(?:\D|$)/i);
    if (exact) {
      const age = Number(exact[1]);
      if (Number.isInteger(age) && age >= 1 && age <= 120) result.reported_age = age;
    }
    return result;
  }

  if (requestedField === "ethnicity") {
    if (/(?:不愿透露|不想说|不方便|保密|prefer\s*not|rather\s*not|tak\s*nak|tidak\s*mahu)/i.test(raw)) {
      result.ethnicity = "不愿透露";
      result.skip_ethnicity = true;
      return result;
    }
    if (/(?:华人|華人|华裔|華裔|chinese|\bcina\b)/i.test(raw)) result.ethnicity = "华人";
    else if (/(?:马来人|馬來人|马来族|馬來族|malay|melayu)/i.test(raw)) result.ethnicity = "马来人";
    else if (/(?:印度人|印度族|indian|\bindia\b)/i.test(raw)) result.ethnicity = "印度人";
    else if (/(?:其他|other|lain)/i.test(raw)) result.ethnicity = "其他";
    return result;
  }

  return result;
}

function profileSystemPrompt(requestedField: string): string {
  return [
    "You are SalonOS Profile Extractor for a salon WhatsApp booking flow.",
    `The backend is currently asking ONLY for: ${requestedField}.`,
    "Extract only information the customer explicitly provided in the latest message.",
    "NEVER infer ethnicity/race from name, language, phone, photo, nationality, or context.",
    "NEVER infer age from appearance or any indirect clue.",
    "For name, accept natural forms such as 'Jimmy', '我叫 Jimmy', 'my name is Jimmy', or 'nama saya Jimmy'.",
    "For age, reported_age is an exact explicitly stated age. age_range is an explicitly stated range such as 20-25. If they decline/skip, set skip_age=true.",
    "For ethnicity, only map an explicit choice: Chinese/华人/Cina -> 华人; Malay/马来人/Melayu -> 马来人; Indian/印度人/India -> 印度人; Other/其他 -> 其他; prefer not to say/不愿透露/不想说 -> 不愿透露.",
    "If the requested field was not provided, leave it null/false. Do not fill other profile fields unless explicitly present in the same message.",
    "Return only the required structured result.",
  ].join("\n");
}

async function extractProfileOpenAI(openAiKey: string, model: string, requestedField: string, payload: Json): Promise<{ result: ProfileResult; raw: Json; responseId: string | null }> {
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { "authorization": `Bearer ${openAiKey}`, "content-type": "application/json" },
    body: JSON.stringify({
      model,
      input: [
        { role: "system", content: profileSystemPrompt(requestedField) },
        { role: "user", content: JSON.stringify(payload) },
      ],
      text: { format: { type: "json_schema", name: "salonos_profile_v1367", strict: true, schema: PROFILE_SCHEMA } },
      max_output_tokens: 400,
    }),
  });
  let body: Json = {};
  try { body = await response.json() as Json; } catch { /* handled below */ }
  if (!response.ok) {
    const apiError = ((body.error as Json | undefined)?.message ?? `HTTP ${response.status}`);
    throw new Error(`openai_api_error:${String(apiError)}`);
  }
  const text = extractOutputText(body);
  if (!text) throw new Error("openai_profile_empty_output");
  let parsed: unknown;
  try { parsed = JSON.parse(text); } catch { throw new Error("openai_profile_invalid_json"); }
  return { result: validateProfile(parsed), raw: body, responseId: typeof body.id === "string" ? body.id : null };
}

async function extractProfileGroq(groqKey: string, model: string, requestedField: string, payload: Json): Promise<{ result: ProfileResult; raw: Json; responseId: string | null }> {
  const callProfile = async (responseFormat: Json | null, mode: string): Promise<{ response: Response; body: Json; mode: string }> => {
    const requestBody: Json = {
      model,
      messages: [
        { role: "system", content: profileSystemPrompt(requestedField) },
        { role: "user", content: JSON.stringify(payload) },
      ],
      include_reasoning: false,
      reasoning_effort: "low",
      temperature: 0,
      max_completion_tokens: 1200,
    };
    if (responseFormat) requestBody.response_format = responseFormat;
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "authorization": `Bearer ${groqKey}`, "content-type": "application/json" },
      body: JSON.stringify(requestBody),
    });
    let body: Json = {};
    try { body = await response.json() as Json; } catch { /* handled below */ }
    return { response, body, mode };
  };

  const parseProfile = (attempt: { body: Json; mode: string }): { result: ProfileResult; raw: Json; responseId: string | null } => {
    const body = attempt.body;
    const choices = Array.isArray(body.choices) ? body.choices as unknown[] : [];
    const first = asJson(choices[0]);
    const message = asJson(first.message);
    let text = typeof message.content === "string" ? message.content.trim() : "";
    if (!text) throw new Error(`groq_profile_empty_output:${attempt.mode}`);
    text = text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
    if (!text.startsWith("{") || !text.endsWith("}")) {
      const a = text.indexOf("{");
      const b = text.lastIndexOf("}");
      if (a >= 0 && b > a) text = text.slice(a, b + 1);
    }
    let parsed: unknown;
    try { parsed = JSON.parse(text); } catch { throw new Error(`groq_profile_invalid_json:${attempt.mode}`); }
    return { result: validateProfile(parsed), raw: { ...body, salonos_groq_mode: attempt.mode }, responseId: typeof body.id === "string" ? body.id : null };
  };

  const errors: string[] = [];
  const tryMode = async (format: Json | null, mode: string) => {
    const attempt = await callProfile(format, mode);
    if (!attempt.response.ok) {
      errors.push(`${mode}:${String(((attempt.body.error as Json | undefined)?.message ?? `HTTP ${attempt.response.status}`))}`);
      return null;
    }
    try { return parseProfile(attempt); } catch (error) { errors.push(`${mode}:${errorText(error)}`); return null; }
  };

  const schema = await tryMode({ type: "json_schema", json_schema: { name: "salonos_profile_v13610_2", strict: false, schema: PROFILE_SCHEMA } }, "json_schema");
  if (schema) return schema;
  const jsonMode = await tryMode({ type: "json_object" }, "json_object");
  if (jsonMode) return jsonMode;
  const plain = await tryMode(null, "plain_json_prompt");
  if (plain) return plain;

  // Conservative deterministic profile fallback. It only records facts explicitly
  // present in the latest message and never infers race/ethnicity or age.
  const latest = asJson(payload.latest_message);
  const text = String(latest.text ?? "").trim();
  const lang = detectLanguageDeterministic(text);
  const result: ProfileResult = {
    name: null,
    reported_age: null,
    age_range: null,
    skip_age: false,
    ethnicity: null,
    skip_ethnicity: false,
    language: lang,
  };

  if (requestedField === "age") {
    const exactAge = text.match(/(?:^|\b)(?:i\s*(?:am|'m)\s*)?(\d{1,3})(?:\s*(?:years?\s*old|岁|歲|tahun))?(?:\b|$)/i);
    const range = text.match(/\b(\d{1,2})\s*[-–~]\s*(\d{1,2})\b/);
    if (range) result.age_range = `${range[1]}-${range[2]}`;
    else if (exactAge) {
      const age = Number(exactAge[1]);
      if (Number.isInteger(age) && age >= 1 && age <= 120) result.reported_age = age;
    }
    if (/prefer not|rather not|don'?t want to say|不愿透露|不願透露|不想说|不想說|tak mahu|tidak mahu/i.test(text)) result.skip_age = true;
  } else if (requestedField === "ethnicity") {
    if (/\bchinese\b|华人|華人|\bcina\b/i.test(text)) result.ethnicity = "华人";
    else if (/\bmalay\b|马来人|馬來人|\bmelayu\b/i.test(text)) result.ethnicity = "马来人";
    else if (/\bindian\b|印度人|\bindia\b/i.test(text)) result.ethnicity = "印度人";
    else if (/\bother\b|其他|lain/i.test(text)) result.ethnicity = "其他";
    else if (/prefer not|rather not|don'?t want to say|不愿透露|不願透露|不想说|不想說|tak mahu|tidak mahu/i.test(text)) {
      result.ethnicity = "不愿透露";
      result.skip_ethnicity = true;
    }
  } else if (requestedField === "name") {
    const named = text.match(/(?:my name is|i am|i'm|nama saya|我叫|我是)\s+([\p{L}][\p{L}\p{M}' .-]{0,60})/iu);
    if (named) result.name = named[1].trim();
    else if (/^[\p{L}][\p{L}\p{M}' .-]{0,60}$/u.test(text)) result.name = text;
  }

  return { result, raw: { deterministic: true, router: "groq_profile_failure_safe_v13610_2", groq_errors: errors, source_text: text }, responseId: null };
}

function compactCommand(text: string): string {
  return text.toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, "").trim();
}

function isConfirmDraftText(text: string): boolean {
  const c = compactCommand(text);
  return new Set(["确认", "确认预约", "确定", "确定预约", "好", "好的", "可以", "ok", "okay", "yes", "confirm", "confirmed", "ya", "setuju", "boleh"]).has(c);
}

function isCancelDraftText(text: string): boolean {
  const c = compactCommand(text);
  return new Set(["取消", "取消预约", "不要", "不确认", "不用了", "cancel", "no", "nope", "batal", "tak", "tidak"]).has(c);
}

function conversationReplyLanguage(latestText: string, recentMessages: Json[], modelLanguage: string = "other"): "zh" | "en" | "ms" {
  // v13.6.10.56 — reply in the customer's active language instead of forcing
  // every WhatsApp turn to English. Short follow-ups such as "who?" inherit
  // the language of the latest recognizable inbound customer message.
  const direct = detectLanguageDeterministic(latestText);
  const neutralTemporalReply = isLanguageNeutralTemporalReply(latestText);
  if (!neutralTemporalReply && ["zh", "en", "ms"].includes(direct)) return direct as "zh" | "en" | "ms";
  let skippedCurrentInbound = false;
  for (const row of recentMessages) {
    if (String(row.direction ?? "") !== "inbound") continue;
    // recentMessages includes the message currently being processed. Skip that
    // one when a neutral clock token such as "7pm" needs the prior language.
    if (neutralTemporalReply && !skippedCurrentInbound
        && String(row.text_body ?? "").trim() === String(latestText || "").trim()) {
      skippedCurrentInbound = true;
      continue;
    }
    const detected = detectLanguageDeterministic(String(row.text_body ?? ""));
    if (["zh", "en", "ms"].includes(detected)) return detected as "zh" | "en" | "ms";
  }
  if (["zh", "en", "ms"].includes(direct)) return direct as "zh" | "en" | "ms";
  if (["zh", "en", "ms"].includes(modelLanguage)) return modelLanguage as "zh" | "en" | "ms";
  return "en";
}

function profileQuestion(field: string, lang: "zh" | "en" | "ms", name?: string | null, retry = false): string {
  if (field === "name") {
    if (lang === "zh") return retry ? "我还没读到您的称呼。请直接告诉我姓名，例如：Jimmy。" : "为了建立预约草稿，请问怎么称呼您？";
    if (lang === "ms") return retry ? "Saya belum dapat nama anda. Sila beritahu nama, contohnya: Jimmy." : "Untuk sediakan draf tempahan, boleh saya tahu nama anda?";
    return retry ? "I couldn't read your name. Please tell me your name, for example: Jimmy." : "To prepare the booking draft, may I have your name?";
  }
  if (field === "age") {
    const prefix = name ? (lang === "zh" ? `谢谢，${name}。` : lang === "ms" ? `Terima kasih, ${name}. ` : `Thanks, ${name}. `) : "";
    if (lang === "zh") return `${prefix}${retry ? "我还没读到年龄资料。" : ""}方便提供年龄或年龄范围吗？例如「21」或「20-25」；不方便的话回复「跳过」即可。`;
    if (lang === "ms") return `${prefix}${retry ? "Saya belum dapat maklumat umur. " : ""}Boleh kongsi umur atau julat umur, contohnya 21 atau 20-25? Jika tidak mahu, balas "skip".`;
    return `${prefix}${retry ? "I couldn't read an age. " : ""}Could you share your age or age range, for example 21 or 20-25? If you'd rather not, reply "skip".`;
  }
  if (lang === "zh") return `${retry ? "我还没读到有效选项。" : ""}最后一个选填资料：族群请选择「华人 / 马来人 / 印度人 / 其他 / 不愿透露」。`;
  if (lang === "ms") return `${retry ? "Saya belum dapat pilihan yang sah. " : ""}Maklumat pilihan terakhir: sila pilih Chinese / Malay / Indian / Other / Prefer not to say.`;
  return `${retry ? "I couldn't read a valid option. " : ""}One last optional detail: choose Chinese / Malay / Indian / Other / Prefer not to say.`;
}

function displayServiceName(value: string | null, lang: "zh" | "en" | "ms", fallback?: string | null): string {
  const raw = (value ?? "").trim();
  if (lang !== "en") return raw || (fallback ?? "Selected service");
  if (raw && !/[\u3400-\u9fff]/u.test(raw)) return raw;
  const candidate = (fallback ?? "").trim();
  if (candidate && !/[\u3400-\u9fff]/u.test(candidate)) return candidate;
  const source = `${raw} ${candidate}`;
  if (/balayage/i.test(source)) return "Balayage";
  if (/ombre/i.test(source)) return "Ombre Hair Color";
  if (/highlight|挑染/u.test(source)) return "Highlights";
  if (/漂发|漂髮|漂色|bleach/iu.test(source)) return "Bleaching";
  if (/染发|染髮|染色|color|colour|dye/iu.test(source)) return "Hair Coloring";
  if (/烫发|燙髮|perm/iu.test(source)) return "Perm";
  if (/拉直|离子|離子|rebond/iu.test(source)) return "Rebonding";
  if (/头皮|頭皮|scalp/iu.test(source)) return "Scalp Treatment";
  if (/护理|護理|treatment/iu.test(source)) return "Hair Treatment";
  if (/接发|接髮|extension/iu.test(source)) return "Hair Extensions";
  if (/胡须|鬍鬚|beard/iu.test(source)) return "Beard Service";
  if (/洗头|洗頭|shampoo|hair\s*wash/iu.test(source)) return "Hair Wash";
  if (/造型|styling/iu.test(source)) return "Hair Styling";
  if (/剪发|剪髮|理发|理髮|hair\s*cut|haircut|trim/iu.test(source)) return "Haircut";
  return raw ? "Selected service" : (candidate || "Selected service");
}

function displayEthnicity(value: string | null, lang: "zh" | "en" | "ms"): string {
  const v = (value ?? "").trim();
  if (!v) return lang === "zh" ? "未提供" : "Not provided";
  if (lang === "en") {
    if (["华人", "華人"].includes(v)) return "Chinese";
    if (["马来人", "馬來人"].includes(v)) return "Malay";
    if (v === "印度人") return "Indian";
    if (v === "其他") return "Other";
    if (v === "不愿透露") return "Prefer not to say";
  }
  if (lang === "ms") {
    if (["华人", "華人"].includes(v)) return "Chinese";
    if (["马来人", "馬來人"].includes(v)) return "Malay";
    if (v === "印度人") return "Indian";
    if (v === "其他") return "Other";
    if (v === "不愿透露") return "Prefer not to say";
  }
  return v;
}

function draftSummaryText(draft: Json, lang: "zh" | "en" | "ms"): string {
  const customer = asJson(draft.customer);
  const appt = asJson(draft.appointment);
  const name = nullableString(customer.name) ?? "-";
  const age = customer.reported_age != null ? String(customer.reported_age) : (nullableString(customer.age_range) ?? (lang === "zh" ? "未提供" : "Not provided"));
  const ethnicity = displayEthnicity(nullableString(customer.ethnicity), lang);
  const date = displayDate(nullableString(appt.date));
  const timeRaw = nullableString(appt.time) ?? "";
  const time = displayTime(timeRaw);
  const service = displayServiceName(nullableString(appt.service_name), lang);
  const staff = nullableString(appt.employee_name) ?? "-";
  if (lang === "zh") return [
    "预约草稿（尚未正式建立）",
    `姓名：${name}`,
    `日期：${date}`,
    `时间：${time}`,
    `项目：${service}`,
    `理发师：${staff}`,
    `年龄：${age}`,
    `族群：${ethnicity}`,
    "",
    "请回复「确认」才会正式建立预约；回复「取消」则取消这份草稿。",
  ].join("\n");
  if (lang === "ms") return [
    "Draf tempahan (belum disahkan)",
    `Nama: ${name}`,
    `Tarikh: ${date}`,
    `Masa: ${time}`,
    `Servis: ${service}`,
    `Stylist: ${staff}`,
    `Umur: ${age}`,
    `Etnik: ${ethnicity}`,
    "",
    "Balas \"confirm\" untuk membuat tempahan rasmi, atau \"cancel\" untuk membatalkan draf.",
  ].join("\n");
  return [
    "Booking draft (not confirmed yet)",
    `Name: ${name}`,
    `Date: ${date}`,
    `Time: ${time}`,
    `Service: ${service}`,
    `Stylist: ${staff}`,
    `Age: ${age}`,
    `Ethnicity: ${ethnicity}`,
    "",
    "Reply \"confirm\" to create the appointment, or \"cancel\" to cancel this draft.",
  ].join("\n");
}

function confirmedBookingText(result: Json, lang: "zh" | "en" | "ms"): string {
  const appt = asJson(result.appointment);
  const visitNo = nullableString(result.visit_number) ?? "";
  const date = displayDate(nullableString(appt.date));
  const time = displayTime(nullableString(appt.time) ?? "");
  const service = nullableString(appt.service_name) ?? "";
  const staff = nullableString(appt.employee_name) ?? "";
  if (lang === "zh") return `预约成功 ✅\n${date} · ${time}\n${staff} · ${service}${visitNo ? `\n预约编号：${visitNo}` : ""}`;
  if (lang === "ms") return `Tempahan berjaya ✅\n${date} · ${time}\n${staff} · ${service}${visitNo ? `\nNo. tempahan: ${visitNo}` : ""}`;
  return `Booking confirmed ✅\n${date} · ${time}\n${staff} · ${service}${visitNo ? `\nBooking no.: ${visitNo}` : ""}`;
}

function slotUnavailableText(result: Json, lang: "zh" | "en" | "ms"): string {
  const alternatives = asJson(result.alternatives);
  const slots = Array.isArray(alternatives.slots) ? alternatives.slots as unknown[] : [];
  const times = slots.map((x) => nullableString(asJson(x).time)).filter((x): x is string => Boolean(x)).slice(0, 5);
  const labels = times.map(displayTime);
  if (lang === "zh") return labels.length
    ? `刚才选择的时间已经没有空位了。现在可选：${labels.join("、")}。请告诉我新的时间。`
    : "刚才选择的时间已经没有空位了。请告诉我您想改到哪个时间，我会重新查询。";
  if (lang === "ms") return labels.length
    ? `Slot yang dipilih tadi sudah tidak tersedia. Slot semasa: ${labels.join(", ")}. Sila pilih masa baharu.`
    : "Slot yang dipilih tadi sudah tidak tersedia. Beritahu masa lain dan saya akan semak semula.";
  return labels.length
    ? `That time is no longer available. Current options: ${labels.join(", ")}. Please choose a new time.`
    : "That time is no longer available. Tell me another time and I'll check again.";
}


function isConfirmCancelAppointmentText(text: string): boolean {
  const c = compactCommand(text);
  return new Set([
    "确认取消", "确定取消", "确认取消预约", "确定取消预约", "是的取消", "对取消",
    "confirmcancel", "yescancel", "cancelappointment", "confirmcancellation",
    "sahkanbatal", "batalkantempahan", "yabatal",
  ]).has(c);
}

function isAbortAppointmentChangeText(text: string): boolean {
  const c = compactCommand(text);
  return new Set([
    "算了", "不用了", "保留", "保留预约", "不取消", "不要取消", "不改了", "不要改了", "取消改期", "取消修改",
    "keep", "keepbooking", "nevermind", "dontcancel", "donotcancel", "dontchange", "cancelchange",
    "kekalkan", "janganbatal", "takjaditukar", "tidakjaditukar",
  ]).has(c);
}

function parseAppointmentSelection(text: string, max: number): number | null {
  const c = compactCommand(text);
  const m = c.match(/^(?:第)?([1-9])(?:个|筆|笔|號|号)?$/u) ?? c.match(/^option([1-9])$/u);
  if (!m) return null;
  const n = Number(m[1]);
  return n >= 1 && n <= max ? n - 1 : null;
}

function candidateArray(findResult: Json): Json[] {
  return Array.isArray(findResult.candidates) ? (findResult.candidates as unknown[]).map(asJson) : [];
}

function candidateLine(candidate: Json, index?: number): string {
  const prefix = index == null ? "" : `${index + 1}. `;
  const date = displayDate(nullableString(candidate.date));
  const time = displayTime(nullableString(candidate.time) ?? "");
  const service = displayServiceName(nullableString(candidate.service_name), "en");
  const employee = nullableString(candidate.employee_name) ?? "Stylist";
  const ref = nullableString(candidate.visit_number);
  return `${prefix}${date} ${time} · ${service} · ${employee}${ref ? ` · ${ref}` : ""}`;
}

function changeDraftSummaryText(draft: Json, lang: "zh" | "en" | "ms"): string {
  const appt = asJson(draft.appointment);
  const requested = asJson(draft.requested);
  const action = String(draft.action_type ?? "");
  const original = candidateLine(appt);
  if (action === "cancel") {
    if (lang === "zh") return `找到这笔预约：\n${original}\n\n如要取消，请回复「确认取消」。如要保留预约，请回复「保留预约」。`;
    if (lang === "ms") return `Saya jumpa tempahan ini:\n${original}\n\nUntuk batal, balas "confirm cancel". Untuk kekalkan tempahan, balas "keep".`;
    return `I found this appointment:\n${original}\n\nTo cancel it, reply "confirm cancel". To keep it, reply "keep booking".`;
  }
  const newDate = displayDate(nullableString(requested.date));
  const newTime = displayTime(nullableString(requested.time) ?? "");
  if (lang === "zh") return `改期草稿（尚未修改原预约）\n原预约：${original}\n新时间：${newDate} ${newTime}\n\n请回复「确认」才会正式改期；回复「保留预约」则维持原预约。`;
  if (lang === "ms") return `Draf tukar masa (tempahan asal belum diubah)\nAsal: ${original}\nMasa baharu: ${newDate} ${newTime}\n\nBalas "confirm" untuk sahkan perubahan, atau "keep" untuk kekalkan tempahan asal.`;
  return `Reschedule draft (original appointment not changed yet)\nOriginal: ${original}\nNew time: ${newDate} ${newTime}\n\nReply "confirm" to apply the change, or "keep booking" to keep the original appointment.`;
}

function changeSuccessText(result: Json, lang: "zh" | "en" | "ms"): string {
  const action = String(result.action_type ?? "");
  const ref = nullableString(result.visit_number) ?? "";
  if (action === "cancel") {
    if (lang === "zh") return `预约已取消 ✅${ref ? `\n预约编号：${ref}` : ""}\n这次取消不会计入到店次数。`;
    if (lang === "ms") return `Tempahan telah dibatalkan ✅${ref ? `\nNo. tempahan: ${ref}` : ""}`;
    return `Appointment cancelled ✅${ref ? `\nBooking no.: ${ref}` : ""}`;
  }
  const requested = asJson(result.requested);
  const date = displayDate(nullableString(requested.date));
  const time = displayTime(nullableString(requested.time) ?? "");
  if (lang === "zh") return `预约已改期 ✅\n${date} · ${time}${ref ? `\n预约编号：${ref}` : ""}\n提醒时间也会按新预约时间重新计算。`;
  if (lang === "ms") return `Tempahan berjaya ditukar ✅\n${date} · ${time}${ref ? `\nNo. tempahan: ${ref}` : ""}`;
  return `Appointment rescheduled ✅\n${date} · ${time}${ref ? `\nBooking no.: ${ref}` : ""}`;
}

function changeNoAppointmentText(lang: "zh" | "en" | "ms", intent: string): string {
  if (lang === "zh") return intent === "cancel"
    ? "我没有在这个分行找到属于您、仍在未来且尚未开始的预约。若您有预约编号，可以直接发给我。"
    : "我没有在这个分行找到属于您、仍在未来且可改期的预约。若您有预约编号，可以直接发给我。";
  if (lang === "ms") return "Saya tidak jumpa tempahan masa hadapan yang masih boleh diubah untuk nombor WhatsApp ini. Jika ada nombor tempahan, sila hantarkan kepada saya.";
  return "I couldn't find a future appointment for this WhatsApp number that is still eligible for self-service. If you have the booking number, send it to me.";
}

function changeMultipleAppointmentsText(findResult: Json, lang: "zh" | "en" | "ms", intent: string): string {
  const candidates = candidateArray(findResult).slice(0, 8);
  const lines = candidates.map((c, i) => candidateLine(c, i)).join("\n");
  if (lang === "zh") return `${intent === "cancel" ? "我找到多笔可取消预约" : "我找到多笔可改期预约"}：\n${lines}\n\n请回复序号，例如「1」。`;
  if (lang === "ms") return `Saya jumpa beberapa tempahan:\n${lines}\n\nBalas nombor pilihan, contohnya "1".`;
  return `I found multiple appointments:\n${lines}\n\nReply with the number, for example "1".`;
}

function rescheduleSlotsText(availability: Json, lang: "zh" | "en" | "ms"): string {
  const date = displayDate(nullableString(availability.date));
  const employee = nullableString(asJson(availability.employee).name) ?? "理发师";
  const slots = Array.isArray(availability.slots) ? availability.slots as unknown[] : [];
  const times = slots.map((x) => nullableString(asJson(x).time)).filter((x): x is string => Boolean(x)).slice(0, 8);
  const labels = times.map(displayTime);
  if (!labels.length) {
    if (lang === "zh") return `${employee} 在 ${date} 这个时段暂时没有可改期的空位。请告诉我其他日期或时间。`;
    if (lang === "ms") return `Tiada slot sesuai untuk ${employee} pada ${date}. Sila beri tarikh atau masa lain.`;
    return `There are no suitable reschedule slots with ${employee} on ${date}. Tell me another date or time.`;
  }
  if (lang === "zh") return `${employee} 在 ${date} 可改到：${labels.join("、")}。请回复您要的时间。`;
  if (lang === "ms") return `${employee} ada slot pada ${date}: ${labels.join(", ")}. Sila pilih masa.`;
  return `${employee} has these reschedule slots on ${date}: ${labels.join(", ")}. Please choose a time.`;
}

function buildChangeReply(
  language: IntentResult["language"],
  latestText: string,
  intent: "cancel" | "reschedule",
  pipelineStage: string,
  tools: Json | null,
  changeDraft: Json | null,
): ReplyPlan {
  const lang = replyLanguage(language, latestText);
  const t = asJson(tools);
  const found = asJson(t.find_upcoming_appointments);
  const availability = asJson(t.check_reschedule_availability);
  const draft = asJson(changeDraft);

  if (pipelineStage === `${intent}_not_found`) {
    return { send: true, kind: `${intent}_not_found`, text: changeNoAppointmentText(lang, intent), state: pipelineStage, pendingAction: "await_booking_reference_or_staff", offeredSlots: [], selectedTime: null, reason: null };
  }
  if (pipelineStage === `${intent}_selecting_appointment`) {
    return { send: true, kind: `${intent}_select_appointment`, text: changeMultipleAppointmentsText(found, lang, intent), state: pipelineStage, pendingAction: "select_existing_appointment", offeredSlots: [], selectedTime: null, reason: null };
  }
  if (pipelineStage === "cancel_awaiting_confirmation" && draft.ok === true) {
    return { send: true, kind: "cancel_confirmation", text: changeDraftSummaryText(draft, lang), state: pipelineStage, pendingAction: "confirm_cancel_existing_appointment", offeredSlots: [], selectedTime: null, reason: null };
  }
  if (pipelineStage === "reschedule_awaiting_new_time") {
    const appt = asJson(t.target_appointment);
    const original = Object.keys(appt).length ? `\n${candidateLine(appt)}` : "";
    const text = lang === "zh" ? `可以改期。请告诉我新的日期和时间，例如「明天下午5点」。${original}`
      : lang === "ms" ? `Boleh. Beritahu tarikh dan masa baharu, contohnya esok 5 petang.${original}`
      : `Sure. Tell me the new date and time, for example tomorrow at 5 PM.${original}`;
    return { send: true, kind: "reschedule_collect_time", text, state: pipelineStage, pendingAction: "collect_reschedule_datetime", offeredSlots: [], selectedTime: null, reason: null };
  }
  if (pipelineStage === "reschedule_awaiting_slot_selection") {
    const slots = Array.isArray(availability.slots) ? (availability.slots as unknown[]).map((x) => nullableString(asJson(x).time)).filter((x): x is string => Boolean(x)) : [];
    return { send: true, kind: "reschedule_slots", text: rescheduleSlotsText(availability, lang), state: pipelineStage, pendingAction: "select_reschedule_time", offeredSlots: slots, selectedTime: null, reason: null };
  }
  if (pipelineStage === "reschedule_awaiting_confirmation" && draft.ok === true) {
    return { send: true, kind: "reschedule_confirmation", text: changeDraftSummaryText(draft, lang), state: pipelineStage, pendingAction: "confirm_reschedule_existing_appointment", offeredSlots: [], selectedTime: nullableString(asJson(draft.requested).time), reason: null };
  }
  if (pipelineStage === "reschedule_human_required") {
    const text = lang === "zh" ? "这笔预约涉及多位员工或较复杂安排，我不会自动改动它。已经停止自动改期，请让门店员工确认。"
      : lang === "ms" ? "Tempahan ini melibatkan susunan yang kompleks. Saya tidak akan mengubahnya secara automatik; staf kedai perlu mengesahkannya."
      : "This appointment has a complex multi-staff setup, so I won't modify it automatically. Store staff should verify the change.";
    return { send: true, kind: "reschedule_human_required", text, state: pipelineStage, pendingAction: "human_reschedule_required", offeredSlots: [], selectedTime: null, reason: "complex_booking_requires_human" };
  }
  return { send: false, kind: "suppressed", text: "", state: pipelineStage, pendingAction: "no_safe_reply", offeredSlots: [], selectedTime: null, reason: `unsupported_change_state:${pipelineStage}` };
}

type DeliveryResult = {
  status: "sent" | "suppressed" | "failed";
  outboundMessageId: string | null;
  metaMessageId: string | null;
  reason: string | null;
};

type ReplyPlan = {
  send: boolean;
  kind: string;
  text: string;
  state: string;
  pendingAction: string;
  offeredSlots: string[];
  selectedTime: string | null;
  reason: string | null;
};

function isGreetingText(text: string): boolean {
  const c = compactCommand(text);
  return new Set([
    "你好", "您好", "哈喽", "哈囉", "嗨", "在吗", "在嗎",
    "hi", "hello", "hey", "hallo", "morning", "goodmorning",
    "selamatpagi", "hai", "helo",
  ]).has(c);
}

function moneyRM(value: unknown): string | null {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return null;
  return `RM ${n.toFixed(2)}`;
}

function buildInformationalReply(
  lang: "zh" | "en" | "ms",
  latestText: string,
  intent: string,
  tools: Json | null,
  staffMention: Json | null,
): ReplyPlan | null {
  const t = asJson(tools);
  if (intent === "price_enquiry" || intent === "service_enquiry") {
    const resolution = asJson(t.resolve_service);
    const status = String(resolution.resolution_status ?? "");
    const service = asJson(resolution.service);
    if (status === "matched" && nullableString(service.name)) {
      const name = nullableString(service.name) ?? "service";
      const price = moneyRM(service.price);
      const minutes = Number(service.estimated_minutes ?? 0);
      let text = "";
      if (intent === "price_enquiry") {
        if (lang === "zh") text = price ? `${name} 目前系统价格是 ${price}${minutes > 0 ? `，预计约 ${minutes} 分钟` : ""}。如果你要的话，我也可以直接帮你查今天/指定日期几点有空。` : `我找到 ${name} 这个项目了，不过目前系统没有设置固定价格。要不要我帮你查预约时间？`;
        else if (lang === "ms") text = price ? `Harga semasa untuk ${name} ialah ${price}${minutes > 0 ? `, anggaran ${minutes} minit` : ""}. Jika mahu, saya boleh terus semak slot yang tersedia.` : `Saya jumpa servis ${name}, tetapi harga tetap belum ditetapkan dalam sistem. Mahu saya semak slot tempahan?`;
        else text = price ? `The current price for ${name} is ${price}${minutes > 0 ? ` and it takes about ${minutes} minutes` : ""}. If you'd like, I can also check available appointment times.` : `I found ${name}, but there isn't a fixed price configured yet. I can still help you check appointment times.`;
      } else {
        if (lang === "zh") text = `${name}${price ? ` · ${price}` : ""}${minutes > 0 ? ` · 约 ${minutes} 分钟` : ""}。如果你想预约，直接告诉我日期、时间，以及有没有指定理发师就可以。`;
        else if (lang === "ms") text = `${name}${price ? ` · ${price}` : ""}${minutes > 0 ? ` · kira-kira ${minutes} minit` : ""}. Untuk tempahan, beritahu tarikh, masa dan stylist pilihan jika ada.`;
        else text = `${name}${price ? ` · ${price}` : ""}${minutes > 0 ? ` · about ${minutes} minutes` : ""}. To book, just tell me the date, time, and whether you want a specific stylist.`;
      }
      return { send: true, kind: intent, text, state: "idle", pendingAction: "await_customer_request", offeredSlots: [], selectedTime: null, reason: null };
    }
    const names = candidateNames(resolution.candidates, "service");
    if (names.length) {
      const list = names.join(", ");
      const text = lang === "zh" ? `我找到几个可能的项目：${list}。你问的是哪一个？`
        : lang === "ms" ? `Saya jumpa beberapa servis yang mungkin: ${list}. Yang mana satu anda maksudkan?`
        : `I found a few possible services: ${list}. Which one did you mean?`;
      return { send: true, kind: `${intent}_clarify_service`, text, state: "idle", pendingAction: "clarify_service", offeredSlots: [], selectedTime: null, reason: status || "ambiguous" };
    }
  }

  if (intent === "staff_enquiry" && staffMention && nullableString(staffMention.name)) {
    const name = nullableString(staffMention.name) ?? "the stylist";
    const text = lang === "zh"
      ? `${name} 是这家分行的员工。你是想预约 ${name} 吗？告诉我想做的项目和日期/时间，我直接帮你查。`
      : lang === "ms"
        ? `${name} ialah staf di cawangan ini. Anda mahu tempah dengan ${name}? Beritahu servis, tarikh dan masa, saya boleh semak terus.`
        : `${name} is a stylist at this branch. Would you like to book with ${name}? Tell me the service, date and time and I can check directly.`;
    return { send: true, kind: "staff_enquiry", text, state: "idle", pendingAction: "await_booking_details", offeredSlots: [], selectedTime: null, reason: null };
  }

  return null;
}

function buildSafeFallbackReply(
  lang: "zh" | "en" | "ms",
  latestText: string,
  intent: string,
): ReplyPlan {
  const greeting = intent === "other" && isGreetingText(latestText);
  if (greeting) {
    const text = lang === "zh"
      ? "你好 👋 请问有什么可以帮您？我可以直接处理预约、改期和取消预约。"
      : lang === "ms"
        ? "Hai 👋 Ada apa yang boleh saya bantu? Saya boleh urus tempahan, tukar masa dan pembatalan."
        : "Hi 👋 How can I help? I can handle bookings, rescheduling and cancellations.";
    return { send: true, kind: "greeting", text, state: "idle", pendingAction: "await_customer_request", offeredSlots: [], selectedTime: null, reason: null };
  }

  const text = lang === "zh"
    ? "我收到您的消息。目前自动系统可以直接处理预约、改期和取消预约；其他门店、价格、会员或一般问题我不会猜答案。请告诉我具体需求，或联系门店员工确认。"
    : lang === "ms"
      ? "Saya sudah terima mesej anda. Sistem automatik kini boleh urus tempahan, tukar masa dan pembatalan. Untuk harga, keahlian, maklumat kedai atau soalan lain, saya tidak akan meneka jawapan; sila beri butiran atau semak dengan staf kedai."
      : "I received your message. The automated system can currently handle bookings, rescheduling and cancellations. I won't guess prices, membership details, store information or other facts; please share the details or confirm with store staff.";
  return { send: true, kind: "safe_fallback", text, state: "idle", pendingAction: "await_customer_request", offeredSlots: [], selectedTime: null, reason: null };
}

function asJson(value: unknown): Json {
  return ((value ?? {}) as Json);
}

function nullableString(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function mergeAppointmentEntities(
  current: IntentResult["entities"],
  previousState: Json | null,
  currentIntent: string,
  allowInformationalContextCarry = false,
): IntentResult["entities"] {
  const prevIntent = String(previousState?.active_intent ?? "");
  // Normal booking slots carry only across appointment -> appointment. A short
  // date/time answer immediately after a factual service/staff answer is the one
  // deliberate exception: it promotes that fresh context into a booking without
  // losing the service or stylist the customer was just discussing.
  const canCarry = prevIntent === "appointment"
    || (allowInformationalContextCarry && ["price_enquiry", "service_enquiry", "staff_enquiry"].includes(prevIntent));
  if (currentIntent !== "appointment" || !canCarry) return current;
  const prev = asJson(previousState?.slots);
  const prevTools = asJson(prev.appointment_tools);
  const previousServiceText = nullableString(prev.service_text)
    ?? nullableString(asJson(asJson(prevTools.resolve_service).service).name);
  const previousStaffName = nullableString(prev.staff_name)
    ?? nullableString(asJson(asJson(prevTools.resolve_staff).staff).name);
  const prevTerms = Array.isArray(prev.service_search_terms)
    ? (prev.service_search_terms as unknown[]).filter((x) => typeof x === "string" && x.trim()).map(String)
    : (previousServiceText ? [previousServiceText] : []);
  const currentPeriod = current.time_period === "unspecified" ? null : current.time_period;
  const prevPeriodRaw = String(prev.time_period ?? "unspecified");
  const prevPeriod = ["morning", "afternoon", "evening", "night"].includes(prevPeriodRaw) ? prevPeriodRaw : "unspecified";
  const effectivePeriod = (currentPeriod ?? prevPeriod) as IntentResult["entities"]["time_period"];
  const currentPeriodWasExplicit = current.time_period !== "unspecified";
  let effectiveTimeIso = current.time_iso;
  // v13.6.10.34: a date-only continuation such as "明天呢" means the same
  // requested clock time on the new date. Preserve the prior exact time only when
  // the latest turn did not itself introduce a new daypart. If the customer says
  // "明天上午", do not incorrectly carry a previous 3 PM into the morning.
  if (!effectiveTimeIso && !currentPeriodWasExplicit) {
    effectiveTimeIso = nullableString(prev.time_iso) ?? nullableString(prev.selected_time);
  }
  // Deterministic repair for short follow-ups such as "3点" after an afternoon offer.
  // The LLM still extracts the hour, but the state machine owns AM/PM disambiguation.
  if (effectiveTimeIso && effectivePeriod === "afternoon") {
    const m = effectiveTimeIso.match(/^(\d{2}):(\d{2})$/);
    if (m) {
      const h = Number(m[1]);
      if (h >= 1 && h <= 5) effectiveTimeIso = `${String(h + 12).padStart(2, "0")}:${m[2]}`;
    }
  }
  return {
    service_text: current.service_text ?? previousServiceText,
    service_search_terms: current.service_search_terms.length ? current.service_search_terms : prevTerms.slice(0, 5),
    staff_name: current.staff_name ?? previousStaffName,
    staff_preference: current.staff_name ? "specified"
      : (current.staff_preference !== "unknown" ? current.staff_preference
        : (["specified", "no_preference"].includes(String(prev.staff_preference ?? ""))
          ? String(prev.staff_preference) as IntentResult["entities"]["staff_preference"] : "unknown")),
    date_text: current.date_text ?? nullableString(prev.date_text),
    date_iso: current.date_iso ?? nullableString(prev.date_iso),
    time_text: current.time_text ?? nullableString(prev.time_text),
    time_iso: effectiveTimeIso,
    time_period: effectivePeriod,
    appointment_reference: current.appointment_reference ?? nullableString(prev.appointment_reference),
    complaint_summary: current.complaint_summary,
    membership_topic: current.membership_topic,
  };
}


function mergeChangeEntities(
  current: IntentResult["entities"],
  previousState: Json | null,
  currentIntent: string,
): IntentResult["entities"] {
  const prevIntent = String(previousState?.active_intent ?? "");
  if (!["cancel", "reschedule"].includes(currentIntent) && !["cancel", "reschedule"].includes(prevIntent)) return current;
  const prevSlots = asJson(previousState?.slots);
  const prevRequest = asJson(prevSlots.change_request);
  const prevPeriodRaw = String(prevRequest.time_period ?? prevSlots.time_period ?? "unspecified");
  const prevPeriod = ["morning", "afternoon", "evening", "night"].includes(prevPeriodRaw) ? prevPeriodRaw : "unspecified";
  const currentPeriod = current.time_period === "unspecified" ? null : current.time_period;
  const effectivePeriod = (currentPeriod ?? prevPeriod) as IntentResult["entities"]["time_period"];
  let effectiveTimeIso = current.time_iso ?? nullableString(prevRequest.time_iso) ?? nullableString(prevSlots.time_iso);
  if (effectiveTimeIso && effectivePeriod === "afternoon") {
    const m = effectiveTimeIso.match(/^(\d{2}):(\d{2})$/);
    if (m) {
      const h = Number(m[1]);
      if (h >= 1 && h <= 5) effectiveTimeIso = `${String(h + 12).padStart(2, "0")}:${m[2]}`;
    }
  }
  return {
    service_text: current.service_text,
    service_search_terms: current.service_search_terms,
    staff_name: current.staff_name,
    staff_preference: current.staff_preference,
    date_text: current.date_text ?? nullableString(prevRequest.date_text),
    date_iso: current.date_iso ?? nullableString(prevRequest.date_iso) ?? nullableString(prevSlots.requested_date),
    time_text: current.time_text ?? nullableString(prevRequest.time_text),
    time_iso: effectiveTimeIso,
    time_period: effectivePeriod,
    appointment_reference: current.appointment_reference
      ?? (["cancel", "reschedule"].includes(prevIntent)
        ? (nullableString(prevRequest.appointment_reference) ?? nullableString(prevSlots.appointment_reference))
        : null),
    complaint_summary: current.complaint_summary,
    membership_topic: current.membership_topic,
  };
}

function wantsSameAsLast(text: string): boolean {
  const t = text.toLowerCase();
  return /跟上次一样|和上次一样|照上次|same as last|same as before|macam sebelum|sama macam sebelum/.test(t);
}

function confirmsSuggestedStylist(text: string): boolean {
  const c = compactCommand(text);
  return new Set([
    "是", "对", "可以", "好", "好的", "继续", "一样", "还是他", "还是她", "跟上次一样", "和上次一样",
    "yes", "same", "samestylist", "sameaslast", "continue", "ok", "okay",
    "ya", "sama", "teruskan",
  ]).has(c);
}

function explicitStaffPreference(text: string): "no_preference" | "specified" | null {
  const raw = String(text || "").trim().toLowerCase();
  if (!raw) return null;
  if (/(?:没有指定|沒指定|不指定|随便|隨便|谁都可以|誰都可以|谁都行|誰都行|都可以|都行|你安排|你决定|你決定|系统安排|系統安排|系统分配|系統分配|由系统安排|由系統安排|随机|隨機|任何理发师|任何理髮師|任何人|任意理发师|任意理髮師|不一定要|不一定找|换个人|換個人|换一个人|換一個人|其他理发师|其他理髮師|别的理发师|別的理髮師|any(?:one| stylist)|any stylist|no preference|no preferred stylist|system assign|system arrange|you choose|you decide|assign (?:me )?(?:someone|anyone)|random stylist|whoever is available|another stylist|other stylist|someone else|different stylist|mana[- ]?mana|sesiapa|awak pilih|anda pilih|sistem pilih|sistem aturkan|stylist lain|orang lain)/i.test(raw)) {
    return "no_preference";
  }
  if (/(?:指定|preferred stylist|prefer (?:a )?stylist|book with|want .* stylist|找.*(?:理发师|理髮師)|(?:nak|mahu)\s+(?:pilih|tempah)\s+(?:stylist|pendandan)|stylist\s+pilihan)/i.test(raw)) {
    return "specified";
  }
  return null;
}

function isGenericSpecifiedStylistRequest(textRaw: string): boolean {
  const text = String(textRaw || "").normalize("NFKC").trim();
  if (explicitStaffPreference(text) !== "specified") return false;
  return /^(?:(?:我|本人)?(?:要|想要|想|希望)?\s*)?(?:指定|选择|選擇|挑选|挑選)\s*(?:一位|一个|一個|个|個)?\s*(?:理发师|理髮師|发型师|髮型師|stylist|hairdresser|barber)?\s*[。.!！?？]*$/i.test(text)
    || /^(?:i\s+)?(?:want|would\s+like|prefer)\s+(?:to\s+)?(?:choose|specify|pick|select)?\s*(?:a\s+)?(?:specific|preferred)?\s*(?:stylist|hairdresser|barber)\s*[.!?]*$/i.test(text)
    || /^(?:saya\s+)?(?:nak|mahu)\s+(?:pilih|tempah)\s+(?:stylist|pendandan)(?:\s+pilihan)?\s*[.!?]*$/i.test(text);
}

function messageContainsStaffName(textRaw: string, staffNameRaw: string | null): boolean {
  const staffName = String(staffNameRaw || "").normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
  if (!staffName) return false;
  const text = String(textRaw || "").normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
  return text.includes(staffName);
}

function groundedAppointmentStaffPreference(
  proposed: IntentResult["entities"]["staff_preference"],
  hasStaffName: boolean,
  priorPreferenceRaw: unknown,
  currentPreferenceIsGrounded: boolean,
): IntentResult["entities"]["staff_preference"] {
  if (currentPreferenceIsGrounded || hasStaffName) return proposed;
  const prior = String(priorPreferenceRaw ?? "unknown");
  return ["specified", "no_preference"].includes(prior)
    ? prior as IntentResult["entities"]["staff_preference"]
    : "unknown";
}

function clearStylistSelectionForRevision(previousState: Json | null): Json | null {
  if (!previousState) return null;
  const slots = asJson(previousState.slots);
  return {
    ...previousState,
    state: "appointment_requires_info",
    active_intent: "appointment",
    pending_action: "collect_staff",
    slots: {
      ...slots,
      staff_name: null,
      staff_preference: "specified",
      booking_draft: null,
      appointment_tools: null,
      preference_staff_suggestion: null,
      staff_choice_mode: null,
      excluded_staff_name: null,
      offered_slots: [],
    },
  };
}


type BranchStaffMention = {
  id: string;
  name: string;
  employee_code: string | null;
  matched_by: "name" | "employee_code";
};

function compactEntityText(valueRaw: string): string {
  return String(valueRaw || "")
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[\s\p{P}\p{S}_]+/gu, "");
}

function containsStaffKey(messageRaw: string, candidateRaw: string, kind: "name" | "employee_code"): boolean {
  const messageKey = compactEntityText(messageRaw);
  const candidateKey = compactEntityText(candidateRaw);
  if (!candidateKey) return false;
  const latinOnly = /^[a-z0-9]+$/i.test(candidateKey);
  // Very short Latin names (for example "ai" or "jo") can occur inside ordinary
  // words. Leave those to the LLM / explicit staff resolver instead of creating a
  // deterministic false positive. Chinese names remain useful from two chars.
  if (kind === "name" && latinOnly && candidateKey.length < 3) return false;
  if (kind === "name" && !latinOnly && candidateKey.length < 2) return false;
  if (kind === "employee_code" && candidateKey.length < 3) return false;
  return messageKey.includes(candidateKey);
}

async function detectBranchStaffMention(
  supabase: any,
  organizationId: string,
  storeId: string,
  messageRaw: string,
): Promise<{ mention: BranchStaffMention | null; error: string | null }> {
  const text = String(messageRaw || "").trim();
  if (!text) return { mention: null, error: null };

  const { data: links, error: linkError } = await supabase
    .from("employee_stores")
    .select("employee_id")
    .eq("organization_id", organizationId)
    .eq("store_id", storeId)
    .eq("status", "active")
    .limit(500);
  if (linkError) return { mention: null, error: `employee_stores:${linkError.message}` };

  const employeeIds = Array.from(new Set((links ?? [])
    .map((row: Json) => nullableString(row.employee_id))
    .filter((id: string | null): id is string => Boolean(id))));
  if (!employeeIds.length) return { mention: null, error: null };

  const { data: employees, error: employeeError } = await supabase
    .from("employees")
    .select("id,name,employee_code")
    .eq("organization_id", organizationId)
    .eq("employment_status", "active")
    .in("id", employeeIds)
    .limit(500);
  if (employeeError) return { mention: null, error: `employees:${employeeError.message}` };

  const matches: Array<BranchStaffMention & { key_length: number }> = [];
  for (const rowRaw of employees ?? []) {
    const row = asJson(rowRaw);
    const id = nullableString(row.id);
    const name = nullableString(row.name);
    const code = nullableString(row.employee_code);
    if (!id || !name) continue;
    if (containsStaffKey(text, name, "name")) {
      matches.push({ id, name, employee_code: code, matched_by: "name", key_length: compactEntityText(name).length });
      continue;
    }
    if (code && containsStaffKey(text, code, "employee_code")) {
      matches.push({ id, name, employee_code: code, matched_by: "employee_code", key_length: compactEntityText(code).length });
    }
  }
  if (!matches.length) return { mention: null, error: null };
  matches.sort((a, b) => b.key_length - a.key_length || a.name.localeCompare(b.name));
  const top = matches[0];
  return {
    mention: { id: top.id, name: top.name, employee_code: top.employee_code, matched_by: top.matched_by },
    error: null,
  };
}

type DeterministicServiceHint = {
  service_text: string;
  service_search_terms: string[];
  reason: string;
};

function deterministicServiceHint(textRaw: string): DeterministicServiceHint | null {
  const text = String(textRaw || "").normalize("NFKC");
  if (!text.trim()) return null;
  const rules: Array<[RegExp, string, string[], string]> = [
    [/(?:hair\s*(?:color|colour|coloring|colouring|dye)|dye\s*(?:my\s*)?hair|染(?:头|頭)?(?:发|髮)|染色)/i,
      "染发", ["染发", "染头发", "染髮", "染頭髮", "hair coloring"], "hair_coloring"],
    [/(?:haircut|hair\s*cut|cut\s*(?:my\s*)?hair|剪(?:头|頭)?(?:发|髮)|理(?:头|頭)?(?:发|髮))/i,
      "剪发", ["剪发", "剪头发", "剪髮", "haircut", "hair cut"], "haircut"],
    [/(?:perm|烫(?:头|頭)?(?:发|髮)|燙(?:頭)?髮)/i,
      "烫发", ["烫发", "烫头发", "燙髮", "perm", "perming"], "perm"],
    [/(?:rebond(?:ing)?|hair\s*straighten(?:ing)?|straighten\s*(?:my\s*)?hair|拉直|离子烫|離子燙)/i,
      "hair straightening", ["hair straightening", "rebonding", "straighten", "拉直", "离子烫"], "straightening"],
    [/(?:highlight(?:s)?|挑染)/i,
      "highlights", ["highlights", "highlight", "挑染", "hair highlights"], "highlights"],
    [/(?:bleach(?:ing)?|漂(?:头|頭)?(?:发|髮))/i,
      "漂发", ["漂发", "漂头发", "漂髮", "bleach", "hair bleaching"], "bleach"],
    [/(?:scalp\s*(?:treatment|care)?|头皮护理|頭皮護理)/i,
      "scalp treatment", ["scalp treatment", "scalp care", "头皮护理", "頭皮護理", "scalp"], "scalp"],
    [/(?:hair\s*treatment|treatment|护理|護理)/i,
      "护理", ["护理", "護理", "hair treatment", "treatment", "hair care"], "treatment"],
    [/(?:hair\s*wash|wash\s*(?:my\s*)?hair|shampoo|洗(?:头|頭)?(?:发|髮)|洗头|洗頭)/i,
      "洗发", ["洗发", "洗头", "洗髮", "hair wash", "shampoo"], "wash"],
    [/(?:blow\s*dry|blowdry|吹(?:头|頭)?(?:发|髮)|吹头|吹頭)/i,
      "blow dry", ["blow dry", "blowdry", "吹头发", "吹頭髮"], "blow_dry"],
  ];
  for (const [pattern, serviceText, terms, reason] of rules) {
    if (pattern.test(text)) return { service_text: serviceText, service_search_terms: terms.slice(0, 5), reason };
  }
  return null;
}


function hasExplicitAppointmentDate(textRaw: string): boolean {
  const text = String(textRaw || "").normalize("NFKC").trim();
  if (!text) return false;
  return /(?:\b(?:today|tomorrow|day\s+after\s+tomorrow|tonight|now)\b|今天|今日|明天|后天|後天|今晚|现在|現在|马上|馬上|\b(?:hari\s+ini|esok|lusa|sekarang)\b|\b(?:mon(?:day)?|tue(?:sday)?|wed(?:nesday)?|thu(?:rsday)?|fri(?:day)?|sat(?:urday)?|sun(?:day)?)\b|星期[一二三四五六日天]|周[一二三四五六日天]|週[一二三四五六日天]|\b\d{4}[-\/.]\d{1,2}[-\/.]\d{1,2}\b|\b\d{1,2}[-\/.]\d{1,2}(?:[-\/.]\d{2,4})?\b|\d{1,2}\s*月\s*\d{1,2}\s*(?:日|号|號)|\d{1,2}\s*(?:号|號))/i.test(text);
}

type DeterministicAppointmentDateHint = {
  date_text: string;
  date_iso: string;
  reason: string;
};

function deterministicAppointmentDateHint(
  textRaw: string,
  currentLocalDateTime: string,
): DeterministicAppointmentDateHint | null {
  const text = String(textRaw || "").normalize("NFKC").trim();
  if (!text) return null;

  // Relative dates are business-critical. Never ask the LLM to perform this
  // arithmetic and never let a prior appointment date win if the customer says
  // a new relative date in the latest turn. Order matters because
  // "day after tomorrow" contains "tomorrow".
  const dayAfter = text.match(/day\s+after\s+tomorrow|后天|後天|\blusa\b/i);
  if (dayAfter) {
    return { date_text: dayAfter[0], date_iso: isoDateAddDays(currentLocalDateTime, 2), reason: "relative_day_after_tomorrow" };
  }
  const tomorrow = text.match(/\btomorrow\b|明天|\besok\b/i);
  if (tomorrow) {
    return { date_text: tomorrow[0], date_iso: isoDateAddDays(currentLocalDateTime, 1), reason: "relative_tomorrow" };
  }
  const today = text.match(/\btoday\b|\btonight\b|\bnow\b|今天|今日|今晚|现在|現在|马上|馬上|\bhari\s+ini\b|\bsekarang\b/i);
  if (today) {
    return { date_text: today[0], date_iso: isoDateAddDays(currentLocalDateTime, 0), reason: "relative_today" };
  }

  // Fully-qualified numeric dates are deterministic as well. Keep the accepted
  // forms intentionally strict; ambiguous day/month-only expressions still go
  // through the normal parser/clarification path.
  const iso = text.match(/\b(20\d{2})[-\/.](\d{1,2})[-\/.](\d{1,2})\b/);
  if (iso) {
    const [, y, mo, d] = iso;
    return {
      date_text: iso[0],
      date_iso: `${y}-${String(Number(mo)).padStart(2, "0")}-${String(Number(d)).padStart(2, "0")}`,
      reason: "explicit_iso_date",
    };
  }
  const dmy = text.match(/\b(\d{1,2})[-\/.](\d{1,2})[-\/.](20\d{2})\b/);
  if (dmy) {
    const [, d, mo, y] = dmy;
    return {
      date_text: dmy[0],
      date_iso: `${y}-${String(Number(mo)).padStart(2, "0")}-${String(Number(d)).padStart(2, "0")}`,
      reason: "explicit_dmy_date",
    };
  }
  return null;
}

function isFreshBookingRestart(textRaw: string): boolean {
  const text = String(textRaw || "").normalize("NFKC").trim();
  if (!text) return false;
  const startsBooking = /(?:我要|我想|想要|麻烦|麻煩|帮我|幫我)?\s*(?:预约|預約|订个|訂個|约个|約個)|\b(?:i\s+(?:want|would\s+like)\s+to\s+)?(?:book|reserve)\b|\b(?:make|book)\s+(?:an?\s+)?appointment\b|\b(?:nak|mahu)\s+(?:tempah|buat\s+janji\s*temu)\b/i.test(text);
  if (!startsBooking) return false;
  const modifiesExisting = /(?:改|修改|调整|調整|换|換|更改|取消|确认|確認|确定|確定|confirm|reschedul|\bchange\b|\bmove\b|\bcancel\b|another\s+stylist|随机|隨機|\brandom\b)/i.test(text);
  return !modifiesExisting;
}

function displayDate(iso: string | null): string {
  if (!iso || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso ?? "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

function displayTime(hhmm: string): string {
  const match = hhmm.match(/^(\d{2}):(\d{2})$/);
  if (!match) return hhmm;
  const h = Number(match[1]);
  const minute = match[2];
  const suffix = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 || 12;
  return `${h12}:${minute} ${suffix}`;
}

function appointmentTimeAcknowledgement(
  lang: "zh" | "en" | "ms",
  entities: IntentResult["entities"],
): string | null {
  const hhmm = nullableString(entities.time_iso);
  if (!hhmm) return null;
  const match = hhmm.match(/^(\d{2}):(\d{2})$/);
  if (!match) return hhmm;
  const hour = Number(match[1]);
  const minute = match[2];
  const hour12 = hour % 12 || 12;

  if (lang === "zh") {
    const raw = nullableString(entities.time_text);
    if (raw && /[\u3400-\u9fff]/.test(raw)) return raw;
    const period = hour < 12 ? "上午" : hour < 18 ? "下午" : "晚上";
    return `${period}${hour12}点${minute === "00" ? "" : minute === "30" ? "半" : `${Number(minute)}分`}`;
  }
  if (lang === "ms") {
    const period = hour < 12 ? "pagi" : hour < 18 ? "petang" : "malam";
    return `pukul ${hour12}${minute === "00" ? "" : `:${minute}`} ${period}`;
  }
  return displayTime(hhmm);
}

function appointmentKnownSlotSummary(
  lang: "zh" | "en" | "ms",
  entities: IntentResult["entities"],
): string {
  const parts: string[] = [];
  const service = nullableString(entities.service_text);
  const rawDate = nullableString(entities.date_text);
  const date = rawDate && rawDate.length <= 32 ? rawDate : displayDate(nullableString(entities.date_iso));
  const time = appointmentTimeAcknowledgement(lang, entities);
  if (service) parts.push(service);
  if (date) parts.push(date);
  if (time) parts.push(time);
  return parts.join(lang === "zh" ? "、" : ", ");
}

function replyLanguage(language: IntentResult["language"], latestText: string): "zh" | "en" | "ms" {
  const direct = detectLanguageDeterministic(latestText);
  if (isLanguageNeutralTemporalReply(latestText) && ["zh", "en", "ms"].includes(language)) {
    return language as "zh" | "en" | "ms";
  }
  if (["zh", "en", "ms"].includes(direct)) return direct as "zh" | "en" | "ms";
  if (["zh", "en", "ms"].includes(language)) return language as "zh" | "en" | "ms";
  return "en";
}

function candidateNames(value: unknown, key: "service" | "staff"): string[] {
  if (!Array.isArray(value)) return [];
  const out: string[] = [];
  for (const raw of value) {
    const item = asJson(raw);
    const name = nullableString(item.name);
    if (name && !out.includes(name)) out.push(name);
    if (out.length >= 4) break;
  }
  return out;
}

function buildAppointmentReply(
  language: IntentResult["language"],
  latestText: string,
  entities: IntentResult["entities"],
  pipelineStage: string,
  appointmentTools: Json | null,
  customerSummary: Json,
  appointmentDraft: Json | null,
  maxSlots: number,
): ReplyPlan {
  const lang = replyLanguage(language, latestText);
  const tools = asJson(appointmentTools);
  const serviceResolution = asJson(tools.resolve_service);
  const staffResolution = asJson(tools.resolve_staff);
  const availability = asJson(tools.check_availability);
  const systemAssignment = asJson(tools.system_assignment);
  const systemAssignmentStatus = String(systemAssignment.assignment_status ?? "");
  const service = asJson(serviceResolution.service);
  const staff = asJson(staffResolution.staff);
  const resolvedServiceName = displayServiceName(nullableString(service.name), lang, entities.service_text);
  const resolvedStaffName = nullableString(staff.name) ?? entities.staff_name ?? "";
  const date = displayDate(entities.date_iso);

  if (pipelineStage === "appointment_requires_info") {
    const missing = Array.isArray(tools.missing_fields) ? (tools.missing_fields as unknown[]).map(String) : [];

    // v13.6.10.56 — acknowledge multi-person wording instead of ignoring it and
    // repeating the same slot question. SalonOS still confirms each appointment
    // safely, but the conversation should first clarify what the customer means.
    if (/(?:两位|兩位|2位|两个(?:人|顾客)|兩個(?:人|顧客)|two\s+(?:people|persons|customers)|2\s+(?:people|persons|customers))/i.test(latestText)) {
      const text = lang === "zh"
        ? "可以，我先确认一下：是两位顾客都要预约吗？请告诉我两位分别要做什么项目；如果项目一样，也可以直接说「两位都染发」。"
        : lang === "ms"
          ? "Boleh. Saya sahkan dulu: adakah tempahan ini untuk dua pelanggan? Beritahu servis untuk setiap orang; jika sama, anda boleh cakap kedua-duanya servis yang sama."
          : "Sure. Just to confirm: is this booking for two customers? Tell me the service for each person; if it is the same, you can say both want the same service.";
      return { send: true, kind: "clarify_party_size", text, state: "appointment_requires_info", pendingAction: "clarify_multi_customer_booking", offeredSlots: [], selectedTime: null, reason: null };
    }
    const field = missing[0] ?? "service";
    const intel = asJson(customerSummary.customer_intelligence);
    const dominantName = nullableString(asJson(intel.dominant_stylist).name);
    const completedCount = Number(intel.completed_visit_count ?? 0);
    const acknowledgedTime = appointmentTimeAcknowledgement(lang, entities);
    if (lang === "zh") {
      const contextService = acknowledgedTime
        ? `好的，${acknowledgedTime}。`
        : entities.service_text ? `好的，${entities.service_text}。` : "可以。";
      const knownSlots = appointmentKnownSlotSummary(lang, entities);
      const preferenceQuestion = `${knownSlots ? `好的，目前是${knownSlots}。` : "好的。"}请问你想指定理发师，还是由系统安排有空且符合技能的理发师？`;
      const text = field === "service" ? "可以，想做什么项目呢？例如剪发、染发或护理。"
        : field === "date" ? `${contextService}你想约今天、明天还是其他日期？`
        : field === "staff_preference"
          ? (completedCount > 0 && dominantName
            ? `${preferenceQuestion}你之前主要找 ${dominantName}；如果仍要他/她，可回复「继续」，也可以直接发其他理发师名字；不指定的话回复「系统安排」。`
            : `${preferenceQuestion}回复「指定」或直接发理发师名字；不指定的话回复「系统安排」。`)
          : field === "staff"
            ? "好的，请告诉我想指定哪位理发师的名字。"
            : "好的，请告诉我还想调整哪项预约资料。";
      return { send: true, kind: "collect_missing", text, state: "appointment_requires_info", pendingAction: `collect_${field}`, offeredSlots: [], selectedTime: null, reason: null };
    }
    if (lang === "ms") {
      const context = acknowledgedTime ? `Baik, ${acknowledgedTime}. ` : "Boleh. ";
      const knownSlots = appointmentKnownSlotSummary(lang, entities);
      const preferenceQuestion = `${knownSlots ? `Baik, setakat ini: ${knownSlots}. ` : "Baik. "}Anda mahu pilih stylist tertentu, atau biar sistem aturkan stylist yang berkemahiran dan available?`;
      const text = field === "service" ? "Boleh. Servis apa yang anda ingin tempah?"
        : field === "date" ? `${context}Anda mahu tempah hari ini, esok atau tarikh lain?`
        : field === "staff_preference"
          ? (completedCount > 0 && dominantName
            ? `${preferenceQuestion} Sebelum ini anda banyak bersama ${dominantName}; balas "teruskan" untuk stylist yang sama, hantar nama stylist lain, atau balas "sistem aturkan" jika tiada pilihan.`
            : `${preferenceQuestion} Balas "pilih stylist" atau terus hantar nama stylist; jika tiada pilihan, balas "sistem aturkan".`)
          : field === "staff"
            ? "Baik, beritahu nama stylist yang anda mahu."
            : "Baik, beritahu maklumat tempahan yang mahu anda ubah.";
      return { send: true, kind: "collect_missing", text, state: "appointment_requires_info", pendingAction: `collect_${field}`, offeredSlots: [], selectedTime: null, reason: null };
    }
    const contextService = acknowledgedTime
      ? `Got it — ${acknowledgedTime}. `
      : entities.service_text ? `Got it — ${entities.service_text}. ` : "Sure. ";
    const knownSlots = appointmentKnownSlotSummary(lang, entities);
    const preferenceQuestion = `${knownSlots ? `Got it — so far I have ${knownSlots}. ` : "Sure. "}Would you like to choose a stylist, or should the system assign someone qualified and available?`;
    const text = field === "service" ? "Sure — what service would you like? For example, haircut, coloring, or treatment."
      : field === "date" ? `${contextService}Which day works for you? You can simply say today, tomorrow, or a specific date.`
      : field === "staff_preference"
        ? (completedCount > 0 && dominantName
          ? `${preferenceQuestion} You previously saw ${dominantName}; reply "continue" for the same stylist, send another stylist's name, or reply "system assign" if you have no preference.`
          : `${preferenceQuestion} Reply "choose stylist" or send the stylist's name; if you have no preference, reply "system assign".`)
        : field === "staff"
          ? "Sure — tell me the stylist's name you want."
          : "Sure — tell me which booking detail you want to change.";
    return { send: true, kind: "collect_missing", text, state: "appointment_requires_info", pendingAction: `collect_${field}`, offeredSlots: [], selectedTime: null, reason: null };
  }

  const serviceStatus = String(serviceResolution.resolution_status ?? "");
  if (serviceStatus && serviceStatus !== "matched") {
    const names = candidateNames(serviceResolution.candidates, "service");
    const requested = entities.service_text ?? "that service";
    let text: string;
    if (serviceStatus === "ambiguous" && names.length) {
      const choices = names.join(", ");
      text = lang === "zh" ? `我找到几个可能的项目：${choices}。请问您要哪一个？`
        : lang === "ms" ? `Saya jumpa beberapa servis yang mungkin: ${choices}. Yang mana satu anda mahu?`
        : `I found a few possible services: ${choices}. Which one would you like?`;
    } else if (names.length) {
      const choices = names.join(", ");
      text = lang === "zh" ? `我暂时无法准确匹配「${requested}」。比较接近的项目有：${choices}。请告诉我您要哪一个。`
        : lang === "ms" ? `Saya belum dapat padankan "${requested}" dengan tepat. Pilihan terdekat ialah: ${choices}. Beritahu saya yang mana satu.`
        : `I couldn't match "${requested}" exactly. The closest services are: ${choices}. Tell me which one you want.`;
    } else {
      text = lang === "zh" ? `我暂时找不到与「${requested}」对应的门店项目。请告诉我项目名称，例如剪发、染发或护理。`
        : lang === "ms" ? `Saya belum jumpa servis kedai yang sepadan dengan "${requested}". Sila beritahu nama servis, contohnya haircut, hair coloring atau treatment.`
        : `I couldn't match "${requested}" to a store service. Please tell me the service name, for example haircut, hair coloring, or treatment.`;
    }
    return { send: true, kind: "clarify_service", text, state: "appointment_needs_resolution", pendingAction: "clarify_service", offeredSlots: [], selectedTime: null, reason: serviceStatus };
  }

  if (pipelineStage === "appointment_staff_alternatives") {
    const alternatives = Array.isArray(tools.staff_alternatives) ? tools.staff_alternatives as unknown[] : [];
    const names = alternatives.map((x) => nullableString(asJson(x).name)).filter((x): x is string => Boolean(x)).slice(0, 6);
    const exactTime = entities.time_iso ? displayTime(entities.time_iso) : null;
    const when = exactTime ? `${date} at ${exactTime}` : `${date}${entities.time_period !== "unspecified" ? ` in the ${entities.time_period}` : ""}`;
    const excluded = nullableString(tools.excluded_staff_name);
    const prefix = excluded ? `I checked other qualified stylists instead of ${excluded}. ` : "";
    const text = names.length === 1
      ? `${prefix}${names[0]} is the only other qualified stylist I found available for ${resolvedServiceName} on ${when}. Reply "${names[0]}" to choose them, or tell me another time/date.`
      : `${prefix}These qualified stylists are available for ${resolvedServiceName} on ${when}: ${names.join(", ")}. Reply with a stylist name, or say "random" and I’ll assign one of them.`;
    return { send: true, kind: "staff_alternatives", text, state: "appointment_staff_alternatives", pendingAction: "choose_alternative_staff_or_random", offeredSlots: [], selectedTime: entities.time_iso, reason: null };
  }

  if (pipelineStage === "appointment_no_alternative_staff") {
    const excluded = nullableString(tools.excluded_staff_name);
    const exactTime = entities.time_iso ? displayTime(entities.time_iso) : null;
    const when = exactTime ? `${date} at ${exactTime}` : `${date}${entities.time_period !== "unspecified" ? ` in the ${entities.time_period}` : ""}`;
    const text = excluded
      ? `I checked the other qualified stylists too, but nobody else is available for ${resolvedServiceName} on ${when}. Tell me another time/date, or tell me a specific stylist you want me to check.`
      : `I couldn’t find a qualified stylist available for ${resolvedServiceName} on ${when}. Tell me another time/date and I’ll check again.`;
    return { send: true, kind: "no_alternative_staff", text, state: "awaiting_alternative_time", pendingAction: "choose_alternative_time_or_staff", offeredSlots: [], selectedTime: null, reason: "no_alternative_staff" };
  }

  const staffSkillValidation = asJson(tools.staff_skill_validation);
  const staffSkillStatus = String(staffSkillValidation.status ?? "");
  if (staffSkillStatus === "not_qualified") {
    const missing = Array.isArray(staffSkillValidation.missing_skills)
      ? (staffSkillValidation.missing_skills as unknown[]).map((x) => nullableString(asJson(x).skill_code)).filter(Boolean).join(", ")
      : "the required skills";
    const text = `${resolvedStaffName || "This stylist"} is not configured with the required skills for ${resolvedServiceName}${missing ? ` (${missing})` : ""}. I won’t book them blindly. Say "another stylist" to see qualified staff, say "random" to let me assign one, or choose another service.`;
    return { send: true, kind: "staff_not_qualified", text, state: "appointment_staff_not_qualified", pendingAction: "choose_qualified_staff_or_service", offeredSlots: [], selectedTime: null, reason: "staff_not_qualified" };
  }
  if (staffSkillStatus === "service_skill_unconfigured") {
    const text = `The service ${resolvedServiceName} has not been linked to required staff skills yet, so I won’t book a specific stylist blindly. Store staff needs to configure the service skills first.`;
    return { send: true, kind: "service_skill_unconfigured", text, state: "human_check_required", pendingAction: "human_skill_configuration_required", offeredSlots: [], selectedTime: null, reason: "service_skill_unconfigured" };
  }
  if (staffSkillStatus === "validation_error") {
    const text = `I couldn’t safely verify whether ${resolvedStaffName || "that stylist"} is qualified for ${resolvedServiceName}. I won’t create the booking until store staff verifies the skill setup.`;
    return { send: true, kind: "staff_skill_validation_error", text, state: "human_check_required", pendingAction: "human_skill_check", offeredSlots: [], selectedTime: null, reason: "staff_skill_validation_error" };
  }

  if (systemAssignmentStatus === "needs_time_selection") {
    const slots = Array.isArray(systemAssignment.slots) ? systemAssignment.slots as unknown[] : [];
    const offered = slots.map((x) => nullableString(asJson(x).time)).filter((x): x is string => Boolean(x)).slice(0, Math.max(1, Math.min(maxSlots, 10)));
    const labels = offered.map(displayTime);
    const text = labels.length
      ? `I found qualified stylists who are free on ${date}. Available times include ${labels.join(", ")}. Choose a time and I’ll assign one of the qualified available stylists.`
      : `I found qualified stylists for ${resolvedServiceName}, but I still need a specific time before I assign one. What time would you like?`;
    return { send: true, kind: "system_assignment_time_options", text, state: "appointment_system_time_options", pendingAction: "select_appointment_time_for_system_assignment", offeredSlots: offered, selectedTime: null, reason: null };
  }

  if (systemAssignmentStatus === "no_qualified_staff") {
    const required = Array.isArray(systemAssignment.required_skills)
      ? (systemAssignment.required_skills as unknown[]).map((x) => nullableString(asJson(x).display_name_en)).filter(Boolean).join(", ") : "the required skills";
    const text = `I couldn’t find an active stylist in this branch who meets ${required || "the required skill requirements"} for ${resolvedServiceName}. Store staff will need to help with this booking or suggest another service.`;
    return { send: true, kind: "no_qualified_staff", text, state: "human_check_required", pendingAction: "human_or_alternative_service", offeredSlots: [], selectedTime: null, reason: systemAssignmentStatus };
  }

  if (systemAssignmentStatus === "service_skill_unconfigured") {
    const text = `This service has not been linked to its required staff skills yet, so I won’t assign a stylist blindly. Store staff needs to configure the service skills before automatic assignment can be used.`;
    return { send: true, kind: "service_skill_unconfigured", text, state: "human_check_required", pendingAction: "human_skill_configuration_required", offeredSlots: [], selectedTime: null, reason: systemAssignmentStatus };
  }

  if (systemAssignmentStatus === "schedule_unconfigured") {
    const text = `Qualified stylists exist for ${resolvedServiceName}, but their schedule is not fully configured for ${date}. Store staff needs to verify the booking.`;
    return { send: true, kind: "schedule_unconfigured", text, state: "human_check_required", pendingAction: "human_schedule_check", offeredSlots: [], selectedTime: null, reason: systemAssignmentStatus };
  }

  if (systemAssignmentStatus === "no_slots") {
    const text = `I found stylists with the required skills for ${resolvedServiceName}, but none of them are free on ${date} in that period. Please give me another time or date.`;
    return { send: true, kind: "system_no_slots", text, state: "awaiting_alternative_time", pendingAction: "choose_alternative_time", offeredSlots: [], selectedTime: null, reason: systemAssignmentStatus };
  }

  const staffStatus = String(staffResolution.resolution_status ?? "");
  if (staffStatus && staffStatus !== "matched") {
    const names = candidateNames(staffResolution.candidates, "staff");
    const choices = names.length ? names.join(", ") : entities.staff_name ?? "this stylist";
    const text = lang === "zh" ? `我暂时无法唯一确认理发师。可能是：${choices}。请告诉我您要哪一位。`
      : lang === "ms" ? `Saya belum dapat pastikan stylist dengan tepat. Pilihan yang mungkin: ${choices}. Sila pilih seorang.`
      : `I couldn't uniquely identify the stylist. Possible matches: ${choices}. Please choose one.`;
    return { send: true, kind: "clarify_staff", text, state: "appointment_needs_resolution", pendingAction: "clarify_staff", offeredSlots: [], selectedTime: null, reason: staffStatus };
  }

  const availabilityStatus = String(availability.availability_status ?? "");
  if (availabilityStatus === "schedule_unconfigured" || availabilityStatus === "schedule_invalid") {
    const text = lang === "zh" ? `我暂时无法确认 ${resolvedStaffName || "这位理发师"} 在 ${date || "当天"} 的班表，我已经把这项情况留给店员确认。`
      : lang === "ms" ? `Saya belum dapat mengesahkan jadual ${resolvedStaffName || "stylist"} pada ${date || "tarikh itu"}. Saya akan serahkan kepada staf untuk semakan.`
      : `I can't confirm ${resolvedStaffName || "the stylist"}'s schedule for ${date || "that date"} yet. I'll leave this for staff verification.`;
    return { send: true, kind: "schedule_unconfigured", text, state: "human_check_required", pendingAction: "human_schedule_check", offeredSlots: [], selectedTime: null, reason: availabilityStatus };
  }
  if (availabilityStatus === "employee_off") {
    const text = lang === "zh" ? `${resolvedStaffName} 在 ${date} 当天没有排班。您可以换其他理发师、改日期，或说「随机」让我安排合资格且有空的人。`
      : lang === "ms" ? `${resolvedStaffName} tidak bertugas pada ${date}. Anda boleh pilih stylist lain, tarikh lain, atau minta saya tetapkan stylist yang layak secara rawak.`
      : `${resolvedStaffName} is not scheduled on ${date}. You can ask for another stylist, choose another date, or say "random" and I’ll assign a qualified available stylist.`;
    return { send: true, kind: "employee_off", text, state: "awaiting_alternative_date", pendingAction: "choose_alternative_date", offeredSlots: [], selectedTime: null, reason: availabilityStatus };
  }

  const slotRows = Array.isArray(availability.slots) ? availability.slots as unknown[] : [];
  const times = slotRows.map((raw) => nullableString(asJson(raw).time)).filter((x): x is string => Boolean(x));
  if (availabilityStatus === "available" && times.length) {
    const exact = entities.time_iso && times.includes(entities.time_iso) ? entities.time_iso : null;
    if (exact) {
      const draft = asJson(appointmentDraft);
      if (draft.ok === true) {
        const nextField = nullableString(draft.next_profile_field);
        if (!nextField && String(draft.status ?? "") === "pending_confirmation") {
          return {
            send: true, kind: "appointment_draft_summary", text: draftSummaryText(draft, lang),
            state: "awaiting_booking_confirmation", pendingAction: "confirm_appointment_draft",
            offeredSlots: times, selectedTime: exact, reason: null,
          };
        }
        if (nextField) {
          const customer = asJson(draft.customer);
          const intro = lang === "zh" ? `${resolvedStaffName} 在 ${date} ${displayTime(exact)} 目前可以预约 ${resolvedServiceName}。`
            : lang === "ms" ? `${resolvedStaffName} tersedia pada ${date}, ${displayTime(exact)} untuk ${resolvedServiceName}. `
            : systemAssignmentStatus === "assigned"
              ? `I matched you with ${resolvedStaffName}, who has the required skills and is available on ${date} at ${displayTime(exact)} for ${resolvedServiceName}. `
              : `${resolvedStaffName} is currently available on ${date} at ${displayTime(exact)} for ${resolvedServiceName}. `;
          return {
            send: true, kind: `collect_${nextField}`, text: intro + profileQuestion(nextField, lang, nullableString(customer.name), false),
            state: `collecting_customer_${nextField}`, pendingAction: `collect_customer_${nextField}`,
            offeredSlots: times, selectedTime: exact, reason: null,
          };
        }
      }
      const customerStatus = String(customerSummary.customer_status ?? "unknown");
      const customerName = nullableString(customerSummary.name);
      const tail = customerStatus === "new_lead" && !customerName
        ? (lang === "zh" ? "为了下一步建立预约草稿，请问怎么称呼您？" : lang === "ms" ? "Untuk sediakan draf tempahan, boleh saya tahu nama anda?" : "To prepare the booking draft, may I have your name?")
        : (lang === "zh" ? "我已经记住这个时间，下一步会进入预约资料确认。" : lang === "ms" ? "Saya sudah simpan pilihan masa ini. Seterusnya kita akan semak butiran tempahan." : "I've saved this time choice. Next we'll verify the booking details.");
      const text = lang === "zh" ? `${resolvedStaffName} 在 ${date} ${displayTime(exact)} 目前可以预约 ${resolvedServiceName}。${tail}`
        : lang === "ms" ? `${resolvedStaffName} tersedia pada ${date}, ${displayTime(exact)} untuk ${resolvedServiceName}. ${tail}`
        : systemAssignmentStatus === "assigned"
          ? `I matched you with ${resolvedStaffName}, who has the required skills and is available on ${date} at ${displayTime(exact)} for ${resolvedServiceName}. ${tail}`
          : `${resolvedStaffName} is currently available on ${date} at ${displayTime(exact)} for ${resolvedServiceName}. ${tail}`;
      return { send: true, kind: "time_selected", text, state: "appointment_time_selected", pendingAction: "collect_customer_profile_or_create_draft", offeredSlots: times, selectedTime: exact, reason: null };
    }
    const offered = times.slice(0, Math.max(1, Math.min(maxSlots, 10)));
    const labels = offered.map(displayTime);
    const text = lang === "zh" ? `${resolvedStaffName} 在 ${date} 目前还有这些时间可以做 ${resolvedServiceName}：${labels.join("、")}。您比较方便哪一个？`
      : lang === "ms" ? `${resolvedStaffName} masih ada slot untuk ${resolvedServiceName} pada ${date}: ${labels.join(", ")}. Masa mana yang sesuai untuk anda?`
      : `${resolvedStaffName} currently has these slots for ${resolvedServiceName} on ${date}: ${labels.join(", ")}. Which time works best for you?`;
    return { send: true, kind: "availability_options", text, state: "awaiting_slot_selection", pendingAction: "select_appointment_time", offeredSlots: offered, selectedTime: null, reason: null };
  }

  if (["no_slots", "outside_shift"].includes(availabilityStatus)) {
    const text = lang === "zh" ? `${resolvedStaffName} 在 ${date}${entities.time_period !== "unspecified" ? "这个时段" : ""}暂时没有适合 ${resolvedServiceName} 的空位。您可以说「换个理发师」查看同一时间其他合资格员工，回复「随机」让我安排，或给我其他时间/日期。`
      : lang === "ms" ? `Tiada slot sesuai untuk ${resolvedServiceName} dengan ${resolvedStaffName} pada ${date}. Anda boleh minta stylist lain pada masa yang sama, minta tugasan rawak, atau beri masa/tarikh lain.`
      : `There are no suitable slots for ${resolvedServiceName} with ${resolvedStaffName} on ${date} in that period. Say "another stylist" to check other qualified staff at the same time, say "random" to let me assign one, or give me another time/date.`;
    return { send: true, kind: "no_slots", text, state: "awaiting_alternative_time", pendingAction: "choose_alternative_time", offeredSlots: [], selectedTime: null, reason: availabilityStatus };
  }

  return { send: false, kind: "suppressed", text: "", state: pipelineStage, pendingAction: "no_safe_reply", offeredSlots: [], selectedTime: null, reason: availabilityStatus || "unsupported_appointment_state" };
}

async function sendMetaTextMessage(
  phoneNumberId: string,
  accessToken: string,
  graphVersion: string,
  to: string,
  bodyText: string,
): Promise<{ metaMessageId: string; response: Json }> {
  const version = /^v\d+\.\d+$/.test(graphVersion) ? graphVersion : "v26.0";
  const response = await fetch(`https://graph.facebook.com/${version}/${encodeURIComponent(phoneNumberId)}/messages`, {
    method: "POST",
    headers: {
      "authorization": `Bearer ${accessToken}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { preview_url: false, body: bodyText.slice(0, 4000) },
    }),
  });
  let payload: Json = {};
  try { payload = await response.json() as Json; } catch { payload = {}; }
  if (!response.ok) {
    const errorObj = asJson(payload.error);
    const msg = String(errorObj.message ?? `HTTP ${response.status}`);
    const code = nullableString(errorObj.code);
    const subcode = nullableString(errorObj.error_subcode);
    const type = nullableString(errorObj.type);
    const trace = nullableString(errorObj.fbtrace_id);
    const meta = [
      code ? `code=${code}` : null,
      subcode ? `subcode=${subcode}` : null,
      type ? `type=${type}` : null,
      trace ? `trace=${trace}` : null,
      `http=${response.status}`,
    ].filter(Boolean).join(",");
    throw new Error(`meta_send_error:${msg}${meta ? ` [${meta}]` : ""}`);
  }
  const messages = Array.isArray(payload.messages) ? payload.messages as unknown[] : [];
  const first = asJson(messages[0]);
  const id = nullableString(first.id);
  if (!id) throw new Error("meta_send_error:missing_message_id");
  return { metaMessageId: id, response: payload };
}


async function deliverAutoReply(
  supabase: any,
  args: {
    organizationId: string;
    storeId: string;
    connectionId: string;
    conversationId: string;
    inboundMessageId: string;
    queueId: string;
    customerPhone: string;
    text: string;
    kind: string;
    stateBefore: string;
    stateAfter: string;
    context?: Json;
  },
): Promise<DeliveryResult> {
  const { data: sendConfig, error: sendConfigError } = await supabase
    .from("whatsapp_store_configs")
    .select("access_token,graph_api_version,auto_reply_enabled")
    .eq("organization_id", args.organizationId)
    .eq("store_id", args.storeId)
    .eq("connection_id", args.connectionId)
    .maybeSingle();
  if (sendConfigError) throw new Error(`whatsapp_send_config_error:${sendConfigError.message}`);

  const token = String(sendConfig?.access_token ?? "").trim();
  if (sendConfig?.auto_reply_enabled === false || !token) {
    const reason = sendConfig?.auto_reply_enabled === false ? "branch_auto_reply_disabled" : "meta_access_token_missing_for_branch";
    await supabase.from("whatsapp_ai_reply_runs").upsert({
      organization_id: args.organizationId,
      store_id: args.storeId,
      queue_id: args.queueId,
      conversation_id: args.conversationId,
      inbound_message_id: args.inboundMessageId,
      reply_type: "text",
      state_before: args.stateBefore,
      state_after: args.stateAfter,
      reply_text: args.text || null,
      status: "suppressed",
      error: reason,
      completed_at: new Date().toISOString(),
    }, { onConflict: "inbound_message_id" });
    return { status: "suppressed", outboundMessageId: null, metaMessageId: null, reason };
  }

  await supabase.from("whatsapp_ai_reply_runs").upsert({
    organization_id: args.organizationId,
    store_id: args.storeId,
    queue_id: args.queueId,
    conversation_id: args.conversationId,
    inbound_message_id: args.inboundMessageId,
    reply_type: "text",
    state_before: args.stateBefore,
    state_after: args.stateAfter,
    reply_text: args.text,
    status: "sending",
    error: null,
  }, { onConflict: "inbound_message_id" });

  const { data: existingOutbound } = await supabase
    .from("whatsapp_messages")
    .select("id,meta_message_id,delivery_status,text_body")
    .eq("reply_to_message_id", args.inboundMessageId)
    .eq("direction", "outbound")
    .maybeSingle();

  let outboundMessageId = existingOutbound?.id ? String(existingOutbound.id) : null;
  if (existingOutbound?.meta_message_id) {
    await supabase.from("whatsapp_ai_reply_runs").update({
      outbound_message_id: outboundMessageId,
      status: "sent",
      error: null,
      completed_at: new Date().toISOString(),
    }).eq("inbound_message_id", args.inboundMessageId);
    return { status: "sent", outboundMessageId, metaMessageId: String(existingOutbound.meta_message_id), reason: null };
  }

  if (!outboundMessageId) {
    const { data: created, error: createError } = await supabase.from("whatsapp_messages").insert({
      organization_id: args.organizationId,
      store_id: args.storeId,
      connection_id: args.connectionId,
      conversation_id: args.conversationId,
      direction: "outbound",
      message_type: "text",
      text_body: args.text,
      delivery_status: "sending",
      ai_status: "completed",
      reply_to_message_id: args.inboundMessageId,
      reply_kind: args.kind,
      reply_context: { queue_id: args.queueId, ...(args.context ?? {}) },
      raw_payload: { source: "salonos_ai_auto_reply", version: "13.6.10.58" },
      sent_at: new Date().toISOString(),
    }).select("id").single();
    if (createError) throw new Error(`outbound_message_create_failed:${createError.message}`);
    outboundMessageId = String(created.id);
  }

  const { data: connection, error: connectionError } = await supabase
    .from("whatsapp_business_connections")
    .select("phone_number_id")
    .eq("id", args.connectionId)
    .eq("organization_id", args.organizationId)
    .eq("store_id", args.storeId)
    .single();
  if (connectionError) throw new Error(`whatsapp_connection_error:${connectionError.message}`);

  try {
    const sent = await sendMetaTextMessage(
      String(connection.phone_number_id), token, String(sendConfig?.graph_api_version ?? "v26.0"), args.customerPhone, args.text,
    );
    await supabase.from("whatsapp_messages").update({
      meta_message_id: sent.metaMessageId,
      delivery_status: "accepted",
      raw_payload: { source: "salonos_ai_auto_reply", meta_response: sent.response, version: "13.6.10.58" },
      sent_at: new Date().toISOString(),
    }).eq("id", outboundMessageId);
    await supabase.from("whatsapp_store_configs").update({
      last_send_at: new Date().toISOString(), last_send_error: null, updated_at: new Date().toISOString(),
    }).eq("connection_id", args.connectionId);
    await supabase.from("whatsapp_ai_reply_runs").update({
      outbound_message_id: outboundMessageId,
      status: "sent",
      meta_response: sent.response,
      error: null,
      completed_at: new Date().toISOString(),
    }).eq("inbound_message_id", args.inboundMessageId);
    return { status: "sent", outboundMessageId, metaMessageId: sent.metaMessageId, reason: null };
  } catch (error) {
    const message = errorText(error).slice(0, 1500);
    if (outboundMessageId) await supabase.from("whatsapp_messages").update({ delivery_status: "failed" }).eq("id", outboundMessageId);
    await supabase.from("whatsapp_store_configs").update({ last_send_error: message, updated_at: new Date().toISOString() }).eq("connection_id", args.connectionId);
    await supabase.from("whatsapp_ai_reply_runs").update({
      outbound_message_id: outboundMessageId,
      status: "failed",
      error: message,
      completed_at: new Date().toISOString(),
    }).eq("inbound_message_id", args.inboundMessageId);
    // Business mutations (booking / cancel / reschedule) may already be committed
    // before Meta delivery happens. Do not throw here, otherwise the durable
    // conversation state remains stuck in an old confirmation state even though
    // the visit has already changed. Return a failed delivery audit instead and
    // let the caller finalize the business state truthfully.
    return { status: "failed", outboundMessageId, metaMessageId: null, reason: message };
  }
}


export default {
  async fetch(req: Request): Promise<Response> {
    const supabaseUrl = env("SUPABASE_URL");
    const key = serviceKey();
    const workerToken = env("SALONOS_AI_WORKER_TOKEN");
    const groqKey = env("GROQ_API_KEY");
    const openAiKey = env("OPENAI_API_KEY");
    const requestedProvider = (env("AI_PROVIDER") || (groqKey ? "groq" : "openai")).toLowerCase();
    const provider = requestedProvider === "groq" || requestedProvider === "openai" ? requestedProvider : "invalid";
    const model = provider === "groq"
      ? (env("GROQ_MODEL") || "openai/gpt-oss-20b")
      : (env("OPENAI_INTENT_MODEL") || env("OPENAI_MODEL") || "gpt-5.6-luna");
    const providerKey = provider === "groq" ? groqKey : openAiKey;

    if (req.method === "GET") {
      return json({
        ok: true,
        service: "SalonOS whatsapp-ai-worker",
        version: "13.6.10.58",
        configured: Boolean(supabaseUrl && key && workerToken && provider !== "invalid" && providerKey),
        provider,
        model,
      });
    }
    if (req.method !== "POST") return json({ ok: false, error: "method_not_allowed" }, 405);

    const suppliedToken = req.headers.get("x-salonos-worker-token") ?? "";
    if (!workerToken || !suppliedToken || !constantTimeEqual(suppliedToken, workerToken)) {
      return json({ ok: false, error: "unauthorized" }, 401);
    }
    if (provider === "invalid") return json({ ok: false, error: "invalid_ai_provider" }, 500);
    if (!supabaseUrl || !key || !providerKey) {
      return json({ ok: false, error: "server_not_configured", provider }, 500);
    }

    let requestBody: Json = {};
    try { requestBody = await req.json() as Json; } catch { requestBody = {}; }
    const requestedQueueId = String(requestBody.queue_id ?? "").trim();
    const force = requestBody.force === true;

    const supabase = createClient(supabaseUrl, key, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    let queueId = requestedQueueId;
    if (!queueId) {
      const { data: nextQueue, error } = await supabase
        .from("whatsapp_ai_queue")
        .select("id")
        .eq("status", "queued")
        .lte("available_at", new Date().toISOString())
        .order("created_at", { ascending: true })
        .limit(1)
        .maybeSingle();
      if (error) return json({ ok: false, error: error.message }, 500);
      if (!nextQueue?.id) return json({ ok: true, processed: 0, reason: "queue_empty" });
      queueId = String(nextQueue.id);
    }

    if (force) {
      await supabase
        .from("whatsapp_ai_queue")
        .update({ status: "queued", last_error: null, available_at: new Date().toISOString(), updated_at: new Date().toISOString() })
        .eq("id", queueId)
        .in("status", ["failed", "skipped"]);
    }

    const { data: claimedRaw, error: claimError } = await supabase.rpc("v1363_ai_claim_queue", { p_queue_id: queueId });
    if (claimError) return json({ ok: false, error: `claim_failed:${claimError.message}` }, 500);
    const claimed = Array.isArray(claimedRaw) ? claimedRaw[0] as Json | undefined : undefined;
    if (!claimed?.id) return json({ ok: true, processed: 0, queue_id: queueId, reason: "not_queued_or_already_claimed" });

    const startedAt = Date.now();
    let runId = "";
    try {
      const organizationId = String(claimed.organization_id);
      const storeId = String(claimed.store_id);
      const conversationId = String(claimed.conversation_id);
      const messageId = String(claimed.message_id);

      await supabase.from("whatsapp_messages").update({ ai_status: "processing" }).eq("id", messageId);

      const { data: conversation, error: convError } = await supabase
        .from("whatsapp_conversations")
        .select("id,customer_phone,customer_name,status,ai_enabled")
        .eq("id", conversationId)
        .eq("organization_id", organizationId)
        .eq("store_id", storeId)
        .single();
      if (convError) throw convError;
      if (!conversation.ai_enabled || String(conversation.status) === "blocked") {
        await supabase.from("whatsapp_ai_queue").update({ status: "skipped", last_error: "ai_disabled_or_blocked", updated_at: new Date().toISOString() }).eq("id", queueId);
        await supabase.from("whatsapp_messages").update({ ai_status: "skipped", ai_processed_at: new Date().toISOString() }).eq("id", messageId);
        return json({ ok: true, processed: 0, queue_id: queueId, reason: "ai_disabled_or_blocked" });
      }

      // Mandatory deterministic first action: Search Customer. The LLM never chooses or bypasses this.
      const { data: customerSearch, error: customerError } = await supabase.rpc("v1368_ai_prepare_customer_context", { p_queue_id: queueId });
      if (customerError) throw new Error(`search_customer_failed:${customerError.message}`);

      const { data: message, error: messageError } = await supabase
        .from("whatsapp_messages")
        .select("id,message_type,text_body,received_at")
        .eq("id", messageId)
        .eq("organization_id", organizationId)
        .eq("store_id", storeId)
        .single();
      if (messageError) throw messageError;

      const { data: previousState } = await supabase
        .from("whatsapp_ai_conversation_state")
        .select("state,active_intent,pending_action,slots,last_processed_at")
        .eq("conversation_id", conversationId)
        .maybeSingle();

      const { data: recentMessages } = await supabase
        .from("whatsapp_messages")
        .select("id,direction,message_type,text_body,received_at,ai_intent,ai_entities")
        .eq("conversation_id", conversationId)
        .order("received_at", { ascending: false })
        .limit(8);

      const customerSummary = (customerSearch ?? {}) as Json;
      const latestTextForState = String(message.text_body ?? "");
      const recentRows = ((recentMessages ?? []) as Json[]);

      // v13.6.10.56 — burst-message guard. Customers often send a booking as
      // several quick WhatsApp bubbles ("today" -> "7pm" -> "Crystal").
      // If a newer inbound message is already present, do not answer this stale
      // bubble separately. Let the newest queue item respond once using the full
      // recent conversation, which prevents repetitive bot-like questions.
      const currentReceivedAtMs = Date.parse(String(message.received_at ?? ""));
      const newerInbound = recentRows.find((row) => {
        if (String(row.direction ?? "") !== "inbound") return false;
        if (String(row.id ?? "") === String(messageId)) return false;
        const t = Date.parse(String(row.received_at ?? ""));
        return Number.isFinite(t) && Number.isFinite(currentReceivedAtMs) && t > currentReceivedAtMs;
      });
      if (newerInbound) {
        const finishedAt = new Date().toISOString();
        await supabase.from("whatsapp_ai_queue").update({
          status: "skipped",
          last_error: "superseded_by_newer_inbound",
          updated_at: finishedAt,
        }).eq("id", queueId);
        await supabase.from("whatsapp_messages").update({
          ai_status: "skipped",
          ai_processed_at: finishedAt,
        }).eq("id", messageId);
        return json({ ok: true, processed: 0, queue_id: queueId, reason: "superseded_by_newer_inbound", newer_message_id: newerInbound.id ?? null });
      }

      const previousStateName = String(previousState?.state ?? "idle");
      const previousActiveIntent = String(previousState?.active_intent ?? "");
      // v13.6.10.28 recovery for conversations already damaged by an older
      // safe_fallback turn. The latest inbound appointment message still carries
      // ai_entities even if conversation_state was reset to idle/other.
      const recentAppointmentEntityRow = recentRows.find((row) =>
        String(row.direction ?? "") === "inbound"
        && String(row.ai_intent ?? "") === "appointment"
        && Object.keys(asJson(row.ai_entities)).length > 0
      );
      const recentAppointmentContextState: Json | null = recentAppointmentEntityRow
        ? { state: "appointment_history_recovered", active_intent: "appointment", slots: asJson(recentAppointmentEntityRow.ai_entities) }
        : null;

      // v13.6.10.25 — draft lookup must be schema-drift tolerant.
      // v13.6.10.24 selected assignment_type/assignment_strategy together with the
      // core v13.6.7 draft columns and ignored PostgREST select errors. If a live
      // database missed either later-added assignment column, Supabase returned
      // data=null and the worker incorrectly concluded that no booking draft existed.
      // That dropped "change to 3 PM" back into confirmed-appointment reschedule.
      //
      // First try the full row. If that select fails, retry only with columns that
      // have existed since the appointment-draft table was introduced. If the DB
      // lookup is still unavailable, recover the durable booking snapshot already
      // stored in conversation-state slots. A terminal DB row still wins and blocks
      // resurrection of any older state snapshot.
      // v13.6.10.26 — use select("*") first so schema drift cannot make the
      // worker lose a perfectly valid draft merely because a named optional column
      // does not exist yet on the live project. If ordering by updated_at itself is
      // unavailable, fall back to created_at.
      const universalDraftLookup = await supabase
        .from("whatsapp_ai_appointment_drafts")
        .select("*")
        .eq("organization_id", organizationId)
        .eq("store_id", storeId)
        .eq("conversation_id", conversationId)
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      let latestBookingDraftRow = universalDraftLookup.data;
      let draftLookupError = universalDraftLookup.error?.message ?? null;
      let draftLookupSource = latestBookingDraftRow ? "database_star" : "database_none";

      if (!latestBookingDraftRow && universalDraftLookup.error) {
        const createdAtDraftLookup = await supabase
          .from("whatsapp_ai_appointment_drafts")
          .select("*")
          .eq("organization_id", organizationId)
          .eq("store_id", storeId)
          .eq("conversation_id", conversationId)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        latestBookingDraftRow = createdAtDraftLookup.data;
        draftLookupError = [draftLookupError, createdAtDraftLookup.error?.message].filter(Boolean).join(" | ") || null;
        draftLookupSource = latestBookingDraftRow ? "database_star_created_at_fallback" : "database_error";
      }

      const stateSlotsForDraftRecovery = asJson(previousState?.slots);
      const stateDraftSnapshot = asJson(stateSlotsForDraftRecovery.booking_draft);
      const stateDraftAppointment = asJson(stateDraftSnapshot.appointment);
      const stateDraftCustomer = asJson(stateDraftSnapshot.customer);
      const stateDraftId = nullableString(stateDraftSnapshot.draft_id) ?? nullableString(stateDraftSnapshot.id);
      const stateDraftPreference = String(stateSlotsForDraftRecovery.staff_preference ?? "unknown");
      const stateDraftCandidate: Json | null = stateDraftId ? {
        id: stateDraftId,
        draft_id: stateDraftId,
        status: nullableString(stateDraftSnapshot.status) ?? "pending_confirmation",
        expires_at: stateDraftSnapshot.expires_at ?? null,
        updated_at: previousState?.last_processed_at ?? null,
        confirmed_visit_id: stateDraftSnapshot.confirmed_visit_id ?? null,
        customer_name: stateDraftCustomer.name ?? stateDraftSnapshot.customer_name ?? null,
        reported_age: stateDraftCustomer.reported_age ?? stateDraftSnapshot.reported_age ?? null,
        age_range: stateDraftCustomer.age_range ?? stateDraftSnapshot.age_range ?? null,
        ethnicity: stateDraftCustomer.ethnicity ?? stateDraftSnapshot.ethnicity ?? null,
        service_id: stateDraftAppointment.service_id ?? stateDraftSnapshot.service_id ?? null,
        service_name_snapshot: stateDraftAppointment.service_name ?? stateDraftSnapshot.service_name_snapshot ?? null,
        service_price_snapshot: stateDraftAppointment.price ?? stateDraftSnapshot.service_price_snapshot ?? null,
        service_duration_minutes: stateDraftAppointment.duration_minutes ?? stateDraftSnapshot.service_duration_minutes ?? null,
        employee_id: stateDraftAppointment.employee_id ?? stateDraftSnapshot.employee_id ?? null,
        employee_name_snapshot: stateDraftAppointment.employee_name ?? stateDraftSnapshot.employee_name_snapshot ?? null,
        appointment_date: stateDraftAppointment.date ?? stateDraftSnapshot.appointment_date ?? null,
        appointment_time: stateDraftAppointment.time ?? stateDraftSnapshot.appointment_time ?? null,
        scheduled_at: stateDraftAppointment.scheduled_at ?? stateDraftSnapshot.scheduled_at ?? null,
        assignment_type: stateDraftSnapshot.assignment_type
          ?? (stateDraftPreference === "no_preference" ? "random" : (stateDraftPreference === "specified" ? "specified" : null)),
        assignment_strategy: stateDraftSnapshot.assignment_strategy ?? null,
      } : null;

      // v13.6.10.26 historical safety net. Older releases could overwrite
      // conversation_state.slots.booking_draft with null after the first mistaken
      // reschedule_not_found reply. In that situation the state fallback added in
      // .25 has nothing left to recover. Search recent AI-run snapshots only when
      // the live draft query returned no row and the current message is clearly a
      // draft date/time revision. This is intentionally time-bounded to six hours.
      const recoverableDraftStatuses = new Set(["collecting_profile", "pending_confirmation", "needs_reschedule", "expired"]);
      const latestRowStatusForRecovery = String(asJson(latestBookingDraftRow).status ?? "").toLowerCase();
      const latestRowUpdatedMsForRecovery = Date.parse(String(asJson(latestBookingDraftRow).updated_at ?? ""));
      const latestRowIsTerminalForRecovery = Boolean(
        latestBookingDraftRow && !recoverableDraftStatuses.has(latestRowStatusForRecovery),
      );
      let historicalDraftCandidate: Json | null = null;
      let historicalDraftSource: string | null = null;
      let historicalDraftCreatedMs = Number.NaN;
      if ((!latestBookingDraftRow || latestRowIsTerminalForRecovery) && !stateDraftCandidate && hasDraftRevisionSignal(latestTextForState)) {
        const { data: priorDraftRuns, error: priorDraftRunsError } = await supabase
          .from("whatsapp_ai_runs")
          .select("output_snapshot,created_at,status")
          .eq("organization_id", organizationId)
          .eq("store_id", storeId)
          .eq("conversation_id", conversationId)
          .order("created_at", { ascending: false })
          .limit(20);
        if (priorDraftRunsError) {
          draftLookupError = [draftLookupError, `run_history:${priorDraftRunsError.message}`].filter(Boolean).join(" | ") || null;
        } else {
          for (const row of ((priorDraftRuns ?? []) as Json[])) {
            const createdMs = Date.parse(String(row.created_at ?? ""));
            if (!Number.isFinite(createdMs) || (Date.now() - createdMs) > 6 * 60 * 60 * 1000) continue;
            // A terminal DB transaction remains authoritative unless this run snapshot
            // was created AFTER that terminal row. That lets us recover a newer draft
            // whose state/row was damaged without resurrecting an older abandoned draft.
            if (latestRowIsTerminalForRecovery
              && (!Number.isFinite(latestRowUpdatedMsForRecovery) || createdMs <= latestRowUpdatedMsForRecovery)) continue;
            const out = asJson(row.output_snapshot);
            const direct = asJson(out.appointment_draft);
            const nested = asJson(out.draft);
            const snap = Object.keys(direct).length ? direct : nested;
            const histId = nullableString(snap.draft_id) ?? nullableString(snap.id);
            if (!histId) continue;

            // Prefer the authoritative row if it still exists.
            const { data: histRow, error: histRowError } = await supabase
              .from("whatsapp_ai_appointment_drafts")
              .select("*")
              .eq("id", histId)
              .eq("organization_id", organizationId)
              .eq("store_id", storeId)
              .maybeSingle();
            if (histRow) {
              const histStatus = String(asJson(histRow).status ?? "").toLowerCase();
              if (recoverableDraftStatuses.has(histStatus) && !nullableString(asJson(histRow).confirmed_visit_id)) {
                historicalDraftCandidate = { ...asJson(histRow), draft_id: histId };
                historicalDraftSource = "ai_run_id_database_recovery";
                historicalDraftCreatedMs = createdMs;
                break;
              }
              continue;
            }
            if (histRowError) {
              draftLookupError = [draftLookupError, `historical_row:${histRowError.message}`].filter(Boolean).join(" | ") || null;
            }

            // If the row itself cannot be read, the run snapshot is still enough to
            // route the message back into appointment flow. The normal booking RPC
            // will re-check skill + availability and create/reuse a durable draft.
            const histAppointment = asJson(snap.appointment);
            const histCustomer = asJson(snap.customer);
            const histStatus = String(snap.status ?? "pending_confirmation").toLowerCase();
            if (!recoverableDraftStatuses.has(histStatus) || nullableString(snap.confirmed_visit_id)) continue;
            historicalDraftCandidate = {
              id: histId, draft_id: histId, status: histStatus, expires_at: snap.expires_at ?? null, updated_at: row.created_at ?? null,
              confirmed_visit_id: null,
              customer_name: histCustomer.name ?? snap.customer_name ?? null,
              reported_age: histCustomer.reported_age ?? snap.reported_age ?? null,
              age_range: histCustomer.age_range ?? snap.age_range ?? null,
              ethnicity: histCustomer.ethnicity ?? snap.ethnicity ?? null,
              service_id: histAppointment.service_id ?? snap.service_id ?? null,
              service_name_snapshot: histAppointment.service_name ?? snap.service_name_snapshot ?? null,
              service_price_snapshot: histAppointment.price ?? snap.service_price_snapshot ?? null,
              service_duration_minutes: histAppointment.duration_minutes ?? snap.service_duration_minutes ?? null,
              employee_id: histAppointment.employee_id ?? snap.employee_id ?? null,
              employee_name_snapshot: histAppointment.employee_name ?? snap.employee_name_snapshot ?? null,
              appointment_date: histAppointment.date ?? snap.appointment_date ?? null,
              appointment_time: histAppointment.time ?? snap.appointment_time ?? null,
              scheduled_at: histAppointment.scheduled_at ?? snap.scheduled_at ?? null,
              assignment_type: snap.assignment_type ?? null,
              assignment_strategy: snap.assignment_strategy ?? null,
            };
            historicalDraftSource = "ai_run_snapshot_recovery";
            historicalDraftCreatedMs = createdMs;
            break;
          }
        }
      }

      // Database row is authoritative unless a bounded AI-run snapshot proves a
      // newer unconfirmed transaction happened after the terminal DB row.
      const historicalSupersedesTerminal = Boolean(
        historicalDraftCandidate
        && latestRowIsTerminalForRecovery
        && Number.isFinite(historicalDraftCreatedMs)
        && Number.isFinite(latestRowUpdatedMsForRecovery)
        && historicalDraftCreatedMs > latestRowUpdatedMsForRecovery,
      );
      const selectedDatabaseDraftRow = historicalSupersedesTerminal ? null : latestBookingDraftRow;
      const latestBookingDraft = selectedDatabaseDraftRow
        ? {
            ...asJson(selectedDatabaseDraftRow),
            draft_id: nullableString(asJson(selectedDatabaseDraftRow).id),
            assignment_type: asJson(selectedDatabaseDraftRow).assignment_type
              ?? (stateDraftCandidate && nullableString(stateDraftCandidate.id) === nullableString(asJson(selectedDatabaseDraftRow).id)
                ? stateDraftCandidate.assignment_type : null),
            assignment_strategy: asJson(selectedDatabaseDraftRow).assignment_strategy
              ?? (stateDraftCandidate && nullableString(stateDraftCandidate.id) === nullableString(asJson(selectedDatabaseDraftRow).id)
                ? stateDraftCandidate.assignment_strategy : null),
          }
        : (stateDraftCandidate ?? historicalDraftCandidate);
      if (stateDraftCandidate && !selectedDatabaseDraftRow) draftLookupSource = "conversation_state_fallback";
      else if (historicalDraftCandidate && !selectedDatabaseDraftRow) draftLookupSource = historicalDraftSource ?? "ai_run_history_fallback";
      const latestDraftStatus = String(latestBookingDraft?.status ?? "").toLowerCase();
      const activeDraftStatuses = new Set(["collecting_profile", "pending_confirmation", "needs_reschedule"]);
      const latestDraftUpdatedMs = Date.parse(String(latestBookingDraft?.updated_at ?? ""));
      const latestDraftExpiresMs = Date.parse(String(latestBookingDraft?.expires_at ?? ""));
      const latestDraftRecent = Number.isFinite(latestDraftUpdatedMs)
        && (Date.now() - latestDraftUpdatedMs) <= 24 * 60 * 60 * 1000;
      const latestDraftExpiredByTime = Number.isFinite(latestDraftExpiresMs)
        && latestDraftExpiresMs <= Date.now();

      // A pending draft is still conversationally recoverable for 24 hours.
      // We only consider the LATEST transaction. If the latest draft is already
      // confirmed/cancelled/failed, an older expired draft is never resurrected.
      let pendingBookingDraft =
        latestBookingDraft
        && (
          activeDraftStatuses.has(latestDraftStatus)
          || (latestDraftStatus === "expired" && latestDraftRecent)
        )
          ? latestBookingDraft
          : null;

      // v13.6.10.34 — an explicit new-booking sentence starts a NEW transaction.
      // It must not inherit a date/service/staff from a previous cancelled, failed,
      // or half-built draft. This also repairs conversations that were already
      // contaminated by older releases: the old unconfirmed draft is abandoned
      // before the new request is interpreted.
      const freshBookingRestart = isFreshBookingRestart(latestTextForState);
      let freshRestartAbandonedDraft: Json | null = null;
      if (freshBookingRestart && pendingBookingDraft) {
        const { data: abandoned, error: abandonError } = await supabase.rpc("v1367_ai_cancel_draft", { p_queue_id: queueId });
        if (abandonError) throw new Error(`fresh_booking_abandon_old_draft_failed:${abandonError.message}`);
        freshRestartAbandonedDraft = asJson(abandoned);
        pendingBookingDraft = null;
      }

      // v13.6.10.58 — changing an unconfirmed draft from an assigned stylist to
      // "I want to choose a stylist" is a real booking revision. Abandon the old
      // draft before intent routing and remove only the stylist-dependent slots;
      // service/date/time remain available for the next availability check.
      const specifiedStylistRevisionRequested = explicitStaffPreference(latestTextForState) === "specified";
      let staffPreferenceRevisionAbandonedDraft: Json | null = null;
      if (!freshBookingRestart && pendingBookingDraft && specifiedStylistRevisionRequested) {
        const { data: abandoned, error: abandonError } = await supabase.rpc("v1367_ai_cancel_draft", { p_queue_id: queueId });
        if (abandonError) throw new Error(`staff_preference_revision_abandon_draft_failed:${abandonError.message}`);
        staffPreferenceRevisionAbandonedDraft = asJson(abandoned);
        pendingBookingDraft = null;
      }
      const clearPriorStylistForRevision = !freshBookingRestart
        && specifiedStylistRevisionRequested
        && previousActiveIntent === "appointment";
      const previousStateForBookingFlow = clearPriorStylistForRevision
        ? clearStylistSelectionForRevision(previousState ? previousState as Json : null)
        : (previousState ? previousState as Json : null);

      const pendingDraftNeedsReactivation = Boolean(
        pendingBookingDraft
        && (
          String(pendingBookingDraft.status ?? "").toLowerCase() === "expired"
          || latestDraftExpiredByTime
        )
      );

      const finishBookingState = async (args: {
        stage: string;
        state: string;
        pendingAction: string | null;
        replyText: string;
        replyKind: string;
        output: Json;
        draft?: Json | null;
        modelName?: string | null;
        resetTransaction?: boolean;
      }): Promise<Response> => {
        const finishedAt = new Date().toISOString();
        const delivery = await deliverAutoReply(supabase, {
          organizationId, storeId, connectionId: String(claimed.connection_id), conversationId,
          inboundMessageId: messageId, queueId, customerPhone: String(conversation.customer_phone),
          text: args.replyText, kind: args.replyKind, stateBefore: previousStateName, stateAfter: args.state,
          context: { booking_stage: args.stage, draft_id: nullableString(asJson(args.draft).draft_id) },
        });
        const { data: currentQueue } = await supabase.from("whatsapp_ai_queue").select("context").eq("id", queueId).maybeSingle();
        const context = {
          ...asJson(currentQueue?.context),
          pipeline_stage: args.state,
          booking_flow: { stage: args.stage, draft: args.draft ?? null, output: args.output },
          reply: {
            status: delivery.status, kind: args.replyKind, text: args.replyText, reason: delivery.reason,
            outbound_message_id: delivery.outboundMessageId, meta_message_id: delivery.metaMessageId,
          },
          pending_action: args.pendingAction,
          next_step: args.pendingAction,
        };
        await supabase.from("whatsapp_ai_queue").update({ status: "completed", context, last_error: null, updated_at: finishedAt })
          .eq("id", queueId).eq("organization_id", organizationId).eq("store_id", storeId);
        await supabase.from("whatsapp_messages").update({
          ai_status: "completed", ai_intent: "appointment", ai_processed_at: finishedAt,
          ai_entities: { booking_stage: args.stage, draft_id: nullableString(asJson(args.draft).draft_id) },
        }).eq("id", messageId).eq("organization_id", organizationId).eq("store_id", storeId);
        const priorSlots = asJson(previousState?.slots);
        const resetTransaction = args.resetTransaction === true;
        await supabase.from("whatsapp_ai_conversation_state").upsert({
          organization_id: organizationId, store_id: storeId, conversation_id: conversationId,
          state: resetTransaction ? "idle" : args.state,
          active_intent: resetTransaction ? null : "appointment",
          pending_action: resetTransaction ? null : args.pendingAction,
          // Completed/abandoned booking transactions must not leak into the next message.
          // Customer intelligence is stored separately in customer_context, so clearing
          // transactional slots here does not discard useful long-term customer context.
          slots: resetTransaction ? {
            last_reply_kind: args.replyKind,
            last_reply_text: args.replyText,
          } : {
            ...priorSlots,
            selected_target_visit_id: null,
            target_appointment: null,
            appointment_reference: null,
            change_draft: null,
            change_request: null,
            candidate_appointments: [],
            booking_draft: args.draft ?? null,
            last_reply_kind: args.replyKind,
            last_reply_text: args.replyText,
          },
          customer_context: customerSearch ?? {}, last_queue_id: queueId, last_message_id: messageId,
          last_model: args.modelName ?? null, last_processed_at: finishedAt, updated_at: finishedAt,
        }, { onConflict: "conversation_id" });
        await supabase.from("whatsapp_conversations").update({ updated_at: finishedAt, last_message_at: finishedAt }).eq("id", conversationId);
        if (runId) {
          await supabase.from("whatsapp_ai_runs").update({
            status: "completed", output_snapshot: { ...args.output, reply: delivery },
            duration_ms: Date.now() - startedAt, completed_at: finishedAt,
          }).eq("id", runId);
        }
        return json({ ok: true, processed: 1, queue_id: queueId, pipeline_stage: args.state, pending_action: args.pendingAction, reply: delivery, output: args.output });
      };

      const finishChangeState = async (args: {
        intent: "cancel" | "reschedule";
        stage: string;
        state: string;
        pendingAction: string | null;
        replyText: string;
        replyKind: string;
        output: Json;
        slotsPatch?: Json;
        modelName?: string | null;
        resetTransaction?: boolean;
      }): Promise<Response> => {
        const finishedAt = new Date().toISOString();
        const delivery = await deliverAutoReply(supabase, {
          organizationId, storeId, connectionId: String(claimed.connection_id), conversationId,
          inboundMessageId: messageId, queueId, customerPhone: String(conversation.customer_phone),
          text: args.replyText, kind: args.replyKind, stateBefore: previousStateName, stateAfter: args.state,
          context: { change_stage: args.stage, action_type: args.intent, ...(args.slotsPatch ?? {}) },
        });
        const { data: currentQueue } = await supabase.from("whatsapp_ai_queue").select("context").eq("id", queueId).maybeSingle();
        const context = {
          ...asJson(currentQueue?.context),
          pipeline_stage: args.state,
          change_flow: { stage: args.stage, action_type: args.intent, output: args.output },
          reply: {
            status: delivery.status, kind: args.replyKind, text: args.replyText, reason: delivery.reason,
            outbound_message_id: delivery.outboundMessageId, meta_message_id: delivery.metaMessageId,
          },
          pending_action: args.pendingAction,
          next_step: args.pendingAction,
        };
        await supabase.from("whatsapp_ai_queue").update({ status: "completed", context, last_error: null, updated_at: finishedAt })
          .eq("id", queueId).eq("organization_id", organizationId).eq("store_id", storeId);
        await supabase.from("whatsapp_messages").update({
          ai_status: "completed", ai_intent: args.intent, ai_processed_at: finishedAt,
          ai_entities: { change_stage: args.stage, action_type: args.intent, ...(args.slotsPatch ?? {}) },
        }).eq("id", messageId).eq("organization_id", organizationId).eq("store_id", storeId);
        const priorSlots = asJson(previousState?.slots);
        const resetTransaction = args.resetTransaction === true;
        await supabase.from("whatsapp_ai_conversation_state").upsert({
          organization_id: organizationId, store_id: storeId, conversation_id: conversationId,
          state: resetTransaction ? "idle" : args.state,
          active_intent: resetTransaction ? null : args.intent,
          pending_action: resetTransaction ? null : args.pendingAction,
          slots: resetTransaction
            ? { last_reply_kind: args.replyKind, last_reply_text: args.replyText }
            : { ...priorSlots, ...(args.slotsPatch ?? {}), last_reply_kind: args.replyKind, last_reply_text: args.replyText },
          customer_context: customerSearch ?? {}, last_queue_id: queueId, last_message_id: messageId,
          last_model: args.modelName ?? null, last_processed_at: finishedAt, updated_at: finishedAt,
        }, { onConflict: "conversation_id" });
        await supabase.from("whatsapp_conversations").update({ updated_at: finishedAt, last_message_at: finishedAt }).eq("id", conversationId);
        if (runId) {
          await supabase.from("whatsapp_ai_runs").update({
            status: "completed", output_snapshot: { ...args.output, reply: delivery },
            duration_ms: Date.now() - startedAt, completed_at: finishedAt,
          }).eq("id", runId);
        }
        return json({ ok: true, processed: 1, queue_id: queueId, pipeline_stage: args.state, intent: args.intent, pending_action: args.pendingAction, reply: delivery, output: args.output });
      };

      // -----------------------------------------------------------------------
      // v13.6.10.25 stale-draft reactivation.
      // A 20-minute draft timeout must never make "change to 3 PM" look like a
      // reschedule request for an already-confirmed Visit.
      //
      // Revisions reactivate the same transaction for another 20 minutes, then
      // the normal appointment pipeline re-checks skill + availability before
      // updating it. We do NOT blindly confirm stale availability.
      // -----------------------------------------------------------------------
      if (
        pendingBookingDraft
        && pendingDraftNeedsReactivation
        && hasDraftRevisionSignal(latestTextForState)
      ) {
        const revivedAt = new Date().toISOString();
        const revivedExpiry = new Date(Date.now() + 20 * 60 * 1000).toISOString();
        const { error: reviveError } = await supabase
          .from("whatsapp_ai_appointment_drafts")
          .update({
            status: "collecting_profile",
            expires_at: revivedExpiry,
            last_queue_id: queueId,
            last_message_id: messageId,
            updated_at: revivedAt,
          })
          .eq("id", String(pendingBookingDraft.id))
          .eq("organization_id", organizationId)
          .eq("store_id", storeId);
        if (reviveError) throw new Error(`reactivate_booking_draft_failed:${reviveError.message}`);
        pendingBookingDraft.status = "collecting_profile";
        pendingBookingDraft.expires_at = revivedExpiry;
      }

      // If the customer tries to CONFIRM a stale draft, do not confirm old
      // availability and do not route to existing-appointment self-service.
      // Ask for the desired date/time once, then the revision path revalidates it.
      if (
        pendingBookingDraft
        && pendingDraftNeedsReactivation
        && isConfirmDraftText(latestTextForState)
      ) {
        const lang = conversationReplyLanguage(latestTextForState, recentRows, "other");
        const date = displayDate(nullableString(pendingBookingDraft.appointment_date));
        const time = displayTime((nullableString(pendingBookingDraft.appointment_time) ?? "").slice(0, 5));
        const service = displayServiceName(nullableString(pendingBookingDraft.service_name_snapshot), "en");
        const reply = lang === "zh"
          ? `这份尚未确认的预约草稿已经超时，我不会直接用旧的空档确认，也不会把它当成已建立的预约。\n原草稿：${date} ${time} · ${service}\n\n请重新告诉我你现在要的时间，例如「下午3点」或「换去下午3点」，我会重新检查员工空档后更新草稿。`
          : lang === "ms"
            ? `Draf tempahan yang belum disahkan ini telah tamat tempoh. Saya tidak akan mengesahkan slot lama atau menganggapnya sebagai tempahan rasmi.\nDraf lama: ${date} ${time} · ${service}\n\nSila hantar masa yang anda mahu sekarang, contohnya "3 PM". Saya akan semak ketersediaan semula.`
            : `This unconfirmed booking draft has expired. I won't confirm the old availability or treat it as an existing appointment.\nPrevious draft: ${date} ${time} · ${service}\n\nPlease send the time you want now, for example "3 PM" or "change to 3 PM". I'll recheck staff availability and update the draft.`;
        return await finishBookingState({
          stage: "booking_draft_expired_needs_revalidation",
          state: "awaiting_booking_confirmation",
          pendingAction: "revise_expired_appointment_draft",
          replyText: reply,
          replyKind: "booking_draft_expired_revalidate",
          output: { draft_id: pendingBookingDraft.id, previous_state: previousStateName },
          draft: pendingBookingDraft,
          modelName: null,
        });
      }

      // -----------------------------------------------------------------------
      // v13.6.10.23 pending-draft recovery.
      // If an unconfirmed booking draft was accidentally routed into the
      // existing-appointment reschedule flow, restore the booking flow instead of
      // repeatedly replying "I couldn't find a future appointment...".
      // -----------------------------------------------------------------------
      const draftMisrouteStates = new Set([
        "reschedule_not_found", "reschedule_confirm_failed",
        "cancel_not_found", "cancel_confirm_failed",
      ]);
      if (
        pendingBookingDraft
        && !pendingDraftNeedsReactivation
        && draftMisrouteStates.has(previousStateName)
        && isConfirmDraftText(latestTextForState)
      ) {
        const lang = conversationReplyLanguage(latestTextForState, recentRows, "other");
        const date = displayDate(nullableString(pendingBookingDraft.appointment_date));
        const time = displayTime((nullableString(pendingBookingDraft.appointment_time) ?? "").slice(0, 5));
        const service = displayServiceName(nullableString(pendingBookingDraft.service_name_snapshot), "en");
        const staff = nullableString(pendingBookingDraft.employee_name_snapshot) ?? "Stylist";
        const reply = lang === "zh"
          ? `我找到的是一份尚未确认的预约草稿，不是已建立的预约。\n目前草稿：${date} ${time} · ${service} · ${staff}\n\n刚才的改时间没有套用成功。请重新告诉我新时间，例如「换去下午3点」；确认新草稿后再回复「确认」。`
          : lang === "ms"
            ? `Saya jumpa draf tempahan yang belum disahkan, bukan tempahan rasmi.\nDraf semasa: ${date} ${time} · ${service} · ${staff}\n\nPerubahan masa tadi belum digunakan. Sila hantar masa baharu sekali lagi, kemudian sahkan draf baharu.`
            : `I found an unconfirmed booking draft, not an existing appointment.\nCurrent draft: ${date} ${time} · ${service} · ${staff}\n\nYour previous time change was not applied. Please send the new time again, for example "change to 3 PM", then confirm the updated draft.`;
        return await finishBookingState({
          stage: "booking_draft_recovered_after_change_misroute",
          state: "awaiting_booking_confirmation",
          pendingAction: "revise_or_confirm_appointment_draft",
          replyText: reply,
          replyKind: "booking_draft_recovered",
          output: { recovered_draft_id: pendingBookingDraft.id, previous_state: previousStateName },
          draft: pendingBookingDraft,
          modelName: null,
        });
      }

      // v13.6.10.28: a plain cancel while an UNCONFIRMED booking draft exists
      // cancels that draft at any booking stage (including profile collection).
      // It must never be misread as cancellation of a future confirmed appointment.
      if (pendingBookingDraft && isCancelDraftText(latestTextForState)) {
        const { data: run, error: runError } = await supabase.from("whatsapp_ai_runs").insert({
          organization_id: organizationId, store_id: storeId, queue_id: queueId, conversation_id: conversationId,
          message_id: messageId, stage: "appointment_draft_cancel", provider: "backend", model: null,
          status: "processing", input_snapshot: { command: "cancel_pending_draft", previous_state: previousStateName, draft_id: pendingBookingDraft.id ?? null },
        }).select("id").single();
        if (runError) throw runError;
        runId = String(run.id);
        const { data: cancelled, error: cancelError } = await supabase.rpc("v1367_ai_cancel_draft", { p_queue_id: queueId });
        if (cancelError) throw new Error(`cancel_draft_failed:${cancelError.message}`);
        const text = "Okay, I cancelled the unconfirmed booking draft. No appointment was created.";
        return await finishBookingState({
          stage: "appointment_draft_cancelled", state: "appointment_draft_cancelled", pendingAction: null,
          replyText: text, replyKind: "draft_cancelled", output: asJson(cancelled), draft: asJson(cancelled), modelName: null, resetTransaction: true,
        });
      }

      // -----------------------------------------------------------------------
      // v13.6.9 existing-appointment change state machine. Confirmation and list
      // selection are deterministic; the LLM never receives authority to mutate.
      // -----------------------------------------------------------------------
      const changeConfirmStates = new Set(["cancel_awaiting_confirmation", "reschedule_awaiting_confirmation"]);
      const changeSelectionStates = new Set(["cancel_selecting_appointment", "reschedule_selecting_appointment"]);

      if ((previousActiveIntent === "cancel" || previousActiveIntent === "reschedule") && changeConfirmStates.has(previousStateName)) {
        const changeIntent = previousActiveIntent as "cancel" | "reschedule";
        const lang = conversationReplyLanguage(latestTextForState, recentRows, "other");
        const shouldConfirm = changeIntent === "cancel" ? isConfirmCancelAppointmentText(latestTextForState) : isConfirmDraftText(latestTextForState);
        if (shouldConfirm) {
          const { data: run, error: runError } = await supabase.from("whatsapp_ai_runs").insert({
            organization_id: organizationId, store_id: storeId, queue_id: queueId, conversation_id: conversationId,
            message_id: messageId, stage: `${changeIntent}_confirm_change`, provider: "backend", model: null,
            status: "processing", input_snapshot: { command: "confirm", previous_state: previousStateName },
          }).select("id").single();
          if (runError) throw runError;
          runId = String(run.id);
          const { data: confirmed, error: confirmError } = await supabase.rpc("v1369_ai_confirm_change", { p_queue_id: queueId });
          if (confirmError) throw new Error(`confirm_change_failed:${confirmError.message}`);
          const result = asJson(confirmed);
          if (result.ok === true && ["cancelled", "rescheduled"].includes(String(result.status ?? ""))) {
            return await finishChangeState({
              intent: changeIntent, stage: `${changeIntent}_confirmed`, state: `${changeIntent}_confirmed`, pendingAction: null,
              replyText: changeSuccessText(result, lang), replyKind: `${changeIntent}_confirmed`, output: result,
              slotsPatch: { selected_target_visit_id: null, target_appointment: null, appointment_reference: null, change_draft: null, change_request: null, candidate_appointments: [] }, modelName: null, resetTransaction: true,
            });
          }
          if (changeIntent === "reschedule" && String(result.error ?? "") === "slot_no_longer_available") {
            const alternatives = asJson(result.alternatives);
            const slots = Array.isArray(alternatives.slots) ? (alternatives.slots as unknown[]).map((x) => nullableString(asJson(x).time)).filter((x): x is string => Boolean(x)) : [];
            return await finishChangeState({
              intent: "reschedule", stage: "reschedule_slot_unavailable", state: "reschedule_awaiting_slot_selection", pendingAction: "select_reschedule_time",
              replyText: rescheduleSlotsText(alternatives, lang), replyKind: "reschedule_slot_unavailable", output: result,
              slotsPatch: { selected_target_visit_id: result.visit_id ?? asJson(previousState?.slots).selected_target_visit_id ?? null, offered_slots: slots, requested_date: alternatives.date ?? asJson(previousState?.slots).date_iso ?? null, time_period: asJson(previousState?.slots).time_period ?? "unspecified", change_draft: null }, modelName: null,
            });
          }
          const err = String(result.error ?? "change_confirm_failed");
          const text = lang === "zh" ? `这次${changeIntent === "cancel" ? "取消" : "改期"}没有执行。原因：${err}。原预约保持不变。`
            : lang === "ms" ? `Perubahan tidak dibuat (${err}). Tempahan asal dikekalkan.`
            : `The change was not applied (${err}). The original appointment remains unchanged.`;
          return await finishChangeState({
            intent: changeIntent, stage: `${changeIntent}_confirm_failed`, state: `${changeIntent}_confirm_failed`, pendingAction: "human_review_change",
            replyText: text, replyKind: "change_confirm_failed", output: result, slotsPatch: {}, modelName: null,
          });
        }
        if (isAbortAppointmentChangeText(latestTextForState)) {
          const { data: abandoned, error: abandonError } = await supabase.rpc("v1369_ai_cancel_change_draft", { p_queue_id: queueId });
          if (abandonError) throw new Error(`cancel_change_draft_failed:${abandonError.message}`);
          const text = lang === "zh" ? "好的，这次修改已经取消，原预约保持不变。"
            : lang === "ms" ? "Baik, perubahan dibatalkan. Tempahan asal dikekalkan."
            : "Okay, the change has been discarded. Your original appointment remains unchanged.";
          return await finishChangeState({
            intent: changeIntent, stage: "change_draft_cancelled", state: "change_draft_cancelled", pendingAction: null,
            replyText: text, replyKind: "change_draft_cancelled", output: asJson(abandoned), slotsPatch: { change_draft: null }, modelName: null, resetTransaction: true,
          });
        }
        // A different date/time may be a revision of the reschedule draft; let the
        // normal intent/entity route handle it. For cancellation confirmation we
        // require the explicit phrase "确认取消" and otherwise repeat safely.
        if (changeIntent === "cancel") {
          const text = lang === "zh" ? "如果确定要取消这笔预约，请回复「确认取消」；如果要保留，请回复「保留预约」。"
            : lang === "ms" ? "Untuk batal, balas \"confirm cancel\". Untuk kekalkan, balas \"keep\"."
            : "To cancel the appointment, reply \"confirm cancel\". To keep it, reply \"keep booking\".";
          return await finishChangeState({ intent: "cancel", stage: "cancel_awaiting_confirmation", state: "cancel_awaiting_confirmation", pendingAction: "confirm_cancel_existing_appointment", replyText: text, replyKind: "cancel_confirmation_retry", output: {}, slotsPatch: {}, modelName: null });
        }
      }

      if ((previousActiveIntent === "cancel" || previousActiveIntent === "reschedule") && changeSelectionStates.has(previousStateName)) {
        const changeIntent = previousActiveIntent as "cancel" | "reschedule";
        const priorSlots = asJson(previousState?.slots);
        const candidates = Array.isArray(priorSlots.candidate_appointments) ? (priorSlots.candidate_appointments as unknown[]).map(asJson) : [];
        const idx = parseAppointmentSelection(latestTextForState, candidates.length);
        const lang = conversationReplyLanguage(latestTextForState, recentRows, "other");
        if (idx == null || !candidates[idx]) {
          const text = lang === "zh" ? `请回复有效序号，例如「1」到「${Math.max(1, candidates.length)}」。`
            : lang === "ms" ? "Sila balas nombor pilihan yang sah."
            : "Please reply with a valid appointment number from the list.";
          return await finishChangeState({ intent: changeIntent, stage: previousStateName, state: previousStateName, pendingAction: "select_existing_appointment", replyText: text, replyKind: "appointment_selection_retry", output: { candidates }, slotsPatch: {}, modelName: null });
        }
        const selected = candidates[idx];
        const targetId = nullableString(selected.visit_id);
        if (!targetId) throw new Error("selected_appointment_missing_visit_id");

        if (changeIntent === "cancel") {
          const { data: prepared, error: prepareError } = await supabase.rpc("v1369_ai_prepare_change_draft", {
            p_queue_id: queueId, p_action_type: "cancel", p_visit_id: targetId, p_date: null, p_time_iso: null, p_time_period: "unspecified",
          });
          if (prepareError) throw new Error(`prepare_cancel_change_failed:${prepareError.message}`);
          const draft = asJson(prepared);
          if (draft.ok !== true) throw new Error(`prepare_cancel_change_failed:${String(draft.error ?? "unknown")}`);
          return await finishChangeState({
            intent: "cancel", stage: "cancel_awaiting_confirmation", state: "cancel_awaiting_confirmation", pendingAction: "confirm_cancel_existing_appointment",
            replyText: changeDraftSummaryText(draft, lang), replyKind: "cancel_confirmation", output: draft,
            slotsPatch: { selected_target_visit_id: targetId, change_draft: draft, candidate_appointments: candidates }, modelName: null,
          });
        }

        const req = asJson(priorSlots.change_request);
        const reqDate = nullableString(req.date_iso) ?? nullableString(selected.date);
        const reqTime = nullableString(req.time_iso);
        const reqPeriod = nullableString(req.time_period) ?? "unspecified";
        if (!reqDate || (!reqTime && reqPeriod === "unspecified")) {
          const text = lang === "zh" ? `已选择：${candidateLine(selected)}\n请告诉我新的日期和时间，例如「明天下午5点」。`
            : lang === "ms" ? `Dipilih: ${candidateLine(selected)}\nSila beri tarikh dan masa baharu.`
            : `Selected: ${candidateLine(selected)}\nTell me the new date and time.`;
          return await finishChangeState({ intent: "reschedule", stage: "reschedule_awaiting_new_time", state: "reschedule_awaiting_new_time", pendingAction: "collect_reschedule_datetime", replyText: text, replyKind: "reschedule_collect_time", output: { selected }, slotsPatch: { selected_target_visit_id: targetId, target_appointment: selected, change_request: req }, modelName: null });
        }
        const { data: availability, error: availabilityError } = await supabase.rpc("v1369_ai_check_reschedule_availability", {
          p_queue_id: queueId, p_visit_id: targetId, p_date: reqDate, p_time_iso: reqTime, p_time_period: reqPeriod,
        });
        if (availabilityError) throw new Error(`check_reschedule_availability_failed:${availabilityError.message}`);
        const av = asJson(availability);
        const status = String(av.availability_status ?? "");
        if (status === "complex_booking_requires_human") {
          return await finishChangeState({ intent: "reschedule", stage: "reschedule_human_required", state: "reschedule_human_required", pendingAction: "human_reschedule_required", replyText: buildChangeReply(lang, latestTextForState, "reschedule", "reschedule_human_required", { check_reschedule_availability: av }, null).text, replyKind: "reschedule_human_required", output: av, slotsPatch: { selected_target_visit_id: targetId, target_appointment: selected }, modelName: null });
        }
        if (!reqTime) {
          const slots = Array.isArray(av.slots) ? (av.slots as unknown[]).map((x) => nullableString(asJson(x).time)).filter((x): x is string => Boolean(x)) : [];
          return await finishChangeState({ intent: "reschedule", stage: "reschedule_awaiting_slot_selection", state: "reschedule_awaiting_slot_selection", pendingAction: "select_reschedule_time", replyText: rescheduleSlotsText(av, lang), replyKind: "reschedule_slots", output: av, slotsPatch: { selected_target_visit_id: targetId, target_appointment: selected, offered_slots: slots, change_request: { ...req, date_iso: reqDate, time_period: reqPeriod } }, modelName: null });
        }
        const exact = Array.isArray(av.slots) && (av.slots as unknown[]).some((x) => nullableString(asJson(x).time) === reqTime);
        if (status === "available" && exact) {
          const { data: prepared, error: prepareError } = await supabase.rpc("v1369_ai_prepare_change_draft", { p_queue_id: queueId, p_action_type: "reschedule", p_visit_id: targetId, p_date: reqDate, p_time_iso: reqTime, p_time_period: reqPeriod });
          if (prepareError) throw new Error(`prepare_reschedule_change_failed:${prepareError.message}`);
          const draft = asJson(prepared);
          if (draft.ok !== true) throw new Error(`prepare_reschedule_change_failed:${String(draft.error ?? "unknown")}`);
          return await finishChangeState({ intent: "reschedule", stage: "reschedule_awaiting_confirmation", state: "reschedule_awaiting_confirmation", pendingAction: "confirm_reschedule_existing_appointment", replyText: changeDraftSummaryText(draft, lang), replyKind: "reschedule_confirmation", output: draft, slotsPatch: { selected_target_visit_id: targetId, target_appointment: selected, change_draft: draft, change_request: { ...req, date_iso: reqDate, time_iso: reqTime, time_period: reqPeriod } }, modelName: null });
        }
        const slots = Array.isArray(av.slots) ? (av.slots as unknown[]).map((x) => nullableString(asJson(x).time)).filter((x): x is string => Boolean(x)) : [];
        return await finishChangeState({ intent: "reschedule", stage: "reschedule_awaiting_slot_selection", state: "reschedule_awaiting_slot_selection", pendingAction: "select_reschedule_time", replyText: rescheduleSlotsText(av, lang), replyKind: "reschedule_slots", output: av, slotsPatch: { selected_target_visit_id: targetId, target_appointment: selected, offered_slots: slots, change_request: { ...req, date_iso: reqDate, time_period: reqPeriod } }, modelName: null });
      }

      // -----------------------------------------------------------------------
      // v13.6.7 state machine: once a time is selected, profile collection and
      // final confirmation are handled explicitly instead of sending short replies
      // such as "Jimmy" or "确认" through the generic intent router.
      // -----------------------------------------------------------------------
      const profileStates = new Set([
        "appointment_time_selected", "appointment_profile_collecting", "collecting_customer_name",
        "collecting_customer_age", "collecting_customer_ethnicity",
      ]);
      const confirmStates = new Set(["awaiting_booking_confirmation", "appointment_draft_pending_confirmation"]);

      // Confirmation is valid ONLY while the conversation is explicitly waiting
      // for booking confirmation. A durable pending draft may remain in storage while
      // the customer is changing staff/service/time; confirming in those states would
      // accidentally book the OLD draft values.
      if (confirmStates.has(previousStateName) && (previousActiveIntent === "appointment" || Boolean(pendingBookingDraft))) {
        if (isConfirmDraftText(latestTextForState)) {
          const { data: run, error: runError } = await supabase.from("whatsapp_ai_runs").insert({
            organization_id: organizationId, store_id: storeId, queue_id: queueId, conversation_id: conversationId,
            message_id: messageId, stage: "appointment_confirm", provider: "backend", model: null,
            status: "processing", input_snapshot: { command: "confirm", previous_state: previousStateName },
          }).select("id").single();
          if (runError) throw runError;
          runId = String(run.id);
          const { data: confirmed, error: confirmError } = await supabase.rpc("v1367_ai_confirm_draft", { p_queue_id: queueId });
          if (confirmError) throw new Error(`confirm_draft_failed:${confirmError.message}`);
          const result = asJson(confirmed);
          const lang = conversationReplyLanguage(latestTextForState, recentRows, "other");
          if (result.ok === true && ["confirmed", "already_confirmed"].includes(String(result.status ?? ""))) {
            return await finishBookingState({
              stage: "appointment_confirmed", state: "appointment_confirmed", pendingAction: null,
              replyText: confirmedBookingText(result, lang), replyKind: "appointment_confirmed", output: result,
              draft: { draft_id: result.draft_id, visit_id: result.visit_id }, modelName: null, resetTransaction: true,
            });
          }
          if (String(result.error ?? "") === "slot_no_longer_available") {
            const alternatives = asJson(result.alternatives);
            const altSlots = Array.isArray(alternatives.slots)
              ? (alternatives.slots as unknown[]).map((x) => nullableString(asJson(x).time)).filter((x): x is string => Boolean(x)).slice(0, 8)
              : [];
            const prior = asJson(previousState?.slots);
            if (previousState) previousState.slots = { ...prior, offered_slots: altSlots, selected_time: null } as any;
            return await finishBookingState({
              stage: "confirm_slot_unavailable", state: "awaiting_slot_selection", pendingAction: "select_appointment_time",
              replyText: slotUnavailableText(result, lang), replyKind: "slot_no_longer_available", output: result,
              draft: { draft_id: result.draft_id }, modelName: null,
            });
          }
          const err = String(result.error ?? "confirm_failed");
          const text = lang === "zh"
            ? (err === "draft_expired" ? "这份预约草稿已经过期，请重新选择预约时间。" : "这份预约暂时无法确认，我已停止自动落单，请重新确认资料或联系店员。")
            : lang === "ms"
              ? (err === "draft_expired" ? "Draf tempahan ini telah tamat tempoh. Sila pilih masa semula." : "Tempahan ini belum dapat disahkan. Tiada tempahan dibuat secara automatik.")
              : (err === "draft_expired" ? "This booking draft has expired. Please choose a time again." : "I couldn't safely confirm this booking, so no appointment was created.");
          return await finishBookingState({
            stage: "appointment_confirm_failed", state: "appointment_confirm_failed", pendingAction: "review_booking",
            replyText: text, replyKind: "confirm_failed", output: result, draft: { draft_id: result.draft_id }, modelName: null,
          });
        }

        if (isCancelDraftText(latestTextForState)) {
          const { data: run, error: runError } = await supabase.from("whatsapp_ai_runs").insert({
            organization_id: organizationId, store_id: storeId, queue_id: queueId, conversation_id: conversationId,
            message_id: messageId, stage: "appointment_draft_cancel", provider: "backend", model: null,
            status: "processing", input_snapshot: { command: "cancel", previous_state: previousStateName },
          }).select("id").single();
          if (runError) throw runError;
          runId = String(run.id);
          const { data: cancelled, error: cancelError } = await supabase.rpc("v1367_ai_cancel_draft", { p_queue_id: queueId });
          if (cancelError) throw new Error(`cancel_draft_failed:${cancelError.message}`);
          const lang = conversationReplyLanguage(latestTextForState, recentRows, "other");
          const text = lang === "zh" ? "好的，这份预约草稿已经取消，没有建立预约。"
            : lang === "ms" ? "Baik, draf tempahan telah dibatalkan. Tiada tempahan dibuat."
            : "Okay, the booking draft has been cancelled. No appointment was created.";
          return await finishBookingState({
            stage: "appointment_draft_cancelled", state: "appointment_draft_cancelled", pendingAction: null,
            replyText: text, replyKind: "draft_cancelled", output: asJson(cancelled), draft: asJson(cancelled), modelName: null, resetTransaction: true,
          });
        }
        // Any other message (e.g. "改4点") falls through to the normal appointment
        // intent/tool pipeline so the customer can revise the booking before confirming.
      }

      if (!freshBookingRestart
          && previousActiveIntent === "appointment" && profileStates.has(previousStateName)
          && !appointmentStaffChoiceSignal(latestTextForState)
          && !hasNamedStaffRevisionSignal(latestTextForState)
          && !hasServiceRevisionSignal(latestTextForState)
          && !hasDraftRevisionSignal(latestTextForState)) {
        const { data: run, error: runError } = await supabase.from("whatsapp_ai_runs").insert({
          organization_id: organizationId, store_id: storeId, queue_id: queueId, conversation_id: conversationId,
          message_id: messageId, stage: "booking_profile", provider, model, status: "processing",
          input_snapshot: { previous_state: previousStateName, latest_message: latestTextForState },
        }).select("id").single();
        if (runError) throw runError;
        runId = String(run.id);

        const { data: ensured, error: ensureError } = await supabase.rpc("v1367_ai_ensure_draft", { p_queue_id: queueId });
        if (ensureError) throw new Error(`ensure_draft_failed:${ensureError.message}`);
        let draft = asJson(ensured);
        if (draft.ok !== true) {
          const lang = conversationReplyLanguage(latestTextForState, recentRows, "other");
          const text = String(draft.error ?? "") === "selected_slot_no_longer_available"
            ? (lang === "zh" ? "刚才选择的时间已经没有空位了，请重新告诉我想要的时间。" : lang === "ms" ? "Slot tadi sudah tidak tersedia. Sila pilih masa semula." : "That time is no longer available. Please choose a new time.")
            : (lang === "zh" ? "我暂时无法安全建立预约草稿，请重新选择预约时间。" : lang === "ms" ? "Saya belum dapat menyediakan draf dengan selamat. Sila pilih masa semula." : "I couldn't safely prepare the booking draft. Please choose the time again.");
          return await finishBookingState({
            stage: "draft_prepare_failed", state: "awaiting_slot_selection", pendingAction: "select_appointment_time",
            replyText: text, replyKind: "draft_prepare_failed", output: draft, draft, modelName: null,
          });
        }

        let nextField = nullableString(draft.next_profile_field);
        let extracted: ProfileResult | null = null;
        if (nextField) {
          // Profile collection is deterministic by design. The backend already knows which
          // single field it asked for, so name/age/ethnicity must be parsed only from the
          // customer's explicit latest reply. This avoids LLM inference of sensitive data,
          // removes an unnecessary model call, and prevents structured-output failures.
          extracted = extractProfileDeterministic(nextField, latestTextForState);

          const provided = nextField === "name" ? Boolean(extracted.name)
            : nextField === "age" ? Boolean(extracted.reported_age || extracted.age_range || extracted.skip_age)
            : Boolean(extracted.ethnicity || extracted.skip_ethnicity);
          const lang = conversationReplyLanguage(latestTextForState, recentRows, extracted.language);
          if (!provided) {
            const customer = asJson(draft.customer);
            return await finishBookingState({
              stage: `collect_customer_${nextField}`, state: `collecting_customer_${nextField}`, pendingAction: `collect_customer_${nextField}`,
              replyText: profileQuestion(nextField, lang, nullableString(customer.name), true), replyKind: `collect_${nextField}_retry`,
              output: { draft, extracted, requested_field: nextField }, draft, modelName: null,
            });
          }

          const { data: updated, error: updateError } = await supabase.rpc("v1367_ai_update_draft_profile", {
            p_queue_id: queueId,
            p_name: extracted.name,
            p_reported_age: extracted.reported_age,
            p_age_range: extracted.age_range,
            p_skip_age: extracted.skip_age,
            p_ethnicity: extracted.ethnicity,
            p_skip_ethnicity: extracted.skip_ethnicity,
          });
          if (updateError) throw new Error(`update_draft_profile_failed:${updateError.message}`);
          draft = asJson(updated);
          nextField = nullableString(draft.next_profile_field);
          if (draft.ok !== true) throw new Error(`update_draft_profile_failed:${String(draft.error ?? "unknown")}`);

          if (nextField) {
            const customer = asJson(draft.customer);
            return await finishBookingState({
              stage: `collect_customer_${nextField}`, state: `collecting_customer_${nextField}`, pendingAction: `collect_customer_${nextField}`,
              replyText: profileQuestion(nextField, lang, nullableString(customer.name), false), replyKind: `collect_${nextField}`,
              output: { draft, extracted }, draft, modelName: null,
            });
          }
          return await finishBookingState({
            stage: "appointment_draft_pending_confirmation", state: "awaiting_booking_confirmation", pendingAction: "confirm_appointment_draft",
            replyText: draftSummaryText(draft, lang), replyKind: "appointment_draft_summary",
            output: { draft, extracted }, draft, modelName: null,
          });
        }

        const lang = conversationReplyLanguage(latestTextForState, recentRows, "other");
        return await finishBookingState({
          stage: "appointment_draft_pending_confirmation", state: "awaiting_booking_confirmation", pendingAction: "confirm_appointment_draft",
          replyText: draftSummaryText(draft, lang), replyKind: "appointment_draft_summary",
          output: { draft }, draft, modelName: null,
        });
      }

      const modelPayload: Json = {
        timezone: "Asia/Kuala_Lumpur",
        current_local_datetime: localNow("Asia/Kuala_Lumpur"),
        latest_message: {
          type: message.message_type,
          text: message.text_body ?? "",
          received_at: message.received_at,
        },
        // A fresh booking is intentionally context-isolated. Historical messages
        // remain available in the database, but they are not allowed to donate a
        // date or appointment reference to this new transaction.
        recent_conversation: freshBookingRestart ? [] : (recentMessages ?? []).slice().reverse().map((m: Json) => ({
          direction: m.direction,
          type: m.message_type,
          text: m.text_body ?? "",
          intent: m.ai_intent ?? null,
          at: m.received_at,
        })),
        previous_state: freshBookingRestart ? null : (previousStateForBookingFlow ? {
          state: previousStateForBookingFlow.state,
          active_intent: previousStateForBookingFlow.active_intent,
          pending_action: previousStateForBookingFlow.pending_action,
          slots: previousStateForBookingFlow.slots,
        } : null),
        customer_summary: {
          status: customerSummary.customer_status ?? "unknown",
          completed_visit_count: customerSummary.completed_visit_count ?? 0,
          favourite_service: customerSummary.favourite_service ?? null,
          dominant_stylist: customerSummary.dominant_stylist ?? null,
          missing_fields: customerSummary.missing_fields ?? [],
          attribution_status: ((customerSummary.attribution as Json | undefined)?.status ?? "unknown"),
        },
      };

      // v13.6.10.28: appointment staff follow-ups are deterministic before the LLM.
      // This covers contextual messages such as "换个人", "have another stylist?",
      // "谁可以做", and "random" while preserving the current service/date/time.
      const staffChoiceSignalForRouting = appointmentStaffChoiceSignal(String(message.text_body ?? ""));
      const deterministicStaffSelection = appointmentAlternativeSelectionIntent(
        String(message.text_body ?? ""),
        freshBookingRestart ? null : previousStateForBookingFlow,
      );
      const staffFollowupContextState = freshBookingRestart
        ? null
        : (previousActiveIntent === "appointment" || pendingBookingDraft)
          ? (previousStateForBookingFlow ?? recentAppointmentContextState)
          : (recentAppointmentContextState ?? previousStateForBookingFlow);
      const deterministicStaffFollowup = deterministicStaffSelection
        ? null
        : appointmentStaffFollowupCommand(
            String(message.text_body ?? ""),
            String(modelPayload.current_local_datetime ?? localNow("Asia/Kuala_Lumpur")),
            staffFollowupContextState,
            pendingBookingDraft,
          );

      // Explicit cancel/reschedule commands and booking-draft date/time revisions are
      // deterministic too. Staff-followup routing wins because changing the stylist
      // on an UNCONFIRMED/new booking must never become an existing-booking reschedule.
      const deterministicDraftRevision = (deterministicStaffSelection || deterministicStaffFollowup)
        ? null
        : pendingBookingDraft
          ? pendingDraftRevisionIntent(
              String(message.text_body ?? ""),
              String(modelPayload.current_local_datetime ?? localNow("Asia/Kuala_Lumpur")),
              pendingBookingDraft,
            )
          : null;

      const deterministicChange = (deterministicStaffSelection || deterministicStaffFollowup || deterministicDraftRevision)
        ? null
        : deterministicChangeCommand(
            String(message.text_body ?? ""),
            String(modelPayload.current_local_datetime ?? localNow("Asia/Kuala_Lumpur")),
          );
      const detectionProvider = (deterministicStaffSelection || deterministicStaffFollowup || deterministicDraftRevision || deterministicChange) ? "backend" : provider;
      const detectionModel = (deterministicStaffSelection || deterministicStaffFollowup || deterministicDraftRevision || deterministicChange) ? null : model;

      const { data: run, error: runError } = await supabase.from("whatsapp_ai_runs").insert({
        organization_id: organizationId,
        store_id: storeId,
        queue_id: queueId,
        conversation_id: conversationId,
        message_id: messageId,
        stage: "intent_tools_reply",
        provider: detectionProvider,
        model: detectionModel,
        status: "processing",
        input_snapshot: {
          ...modelPayload,
          deterministic_change_router: deterministicChange ? true : false,
          deterministic_draft_revision_router: deterministicDraftRevision ? true : false,
          deterministic_staff_selection_router: deterministicStaffSelection ? true : false,
          deterministic_staff_followup_router: deterministicStaffFollowup ? true : false,
          staff_choice_signal: staffChoiceSignalForRouting,
          fresh_booking_restart: freshBookingRestart,
          fresh_restart_abandoned_draft: freshRestartAbandonedDraft,
          staff_preference_revision_abandoned_draft: staffPreferenceRevisionAbandonedDraft,
          explicit_date_in_latest_message: hasExplicitAppointmentDate(latestTextForState),
          prior_date_provenance: String(asJson(previousStateForBookingFlow?.slots).date_provenance ?? ""),
          booking_draft_lookup: {
            source: draftLookupSource,
            error: draftLookupError,
            draft_id: nullableString(latestBookingDraft?.id) ?? nullableString(latestBookingDraft?.draft_id),
            draft_status: nullableString(latestBookingDraft?.status),
            state_snapshot_present: Boolean(stateDraftCandidate),
            historical_snapshot_present: Boolean(historicalDraftCandidate),
            historical_source: historicalDraftSource,
            historical_supersedes_terminal: historicalSupersedesTerminal,
          },
        },
      }).select("id").single();
      if (runError) throw runError;
      runId = String(run.id);

      const detected = deterministicStaffSelection
        ? {
            result: deterministicStaffSelection,
            raw: {
              deterministic: true,
              router: "appointment_staff_alternative_selection_v1361028",
              staff_name: deterministicStaffSelection.entities.staff_name,
            } as Json,
            responseId: null,
          }
        : deterministicStaffFollowup
          ? {
            result: deterministicStaffFollowup.result,
            raw: {
              deterministic: true,
              router: "appointment_staff_followup_v1361028",
              mode: deterministicStaffFollowup.mode,
              exclude_staff_name: deterministicStaffFollowup.excludeStaffName,
              source_staff_name: deterministicStaffFollowup.sourceStaffName,
              reason: deterministicStaffFollowup.reason,
            } as Json,
            responseId: null,
          }
        : deterministicDraftRevision
          ? {
              result: deterministicDraftRevision,
              raw: {
                deterministic: true,
                router: "pending_booking_draft_revision_v1361028",
                draft_id: pendingBookingDraft?.id ?? null,
                draft_reactivated: pendingDraftNeedsReactivation,
              } as Json,
              responseId: null,
            }
          : deterministicChange
            ? { result: deterministicChange, raw: { deterministic: true, router: "change_command_v1369_2" } as Json, responseId: null }
          : provider === "groq"
            ? await detectIntentGroq(groqKey, model, modelPayload)
            : await detectIntentOpenAI(openAiKey, model, modelPayload);

      // v13.6.10.31: deterministic entity repair runs after the model but before
      // routing/merge. The model can concatenate a real employee name with a Chinese
      // service phrase (for example "weihong染头发") and then incorrectly feed the
      // combined string to resolve_service. We verify employee names against the
      // current branch, independently recognize common service phrases, and keep the
      // two entities separate before any service/staff tool is called.
      const latestTextForEntityRepair = String(message.text_body ?? "");
      const deterministicServiceForEntityRepair = deterministicServiceHint(latestTextForEntityRepair);
      const explicitPreferenceForEntityRepair = explicitStaffPreference(latestTextForEntityRepair);
      const branchStaffScan = await detectBranchStaffMention(
        supabase,
        organizationId,
        storeId,
        latestTextForEntityRepair,
      );
      const branchStaffMention = branchStaffScan.mention;
      const bookingSyntaxForEntityRepair = /\b(book|booking|appointment|reserve|reservation)\b|预约|預約|约个|約個|tempah|janji\s*temu/i.test(latestTextForEntityRepair);
      const timeSyntaxForEntityRepair = /(?:上午|早上|下午|午后|午後|晚上|夜晚)?\s*(?:\d{1,2}|[一二两兩三四五六七八九十]{1,3})\s*(?:点|點|時|时)|\b\d{1,2}(?::[0-5]\d)?\s*(?:am|pm)\b/i.test(latestTextForEntityRepair);

      if (deterministicServiceForEntityRepair
          && (detected.result.intent === "appointment" || bookingSyntaxForEntityRepair || timeSyntaxForEntityRepair)) {
        detected.result.entities.service_text = deterministicServiceForEntityRepair.service_text;
        detected.result.entities.service_search_terms = deterministicServiceForEntityRepair.service_search_terms;
      }

      if (branchStaffMention
          && explicitPreferenceForEntityRepair !== "no_preference"
          && !staffChoiceSignalForRouting) {
        detected.result.entities.staff_name = branchStaffMention.name;
        detected.result.entities.staff_preference = "specified";
      }

      // A model may copy the employee from an older assistant summary even when
      // the customer's latest reply is only "today" or "7 PM". A current-turn
      // employee is trusted only when the name is actually present in the message;
      // a legitimate prior employee can still be carried by the appointment state.
      if (!branchStaffMention
          && detected.result.entities.staff_name
          && !messageContainsStaffName(latestTextForEntityRepair, detected.result.entities.staff_name)) {
        detected.result.entities.staff_name = null;
      }

      // A generic request such as "我要指定理发师" selects the choice mode, not
      // any employee. Never let the model copy a stylist name from the old draft.
      if (!branchStaffMention && isGenericSpecifiedStylistRequest(latestTextForEntityRepair)) {
        detected.result.entities.staff_name = null;
        detected.result.entities.staff_preference = "specified";
      }

      if (branchStaffMention && deterministicServiceForEntityRepair
          && (bookingSyntaxForEntityRepair || timeSyntaxForEntityRepair || detected.result.intent === "appointment")) {
        detected.result.intent = "appointment";
      }

      // v13.6.10.56 — common price questions are deterministic enough to route
      // safely. This prevents "染发多少钱 / how much is hair coloring" from
      // falling into the generic unsupported-message reply when a model misses it.
      if (deterministicServiceForEntityRepair
          && /(?:多少钱|多少錢|价格|價格|收费|收費|how\s*much|price|cost|harga|berapa)/i.test(latestTextForEntityRepair)
          && !bookingSyntaxForEntityRepair) {
        detected.result.intent = "price_enquiry";
      }

      const latestMessageHasExplicitDate = hasExplicitAppointmentDate(latestTextForEntityRepair);
      const deterministicDateForEntityRepair = deterministicAppointmentDateHint(
        latestTextForEntityRepair,
        String(modelPayload.current_local_datetime ?? localNow("Asia/Kuala_Lumpur")),
      );
      const deterministicTemporalForEntityRepair = deterministicAppointmentTemporalHint(
        latestTextForEntityRepair,
        String(modelPayload.current_local_datetime ?? localNow("Asia/Kuala_Lumpur")),
      );
      const informationalAppointmentSlotFollowup = isInformationalAppointmentSlotFollowup(
        latestTextForEntityRepair,
        freshBookingRestart ? null : (previousState ? previousState as Json : null),
        deterministicTemporalForEntityRepair,
      );
      const informationalServiceSlotContext = ["price_enquiry", "service_enquiry"].includes(detected.result.intent)
        && Boolean(deterministicServiceForEntityRepair || detected.result.entities.service_text);
      const appointmentDateContext = Boolean(
        detected.result.intent === "appointment"
        || previousActiveIntent === "appointment"
        || pendingBookingDraft
        || bookingSyntaxForEntityRepair
        || informationalServiceSlotContext
        || informationalAppointmentSlotFollowup
      );
      if (deterministicDateForEntityRepair && appointmentDateContext) {
        // v13.6.10.34: latest-turn date wins. This prevents a date-only follow-up
        // such as "明天呢" from inheriting yesterday/today merely because the
        // model omitted date_iso or resolved the relative date incorrectly.
        detected.result.entities.date_text = deterministicDateForEntityRepair.date_text;
        detected.result.entities.date_iso = deterministicDateForEntityRepair.date_iso;
        if (["other", "staff_enquiry"].includes(detected.result.intent) && previousActiveIntent === "appointment") {
          detected.result.intent = "appointment";
        }
      }
      // v13.6.10.56 — exact time/daypart repair for short conversational
      // follow-ups. The deterministic parser is reused without giving it write
      // authority: it only repairs entities such as "7点", "下午三点", or
      // "今晚" when an appointment conversation is already active.
      if (deterministicTemporalForEntityRepair && appointmentDateContext) {
        const te = deterministicTemporalForEntityRepair.entities;
        if (te.time_text) detected.result.entities.time_text = te.time_text;
        if (te.time_iso) detected.result.entities.time_iso = te.time_iso;
        if (te.time_period !== "unspecified") detected.result.entities.time_period = te.time_period;
      }

      // "现在 / now / sekarang" is a concrete booking-time request. Treat it
      // as today and use the current local clock minute rather than asking the
      // customer for a date they have already implied.
      if (appointmentDateContext && /(?:现在|現在|马上|馬上|now|sekarang)/i.test(latestTextForEntityRepair)) {
        const local = String(modelPayload.current_local_datetime ?? localNow("Asia/Kuala_Lumpur"));
        const hhmm = local.slice(11, 16);
        detected.result.entities.date_text = detected.result.entities.date_text ?? "today";
        detected.result.entities.date_iso = detected.result.entities.date_iso ?? isoDateAddDays(local, 0);
        detected.result.entities.time_text = detected.result.entities.time_text ?? latestTextForEntityRepair;
        detected.result.entities.time_iso = detected.result.entities.time_iso ?? hhmm;
      }

      const explicitDateResolvedThisTurn = Boolean(
        latestMessageHasExplicitDate && nullableString(detected.result.entities.date_iso),
      );
      const priorSlotsForDateTrust = asJson(previousState?.slots);
      const priorDateProvenanceForRepair = String(priorSlotsForDateTrust.date_provenance ?? "");
      const canCarryDateFromCurrentBooking = !freshBookingRestart
        && Boolean(
          pendingBookingDraft
          || ["customer_explicit", "draft_authoritative", "carried_same_transaction"].includes(priorDateProvenanceForRepair)
        );
      if (!latestMessageHasExplicitDate && !canCarryDateFromCurrentBooking) {
        // LLMs are not allowed to turn "3 PM" into "today at 3 PM". A date is
        // business-critical and must either be explicitly stated by the customer or
        // come from the SAME active unconfirmed booking transaction.
        detected.result.entities.date_text = null;
        detected.result.entities.date_iso = null;
      } else if (latestMessageHasExplicitDate && !explicitDateResolvedThisTurn) {
        // The customer clearly tried to change/specify a date, but this turn could
        // not safely resolve it. Do NOT fall back to the prior date. The appointment
        // pipeline will ask for the date again instead of silently booking/checking
        // the wrong day.
        detected.result.entities.date_text = null;
        detected.result.entities.date_iso = null;
      }
      if (freshBookingRestart) {
        // A new booking cannot target or inherit an old booking reference.
        detected.result.entities.appointment_reference = null;
      }

      const detectedRawForRepair = asJson(detected.raw);
      detectedRawForRepair.entity_repair_v1361033 = {
        branch_staff_mention: branchStaffMention,
        branch_staff_scan_error: branchStaffScan.error,
        deterministic_service_hint: deterministicServiceForEntityRepair,
        explicit_staff_preference: explicitPreferenceForEntityRepair,
        fresh_booking_restart: freshBookingRestart,
        latest_message_has_explicit_date: latestMessageHasExplicitDate,
        deterministic_date_hint: deterministicDateForEntityRepair,
        deterministic_temporal_hint: deterministicTemporalForEntityRepair ?? null,
        informational_appointment_slot_followup: informationalAppointmentSlotFollowup,
        informational_service_slot_context: informationalServiceSlotContext,
        explicit_date_resolved_this_turn: explicitDateResolvedThisTurn,
        can_carry_date_from_current_booking: canCarryDateFromCurrentBooking,
      };

      let intent = detected.result.intent;
      const rawPreviousStateJson = previousStateForBookingFlow;
      const rawPreviousSlots = asJson(rawPreviousStateJson?.slots);
      const priorDateProvenance = String(rawPreviousSlots.date_provenance ?? "");
      const priorDateTrusted = Boolean(
        !freshBookingRestart
        && (pendingBookingDraft
          || ["customer_explicit", "draft_authoritative", "carried_same_transaction"].includes(priorDateProvenance))
      );
      const previousStateJson: Json | null = freshBookingRestart
        ? null
        : rawPreviousStateJson
          ? {
              ...rawPreviousStateJson,
              // If the latest message explicitly mentions a date but that date was
              // not safely resolved, the old date is forbidden from participating
              // in mergeAppointmentEntities. This closes the .32 provenance hole
              // where "明天呢" could accidentally re-use today's date.
              slots: (latestMessageHasExplicitDate && !explicitDateResolvedThisTurn)
                ? { ...rawPreviousSlots, date_text: null, date_iso: null }
                : priorDateTrusted
                  ? rawPreviousSlots
                  : { ...rawPreviousSlots, date_text: null, date_iso: null },
            }
          : null;
      const priorSlotsForStaffChoice = asJson(previousStateJson?.slots);
      const explicitPreferenceForRouting = explicitStaffPreference(String(message.text_body ?? ""));
      const hasAppointmentFollowupEntity = Boolean(
        detected.result.entities.time_iso || detected.result.entities.date_iso ||
        detected.result.entities.service_text || detected.result.entities.staff_name ||
        detected.result.entities.staff_preference !== "unknown" || explicitPreferenceForRouting,
      );
      const prevIntentForRouting = String(previousStateJson?.active_intent ?? "");
      const prevStateForRouting = String(previousStateJson?.state ?? "");
      const pendingDraftBookingRevision = Boolean(
        pendingBookingDraft && (
          deterministicStaffFollowup || deterministicDraftRevision || staffChoiceSignalForRouting
          || hasNamedStaffRevisionSignal(String(message.text_body ?? ""))
          || hasServiceRevisionSignal(String(message.text_body ?? ""))
          || (detected.result.intent === "appointment" && hasAppointmentFollowupEntity)
        )
      );
      if (["other", "staff_enquiry"].includes(intent) && prevIntentForRouting === "appointment" && hasAppointmentFollowupEntity) {
        intent = "appointment";
      }
      // v13.6.10.57 — a short date/time answer to the worker's service-price or
      // service/staff follow-up is a booking continuation. Promote it even when
      // the model labels a neutral token such as "7pm" as `other`.
      if (informationalAppointmentSlotFollowup
          && ["other", "appointment", "price_enquiry", "service_enquiry", "staff_enquiry"].includes(intent)) {
        intent = "appointment";
      }
      // v13.6.10.28: "who can do it / another stylist" is a booking choice request,
      // even when the model calls it staff_enquiry/other. If booking context is absent,
      // the appointment flow will safely ask for service/date instead of sending the
      // generic unsupported-message fallback.
      if (staffChoiceSignalForRouting && ["other", "staff_enquiry"].includes(intent)) {
        intent = "appointment";
      }
      const priorPreferenceStaffSuggestion = nullableString(asJson(previousStateJson?.slots).preference_staff_suggestion);
      if (intent === "other" && prevIntentForRouting === "appointment"
          && priorPreferenceStaffSuggestion && confirmsSuggestedStylist(String(message.text_body ?? ""))) {
        intent = "appointment";
      }
      // v13.6.10.27 — an unconfirmed booking-draft revision has higher routing
      // precedence than continuity from a stale reschedule_* state. In .23-.26,
      // deterministicDraftRevision correctly produced intent=appointment, but this
      // continuity rule immediately overwrote it back to reschedule whenever the
      // previous turn was reschedule_not_found. That recreated the exact same
      // future-appointment/self-service reply even after the draft had been found.
      if (!pendingDraftBookingRevision
          && !(deterministicStaffFollowup || deterministicDraftRevision)
          && ["other", "appointment"].includes(intent)
          && prevIntentForRouting === "reschedule"
          && (prevStateForRouting.startsWith("reschedule_") || hasAppointmentFollowupEntity)) {
        intent = "reschedule";
      }
      if (pendingDraftBookingRevision || ((deterministicStaffFollowup || deterministicDraftRevision) && pendingBookingDraft)) {
        intent = "appointment";
      }
      let effectiveEntities = intent === "appointment"
        ? mergeAppointmentEntities(
            detected.result.entities,
            previousStateJson,
            intent,
            informationalAppointmentSlotFollowup,
          )
        : mergeChangeEntities(detected.result.entities, previousStateJson, intent);
      const effectiveDateProvenance = effectiveEntities.date_iso
        ? (explicitDateResolvedThisTurn
          ? "customer_explicit"
          : intent === "appointment" && pendingBookingDraft
            ? "draft_authoritative"
            : intent === "appointment" && priorDateTrusted
              ? "carried_same_transaction"
              : null)
        : null;

      let staffChoiceMode: AppointmentStaffChoiceMode | null = deterministicStaffFollowup?.mode ?? null;
      let excludedStaffName: string | null = deterministicStaffFollowup?.excludeStaffName ?? null;
      const priorStaffChoiceModeRaw = String(priorSlotsForStaffChoice.staff_choice_mode ?? "");
      const priorStaffChoiceMode = ["random_assign", "list_alternatives"].includes(priorStaffChoiceModeRaw)
        ? priorStaffChoiceModeRaw as AppointmentStaffChoiceMode
        : null;
      const priorExcludedStaffName = nullableString(priorSlotsForStaffChoice.excluded_staff_name);

      if (intent === "appointment") {
        const explicitPreference = explicitPreferenceForRouting;
        const currentSignal = staffChoiceSignalForRouting;
        const currentPreferenceIsGrounded = Boolean(
          explicitPreference || currentSignal || deterministicStaffFollowup || deterministicStaffSelection
          || detected.result.entities.staff_name,
        );
        // The model cannot invent specified/no-preference from a date/time-only
        // reply. Reuse a trusted choice from this transaction, otherwise ask.
        effectiveEntities = {
          ...effectiveEntities,
          staff_preference: groundedAppointmentStaffPreference(
            effectiveEntities.staff_preference,
            Boolean(effectiveEntities.staff_name),
            priorSlotsForStaffChoice.staff_preference,
            currentPreferenceIsGrounded,
          ),
        };
        if (!staffChoiceMode && currentSignal) staffChoiceMode = currentSignal.mode;
        if (!excludedStaffName && currentSignal?.excludePrevious) {
          excludedStaffName = nullableString(priorSlotsForStaffChoice.staff_name)
            ?? nullableString(asJson(asJson(asJson(priorSlotsForStaffChoice.appointment_tools).resolve_staff).staff).name)
            ?? nullableString(asJson(priorSlotsForStaffChoice.booking_draft).employee_name_snapshot);
        }
        if (!staffChoiceMode && priorStaffChoiceMode && !effectiveEntities.staff_name) {
          staffChoiceMode = priorStaffChoiceMode;
          excludedStaffName = excludedStaffName ?? priorExcludedStaffName;
        }

        if (deterministicStaffFollowup || currentSignal || staffChoiceMode) {
          effectiveEntities = { ...effectiveEntities, staff_name: null, staff_preference: "no_preference" };
        } else if (explicitPreference === "no_preference") {
          effectiveEntities = { ...effectiveEntities, staff_name: null, staff_preference: "no_preference" };
        } else if (effectiveEntities.staff_name) {
          effectiveEntities = { ...effectiveEntities, staff_preference: "specified" };
        } else if (explicitPreference === "specified") {
          effectiveEntities = { ...effectiveEntities, staff_preference: "specified" };
        }

        // A direct named stylist selection ends the temporary "show alternatives"
        // mode. A later "random" command explicitly starts random assignment again.
        if (detected.result.entities.staff_name && !deterministicStaffFollowup) {
          staffChoiceMode = null;
          excludedStaffName = null;
          effectiveEntities = { ...effectiveEntities, staff_name: detected.result.entities.staff_name, staff_preference: "specified" };
        }
      } else {
        staffChoiceMode = null;
        excludedStaffName = null;
      }

      // Existing-customer continuity: the favourite service may be reused only
      // when the customer explicitly says "same as last time". A dominant stylist
      // is NEVER silently converted into a new "specified stylist" booking because
      // that would corrupt the user's specified-vs-random marketing analytics.
      // Instead we store it as a suggestion and accept a short contextual yes only
      // after the previous reply explicitly asked whether to use that stylist again.
      let preferenceStaffSuggestion: string | null = null;
      if (intent === "appointment") {
        const intel = asJson(customerSummary.customer_intelligence);
        const favourite = nullableString(intel.favourite_service);
        const dominant = asJson(intel.dominant_stylist);
        const dominantName = nullableString(dominant.name);
        const completedCount = Number(intel.completed_visit_count ?? 0);
        if (!effectiveEntities.service_text && favourite && wantsSameAsLast(String(message.text_body ?? ""))) {
          effectiveEntities = { ...effectiveEntities, service_text: favourite, service_search_terms: [favourite] };
        }
        const priorSuggestion = nullableString(asJson(previousStateJson?.slots).preference_staff_suggestion);
        if (!effectiveEntities.staff_name && priorSuggestion && confirmsSuggestedStylist(String(message.text_body ?? ""))) {
          effectiveEntities = { ...effectiveEntities, staff_name: priorSuggestion, staff_preference: "specified" };
        }
        if (completedCount > 0 && effectiveEntities.service_text && !effectiveEntities.staff_name
            && effectiveEntities.staff_preference !== "no_preference" && dominantName) {
          preferenceStaffSuggestion = dominantName;
        }
      }
      const action = pendingAction(intent);
      const detectedAt = new Date().toISOString();

      const runTool = async (toolName: string, rpcName: string, input: Json): Promise<Json> => {
        const toolStarted = Date.now();
        const { data, error } = await supabase.rpc(rpcName, input);
        if (error) {
          await supabase.from("whatsapp_ai_tool_runs").insert({
            organization_id: organizationId, store_id: storeId, queue_id: queueId,
            conversation_id: conversationId, message_id: messageId, tool_name: toolName, status: "failed",
            input_snapshot: input, output_snapshot: {}, error: error.message, duration_ms: Date.now() - toolStarted,
          });
          throw new Error(`${toolName}_failed:${error.message}`);
        }
        const output = ((data ?? {}) as Json);
        await supabase.from("whatsapp_ai_tool_runs").insert({
          organization_id: organizationId, store_id: storeId, queue_id: queueId,
          conversation_id: conversationId, message_id: messageId, tool_name: toolName, status: "completed",
          input_snapshot: input, output_snapshot: output, duration_ms: Date.now() - toolStarted,
        });
        return output;
      };

      let pipelineStage = "intent_detected";
      let finalAction = action;
      let appointmentTools: Json | null = null;
      let changeDraft: Json | null = null;

      if (intent === "cancel") {
        const found = await runTool("find_upcoming_appointments", "v1369_ai_find_upcoming_appointments", {
          p_queue_id: queueId,
          p_reference: detected.result.entities.appointment_reference,
          p_date: effectiveEntities.date_iso,
          p_time_iso: effectiveEntities.time_iso,
        });
        appointmentTools = { find_upcoming_appointments: found };
        const resolution = String(found.resolution_status ?? "not_found");
        const candidates = candidateArray(found);
        if (resolution === "not_found") {
          pipelineStage = "cancel_not_found"; finalAction = "await_booking_reference_or_staff";
        } else if (resolution === "multiple") {
          pipelineStage = "cancel_selecting_appointment"; finalAction = "select_existing_appointment";
        } else {
          const candidate = candidates[0] ?? asJson(found.appointment);
          const targetId = nullableString(candidate.visit_id);
          if (!targetId) throw new Error("cancel_target_visit_missing");
          const prepared = await runTool("prepare_cancel_change", "v1369_ai_prepare_change_draft", {
            p_queue_id: queueId, p_action_type: "cancel", p_visit_id: targetId, p_date: null, p_time_iso: null, p_time_period: "unspecified",
          });
          changeDraft = prepared;
          if (prepared.ok !== true) {
            pipelineStage = "cancel_not_found"; finalAction = "await_booking_reference_or_staff";
          } else {
            pipelineStage = "cancel_awaiting_confirmation"; finalAction = "confirm_cancel_existing_appointment";
          }
        }
      } else if (intent === "reschedule") {
        const priorSlots = asJson(previousState?.slots);
        let targetId = nullableString(priorSlots.selected_target_visit_id);
        let target = asJson(priorSlots.target_appointment);
        let found: Json | null = null;

        // v13.6.9.4 stale-target guard. Conversation slots are persistent by design,
        // so an older cancel/reschedule target may survive into a later booking unless
        // explicitly cleared. Before trusting a carried target UUID, re-resolve it through
        // the tenant-scoped FUTURE + BOOKED lookup. If it is no longer eligible, discard it
        // and locate the customer's current appointment instead.
        if (targetId) {
          const priorReference = nullableString(target.visit_number);
          const validated = await runTool("validate_reschedule_target", "v1369_ai_find_upcoming_appointments", {
            p_queue_id: queueId,
            p_reference: priorReference,
            p_date: null,
            p_time_iso: null,
          });
          appointmentTools = { validate_reschedule_target: validated };
          const validCandidates = candidateArray(validated);
          const validatedTarget = validCandidates.find((c) => nullableString(c.visit_id) === targetId) ?? null;
          if (validatedTarget) {
            target = validatedTarget;
          } else {
            targetId = null;
            target = {};
          }
        }

        if (!targetId) {
          found = await runTool("find_upcoming_appointments", "v1369_ai_find_upcoming_appointments", {
            p_queue_id: queueId,
            p_reference: detected.result.entities.appointment_reference,
            p_date: null,
            p_time_iso: null,
          });
          appointmentTools = { ...asJson(appointmentTools), find_upcoming_appointments: found };
          const resolution = String(found.resolution_status ?? "not_found");
          const candidates = candidateArray(found);
          if (resolution === "not_found") {
            pipelineStage = "reschedule_not_found"; finalAction = "await_booking_reference_or_staff";
          } else if (resolution === "multiple") {
            pipelineStage = "reschedule_selecting_appointment"; finalAction = "select_existing_appointment";
          } else {
            target = candidates[0] ?? asJson(found.appointment);
            targetId = nullableString(target.visit_id);
          }
        }

        if (targetId && !["reschedule_not_found", "reschedule_selecting_appointment"].includes(pipelineStage)) {
          if (target.can_self_reschedule === false || Number(target.employee_count ?? 1) !== 1) {
            pipelineStage = "reschedule_human_required"; finalAction = "human_reschedule_required";
            appointmentTools = { ...asJson(appointmentTools), target_appointment: target };
          } else {
            const newDate = effectiveEntities.date_iso ?? nullableString(target.date);
            const newTime = effectiveEntities.time_iso;
            const period = effectiveEntities.time_period;
            appointmentTools = { ...asJson(appointmentTools), target_appointment: target };
            if (!newDate || (!newTime && period === "unspecified")) {
              pipelineStage = "reschedule_awaiting_new_time"; finalAction = "collect_reschedule_datetime";
            } else {
              const availability = await runTool("check_reschedule_availability", "v1369_ai_check_reschedule_availability", {
                p_queue_id: queueId, p_visit_id: targetId, p_date: newDate, p_time_iso: newTime, p_time_period: period,
              });
              appointmentTools = { ...asJson(appointmentTools), check_reschedule_availability: availability };
              const avStatus = String(availability.availability_status ?? "unknown");
              if (avStatus === "complex_booking_requires_human") {
                pipelineStage = "reschedule_human_required"; finalAction = "human_reschedule_required";
              } else if (!newTime) {
                pipelineStage = "reschedule_awaiting_slot_selection"; finalAction = "select_reschedule_time";
              } else {
                const exact = Array.isArray(availability.slots)
                  && (availability.slots as unknown[]).some((x) => nullableString(asJson(x).time) === newTime);
                if (avStatus === "available" && exact) {
                  const prepared = await runTool("prepare_reschedule_change", "v1369_ai_prepare_change_draft", {
                    p_queue_id: queueId, p_action_type: "reschedule", p_visit_id: targetId, p_date: newDate, p_time_iso: newTime, p_time_period: period,
                  });
                  changeDraft = prepared;
                  if (prepared.ok === true) {
                    pipelineStage = "reschedule_awaiting_confirmation"; finalAction = "confirm_reschedule_existing_appointment";
                  } else {
                    pipelineStage = "reschedule_awaiting_slot_selection"; finalAction = "select_reschedule_time";
                  }
                } else {
                  // Exact requested time is busy. Fetch safe alternatives in the same conversational period.
                  const alternatives = await runTool("check_reschedule_alternatives", "v1369_ai_check_reschedule_availability", {
                    p_queue_id: queueId, p_visit_id: targetId, p_date: newDate, p_time_iso: null, p_time_period: period,
                  });
                  appointmentTools = { ...asJson(appointmentTools), check_reschedule_availability: alternatives };
                  pipelineStage = "reschedule_awaiting_slot_selection"; finalAction = "select_reschedule_time";
                }
              }
            }
          }
        }
      } else if (intent === "appointment") {
        const e = effectiveEntities;
        const preference = e.staff_name ? "specified" : e.staff_preference;
        const missing: string[] = [];
        if (!e.service_text) missing.push("service");
        if (!e.date_iso) missing.push("date");
        if (preference === "unknown") missing.push("staff_preference");
        if (preference === "specified" && !e.staff_name) missing.push("staff");

        if (missing.length > 0) {
          pipelineStage = "appointment_requires_info";
          finalAction = `collect_missing:${missing.join(",")}`;
          appointmentTools = { missing_fields: missing, staff_preference: preference };
        } else {
          const serviceResolution = await runTool("resolve_service", "v1365_ai_resolve_service", {
            p_queue_id: queueId,
            p_query: e.service_text,
            p_search_terms: e.service_search_terms,
          });
          appointmentTools = { resolve_service: serviceResolution, staff_preference: preference };

          const serviceStatus = String(serviceResolution.resolution_status ?? "not_found");
          const serviceObj = asJson(serviceResolution.service);
          const serviceId = typeof serviceObj.id === "string" ? serviceObj.id : "";

          if (serviceStatus !== "matched" || !serviceId) {
            pipelineStage = "appointment_needs_resolution";
            finalAction = "clarify_service";
          } else if (preference === "specified") {
            const staffResolution = await runTool("resolve_staff", "v1365_ai_resolve_staff", {
              p_queue_id: queueId,
              p_staff_name: e.staff_name,
            });
            appointmentTools = { ...appointmentTools, resolve_staff: staffResolution };
            let staffStatus = String(staffResolution.resolution_status ?? "not_found");
            const staffCandidates = Array.isArray(staffResolution.candidates)
              ? (staffResolution.candidates as unknown[]).map(asJson)
              : [];
            // v13.6.10.56 — if the resolver returns exactly one real branch
            // candidate, do not ask the customer to choose between one option.
            // Treat that single candidate as the intended stylist.
            let staffObj = asJson(staffResolution.staff);
            if ((staffStatus !== "matched" || !nullableString(staffObj.id)) && staffCandidates.length === 1) {
              staffObj = staffCandidates[0];
              staffStatus = nullableString(staffObj.id) ? "matched" : staffStatus;
              appointmentTools = { ...appointmentTools, resolve_staff: { ...staffResolution, resolution_status: staffStatus, staff: staffObj } };
            }
            const staffId = typeof staffObj.id === "string" ? staffObj.id : "";

            if (staffStatus !== "matched" || !staffId) {
              pipelineStage = "appointment_needs_resolution";
              finalAction = "clarify_staff";
            } else {
              // v13.6.10.28: specified staff must obey the SAME required-skill rules
              // as random/system assignment. Being on duty or named by the customer
              // does not make an employee qualified for a service.
              const { data: requirements, error: requirementError } = await supabase
                .from("service_skill_requirements")
                .select("skill_code,minimum_level")
                .eq("organization_id", organizationId)
                .eq("store_id", storeId)
                .eq("service_id", serviceId)
                .eq("active", true)
                .eq("required", true);

              if (requirementError) {
                appointmentTools = { ...appointmentTools, staff_skill_validation: { status: "validation_error", error: requirementError.message } };
                pipelineStage = "appointment_staff_skill_validation_error";
                finalAction = "human_skill_check";
              } else if (!requirements?.length) {
                appointmentTools = { ...appointmentTools, staff_skill_validation: { status: "service_skill_unconfigured", missing_skills: [] } };
                pipelineStage = "appointment_skill_unconfigured";
                finalAction = "human_skill_configuration_required";
              } else {
                const skillCodes = requirements.map((r: Json) => String(r.skill_code ?? "")).filter(Boolean);
                const { data: employeeSkills, error: skillError } = await supabase
                  .from("employee_skills")
                  .select("skill_code,skill_level")
                  .eq("organization_id", organizationId)
                  .eq("employee_id", staffId)
                  .eq("active", true)
                  .in("skill_code", skillCodes);

                if (skillError) {
                  appointmentTools = { ...appointmentTools, staff_skill_validation: { status: "validation_error", error: skillError.message } };
                  pipelineStage = "appointment_staff_skill_validation_error";
                  finalAction = "human_skill_check";
                } else {
                  const levels = new Map((employeeSkills ?? []).map((row: Json) => [String(row.skill_code ?? ""), Number(row.skill_level ?? 0)]));
                  const missingSkills = requirements.filter((req: Json) => Number(levels.get(String(req.skill_code ?? "")) ?? 0) < Number(req.minimum_level ?? 1));
                  if (missingSkills.length > 0) {
                    appointmentTools = { ...appointmentTools, staff_skill_validation: { status: "not_qualified", missing_skills: missingSkills } };
                    pipelineStage = "appointment_staff_not_qualified";
                    finalAction = "choose_qualified_staff_or_service";
                  } else {
                    appointmentTools = { ...appointmentTools, staff_skill_validation: { status: "qualified", missing_skills: [] } };
                    const availability = await runTool("check_availability", "v1366_ai_check_availability", {
                      p_queue_id: queueId,
                      p_service_id: serviceId,
                      p_employee_id: staffId,
                      p_date: e.date_iso,
                      p_time_iso: e.time_iso,
                      p_time_period: e.time_period,
                    });
                    appointmentTools = { ...appointmentTools, check_availability: availability };
                    const availabilityStatus = String(availability.availability_status ?? "unknown");
                    if (availabilityStatus === "available" || availabilityStatus === "no_slots") {
                      pipelineStage = "appointment_tools_resolved";
                      finalAction = "ready_for_reply_generation";
                    } else if (availabilityStatus === "schedule_unconfigured" || availabilityStatus === "schedule_invalid") {
                      pipelineStage = "appointment_schedule_unconfigured";
                      finalAction = "human_schedule_check";
                    } else {
                      pipelineStage = "appointment_availability_checked";
                      finalAction = `availability:${availabilityStatus}`;
                    }
                  }
                }
              }
            }
          } else {
            const assignment = await runTool("assign_staff", "v13610_ai_assign_staff", {
              p_queue_id: queueId,
              p_service_id: serviceId,
              p_date: e.date_iso,
              p_time_iso: e.time_iso,
              p_time_period: e.time_period,
            });
            let assignmentStatus = String(assignment.assignment_status ?? "unknown");
            let effectiveAssignment: Json = assignment;
            const allCandidates = Array.isArray(assignment.candidates)
              ? (assignment.candidates as unknown[]).map(asJson)
              : [];
            const excludedKey = excludedStaffName?.trim().toLowerCase() ?? null;
            const filteredCandidates = excludedKey
              ? allCandidates.filter((candidate) => String(candidate.name ?? "").trim().toLowerCase() !== excludedKey)
              : allCandidates;

            // "random, but not the previous stylist" must not accidentally select the
            // very stylist the customer just asked to move away from. The RPC already
            // returns every exact-time candidate, so choose only from the filtered pool.
            if (staffChoiceMode === "random_assign" && excludedKey && assignmentStatus === "assigned") {
              if (filteredCandidates.length > 0) {
                const selected = filteredCandidates[Math.floor(Math.random() * filteredCandidates.length)];
                const selectedAvailability = asJson(selected.availability);
                const selectedStaff = { ...selected } as Json;
                delete selectedStaff.availability;
                effectiveAssignment = {
                  ...assignment,
                  assignment_status: "assigned",
                  resolution_status: "matched",
                  assignment_type: "random",
                  assignment_strategy: "skill_availability_random_excluding_previous",
                  staff: selectedStaff,
                  candidates: filteredCandidates,
                  eligible_staff_count: filteredCandidates.length,
                  availability: selectedAvailability,
                  slots: selectedAvailability.slots ?? [],
                  excluded_staff_name: excludedStaffName,
                };
              } else {
                assignmentStatus = "no_alternative_staff";
                effectiveAssignment = {
                  ...assignment,
                  assignment_status: "no_alternative_staff",
                  candidates: [],
                  staff: null,
                  availability: {},
                  slots: [],
                  excluded_staff_name: excludedStaffName,
                };
              }
            }

            const effectiveStatus = String(effectiveAssignment.assignment_status ?? assignmentStatus);
            const assignedStaff = asJson(effectiveAssignment.staff);
            const assignedStaffId = nullableString(assignedStaff.id);
            const assignmentAvailability = asJson(effectiveAssignment.availability);

            appointmentTools = {
              ...appointmentTools,
              system_assignment: effectiveAssignment,
              staff_choice_mode: staffChoiceMode,
              excluded_staff_name: excludedStaffName,
              staff_alternatives: filteredCandidates,
              resolve_staff: effectiveStatus === "assigned" && assignedStaffId
                ? { ...effectiveAssignment, resolution_status: "matched", staff: assignedStaff }
                : { resolution_status: "system_pool", staff: null, candidates: filteredCandidates },
              check_availability: effectiveStatus === "assigned"
                ? assignmentAvailability
                : {
                    availability_status: effectiveStatus === "needs_time_selection" ? "available"
                      : ["no_slots", "no_alternative_staff"].includes(effectiveStatus) ? "no_slots"
                      : effectiveStatus,
                    slots: effectiveAssignment.slots ?? [],
                    service: effectiveAssignment.service ?? serviceObj,
                  },
            };

            // Asking "who can do it / another stylist" means SHOW choices first.
            // Do not silently random-assign or mutate the pending draft until the
            // customer names a stylist or explicitly says "random".
            if (staffChoiceMode === "list_alternatives" && ["assigned", "needs_time_selection", "no_slots"].includes(assignmentStatus)) {
              if (filteredCandidates.length > 0) {
                pipelineStage = "appointment_staff_alternatives";
                finalAction = "choose_alternative_staff_or_random";
              } else {
                pipelineStage = "appointment_no_alternative_staff";
                finalAction = "choose_alternative_time_or_staff";
              }
            } else if (effectiveStatus === "assigned" && assignedStaffId) {
              pipelineStage = "appointment_tools_resolved";
              finalAction = "ready_for_reply_generation";
            } else if (effectiveStatus === "needs_time_selection") {
              pipelineStage = "appointment_system_time_options";
              finalAction = "select_appointment_time_for_system_assignment";
            } else if (effectiveStatus === "no_qualified_staff") {
              pipelineStage = "appointment_no_qualified_staff";
              finalAction = "human_or_alternative_service";
            } else if (effectiveStatus === "service_skill_unconfigured") {
              pipelineStage = "appointment_skill_unconfigured";
              finalAction = "human_skill_configuration_required";
            } else if (effectiveStatus === "schedule_unconfigured") {
              pipelineStage = "appointment_schedule_unconfigured";
              finalAction = "human_schedule_check";
            } else if (["no_slots", "no_alternative_staff"].includes(effectiveStatus)) {
              pipelineStage = staffChoiceMode ? "appointment_no_alternative_staff" : "appointment_system_no_slots";
              finalAction = staffChoiceMode ? "choose_alternative_time_or_staff" : "choose_alternative_time";
            } else {
              pipelineStage = "appointment_assignment_checked";
              finalAction = `system_assignment:${effectiveStatus}`;
            }
          }
        }
      }

      // v13.6.10.56 — answer common factual service questions from SalonOS data
      // instead of falling back to a robotic "I only handle bookings" message.
      // The same tenant-safe resolver used by bookings is reused here, so prices
      // and durations come from the branch database and are never invented.
      if (["price_enquiry", "service_enquiry"].includes(intent) && effectiveEntities.service_text) {
        const infoServiceResolution = await runTool("resolve_service_info", "v1365_ai_resolve_service", {
          p_queue_id: queueId,
          p_query: effectiveEntities.service_text,
          p_search_terms: effectiveEntities.service_search_terms,
        });
        appointmentTools = { ...asJson(appointmentTools), resolve_service: infoServiceResolution };
      }

      const latestText = String(message.text_body ?? "");
      const { data: sendConfig, error: sendConfigError } = await supabase
        .from("whatsapp_store_configs")
        .select("access_token,graph_api_version,auto_reply_enabled,max_slots_in_reply")
        .eq("organization_id", organizationId)
        .eq("store_id", storeId)
        .eq("connection_id", String(claimed.connection_id))
        .maybeSingle();
      if (sendConfigError) throw new Error(`whatsapp_send_config_error:${sendConfigError.message}`);

      let appointmentDraft: Json | null = null;
      if (intent === "appointment" && effectiveEntities.time_iso && appointmentTools && staffChoiceMode !== "list_alternatives") {
        const availability = asJson(asJson(appointmentTools).check_availability);
        const exactSlots = Array.isArray(availability.slots) ? availability.slots as unknown[] : [];
        const exactAvailable = String(availability.availability_status ?? "") === "available"
          && exactSlots.some((x) => nullableString(asJson(x).time) === effectiveEntities.time_iso);
        if (exactAvailable) {
          // Persist the backend-verified selection first; v1367_ai_ensure_draft derives
          // every tenant/service/staff/date/time field from this durable state.
          const preliminaryAt = new Date().toISOString();
          const priorSlots = freshBookingRestart ? {} : asJson(previousState?.slots);
          const { error: preliminaryStateError } = await supabase.from("whatsapp_ai_conversation_state").upsert({
            organization_id: organizationId, store_id: storeId, conversation_id: conversationId,
            state: "appointment_time_selected", active_intent: "appointment", pending_action: "collect_customer_profile_or_create_draft",
            slots: {
              ...priorSlots, ...effectiveEntities, appointment_tools: appointmentTools,
              booking_context_version: "13.6.10.58",
              date_provenance: effectiveDateProvenance,
              offered_slots: exactSlots.map((x) => nullableString(asJson(x).time)).filter(Boolean),
              selected_time: effectiveEntities.time_iso,
            },
            customer_context: customerSearch ?? {}, last_queue_id: queueId, last_message_id: messageId,
            last_model: model, last_processed_at: preliminaryAt, updated_at: preliminaryAt,
          }, { onConflict: "conversation_id" });
          if (preliminaryStateError) throw preliminaryStateError;
          const { data: ensured, error: ensureError } = await supabase.rpc("v1367_ai_ensure_draft", { p_queue_id: queueId });
          if (ensureError) throw new Error(`ensure_draft_failed:${ensureError.message}`);
          appointmentDraft = asJson(ensured);

          if (appointmentDraft.ok === true) {
            const systemAssignment = asJson(asJson(appointmentTools).system_assignment);
            const systemAssigned = String(systemAssignment.assignment_status ?? "") === "assigned";
            const draftId = nullableString(appointmentDraft.draft_id);
            if (draftId) {
              const assignmentType = systemAssigned ? "random" : "specified";
              const assignmentStrategy = systemAssigned
                ? nullableString(systemAssignment.assignment_strategy) ?? "skill_availability_random"
                : "customer_specified";
              const { error: assignmentPersistError } = await supabase.from("whatsapp_ai_appointment_drafts").update({
                assignment_type: assignmentType,
                assignment_strategy: assignmentStrategy,
                updated_at: new Date().toISOString(),
              }).eq("id", draftId).eq("organization_id", organizationId).eq("store_id", storeId);
              if (assignmentPersistError) throw new Error(`assignment_type_persist_failed:${assignmentPersistError.message}`);
              appointmentDraft = { ...appointmentDraft, assignment_type: assignmentType, assignment_strategy: assignmentStrategy };
            }
          }

          if (appointmentDraft.ok !== true && appointmentDraft.availability) {
            appointmentTools = { ...asJson(appointmentTools), check_availability: asJson(appointmentDraft.availability) };
            pipelineStage = "appointment_availability_checked";
            finalAction = `availability:${String(asJson(appointmentDraft.availability).availability_status ?? "unknown")}`;
          }
        }
      }

      const activeReplyLanguage = conversationReplyLanguage(
        latestText,
        recentRows,
        detected.result.language,
      );
      let replyPlan: ReplyPlan = intent === "appointment"
        ? buildAppointmentReply(
            activeReplyLanguage,
            latestText,
            effectiveEntities,
            pipelineStage,
            appointmentTools,
            customerSummary,
            appointmentDraft,
            Number(sendConfig?.max_slots_in_reply ?? 5),
          )
        : (intent === "cancel" || intent === "reschedule")
          ? buildChangeReply(
              activeReplyLanguage,
              latestText,
              intent,
              pipelineStage,
              appointmentTools,
              changeDraft,
            )
          : (buildInformationalReply(
              activeReplyLanguage,
              latestText,
              intent,
              appointmentTools,
              branchStaffMention,
            ) ?? buildSafeFallbackReply(
              activeReplyLanguage,
              latestText,
              intent,
            ));

      const stateBefore = String(previousState?.state ?? "idle");
      let outboundMessageId: string | null = null;
      let outboundMetaMessageId: string | null = null;
      let replyStatus = "suppressed";
      // v13.6.10.34: delivery failures are audited separately from AI/business
      // processing failures. A Meta authentication outage must not turn an
      // otherwise completed booking turn into a worker HTTP 500.
      let deliveryError: string | null = null;

      if (replyPlan.send) {
        const token = String(sendConfig?.access_token ?? "").trim();
        const autoReplyEnabled = sendConfig?.auto_reply_enabled !== false;
        if (!autoReplyEnabled) {
          replyPlan = { ...replyPlan, send: false, reason: "branch_auto_reply_disabled" };
        } else if (!token) {
          replyPlan = { ...replyPlan, send: false, reason: "meta_access_token_missing_for_branch" };
        }
      }

      if (replyPlan.send) {
        pipelineStage = replyPlan.state;
        finalAction = replyPlan.pendingAction;

        await supabase.from("whatsapp_ai_reply_runs").upsert({
          organization_id: organizationId,
          store_id: storeId,
          queue_id: queueId,
          conversation_id: conversationId,
          inbound_message_id: messageId,
          reply_type: "text",
          state_before: stateBefore,
          state_after: pipelineStage,
          reply_text: replyPlan.text,
          status: "sending",
          error: null,
        }, { onConflict: "inbound_message_id" });

        const { data: existingOutbound } = await supabase
          .from("whatsapp_messages")
          .select("id,meta_message_id,delivery_status,text_body")
          .eq("reply_to_message_id", messageId)
          .eq("direction", "outbound")
          .maybeSingle();

        if (existingOutbound?.meta_message_id) {
          outboundMessageId = String(existingOutbound.id);
          outboundMetaMessageId = String(existingOutbound.meta_message_id);
          replyStatus = "sent";
          await supabase.from("whatsapp_ai_reply_runs").update({
            outbound_message_id: outboundMessageId,
            status: "sent",
            error: null,
            completed_at: new Date().toISOString(),
          }).eq("inbound_message_id", messageId);
        } else {
          if (existingOutbound?.id) {
            outboundMessageId = String(existingOutbound.id);
          } else {
            const { data: createdOutbound, error: outboundCreateError } = await supabase.from("whatsapp_messages").insert({
              organization_id: organizationId,
              store_id: storeId,
              connection_id: String(claimed.connection_id),
              conversation_id: conversationId,
              direction: "outbound",
              message_type: "text",
              text_body: replyPlan.text,
              delivery_status: "sending",
              ai_status: "completed",
              reply_to_message_id: messageId,
              reply_kind: replyPlan.kind,
              reply_context: {
                queue_id: queueId,
                pipeline_stage: pipelineStage,
                offered_slots: replyPlan.offeredSlots,
                selected_time: replyPlan.selectedTime,
              },
              raw_payload: { source: "salonos_ai_auto_reply", version: "13.6.10.58" },
              sent_at: new Date().toISOString(),
            }).select("id").single();
            if (outboundCreateError) throw new Error(`outbound_message_create_failed:${outboundCreateError.message}`);
            outboundMessageId = String(createdOutbound.id);
          }

          const { data: connection, error: connectionError } = await supabase
            .from("whatsapp_business_connections")
            .select("phone_number_id")
            .eq("id", String(claimed.connection_id))
            .eq("organization_id", organizationId)
            .eq("store_id", storeId)
            .single();
          if (connectionError) throw new Error(`whatsapp_connection_error:${connectionError.message}`);

          try {
            const sent = await sendMetaTextMessage(
              String(connection.phone_number_id),
              String(sendConfig?.access_token ?? ""),
              String(sendConfig?.graph_api_version ?? "v26.0"),
              String(conversation.customer_phone),
              replyPlan.text,
            );
            outboundMetaMessageId = sent.metaMessageId;
            replyStatus = "sent";
            await supabase.from("whatsapp_messages").update({
              meta_message_id: sent.metaMessageId,
              delivery_status: "accepted",
              raw_payload: { source: "salonos_ai_auto_reply", meta_response: sent.response, version: "13.6.10.58" },
              sent_at: new Date().toISOString(),
            }).eq("id", outboundMessageId);
            await supabase.from("whatsapp_store_configs").update({
              last_send_at: new Date().toISOString(), last_send_error: null, updated_at: new Date().toISOString(),
            }).eq("connection_id", String(claimed.connection_id));
            await supabase.from("whatsapp_ai_reply_runs").update({
              outbound_message_id: outboundMessageId,
              status: "sent",
              meta_response: sent.response,
              error: null,
              completed_at: new Date().toISOString(),
            }).eq("inbound_message_id", messageId);
          } catch (sendError) {
            const sendMessage = errorText(sendError).slice(0, 1500);
            deliveryError = sendMessage;
            replyStatus = "failed";
            await supabase.from("whatsapp_messages").update({ delivery_status: "failed" }).eq("id", outboundMessageId);
            await supabase.from("whatsapp_store_configs").update({
              last_send_error: sendMessage, updated_at: new Date().toISOString(),
            }).eq("connection_id", String(claimed.connection_id));
            await supabase.from("whatsapp_ai_reply_runs").update({
              outbound_message_id: outboundMessageId,
              status: "failed",
              error: sendMessage,
              completed_at: new Date().toISOString(),
            }).eq("inbound_message_id", messageId);
            // Do NOT throw. Booking/cancel/reschedule mutations and conversation
            // state may already be committed. The queue must finish truthfully
            // with reply.status=failed while preserving the Meta error for ops.
          }
        }
      } else {
        await supabase.from("whatsapp_ai_reply_runs").upsert({
          organization_id: organizationId,
          store_id: storeId,
          queue_id: queueId,
          conversation_id: conversationId,
          inbound_message_id: messageId,
          reply_type: "text",
          state_before: stateBefore,
          state_after: pipelineStage,
          reply_text: replyPlan.text || null,
          status: "suppressed",
          error: replyPlan.reason,
          completed_at: new Date().toISOString(),
        }, { onConflict: "inbound_message_id" });
        finalAction = replyPlan.reason ? `reply_suppressed:${replyPlan.reason}` : finalAction;
      }

      // Re-read context because Search Customer and backend tools may have enriched state.
      const { data: refreshedQueue, error: refreshedError } = await supabase
        .from("whatsapp_ai_queue")
        .select("context")
        .eq("id", queueId)
        .single();
      if (refreshedError) throw refreshedError;
      const oldContext = asJson(refreshedQueue?.context);
      const findForState = asJson(asJson(appointmentTools).find_upcoming_appointments);
      const candidateAppointmentsForState = candidateArray(findForState);
      const targetForState = asJson(asJson(appointmentTools).target_appointment);
      const priorSlotsForState = asJson(previousState?.slots);
      const isChangeIntent = intent === "cancel" || intent === "reschedule";
      const selectedTargetVisitId = isChangeIntent
        ? (nullableString(targetForState.visit_id)
          ?? nullableString(asJson(changeDraft).appointment ? asJson(asJson(changeDraft).appointment).visit_id : null)
          ?? nullableString(priorSlotsForState.selected_target_visit_id))
        : null;
      const finalContext: Json = {
        ...oldContext,
        pipeline_stage: pipelineStage,
        intent_detection: {
          ...detected.result,
          intent,
          entities: effectiveEntities,
          provider: detectionProvider,
          model: detectionModel,
          detected_at: detectedAt,
        },
        backend_tools: appointmentTools,
        appointment_draft: appointmentDraft,
        appointment_change_draft: changeDraft,
        reply: {
          status: replyStatus,
          kind: replyPlan.kind,
          text: replyPlan.text || null,
          reason: replyPlan.reason,
          delivery_error: deliveryError,
          outbound_message_id: outboundMessageId,
          meta_message_id: outboundMetaMessageId,
          offered_slots: replyPlan.offeredSlots,
          selected_time: replyPlan.selectedTime,
        },
        pending_action: finalAction,
        next_step: finalAction,
      };

      const { error: queueUpdateError } = await supabase.from("whatsapp_ai_queue").update({
        status: "completed",
        context: finalContext,
        last_error: null,
        updated_at: detectedAt,
      }).eq("id", queueId).eq("organization_id", organizationId).eq("store_id", storeId);
      if (queueUpdateError) throw queueUpdateError;

      const { error: messageUpdateError } = await supabase.from("whatsapp_messages").update({
        ai_status: "completed",
        ai_intent: intent,
        ai_confidence: detected.result.confidence,
        ai_entities: effectiveEntities,
        ai_processed_at: detectedAt,
      }).eq("id", messageId).eq("organization_id", organizationId).eq("store_id", storeId);
      if (messageUpdateError) throw messageUpdateError;

      const { error: stateError } = await supabase.from("whatsapp_ai_conversation_state").upsert({
        organization_id: organizationId,
        store_id: storeId,
        conversation_id: conversationId,
        state: pipelineStage,
        active_intent: intent,
        pending_action: finalAction,
        slots: {
          ...effectiveEntities,
          booking_context_version: "13.6.10.58",
          date_provenance: effectiveDateProvenance,
          appointment_tools: appointmentTools,
          // v13.6.10.26: never erase a recoverable unconfirmed booking draft merely
          // because the current turn was routed through cancel/reschedule or produced
          // no new appointmentDraft object. This is what made .23-.25 unable to
          // recover after the first mistaken reschedule_not_found reply.
          booking_draft: appointmentDraft ?? (pendingBookingDraft ? pendingBookingDraft : null),
          change_draft: isChangeIntent ? changeDraft : null,
          change_request: isChangeIntent ? effectiveEntities : null,
          candidate_appointments: isChangeIntent
            ? (candidateAppointmentsForState.length ? candidateAppointmentsForState : (Array.isArray(priorSlotsForState.candidate_appointments) ? priorSlotsForState.candidate_appointments : []))
            : [],
          selected_target_visit_id: selectedTargetVisitId,
          target_appointment: isChangeIntent
            ? (Object.keys(targetForState).length ? targetForState : asJson(priorSlotsForState.target_appointment))
            : null,
          preference_staff_suggestion: intent === "appointment" && !effectiveEntities.staff_name ? preferenceStaffSuggestion : null,
          staff_choice_mode: intent === "appointment" ? staffChoiceMode : null,
          excluded_staff_name: intent === "appointment" ? excludedStaffName : null,
          offered_slots: replyPlan.offeredSlots,
          selected_time: replyPlan.selectedTime,
          last_reply_kind: replyPlan.kind,
          last_reply_text: replyPlan.text || null,
        },
        customer_context: customerSearch ?? {},
        last_queue_id: queueId,
        last_message_id: messageId,
        last_model: detectionModel,
        last_processed_at: detectedAt,
        updated_at: detectedAt,
      }, { onConflict: "conversation_id" });
      if (stateError) throw stateError;

      await supabase.from("whatsapp_conversations").update({
        updated_at: new Date().toISOString(),
        last_message_at: new Date().toISOString(),
      }).eq("id", conversationId);

      await supabase.from("whatsapp_ai_runs").update({
        status: "completed",
        output_snapshot: {
          intent: { ...detected.result, intent, entities: effectiveEntities },
          pending_action: finalAction,
          pipeline_stage: pipelineStage,
          backend_tools: appointmentTools,
          appointment_draft: appointmentDraft,
          appointment_change_draft: changeDraft,
          reply: {
            status: replyStatus,
            kind: replyPlan.kind,
            text: replyPlan.text || null,
            reason: replyPlan.reason,
            delivery_error: deliveryError,
            outbound_message_id: outboundMessageId,
            meta_message_id: outboundMetaMessageId,
          },
          provider_response_id: detected.responseId,
        },
        duration_ms: Date.now() - startedAt,
        completed_at: detectedAt,
      }).eq("id", runId);

      return json({
        ok: true,
        processed: 1,
        queue_id: queueId,
        pipeline_stage: pipelineStage,
        intent,
        confidence: detected.result.confidence,
        entities: effectiveEntities,
        backend_tools: appointmentTools,
        appointment_change_draft: changeDraft,
        reply: {
          status: replyStatus,
          kind: replyPlan.kind,
          text: replyPlan.text || null,
          reason: replyPlan.reason,
          outbound_message_id: outboundMessageId,
          meta_message_id: outboundMetaMessageId,
        },
        pending_action: finalAction,
        customer_status: customerSummary.customer_status ?? "unknown",
        provider,
        model,
      });

    } catch (error) {
      const message = errorText(error).slice(0, 1500);
      const finishedAt = new Date().toISOString();
      console.error(`whatsapp-ai-worker queue=${queueId}`, error);
      await supabase.from("whatsapp_ai_queue").update({
        status: "failed",
        last_error: message,
        updated_at: finishedAt,
      }).eq("id", queueId);
      const { data: q } = await supabase.from("whatsapp_ai_queue").select("message_id").eq("id", queueId).maybeSingle();
      if (q?.message_id) {
        await supabase.from("whatsapp_messages").update({ ai_status: "failed", ai_processed_at: finishedAt }).eq("id", q.message_id);
      }
      if (runId) {
        await supabase.from("whatsapp_ai_runs").update({
          status: "failed",
          error: message,
          duration_ms: Date.now() - startedAt,
          completed_at: finishedAt,
        }).eq("id", runId);
      }
      return json({ ok: false, queue_id: queueId, error: message }, 500);
    }
  },
};
