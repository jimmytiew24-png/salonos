import { createClient } from "npm:@supabase/supabase-js@2";

type Json = Record<string, unknown>;

function env(name: string): string {
  return (Deno.env.get(name) ?? "").trim();
}

function serviceKey(): string {
  const legacy = env("SUPABASE_SERVICE_ROLE_KEY");
  if (legacy) return legacy;
  try {
    const keys = JSON.parse(env("SUPABASE_SECRET_KEYS") || "{}") as Record<string, string>;
    return (keys.default ?? Object.values(keys)[0] ?? "").trim();
  } catch {
    return "";
  }
}

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function errorText(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  try { return JSON.stringify(error); } catch { return "unknown_error"; }
}

function cleanDigits(value: unknown): string {
  return String(value ?? "").replace(/\D+/g, "");
}

async function readMetaJson(response: Response): Promise<Json> {
  const text = await response.text();
  let payload: Json = {};
  try { payload = text ? JSON.parse(text) as Json : {}; } catch { payload = { raw: text }; }
  if (!response.ok) {
    const metaError = (payload.error && typeof payload.error === "object") ? payload.error as Json : {};
    const message = String(metaError.message ?? payload.error_description ?? payload.error ?? `Meta HTTP ${response.status}`);
    const code = String(metaError.code ?? "");
    const subcode = String(metaError.error_subcode ?? "");
    throw new Error(`meta_error:${message}${code ? ` code=${code}` : ""}${subcode ? ` subcode=${subcode}` : ""} http=${response.status}`);
  }
  return payload;
}

async function audit(supabase: ReturnType<typeof createClient>, row: Json): Promise<void> {
  try {
    const result = await supabase.from("whatsapp_embedded_signup_events").insert(row);
    if (result.error) console.warn("embedded_signup_audit_failed", result.error.message);
  } catch (error) {
    console.warn("embedded_signup_audit_failed", errorText(error));
  }
}

Deno.serve(async (request) => {
  if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const supabaseUrl = env("SUPABASE_URL");
  const key = serviceKey();
  if (!supabaseUrl || !key) return json({ error: "supabase_service_config_missing" }, 500);

  const authHeader = request.headers.get("authorization") ?? "";
  const bearer = authHeader.match(/^Bearer\s+(.+)$/i)?.[1]?.trim() ?? "";
  if (!bearer) return json({ error: "owner_auth_required" }, 401);

  const admin = createClient(supabaseUrl, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userResult, error: userError } = await admin.auth.getUser(bearer);
  const user = userResult?.user;
  if (userError || !user?.id) return json({ error: "invalid_owner_session" }, 401);

  let body: Json = {};
  try { body = await request.json() as Json; } catch { return json({ error: "invalid_json" }, 400); }

  const action = String(body.action ?? "").trim();
  const storeId = String(body.store_id ?? "").trim();
  if (!storeId) return json({ error: "store_id_required" }, 400);

  const { data: store, error: storeError } = await admin
    .from("stores")
    .select("id,organization_id,name,status")
    .eq("id", storeId)
    .maybeSingle();
  if (storeError || !store?.id || !store.organization_id) return json({ error: "store_not_found" }, 404);

  const { data: membership, error: memberError } = await admin
    .from("organization_members")
    .select("role,status")
    .eq("organization_id", store.organization_id)
    .eq("user_id", user.id)
    .eq("status", "active")
    .eq("role", "owner")
    .maybeSingle();
  if (memberError || !membership) return json({ error: "owner_role_required_for_whatsapp_connection" }, 403);

  const appId = env("META_APP_ID");
  const appSecret = env("META_APP_SECRET");
  const configId = env("META_EMBEDDED_SIGNUP_CONFIG_ID");
  const graphVersion = env("META_GRAPH_API_VERSION") || "v26.0";
  const schemaProbe = await admin.from("whatsapp_business_connections").select("onboarding_method").limit(1);
  const auditProbe = await admin.from("whatsapp_embedded_signup_events").select("id").limit(1);
  const schemaReady = !schemaProbe.error && !auditProbe.error;
  const secretsReady = Boolean(appId && appSecret && configId);
  const ready = secretsReady && schemaReady;

  if (action === "config") {
    return json({
      ok: true,
      ready,
      app_id: secretsReady ? appId : "",
      config_id: secretsReady ? configId : "",
      graph_api_version: graphVersion,
      session_info_version: "3",
      supports_business_app_onboarding: true,
      schema_ready: schemaReady,
      missing: [
        !appId ? "META_APP_ID" : "",
        !appSecret ? "META_APP_SECRET" : "",
        !configId ? "META_EMBEDDED_SIGNUP_CONFIG_ID" : "",
        !schemaReady ? "RUN_ONCE_V13_6_10_35_EMBEDDED_SIGNUP_FOUNDATION.sql" : "",
      ].filter(Boolean),
    });
  }

  if (action !== "complete") return json({ error: "unsupported_action" }, 400);
  if (!ready) return json({ error: "embedded_signup_platform_not_configured" }, 503);

  const code = String(body.code ?? "").trim();
  const wabaId = String(body.waba_id ?? "").trim();
  const phoneNumberId = String(body.phone_number_id ?? "").trim();
  const metaBusinessId = String(body.meta_business_id ?? "").trim();
  const flowType = String(body.flow_type ?? "standard").trim() === "business_app" ? "business_app" : "standard";
  if (!code || !wabaId || !phoneNumberId) return json({ error: "embedded_signup_result_incomplete" }, 400);

  const auditBase = {
    organization_id: store.organization_id,
    store_id: storeId,
    actor_user_id: user.id,
    event_type: "complete",
    flow_type: flowType,
    waba_id: wabaId,
    phone_number_id: phoneNumberId,
    meta_business_id: metaBusinessId || null,
  };

  try {
    const conflictQuery = await admin
      .from("whatsapp_business_connections")
      .select("id,organization_id,store_id")
      .eq("phone_number_id", phoneNumberId)
      .maybeSingle();
    if (conflictQuery.error) throw new Error(`connection_lookup_failed:${conflictQuery.error.message}`);
    if (conflictQuery.data && (String(conflictQuery.data.organization_id) !== String(store.organization_id) || String(conflictQuery.data.store_id) !== storeId)) {
      throw new Error("phone_number_id_already_bound_to_another_branch");
    }

    const tokenParams = new URLSearchParams({
      client_id: appId,
      client_secret: appSecret,
      code,
    });
    const tokenResponse = await fetch(`https://graph.facebook.com/${graphVersion}/oauth/access_token?${tokenParams.toString()}`, {
      method: "GET",
      headers: { accept: "application/json" },
    });
    const tokenPayload = await readMetaJson(tokenResponse);
    const businessToken = String(tokenPayload.access_token ?? "").trim();
    if (!businessToken) throw new Error("meta_business_token_missing_after_code_exchange");

    const phonesResponse = await fetch(
      `https://graph.facebook.com/${graphVersion}/${encodeURIComponent(wabaId)}/phone_numbers?fields=id,display_phone_number,verified_name&limit=100`,
      { headers: { authorization: `Bearer ${businessToken}` } },
    );
    const phonesPayload = await readMetaJson(phonesResponse);
    const phones = Array.isArray(phonesPayload.data) ? phonesPayload.data as Json[] : [];
    const selectedPhone = phones.find((item) => String(item.id ?? "") === phoneNumberId);
    if (!selectedPhone) throw new Error("selected_phone_number_not_owned_by_selected_waba");

    const subscribeResponse = await fetch(
      `https://graph.facebook.com/${graphVersion}/${encodeURIComponent(wabaId)}/subscribed_apps`,
      {
        method: "POST",
        headers: {
          authorization: `Bearer ${businessToken}`,
          "content-type": "application/json",
        },
        body: "{}",
      },
    );
    await readMetaJson(subscribeResponse);

    const now = new Date().toISOString();
    const publicPhone = cleanDigits(selectedPhone.display_phone_number);

    const previousConnections = await admin
      .from("whatsapp_business_connections")
      .select("id,phone_number_id")
      .eq("organization_id", store.organization_id)
      .eq("store_id", storeId);
    if (previousConnections.error) throw new Error(`previous_connection_lookup_failed:${previousConnections.error.message}`);
    const oldIds = (previousConnections.data ?? [])
      .filter((row) => String(row.phone_number_id ?? "") !== phoneNumberId)
      .map((row) => String(row.id));
    if (oldIds.length) {
      const disableOld = await admin.from("whatsapp_business_connections").update({ enabled: false, updated_at: now }).in("id", oldIds);
      if (disableOld.error) throw new Error(`disable_previous_connection_failed:${disableOld.error.message}`);
    }

    const connectionPayload = {
      organization_id: store.organization_id,
      store_id: storeId,
      phone_number_id: phoneNumberId,
      business_account_id: wabaId,
      display_phone_number: publicPhone || null,
      enabled: true,
      connection_status: "configured",
      onboarding_method: "embedded_signup",
      embedded_signup_status: "connected",
      meta_business_id: metaBusinessId || null,
      embedded_signup_connected_at: now,
      webhook_subscribed_at: now,
      embedded_signup_last_error: null,
      updated_at: now,
    };
    const connectionUpsert = await admin
      .from("whatsapp_business_connections")
      .upsert(connectionPayload, { onConflict: "phone_number_id" })
      .select("id")
      .single();
    if (connectionUpsert.error || !connectionUpsert.data?.id) {
      throw new Error(`connection_save_failed:${connectionUpsert.error?.message ?? "missing_connection_id"}`);
    }
    const connectionId = String(connectionUpsert.data.id);

    const configPayload = {
      organization_id: store.organization_id,
      store_id: storeId,
      connection_id: connectionId,
      access_token: businessToken,
      graph_api_version: graphVersion,
      auto_reply_enabled: true,
      token_configured_at: now,
      token_source: "embedded_signup",
      token_last_verified_at: now,
      last_send_error: null,
      updated_at: now,
    };
    const currentConfig = await admin.from("whatsapp_store_configs")
      .select("connection_id")
      .eq("organization_id", store.organization_id)
      .eq("store_id", storeId)
      .maybeSingle();
    if (currentConfig.error) throw new Error(`send_config_lookup_failed:${currentConfig.error.message}`);
    const configWrite = currentConfig.data
      ? await admin.from("whatsapp_store_configs").update(configPayload)
          .eq("organization_id", store.organization_id).eq("store_id", storeId)
      : await admin.from("whatsapp_store_configs").insert(configPayload);
    if (configWrite.error) throw new Error(`send_config_save_failed:${configWrite.error.message}`);

    const existingSettings = await admin
      .from("v13_organization_settings")
      .select("whatsapp")
      .eq("organization_id", store.organization_id)
      .maybeSingle();
    const existingWhatsapp = (existingSettings.data?.whatsapp && typeof existingSettings.data.whatsapp === "object")
      ? existingSettings.data.whatsapp as Json
      : {};
    const whatsappSettings = {
      ...existingWhatsapp,
      enabled: true,
      phone_number_id: phoneNumberId,
      business_account_id: wabaId,
      public_phone: publicPhone || null,
      access_token_configured: true,
      auto_reply_enabled: true,
      onboarding_method: "embedded_signup",
    };
    const orgSettingsUpsert = await admin.from("v13_organization_settings").upsert({
      organization_id: store.organization_id,
      whatsapp: whatsappSettings,
      updated_at: now,
    }, { onConflict: "organization_id" });
    if (orgSettingsUpsert.error) throw new Error(`organization_settings_sync_failed:${orgSettingsUpsert.error.message}`);

    await audit(admin, { ...auditBase, status: "success" });
    return json({
      ok: true,
      connection_id: connectionId,
      onboarding_method: "embedded_signup",
      embedded_signup_status: "connected",
      waba_id: wabaId,
      phone_number_id: phoneNumberId,
      display_phone_number: publicPhone || null,
      verified_name: String(selectedPhone.verified_name ?? ""),
      webhook_subscribed: true,
      token_configured: true,
    });
  } catch (error) {
    const message = errorText(error);
    console.error("whatsapp_embedded_signup_failed", message);
    await audit(admin, { ...auditBase, status: "failed", error_message: message.slice(0, 1800) });
    try {
      await admin.from("whatsapp_business_connections").update({
        embedded_signup_status: "error",
        embedded_signup_last_error: message.slice(0, 1800),
        updated_at: new Date().toISOString(),
      }).eq("organization_id", store.organization_id).eq("store_id", storeId).eq("phone_number_id", phoneNumberId);
    } catch { /* best effort */ }
    return json({ error: "embedded_signup_failed", message }, 502);
  }
});
