import { createClient } from "npm:@supabase/supabase-js@2";

type Json = Record<string, unknown>;

function env(name: string): string {
  return (Deno.env.get(name) ?? "").trim();
}

function serviceKey(): string {
  const legacy = env("SUPABASE_SERVICE_ROLE_KEY");
  if (legacy) return legacy;
  try {
    const keys = JSON.parse(env("SUPABASE_SECRET_KEYS") || "{}") as Record<string, string>;
    return (keys.default ?? Object.values(keys)[0] ?? "").trim();
  } catch {
    return "";
  }
}

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function errorText(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  try { return JSON.stringify(error); } catch { return "unknown_error"; }
}

function cleanDigits(value: unknown): string {
  return String(value ?? "").replace(/\D+/g, "");
}

function randomHex(bytes = 24): string {
  const buf = new Uint8Array(bytes);
  crypto.getRandomValues(buf);
  return [...buf].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha256Hex(value: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function readMetaJson(response: Response): Promise<Json> {
  const text = await response.text();
  let payload: Json = {};
  try { payload = text ? JSON.parse(text) as Json : {}; } catch { payload = { raw: text }; }
  if (!response.ok) {
    const metaError = (payload.error && typeof payload.error === "object") ? payload.error as Json : {};
    const message = String(metaError.message ?? payload.error_description ?? payload.error ?? `Meta HTTP ${response.status}`);
    const code = String(metaError.code ?? "");
    const subcode = String(metaError.error_subcode ?? "");
    throw new Error(`meta_error:${message}${code ? ` code=${code}` : ""}${subcode ? ` subcode=${subcode}` : ""} http=${response.status}`);
  }
  return payload;
}

async function audit(supabase: ReturnType<typeof createClient>, row: Json): Promise<void> {
  try {
    const result = await supabase.from("whatsapp_manual_connect_events").insert(row);
    if (result.error) console.warn("manual_connect_audit_failed", result.error.message);
  } catch (error) {
    console.warn("manual_connect_audit_failed", errorText(error));
  }
}

Deno.serve(async (request) => {
  if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const supabaseUrl = env("SUPABASE_URL");
  const key = serviceKey();
  const graphVersion = env("META_GRAPH_API_VERSION") || "v26.0";
  if (!supabaseUrl || !key) return json({ error: "supabase_service_config_missing" }, 500);

  const authHeader = request.headers.get("authorization") ?? "";
  const bearer = authHeader.match(/^Bearer\s+(.+)$/i)?.[1]?.trim() ?? "";
  if (!bearer) return json({ error: "owner_auth_required" }, 401);

  const admin = createClient(supabaseUrl, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userResult, error: userError } = await admin.auth.getUser(bearer);
  const user = userResult?.user;
  if (userError || !user?.id) return json({ error: "invalid_owner_session" }, 401);

  let body: Json = {};
  try { body = await request.json() as Json; } catch { return json({ error: "invalid_json" }, 400); }

  const action = String(body.action ?? "connect").trim();
  const storeId = String(body.store_id ?? "").trim();
  if (!storeId) return json({ error: "store_id_required" }, 400);

  const { data: store, error: storeError } = await admin
    .from("stores")
    .select("id,organization_id,name,status")
    .eq("id", storeId)
    .maybeSingle();
  if (storeError || !store?.id || !store.organization_id) return json({ error: "store_not_found" }, 404);

  const { data: membership, error: memberError } = await admin
    .from("organization_members")
    .select("role,status")
    .eq("organization_id", store.organization_id)
    .eq("user_id", user.id)
    .eq("status", "active")
    .eq("role", "owner")
    .maybeSingle();
  if (memberError || !membership) return json({ error: "owner_role_required_for_whatsapp_connection" }, 403);

  if (action === "status") {
    const schemaProbe = await admin.from("whatsapp_connection_secrets").select("connection_id").limit(1);
    return json({ ok: true, ready: !schemaProbe.error, graph_api_version: graphVersion });
  }
  if (action !== "connect") return json({ error: "unsupported_action" }, 400);

  const appId = String(body.meta_app_id ?? "").trim();
  const appSecret = String(body.meta_app_secret ?? "").trim();
  const accessToken = String(body.access_token ?? "").trim();
  const wabaId = String(body.waba_id ?? "").trim();
  const phoneNumberId = String(body.phone_number_id ?? "").trim();
  const requestedPublicPhone = cleanDigits(body.display_phone_number);
  const autoReplyEnabled = body.auto_reply_enabled !== false;

  if (!appId || !appSecret || !accessToken || !wabaId || !phoneNumberId) {
    return json({ error: "manual_connect_fields_required", required: ["meta_app_id","meta_app_secret","access_token","waba_id","phone_number_id"] }, 400);
  }
  if (!/^\d+$/.test(appId) || !/^\d+$/.test(wabaId) || !/^\d+$/.test(phoneNumberId)) {
    return json({ error: "manual_connect_ids_must_be_numeric" }, 400);
  }

  const auditBase = {
    organization_id: store.organization_id,
    store_id: storeId,
    actor_user_id: user.id,
    event_type: "connect",
    meta_app_id: appId,
    waba_id: wabaId,
    phone_number_id: phoneNumberId,
  };

  try {
    const schemaProbe = await admin.from("whatsapp_connection_secrets").select("connection_id").limit(1);
    if (schemaProbe.error) throw new Error("manual_connect_schema_missing_run_v13_6_10_36_sql");

    const conflictQuery = await admin
      .from("whatsapp_business_connections")
      .select("id,organization_id,store_id")
      .eq("phone_number_id", phoneNumberId)
      .maybeSingle();
    if (conflictQuery.error) throw new Error(`connection_lookup_failed:${conflictQuery.error.message}`);
    if (conflictQuery.data && (String(conflictQuery.data.organization_id) !== String(store.organization_id) || String(conflictQuery.data.store_id) !== storeId)) {
      throw new Error("phone_number_id_already_bound_to_another_branch");
    }

    // Verify that the access token was issued to the customer's Meta App.
    const debugUrl = new URL(`https://graph.facebook.com/${graphVersion}/debug_token`);
    debugUrl.searchParams.set("input_token", accessToken);
    debugUrl.searchParams.set("access_token", `${appId}|${appSecret}`);
    const debugResponse = await fetch(debugUrl.toString(), { headers: { accept: "application/json" } });
    const debugPayload = await readMetaJson(debugResponse);
    const debugData = (debugPayload.data && typeof debugPayload.data === "object") ? debugPayload.data as Json : {};
    if (debugData.is_valid !== true) throw new Error("meta_access_token_invalid");
    const debugAppId = String(debugData.app_id ?? "").trim();
    if (debugAppId && debugAppId !== appId) throw new Error("access_token_belongs_to_different_meta_app");

    const scopes = Array.isArray(debugData.scopes) ? debugData.scopes.map(String) : [];
    if (scopes.length && !scopes.includes("whatsapp_business_messaging")) {
      throw new Error("access_token_missing_whatsapp_business_messaging_permission");
    }

    const phonesResponse = await fetch(
      `https://graph.facebook.com/${graphVersion}/${encodeURIComponent(wabaId)}/phone_numbers?fields=id,display_phone_number,verified_name&limit=100`,
      { headers: { authorization: `Bearer ${accessToken}`, accept: "application/json" } },
    );
    const phonesPayload = await readMetaJson(phonesResponse);
    const phones = Array.isArray(phonesPayload.data) ? phonesPayload.data as Json[] : [];
    const selectedPhone = phones.find((item) => String(item.id ?? "") === phoneNumberId);
    if (!selectedPhone) throw new Error("selected_phone_number_not_owned_by_selected_waba");

    // Subscribe this WABA to the customer's own Meta App. The App still needs
    // its Webhooks callback URL + messages field configured with the verify token
    // returned once below.
    const subscribeResponse = await fetch(
      `https://graph.facebook.com/${graphVersion}/${encodeURIComponent(wabaId)}/subscribed_apps`,
      {
        method: "POST",
        headers: {
          authorization: `Bearer ${accessToken}`,
          "content-type": "application/json",
        },
        body: "{}",
      },
    );
    await readMetaJson(subscribeResponse);

    const now = new Date().toISOString();
    const publicPhone = cleanDigits(selectedPhone.display_phone_number) || requestedPublicPhone;
    const verifyToken = `salonos_${randomHex(24)}`;
    const verifyTokenHash = await sha256Hex(verifyToken);
    const verifyTokenHint = verifyToken.slice(-8);

    const previousConnections = await admin
      .from("whatsapp_business_connections")
      .select("id,phone_number_id")
      .eq("organization_id", store.organization_id)
      .eq("store_id", storeId);
    if (previousConnections.error) throw new Error(`previous_connection_lookup_failed:${previousConnections.error.message}`);
    const oldIds = (previousConnections.data ?? [])
      .filter((row) => String(row.phone_number_id ?? "") !== phoneNumberId)
      .map((row) => String(row.id));
    if (oldIds.length) {
      const disableOld = await admin.from("whatsapp_business_connections").update({ enabled: false, updated_at: now }).in("id", oldIds);
      if (disableOld.error) throw new Error(`disable_previous_connection_failed:${disableOld.error.message}`);
    }

    const connectionPayload = {
      organization_id: store.organization_id,
      store_id: storeId,
      phone_number_id: phoneNumberId,
      business_account_id: wabaId,
      display_phone_number: publicPhone || null,
      enabled: true,
      connection_status: "configured",
      onboarding_method: "manual",
      meta_app_id: appId,
      manual_setup_status: "webhook_pending",
      manual_connected_at: now,
      manual_last_error: null,
      updated_at: now,
    };
    const connectionUpsert = await admin
      .from("whatsapp_business_connections")
      .upsert(connectionPayload, { onConflict: "phone_number_id" })
      .select("id")
      .single();
    if (connectionUpsert.error || !connectionUpsert.data?.id) {
      throw new Error(`connection_save_failed:${connectionUpsert.error?.message ?? "missing_connection_id"}`);
    }
    const connectionId = String(connectionUpsert.data.id);

    const secretPayload = {
      connection_id: connectionId,
      organization_id: store.organization_id,
      store_id: storeId,
      meta_app_id: appId,
      meta_app_secret: appSecret,
      verify_token_hash: verifyTokenHash,
      verify_token_hint: verifyTokenHint,
      token_last_verified_at: now,
      webhook_verified_at: null,
      updated_at: now,
    };
    const secretWrite = await admin.from("whatsapp_connection_secrets")
      .upsert(secretPayload, { onConflict: "organization_id,store_id" });
    if (secretWrite.error) throw new Error(`connection_secret_save_failed:${secretWrite.error.message}`);

    const configPayload = {
      organization_id: store.organization_id,
      store_id: storeId,
      connection_id: connectionId,
      access_token: accessToken,
      graph_api_version: graphVersion,
      auto_reply_enabled: autoReplyEnabled,
      token_configured_at: now,
      token_source: "manual",
      token_last_verified_at: now,
      last_send_error: null,
      updated_at: now,
    };
    const currentConfig = await admin.from("whatsapp_store_configs")
      .select("connection_id")
      .eq("organization_id", store.organization_id)
      .eq("store_id", storeId)
      .maybeSingle();
    if (currentConfig.error) throw new Error(`send_config_lookup_failed:${currentConfig.error.message}`);
    const configWrite = currentConfig.data
      ? await admin.from("whatsapp_store_configs").update(configPayload)
          .eq("organization_id", store.organization_id).eq("store_id", storeId)
      : await admin.from("whatsapp_store_configs").insert(configPayload);
    if (configWrite.error) throw new Error(`send_config_save_failed:${configWrite.error.message}`);

    const existingSettings = await admin
      .from("v13_organization_settings")
      .select("whatsapp")
      .eq("organization_id", store.organization_id)
      .maybeSingle();
    const existingWhatsapp = (existingSettings.data?.whatsapp && typeof existingSettings.data.whatsapp === "object")
      ? existingSettings.data.whatsapp as Json
      : {};
    const whatsappSettings = {
      ...existingWhatsapp,
      enabled: true,
      phone_number_id: phoneNumberId,
      business_account_id: wabaId,
      public_phone: publicPhone || null,
      access_token_configured: true,
      auto_reply_enabled: autoReplyEnabled,
      onboarding_method: "manual",
      meta_app_id: appId,
    };
    const orgSettingsUpsert = await admin.from("v13_organization_settings").upsert({
      organization_id: store.organization_id,
      whatsapp: whatsappSettings,
      updated_at: now,
    }, { onConflict: "organization_id" });
    if (orgSettingsUpsert.error) throw new Error(`organization_settings_sync_failed:${orgSettingsUpsert.error.message}`);

    const expiresAt = Number(debugData.expires_at ?? 0);
    const dataAccessExpiresAt = Number(debugData.data_access_expires_at ?? 0);
    const warnings: string[] = [];
    const nowSeconds = Math.floor(Date.now() / 1000);
    if (expiresAt > 0 && expiresAt - nowSeconds < 7 * 86400) warnings.push("access_token_expires_within_7_days_use_system_user_token");
    if (scopes.length && !scopes.includes("whatsapp_business_management")) warnings.push("whatsapp_business_management_not_reported_in_token_scopes");

    await audit(admin, { ...auditBase, connection_id: connectionId, status: "success" });
    return json({
      ok: true,
      connection_id: connectionId,
      onboarding_method: "manual",
      manual_setup_status: "webhook_pending",
      meta_app_id: appId,
      waba_id: wabaId,
      phone_number_id: phoneNumberId,
      display_phone_number: publicPhone || null,
      verified_name: String(selectedPhone.verified_name ?? ""),
      callback_url: `${supabaseUrl}/functions/v1/whatsapp-webhook`,
      verify_token: verifyToken,
      webhook_field: "messages",
      waba_subscribed_to_app: true,
      token_configured: true,
      token_expires_at: expiresAt > 0 ? new Date(expiresAt * 1000).toISOString() : null,
      data_access_expires_at: dataAccessExpiresAt > 0 ? new Date(dataAccessExpiresAt * 1000).toISOString() : null,
      warnings,
    });
  } catch (error) {
    const message = errorText(error);
    console.error("whatsapp_manual_connect_failed", message);
    await audit(admin, { ...auditBase, status: "failed", error_message: message.slice(0, 1800) });
    try {
      await admin.from("whatsapp_business_connections").update({
        manual_setup_status: "error",
        manual_last_error: message.slice(0, 1800),
        updated_at: new Date().toISOString(),
      }).eq("organization_id", store.organization_id).eq("store_id", storeId).eq("phone_number_id", phoneNumberId);
    } catch { /* best effort */ }
    return json({ error: "manual_connect_failed", message }, 502);
  }
});
