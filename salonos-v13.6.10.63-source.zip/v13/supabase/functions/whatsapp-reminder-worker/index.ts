import { createClient } from "npm:@supabase/supabase-js@2";

type Json = Record<string, unknown>;

type ReminderRow = {
  id: string;
  organization_id: string;
  store_id: string;
  visit_id: string;
  connection_id: string;
  conversation_id: string | null;
  customer_id: string | null;
  customer_phone: string;
  customer_name: string | null;
  store_name: string | null;
  service_name: string | null;
  employee_name: string | null;
  scheduled_at: string;
  reminder_minutes_before: number;
  due_at: string;
  attempts: number;
  last_inbound_at: string | null;
};

function env(name: string): string {
  return (Deno.env.get(name) ?? "").trim();
}

function serviceKey(): string {
  const legacy = env("SUPABASE_SERVICE_ROLE_KEY");
  if (legacy) return legacy;
  try {
    const keys = JSON.parse(env("SUPABASE_SECRET_KEYS") || "{}") as Record<string, string>;
    return (keys.default ?? Object.values(keys)[0] ?? "").trim();
  } catch {
    return "";
  }
}

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function errorText(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  try { return JSON.stringify(error); } catch { return "unknown_error"; }
}

function malaysiaParts(value: string): { date: string; time: string } {
  const d = new Date(value);
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kuala_Lumpur",
    day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).formatToParts(d);
  const p = Object.fromEntries(parts.map((x) => [x.type, x.value]));
  return { date: `${p.day}/${p.month}/${p.year}`, time: `${p.hour}:${p.minute}` };
}

function renderReminder(template: string | null | undefined, row: ReminderRow): string {
  const t = (template ?? "").trim() ||
    "您好 {customer}，提醒您 {date} {time} 在 {store} 有预约：{service} · {staff}。如需改期或取消，请直接回复这条消息。";
  const local = malaysiaParts(row.scheduled_at);
  const replacements: Record<string, string> = {
    customer: row.customer_name?.trim() || "顾客",
    date: local.date,
    time: local.time,
    store: row.store_name?.trim() || "Salon",
    service: row.service_name?.trim() || "预约服务",
    staff: row.employee_name?.trim() || "理发师",
  };
  return t.replace(/\{(customer|date|time|store|service|staff)\}/g, (_, k: string) => replacements[k] ?? "");
}

async function metaSendText(args: {
  version: string; phoneNumberId: string; accessToken: string; to: string; text: string;
}): Promise<{ messageId: string | null; body: Json }> {
  const response = await fetch(`https://graph.facebook.com/${args.version}/${encodeURIComponent(args.phoneNumberId)}/messages`, {
    method: "POST",
    headers: { authorization: `Bearer ${args.accessToken}`, "content-type": "application/json" },
    body: JSON.stringify({ messaging_product: "whatsapp", recipient_type: "individual", to: args.to, type: "text", text: { preview_url: false, body: args.text } }),
  });
  let body: Json = {};
  try { body = await response.json() as Json; } catch { /* handled below */ }
  if (!response.ok) {
    const msg = String(((body.error as Json | undefined)?.message ?? `HTTP ${response.status}`));
    throw new Error(`meta_send_text_error:${msg}`);
  }
  const messages = Array.isArray(body.messages) ? body.messages as Json[] : [];
  return { messageId: typeof messages[0]?.id === "string" ? String(messages[0].id) : null, body };
}

async function metaSendTemplate(args: {
  version: string; phoneNumberId: string; accessToken: string; to: string;
  templateName: string; languageCode: string; row: ReminderRow;
}): Promise<{ messageId: string | null; body: Json }> {
  const local = malaysiaParts(args.row.scheduled_at);
  const values = [
    args.row.customer_name?.trim() || "顾客",
    local.date,
    local.time,
    args.row.service_name?.trim() || "预约服务",
    args.row.employee_name?.trim() || "理发师",
    args.row.store_name?.trim() || "Salon",
  ];
  const response = await fetch(`https://graph.facebook.com/${args.version}/${encodeURIComponent(args.phoneNumberId)}/messages`, {
    method: "POST",
    headers: { authorization: `Bearer ${args.accessToken}`, "content-type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: args.to,
      type: "template",
      template: {
        name: args.templateName,
        language: { code: args.languageCode },
        components: [{ type: "body", parameters: values.map((text) => ({ type: "text", text })) }],
      },
    }),
  });
  let body: Json = {};
  try { body = await response.json() as Json; } catch { /* handled below */ }
  if (!response.ok) {
    const msg = String(((body.error as Json | undefined)?.message ?? `HTTP ${response.status}`));
    throw new Error(`meta_send_template_error:${msg}`);
  }
  const messages = Array.isArray(body.messages) ? body.messages as Json[] : [];
  return { messageId: typeof messages[0]?.id === "string" ? String(messages[0].id) : null, body };
}

Deno.serve(async (req) => {
  if (req.method === "GET") return json({ ok: true, service: "salonos-whatsapp-reminder-worker", version: "13.6.8" });
  if (req.method !== "POST") return json({ ok: false, error: "method_not_allowed" }, 405);

  const workerToken = env("SALONOS_AI_WORKER_TOKEN");
  const supplied = req.headers.get("x-salonos-worker-token") ?? "";
  if (!workerToken || !constantTimeEqual(workerToken, supplied)) return json({ ok: false, error: "unauthorized" }, 401);

  const supabaseUrl = env("SUPABASE_URL");
  const key = serviceKey();
  if (!supabaseUrl || !key) return json({ ok: false, error: "supabase_service_key_missing" }, 500);
  const supabase = createClient(supabaseUrl, key, { auth: { persistSession: false } });

  let body: Json = {};
  try { body = await req.json() as Json; } catch { /* optional body */ }
  const limit = Math.max(1, Math.min(Number(body.limit ?? 20) || 20, 100));

  const { data: remindersRaw, error: claimError } = await supabase.rpc("v1368_claim_due_reminders", { p_limit: limit });
  if (claimError) return json({ ok: false, error: `claim_failed:${claimError.message}` }, 500);
  const reminders = (Array.isArray(remindersRaw) ? remindersRaw : []) as ReminderRow[];
  const results: Json[] = [];

  for (const row of reminders) {
    try {
      const { data: cfg, error: cfgError } = await supabase
        .from("whatsapp_store_configs")
        .select("access_token,graph_api_version,reminder_enabled,reminder_text_template,reminder_template_name,reminder_template_language")
        .eq("organization_id", row.organization_id).eq("store_id", row.store_id).eq("connection_id", row.connection_id).maybeSingle();
      if (cfgError) throw cfgError;
      if (!cfg?.reminder_enabled) {
        await supabase.rpc("v1368_finish_reminder", { p_reminder_id: row.id, p_status: "skipped", p_error: "reminder_disabled" });
        results.push({ id: row.id, status: "skipped", reason: "reminder_disabled" });
        continue;
      }
      const accessToken = String(cfg.access_token ?? "").trim();
      if (!accessToken) throw new Error("branch_access_token_missing");

      const { data: conn, error: connError } = await supabase.from("whatsapp_business_connections")
        .select("phone_number_id,enabled")
        .eq("id", row.connection_id).eq("organization_id", row.organization_id).eq("store_id", row.store_id).maybeSingle();
      if (connError) throw connError;
      if (!conn?.enabled || !conn.phone_number_id) throw new Error("whatsapp_connection_disabled_or_missing");

      const version = String(cfg.graph_api_version ?? "v26.0").trim() || "v26.0";
      const phone = String(row.customer_phone ?? "").replace(/\D+/g, "");
      if (!phone) throw new Error("customer_phone_missing");

      const lastInboundMs = row.last_inbound_at ? new Date(row.last_inbound_at).getTime() : 0;
      const insideServiceWindow = lastInboundMs > 0 && (Date.now() - lastInboundMs) < 24 * 60 * 60 * 1000;
      let mode: "text" | "template";
      let sent: { messageId: string | null; body: Json };
      let sentText: string | null = null;

      if (insideServiceWindow) {
        mode = "text";
        sentText = renderReminder(String(cfg.reminder_text_template ?? ""), row);
        sent = await metaSendText({ version, phoneNumberId: String(conn.phone_number_id), accessToken, to: phone, text: sentText });
      } else {
        const templateName = String(cfg.reminder_template_name ?? "").trim();
        if (!templateName) {
          await supabase.rpc("v1368_finish_reminder", {
            p_reminder_id: row.id, p_status: "template_required", p_error: "outside_24h_window_and_template_not_configured",
          });
          results.push({ id: row.id, status: "template_required" });
          continue;
        }
        mode = "template";
        sent = await metaSendTemplate({
          version, phoneNumberId: String(conn.phone_number_id), accessToken, to: phone,
          templateName, languageCode: String(cfg.reminder_template_language ?? "zh_CN") || "zh_CN", row,
        });
      }

      let outboundMessageId: string | null = null;
      if (row.conversation_id) {
        const messagePayload = {
          organization_id: row.organization_id,
          store_id: row.store_id,
          connection_id: row.connection_id,
          conversation_id: row.conversation_id,
          direction: "outbound",
          meta_message_id: sent.messageId,
          message_type: mode === "template" ? "template" : "text",
          text_body: sentText,
          delivery_status: "sent",
          ai_status: "completed",
          reply_kind: "appointment_reminder",
          reply_context: { reminder_id: row.id, visit_id: row.visit_id, send_mode: mode, scheduled_at: row.scheduled_at },
          sent_at: new Date().toISOString(),
          raw_payload: sent.body,
        };
        const { data: outbound, error: outError } = await supabase.from("whatsapp_messages").insert(messagePayload).select("id").single();
        if (outError && !String(outError.message).toLowerCase().includes("duplicate")) throw outError;
        outboundMessageId = outbound?.id ? String(outbound.id) : null;
      }

      await supabase.rpc("v1368_finish_reminder", {
        p_reminder_id: row.id,
        p_status: "sent",
        p_send_mode: mode,
        p_meta_message_id: sent.messageId,
        p_outbound_message_id: outboundMessageId,
        p_error: null,
      });
      await supabase.from("whatsapp_store_configs").update({ last_send_at: new Date().toISOString(), last_send_error: null, updated_at: new Date().toISOString() })
        .eq("organization_id", row.organization_id).eq("store_id", row.store_id);
      results.push({ id: row.id, status: "sent", send_mode: mode, meta_message_id: sent.messageId });
    } catch (error) {
      const msg = errorText(error).slice(0, 1200);
      await supabase.rpc("v1368_finish_reminder", { p_reminder_id: row.id, p_status: "failed", p_error: msg });
      await supabase.from("whatsapp_store_configs").update({ last_send_error: msg, updated_at: new Date().toISOString() })
        .eq("organization_id", row.organization_id).eq("store_id", row.store_id);
      results.push({ id: row.id, status: "failed", error: msg });
    }
  }

  return json({ ok: true, version: "13.6.8", claimed: reminders.length, results });
});
