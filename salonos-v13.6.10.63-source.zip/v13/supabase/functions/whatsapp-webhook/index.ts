import { createClient } from "npm:@supabase/supabase-js@2";

type Json = Record<string, unknown>;

declare const EdgeRuntime: { waitUntil(promise: Promise<unknown>): void } | undefined;

const encoder = new TextEncoder();

function env(name: string): string {
  return (Deno.env.get(name) ?? "").trim();
}

function serviceKey(): string {
  const legacy = env("SUPABASE_SERVICE_ROLE_KEY");
  if (legacy) return legacy;
  try {
    const keys = JSON.parse(env("SUPABASE_SECRET_KEYS") || "{}") as Record<string, string>;
    return (keys.default ?? Object.values(keys)[0] ?? "").trim();
  } catch {
    return "";
  }
}

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function normalizePhone(value: unknown): string {
  return String(value ?? "").replace(/\D+/g, "");
}

function hex(bytes: ArrayBuffer): string {
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha256Hex(value: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(value));
  return hex(digest);
}

function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

async function verifyMetaSignature(rawBody: string, signatureHeader: string, appSecret: string): Promise<boolean> {
  if (!signatureHeader.startsWith("sha256=") || !appSecret) return false;
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(appSecret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const digest = await crypto.subtle.sign("HMAC", key, encoder.encode(rawBody));
  return constantTimeEqual(`sha256=${hex(digest)}`, signatureHeader.toLowerCase());
}

function extractText(message: Json): string {
  const type = String(message.type ?? "unknown");
  if (type === "text") return String((message.text as Json | undefined)?.body ?? "");
  if (type === "button") return String((message.button as Json | undefined)?.text ?? "");
  if (type === "interactive") {
    const interactive = (message.interactive as Json | undefined) ?? {};
    const buttonReply = (interactive.button_reply as Json | undefined) ?? {};
    const listReply = (interactive.list_reply as Json | undefined) ?? {};
    return String(buttonReply.title ?? listReply.title ?? "");
  }
  if (["image", "video", "document"].includes(type)) {
    return String(((message[type] as Json | undefined) ?? {}).caption ?? "");
  }
  return "";
}

function extractRef(text: string): string | null {
  if (!text) return null;
  const explicit = text.match(/\bRef\s*[:：]\s*([A-Za-z0-9][A-Za-z0-9_-]{2,63})\b/i);
  if (explicit?.[1]) return explicit[1].toUpperCase();
  // SalonOS generated refs normally end with a 4-char hex suffix, e.g. JASON-R001-A82K / JASON-R001-A82F.
  const generated = text.match(/\b([A-Z0-9][A-Z0-9_-]{2,48}-[A-Z0-9]{4})\b/i);
  return generated?.[1] ? generated[1].toUpperCase() : null;
}

async function resolveAttribution(
  supabase: ReturnType<typeof createClient>,
  refCode: string | null,
  organizationId: string,
  storeId: string,
) {
  if (!refCode) return { matched: false, refCode: null, link: null, status: "ref_missing" };
  const { data: click } = await supabase
    .from("tracking_clicks")
    .select("tracking_link_id,ref_code,clicked_at")
    .eq("organization_id", organizationId)
    .eq("store_id", storeId)
    .eq("ref_code", refCode)
    .order("clicked_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (!click?.tracking_link_id) return { matched: false, refCode, link: null, status: "invalid_ref" };
  const { data: link } = await supabase
    .from("tracking_links")
    .select("id,organization_id,store_id,channel_id,social_account_id,content_id,staff_id")
    .eq("organization_id", organizationId)
    .eq("store_id", storeId)
    .eq("id", click.tracking_link_id)
    .limit(1)
    .maybeSingle();
  if (!link) return { matched: false, refCode, link: null, status: "invalid_ref" };
  return { matched: true, refCode, link, status: "matched" };
}

async function upsertConversation(
  supabase: ReturnType<typeof createClient>,
  connection: Json,
  waId: string,
  phone: string,
  customerName: string,
) {
  const now = new Date().toISOString();
  const payload = {
    organization_id: connection.organization_id,
    store_id: connection.store_id,
    connection_id: connection.id,
    customer_wa_id: waId,
    customer_phone: phone,
    customer_name: customerName || null,
    last_message_at: now,
    updated_at: now,
  };
  const { data, error } = await supabase
    .from("whatsapp_conversations")
    .upsert(payload, { onConflict: "connection_id,customer_wa_id" })
    .select("id,current_lead_id,status,ai_enabled")
    .single();
  if (error) throw error;
  return data;
}

async function ensureLead(
  supabase: ReturnType<typeof createClient>,
  connection: Json,
  conversation: Json,
  phone: string,
  metaMessageId: string,
  attribution: Awaited<ReturnType<typeof resolveAttribution>>,
) {
  let current: Json | null = null;
  if (conversation.current_lead_id) {
    const { data } = await supabase
      .from("marketing_leads")
      .select("id,lead_status,ref_code,tracking_link_id")
      .eq("id", String(conversation.current_lead_id))
      .maybeSingle();
    if (data && !["completed", "lost"].includes(String(data.lead_status ?? ""))) current = data;
  }

  const now = new Date().toISOString();
  const link = attribution.link as Json | null;
  const leadPatch: Json = {
    organization_id: connection.organization_id,
    store_id: connection.store_id,
    whatsapp_conversation_id: conversation.id,
    customer_phone: phone,
    whatsapp_message_id: metaMessageId || null,
    first_message_at: now,
    attribution_status: attribution.status,
    source_fallback_needed: !attribution.matched,
    updated_at: now,
  };
  if (attribution.matched && link) {
    leadPatch.tracking_link_id = link.id;
    leadPatch.channel_id = link.channel_id ?? null;
    leadPatch.social_account_id = link.social_account_id ?? null;
    leadPatch.content_id = link.content_id ?? null;
    leadPatch.staff_id = link.staff_id ?? null;
    leadPatch.ref_code = attribution.refCode;
    leadPatch.source_fallback_needed = false;
  }

  let leadId = current?.id ? String(current.id) : "";
  if (leadId) {
    // Do not erase an existing good attribution when later messages contain no Ref.
    if (!attribution.matched && current?.tracking_link_id) {
      delete leadPatch.attribution_status;
      delete leadPatch.source_fallback_needed;
      delete leadPatch.first_message_at;
      delete leadPatch.whatsapp_message_id;
    }
    const { error } = await supabase.from("marketing_leads").update(leadPatch).eq("id", leadId);
    if (error) throw error;
  } else {
    const { data, error } = await supabase
      .from("marketing_leads")
      .insert({ ...leadPatch, lead_status: "new" })
      .select("id")
      .single();
    if (error) throw error;
    leadId = String(data.id);
    const { error: convError } = await supabase
      .from("whatsapp_conversations")
      .update({ current_lead_id: leadId, updated_at: now })
      .eq("id", String(conversation.id));
    if (convError) throw convError;
  }
  return leadId;
}

async function storeInboundMessage(
  supabase: ReturnType<typeof createClient>,
  connection: Json,
  conversation: Json,
  message: Json,
  refCode: string | null,
  textBody: string,
) {
  const metaMessageId = String(message.id ?? "");
  if (metaMessageId) {
    const { data: existing } = await supabase
      .from("whatsapp_messages")
      .select("id")
      .eq("meta_message_id", metaMessageId)
      .maybeSingle();
    if (existing?.id) return { id: String(existing.id), duplicate: true };
  }
  const receivedAt = message.timestamp
    ? new Date(Number(message.timestamp) * 1000).toISOString()
    : new Date().toISOString();
  const payload = {
    organization_id: connection.organization_id,
    store_id: connection.store_id,
    connection_id: connection.id,
    conversation_id: conversation.id,
    direction: "inbound",
    meta_message_id: metaMessageId || null,
    message_type: String(message.type ?? "unknown"),
    text_body: textBody || null,
    ref_code: refCode,
    delivery_status: "received",
    ai_status: "queued",
    raw_payload: message,
    received_at: receivedAt,
  };
  const { data, error } = await supabase.from("whatsapp_messages").insert(payload).select("id").single();
  if (error) {
    // Meta can retry the same webhook. The unique message id makes processing idempotent.
    if (metaMessageId) {
      const { data: existing } = await supabase
        .from("whatsapp_messages")
        .select("id")
        .eq("meta_message_id", metaMessageId)
        .maybeSingle();
      if (existing?.id) return { id: String(existing.id), duplicate: true };
    }
    throw error;
  }
  return { id: String(data.id), duplicate: false };
}

async function queueForAi(
  supabase: ReturnType<typeof createClient>,
  connection: Json,
  conversation: Json,
  messageId: string,
  leadId: string,
  attribution: Awaited<ReturnType<typeof resolveAttribution>>,
  textBody: string,
) {
  const context = {
    source: "whatsapp_cloud_api",
    text: textBody,
    ref_code: attribution.refCode,
    attribution_status: attribution.status,
    attribution_matched: attribution.matched,
    source_fallback_needed: !attribution.matched,
    next_step: attribution.matched ? "ai_process_message" : "ai_process_message_and_ask_source_if_needed",
  };
  const { data, error } = await supabase.from("whatsapp_ai_queue").insert({
    organization_id: connection.organization_id,
    store_id: connection.store_id,
    connection_id: connection.id,
    conversation_id: conversation.id,
    message_id: messageId,
    lead_id: leadId || null,
    status: "queued",
    context,
    updated_at: new Date().toISOString(),
  }).select("id").single();
  if (error) throw error;
  return data as Json;
}

async function triggerAiWorker(supabaseUrl: string, queueId: string): Promise<void> {
  const workerToken = env("SALONOS_AI_WORKER_TOKEN");
  if (!workerToken) {
    console.warn(`AI queue ${queueId} created but SALONOS_AI_WORKER_TOKEN is not configured; worker was not auto-triggered.`);
    return;
  }
  try {
    const response = await fetch(`${supabaseUrl}/functions/v1/whatsapp-ai-worker`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-salonos-worker-token": workerToken,
      },
      body: JSON.stringify({ queue_id: queueId }),
    });
    if (!response.ok) {
      console.error(`AI worker trigger failed queue=${queueId} HTTP ${response.status}: ${await response.text()}`);
    }
  } catch (error) {
    console.error(`AI worker trigger exception queue=${queueId}`, error);
  }
}

function runInBackground(task: Promise<unknown>): void {
  try {
    if (typeof EdgeRuntime !== "undefined" && EdgeRuntime?.waitUntil) {
      EdgeRuntime.waitUntil(task);
      return;
    }
  } catch { /* local/non-Supabase runtime fallback below */ }
  task.catch((error) => console.error("Background AI worker task failed", error));
}

async function processStatuses(supabase: ReturnType<typeof createClient>, statuses: unknown[]) {
  for (const raw of statuses) {
    const status = (raw ?? {}) as Json;
    const id = String(status.id ?? "");
    if (!id) continue;
    await supabase
      .from("whatsapp_messages")
      .update({ delivery_status: String(status.status ?? "unknown") })
      .eq("meta_message_id", id);
  }
}

function extractPayloadPhoneNumberIds(payload: Json): string[] {
  const ids = new Set<string>();
  const entries = Array.isArray(payload.entry) ? payload.entry as unknown[] : [];
  for (const entryRaw of entries) {
    const entry = (entryRaw ?? {}) as Json;
    const changes = Array.isArray(entry.changes) ? entry.changes as unknown[] : [];
    for (const changeRaw of changes) {
      const change = (changeRaw ?? {}) as Json;
      const value = ((change.value as Json | undefined) ?? {});
      const metadata = ((value.metadata as Json | undefined) ?? {});
      const phoneNumberId = String(metadata.phone_number_id ?? "").trim();
      if (phoneNumberId) ids.add(phoneNumberId);
    }
  }
  return [...ids];
}

export default {
  async fetch(req: Request): Promise<Response> {
    const url = new URL(req.url);
    const verifyToken = env("WHATSAPP_VERIFY_TOKEN");
    const globalAppSecret = env("META_APP_SECRET");
    const supabaseUrl = env("SUPABASE_URL");
    const key = serviceKey();

    if (req.method === "GET") {
      const mode = url.searchParams.get("hub.mode") ?? "";
      const token = url.searchParams.get("hub.verify_token") ?? "";
      const challenge = url.searchParams.get("hub.challenge") ?? "";
      if (mode !== "subscribe" || !token) return new Response("Webhook verification failed", { status: 403 });

      // Backward compatible verification for the SalonOS-owned Meta App.
      if (verifyToken && constantTimeEqual(token, verifyToken)) {
        return new Response(challenge, { status: 200, headers: { "content-type": "text/plain" } });
      }

      // v13.6.10.36: every manually connected customer Meta App receives a
      // unique Verify Token. Only its SHA-256 hash is stored.
      if (!supabaseUrl || !key) return new Response("Webhook verification failed", { status: 403 });
      const supabase = createClient(supabaseUrl, key, { auth: { persistSession: false, autoRefreshToken: false } });
      const tokenHash = await sha256Hex(token);
      const { data: secretRow } = await supabase
        .from("whatsapp_connection_secrets")
        .select("connection_id")
        .eq("verify_token_hash", tokenHash)
        .limit(1)
        .maybeSingle();
      if (secretRow?.connection_id) {
        const now = new Date().toISOString();
        await supabase.from("whatsapp_connection_secrets").update({ webhook_verified_at: now, updated_at: now })
          .eq("connection_id", String(secretRow.connection_id));
        await supabase.from("whatsapp_business_connections").update({
          manual_setup_status: "webhook_verified",
          manual_last_error: null,
          updated_at: now,
        }).eq("id", String(secretRow.connection_id));
        return new Response(challenge, { status: 200, headers: { "content-type": "text/plain" } });
      }
      return new Response("Webhook verification failed", { status: 403 });
    }

    if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
    if (!supabaseUrl || !key) {
      console.error("Missing SUPABASE_URL/service key");
      return json({ ok: false, error: "server_not_configured" }, 500);
    }

    const rawBody = await req.text();
    let payload: Json;
    try {
      payload = JSON.parse(rawBody) as Json;
    } catch {
      return json({ ok: false, error: "invalid_json" }, 400);
    }

    const signature = (req.headers.get("x-hub-signature-256") ?? "").toLowerCase();
    const supabase = createClient(supabaseUrl, key, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    // The same callback URL can receive webhooks signed by the SalonOS Meta App
    // or by a customer's own Meta App. We first inspect only the untrusted phone
    // id so we can locate candidate secrets; nothing is processed until HMAC passes.
    const phoneNumberIds = extractPayloadPhoneNumberIds(payload);
    const matchedManualConnectionIds = new Set<string>();
    const manualSecretConnectionIds = new Set<string>();
    let globalSignatureValid = false;
    if (globalAppSecret) globalSignatureValid = await verifyMetaSignature(rawBody, signature, globalAppSecret);

    if (phoneNumberIds.length) {
      const { data: candidateConnections, error: candidateError } = await supabase
        .from("whatsapp_business_connections")
        .select("id,phone_number_id")
        .in("phone_number_id", phoneNumberIds)
        .eq("enabled", true);
      if (candidateError) throw candidateError;
      const candidateIds = (candidateConnections ?? []).map((row) => String(row.id)).filter(Boolean);
      if (candidateIds.length) {
        const { data: secretRows, error: secretError } = await supabase
          .from("whatsapp_connection_secrets")
          .select("connection_id,meta_app_secret")
          .in("connection_id", candidateIds);
        if (secretError) {
          // v13.6.10.36 SQL may not be installed yet. Preserve global-app behavior.
          console.warn("Manual WhatsApp secret lookup unavailable", secretError.message);
        } else {
          for (const row of secretRows ?? []) {
            const connectionId = String(row.connection_id ?? "");
            const secret = String(row.meta_app_secret ?? "");
            if (!connectionId || !secret) continue;
            manualSecretConnectionIds.add(connectionId);
            if (await verifyMetaSignature(rawBody, signature, secret)) matchedManualConnectionIds.add(connectionId);
          }
        }
      }
    }

    if (!globalSignatureValid && matchedManualConnectionIds.size === 0) {
      console.warn("Rejected WhatsApp webhook: invalid Meta signature");
      return json({ ok: false, error: "invalid_signature" }, 401);
    }

    if (String(payload.object ?? "") !== "whatsapp_business_account") {
      return json({ ok: true, ignored: "unsupported_object" });
    }

    let processed = 0;
    let queued = 0;
    const entries = Array.isArray(payload.entry) ? payload.entry as unknown[] : [];
    for (const entryRaw of entries) {
      const entry = (entryRaw ?? {}) as Json;
      const changes = Array.isArray(entry.changes) ? entry.changes as unknown[] : [];
      for (const changeRaw of changes) {
        const change = (changeRaw ?? {}) as Json;
        const value = ((change.value as Json | undefined) ?? {});
        const metadata = ((value.metadata as Json | undefined) ?? {});
        const phoneNumberId = String(metadata.phone_number_id ?? "").trim();
        if (!phoneNumberId) continue;

        const { data: connection, error: connectionError } = await supabase
          .from("whatsapp_business_connections")
          .select("id,organization_id,store_id,phone_number_id,business_account_id,display_phone_number,enabled")
          .eq("phone_number_id", phoneNumberId)
          .eq("enabled", true)
          .limit(1)
          .maybeSingle();
        if (connectionError) throw connectionError;
        if (!connection) {
          console.warn(`No SalonOS branch bound to phone_number_id=${phoneNumberId}`);
          continue;
        }

        const connectionId = String(connection.id);
        // A connection with its own stored customer App Secret must match that
        // secret. A valid SalonOS-global signature cannot authorize another app's branch.
        if (manualSecretConnectionIds.has(connectionId) && !matchedManualConnectionIds.has(connectionId)) {
          console.warn(`Rejected cross-app WhatsApp payload for connection=${connectionId}`);
          continue;
        }
        if (!manualSecretConnectionIds.has(connectionId) && !globalSignatureValid) continue;

        const now = new Date().toISOString();
        const connectionPatch: Json = {
          connection_status: "live",
          last_webhook_at: now,
          last_error: null,
          updated_at: now,
        };
        if (matchedManualConnectionIds.has(connectionId)) {
          connectionPatch.manual_setup_status = "live";
          connectionPatch.manual_last_error = null;
          await supabase.from("whatsapp_connection_secrets").update({ webhook_verified_at: now, updated_at: now })
            .eq("connection_id", connectionId);
        }
        await supabase.from("whatsapp_business_connections").update(connectionPatch).eq("id", connectionId);

        const statuses = Array.isArray(value.statuses) ? value.statuses as unknown[] : [];
        if (statuses.length) await processStatuses(supabase, statuses);

        const contacts = Array.isArray(value.contacts) ? value.contacts as Json[] : [];
        const contactByWaId = new Map<string, string>();
        for (const c of contacts) {
          const waId = String(c.wa_id ?? "");
          const name = String(((c.profile as Json | undefined) ?? {}).name ?? "");
          if (waId) contactByWaId.set(waId, name);
        }

        const messages = Array.isArray(value.messages) ? value.messages as Json[] : [];
        for (const message of messages) {
          const waId = String(message.from ?? "").trim();
          const phone = normalizePhone(waId);
          if (!waId || !phone) continue;
          const customerName = contactByWaId.get(waId) ?? "";
          const textBody = extractText(message).trim();
          const refCode = extractRef(textBody);
          const attribution = await resolveAttribution(
            supabase,
            refCode,
            String(connection.organization_id),
            String(connection.store_id),
          );

          const conversation = await upsertConversation(supabase, connection as Json, waId, phone, customerName);
          const stored = await storeInboundMessage(supabase, connection as Json, conversation as Json, message, refCode, textBody);
          if (stored.duplicate) continue;

          const leadId = await ensureLead(
            supabase,
            connection as Json,
            conversation as Json,
            phone,
            String(message.id ?? ""),
            attribution,
          );
          const aiQueue = await queueForAi(
            supabase,
            connection as Json,
            conversation as Json,
            stored.id,
            leadId,
            attribution,
            textBody,
          );
          const aiQueueId = String(aiQueue.id ?? "");
          if (aiQueueId) runInBackground(triggerAiWorker(supabaseUrl, aiQueueId));
          processed++;
          queued++;
        }
      }
    }

    return json({ ok: true, processed, ai_queued: queued });
  },
};
