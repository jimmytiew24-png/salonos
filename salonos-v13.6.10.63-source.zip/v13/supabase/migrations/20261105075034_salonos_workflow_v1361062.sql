-- SalonOS .62: workflow integrity, receipt reversal, and operations review.
begin;
set local lock_timeout = '5s';

create schema if not exists salonos_workflow;
revoke all on schema salonos_workflow from public, anon, authenticated;

create table if not exists salonos_workflow.order_requests (
  store_id uuid not null references public.stores(id),
  actor_id uuid not null,
  request_id uuid not null,
  visit_id uuid not null references public.visits(id),
  created_at timestamptz not null default now(),
  primary key (store_id, actor_id, request_id)
);

create or replace function salonos_workflow.require_store(p_store_id uuid)
returns uuid language plpgsql stable set search_path = '' as $$
declare v_org uuid;
begin
  if auth.uid() is null then raise exception '请先用老板或经理账号登录。' using errcode='42501'; end if;
  select organization_id into v_org from public.stores where id=p_store_id and status='active';
  if v_org is null or not coalesce(public.can_access_store(p_store_id),false)
     or not coalesce(public.has_organization_role(v_org,array['owner','manager']),false) then
    raise exception '你没有当前分行的操作权限。' using errcode='42501';
  end if;
  return v_org;
end;
$$;

create or replace function salonos_workflow.lock_booking(p_org uuid)
returns void language sql volatile set search_path = '' as $$
  select pg_advisory_xact_lock(hashtextextended('salonos:booking:'||p_org::text,0));
$$;

create or replace function salonos_workflow.visit_minutes(p_visit uuid)
returns integer language sql stable set search_path = '' as $$
  select greatest(coalesce(sum(greatest(coalesce(estimated_minutes_snapshot,30),1)*greatest(quantity,1)),0),30)::integer
  from public.visit_service_items where visit_id=p_visit and status<>'cancelled';
$$;

create or replace function salonos_workflow.assert_slot(p_org uuid,p_visit uuid,p_employee uuid,p_start timestamptz,p_minutes integer)
returns void language plpgsql volatile set search_path = '' as $$
begin
  if p_start is null then return; end if;
  perform salonos_workflow.lock_booking(p_org);
  if exists (
    select 1 from public.visit_service_workers w
    join public.visit_service_items i on i.id=w.service_item_id and i.organization_id=w.organization_id
    join public.visits v on v.id=i.visit_id and v.organization_id=i.organization_id
    cross join lateral (select case when v.visit_type='appointment' then v.scheduled_at else coalesce(v.started_at,v.arrived_at,v.created_at) end as begins) t
    where v.organization_id=p_org and v.id<>p_visit and w.employee_id=p_employee and w.status='active'
      and i.status<>'cancelled' and v.status in ('booked','arrived','waiting','in_service','paused','ready_for_checkout')
      and t.begins < p_start + make_interval(mins=>p_minutes)
      and t.begins + make_interval(mins=>salonos_workflow.visit_minutes(v.id)) > p_start
  ) then
    raise exception '该员工的时段已被占用，请刷新并重新选择理发师或时间。' using errcode='P0001';
  end if;
end;
$$;

create or replace function salonos_workflow.guard_worker_slot()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v_visit public.visits%rowtype;
begin
  if new.status<>'active' then return new; end if;
  select v.* into v_visit from public.visits v join public.visit_service_items i on i.visit_id=v.id
    where i.id=new.service_item_id and i.organization_id=new.organization_id and i.store_id=new.store_id
      and v.organization_id=new.organization_id and v.store_id=new.store_id for update of v;
  if not found then raise exception '服务项目不属于当前门店。'; end if;
  if v_visit.status in ('completed','cancelled','no_show') then raise exception '已关闭的订单不能重新派人。'; end if;
  if v_visit.status in ('booked','arrived','waiting','in_service','paused','ready_for_checkout') then
    perform salonos_workflow.assert_slot(v_visit.organization_id,v_visit.id,new.employee_id,
      case when v_visit.visit_type='appointment' then v_visit.scheduled_at else coalesce(v_visit.started_at,v_visit.arrived_at,v_visit.created_at) end,
      salonos_workflow.visit_minutes(v_visit.id));
  end if;
  return new;
end;
$$;

create or replace function salonos_workflow.guard_visit_change()
returns trigger language plpgsql security definer set search_path = '' as $$
declare w record;
begin
  if new.status is distinct from old.status then
    if old.status in ('completed','cancelled','no_show') or exists(select 1 from public.payments p where p.visit_id=old.id and p.status in ('paid','refunded','voided') and new.status<>'completed') then
      raise exception '已关闭或已结账的订单不能退回服务流程。';
    end if;
    if not (case old.status
      when 'draft' then new.status in ('booked','arrived','waiting','cancelled','no_show')
      when 'booked' then new.status in ('arrived','waiting','cancelled','no_show')
      when 'arrived' then new.status in ('waiting','in_service','cancelled','no_show')
      when 'waiting' then new.status in ('arrived','in_service','cancelled','no_show')
      when 'in_service' then new.status in ('paused','ready_for_checkout','cancelled')
      when 'paused' then new.status in ('in_service','ready_for_checkout','cancelled')
      when 'ready_for_checkout' then new.status in ('completed','cancelled')
      else false end) then
      raise exception '当前订单状态不能执行这一步，请刷新订单后再试。';
    end if;
    if new.visit_type='appointment' and new.status='waiting' and new.arrived_at is null then
      raise exception '请先确认预约顾客到店。';
    end if;
  end if;
  if new.scheduled_at is distinct from old.scheduled_at and new.visit_type='appointment' then
    if new.status in ('completed','cancelled','no_show') then raise exception '已关闭的订单不能改期。'; end if;
    if new.scheduled_at is null then raise exception '预约时间不能为空。'; end if;
    perform salonos_workflow.lock_booking(new.organization_id);
    for w in select distinct a.employee_id from public.visit_service_workers a join public.visit_service_items i on i.id=a.service_item_id
      where i.visit_id=new.id and i.status<>'cancelled' and a.status='active' loop
      perform salonos_workflow.assert_slot(new.organization_id,new.id,w.employee_id,new.scheduled_at,salonos_workflow.visit_minutes(new.id));
    end loop;
  end if;
  return new;
end;
$$;

drop trigger if exists salonos_workflow_worker_slot on public.visit_service_workers;
create trigger salonos_workflow_worker_slot before insert or update of employee_id,service_item_id,status on public.visit_service_workers
for each row execute function salonos_workflow.guard_worker_slot();
drop trigger if exists salonos_workflow_visit_change on public.visits;
create trigger salonos_workflow_visit_change before update of status,scheduled_at on public.visits
for each row execute function salonos_workflow.guard_visit_change();

create or replace function public.v1361062_find_owner_order(p_store_id uuid,p_request_id uuid)
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare v_visit uuid;
begin
  perform salonos_workflow.require_store(p_store_id);
  select visit_id into v_visit from salonos_workflow.order_requests where store_id=p_store_id and actor_id=auth.uid() and request_id=p_request_id;
  return jsonb_build_object('visit_id',v_visit);
end;
$$;

create or replace function public.v1361062_create_owner_order(p_store_id uuid,p_request_id uuid,p_order jsonb)
returns jsonb language plpgsql volatile security definer set search_path = '' as $$
declare
  v_org uuid; v_visit uuid; v_item uuid; v_id uuid; v_recipient uuid; v_starts timestamptz; v_at timestamptz;
  v_type text; v_pref text; v_pref_employee uuid; v_rec jsonb; v_one jsonb; v_worker jsonb;
  v_item_service public.services%rowtype; v_customer public.customers%rowtype; v_c jsonb;
  v_map jsonb:='{}'; v_ids uuid[]; v_primary int; v_pct numeric; v_total numeric; v_role text;
  v_minutes int; v_count int; v_price numeric; v_digits text;
begin
  v_org:=salonos_workflow.require_store(p_store_id);
  if p_request_id is null then raise exception '缺少开单请求编号，请刷新后重试。'; end if;
  perform salonos_workflow.lock_booking(v_org);
  select visit_id into v_visit from salonos_workflow.order_requests where store_id=p_store_id and actor_id=auth.uid() and request_id=p_request_id;
  if found then return jsonb_build_object('visit_id',v_visit,'replayed',true); end if;
  if jsonb_typeof(p_order->'items') is distinct from 'array' or jsonb_typeof(p_order->'recipients') is distinct from 'array'
     or jsonb_typeof(p_order->'customer') is distinct from 'object' then raise exception '订单资料不完整。'; end if;
  if jsonb_array_length(p_order->'items') not between 1 and 40 or jsonb_array_length(p_order->'recipients')>30 then
    raise exception '请至少选择一个服务项目，并检查同行者数量。';
  end if;
  v_type:=p_order->>'visit_type';
  if v_type is null or v_type not in ('walk_in','appointment') then raise exception '到店方式无效。'; end if;
  v_at:=clock_timestamp();
  if v_type='appointment' then
    v_starts:=nullif(p_order->>'scheduled_at','')::timestamptz;
    if v_starts is null or v_starts<v_at then raise exception '请重新选择未来的预约时间。'; end if;
  else v_starts:=v_at; end if;
  select count(*),greatest(coalesce(sum(greatest(coalesce(s.estimated_minutes,60),1)),0),30)::int into v_count,v_minutes
    from jsonb_array_elements(p_order->'items') i join public.services s on s.id=(i->>'service_id')::uuid
    where s.organization_id=v_org and s.store_id=p_store_id and s.active;
  if v_count<>jsonb_array_length(p_order->'items') then raise exception '有服务已停用或不属于当前门店。'; end if;
  v_c:=p_order->'customer';
  v_id:=nullif(v_c->>'id','')::uuid;
  if v_id is not null then
    select * into v_customer from public.customers where id=v_id and organization_id=v_org and store_id=p_store_id;
    if not found then raise exception '顾客不属于当前门店。'; end if;
  else
    v_digits:=regexp_replace(coalesce(v_c->>'phone',''),'[^0-9]','','g');
    if v_digits='' or btrim(coalesce(v_c->>'name',''))='' then raise exception '顾客姓名和电话必填。'; end if;
    select * into v_customer from public.customers where organization_id=v_org and store_id=p_store_id
      and regexp_replace(coalesce(phone,''),'[^0-9]','','g')=v_digits order by created_at,id limit 1;
    if not found then
      insert into public.customers(organization_id,store_id,name,phone,gender,birth_date,ethnicity,acquisition_platform,notes)
      values(v_org,p_store_id,btrim(v_c->>'name'),btrim(v_c->>'phone'),
        case when v_c->>'gender' in ('male','female') then v_c->>'gender' else 'unspecified' end,
        nullif(v_c->>'birth_date','')::date,v_c->>'ethnicity',v_c->>'acquisition_platform',v_c->>'notes')
      returning * into v_customer;
    end if;
  end if;
  insert into public.visits(organization_id,store_id,visit_number,visit_type,status,scheduled_at,arrived_at,notes,created_by_user_id)
  values(v_org,p_store_id,'V'||to_char(v_at at time zone 'Asia/Kuala_Lumpur','YYMMDDHH24MISS')||'-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,8)),
    v_type,case when v_type='appointment' then 'booked' else 'arrived' end,
    case when v_type='appointment' then v_starts end,case when v_type='walk_in' then v_at end,p_order->>'notes',auth.uid())
  returning id into v_visit;
  insert into public.visit_recipients(organization_id,visit_id,customer_id,name_snapshot,phone_snapshot,recipient_type)
  values(v_org,v_visit,v_customer.id,v_customer.name,v_customer.phone,'primary') returning id into v_recipient;
  v_map:=jsonb_build_object('self',v_recipient);
  for v_rec in select value from jsonb_array_elements(p_order->'recipients') loop
    if nullif(btrim(v_rec->>'key'),'') is null or v_map ? (v_rec->>'key') or nullif(btrim(v_rec->>'name'),'') is null
       or coalesce(v_rec->>'type','') not in ('child','family','friend','other') then raise exception '同行者资料无效或重复。'; end if;
    insert into public.visit_recipients(organization_id,visit_id,name_snapshot,recipient_type,notes)
    values(v_org,v_visit,btrim(v_rec->>'name'),v_rec->>'type',v_rec->>'notes') returning id into v_recipient;
    v_map:=v_map||jsonb_build_object(v_rec->>'key',v_recipient);
  end loop;
  for v_one in select value from jsonb_array_elements(p_order->'items') loop
    select * into v_item_service from public.services where id=(v_one->>'service_id')::uuid
      and organization_id=v_org and store_id=p_store_id and active;
    if not found then raise exception '服务已停用，请重新选择。'; end if;
    v_recipient:=(v_map->>(v_one->>'recipient_key'))::uuid;
    if v_recipient is null then raise exception '请重新选择这个项目的服务对象。'; end if;
    v_price:=coalesce((v_one->>'price')::numeric,v_item_service.default_price);
    if v_price is null or v_price<0 or v_price>99999999 then raise exception '服务价格无效。'; end if;
    if jsonb_typeof(v_one->'workers') is distinct from 'array' then raise exception '请为服务分配员工。'; end if;
    if jsonb_array_length(v_one->'workers') not between 1 and 12 then raise exception '员工数量无效。'; end if;
    insert into public.visit_service_items(organization_id,store_id,visit_id,recipient_id,service_id,service_name_snapshot,service_category_snapshot,unit_price,quantity,estimated_minutes_snapshot,status)
    values(v_org,p_store_id,v_visit,v_recipient,v_item_service.id,v_item_service.name,v_item_service.category,v_price,1,coalesce(v_item_service.estimated_minutes,60),'waiting')
    returning id into v_item;
    v_ids:='{}'; v_primary:=0; v_total:=0;
    for v_worker in select value from jsonb_array_elements(v_one->'workers') loop
      v_id:=nullif(v_worker->>'id','')::uuid; v_role:=v_worker->>'role'; v_pct:=round((v_worker->>'pct')::numeric,2);
      if v_id is null or v_id=any(v_ids) or v_role is null or v_role not in ('primary','support','assistant')
         or v_pct is null or v_pct not between 0 and 100 then raise exception '服务的员工角色或贡献比例无效。'; end if;
      if v_role='assistant' and not coalesce(v_item_service.allows_assistant,false) then raise exception '该服务不允许分配助理。'; end if;
      if not coalesce(public.v1361030_employee_free_for_slot(v_org,p_store_id,v_id,v_starts,v_minutes,v_type,v_visit),false)
         or (v_role<>'assistant' and not coalesce(public.v1361030_employee_qualified_for_service(v_org,p_store_id,v_id,v_item_service.id),false)) then
        raise exception '所选员工已不可用或不符合服务要求，请刷新并重选。';
      end if;
      perform salonos_workflow.assert_slot(v_org,v_visit,v_id,v_starts,v_minutes);
      v_ids:=array_append(v_ids,v_id); v_total:=v_total+v_pct;
      if v_role='primary' then v_primary:=v_primary+1; end if;
      insert into public.visit_service_workers(organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status)
      values(v_org,p_store_id,v_item,v_id,v_role,v_pct,'active');
    end loop;
    if v_primary<>1 or abs(v_total-100)>0.05 then raise exception '每个项目必须有一位主理发师，贡献比例总计 100%%。'; end if;
  end loop;
  v_pref:=p_order->>'preference_type'; v_pref_employee:=nullif(p_order->>'preference_employee','')::uuid;
  if coalesce(v_pref,'') not in ('specified','random') then raise exception '预约偏好无效。'; end if;
  if v_pref='specified' and (v_pref_employee is null or not exists(select 1 from public.employees e join public.employee_stores es on es.employee_id=e.id
    where e.id=v_pref_employee and e.organization_id=v_org and e.employment_status='active'
      and es.organization_id=v_org and es.store_id=p_store_id and es.status='active')) then raise exception '指定员工已不在当前门店。'; end if;
  insert into public.appointment_employee_preferences(organization_id,store_id,visit_id,preference_type,employee_id)
  values(v_org,p_store_id,v_visit,v_pref,case when v_pref='specified' then v_pref_employee end);
  insert into salonos_workflow.order_requests(store_id,actor_id,request_id,visit_id) values(p_store_id,auth.uid(),p_request_id,v_visit);
  return jsonb_build_object('visit_id',v_visit,'replayed',false);
end;
$$;

create or replace function salonos_workflow.employee_visit_scope(p_session_token text,p_visit_id uuid,p_lock boolean)
returns jsonb language plpgsql set search_path = '' as $$
declare c jsonb; v_visit public.visits%rowtype; v_emp uuid;
begin
  c:=public.employee_session_context(p_session_token); v_emp:=(c->>'employee_id')::uuid;
  if v_emp is null then raise exception '员工登录已过期，请重新登录。' using errcode='42501'; end if;
  if p_lock then
    select * into v_visit from public.visits where id=p_visit_id and organization_id=(c->>'organization_id')::uuid and store_id=(c->>'store_id')::uuid for update;
  else
    select * into v_visit from public.visits where id=p_visit_id and organization_id=(c->>'organization_id')::uuid and store_id=(c->>'store_id')::uuid;
  end if;
  if v_visit.id is null then raise exception '找不到可操作的订单。' using errcode='42501'; end if;
  if coalesce(c->>'employee_role','staff') not in ('manager','receptionist') and not exists(
    select 1 from public.visit_service_items i join public.visit_service_workers w on w.service_item_id=i.id
      and w.organization_id=i.organization_id and w.store_id=i.store_id
    where i.visit_id=p_visit_id and i.organization_id=v_visit.organization_id and i.store_id=v_visit.store_id
      and i.status<>'cancelled' and w.employee_id=v_emp and w.status='active'
  ) then raise exception '你不是这笔订单的负责员工。' using errcode='42501'; end if;
  return c;
end;
$$;

create or replace function salonos_workflow.set_visit_status(p_visit_id uuid,p_status text)
returns jsonb language plpgsql set search_path = '' as $$
declare v_status text:=lower(coalesce(p_status,''));
begin
  if v_status not in ('booked','arrived','waiting','in_service','paused','ready_for_checkout','cancelled','no_show') then
    raise exception '不允许的订单状态。';
  end if;
  update public.visits set status=v_status,
    arrived_at=case when v_status='arrived' then coalesce(arrived_at,now()) else arrived_at end,
    started_at=case when v_status='in_service' then coalesce(started_at,now()) else started_at end,
    service_completed_at=case when v_status='ready_for_checkout' then coalesce(service_completed_at,now()) else service_completed_at end,
    updated_at=now() where id=p_visit_id;
  return jsonb_build_object('ok',true,'status',v_status);
end;
$$;

create or replace function public.v1344_employee_set_visit_status(p_session_token text,p_visit_id uuid,p_status text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare c jsonb; v_status text:=lower(coalesce(p_status,''));
begin
  c:=salonos_workflow.employee_visit_scope(p_session_token,p_visit_id,true);
  if v_status='booked' or (coalesce(c->>'employee_role','staff') not in ('manager','receptionist')
    and v_status not in ('arrived','waiting','in_service','paused','ready_for_checkout')) then
    raise exception '这个员工角色不能执行该状态操作。' using errcode='42501';
  end if;
  return salonos_workflow.set_visit_status(p_visit_id,v_status);
end;
$$;

create or replace function public.v1361062_owner_visit_status(p_store_id uuid,p_visit_id uuid,p_status text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_org uuid;
begin
  v_org:=salonos_workflow.require_store(p_store_id);
  perform 1 from public.visits where id=p_visit_id and organization_id=v_org and store_id=p_store_id for update;
  if not found then raise exception '找不到当前门店的订单。' using errcode='42501'; end if;
  return salonos_workflow.set_visit_status(p_visit_id,p_status);
end;
$$;

create or replace function public.v1361062_replace_workers(p_store_id uuid,p_service_item_id uuid,p_workers jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_org uuid; v_visit public.visits%rowtype; v_item public.visit_service_items%rowtype; w jsonb;
  v_emp uuid; v_role text; v_pct numeric; v_seen uuid[]:='{}'; v_total numeric:=0; v_primary integer:=0;
  v_start timestamptz; v_minutes integer; v_allows boolean;
begin
  v_org:=salonos_workflow.require_store(p_store_id);
  if jsonb_typeof(p_workers) is distinct from 'array' then raise exception '请选择工作人员。'; end if;
  if jsonb_array_length(p_workers) not between 1 and 12 then raise exception '工作人员数量无效。'; end if;
  select * into v_item from public.visit_service_items where id=p_service_item_id and organization_id=v_org and store_id=p_store_id;
  if not found or v_item.status='cancelled' then raise exception '找不到当前门店的有效服务项目。'; end if;
  select * into v_visit from public.visits where id=v_item.visit_id and organization_id=v_org and store_id=p_store_id for update;
  if not found or v_visit.status in ('completed','cancelled','no_show') then raise exception '已关闭的订单不能重新派人。'; end if;
  perform salonos_workflow.lock_booking(v_org);
  v_start:=case when v_visit.visit_type='appointment' then v_visit.scheduled_at else clock_timestamp() end;
  v_minutes:=salonos_workflow.visit_minutes(v_visit.id);
  select allows_assistant into v_allows from public.services where id=v_item.service_id and organization_id=v_org and store_id=p_store_id;
  for w in select value from jsonb_array_elements(p_workers) loop
    v_emp:=nullif(w->>'id','')::uuid; v_role:=w->>'role'; v_pct:=round((w->>'pct')::numeric,2);
    if v_emp is null or v_emp=any(v_seen) or v_role is null or v_role not in ('primary','support','assistant')
       or v_pct is null or v_pct not between 0 and 100 then raise exception '员工角色或贡献比例无效。'; end if;
    if (v_role='assistant' and not coalesce(v_allows,false))
      or not coalesce(public.v1361030_employee_free_for_slot(v_org,p_store_id,v_emp,v_start,v_minutes,v_visit.visit_type,v_visit.id),false)
      or (v_role<>'assistant' and not coalesce(public.v1361030_employee_qualified_for_service(v_org,p_store_id,v_emp,v_item.service_id),false)) then
      raise exception '所选员工已不可用或不符合服务要求，请刷新并重选。';
    end if;
    perform salonos_workflow.assert_slot(v_org,v_visit.id,v_emp,v_start,v_minutes);
    v_seen:=array_append(v_seen,v_emp); v_total:=v_total+v_pct;
    if v_role='primary' then v_primary:=v_primary+1; end if;
  end loop;
  if v_primary<>1 or abs(v_total-100)>0.05 then raise exception '请选择一位主理发师，贡献比例总计 100%%。'; end if;
  delete from public.visit_service_workers where service_item_id=v_item.id and organization_id=v_org and store_id=p_store_id;
  insert into public.visit_service_workers(organization_id,store_id,service_item_id,employee_id,worker_role,contribution_percent,status)
  select v_org,p_store_id,v_item.id,(value->>'id')::uuid,value->>'role',round((value->>'pct')::numeric,2),'active'
    from jsonb_array_elements(p_workers);
  return jsonb_build_object('ok',true);
end;
$$;

-- Preserve old employee clients, but do not leave the former unrestricted
-- visit_status / visit_detail actions exposed as alternate API routes.
do $$
begin
  if to_regprocedure('salonos_workflow.v13_employee_api(text,text,jsonb)') is null then
    alter function public.v13_employee_api(text,text,jsonb) set schema salonos_workflow;
  end if;
end;
$$;
revoke all on function salonos_workflow.v13_employee_api(text,text,jsonb) from public,anon,authenticated;
create or replace function public.v13_employee_api(p_session_token text,p_action text,p_payload jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare a text:=lower(coalesce(p_action,''));
begin
  if a='visit_status' then
    return public.v1344_employee_set_visit_status(p_session_token,(p_payload->>'visit_id')::uuid,p_payload->>'status');
  elsif a='visit_detail' then
    perform salonos_workflow.employee_visit_scope(p_session_token,(p_payload->>'visit_id')::uuid,false);
  end if;
  return salonos_workflow.v13_employee_api(p_session_token,p_action,p_payload);
end;
$$;

create table if not exists salonos_workflow.receipt_refunds (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null unique references public.payments(id),
  organization_id uuid not null,
  store_id uuid not null,
  visit_id uuid not null,
  receipt_number text not null,
  total numeric(12,2) not null,
  external_amount numeric(12,2) not null,
  wallet_amount numeric(12,2) not null,
  reason text not null,
  external_reference text,
  actor_id uuid not null,
  created_at timestamptz not null default now(),
  breakdown jsonb not null default '{}'::jsonb
);

create or replace function salonos_workflow.guard_order_product()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v_visit public.visits%rowtype; v_target uuid; v_org uuid; v_store uuid;
begin
  if tg_op='UPDATE' and (old.visit_id,old.organization_id,old.store_id) is distinct from (new.visit_id,new.organization_id,new.store_id) then
    raise exception '不能把订单商品转移到另一笔订单。';
  end if;
  if tg_op='DELETE' then v_target:=old.visit_id; v_org:=old.organization_id; v_store:=old.store_id;
  else v_target:=new.visit_id; v_org:=new.organization_id; v_store:=new.store_id; end if;
  select * into v_visit from public.visits where id=v_target for update;
  if not found or (v_visit.organization_id,v_visit.store_id) is distinct from (v_org,v_store) then
    raise exception '订单商品不属于当前门店。';
  end if;
  if v_visit.status in ('completed','cancelled','no_show') or exists(select 1 from public.payments p where p.visit_id=v_target) then
    -- Only the bookkeeping-only transition created by an approved refund
    -- can touch these rows. The recorded quantity and price stay immutable.
    if tg_op='UPDATE' and old.status='active' and new.status='returned'
       and (to_jsonb(new)-array['status','updated_at','line_total'])=(to_jsonb(old)-array['status','updated_at','line_total'])
       and exists(select 1 from salonos_workflow.receipt_refunds f join public.payments p on p.id=f.payment_id
         where f.visit_id=v_target and p.status='refunded') then return new; end if;
    raise exception '已结账或已关闭的订单不能增减商品。请用原收据办理退款。';
  end if;
  if tg_op='DELETE' then return old; end if;
  return new;
end;
$$;
drop trigger if exists salonos_workflow_order_product on public.visit_product_items;
create trigger salonos_workflow_order_product before insert or update or delete on public.visit_product_items
for each row execute function salonos_workflow.guard_order_product();

create or replace function public.v1361062_refund_receipt(p_store_id uuid,p_payment_id uuid,p_reason text,p_external_confirmed boolean,p_external_reference text default null,p_stock_return_confirmed boolean default false)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_org uuid; p public.payments%rowtype; v public.visits%rowtype; f salonos_workflow.receipt_refunds%rowtype;
  v_wallet numeric; v_external numeric; v_expected_wallet numeric; v_lines numeric; v_commission numeric; v_perf numeric;
  v_stock_rows integer; v_wallet_rows integer; v_loyalty_rows integer; v_commission_rows integer; x record;
begin
  v_org:=salonos_workflow.require_store(p_store_id);
  select * into p from public.payments where id=p_payment_id and organization_id=v_org and store_id=p_store_id;
  if not found then raise exception '找不到当前门店的收据。' using errcode='42501'; end if;
  -- Match checkout and product edit lock order: visit, receipt, wallets.
  select * into v from public.visits where id=p.visit_id and organization_id=v_org and store_id=p_store_id for update;
  if not found then raise exception '原收据没有有效订单。'; end if;
  select * into p from public.payments where id=p_payment_id and organization_id=v_org and store_id=p_store_id and visit_id=v.id for update;
  if not found then raise exception '原收据已发生变化，请刷新后再试。'; end if;
  select * into f from salonos_workflow.receipt_refunds where payment_id=p.id;
  if found then return to_jsonb(f)||jsonb_build_object('replayed',true); end if;
  if p.status<>'paid' or v.status<>'completed' then raise exception '只有已收款且完成的原收据可以退款。'; end if;
  if length(btrim(coalesce(p_reason,''))) not between 3 and 500 then raise exception '请填写退款原因（3–500 字）。'; end if;
  select coalesce(sum(amount),0),coalesce(sum(amount) filter(where payment_method='member_wallet'),0)
    into v_lines,v_expected_wallet from public.payment_items where payment_id=p.id and organization_id=v_org and store_id=p_store_id;
  select -coalesce(sum(amount_delta),0) into v_wallet from public.member_wallet_ledger where organization_id=v_org
    and reference_type='payment' and reference_id=p.id and transaction_type='payment' and amount_delta<0;
  if abs(v_lines-p.paid_total)>0.01 or abs(v_wallet-v_expected_wallet)>0.01
    or abs(p.paid_total-p.change_amount-p.grand_total)>0.01 or v_wallet>p.grand_total then
    raise exception '原收据或钱包流水不一致，请先对账；本次没有退款。';
  end if;
  if exists (
    select 1 from (
      select membership_id,sum(amount) amount from public.payment_items where payment_id=p.id
        and organization_id=v_org and store_id=p_store_id and payment_method='member_wallet' group by membership_id
    ) expected full join (
      select membership_id,-sum(amount_delta) amount from public.member_wallet_ledger where organization_id=v_org
        and reference_type='payment' and reference_id=p.id and transaction_type='payment' and amount_delta<0 group by membership_id
    ) actual using(membership_id) where expected.amount is distinct from actual.amount
  ) then raise exception '原钱包扣款与会员不匹配，请先对账；本次没有退款。'; end if;
  if exists (
    select 1 from public.visit_product_items i join public.products product on product.id=i.product_id
      and product.organization_id=i.organization_id and product.store_id=i.store_id
    where i.visit_id=v.id and i.organization_id=v_org and i.store_id=p_store_id and i.status='active'
      and product.stock_enabled and i.item_type<>'bundle'
    group by i.product_id
    having sum(i.quantity) > coalesce((
      select -sum(m.quantity_delta) from public.inventory_stock_movements m
      where m.organization_id=v_org and m.store_id=p_store_id and m.product_id=i.product_id
        and m.reference_type='payment' and m.reference_id=p.id and m.movement_type='sale' and m.quantity_delta<0
    ),0)
  ) then raise exception '原收据有缺失的扣库记录，请先对账；本次没有退款。'; end if;
  v_external:=p.grand_total-v_wallet;
  if v_external>0 and (p_external_confirmed is not true or nullif(btrim(p_external_reference),'') is null) then
    raise exception '请先完成现金或外部支付退款，再确认并填写凭证。';
  end if;
  if p_stock_return_confirmed is not true and exists(
    select 1 from public.inventory_stock_movements where organization_id=v_org and store_id=p_store_id
      and reference_type='payment' and reference_id=p.id and movement_type='sale' and quantity_delta<0
  ) then raise exception '请确认已收到退回商品，再登记回补库存。'; end if;
  -- Wallet/loyalty rows are append-only; serialize with checkout's membership locks.
  for x in select id from public.memberships where organization_id=v_org and id in (
    select membership_id from public.member_wallet_ledger where organization_id=v_org and reference_type='payment' and reference_id=p.id
    union select membership_id from public.member_loyalty_ledger where organization_id=v_org and reference_type='payment' and reference_id=p.id
  ) order by id for update loop null; end loop;
  select coalesce(sum(performance_amount),0) into v_perf from public.service_performance_ledger where payment_id=p.id and organization_id=v_org and store_id=p_store_id;
  select coalesce(sum(l.commission_amount),0) into v_commission from public.employee_commission_ledger l
    where l.organization_id=v_org and l.store_id=p_store_id and (
      (l.source_type='product' and exists(select 1 from public.visit_product_items i where i.id=l.source_id and i.visit_id=v.id))
      or (l.source_type='service' and (l.source_id=p.id or exists(select 1 from public.visit_service_items i where i.id=l.source_id and i.visit_id=v.id)))
    );
  insert into salonos_workflow.receipt_refunds(payment_id,organization_id,store_id,visit_id,receipt_number,total,external_amount,wallet_amount,reason,external_reference,actor_id)
  values(p.id,v_org,p_store_id,v.id,p.receipt_number,p.grand_total,v_external,v_wallet,btrim(p_reason),nullif(left(btrim(p_external_reference),150),''),auth.uid()) returning * into f;
  insert into public.inventory_stock_movements(organization_id,store_id,product_id,quantity_delta,movement_type,unit_cost,reference_type,reference_id,notes,created_by_user_id)
  select v_org,p_store_id,product_id,-quantity_delta,'sale_return',unit_cost,'receipt_refund',f.id,'Receipt '||p.receipt_number,auth.uid()
    from public.inventory_stock_movements where organization_id=v_org and store_id=p_store_id
      and reference_type='payment' and reference_id=p.id and movement_type='sale' and quantity_delta<0;
  get diagnostics v_stock_rows=row_count;
  insert into public.member_wallet_ledger(organization_id,membership_id,amount_delta,transaction_type,reference_type,reference_id,notes,created_by_user_id)
  select v_org,membership_id,-amount_delta,'refund','receipt_refund',f.id,'Receipt '||p.receipt_number,auth.uid()
    from public.member_wallet_ledger where organization_id=v_org and reference_type='payment' and reference_id=p.id and transaction_type='payment' and amount_delta<0;
  get diagnostics v_wallet_rows=row_count;
  insert into public.member_loyalty_ledger(organization_id,membership_id,experience_delta,points_delta,transaction_type,reference_type,reference_id,notes,created_by_user_id)
  select v_org,membership_id,-experience_delta,-points_delta,'refund','receipt_refund',f.id,'Receipt '||p.receipt_number,auth.uid()
    from public.member_loyalty_ledger where organization_id=v_org and reference_type='payment' and reference_id=p.id and transaction_type='purchase';
  get diagnostics v_loyalty_rows=row_count;
  if v_loyalty_rows>0 then
    with affected as (
      select distinct membership_id from public.member_loyalty_ledger where organization_id=v_org
        and reference_type='receipt_refund' and reference_id=f.id
    ), levels as (
      select a.membership_id,(select l.id from public.membership_levels l
        where l.organization_id=v_org and l.active and l.min_experience<=greatest(0,coalesce((
          select sum(b.experience_delta) from public.member_loyalty_ledger b
          where b.organization_id=v_org and b.membership_id=a.membership_id
        ),0)) order by l.min_experience desc,l.level_number desc limit 1) as level_id
      from affected a
    )
    update public.memberships m set current_level_id=l.level_id,updated_at=now() from levels l
      where m.id=l.membership_id and m.organization_id=v_org and l.level_id is not null and m.current_level_id is distinct from l.level_id;
  end if;
  insert into public.employee_commission_ledger(organization_id,store_id,employee_id,source_type,source_id,base_amount,commission_rate,commission_amount,notes)
  select v_org,p_store_id,l.employee_id,'manual_adjustment',l.id,-l.base_amount,l.commission_rate,-l.commission_amount,'Receipt refund '||p.receipt_number
    from public.employee_commission_ledger l where l.organization_id=v_org and l.store_id=p_store_id and (
      (l.source_type='product' and exists(select 1 from public.visit_product_items i where i.id=l.source_id and i.visit_id=v.id))
      or (l.source_type='service' and (l.source_id=p.id or exists(select 1 from public.visit_service_items i where i.id=l.source_id and i.visit_id=v.id)))
    );
  get diagnostics v_commission_rows=row_count;
  update public.payments set status='refunded',updated_at=now() where id=p.id;
  update public.visit_product_items set status='returned',updated_at=now() where visit_id=v.id and status='active' and organization_id=v_org and store_id=p_store_id;
  update salonos_workflow.receipt_refunds set breakdown=jsonb_build_object('stock_rows',v_stock_rows,'wallet_rows',v_wallet_rows,
    'loyalty_rows',v_loyalty_rows,'commission_rows',v_commission_rows,'commission_amount',v_commission,'performance_amount',v_perf)
    where id=f.id returning * into f;
  return to_jsonb(f)||jsonb_build_object('replayed',false);
end;
$$;

create or replace function public.v1361062_receipt_for_visit(p_store_id uuid,p_visit_id uuid)
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare v_org uuid; p public.payments%rowtype; f salonos_workflow.receipt_refunds%rowtype; v_wallet numeric;
begin
  v_org:=salonos_workflow.require_store(p_store_id);
  select * into p from public.payments where visit_id=p_visit_id and organization_id=v_org and store_id=p_store_id order by paid_at desc limit 1;
  if not found then return '{}'::jsonb; end if;
  select coalesce(sum(amount),0) into v_wallet from public.payment_items where payment_id=p.id
    and organization_id=v_org and store_id=p_store_id and payment_method='member_wallet';
  select * into f from salonos_workflow.receipt_refunds where payment_id=p.id;
  return jsonb_build_object('payment_id',p.id,'receipt',p.receipt_number,'status',p.status,'total',p.grand_total,
    'external',greatest(p.grand_total-v_wallet,0),'wallet',v_wallet,'refund',case when f.id is not null then to_jsonb(f) end,
    'services',coalesce((select jsonb_agg(jsonb_build_object('label',i.service_name_snapshot,'quantity',i.quantity,'amount',i.line_total) order by i.created_at,i.id)
      from public.visit_service_items i where i.visit_id=p.visit_id and i.organization_id=v_org and i.store_id=p_store_id and i.status<>'cancelled'),'[]'::jsonb),
    'products',coalesce((select jsonb_agg(jsonb_build_object('label',i.product_name_snapshot,'quantity',i.quantity,'amount',i.line_total,'returned',i.status='returned') order by i.created_at,i.id)
      from public.visit_product_items i where i.visit_id=p.visit_id and i.organization_id=v_org and i.store_id=p_store_id and i.status in ('active','returned')),'[]'::jsonb));
end;
$$;

create table if not exists salonos_workflow.review_events (
  store_id uuid not null references public.stores(id),
  organization_id uuid not null,
  kind text not null check(kind in ('order_review','wa_manual')),
  subject_id uuid not null,
  previous_status text not null,
  note text not null,
  actor_id uuid not null,
  created_at timestamptz not null default now(),
  primary key(store_id,kind,subject_id)
);
create table if not exists salonos_workflow.conversation_pauses (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null,
  conversation_id uuid not null,
  queue_id uuid not null,
  paused_by uuid not null,
  paused_at timestamptz not null default now(),
  resumed_by uuid,
  resumed_at timestamptz
);
create unique index if not exists salonos_one_active_conversation_pause
  on salonos_workflow.conversation_pauses(store_id,conversation_id) where resumed_at is null;

create or replace function salonos_workflow.guard_handed_off_queue()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.status in ('queued','processing') and new.status is distinct from old.status and exists(
    select 1 from salonos_workflow.review_events r where r.store_id=old.store_id and r.kind='wa_manual' and r.subject_id=old.id
  ) then raise exception '该 WhatsApp 任务已由门店人工接手，不能重新自动发送。'; end if;
  return new;
end;
$$;
drop trigger if exists salonos_workflow_handed_off_queue on public.whatsapp_ai_queue;
create trigger salonos_workflow_handed_off_queue before update of status on public.whatsapp_ai_queue
for each row execute function salonos_workflow.guard_handed_off_queue();

create or replace function public.v1361062_operations(p_store_id uuid)
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare v_org uuid;
begin
  v_org:=salonos_workflow.require_store(p_store_id);
  return jsonb_build_object(
    'orders',coalesce((select jsonb_agg(to_jsonb(t)) from (
      select v.id,v.visit_number,v.status,coalesce(v.scheduled_at,v.created_at) as order_at,
        r.created_at as reviewed_at,r.note as review_note
      from public.visits v left join salonos_workflow.review_events r on r.store_id=v.store_id and r.kind='order_review' and r.subject_id=v.id
      where v.organization_id=v_org and v.store_id=p_store_id and v.status in ('draft','booked','arrived','waiting','in_service','paused','ready_for_checkout')
        and coalesce(v.scheduled_at,v.created_at)<now()-interval '7 days' order by r.created_at nulls first,order_at limit 100
    ) t),'[]'::jsonb),
    'messages',coalesce((select jsonb_agg(to_jsonb(t)) from (
      select q.id,q.status,q.created_at,q.updated_at,q.attempts,c.customer_phone,c.ai_enabled,c.id as conversation_id,
        case when coalesce(q.last_error,'')='' then '尚未尝试'
          when q.last_error ~* 'access token|oauth|meta_send|graph' then 'Meta 验证或发送'
          when q.last_error ~* 'groq|openai|provider|model' then 'AI 服务'
          when q.last_error ~* 'timeout|timed out' then '连接超时' else '其他失败' end as error_group,
        r.created_at as reviewed_at,r.note as review_note,
        exists(select 1 from salonos_workflow.conversation_pauses cp where cp.store_id=q.store_id and cp.queue_id=q.id and cp.resumed_at is null) as can_resume
      from public.whatsapp_ai_queue q
      left join public.whatsapp_conversations c on c.id=q.conversation_id and c.organization_id=q.organization_id and c.store_id=q.store_id
      left join salonos_workflow.review_events r on r.store_id=q.store_id and r.kind='wa_manual' and r.subject_id=q.id
      where q.organization_id=v_org and q.store_id=p_store_id and (q.status='failed' or (q.status='queued' and q.available_at<now()-interval '15 minutes') or r.subject_id is not null)
      order by r.created_at nulls first,q.created_at limit 100
    ) t),'[]'::jsonb)
  );
end;
$$;

create or replace function public.v1361062_review_operation(p_store_id uuid,p_kind text,p_subject_id uuid,p_note text,p_pause_ai boolean default false)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_org uuid; v_status text; v_conversation uuid; r salonos_workflow.review_events%rowtype;
begin
  v_org:=salonos_workflow.require_store(p_store_id);
  if length(btrim(coalesce(p_note,''))) not between 3 and 500 then raise exception '请填写处理备注（3–500 字）。'; end if;
  if p_kind='order_review' then
    select status into v_status from public.visits where id=p_subject_id and organization_id=v_org and store_id=p_store_id
      and coalesce(scheduled_at,created_at)<now()-interval '7 days' and status not in ('completed','cancelled','no_show') for update;
    if not found then raise exception '这笔订单已关闭或不在异常列表。'; end if;
  elsif p_kind='wa_manual' then
    select status,conversation_id into v_status,v_conversation from public.whatsapp_ai_queue
      where id=p_subject_id and organization_id=v_org and store_id=p_store_id for update;
    if not found then raise exception '找不到当前门店的 WhatsApp 任务。'; end if;
    if v_status not in ('queued','failed','skipped') or (v_status='queued' and not exists(
      select 1 from public.whatsapp_ai_queue where id=p_subject_id and available_at<now()-interval '15 minutes'
    )) then raise exception '任务正在处理或已完成，不能人工接手。'; end if;
  else raise exception '处理类型无效。'; end if;
  select * into r from salonos_workflow.review_events where store_id=p_store_id and kind=p_kind and subject_id=p_subject_id;
  if found then return jsonb_build_object('ok',true,'replayed',true); end if;
  if p_kind='wa_manual' then
    if v_status='skipped' then raise exception '此任务已跳过。'; end if;
    update public.whatsapp_ai_queue set status='skipped',updated_at=now() where id=p_subject_id;
    if p_pause_ai is true then
      update public.whatsapp_conversations set ai_enabled=false,updated_at=now()
        where id=v_conversation and organization_id=v_org and store_id=p_store_id and ai_enabled is true;
      if found then
        insert into salonos_workflow.conversation_pauses(store_id,conversation_id,queue_id,paused_by)
        values(p_store_id,v_conversation,p_subject_id,auth.uid());
      end if;
    end if;
  end if;
  insert into salonos_workflow.review_events(store_id,organization_id,kind,subject_id,previous_status,note,actor_id)
  values(p_store_id,v_org,p_kind,p_subject_id,v_status,btrim(p_note),auth.uid());
  return jsonb_build_object('ok',true,'replayed',false);
end;
$$;

create or replace function public.v1361062_resume_conversation(p_store_id uuid,p_conversation_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_org uuid;
begin
  v_org:=salonos_workflow.require_store(p_store_id);
  perform 1 from public.whatsapp_conversations where id=p_conversation_id and organization_id=v_org and store_id=p_store_id for update;
  if not found then raise exception '找不到当前门店的 WhatsApp 对话。'; end if;
  update salonos_workflow.conversation_pauses set resumed_at=now(),resumed_by=auth.uid()
    where store_id=p_store_id and conversation_id=p_conversation_id and resumed_at is null;
  if not found then raise exception '这个对话没有可恢复的人工暂停。'; end if;
  update public.whatsapp_conversations set ai_enabled=true,updated_at=now()
    where id=p_conversation_id and organization_id=v_org and store_id=p_store_id;
  return jsonb_build_object('ok',true);
end;
$$;

revoke all on all tables in schema salonos_workflow from public,anon,authenticated;
revoke all on all functions in schema salonos_workflow from public,anon,authenticated;
revoke all on function public.v1361062_find_owner_order(uuid,uuid),public.v1361062_create_owner_order(uuid,uuid,jsonb),
  public.v1361062_owner_visit_status(uuid,uuid,text),public.v1361062_replace_workers(uuid,uuid,jsonb),public.v1361062_refund_receipt(uuid,uuid,text,boolean,text,boolean),
  public.v1361062_receipt_for_visit(uuid,uuid),public.v1361062_operations(uuid),
  public.v1361062_review_operation(uuid,text,uuid,text,boolean),public.v1361062_resume_conversation(uuid,uuid) from public,anon,authenticated;
grant execute on function public.v1361062_find_owner_order(uuid,uuid),public.v1361062_create_owner_order(uuid,uuid,jsonb),
  public.v1361062_owner_visit_status(uuid,uuid,text),public.v1361062_replace_workers(uuid,uuid,jsonb),public.v1361062_refund_receipt(uuid,uuid,text,boolean,text,boolean),
  public.v1361062_receipt_for_visit(uuid,uuid),public.v1361062_operations(uuid),
  public.v1361062_review_operation(uuid,text,uuid,text,boolean),public.v1361062_resume_conversation(uuid,uuid) to authenticated;
revoke all on function public.v13_employee_api(text,text,jsonb),public.v1344_employee_set_visit_status(text,uuid,text) from public,anon,authenticated;
grant execute on function public.v13_employee_api(text,text,jsonb),public.v1344_employee_set_visit_status(text,uuid,text) to anon,authenticated;
notify pgrst, 'reload schema';
commit;
