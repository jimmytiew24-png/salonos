<?php
declare(strict_types=1);

/** SalonOS v13.1 unified Supabase business modules. */

function v13_org_uuid(): string { return trim((string)(salonos_supabase_identity()['organization_id'] ?? '')); }
function v13_store_uuid(): string { return trim((string)(current_store()['id'] ?? '')); }
function v13_owner_token_required_all(): string {
    if(!v13_is_owner()) throw new RuntimeException('这个操作需要老板账号。');
    $t=v13_business_token(); if($t==='') throw new RuntimeException('Supabase 登录已过期，请重新登录。'); return $t;
}
function v13_owner_rows(string $table,string $query): array { return salonos_supabase_rest_rows($table,$query,v13_owner_token_required_all()); }
function v13_owner_write(string $table,string $query,string $method,array $body,string $prefer='return=representation'): array {
    return salonos_supabase_rest_write($table,$query,$method,$body,$prefer);
}
function v13_rpc_json(string $name,array $args,string $token): array {
    $r=v13_rpc($name,$args,$token); return is_array($r)?$r:[];
}
function v13_employee_api(string $action,array $payload=[]): array {
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($session==='') throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    if($action==='training'){
        try{return v13_rpc_json('v1350_employee_training',['p_session_token'=>$session],'');}
        catch(Throwable $e){if(!v136_rpc_signature_mismatch($e,'v1350_employee_training'))throw $e;}
    }
    if($action==='training_progress'){
        try{return v13_rpc_json('v1350_employee_training_progress',['p_session_token'=>$session,'p_course_id'=>(string)($payload['course_id']??''),'p_progress_percent'=>(int)($payload['progress_percent']??0)],'');}
        catch(Throwable $e){if(!v136_rpc_signature_mismatch($e,'v1350_employee_training_progress'))throw $e;}
    }
    if($action==='catalog'){
        try{return v13_rpc_json('v1350_employee_catalog',['p_session_token'=>$session],'');}
        catch(Throwable $e){if(!v136_rpc_signature_mismatch($e,'v1350_employee_catalog'))throw $e;}
    }
    return v13_rpc_json('v13_employee_api',['p_session_token'=>$session,'p_action'=>$action,'p_payload'=>$payload],'');
}

function v1355_employee_product_inventory_payload(): array {
    static $cache=null;
    if(v13_is_owner()) return [];
    if(is_array($cache)) return $cache;
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($session==='') throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    $cache=v13_rpc_json('v1355_employee_product_inventory',['p_session_token'=>$session],'');
    return is_array($cache)?$cache:[];
}
function v1355_bundle_rows(bool $activeOnly=true): array {
    if(v13_is_owner()){
        $q='select=id,organization_id,store_id,name,sku,category_id,category,sale_price,image_path,active,created_at,updated_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid());
        if($activeOnly)$q.='&active=eq.true';
        return v13_owner_rows('v13_product_bundles',$q.'&order=created_at.desc&limit=1000');
    }
    $rows=v1355_employee_product_inventory_payload()['bundles']??[];
    if(!is_array($rows))return [];
    if($activeOnly)$rows=array_values(array_filter($rows,static fn($r)=>!empty($r['active'])));
    return $rows;
}
function v1355_bundle_items(): array {
    if(v13_is_owner()) return v13_owner_rows('v13_product_bundle_items','select=id,bundle_id,product_id,quantity&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&limit=5000');
    $rows=v1355_employee_product_inventory_payload()['bundle_items']??[];
    return is_array($rows)?$rows:[];
}

function v13_uuid(): string { return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',random_int(0,65535),random_int(0,65535),random_int(0,65535),random_int(0,4095)|0x4000,random_int(0,16383)|0x8000,random_int(0,65535),random_int(0,65535),random_int(0,65535)); }
function v13_visit_no(): string { return 'V'.date('ymdHis').'-'.strtoupper(bin2hex(random_bytes(2))); }
function v13_status_label(string $s): string { return match($s){'draft'=>'草稿','booked'=>'预约','arrived'=>'已到店','waiting'=>'等候','in_service'=>'服务中','paused'=>'暂停','ready_for_checkout'=>'待结账','completed'=>'已完成','cancelled'=>'已取消','no_show'=>'未到',default=>$s}; }
function v13_visit_type_label(string $s): string { return $s==='appointment'?'预约':'Walk-in'; }
function v13_json_post(string $key): array { $v=json_decode((string)($_POST[$key]??''),true); return is_array($v)?$v:[]; }

function v1350_service_categories(bool $activeOnly=false): array {
    if(!v13_is_owner()) return [];
    $q='select=id,name,description,sort_order,active&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid());
    if($activeOnly)$q.='&active=eq.true';
    return v13_owner_rows('service_categories',$q.'&order=sort_order.asc,name.asc&limit=500');
}
function v1350_storage_public_url(string $bucket,string $path): string {
    $parts=array_map('rawurlencode',array_filter(explode('/',trim($path,'/')),fn($x)=>$x!==''));
    return rtrim(SALONOS_SUPABASE_URL,'/').'/storage/v1/object/public/'.rawurlencode($bucket).'/'.implode('/',$parts);
}
function v1350_storage_put(string $bucket,string $path,string $bytes,string $mime): void {
    $token=v13_owner_token_required_all();
    $url=rtrim(SALONOS_SUPABASE_URL,'/').'/storage/v1/object/'.rawurlencode($bucket).'/'.implode('/',array_map('rawurlencode',explode('/',trim($path,'/'))));
    $headers=['apikey: '.SALONOS_SUPABASE_PUBLISHABLE_KEY,'Authorization: Bearer '.$token,'Content-Type: '.$mime,'x-upsert: true'];
    $status=0;$raw=false;$err='';
    if(function_exists('curl_init')){
        $ch=curl_init($url);
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>25,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$bytes,CURLOPT_HTTPHEADER=>$headers,CURLOPT_IPRESOLVE=>CURL_IPRESOLVE_V4]);
        $raw=curl_exec($ch); if($raw===false)$err=(string)curl_error($ch); $status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); curl_close($ch);
    } else {
        $ctx=stream_context_create(['http'=>['method'=>'POST','header'=>implode("\r\n",$headers),'content'=>$bytes,'ignore_errors'=>true,'timeout'=>25]]);
        $raw=@file_get_contents($url,false,$ctx);
        if(!empty($http_response_header)&&preg_match('/\s(\d{3})\s/',(string)$http_response_header[0],$m))$status=(int)$m[1];
        if($raw===false)$err='Storage upload failed';
    }
    if($raw===false || $status<200 || $status>=300){
        $detail=is_string($raw)?$raw:$err;
        throw new RuntimeException('照片上传到 Supabase Storage 失败。'.($detail!==''?' 请稍后重试。':''));
    }
}
function v1350_upload_image(string $field,string $folder,?string $existing=null): ?string {
    $file=$_FILES[$field]??null;
    if(!is_array($file) || (int)($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) return $existing;
    if((int)($file['error']??0)!==UPLOAD_ERR_OK) throw new RuntimeException('照片上传失败，请重新选择图片。');
    $size=(int)($file['size']??0); if($size<=0 || $size>8*1024*1024) throw new RuntimeException('图片必须小于 8MB。系统会压缩后再放到 Supabase Storage。');
    $tmp=(string)($file['tmp_name']??''); $info=@getimagesize($tmp); $mime=(string)($info['mime']??'');
    if(!in_array($mime,['image/jpeg','image/png','image/webp'],true)) throw new RuntimeException('只支持 JPG / PNG / WebP 图片。');
    $bytes=''; $outMime=$mime; $ext=match($mime){'image/jpeg'=>'jpg','image/png'=>'png',default=>'webp'};
    if(function_exists('imagecreatefromstring') && function_exists('imagewebp')){
        $src=@imagecreatefromstring((string)file_get_contents($tmp));
        if($src){
            $w=imagesx($src);$h=imagesy($src);$max=1400;$scale=min(1,$max/max($w,$h));$nw=max(1,(int)round($w*$scale));$nh=max(1,(int)round($h*$scale));
            $dst=imagecreatetruecolor($nw,$nh);
            imagealphablending($dst,false);imagesavealpha($dst,true);$transparent=imagecolorallocatealpha($dst,0,0,0,127);imagefilledrectangle($dst,0,0,$nw,$nh,$transparent);
            imagecopyresampled($dst,$src,0,0,0,0,$nw,$nh,$w,$h);
            ob_start(); imagewebp($dst,null,78); $bytes=(string)ob_get_clean(); imagedestroy($dst); imagedestroy($src);
            $outMime='image/webp';$ext='webp';
        }
    }
    if($bytes===''){
        if($size>2*1024*1024) throw new RuntimeException('服务器无法压缩这张图片，请先把图片压到 2MB 以下再上传。');
        $bytes=(string)file_get_contents($tmp);
    }
    $safeFolder=preg_replace('/[^A-Za-z0-9_-]/','-',trim($folder))?:'media';
    $path=v13_org_uuid().'/'.$safeFolder.'/'.date('YmdHis').'-'.bin2hex(random_bytes(5)).'.'.$ext;
    v1350_storage_put('salonos-media',$path,$bytes,$outMime);
    return v1350_storage_public_url('salonos-media',$path);
}
function v1350_save_service_category(): void {
    v13_owner_token_required_all();$id=trim((string)($_POST['category_id']??''));$name=trim((string)($_POST['name']??''));if($name==='')throw new RuntimeException('分类名称必填。');
    $body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'name'=>$name,'description'=>trim((string)($_POST['description']??''))?:null,'sort_order'=>(int)($_POST['sort_order']??0),'active'=>!empty($_POST['active']),'updated_at'=>date(DATE_ATOM)];
    if($id==='')v13_owner_write('service_categories','','POST',$body);else v13_owner_write('service_categories','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',$body);
}
function v1350_archive_service_category(): void {
    v13_owner_token_required_all();$id=trim((string)($_POST['category_id']??''));if($id==='')return;
    v13_owner_write('service_categories','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',['active'=>false,'updated_at'=>date(DATE_ATOM)]);
}
function v1350_save_inventory_item(): void {
    v13_owner_token_required_all();$id=trim((string)($_POST['product_id']??''));$name=trim((string)($_POST['name']??''));if($name==='')throw new RuntimeException('库存名称必填。');
    $existing=trim((string)($_POST['existing_image_path']??''))?:null;
    $image=v1350_upload_image('image_file','inventory',$existing);
    $sku=trim((string)($_POST['sku']??''));if($sku==='')$sku='INV-'.strtoupper(bin2hex(random_bytes(3)));
    $categoryId=trim((string)($_POST['category_id']??'')); $category=trim((string)($_POST['category']??''));
    if($categoryId!==''){
        $cats=v13_owner_rows('v13_product_categories','select=id,name&id=eq.'.rawurlencode($categoryId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&active=eq.true&limit=1');
        if(!$cats) throw new RuntimeException('选择的产品分类不存在或已停用。');
        $category=(string)$cats[0]['name'];
    }
    if($category==='') throw new RuntimeException('请先选择产品分类。');
    $body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'sku'=>$sku,'barcode'=>trim((string)($_POST['barcode']??''))?:null,'name'=>$name,'category_id'=>$categoryId!==''?$categoryId:null,'category'=>$category,'sale_price'=>max(0,(float)($_POST['sale_price']??0)),'cost_price'=>max(0,(float)($_POST['cost_price']??0)),'image_path'=>$image,'reorder_level'=>max(0,(float)($_POST['reorder_level']??0)),'purpose'=>trim((string)($_POST['purpose']??''))?:null,'stock_unit'=>trim((string)($_POST['stock_unit']??'pcs'))?:'pcs','retail_enabled'=>!empty($_POST['retail_enabled']),'stock_enabled'=>true,'active'=>!empty($_POST['active']),'updated_at'=>date(DATE_ATOM)];
    if($id==='')v13_owner_write('products','','POST',$body);else v13_owner_write('products','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',$body);
}
function v1350_archive_inventory_item(): void {
    v13_owner_token_required_all();$id=trim((string)($_POST['product_id']??''));if($id==='')return;
    v13_owner_write('products','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',['stock_enabled'=>false,'active'=>false,'updated_at'=>date(DATE_ATOM)]);
}
function v1350_assign_kpi(): void {
    v13_owner_token_required_all();$employee=trim((string)($_POST['employee_id']??''));$rule=trim((string)($_POST['rule_id']??''));if($employee===''||$rule==='')throw new RuntimeException('请选择员工与 KPI。');
    $month=trim((string)($_POST['period_month']??date('Y-m')));if(!preg_match('/^\d{4}-\d{2}$/',$month))$month=date('Y-m');
    $start=$month.'-01';$end=date('Y-m-t',strtotime($start));
    $ruleRows=v13_owner_rows('v13_kpi_rules','select=id,target_value,bonus_amount&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&id=eq.'.rawurlencode($rule).'&limit=1');
    if(!$ruleRows)throw new RuntimeException('KPI Template 不存在或已移除。');
    $targetRaw=trim((string)($_POST['target_value']??''));$bonusRaw=trim((string)($_POST['bonus_amount']??''));
    $target=$targetRaw===''||((float)$targetRaw)<=0?(float)($ruleRows[0]['target_value']??0):max(0,(float)$targetRaw);
    $bonus=$bonusRaw===''||((float)$bonusRaw)<=0?(float)($ruleRows[0]['bonus_amount']??0):max(0,(float)$bonusRaw);
    $body=['organization_id'=>v13_org_uuid(),'employee_id'=>$employee,'rule_id'=>$rule,'effective_from'=>$start,'effective_to'=>$end,'target_value'=>$target,'bonus_amount'=>$bonus,'status'=>'active','active'=>true,'updated_at'=>date(DATE_ATOM)];
    v13_owner_write('v13_kpi_assignments','on_conflict=employee_id,rule_id,effective_from','POST',$body,'resolution=merge-duplicates,return=representation');
}
function v1350_save_commission_tier(): void {
    v13_owner_token_required_all();$id=trim((string)($_POST['tier_id']??''));$min=max(0,(float)($_POST['min_performance']??0));$maxRaw=trim((string)($_POST['max_performance']??''));$max=$maxRaw===''?null:max($min,(float)$maxRaw);$rate=max(0,min(100,(float)($_POST['commission_rate']??0)));$name=trim((string)($_POST['tier_name']??''));if($name==='')$name='Tier '.date('His');
    $body=['organization_id'=>v13_org_uuid(),'tier_name'=>$name,'min_monthly_performance'=>$min,'max_monthly_performance'=>$max,'commission_rate'=>$rate,'active'=>!empty($_POST['active']),'updated_at'=>date(DATE_ATOM)];
    if($id==='')v13_owner_write('service_commission_tiers','','POST',$body);else v13_owner_write('service_commission_tiers','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()),'PATCH',$body);
}
function v1350_archive_commission_tier(): void {
    v13_owner_token_required_all();$id=trim((string)($_POST['tier_id']??''));if($id!=='')v13_owner_write('service_commission_tiers','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()),'PATCH',['active'=>false,'updated_at'=>date(DATE_ATOM)]);
}
function v1350_save_monthly_commission_override(): void {
    v13_owner_token_required_all();$employee=trim((string)($_POST['employee_id']??''));$month=trim((string)($_POST['month']??date('Y-m')));if($employee===''||!preg_match('/^\d{4}-\d{2}$/',$month))throw new RuntimeException('员工或月份无效。');
    $body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'employee_id'=>$employee,'month_start'=>$month.'-01','override_rate'=>trim((string)($_POST['override_rate']??''))===''?null:max(0,min(100,(float)$_POST['override_rate'])),'final_commission_amount'=>trim((string)($_POST['final_commission_amount']??''))===''?null:max(0,(float)$_POST['final_commission_amount']),'notes'=>trim((string)($_POST['notes']??''))?:null,'updated_at'=>date(DATE_ATOM)];
    v13_owner_write('v13_monthly_commission_overrides','on_conflict=organization_id,store_id,employee_id,month_start','POST',$body,'resolution=merge-duplicates,return=representation');
}

function v136_rpc_signature_mismatch(Throwable $e,string $rpc=''): bool {
    $code='';
    if($e instanceof SalonosSupabaseHttpException) $code=strtoupper((string)($e->payload['code']??''));
    $m=strtolower($e->getMessage());
    $isMissing=$code==='PGRST202' || str_contains($m,'pgrst202') || str_contains($m,'could not find the function');
    if(!$isMissing) return false;
    return $rpc==='' || str_contains($m,strtolower($rpc));
}
function v136_rpc_with_variants(string $name,array $variants,string $token): mixed {
    $last=null;
    foreach($variants as $args){
        try { return v13_rpc($name,is_array($args)?$args:[],$token); }
        catch(Throwable $e){
            if(!v136_rpc_signature_mismatch($e,$name)) throw $e;
            $last=$e;
        }
    }
    throw new RuntimeException('Supabase RPC「'.$name.'」版本尚未同步。请运行 RUN_ONCE_V13_5_3_CUMULATIVE_RUNTIME.sql 后刷新。',0,$last);
}
function v135_runtime_contract_info(): array {
    static $cache=null; if(is_array($cache))return $cache;
    $cache=['version'=>'','ok'=>false,'available'=>false];
    if(!v13_is_owner())return $cache;
    $token=v13_owner_token_required_all();

    // Current build first checks the newest additive contract. This prevents an older
    // v13.5.0 probe from reporting PASS while v13.5.3 product/customer RPCs are missing.
    foreach(['v1355_runtime_contract_status','v1354_runtime_contract_status','v1353_runtime_contract_status','v1350_runtime_contract_status'] as $rpc){
        try{
            $probe=v13_rpc($rpc,[],$token);
            if(is_array($probe) && array_is_list($probe)) $probe=is_array($probe[0]??null)?$probe[0]:[];
            if(!is_array($probe)) continue;
            $fallbackVersion=match($rpc){'v1355_runtime_contract_status'=>'13.5.5','v1354_runtime_contract_status'=>'13.5.4','v1353_runtime_contract_status'=>'13.5.3',default=>'13.5.0'};
            $v=(string)($probe['version']??$fallbackVersion);
            $isCurrent=$rpc==='v1355_runtime_contract_status';
            $cache=['version'=>$v,'ok'=>$isCurrent && !empty($probe['ok']),'available'=>true,'contract'=>$probe,'needs_patch'=>!$isCurrent||empty($probe['ok'])];
            return $cache;
        }catch(Throwable $ignore){
            // Try the older probe so pages can still render a useful compatibility notice.
        }
    }
    try{
        $rows=v13_owner_rows('salonos_system_meta','select=meta_key,meta_value&meta_key=in.(runtime_contract_version,product_ux_version,customer_search_version,member_retail_version,service_board_version,compat_patch_version)&limit=20');
        $map=[];foreach($rows as $r)$map[(string)($r['meta_key']??'')]=(string)($r['meta_value']??'');
        $v=$map['runtime_contract_version']??$map['product_ux_version']??$map['service_board_version']??$map['compat_patch_version']??'';
        $cache=['version'=>$v,'ok'=>false,'available'=>true,'meta'=>$map,'needs_patch'=>true];
    }catch(Throwable $e){$cache=['version'=>'','ok'=>false,'available'=>false,'needs_patch'=>true];}
    return $cache;
}

function v13_service_rows(bool $activeOnly=false, bool $archivedOnly=false): array {
    $q='select=id,organization_id,store_id,category_id,category,name,default_price,estimated_minutes,allows_assistant,active,created_at,updated_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid());
    if($activeOnly)$q.='&active=eq.true';
    elseif($archivedOnly)$q.='&active=eq.false';
    return v13_owner_rows('services',$q.'&order=category.asc,name.asc&limit=1000');
}
function v13_product_rows(bool $activeOnly=false): array {
    if(!v13_is_owner()){
        $rows=v1355_employee_product_inventory_payload()['products']??[];
        if(!is_array($rows))return [];
        if($activeOnly)$rows=array_values(array_filter($rows,static fn($r)=>!empty($r['active'])));
        return $rows;
    }
    $base='&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid());
    $active=$activeOnly?'&active=eq.true':'';
    try {
        return v13_owner_rows('products','select=id,organization_id,store_id,sku,barcode,name,category_id,category,sale_price,cost_price,default_commission_rate,image_path,active,reorder_level,purpose,retail_enabled,stock_enabled,stock_unit'.$base.$active.'&order=category.asc,name.asc&limit=2000');
    } catch(Throwable $e) {
        if(!v135_rpc_missing($e,'category_id') && !str_contains(strtolower($e->getMessage()),'category_id')) throw $e;
        $rows=v13_owner_rows('products','select=id,organization_id,store_id,sku,barcode,name,category,sale_price,cost_price,default_commission_rate,image_path,active,reorder_level,purpose,retail_enabled,stock_enabled,stock_unit'.$base.$active.'&order=category.asc,name.asc&limit=2000');
        foreach($rows as &$row)$row['category_id']=null; unset($row);
        return $rows;
    }
}
function v1353_product_categories(bool $activeOnly=true): array {
    if(!v13_is_owner()){
        $rows=v1355_employee_product_inventory_payload()['categories']??[];
        if(!is_array($rows))return [];
        if($activeOnly)$rows=array_values(array_filter($rows,static fn($r)=>!array_key_exists('active',$r)||!empty($r['active'])));
        return $rows;
    }
    try {
        $q='select=id,organization_id,store_id,name,description,sort_order,active,created_at,updated_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid());
        if($activeOnly)$q.='&active=eq.true';
        return v13_owner_rows('v13_product_categories',$q.'&order=sort_order.asc,name.asc&limit=500');
    } catch(Throwable $e) { return []; }
}
function v1353_save_product_category(): void {
    v13_owner_token_required_all();
    $id=trim((string)($_POST['category_id']??''));
    $name=trim((string)($_POST['name']??''));
    if($name==='') throw new RuntimeException('产品分类名称必填。');
    $body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'name'=>$name,'description'=>trim((string)($_POST['description']??''))?:null,'sort_order'=>(int)($_POST['sort_order']??0),'active'=>!empty($_POST['active']),'updated_at'=>date(DATE_ATOM)];
    if($id==='') v13_owner_write('v13_product_categories','','POST',$body);
    else v13_owner_write('v13_product_categories','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',$body);
}
function v1353_archive_product_category(): void {
    v13_owner_token_required_all();
    $id=trim((string)($_POST['category_id']??'')); if($id==='') return;
    v13_owner_write('v13_product_categories','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',['active'=>false,'updated_at'=>date(DATE_ATOM)]);
}
function v1353_bundle_rows(bool $activeOnly=true): array {
    if(!v13_is_owner()) return v1355_bundle_rows($activeOnly);
    $q='&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid());
    if($activeOnly)$q.='&active=eq.true';
    try { return v13_owner_rows('v13_product_bundles','select=id,name,sku,category_id,category,sale_price,image_path,active,created_at,updated_at'.$q.'&order=category.asc,name.asc&limit=1000'); }
    catch(Throwable $e){ return v13_owner_rows('v13_product_bundles','select=id,name,sku,sale_price,image_path,active,created_at'.$q.'&order=name.asc&limit=1000'); }
}
function v13510_product_image_url(?string $value): string {
    $value=trim((string)$value);
    if($value==='') return '';
    if(preg_match('~^https?://~i',$value)) return $value;
    if(str_starts_with($value,'/storage/v1/object/public/')) return rtrim(SALONOS_SUPABASE_URL,'/').$value;
    return v1350_storage_public_url('salonos-media',$value);
}
function v13510_category_name_from_id(string $categoryId): string {
    $categoryId=trim($categoryId);
    if($categoryId==='') return '';
    try {
        foreach(v1353_product_categories(true) as $cat){
            if((string)($cat['id']??'')===$categoryId) return trim((string)($cat['name']??''));
        }
    } catch(Throwable $e) {}
    return '';
}

function v1353_sellable_product_catalog(string $query='',string $categoryId='',string $categoryName=''): array {
    $query=trim($query); $categoryId=trim($categoryId); $categoryName=trim($categoryName);
    if($categoryName==='' && $categoryId!=='') $categoryName=v13510_category_name_from_id($categoryId);
    $products=array_values(array_filter(v13_product_rows(true),static fn($p)=>!empty($p['retail_enabled'])));
    $stock=v13_inventory_map();
    $needle=mb_strtolower($query,'UTF-8');
    $categoryNeedle=mb_strtolower($categoryName,'UTF-8');
    $rows=[];
    foreach($products as $p){
        $productCategoryId=trim((string)($p['category_id']??''));
        $productCategoryName=trim((string)($p['category']??''));
        if($categoryId!==''){
            $idMatch=$productCategoryId!=='' && $productCategoryId===$categoryId;
            $legacyNameMatch=$categoryNeedle!=='' && mb_strtolower($productCategoryName,'UTF-8')===$categoryNeedle;
            if(!$idMatch && !$legacyNameMatch) continue;
        }
        $hay=mb_strtolower(implode(' ',[(string)($p['name']??''),(string)($p['sku']??''),(string)($p['barcode']??''),$productCategoryName,(string)($p['purpose']??'')]),'UTF-8');
        if($needle!=='' && !str_contains($hay,$needle)) continue;
        $available=!empty($p['stock_enabled'])?max(0,(float)($stock[(string)$p['id']]??0)):999999;
        $rows[]=[
          'id'=>(string)$p['id'],'type'=>'single','type_text'=>'销售产品','name'=>(string)$p['name'],
          'code'=>(string)($p['sku']??$p['barcode']??''),'sku'=>(string)($p['sku']??''),'barcode'=>(string)($p['barcode']??''),
          'category_id'=>$productCategoryId,'category'=>$productCategoryName!==''?$productCategoryName:($categoryName!==''?$categoryName:'未分类'),'description'=>(string)($p['purpose']??''),
          'price'=>(float)($p['sale_price']??0),'price_text'=>money($p['sale_price']??0),'image_url'=>v13510_product_image_url((string)($p['image_path']??'')),
          'available'=>$available,'stock_text'=>!empty($p['stock_enabled'])?number_format($available,2).' '.(string)($p['stock_unit']??'pcs'):'不追踪库存'
        ];
    }
    usort($rows,static fn($a,$b)=>strcasecmp((string)$a['name'],(string)$b['name']));
    return array_slice($rows,0,50);
}
function v13_inventory_map(): array {
    // v13.2 no longer assumes inventory_balances has a column literally named `quantity`.
    // The bridge RPC discovers the real balance column and falls back to the stock ledger.
    if (function_exists('v132_inventory_map')) return v132_inventory_map();
    return [];
}
function v13_employee_rows_owner(): array {
    $r=v13_rpc('v13_employee_directory',['p_store_id'=>v13_store_uuid()],v13_owner_token_required_all());
    return is_array($r) && array_is_list($r)?$r:(is_array($r)?$r:[]);
}
function v13_customer_rows_owner(string $q=''): array {
    $dataset=salonos_supabase_customer_dataset($q);
    return is_array($dataset['customers']??null)?$dataset['customers']:[];
}
function v1350_find_customer_by_phone_owner(string $phone): ?array {
    $digits=preg_replace('/\D+/','',$phone)?:''; if($digits==='')return null;
    $rows=v13_owner_rows('customers','select=id,name,phone,gender,birth_date,ethnicity,notes,created_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&order=created_at.asc&limit=2000');
    foreach($rows as $row){ if((preg_replace('/\D+/','',(string)($row['phone']??''))?:'')===$digits)return $row; }
    return null;
}

function v13_save_service(): void {
    v13_owner_token_required_all(); $id=trim((string)($_POST['service_id']??''));
    $categoryId=trim((string)($_POST['category_id']??'')); $category=trim((string)($_POST['category']??''));
    if($categoryId!==''){
        $cats=v13_owner_rows('service_categories','select=id,name&id=eq.'.rawurlencode($categoryId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=1');
        if(!empty($cats[0]['name']))$category=(string)$cats[0]['name'];
    }
    $body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'category_id'=>$categoryId!==''?$categoryId:null,'category'=>$category,'name'=>trim((string)($_POST['name']??'')),'default_price'=>max(0,(float)($_POST['price']??0)),'estimated_minutes'=>max(1,(int)($_POST['minutes']??60)),'allows_assistant'=>!empty($_POST['allows_assistant']),'active'=>!empty($_POST['active']),'updated_at'=>date(DATE_ATOM)];
    if($body['category']===''||$body['name']==='')throw new RuntimeException('服务分类和名称必填。');
    if($id!=='')v13_owner_write('services','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()),'PATCH',$body);
    else v13_owner_write('services','','POST',$body);
}
function v13_save_product(): void {
    v13_owner_token_required_all(); $id=trim((string)($_POST['product_id']??''));
    $sku=trim((string)($_POST['sku']??'')); if($sku==='')$sku='PRD-'.strtoupper(bin2hex(random_bytes(3)));
    $existing=trim((string)($_POST['existing_image_path']??$_POST['image_path']??''))?:null;
    $image=v1350_upload_image('image_file','products',$existing);
    $categoryId=trim((string)($_POST['category_id']??'')); $category=trim((string)($_POST['category']??''));
    if($categoryId!==''){
        $cats=v13_owner_rows('v13_product_categories','select=id,name&id=eq.'.rawurlencode($categoryId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&active=eq.true&limit=1');
        if(!$cats) throw new RuntimeException('选择的产品分类不存在或已停用。');
        $category=(string)$cats[0]['name'];
    }
    $body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'sku'=>$sku,'barcode'=>trim((string)($_POST['barcode']??''))?:null,'name'=>trim((string)($_POST['name']??'')),'category_id'=>$categoryId!==''?$categoryId:null,'category'=>$category!==''?$category:null,'sale_price'=>max(0,(float)($_POST['sale_price']??0)),'cost_price'=>max(0,(float)($_POST['cost_price']??0)),'default_commission_rate'=>max(0,min(100,(float)($_POST['commission_rate']??0))),'image_path'=>$image,'reorder_level'=>max(0,(float)($_POST['reorder_level']??0)),'purpose'=>trim((string)($_POST['purpose']??''))?:null,'stock_unit'=>trim((string)($_POST['stock_unit']??'pcs'))?:'pcs','retail_enabled'=>true,'stock_enabled'=>true,'active'=>!empty($_POST['active']),'updated_at'=>date(DATE_ATOM)];
    if($body['name']==='')throw new RuntimeException('产品名称必填。');
    if($category==='')throw new RuntimeException('请先选择产品分类。');
    if($id!=='')v13_owner_write('products','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()),'PATCH',$body);
    else v13_owner_write('products','','POST',$body);
}

function v1352_delete_service(): string {
    v13_owner_token_required_all();
    $id=trim((string)($_POST['service_id']??''));
    if($id==='') throw new RuntimeException('缺少服务 ID。');
    $refs=v13_owner_rows('visit_service_items','select=id&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&service_id=eq.'.rawurlencode($id).'&limit=1');
    if($refs){
        v13_owner_write('services','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',['active'=>false,'updated_at'=>date(DATE_ATOM)],'return=minimal');
        return '这个服务已有历史订单引用，所以已安全归档，不再出现在新订单中。';
    }
    v13_owner_write('services','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'DELETE',[],'return=minimal');
    return '服务项目已删除。';
}
function v1352_delete_product(): string {
    v13_owner_token_required_all();
    $id=trim((string)($_POST['product_id']??''));
    if($id==='') throw new RuntimeException('缺少产品 ID。');
    $hasHistory=false;
    foreach([
        ['inventory_stock_movements','product_id'],
        ['visit_product_items','product_id'],
        ['v13_product_bundle_items','product_id']
    ] as [$table,$col]){
        try{
            $rows=v13_owner_rows($table,'select=id&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&'.$col.'=eq.'.rawurlencode($id).'&limit=1');
            if($rows){$hasHistory=true;break;}
        }catch(Throwable $e){}
    }
    if($hasHistory){
        v13_owner_write('products','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',['active'=>false,'retail_enabled'=>false,'updated_at'=>date(DATE_ATOM)],'return=minimal');
        return '这个产品已有库存 / 销售历史，因此已安全归档，不再显示为可销售产品。';
    }
    v13_owner_write('products','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'DELETE',[],'return=minimal');
    return '产品已删除。';
}
function v1352_delete_bundle(): string {
    v13_owner_token_required_all();
    $id=trim((string)($_POST['bundle_id']??''));
    if($id==='') throw new RuntimeException('缺少配套 ID。');
    try{v13_owner_write('v13_product_bundle_items','bundle_id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()),'DELETE',[],'return=minimal');}catch(Throwable $e){}
    v13_owner_write('v13_product_bundles','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'DELETE',[],'return=minimal');
    return '产品配套已删除。';
}

function v13_adjust_stock(): void {
    $token=v13_owner_token_required_all(); $pid=trim((string)($_POST['product_id']??'')); $qty=(float)($_POST['quantity_delta']??0); if($pid===''||abs($qty)<0.00001)throw new RuntimeException('请选择产品并填写调整数量。');
    $unit=max(0,(float)($_POST['unit_cost']??0)); $notes=trim((string)($_POST['notes']??''));
    try{
        v13_rpc('v1346_add_product_stock',['p_product_id'=>$pid,'p_quantity_delta'=>$qty,'p_unit_cost'=>$unit,'p_notes'=>$notes],$token);
    }catch(Throwable $e){
        if(!v136_rpc_signature_mismatch($e,'v1346_add_product_stock')) throw $e;
        v136_rpc_with_variants('add_product_stock',[
            ['product_id'=>$pid,'quantity_delta'=>$qty,'unit_cost'=>$unit,'notes'=>$notes],
            ['p_product_id'=>$pid,'p_quantity_delta'=>$qty,'p_unit_cost'=>$unit,'p_notes'=>$notes],
        ],$token);
    }
}
function v13_save_bundle(): void {
    v13_owner_token_required_all(); $id=trim((string)($_POST['bundle_id']??'')); $name=trim((string)($_POST['name']??'')); if($name==='')throw new RuntimeException('配套名称必填。');
    $existing=trim((string)($_POST['existing_image_path']??$_POST['image_path']??''))?:null;
    $image=v1350_upload_image('image_file','bundles',$existing);
    $categoryId=trim((string)($_POST['category_id']??'')); $category=trim((string)($_POST['category']??''));
    if($categoryId!==''){
        $cats=v13_owner_rows('v13_product_categories','select=id,name&id=eq.'.rawurlencode($categoryId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&active=eq.true&limit=1');
        if(!$cats) throw new RuntimeException('选择的产品分类不存在或已停用。');
        $category=(string)$cats[0]['name'];
    }
    if($category==='') throw new RuntimeException('请先选择产品分类。');
    $body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'name'=>$name,'sku'=>trim((string)($_POST['sku']??''))?:null,'category_id'=>$categoryId!==''?$categoryId:null,'category'=>$category,'sale_price'=>max(0,(float)($_POST['sale_price']??0)),'image_path'=>$image,'active'=>!empty($_POST['active']),'updated_at'=>date(DATE_ATOM)];
    if($id===''){ $res=v13_owner_write('v13_product_bundles','','POST',$body); $id=(string)($res[0]['id']??''); } else v13_owner_write('v13_product_bundles','id=eq.'.rawurlencode($id),'PATCH',$body);
    if($id==='')throw new RuntimeException('配套保存失败。');
    v13_owner_write('v13_product_bundle_items','bundle_id=eq.'.rawurlencode($id),'DELETE',[], 'return=minimal');
    $pids=(array)($_POST['bundle_product_id']??[]); $qtys=(array)($_POST['bundle_quantity']??[]);
    foreach($pids as $i=>$pid){
        $pid=trim((string)$pid); if($pid==='')continue; $qty=max(.01,(float)($qtys[$i]??1));
        v13_owner_write('v13_product_bundle_items','','POST',['organization_id'=>v13_org_uuid(),'bundle_id'=>$id,'product_id'=>$pid,'quantity'=>$qty]);
    }
}


function v134_employee_assignable(array $employee,string $visitType='walk_in'): bool {
    if((string)($employee['employment_status']??'active')!=='active') return false;
    if($visitType==='walk_in'){
        if(array_key_exists('is_on_duty',$employee) && !$employee['is_on_duty']) return false;
        $availability=strtolower((string)($employee['availability_status']??'available'));
        if(in_array($availability,['break','off_duty','in_service','busy','disabled','inactive'],true)) return false;
    }
    return true;
}
function v134_default_contribution_plan(int $coCount,int $assistantCount): array {
    if($coCount>0 && $assistantCount>0) return [60.0,25.0,15.0];
    if($coCount>0) return [75.0,25.0,0.0];
    if($assistantCount>0) return [80.0,0.0,20.0];
    return [100.0,0.0,0.0];
}
function v134_contribution_value(mixed $value,float $fallback): float {
    if($value===null || $value==='') return $fallback;
    return max(0.0,min(100.0,(float)$value));
}

// v13.6.10.30: one staff-pool truth for manual SalonOS orders.
// The browser list is advisory; this helper is called again immediately before writes.
function v1361030_staff_pool_runtime(array $serviceIds,string $visitType,string $scheduledRaw='',string $excludeVisitId=''): array {
    $serviceIds=array_values(array_unique(array_filter(array_map(static fn($v)=>trim((string)$v),$serviceIds))));
    $visitType=$visitType==='appointment'?'appointment':'walk_in';
    $tz=new DateTimeZone('Asia/Kuala_Lumpur');
    if($visitType==='appointment'){
        $raw=trim($scheduledRaw);
        if($raw==='') throw new RuntimeException('预约订单必须填写预约日期与时间。');
        $dt=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$raw,$tz);
        if(!$dt){ try{$dt=new DateTimeImmutable($raw,$tz);}catch(Throwable $e){$dt=false;} }
        if(!$dt) throw new RuntimeException('预约日期与时间格式无效。');
    } else {
        $dt=new DateTimeImmutable('now',$tz);
    }
    $startAt=$dt->format(DATE_ATOM);
    $exclude=trim($excludeVisitId)!==''?trim($excludeVisitId):null;
    try{
        if(v13_is_owner()){
            $pool=v13_rpc_json('v1361030_owner_staff_pool',[
                'p_store_id'=>v13_store_uuid(),'p_service_ids'=>$serviceIds,'p_start_at'=>$startAt,
                'p_visit_type'=>$visitType,'p_exclude_visit_id'=>$exclude
            ],v13_owner_token_required_all());
        } else {
            $session=trim((string)($_SESSION['v13_employee_session_token']??''));
            if($session==='') throw new RuntimeException('员工登录已过期，请重新输入手机号。');
            $pool=v13_rpc_json('v1361030_employee_staff_pool',[
                'p_session_token'=>$session,'p_service_ids'=>$serviceIds,'p_start_at'=>$startAt,
                'p_visit_type'=>$visitType,'p_exclude_visit_id'=>$exclude
            ],'');
        }
    }catch(Throwable $e){
        if(v135_rpc_missing($e,'v1361030_owner_staff_pool')||v135_rpc_missing($e,'v1361030_employee_staff_pool')){
            throw new RuntimeException('数据库尚未安装 v13.6.10.30 员工排班校验补丁。请先运行 RUN_ONCE_V13_6_10_30_MANUAL_BOOKING_STAFF_INTEGRITY.sql。');
        }
        throw $e;
    }
    return is_array($pool)?$pool:[];
}
function v1361030_staff_id_map(array $rows): array {
    $out=[]; foreach($rows as $row){ if(!is_array($row))continue; $id=trim((string)($row['id']??'')); if($id!=='')$out[$id]=$row; } return $out;
}
function v1361030_preflight_visit_team(array $items,string $visitType,string $scheduledRaw,string $assignment,string $appointmentPreference,string $appointmentEmployee=''): array {
    $serviceIds=[];
    foreach($items as $item){ if(is_array($item)){ $sid=trim((string)($item['service_id']??'')); if($sid!=='')$serviceIds[]=$sid; } }
    if(!$serviceIds) throw new RuntimeException('请至少选择一个服务项目。');
    $pool=v1361030_staff_pool_runtime($serviceIds,$visitType,$scheduledRaw);
    $byService=is_array($pool['by_service']??null)?$pool['by_service']:[];
    $common=v1361030_staff_id_map(is_array($pool['common']??null)?$pool['common']:[]);
    $assistants=v1361030_staff_id_map(is_array($pool['assistant_pool']??null)?$pool['assistant_pool']:[]);
    if($visitType==='appointment' && $appointmentPreference==='specified'){
        $appointmentEmployee=trim($appointmentEmployee);
        if($appointmentEmployee===''||!isset($common[$appointmentEmployee])){
            throw new RuntimeException('预约指定的理发师无法覆盖这张订单的全部项目，或该时间已被占用／不在排班内。请更换理发师或时间。');
        }
    }
    $systemLeads=[];
    foreach($items as $i=>$item){
        if(!is_array($item))continue;
        $sid=trim((string)($item['service_id']??'')); if($sid==='')continue;
        $eligible=v1361030_staff_id_map(is_array($byService[$sid]??null)?$byService[$sid]:[]);
        $lead=trim((string)($item['lead_employee_id']??''));
        $preselectedWorkerIds=array_values(array_unique(array_filter(array_map(static fn($v)=>trim((string)$v),array_merge(
            (array)($item['co_stylists']??[]),(array)($item['assistants']??[])
        )))));
        if($assignment==='system'){
            if($visitType==='appointment' && $appointmentPreference==='specified' && $appointmentEmployee!==''){
                $lead=$appointmentEmployee;
            } else {
                // Do not randomly choose someone the user already added as co-stylist/assistant.
                // Otherwise a valid order could fail nondeterministically depending on random draw.
                $ids=array_values(array_diff(array_keys($eligible),$preselectedWorkerIds));
                if(!$ids) throw new RuntimeException('项目 '.($i+1).' 目前没有可作为主理发师且不与协作人员重复的合资格员工。请更换时间或调整人员。');
                $lead=$ids[random_int(0,count($ids)-1)];
            }
            $systemLeads[$i]=$lead;
        } elseif($lead==='' || !isset($eligible[$lead])){
            throw new RuntimeException('项目 '.($i+1).' 的主理发师不符合该服务技能要求，或该时间不可用。请重新选择。');
        }
        $seen=[]; if($lead!=='')$seen[$lead]=true;
        foreach((array)($item['co_stylists']??[]) as $raw){
            $id=trim((string)$raw); if($id==='')continue;
            if(isset($seen[$id])) throw new RuntimeException('项目 '.($i+1).' 同一位员工不能重复担任多个角色。');
            if(!isset($eligible[$id])) throw new RuntimeException('项目 '.($i+1).' 的共同理发师不符合服务技能要求，或该时间不可用。');
            $seen[$id]=true;
        }
        foreach((array)($item['assistants']??[]) as $raw){
            $id=trim((string)$raw); if($id==='')continue;
            if(isset($seen[$id])) throw new RuntimeException('项目 '.($i+1).' 同一位员工不能重复担任多个角色。');
            if(!isset($assistants[$id])) throw new RuntimeException('项目 '.($i+1).' 的助理当前不在排班、休息中或与其他订单冲突。');
            $seen[$id]=true;
        }
        $coIds=array_values(array_filter(array_map('strval',(array)($item['co_stylists']??[])),static fn($v)=>trim($v)!==''));
        $assistantIds=array_values(array_filter(array_map('strval',(array)($item['assistants']??[])),static fn($v)=>trim($v)!==''));
        [$defaultLead,$defaultCoPool,$defaultAssistantPool]=v134_default_contribution_plan(count($coIds),count($assistantIds));
        $sum=v134_contribution_value($item['lead_contribution']??null,$defaultLead);
        $coPcts=(array)($item['co_contributions']??[]); $asPcts=(array)($item['assistant_contributions']??[]);
        $coEach=count($coIds)?$defaultCoPool/count($coIds):0.0; $asEach=count($assistantIds)?$defaultAssistantPool/count($assistantIds):0.0;
        foreach($coIds as $idx=>$unused)$sum+=v134_contribution_value($coPcts[$idx]??null,$coEach);
        foreach($assistantIds as $idx=>$unused)$sum+=v134_contribution_value($asPcts[$idx]??null,$asEach);
        if(abs($sum-100.0)>0.05) throw new RuntimeException('项目 '.($i+1).' 的 Contribution % 总和必须是 100%，目前是 '.number_format($sum,2).'% 。');
    }
    return ['pool'=>$pool,'system_leads'=>$systemLeads];
}

function v13_create_visit_owner(): string {
    v13_owner_token_required_all();
    $requestId=trim((string)($_POST['order_request_id']??''));
    if(!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i',$requestId)) throw new RuntimeException('开单页面已过期。请刷新并恢复草稿后重试。');
    $findOrder=static fn()=>v1361062_workflow_rpc('v1361062_find_owner_order',['p_request_id'=>$requestId]);
    $existing=$findOrder();
    if(!empty($existing['visit_id']))return (string)$existing['visit_id'];
    $type=((string)($_POST['visit_type']??'walk_in')==='appointment')?'appointment':'walk_in';
    $assignment=((string)($_POST['assignment_type']??'specified')==='system')?'system':'specified';
    $scheduled=trim((string)($_POST['appointment_at']??$_POST['scheduled_at']??''));
    $scheduledPayload=$scheduled;
    if($type==='appointment'){
        if($scheduled==='') throw new RuntimeException('预约订单必须填写预约日期与时间。');
        $tz=new DateTimeZone('Asia/Kuala_Lumpur');
        $scheduledDt=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$scheduled,$tz);
        if(!$scheduledDt){ try{$scheduledDt=new DateTimeImmutable($scheduled,$tz);}catch(Throwable $e){$scheduledDt=false;} }
        if(!$scheduledDt) throw new RuntimeException('预约日期与时间格式无效。');
        // datetime-local has no offset. Persist the same Malaysia instant that availability
        // preflight validates, instead of letting the InfinityFree/PHP server timezone shift it.
        $scheduledPayload=$scheduledDt->format(DATE_ATOM);
    }

    // Step 1 appointment preference. This is separate from the detailed per-project team in Step 2.
    $appointmentPreference=((string)($_POST['appointment_assignment_type']??'system')==='specified')?'specified':'system';
    $appointmentEmployee=trim((string)($_POST['appointment_employee_id']??''));

    // v13.6.10.30 preflight happens BEFORE creating customer/visit rows. This prevents
    // a bad multi-worker assignment from leaving a half-created order behind.
    $postedItems=(array)($_POST['items']??[]);
    try {
        $teamPreflight=v1361030_preflight_visit_team($postedItems,$type,$scheduledPayload,$assignment,$appointmentPreference,$appointmentEmployee);
    } catch (Throwable $e) {
        // A concurrent retry can reach the preflight just after the first request committed.
        $existing=$findOrder();
        if(!empty($existing['visit_id']))return (string)$existing['visit_id'];
        throw $e;
    }
    $systemLeadPlan=is_array($teamPreflight['system_leads']??null)?$teamPreflight['system_leads']:[];

    $customerId=trim((string)($_POST['customer_id']??''));
    $name=trim((string)($_POST['customer_name']??''));
    $phone=trim((string)($_POST['customer_phone']??''));
    if($customerId===''&&($name===''||$phone===''))throw new RuntimeException('顾客姓名和电话必填。');
    $age=trim((string)($_POST['customer_age']??''));
    $customer=[
        'id'=>$customerId?:null,'name'=>$name,'phone'=>$phone,
        'gender'=>(string)($_POST['customer_gender']??'unspecified'),
        'birth_date'=>trim((string)($_POST['customer_birth_date']??''))?:null,
        'ethnicity'=>trim((string)($_POST['customer_ethnicity']??''))?:null,
        'acquisition_platform'=>trim((string)($_POST['customer_acquisition_platform']??''))?:null,
        'notes'=>$age!==''?'Order intake age: '.max(0,(int)$age):null,
    ];
    $recipients=[];
    foreach((array)($_POST['recipients']??[]) as $rec){
        if(!is_array($rec)) continue;
        $key=trim((string)($rec['key']??'')); $rname=trim((string)($rec['name']??'')); $rel=trim((string)($rec['relationship']??'同行者'));
        if($key===''||$rname==='') continue;
        $rtype=match($rel){'孩子'=>'child','长辈','家人'=>'family','朋友','同行者'=>'friend',default=>'other'};
        $notes=$rel; if(trim((string)($rec['age']??''))!=='')$notes.=' · Age: '.(int)$rec['age'];
        if($key==='self'||isset($recipients[$key]))throw new RuntimeException('同行者资料重复，请重新选择。');
        $recipients[$key]=['key'=>$key,'name'=>$rname,'type'=>$rtype,'notes'=>$notes];
    }

    $services=v13_service_rows(false); $serviceMap=[]; foreach($services as $sv)$serviceMap[(string)$sv['id']]=$sv;
    $employees=v13_employee_rows_owner(); $employeeMap=[]; foreach($employees as $e)$employeeMap[(string)$e['id']]=$e;

    if($type==='appointment' && $appointmentPreference==='specified'){
        if($appointmentEmployee==='' || !isset($employeeMap[$appointmentEmployee]) || !v134_employee_assignable($employeeMap[$appointmentEmployee],'appointment')){
            throw new RuntimeException('预约指定的理发师无效或已停用。');
        }
    } else {
        $appointmentEmployee='';
    }

    $fallbackLead='';
    foreach($employees as $e){
        $pos=(string)($e['position']??'');
        if(v134_employee_assignable($e,$type) && !str_contains($pos,'前台') && !str_contains($pos,'助理')){
            $fallbackLead=(string)$e['id']; break;
        }
    }

    $plan=[]; $firstLeadEmployee='';
    foreach((array)($_POST['items']??[]) as $i=>$item){
        if(!is_array($item))continue;
        $sid=trim((string)($item['service_id']??'')); if($sid===''||empty($serviceMap[$sid]))continue;
        $sv=$serviceMap[$sid]; $recipientKey=trim((string)($item['recipient_key']??'self'))?:'self';
        $price=max(0,(float)($item['price']??$sv['default_price']??0));

        $lead=trim((string)($item['lead_employee_id']??''));
        if($assignment==='system'){
            $lead=trim((string)($systemLeadPlan[$i]??''));
        } elseif($lead===''){
            $lead=($type==='appointment' && $appointmentPreference==='specified' && $appointmentEmployee!=='')?$appointmentEmployee:$fallbackLead;
        }
        if($lead==='' || !isset($employeeMap[$lead]) || !v134_employee_assignable($employeeMap[$lead],$type)){
            throw new RuntimeException('项目 '.($i+1).' 的主理发师目前不可用。');
        }
        if($firstLeadEmployee==='') $firstLeadEmployee=$lead;

        $coIds=(array)($item['co_stylists']??[]);
        $coPcts=(array)($item['co_contributions']??[]);
        $assistantIds=(array)($item['assistants']??[]);
        $assistantPcts=(array)($item['assistant_contributions']??[]);

        $co=[]; $assist=[]; $seen=[$lead=>true];
        foreach($coIds as $idx=>$rawId){
            $id=trim((string)$rawId); if($id==='')continue;
            if(isset($seen[$id])) throw new RuntimeException('项目 '.($i+1).' 同一位员工不能重复担任多个角色。');
            if(!isset($employeeMap[$id]) || !v134_employee_assignable($employeeMap[$id],$type)) throw new RuntimeException('项目 '.($i+1).' 有共同理发师目前不可用。');
            $seen[$id]=true; $co[]=['id'=>$id,'pct'=>$coPcts[$idx]??null];
        }
        foreach($assistantIds as $idx=>$rawId){
            $id=trim((string)$rawId); if($id==='')continue;
            if(isset($seen[$id])) throw new RuntimeException('项目 '.($i+1).' 同一位员工不能重复担任多个角色。');
            if(!isset($employeeMap[$id]) || !v134_employee_assignable($employeeMap[$id],$type)) throw new RuntimeException('项目 '.($i+1).' 有助理目前不可用。');
            $seen[$id]=true; $assist[]=['id'=>$id,'pct'=>$assistantPcts[$idx]??null];
        }

        [$defaultLead,$defaultCoPool,$defaultAssistantPool]=v134_default_contribution_plan(count($co),count($assist));
        $leadPct=v134_contribution_value($item['lead_contribution']??null,$defaultLead);
        $coEach=count($co)>0?$defaultCoPool/count($co):0.0;
        $assistantEach=count($assist)>0?$defaultAssistantPool/count($assist):0.0;

        $workerPlan=[['id'=>$lead,'role'=>'primary','pct'=>$leadPct]];
        foreach($co as $worker)$workerPlan[]=['id'=>$worker['id'],'role'=>'support','pct'=>v134_contribution_value($worker['pct'],$coEach)];
        foreach($assist as $worker)$workerPlan[]=['id'=>$worker['id'],'role'=>'assistant','pct'=>v134_contribution_value($worker['pct'],$assistantEach)];

        $sum=array_sum(array_map(static fn($w)=>(float)$w['pct'],$workerPlan));
        if(abs($sum-100.0)>0.05) throw new RuntimeException('项目 '.($i+1).' 的 Contribution % 总和必须是 100%，目前是 '.number_format($sum,2).'% 。');

        $plan[]=['service_id'=>$sid,'recipient_key'=>$recipientKey,'price'=>round($price,2),'workers'=>$workerPlan];
    }
    if(!$plan)throw new RuntimeException('请至少选择一个服务项目。');
    $preferenceType=($type==='appointment'?$appointmentPreference:$assignment)==='specified'?'specified':'random';
    $result=v1361062_workflow_rpc('v1361062_create_owner_order',['p_request_id'=>$requestId,'p_order'=>[
        'visit_type'=>$type,'scheduled_at'=>$type==='appointment'?$scheduledPayload:null,
        'notes'=>trim((string)($_POST['notes']??''))?:null,'customer'=>$customer,
        'recipients'=>array_values($recipients),'items'=>$plan,'preference_type'=>$preferenceType,
        'preference_employee'=>$preferenceType==='specified'?($type==='appointment'?$appointmentEmployee:$firstLeadEmployee):null,
    ]]);
    if(empty($result['visit_id']))throw new RuntimeException('未收到开单结果。请用同一份草稿重试。');
    return (string)$result['visit_id'];
}

function v13_owner_visit_rows(bool $history=false): array {
    $status = $history ? 'status=in.(completed,cancelled,no_show)' : 'status=not.in.(completed,cancelled,no_show)';
    $limit=$history?100:500;
    return v13_owner_rows('visits','select=id,visit_number,visit_type,status,scheduled_at,arrived_at,started_at,service_completed_at,checked_out_at,notes,created_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&'.$status.'&order=created_at.desc&limit='.$limit);
}
function v134_owner_history_page(int $page,int $pageSize=100): array {
    $page=max(1,$page); $pageSize=max(25,min(200,$pageSize)); $offset=($page-1)*$pageSize;
    $status=trim((string)($_GET['status']??'all'));
    $from=trim((string)($_GET['from']??'')); $to=trim((string)($_GET['to']??''));
    $statusFilter=in_array($status,['completed','cancelled','no_show'],true)?'status=eq.'.rawurlencode($status):'status=in.(completed,cancelled,no_show)';
    $query='select=id,visit_number,visit_type,status,scheduled_at,arrived_at,started_at,service_completed_at,checked_out_at,notes,created_at'
        .'&organization_id=eq.'.rawurlencode(v13_org_uuid())
        .'&store_id=eq.'.rawurlencode(v13_store_uuid())
        .'&'.$statusFilter;
    if($from!=='' && preg_match('/^\d{4}-\d{2}-\d{2}$/',$from)) $query.='&created_at=gte.'.rawurlencode($from.'T00:00:00+08:00');
    if($to!=='' && preg_match('/^\d{4}-\d{2}-\d{2}$/',$to)){
        $next=date('Y-m-d',strtotime($to.' +1 day'));
        $query.='&created_at=lt.'.rawurlencode($next.'T00:00:00+08:00');
    }
    $query.='&order=created_at.desc&limit='.$pageSize.'&offset='.$offset;
    return v13_owner_rows('visits',$query);
}
function v13_owner_visit_detail(string $visitId): array {
    v13_owner_token_required_all(); $org=v13_org_uuid(); $store=v13_store_uuid();
    $vis=v13_owner_rows('visits','select=*&id=eq.'.rawurlencode($visitId).'&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&limit=1');
    if(!$vis)return [];
    // select=* is intentional: optional snapshot/signature columns may arrive in a later
    // schema patch, but the order modal must still open instead of throwing PGRST204.
    $rec=v13_owner_rows('visit_recipients','select=*&visit_id=eq.'.rawurlencode($visitId).'&organization_id=eq.'.rawurlencode($org).'&limit=100');
    $items=v13_owner_rows('visit_service_items','select=*&visit_id=eq.'.rawurlencode($visitId).'&organization_id=eq.'.rawurlencode($org).'&limit=200');

    // v13.6.10.29: workers/signoffs belong to SERVICE ITEMS, not directly to a visit.
    // The old detail query loaded every worker row in the whole store, so the modal summary
    // could show staff from unrelated orders (for example fatchew + weihong on a one-stylist visit).
    // Scope both child tables to this visit's service_item ids and attach the matching workers
    // back onto each item so SERVICE ITEMS and the summary use the exact same assignment truth.
    $itemIds=[];
    foreach($items as $it){
        $itemId=trim((string)($it['id']??''));
        if($itemId!=='')$itemIds[]=$itemId;
    }
    $itemIds=array_values(array_unique($itemIds));
    $workers=[];
    $sign=[];
    if($itemIds){
        $itemFilter=v135_in_filter($itemIds);
        $workers=v13_owner_rows('visit_service_workers','select=*&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&service_item_id=in.'.$itemFilter.'&status=eq.active&limit=1000');
        try{$sign=v13_owner_rows('visit_service_signoffs','select=*&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&service_item_id=in.'.$itemFilter.'&limit=1000');}catch(Throwable $ignore){}
    }
    $workersByItem=[];
    foreach($workers as $w){
        $serviceItemId=trim((string)($w['service_item_id']??''));
        if($serviceItemId!=='')$workersByItem[$serviceItemId][]=$w;
    }
    foreach($items as &$it){
        $itemId=trim((string)($it['id']??''));
        $it['workers']=$workersByItem[$itemId]??[];
    }
    unset($it);

    $products=[]; try{$products=v13_owner_rows('visit_product_items','select=*&visit_id=eq.'.rawurlencode($visitId).'&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&status=eq.active&limit=500');}catch(Throwable $ignore){}
    $payments=[]; try{$payments=v13_owner_rows('payments','select=*&visit_id=eq.'.rawurlencode($visitId).'&organization_id=eq.'.rawurlencode($org).'&limit=5');}catch(Throwable $ignore){}
    $confirmations=[]; try{$confirmations=v13_owner_rows('v13_visit_confirmations','select=*&visit_id=eq.'.rawurlencode($visitId).'&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&order=signed_at.desc&limit=5');}catch(Throwable $ignore){}
    return ['visit'=>$vis[0],'recipients'=>$rec,'items'=>$items,'workers'=>$workers,'signoffs'=>$sign,'product_items'=>$products,'payments'=>$payments,'confirmations'=>$confirmations];
}
function v13_update_visit_status_owner(): void {
    v1361062_workflow_rpc('v1361062_owner_visit_status',[
        'p_visit_id'=>v1361062_required_uuid($_POST['visit_id']??null),'p_status'=>(string)($_POST['status']??''),
    ]);
}
function v13_assign_service_workers_owner(): void {
    v13_owner_token_required_all();
    $item=trim((string)($_POST['service_item_id']??''));
    $primary=trim((string)($_POST['primary_employee_id']??''));
    if($item===''||$primary==='') throw new RuntimeException('请选择主理发师。');
    $org=v13_org_uuid(); $store=v13_store_uuid();

    // Resolve the canonical service/visit first. Reassignment must never validate against
    // another order or erase workers before all new workers pass skill/schedule/conflict checks.
    $itemRows=v13_owner_rows('visit_service_items','select=id,visit_id,service_id,status&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&id=eq.'.rawurlencode($item).'&limit=1');
    $itemRow=$itemRows[0]??null;
    if(!$itemRow || (string)($itemRow['status']??'active')==='cancelled') throw new RuntimeException('项目不存在或已取消。');
    $visitId=trim((string)($itemRow['visit_id']??'')); $serviceId=trim((string)($itemRow['service_id']??''));
    if($visitId===''||$serviceId==='') throw new RuntimeException('项目资料不完整，无法重新分配员工。');
    $visitRows=v13_owner_rows('visits','select=id,visit_type,status,scheduled_at,started_at,arrived_at,created_at&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&id=eq.'.rawurlencode($visitId).'&limit=1');
    $visit=$visitRows[0]??null;
    if(!$visit) throw new RuntimeException('订单不存在。');
    $visitStatus=(string)($visit['status']??'');
    if(in_array($visitStatus,['cancelled','no_show','completed','checked_out'],true)) throw new RuntimeException('已取消、爽约或已完成的订单不能重新分配员工。');
    $visitType=((string)($visit['visit_type']??'walk_in')==='appointment')?'appointment':'walk_in';
    $scheduledRaw=$visitType==='appointment'?(string)($visit['scheduled_at']??''):'';
    $pool=v1361030_staff_pool_runtime([$serviceId],$visitType,$scheduledRaw,$visitId);
    $byService=is_array($pool['by_service']??null)?$pool['by_service']:[];
    $eligible=v1361030_staff_id_map(is_array($byService[$serviceId]??null)?$byService[$serviceId]:[]);
    $assistantPool=v1361030_staff_id_map(is_array($pool['assistant_pool']??null)?$pool['assistant_pool']:[]);
    if(!isset($eligible[$primary])) throw new RuntimeException('主理发师不符合这个项目的技能要求，或当前时间不可用。');

    $coIds=array_values(array_unique(array_filter(array_map(static fn($v)=>trim((string)$v),(array)($_POST['co_stylists']??$_POST['co_employee_ids']??[])))));
    $assistantIds=array_values(array_unique(array_filter(array_map(static fn($v)=>trim((string)$v),(array)($_POST['assistants']??$_POST['assistant_employee_ids']??[])))));
    $legacyAssistant=trim((string)($_POST['assistant_employee_id']??''));
    if($legacyAssistant!=='' && !$assistantIds)$assistantIds=[$legacyAssistant];
    $seen=[$primary=>true];
    foreach($coIds as $id){
        if(isset($seen[$id])) throw new RuntimeException('同一位员工不能在同一项目重复担任多个角色。');
        if(!isset($eligible[$id])) throw new RuntimeException('共同理发师不符合这个项目的技能要求，或当前时间不可用。');
        $seen[$id]=true;
    }
    foreach($assistantIds as $id){
        if(isset($seen[$id])) throw new RuntimeException('同一位员工不能在同一项目重复担任多个角色。');
        if(!isset($assistantPool[$id])) throw new RuntimeException('助理当前不在排班、休息中或与其他订单冲突。');
        $seen[$id]=true;
    }

    [$defaultLead,$defaultCoPool,$defaultAssistantPool]=v134_default_contribution_plan(count($coIds),count($assistantIds));
    $leadPct=v134_contribution_value($_POST['lead_contribution']??null,$defaultLead);
    $coPcts=(array)($_POST['co_contributions']??[]); $assistantPcts=(array)($_POST['assistant_contributions']??[]);
    $coEach=count($coIds)?$defaultCoPool/count($coIds):0.0; $assistantEach=count($assistantIds)?$defaultAssistantPool/count($assistantIds):0.0;
    $plan=[['id'=>$primary,'role'=>'primary','pct'=>$leadPct]]; $sum=$leadPct;
    foreach($coIds as $i=>$id){$pct=v134_contribution_value($coPcts[$i]??null,$coEach);$sum+=$pct;$plan[]=['id'=>$id,'role'=>'support','pct'=>$pct];}
    foreach($assistantIds as $i=>$id){$pct=v134_contribution_value($assistantPcts[$i]??null,$assistantEach);$sum+=$pct;$plan[]=['id'=>$id,'role'=>'assistant','pct'=>$pct];}
    if(abs($sum-100.0)>0.05) throw new RuntimeException('Contribution % 总和必须是 100%，目前是 '.number_format($sum,2).'% 。');

    v1361062_workflow_rpc('v1361062_replace_workers',['p_service_item_id'=>$item,'p_workers'=>$plan]);
}
function v13_add_visit_product_owner(): void {
    v13_owner_token_required_all();$visit=trim((string)($_POST['visit_id']??''));$pid=trim((string)($_POST['product_id']??''));$qty=max(.01,(float)($_POST['quantity']??1));$sales=trim((string)($_POST['salesperson_employee_id']??''));
    if($visit===''||$pid==='')throw new RuntimeException('订单和产品必填。');
    $rows=v13_owner_rows('products','select=id,name,sku,sale_price,cost_price,default_commission_rate,active&id=eq.'.rawurlencode($pid).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=1');
    $pr=$rows[0]??null;if(!$pr||empty($pr['active']))throw new RuntimeException('产品不存在或已停用。');
    if($sales!==''){
        $staffRows=v13_owner_rows('employees','select=id,name,employment_status,account_status&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&id=eq.'.rawurlencode($sales).'&limit=1');
        $seller=$staffRows[0]??null;
        if(!$seller || (string)($seller['employment_status']??'active')!=='active' || (isset($seller['account_status']) && (string)$seller['account_status']!=='active')) throw new RuntimeException('选择的产品销售员工不属于当前分行或已经停用。');
    }
    v13_owner_write('visit_product_items','','POST',['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'visit_id'=>$visit,'product_id'=>$pid,'product_name_snapshot'=>(string)$pr['name'],'sku_snapshot'=>(string)($pr['sku']??''),'unit_price'=>(float)($pr['sale_price']??0),'cost_price_snapshot'=>(float)($pr['cost_price']??0),'quantity'=>$qty,'salesperson_employee_id'=>$sales!==''?$sales:null,'commission_rate_snapshot'=>(float)($pr['default_commission_rate']??0),'status'=>'active']);
}

function v13_remove_visit_product_owner(): void {
    v13_owner_token_required_all();
    $itemId=trim((string)($_POST['product_item_id']??''));
    $visitId=trim((string)($_POST['visit_id']??''));
    if($itemId===''||$visitId==='') throw new RuntimeException('订单产品资料不完整。');
    $org=v13_org_uuid(); $store=v13_store_uuid();

    // Only an active, pre-checkout order add-on can be removed. We keep the row as
    // cancelled instead of destroying history, and active-only totals immediately recalculate.
    $vis=v13_owner_rows('visits','select=id,status&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&id=eq.'.rawurlencode($visitId).'&limit=1');
    $visit=$vis[0]??null;
    if(!$visit) throw new RuntimeException('订单不存在。');
    if(in_array((string)($visit['status']??''),['completed','checked_out','cancelled','no_show'],true)) throw new RuntimeException('已完成或已关闭的订单不能移除产品。');

    $rows=v13_owner_rows('visit_product_items','select=id,visit_id,status,product_name_snapshot&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&visit_id=eq.'.rawurlencode($visitId).'&id=eq.'.rawurlencode($itemId).'&limit=1');
    $row=$rows[0]??null;
    if(!$row || (string)($row['status']??'')!=='active') throw new RuntimeException('这个订单产品已经被移除或不存在。');

    v13_owner_write('visit_product_items','id=eq.'.rawurlencode($itemId).'&visit_id=eq.'.rawurlencode($visitId).'&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store),'PATCH',[
        'status'=>'cancelled','updated_at'=>date(DATE_ATOM)
    ]);
}

function v13_checkout_owner(): void {
    $token=v13_owner_token_required_all(); $visitId=trim((string)($_POST['visit_id']??'')); $method=(string)($_POST['payment_method']??'cash'); $amount=max(0,(float)($_POST['amount']??0));
    if(!in_array($method,['cash','card','ewallet','bank_transfer','member_wallet','other'],true))$method='cash';
    if($visitId===''||$amount<=0)throw new RuntimeException('付款资料不完整。');
    $membershipId=trim((string)($_POST['membership_id']??''));
    if($method==='member_wallet' && $membershipId===''){
        $rec=v13_owner_rows('visit_recipients','select=customer_id&visit_id=eq.'.rawurlencode($visitId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&recipient_type=eq.primary&limit=1');
        $cid=(string)($rec[0]['customer_id']??'');
        if($cid!==''){ $mem=v13_owner_rows('memberships','select=id&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&customer_id=eq.'.rawurlencode($cid).'&status=eq.active&limit=1'); $membershipId=(string)($mem[0]['id']??''); }
        if($membershipId==='')throw new RuntimeException('这个顾客没有可用会员钱包。');
    }
    $reference=trim((string)($_POST['reference_number']??''))?:null;
    // v13.4.7 sends a compatibility payment envelope. Historical checkout_visit builds
    // used different JSON key names (method vs payment_method). Keep all aliases here
    // and normalize again inside Supabase so payment_items.payment_method cannot become NULL.
    $payments=[[
        'payment_method'=>$method,'method'=>$method,'payment_type'=>$method,'type'=>$method,'payment_channel'=>$method,
        'amount'=>$amount,'paid_amount'=>$amount,'payment_amount'=>$amount,'value'=>$amount,
        'reference_number'=>$reference,'reference'=>$reference,'ref'=>$reference,'transaction_reference'=>$reference,'notes'=>null,'note'=>null
    ]];
    $discount=max(0,(float)($_POST['discount_total']??0)); $tax=max(0,(float)($_POST['tax_total']??0)); $membership=$membershipId!==''?$membershipId:null;
    try{
        v13_rpc('v1347_checkout_visit',['p_visit_id'=>$visitId,'p_payments'=>$payments,'p_discount_total'=>$discount,'p_tax_total'=>$tax,'p_membership_id'=>$membership],$token);
    }catch(Throwable $e){
        if(v136_rpc_signature_mismatch($e,'v1347_checkout_visit')){
            throw new RuntimeException('结账数据库契约尚未同步到当前 v13.5.3。请运行 RUN_ONCE_V13_5_3_CUMULATIVE_RUNTIME.sql 后刷新。',0,$e);
        }
        throw $e;
    }
}
function v13_save_kpi_rule(): void {
    v13_owner_token_required_all(); $id=trim((string)($_POST['rule_id']??'')); $metric=(string)($_POST['metric_type']??'service_performance');
    $allowed=['service_performance','product_sales','total_sales','service_count','customer_count','avg_ticket','requested_count','training_completion','manual'];
    if(!in_array($metric,$allowed,true))$metric='service_performance';
    $body=['organization_id'=>v13_org_uuid(),'name'=>trim((string)($_POST['name']??'')),'metric_type'=>$metric,'target_value'=>max(0,(float)($_POST['target_value']??0)),'bonus_amount'=>max(0,(float)($_POST['bonus_amount']??0)),'active'=>!empty($_POST['active']),'updated_at'=>date(DATE_ATOM)];
    if($body['name']==='')throw new RuntimeException('KPI 名称必填。');
    if($id==='')v13_owner_write('v13_kpi_rules','','POST',$body); else v13_owner_write('v13_kpi_rules','id=eq.'.rawurlencode($id),'PATCH',$body);
}
function v13_save_training_course(): void {
    v13_owner_token_required_all(); $id=trim((string)($_POST['course_id']??''));
    $existing=trim((string)($_POST['existing_cover_image_path']??''))?:null;
    $cover=v1350_upload_image('cover_image_file','training',$existing);
    $roles=array_values(array_unique(array_filter(array_map('strval',(array)($_POST['target_roles']??[])))));
    $body=['organization_id'=>v13_org_uuid(),'title'=>trim((string)($_POST['title']??'')),'category'=>trim((string)($_POST['category']??''))?:'通用培训','description'=>trim((string)($_POST['description']??''))?:null,'content'=>trim((string)($_POST['content']??''))?:null,'content_url'=>trim((string)($_POST['content_url']??''))?:null,'cover_image_path'=>$cover,'target_roles'=>$roles,'estimated_minutes'=>max(0,(int)($_POST['estimated_minutes']??0)),'version_label'=>trim((string)($_POST['version_label']??''))?:null,'required'=>!empty($_POST['required']),'publication_status'=>!empty($_POST['active'])?'published':'archived','active'=>!empty($_POST['active']),'updated_at'=>date(DATE_ATOM)];
    if($body['title']==='')throw new RuntimeException('课程名称必填。');
    if($id==='')v13_owner_write('v13_training_courses','','POST',$body); else v13_owner_write('v13_training_courses','id=eq.'.rawurlencode($id),'PATCH',$body);
}
function v13_save_settings(): void {
    v13_owner_token_required_all(); $section=(string)($_POST['settings_section']??'general'); if(!in_array($section,['general','role_permissions','whatsapp'],true))$section='general';
    $rows=v13_owner_rows('v13_organization_settings','select=organization_id,general,role_permissions,whatsapp&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&limit=1');
    $current=$rows[0]??['organization_id'=>v13_org_uuid(),'general'=>[],'role_permissions'=>[],'whatsapp'=>[]];
    if($section==='general')$current['general']=['language'=>(string)($_POST['language']??'zh'),'timezone'=>trim((string)($_POST['timezone']??'Asia/Kuala_Lumpur')),'currency'=>trim((string)($_POST['currency']??'MYR')),'receipt_prefix'=>trim((string)($_POST['receipt_prefix']??'SAL'))];
    elseif($section==='whatsapp')$current['whatsapp']=['enabled'=>!empty($_POST['wa_enabled']),'phone_number_id'=>trim((string)($_POST['wa_phone_number_id']??'')),'business_account_id'=>trim((string)($_POST['wa_business_account_id']??'')),'access_token'=>trim((string)($_POST['wa_access_token']??'')),'reminder_minutes'=>max(0,(int)($_POST['wa_reminder_minutes']??60))];
    else $current['role_permissions']=v13_json_post('permissions_json');
    v13_owner_write('v13_organization_settings','on_conflict=organization_id','POST',$current,'resolution=merge-duplicates,return=representation');
}
function v13_save_commission_settings(): void {
    v13_owner_token_required_all(); $mode=in_array((string)($_POST['mode']??''),['fixed','tiered'],true)?(string)$_POST['mode']:'fixed';
    $body=['organization_id'=>v13_org_uuid(),'mode'=>$mode,'fixed_rate'=>max(0,min(100,(float)($_POST['fixed_rate']??0))),'updated_at'=>date(DATE_ATOM)];
    v13_owner_write('service_commission_settings','on_conflict=organization_id','POST',$body,'resolution=merge-duplicates,return=representation');
}

function v13_employee_create_visit(): string {
    $items=[];
    foreach((array)($_POST['items']??[]) as $item){
        if(!is_array($item))continue;
        $sid=trim((string)($item['service_id']??'')); if($sid==='')continue;
        $items[]=[
            'service_id'=>$sid,
            'recipient_key'=>trim((string)($item['recipient_key']??'self'))?:'self',
            'price'=>max(0,(float)($item['price']??0)),
            'lead_employee_id'=>trim((string)($item['lead_employee_id']??'')),
            'lead_contribution'=>isset($item['lead_contribution'])?(float)$item['lead_contribution']:null,
            'co_stylists'=>array_values(array_map('strval',(array)($item['co_stylists']??[]))),
            'co_contributions'=>array_values((array)($item['co_contributions']??[])),
            'assistants'=>array_values(array_map('strval',(array)($item['assistants']??[]))),
            'assistant_contributions'=>array_values((array)($item['assistant_contributions']??[])),
        ];
    }
    $recipients=[];
    foreach((array)($_POST['recipients']??[]) as $rec){
        if(!is_array($rec))continue;
        $name=trim((string)($rec['name']??'')); if($name==='')continue;
        $recipients[]=[
            'key'=>trim((string)($rec['key']??'')),
            'name'=>$name,
            'relationship'=>trim((string)($rec['relationship']??'同行者')),
            'age'=>trim((string)($rec['age']??'')),
        ];
    }
    $visitType=(string)($_POST['visit_type']??'walk_in');
    $scheduledRaw=trim((string)($_POST['appointment_at']??$_POST['scheduled_at']??''));
    $scheduledPayload=$scheduledRaw;
    if($visitType==='appointment'){
        if($scheduledRaw==='') throw new RuntimeException('预约订单必须填写预约日期与时间。');
        $tz=new DateTimeZone('Asia/Kuala_Lumpur');
        $scheduledDt=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$scheduledRaw,$tz);
        if(!$scheduledDt){
            try{$scheduledDt=new DateTimeImmutable($scheduledRaw,$tz);}catch(Throwable $e){$scheduledDt=false;}
        }
        if(!$scheduledDt) throw new RuntimeException('预约日期与时间格式无效。');
        // datetime-local carries no timezone. Convert it to an explicit Malaysia offset
        // before sending to Supabase so PostgreSQL does not treat 18:00 MYT as 18:00 UTC.
        $scheduledPayload=$scheduledDt->format(DATE_ATOM);
    }
    $requestedAssignment=((string)($_POST['assignment_type']??'specified')==='system')?'system':'specified';
    $appointmentPreference=((string)($_POST['appointment_assignment_type']??'system')==='specified')?'specified':'system';
    $appointmentEmployee=trim((string)($_POST['appointment_employee_id']??''));
    $teamPreflight=v1361030_preflight_visit_team($items,$visitType,$scheduledPayload,$requestedAssignment,$appointmentPreference,$appointmentEmployee);
    $systemLeadPlan=is_array($teamPreflight['system_leads']??null)?$teamPreflight['system_leads']:[];
    if($requestedAssignment==='system'){
        foreach($items as $idx=>&$row){ if(is_array($row) && isset($systemLeadPlan[$idx])) $row['lead_employee_id']=(string)$systemLeadPlan[$idx]; }
        unset($row);
    }
    // The legacy transactional employee RPC treats assignment_type=system as "use current employee".
    // v13.6.10.30 resolves the system choice here using the validated pool, then asks the RPC to persist
    // those concrete assignments. Analytics below still records the customer's original random/system choice.
    $executionAssignment=$requestedAssignment==='system'?'specified':$requestedAssignment;

    $payload=[
        'customer_id'=>trim((string)($_POST['customer_id']??'')),
        'customer_name'=>trim((string)($_POST['customer_name']??'')),
        'customer_phone'=>trim((string)($_POST['customer_phone']??'')),
        'customer_ethnicity'=>trim((string)($_POST['customer_ethnicity']??'')),
        'customer_gender'=>(string)($_POST['customer_gender']??'unspecified'),
        'customer_birth_date'=>trim((string)($_POST['customer_birth_date']??'')),
        'customer_age'=>trim((string)($_POST['customer_age']??'')),
        'customer_acquisition_platform'=>trim((string)($_POST['customer_acquisition_platform']??'')),
        'visit_type'=>$visitType,
        'scheduled_at'=>$scheduledPayload,
        'appointment_assignment_type'=>(string)($_POST['appointment_assignment_type']??'system'),
        'appointment_employee_id'=>trim((string)($_POST['appointment_employee_id']??'')),
        'assignment_type'=>$executionAssignment,
        'notes'=>trim((string)($_POST['notes']??'')),
        'recipients'=>$recipients,
        'items'=>$items,
    ];
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($session==='')throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    $r=v13_rpc_json('v134_employee_create_visit',['p_session_token'=>$session,'p_payload'=>$payload],'');
    $id=trim((string)($r['visit_id']??''));
    if($id==='')throw new RuntimeException('订单建立失败。');

    // v13.5.11: employee-created visits also record stylist preference + first-visit source.
    // This additive RPC is allowed to be absent temporarily so an un-run patch never blocks order creation.
    $prefType=$visitType==='appointment'
        ? (((string)($_POST['appointment_assignment_type']??'system')==='specified')?'specified':'random')
        : (((string)($_POST['assignment_type']??'specified')==='specified')?'specified':'random');
    $prefEmployee='';
    if($prefType==='specified'){
        if($visitType==='appointment') $prefEmployee=trim((string)($_POST['appointment_employee_id']??''));
        if($prefEmployee===''){
            foreach($items as $row){$candidate=trim((string)($row['lead_employee_id']??''));if($candidate!==''){$prefEmployee=$candidate;break;}}
        }
    }
    try{
        v13_rpc_json('v13511_employee_finalize_visit_intake',[
            'p_session_token'=>$session,
            'p_visit_id'=>$id,
            'p_preference_type'=>$prefType,
            'p_employee_id'=>$prefEmployee!==''?$prefEmployee:null,
            'p_acquisition_platform'=>trim((string)($_POST['customer_acquisition_platform']??''))
        ],'');
    }catch(Throwable $finalizeError){
        if(!v135_rpc_missing($finalizeError,'v13511_employee_finalize_visit_intake')) throw $finalizeError;
    }
    return $id;
}
function v13_employee_update_training(): void {
    v13_employee_api('training_progress',['course_id'=>(string)($_POST['course_id']??''),'progress_percent'=>max(0,min(100,(int)($_POST['progress_percent']??0)))]);
}
function v13_employee_visit_status(): void {
    v13_employee_api('visit_status',['visit_id'=>(string)($_POST['visit_id']??''),'status'=>(string)($_POST['status']??'')]);
}
function v13_employee_signoff(): void {
    v13_employee_api('signoff',['service_item_id'=>(string)($_POST['service_item_id']??''),'signature_data'=>(string)($_POST['signature_data']??'')]);
}

function v1344_employee_board_status(): void {
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($session==='') throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    $visitId=trim((string)($_POST['visit_id']??'')); $status=trim((string)($_POST['status']??''));
    if($visitId==='') throw new RuntimeException('找不到订单。');
    try { v13_rpc_json('v1344_employee_set_visit_status',['p_session_token'=>$session,'p_visit_id'=>$visitId,'p_status'=>$status],''); }
    catch(Throwable $e){ if(!v135_rpc_missing($e,'v1344_employee_set_visit_status')) throw $e; v13_employee_api('visit_status',['visit_id'=>$visitId,'status'=>$status]); }
}
function v1344_employee_availability(): void {
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($session==='') throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    $status=trim((string)($_POST['availability_status']??'available'));
    try { v13_rpc_json('v1344_employee_set_availability',['p_session_token'=>$session,'p_status'=>$status],''); }
    catch(Throwable $e){ if(!v135_rpc_missing($e,'v1344_employee_set_availability')) throw $e; throw new RuntimeException('数据库尚未安装实时员工状态补丁；服务现场仍可使用，请先运行 RUN_ONCE_V13_5_0_CUMULATIVE_RUNTIME.sql。'); }
}
function v1344_board_arrive(): void {
    if(empty($_POST['phone_confirmed'])) throw new RuntimeException('请先核对顾客手机号。');
    $_POST['status']='arrived';
    if(v13_is_owner()) { v13_update_visit_status_owner(); return; }
    // v13.5.8: assigned staff may confirm that their own appointment customer has arrived.
    // The Supabase RPC is the security boundary: manager/receptionist can manage the store,
    // while normal staff may only mark visits assigned to themselves.
    v1344_employee_board_status();
}

function v1331_owner_confirm_visit(): void {
    v13_owner_token_required_all();
    $visitId=trim((string)($_POST['visit_id']??'')); $sig=trim((string)($_POST['signature_data']??'')); $name=trim((string)($_POST['customer_name']??''));
    if($visitId===''||strlen($sig)<40)throw new RuntimeException('请先完成顾客签名。');
    $detail=v13_owner_visit_detail($visitId); if(!$detail)throw new RuntimeException('找不到这笔订单。');
    $visit=$detail['visit']??[];
    $visitType=(string)($visit['visit_type']??'walk_in');
    if(in_array((string)($visit['status']??''),['completed','cancelled','no_show'],true))throw new RuntimeException('已关闭的订单不能修改顾客签名。');
    if($visitType==='appointment' && empty($visit['arrived_at'])) throw new RuntimeException('预约顾客还没有确认到店；请先在服务现场点击「顾客已到达」，到店后才可以签名。');
    $snapshot=v1331_build_review_snapshot($detail);
    $existing=v13_owner_rows('v13_visit_confirmations','select=id&visit_id=eq.'.rawurlencode($visitId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&limit=1');
    $body=[
        'organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'visit_id'=>$visitId,
        'customer_name'=>$name!==''?$name:(string)($snapshot['customer_name']??'顾客'),
        'signature_data'=>$sig,'order_snapshot'=>$snapshot,'signed_at'=>date(DATE_ATOM),
        'created_by_user_id'=>(string)(user()['id']??'')?:null,'updated_at'=>date(DATE_ATOM)
    ];
    if($existing)v13_owner_write('v13_visit_confirmations','id=eq.'.rawurlencode((string)$existing[0]['id']),'PATCH',$body);
    else v13_owner_write('v13_visit_confirmations','','POST',$body);
    if(in_array((string)($visit['status']??''),['draft','arrived'],true)){
        v13_owner_write('visits','id=eq.'.rawurlencode($visitId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',['status'=>'waiting','updated_at'=>date(DATE_ATOM)]);
    }
}
function v1331_employee_confirm_visit(): void {
    $visitId=trim((string)($_POST['visit_id']??'')); $sig=trim((string)($_POST['signature_data']??'')); $name=trim((string)($_POST['customer_name']??''));
    if($visitId===''||strlen($sig)<40)throw new RuntimeException('请先完成顾客签名。');
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($session==='')throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    $review=v1331_employee_order_review($visitId);
    $visit=is_array($review['visit']??null)?$review['visit']:[];
    if((string)($visit['visit_type']??'walk_in')==='appointment' && empty($visit['arrived_at'])){
        throw new RuntimeException('预约顾客还没有确认到店；请先在服务现场点击「顾客已到达」，到店后才可以签名。');
    }
    v13_rpc_json('v1331_employee_confirm_visit',['p_session_token'=>$session,'p_visit_id'=>$visitId,'p_customer_name'=>$name,'p_signature_data'=>$sig],'');
}

function v13_handle_full_action(string $action): bool {
    if($_SERVER['REQUEST_METHOD']!=='POST')return false;
    $owner=v13_is_owner();
    if($owner && $action==='save_service'){v13_save_service();flash('success','服务项目已保存到 Supabase。');return true;}
    if($owner && $action==='delete_service_v1352'){flash('success',v1352_delete_service());return true;}
    if($owner && $action==='save_service_category_v1350'){v1350_save_service_category();flash('success','服务分类已保存。');return true;}
    if($owner && $action==='archive_service_category_v1350'){v1350_archive_service_category();flash('success','服务分类已停用；历史服务不会删除。');return true;}
    if($owner && $action==='create_visit_v13'){$_SESSION['v1331_last_visit_id']=v13_create_visit_owner();flash('success',((string)($_POST['visit_type']??'walk_in')==='appointment')?'预约已建立；顾客到店后再由员工确认到店并让顾客签名。':'订单已建立，请让顾客完成第 4 步签名。');return true;}
    if($owner && $action==='visit_status_v13'){v13_update_visit_status_owner();flash('success','订单状态已更新。');return true;}
    if($action==='board_arrive_v1344'){v1344_board_arrive();flash('success','顾客已确认到店，订单继续保留在当前日期时间表。');return true;}
    if($owner && $action==='assign_service_workers_v13'){v13_assign_service_workers_owner();flash('success','项目负责员工已更新。');return true;}
    if($owner && $action==='add_visit_product_v13'){v13_add_visit_product_owner();flash('success','产品已加入订单；库存会在结账时扣减。');return true;}
    if($owner && $action==='remove_visit_product_v13'){v13_remove_visit_product_owner();flash('success','已从订单移除产品；订单金额已重新计算。');return true;}
    if($owner && $action==='checkout_v13'){v13_checkout_owner();flash('success','订单已在 Supabase 完成结账。');return true;}
    if($owner && $action==='save_product_v13'){v13_save_product();flash('success','产品已保存到 Supabase。');return true;}
    if($owner && $action==='delete_product_v1352'){flash('success',v1352_delete_product());return true;}
    if($owner && $action==='save_product_category_v1353'){v1353_save_product_category();flash('success','产品分类已保存。');return true;}
    if($owner && $action==='archive_product_category_v1353'){v1353_archive_product_category();flash('success','产品分类已停用；历史产品不会删除。');return true;}
    if($owner && $action==='save_inventory_v1350'){v1350_save_inventory_item();flash('success','库存货品已保存；照片已独立放在 Supabase Storage。');return true;}
    if($owner && $action==='archive_inventory_v1350'){v1350_archive_inventory_item();flash('success','库存货品已归档；历史库存流水继续保留。');return true;}
    if($owner && $action==='adjust_stock_v13'){v13_adjust_stock();flash('success','库存流水已写入 Supabase。');return true;}
    if($owner && $action==='save_bundle_v13'){v13_save_bundle();flash('success','产品配套已保存到 Supabase。');return true;}
    if($owner && $action==='delete_bundle_v1352'){flash('success',v1352_delete_bundle());return true;}
    if($owner && $action==='save_kpi_v13'){v13_save_kpi_rule();flash('success','KPI 已保存到 Supabase。');return true;}
    if($owner && $action==='assign_kpi_v1350'){v1350_assign_kpi();flash('success','员工 KPI 任务已设置。');return true;}
    if($owner && $action==='save_training_v13'){v13_save_training_course();flash('success','培训课程已保存到 Supabase。');return true;}
    if($owner && $action==='save_settings_v13'){v13_save_settings();flash('success','系统设置已保存到 Supabase。');return true;}
    if($owner && $action==='save_commission_v13'){v13_save_commission_settings();flash('success','抽成设置已保存到 Supabase。');return true;}
    if($owner && $action==='save_commission_tier_v1350'){v1350_save_commission_tier();flash('success','抽成阶梯已保存。');return true;}
    if($owner && $action==='archive_commission_tier_v1350'){v1350_archive_commission_tier();flash('success','抽成阶梯已停用。');return true;}
    if($owner && $action==='save_monthly_commission_override_v1350'){v1350_save_monthly_commission_override();flash('success','员工月度抽成调整已保存。');return true;}
    if(!$owner && $action==='employee_create_visit_v13'){$_SESSION['v1331_last_visit_id']=v13_employee_create_visit();flash('success',((string)($_POST['visit_type']??'walk_in')==='appointment')?'预约已建立；现在不签名，等顾客到店后从服务现场确认到店再签名。':'订单已建立，请让顾客完成第 4 步签名。');return true;}
    if(!$owner && $action==='employee_visit_status_v13'){v13_employee_visit_status();flash('success','服务状态已更新。');return true;}
    if(!$owner && $action==='board_employee_status_v1344'){v1344_employee_board_status();flash('success','服务状态已更新。');return true;}
    if(!$owner && $action==='employee_availability_v1344'){v1344_employee_availability();flash('success','你的实时工作状态已更新。');return true;}
    if(!$owner && $action==='employee_signoff_v13'){v13_employee_signoff();flash('success','顾客签名已保存到 Supabase。');return true;}
    if($owner && $action==='confirm_visit_v1331'){v1331_owner_confirm_visit();flash('success','顾客签名与订单确认已保存到 Supabase。');return true;}
    if(!$owner && $action==='confirm_visit_v1331'){v1331_employee_confirm_visit();flash('success','顾客签名与订单确认已保存到 Supabase。');return true;}
    if(!$owner && $action==='employee_training_v13'){v13_employee_update_training();flash('success','培训进度已保存。');return true;}
    return false;
}

function v1358_dashboard_live_payload(): array {
    if(v13_is_owner()){
        $d=v13_rpc_json('v13_owner_dashboard',['p_store_id'=>v13_store_uuid()],v13_owner_token_required_all());
        $products=v13_product_rows(false); $stock=v13_inventory_map(); $low=0;
        foreach($products as $p){ if(!empty($p['stock_enabled']) && ($stock[(string)$p['id']]??0)<=(float)($p['reorder_level']??0)) $low++; }
        return [
            'customers'=>(string)intval($d['customers']??0),
            'active_employees'=>(string)intval($d['active_employees']??0),
            'today_visits'=>(string)intval($d['today_visits']??0),
            'ready_checkout'=>(string)intval($d['ready_checkout']??0),
            'month_revenue'=>money($d['month_revenue']??0),
            'low_stock'=>(string)$low,
            'updated_at'=>(new DateTimeImmutable('now',new DateTimeZone('Asia/Kuala_Lumpur')))->format('H:i:s')
        ];
    }
    $d=v13_employee_api('dashboard');
    return [
        'today_visits'=>(string)intval($d['today_visits']??0),
        'assigned_open'=>(string)intval($d['assigned_open']??0),
        'updated_at'=>(new DateTimeImmutable('now',new DateTimeZone('Asia/Kuala_Lumpur')))->format('H:i:s')
    ];
}

function v13_page_dashboard(): void {
    if(v13_is_owner()){
        $d=v13_rpc_json('v13_owner_dashboard',['p_store_id'=>v13_store_uuid()],v13_owner_token_required_all());
        $products=v13_product_rows(false);$stock=v13_inventory_map();
        $low=0;foreach($products as $p){if(!empty($p['stock_enabled'])&&($stock[(string)$p['id']]??0)<=(float)($p['reorder_level']??0))$low++;}
        ?>
        <div class="page-head"><div><span class="eyebrow">STORE OVERVIEW · SUPABASE</span><h1>工作台</h1><p><?=e((string)(current_store()['name']??'当前门店'))?> · 这里不再放重复快捷入口，直接显示门店实时经营数据。</p></div><div class="page-head-actions"><span class="badge badge-green" data-dashboard-live-status>实时同步</span></div></div>
        <section class="v1350-dashboard-data-grid" data-dashboard-live-root>
          <article class="v1350-data-tile"><div class="v1350-data-icon"><?=ui_icon('users')?></div><div><span>当前门店顾客</span><strong data-dashboard-live="customers"><?=intval($d['customers']??0)?></strong><small>Customer records</small></div></article>
          <article class="v1350-data-tile"><div class="v1350-data-icon"><?=ui_icon('employee')?></div><div><span>在职员工</span><strong data-dashboard-live="active_employees"><?=intval($d['active_employees']??0)?></strong><small>Active staff</small></div></article>
          <article class="v1350-data-tile"><div class="v1350-data-icon"><?=ui_icon('clock')?></div><div><span>今日订单</span><strong data-dashboard-live="today_visits"><?=intval($d['today_visits']??0)?></strong><small>Walk-in + Appointment</small></div></article>
          <article class="v1350-data-tile"><div class="v1350-data-icon"><?=ui_icon('receipt')?></div><div><span>待结账</span><strong data-dashboard-live="ready_checkout"><?=intval($d['ready_checkout']??0)?></strong><small>Ready for checkout</small></div></article>
          <article class="v1350-data-tile v1350-data-tile-wide"><div class="v1350-data-icon"><?=ui_icon('analytics')?></div><div><span>本月营业额</span><strong data-dashboard-live="month_revenue"><?=money($d['month_revenue']??0)?></strong><small>已付款订单，不因多人 Contribution 重复计算</small></div></article>
          <article class="v1350-data-tile"><div class="v1350-data-icon"><?=ui_icon('box')?></div><div><span>低库存提醒</span><strong data-dashboard-live="low_stock"><?=$low?></strong><small>达到 / 低于补货线</small></div></article>
        </section>
        <section class="card v1350-store-pulse"><div><span class="card-kicker">STORE PULSE</span><h3>门店运行状态</h3><p>服务现场、订单、产品库存、KPI、抽成与经营分析继续共用同一套 Supabase 门店数据。</p></div><div class="v1350-pulse-chips"><span class="badge badge-green">Supabase Only</span><span class="badge badge-gold"><?=e((string)(current_store()['name']??'Store'))?></span><span class="badge <?=$low>0?'badge-red':'badge-green'?>"><?=$low>0?$low.' 项低库存':'库存正常'?></span></div></section>
        <?php
    }else{
        $d=v13_employee_api('dashboard'); ?>
        <div class="page-head"><div><span class="eyebrow">EMPLOYEE WORKSPACE · SUPABASE</span><h1>工作台</h1><p><?=e((string)(user()['employee_name']??'员工'))?> · <?=e((string)(current_store()['name']??'SalonOS'))?></p></div><div class="page-head-actions"><span class="badge badge-green" data-dashboard-live-status>实时同步</span></div></div>
        <section class="v1350-dashboard-data-grid" data-dashboard-live-root>
          <article class="v1350-data-tile"><div class="v1350-data-icon"><?=ui_icon('clock')?></div><div><span>今日门店订单</span><strong data-dashboard-live="today_visits"><?=intval($d['today_visits']??0)?></strong><small>当前分行</small></div></article>
          <article class="v1350-data-tile"><div class="v1350-data-icon"><?=ui_icon('scissors')?></div><div><span>我的进行中项目</span><strong data-dashboard-live="assigned_open"><?=intval($d['assigned_open']??0)?></strong><small>只显示与你相关</small></div></article>
        </section>
        <?php
    }
}

function v13_page_services(): void {
    if(!v13_is_owner()){echo '<section class="card" style="padding:24px"><h2>服务项目</h2><p>员工端只在新建订单中读取对应分类的启用服务；服务目录由管理层维护。</p></section>';return;}
    $showArchived=!empty($_GET['show_archived']);$rows=v13_service_rows(!$showArchived,$showArchived);$categories=v1350_service_categories(!$showArchived);$filter=trim((string)($_GET['category_id']??''));
    $listUrl='index.php?page=services'.($showArchived?'&show_archived=1':'');
    $countBy=[];foreach($rows as $r){$key=(string)($r['category_id']??'');$countBy[$key]=($countBy[$key]??0)+1;}
    $initialVisibleCount=$filter!==''?(int)($countBy[$filter]??0):count($rows);
    ?>
    <div class="page-head responsive-page-head"><div><span class="eyebrow">SERVICE LIBRARY · SUPABASE</span><h1>服务项目</h1><p>先建立服务分类，再把服务放进对应分类；删除后不会继续堆在正常列表，有历史引用的资料只在「已归档」查看。</p></div><div class="hero-actions"><a class="btn btn-light" href="index.php?page=services<?=$showArchived?'':'&show_archived=1'?>"><?=$showArchived?'返回启用服务':'查看已归档'?></a><button class="btn btn-light" type="button" data-v1350-modal-open="service-category">＋ 新建分类</button><button class="btn btn-primary" type="button" data-v1350-modal-open="service-item">＋ 新增服务</button></div></div>
    <section class="v1350-folder-grid" data-inline-category-nav="services">
      <a class="v1350-folder-card <?=$filter===''?'active':''?>" href="<?=e($listUrl)?>" data-inline-category-filter="" data-no-page-loader><div class="v1350-folder-icon"><?=ui_icon('box')?></div><div><strong><?=$showArchived?'全部归档服务':'全部服务'?></strong><span><?=count($rows)?> 项</span></div></a>
      <?php foreach($categories as $cat):$cid=(string)$cat['id'];?><a class="v1350-folder-card <?=$filter===$cid?'active':''?>" href="<?=e($listUrl.'&category_id='.rawurlencode($cid))?>" data-inline-category-filter="<?=e($cid)?>" data-no-page-loader><div class="v1350-folder-icon"><?=ui_icon('scissors')?></div><div><strong><?=e((string)$cat['name'])?></strong><span><?=intval($countBy[$cid]??0)?> 项</span></div></a><?php endforeach;?>
    </section>
    <section class="card v1350-service-list-card" data-inline-category-content="services"><div class="card-head"><div><span class="card-kicker">SERVICES</span><h3 data-inline-category-title data-title-all="全部服务" data-title-filtered="分类服务"><?=$filter!==''?'分类服务':'全部服务'?></h3></div><span class="muted" data-inline-category-count><?=$initialVisibleCount?> 项</span></div>
      <div class="v1350-service-cards"><?php foreach($rows as $r):$rcid=(string)($r['category_id']??'');$hidden=$filter!==''&&$rcid!==$filter;?><article class="v1350-service-card" data-inline-category-item="<?=e($rcid)?>" <?=$hidden?'hidden':''?>><div><span class="card-kicker"><?=e((string)($r['category']??'未分类'))?></span><h3><?=e((string)$r['name'])?></h3><p><?=money($r['default_price']??0)?> · <?=intval($r['estimated_minutes']??0)?> 分钟 · <?=!empty($r['allows_assistant'])?'允许助理':'主理发师'?></p></div><div class="v1350-row-actions"><span class="badge <?=!empty($r['active'])?'badge-green':'badge-gray'?>"><?=!empty($r['active'])?'启用':'停用'?></span><button class="btn btn-light btn-small" type="button" data-v1350-modal-open="service-item" data-id="<?=e((string)$r['id'])?>" data-name="<?=e((string)$r['name'])?>" data-category_id="<?=e((string)($r['category_id']??''))?>" data-category="<?=e((string)($r['category']??''))?>" data-price="<?=e((string)($r['default_price']??0))?>" data-minutes="<?=e((string)($r['estimated_minutes']??60))?>" data-allows_assistant="<?=!empty($r['allows_assistant'])?'1':'0'?>" data-active="<?=!empty($r['active'])?'1':'0'?>">修改</button><button class="btn btn-danger-soft btn-small" type="button" data-v1350-modal-open="service-delete" data-service_id="<?=e((string)$r['id'])?>" data-service_name="<?=e((string)$r['name'])?>">删除</button></div></article><?php endforeach;?><div class="empty compact-empty" data-inline-category-empty <?=$initialVisibleCount>0?'hidden':''?>><h3>这个分类还没有服务</h3><p>点击「新增服务」建立第一项。</p></div></div>
    </section>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="service-category"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">SERVICE CATEGORY</span><h3>新建服务分类</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_service_category_v1350"><input type="hidden" name="return_page" value="services"><div class="field"><label>分类名称 *</label><input class="input" name="name" required placeholder="例如 Haircut / Colour / Treatment"></div><div class="field"><label>说明</label><textarea class="textarea" name="description" rows="3"></textarea></div><div class="field"><label>排序</label><input class="input" type="number" name="sort_order" value="0"></div><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" checked><span>启用分类</span></label><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存分类</button></div></form></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="service-item"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">SERVICE ITEM</span><h3>新增 / 修改服务</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_service"><input type="hidden" name="return_page" value="services"><input type="hidden" name="service_id" data-bind="id"><div class="form-grid"><div class="field"><label>服务分类 *</label><select class="select" name="category_id" data-bind="category_id" required><option value="">选择分类</option><?php foreach($categories as $cat):if(empty($cat['active']))continue;?><option value="<?=e((string)$cat['id'])?>"><?=e((string)$cat['name'])?></option><?php endforeach;?></select><input type="hidden" name="category" data-bind="category"></div><div class="field"><label>服务名称 *</label><input class="input" name="name" data-bind="name" required></div><div class="field"><label>默认价格 RM</label><input class="input" type="number" step="0.01" min="0" name="price" data-bind="price" value="0"></div><div class="field"><label>预计分钟</label><input class="input" type="number" min="1" name="minutes" data-bind="minutes" value="60"></div><label class="confirm-checkbox"><input type="checkbox" name="allows_assistant" value="1" data-bind="allows_assistant"><span>允许助理参与</span></label><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" data-bind="active" checked><span>启用服务</span></label></div><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存服务</button></div></form></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="service-delete"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">DELETE SERVICE</span><h3>删除服务项目</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="delete_service_v1352"><input type="hidden" name="return_page" value="services"><input type="hidden" name="service_id" data-bind="service_id"><p>确定删除「<strong data-v1350-copy="service_name">这个服务</strong>」？没有历史引用会直接删除；已有历史订单则会安全归档，避免破坏旧订单。</p><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-danger">确认删除</button></div></form></section></div>
    <?php
}


function v1331_visit_wizard_progress(int $currentStep): void {
    $labels=[1=>'到店类型',2=>'顾客与项目',3=>'订单确认',4=>'电子签名'];
    $progress=max(0,min(100,(($currentStep-1)/3)*100));
    ?>
    <div class="wizard-progress" data-wizard-progress style="--wizard-progress:<?=$progress?>%">
      <div class="wizard-progress-line"><span data-progress-fill></span></div>
      <div class="wizard-step-list">
        <?php foreach($labels as $step=>$label): $state=$step<$currentStep?'done':($step===$currentStep?'current':'upcoming'); ?>
        <button class="wizard-step <?=$state?>" type="button" data-step-indicator="<?=$step?>" data-step-number="<?=$step?>" <?=$currentStep===4?'disabled':''?>>
          <span class="wizard-step-number"><?=$step<$currentStep?'✓':$step?></span><span class="wizard-step-label"><?=e($label)?></span>
        </button>
        <?php endforeach; ?>
      </div>
    </div>
    <?php
}
function v1331_recipient_editor_row(): void { ?>
    <article class="recipient-editor" data-recipient-row>
      <input type="hidden" data-recipient-field="key" value="">
      <div class="recipient-editor-index" data-recipient-index>同行者</div>
      <div class="field"><label>姓名 *</label><input class="input" data-recipient-field="name" placeholder="例如：小明 Junior"></div>
      <div class="field"><label>关系</label><select class="select" data-recipient-field="relationship"><?php foreach(['孩子','长辈','家人','朋友','同行者','其他'] as $option): ?><option><?=e($option)?></option><?php endforeach; ?></select></div>
      <div class="field"><label>年龄</label><input class="input" type="number" min="0" max="120" data-recipient-field="age" placeholder="选填"></div>
      <button type="button" class="icon-danger-button" data-remove-recipient aria-label="删除同行者"><?=ui_icon('x')?></button>
    </article>
<?php }
function v1331_worker_select_row(string $role,array $employees): void { ?>
    <div class="worker-select-row" data-worker-row>
      <select class="select worker-select" data-worker-role="<?=e($role)?>"><option value="">请选择员工</option><?php foreach($employees as $employee): ?><option value="<?=e((string)$employee['id'])?>"><?=e((string)$employee['name'].' · '.(string)($employee['position']??''))?></option><?php endforeach; ?></select>
      <label class="worker-share-input"><input class="input contribution-input" type="number" min="0" max="100" step="0.01" value="0" data-worker-contribution aria-label="贡献比例"><span>%</span></label>
      <button type="button" class="worker-remove" data-remove-worker aria-label="删除人员"><?=ui_icon('x')?></button>
    </div>
<?php }
function v1331_service_row(array $services,array $stylists,array $helpers): void {
    $categoryMap=[];
    foreach($services as $service){
        $cid=(string)($service['category_id']??'');
        $cname=trim((string)($service['category']??'未分类'));
        $key=$cid!==''?$cid:'legacy:'.sha1($cname);
        $categoryMap[$key]=['id'=>$key,'name'=>$cname];
    }
    ?>
    <article class="service-row">
      <header class="service-row-head"><div class="service-row-title"><span class="service-index">项目 1</span><small data-service-summary>请先选择服务分类</small></div><button type="button" class="service-remove" data-remove-service aria-label="删除项目"><?=ui_icon('x')?></button></header>
      <div class="service-row-grid">
        <div class="field"><label>服务分类 *</label><select class="select service-category-select" data-service-category required><option value="">选择分类</option><?php foreach($categoryMap as $cat):?><option value="<?=e((string)$cat['id'])?>"><?=e((string)$cat['name'])?></option><?php endforeach;?></select></div>
        <div class="field service-main-field"><label>分类内服务 *</label><select class="select service-select" data-field="service_id" required disabled><option value="">先选择分类</option><?php foreach($services as $service):$cid=(string)($service['category_id']??'');$cname=trim((string)($service['category']??'未分类'));$key=$cid!==''?$cid:'legacy:'.sha1($cname); ?><option value="<?=e((string)$service['id'])?>" data-category-id="<?=e($key)?>" data-price="<?=e((string)($service['default_price']??$service['price']??0))?>" data-minutes="<?=e((string)($service['estimated_minutes']??$service['minutes']??60))?>" hidden><?=e((string)$service['name'])?></option><?php endforeach; ?></select><div class="duration-label"><span><?=ui_icon('clock')?></span><span data-duration-text>0 分钟</span><span>系统默认预计时间</span></div></div>
        <div class="field recipient-field"><label>服务对象</label><select class="select recipient-select" data-field="recipient_key"><option value="self">顾客本人</option></select></div>
        <div class="field price-field"><label>项目价格</label><div class="money-input"><span>RM</span><input class="input price-input" type="number" min="0" step="0.01" data-field="price" value="0.00"></div></div>
        <div class="service-team-grid">
          <div class="field lead-field"><label>主理发师 *</label><div class="lead-assignment-row"><select class="select lead-select" data-field="lead_employee_id" data-availability-select><option value="">由系统智能建议</option><?php foreach($stylists as $employee): ?><option value="<?=e((string)$employee['id'])?>"><?=e((string)$employee['name'].' · '.(string)($employee['position']??''))?></option><?php endforeach; ?></select><label class="lead-share-input"><input class="input contribution-input" type="number" min="0" max="100" step="0.01" value="100" data-field="lead_contribution" data-lead-contribution aria-label="主理发师贡献比例"><span>%</span></label></div><small class="field-hint">一个项目可以多位理发师与多位助理。每位工作人员都可以单独调整 Contribution %，总和必须是 100%。</small></div>
          <div class="team-builder"><div class="team-builder-head"><div><label>共同理发师</label><small>可以增加多位共同理发师</small></div><button type="button" class="team-add-button" data-add-worker="co_stylist">＋ 增加理发师</button></div><div class="worker-list" data-worker-list="co_stylist"></div><template data-worker-template="co_stylist"><?php v1331_worker_select_row('co_stylist',$stylists); ?></template></div>
          <div class="team-builder"><div class="team-builder-head"><div><label>助理 / 协助员工</label><small>可以增加多位助理</small></div><button type="button" class="team-add-button" data-add-worker="assistant">＋ 增加助理</button></div><div class="worker-list" data-worker-list="assistant"></div><template data-worker-template="assistant"><?php v1331_worker_select_row('assistant',$helpers); ?></template></div>
        </div>
        <div class="contribution-note"><div><strong>业绩 / 贡献分配</strong><span data-contribution-note>目前总和 100%。</span></div><button type="button" class="btn btn-light btn-small" data-auto-contribution>自动分配</button></div>
      </div>
    </article>
<?php }

function v1331_build_review_snapshot(array $detail): array {
    $visit=is_array($detail['visit']??null)?$detail['visit']:[];
    $recipients=is_array($detail['recipients']??null)?$detail['recipients']:[];
    $items=is_array($detail['items']??null)?$detail['items']:[];
    $allWorkers=is_array($detail['workers']??null)?$detail['workers']:[];
    $employeeMap=[];
    if(v13_is_owner()){
        try{foreach(v13_employee_rows_owner() as $e)$employeeMap[(string)$e['id']]=(string)$e['name'];}catch(Throwable $ignored){}
    }
    foreach((array)($detail['employees']??[]) as $e)if(is_array($e))$employeeMap[(string)($e['id']??'')]=(string)($e['name']??'员工');

    $recipientMap=[]; $primary=[];
    foreach($recipients as $r){
        if(!is_array($r))continue;
        $recipientMap[(string)($r['id']??'')]=(string)($r['name_snapshot']??'顾客');
        if(($r['recipient_type']??'')==='primary')$primary=$r;
    }
    $outItems=[]; $total=0.0; $minutes=0;
    foreach($items as $item){
        if(!is_array($item))continue;
        $itemId=(string)($item['id']??'');
        $workers=is_array($item['workers']??null)?$item['workers']:array_values(array_filter($allWorkers,fn($w)=>is_array($w)&&(string)($w['service_item_id']??'')===$itemId&&($w['status']??'active')==='active'));
        $workerNames=['primary'=>[],'support'=>[],'assistant'=>[]];
        foreach($workers as $w){
            if(!is_array($w))continue;
            $role=(string)($w['worker_role']??$w['role']??'support');
            $eid=(string)($w['employee_id']??'');
            $nm=(string)($w['employee_name']??$w['name']??($employeeMap[$eid]??'员工'));
            $pct=(float)($w['contribution_percent']??0);
            $label=$nm.($pct>0?' '.rtrim(rtrim(number_format($pct,2,'.',''),'0'),'.').'%':'');
            $workerNames[$role]??=[]; $workerNames[$role][]=$label;
        }
        $line=(float)($item['line_total']??((float)($item['unit_price']??0)*(float)($item['quantity']??1)));
        $mins=(int)($item['estimated_minutes_snapshot']??$item['minutes']??0);
        $total+=$line; $minutes+=$mins;
        $outItems[]=[
            'id'=>$itemId,'name'=>(string)($item['service_name_snapshot']??$item['name']??'服务项目'),
            'category'=>(string)($item['service_category_snapshot']??$item['category']??''),
            'recipient'=>(string)($recipientMap[(string)($item['recipient_id']??'')]??($primary['name_snapshot']??'顾客本人')),
            'amount'=>$line,'minutes'=>$mins,'primary'=>$workerNames['primary']??[],'support'=>$workerNames['support']??[],'assistants'=>$workerNames['assistant']??[]
        ];
    }
    return [
        'visit_id'=>(string)($visit['id']??''),'visit_number'=>(string)($visit['visit_number']??''),
        'visit_type'=>(string)($visit['visit_type']??'walk_in'),'scheduled_at'=>$visit['scheduled_at']??null,
        'customer_name'=>(string)($primary['name_snapshot']??'顾客'),'customer_phone'=>(string)($primary['phone_snapshot']??''),
        'items'=>$outItems,'total'=>$total,'minutes'=>$minutes
    ];
}
function v1331_employee_order_review(string $visitId): array {
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($session==='')throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    return v13_rpc_json('v1331_employee_order_review',['p_session_token'=>$session,'p_visit_id'=>$visitId],'');
}
function v1331_page_confirm(string $visitId): void {
    if($visitId===''){echo '<section class="card empty-state"><h3>找不到订单</h3><p>缺少订单编号。</p></section>';return;}
    $detail=v13_is_owner()?v13_owner_visit_detail($visitId):v1331_employee_order_review($visitId);
    if(!$detail){echo '<section class="card empty-state"><h3>找不到订单</h3><p>订单不存在或你没有权限。</p></section>';return;}
    $snap=v1331_build_review_snapshot($detail);
    $returnBoardDate=date('Y-m-d');
    if(($snap['visit_type']??'walk_in')==='appointment' && !empty($snap['scheduled_at'])){
        $scheduledLocal=v1344_local_dt((string)$snap['scheduled_at']);
        if($scheduledLocal) $returnBoardDate=$scheduledLocal->format('Y-m-d');
    }
    $visitRow=is_array($detail['visit']??null)?$detail['visit']:[];
    if(($snap['visit_type']??'walk_in')==='appointment' && empty($visitRow['arrived_at'])){
        ?>
        <div class="page-head wizard-page-head"><div><span class="eyebrow">APPOINTMENT BOOKED · SUPABASE</span><h1>预约已经建立</h1><p><?=e((string)$snap['visit_number'])?> · 预约建立阶段不允许顾客签名。</p></div></div>
        <section class="card empty-state appointment-signature-locked"><h3>顾客到店后才开放签名</h3><p>请到「服务现场」打开这笔预约，顾客真正到店后先点击「顾客已到达」。系统记录到店时间后，才会进入顾客确认与电子签名。</p><a class="btn btn-primary" href="index.php?page=orders&board_date=<?=e($returnBoardDate)?>">返回服务现场 →</a></section>
        <?php return;
    }
    ?>
    <div class="page-head wizard-page-head"><div><span class="eyebrow">CUSTOMER CONFIRMATION · SUPABASE</span><h1>顾客确认与电子签名</h1><p><?=e((string)$snap['visit_number'])?> · 第 4 步，请顾客最后确认项目、人员、时间和金额。</p></div><div class="page-head-actions"><a class="btn btn-light" href="index.php?page=orders&board_date=<?=e($returnBoardDate)?>">稍后处理</a><span class="badge badge-gold">等待顾客签名</span></div></div>
    <?php v1331_visit_wizard_progress(4); ?>
    <div class="confirm-layout">
      <section class="confirm-order">
        <div class="confirm-customer-card"><div class="selected-customer-avatar"><?=e(mb_substr((string)$snap['customer_name'],0,1))?></div><div><span>主要顾客</span><strong><?=e((string)$snap['customer_name'])?></strong><small><?=e((string)$snap['customer_phone'])?> · <?=($snap['visit_type']==='appointment'?'预约':'Walk-in')?><?=!empty($snap['scheduled_at'])?' · '.e(app_date((string)$snap['scheduled_at'],true)):''?></small></div></div>
        <?php foreach($snap['items'] as $item): ?>
          <div class="recipient-block"><div class="recipient-head"><div><span>服务对象</span><strong><?=e((string)$item['recipient'])?></strong></div><span class="badge badge-gray"><?=e((string)$item['category'])?></span></div>
            <div class="order-item"><div><strong><?=e((string)$item['name'])?></strong><small>主理：<?=e(implode('、',$item['primary'])?:'系统安排')?><?=!empty($item['support'])?' · 共同理发师：'.e(implode('、',$item['support'])):''?><?=!empty($item['assistants'])?' · 助理：'.e(implode('、',$item['assistants'])):''?> · 约 <?=(int)$item['minutes']?> 分钟</small></div><strong><?=money($item['amount'])?></strong></div>
          </div>
        <?php endforeach; ?>
        <div class="confirm-total-card"><div><span>预计总时间</span><strong><?=(int)$snap['minutes']?> 分钟</strong></div><div><span>预计总额</span><strong><?=money($snap['total'])?></strong></div></div>
      </section>
      <form class="card form-card signature-card" method="post">
        <input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="confirm_visit_v1331"><input type="hidden" name="visit_id" value="<?=e($visitId)?>"><input type="hidden" name="board_date" value="<?=e($returnBoardDate)?>"><input type="hidden" name="signature_data" id="signature-data">
        <div class="wizard-panel-head compact"><span class="panel-number">04</span><div><h2>顾客签名</h2><p>签名会和这一次订单内容一起保存到 Supabase。</p></div></div>
        <div class="field"><label>确认人姓名</label><input class="input" name="customer_name" value="<?=e((string)$snap['customer_name'])?>" required></div>
        <div class="field"><label>请在下方签名</label><div class="signature-box"><canvas id="signature-pad"></canvas><div class="signature-actions"><span>请使用手指或鼠标签名</span><button class="btn btn-light btn-small" type="button" data-clear-signature>清除签名</button></div></div></div>
        <label class="confirm-checkbox"><input type="checkbox" required><span>我已检查并同意以上顾客资料、服务项目、工作人员、预计时间与金额。</span></label>
        <button class="btn btn-primary btn-block">确认签名并完成订单建立 →</button>
      </form>
    </div>
    <?php
}


function v13_page_new_visit(): void {
    if(v13_is_owner()){
        $services=v13_service_rows(true);
        $employees=v13_employee_rows_owner();
    } else {
        $cat=v13_employee_api('catalog');
        $services=is_array($cat['services']??null)?$cat['services']:[];
        foreach($services as &$sv){$sv['default_price']=$sv['default_price']??$sv['price']??0;$sv['estimated_minutes']=$sv['estimated_minutes']??$sv['minutes']??60;} unset($sv);
        $employees=is_array($cat['employees']??null)?$cat['employees']:[];
    }
    $stylists=array_values(array_filter($employees,static function($e){
        $p=(string)($e['position']??'');
        return !str_contains($p,'前台') && !str_contains($p,'助理') && (($e['employment_status']??'active')==='active');
    }));
    $helpers=array_values(array_filter($employees,static function($e){
        $p=(string)($e['position']??'');
        return !str_contains($p,'前台') && (($e['employment_status']??'active')==='active');
    }));
    $draftKey=v1361062_draft_key();
    ?>
    <div class="page-head wizard-page-head">
      <div><span class="eyebrow">NEW CUSTOMER VISIT · SUPABASE</span><h1>新建顾客订单</h1><p>Walk-in：顾客与项目确认后现场签名；预约：先完成 3 步建立预约，顾客到店并确认「顾客已到达」后才开放签名。</p></div>
      <span class="draft-status"><i></i> <span data-draft-status>新订单草稿</span></span>
    </div>

    <div class="draft-recovery" data-draft-recovery hidden>
      <div><strong>找到尚未提交的自动保存草稿</strong><span data-draft-recovery-time>可恢复上次填写内容</span></div>
      <div><button type="button" class="btn btn-light btn-small" data-discard-draft>舍弃</button><button type="button" class="btn btn-primary btn-small" data-restore-draft>恢复草稿</button></div>
    </div>

    <?php v1331_visit_wizard_progress(1); ?>

    <form method="post" class="card form-card wizard-form" id="visit-wizard" novalidate data-draft-key="<?=e($draftKey)?>" data-editing="0" data-current-status="new">
      <input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="<?=v13_is_owner()?'create_visit_v13':'employee_create_visit_v13'?>">
      <?php if(v13_is_owner()):?><input type="hidden" name="order_request_id" value="<?=e(v13_uuid())?>"><?php endif;?>
      <script type="application/json" id="initial-customer-data">null</script>
      <div class="wizard-error" data-wizard-error hidden></div>

      <section class="wizard-panel active" data-wizard-panel="1">
        <div class="wizard-panel-head"><span class="panel-number">01</span><div><h2>到店方式</h2><p>第一步先决定 Walk-in 或预约。预约才显示日期、时间以及“指定理发师 / 系统分配”。</p></div></div>
        <div class="choice-grid">
          <div class="choice-group"><label class="choice-group-label">到店方式</label><div class="choice-cards">
            <label class="choice-card"><input type="radio" name="visit_type" value="walk_in" checked><span><b>Walk-in</b><small>自动使用当前日期与时间</small></span></label>
            <label class="choice-card"><input type="radio" name="visit_type" value="appointment"><span><b>预约</b><small>选择未来日期与时间</small></span></label>
          </div>
          <div class="appointment-datetime-field appointment-step-one" data-appointment-field hidden>
            <div class="field"><label>预约日期与时间 *</label><input class="input" type="datetime-local" name="appointment_at" data-appointment-input><small class="field-help">预约会保留在员工时间表，不会因为确认到达而消失。</small></div>
            <div class="appointment-preference-block">
              <label class="choice-group-label">预约理发师偏好</label>
              <div class="choice-cards compact-choice-cards">
                <label class="choice-card"><input type="radio" name="appointment_assignment_type" value="system" checked><span><b>系统分配</b><small>不锁定特定理发师</small></span></label>
                <label class="choice-card"><input type="radio" name="appointment_assignment_type" value="specified"><span><b>指定理发师</b><small>预约时先锁定偏好</small></span></label>
              </div>
              <div class="field" data-appointment-stylist-field hidden><label>预约指定理发师 *</label><select class="select appointment-preferred-select" name="appointment_employee_id" data-availability-select><option value="">请选择理发师</option><?php foreach($stylists as $employee): ?><option value="<?=e((string)$employee['id'])?>"><?=e((string)$employee['name'].' · '.(string)($employee['position']??''))?></option><?php endforeach; ?></select><small class="field-help">第二步每个项目仍然可以分别安排主理发师、共同理发师和助理。</small></div>
            </div>
          </div></div>
        </div>
        <div class="step-note"><strong>下一步</strong><span>填写 / 搜索顾客会员资料，再增加一个或多个服务项目和每个项目的工作人员。</span></div>
      </section>

      <section class="wizard-panel" data-wizard-panel="2">
        <div class="wizard-panel-head"><span class="panel-number">02</span><div><h2>顾客与服务项目</h2><p>先搜索已有顾客／会员；没有资料就直接建立新顾客。然后加入服务项目和负责人员。</p></div></div>

        <div class="wizard-section customer-intake-section">
          <div class="wizard-section-title"><div><h3>顾客资料</h3><p>可用姓名、电话号码或会员编号搜索。</p></div><span class="required-chip">姓名＋电话必填</span></div>
          <div class="customer-intake-layout">
            <div class="customer-existing-picker">
              <div class="field-label-row"><label>搜索已有顾客／会员（选填）</label><small>输入至少两个字符</small></div>
              <div class="customer-search-box"><div class="input-shell customer-search-input"><span class="input-icon">⌕</span><input class="input" id="customer-search" type="search" placeholder="姓名、电话号码或会员编号" autocomplete="off"><span class="search-spinner" data-customer-spinner hidden></span></div><input type="hidden" name="customer_id" id="customer-id"><div class="customer-results" id="customer-results" hidden></div></div>
              <div class="selected-customer" id="selected-customer" hidden><div class="selected-customer-avatar" data-selected-initial>客</div><div><strong data-selected-name>—</strong><span data-selected-meta>—</span></div><button type="button" class="btn btn-light btn-small" data-clear-customer>改用新顾客</button></div>
            </div>
            <div class="customer-quick-fields">
              <div class="field"><label>顾客姓名 *</label><input class="input" id="visit-customer-name" name="customer_name" placeholder="第一次到店直接填写姓名" required></div>
              <div class="field"><label>电话号码 *</label><input class="input" id="visit-customer-phone" name="customer_phone" inputmode="tel" placeholder="例如 0123456789" required></div>
              <div class="guest-extra-fields" data-guest-extra-fields>
                <div class="field"><label>性别（选填）</label><select class="select" name="customer_gender"><option value="unspecified">不填写</option><option value="male">男</option><option value="female">女</option></select></div>
                <div class="field"><label>族群（选填）</label><select class="select" name="customer_ethnicity"><option value="">不填写</option><option value="华人">华人</option><option value="马来人">马来人</option><option value="印度人">印度人</option><option value="其他">其他</option></select></div>
                <div class="field"><label>年龄（选填）</label><input class="input" type="number" min="0" max="120" name="customer_age"></div>
                <div class="field"><label>出生日期（选填）</label><input class="input" type="date" name="customer_birth_date"></div>
                <div class="field span-2"><label>第一次到店来源（选填）</label><input class="input" name="customer_acquisition_platform" list="customer-source-options" placeholder="例如 Google / Facebook / 朋友介绍 / 路过门店"><datalist id="customer-source-options"><option value="Google Search"><option value="Facebook"><option value="Instagram"><option value="TikTok"><option value="小红书"><option value="朋友介绍"><option value="WhatsApp"><option value="路过门店"><option value="其他"></datalist><small class="field-help">用于经营分析里的新客来源统计；选择已有顾客时不会覆盖原来源。</small></div>
              </div>
            </div>
          </div>
          <div class="customer-intake-note"><strong>会员搜索</strong><span>找到会员后会自动带入姓名和电话；没找到就直接建立非会员顾客，不会卡住订单。</span></div>
        </div>

        <div class="wizard-section">
          <div class="wizard-section-title"><div><h3>同行服务对象</h3><p>需要时可加入孩子、家人或朋友，并为他们分别安排项目。</p></div><button type="button" class="btn btn-light" data-add-recipient>＋ 增加同行者</button></div>
          <div class="recipient-editor-list" id="recipient-rows"></div>
          <template id="recipient-template"><?php v1331_recipient_editor_row(); ?></template>
          <div class="empty-inline" data-recipient-empty>目前只有主要顾客本人。需要时点击“增加同行者”。</div>
        </div>

        <div class="wizard-section">
          <div class="wizard-section-title"><div><h3>理发师安排方式</h3><p>在这里决定顾客是否指定理发师；选择“顾客指定”后，每个项目都能独立选择主理发师、共同理发师与助理。</p></div></div>
          <div class="choice-cards">
            <label class="choice-card"><input type="radio" name="assignment_type" value="specified" checked><span><b>顾客指定</b><small>每个项目自己选择负责人员</small></span></label>
            <label class="choice-card"><input type="radio" name="assignment_type" value="system"><span><b>系统安排</b><small>主理发师由系统安排，仍可加入协作人员</small></span></label>
          </div>
        </div>

        <div class="wizard-section">
          <div class="wizard-section-title"><div><h3>服务项目与人员</h3><p>一个项目可以有多位理发师与多位助理，并且每位工作人员都能填写 Contribution %；项目总和必须为 100%。</p></div><button type="button" class="btn btn-light" data-add-service>＋ 添加项目</button></div>
          <div id="service-rows"><?php v1331_service_row($services,$stylists,$helpers); ?></div>
          <template id="service-template"><?php v1331_service_row($services,$stylists,$helpers); ?></template>
          <div class="order-total-bar"><div><span>预计总时间</span><strong data-order-minutes>0 分钟</strong></div><div><span>预计总额</span><strong data-order-total>RM 0.00</strong></div></div>
        </div>
      </section>

      <section class="wizard-panel" data-wizard-panel="3">
        <div class="wizard-panel-head"><span class="panel-number">03</span><div><h2>顾客确认订单</h2><p>第三步确认全部资料。Walk-in 会接着现场签名；预约只建立预约，不会在预约阶段要求顾客签名。</p></div></div>
        <div class="review-grid"><div class="review-card"><span>顾客</span><strong data-review-customer>尚未选择</strong><small data-review-customer-meta>—</small></div><div class="review-card"><span>到店方式</span><strong data-review-visit-type>—</strong><small data-review-assignment>—</small></div><div class="review-card"><span>预计总时间</span><strong data-review-minutes>0 分钟</strong><small>以项目预计时间计算</small></div><div class="review-card emphasis"><span>预计总额</span><strong data-review-total>RM 0.00</strong><small>仍可返回修改</small></div></div>
        <div class="review-list" data-review-items></div>
        <div class="step-note important" data-review-flow-note><strong data-review-flow-title>下一步</strong><span data-review-flow-text>Walk-in 建立后进入现场签名；预约建立后直接回到服务现场，等顾客到店后才开放签名。</span></div>
      </section>

      <div class="wizard-actions"><button type="button" class="btn btn-light" data-wizard-prev hidden>← 上一步</button><div class="wizard-actions-right"><span class="wizard-step-counter" data-step-counter>第 1 / 4 步</span><button type="button" class="btn btn-primary" data-wizard-next>下一步 →</button><button type="submit" class="btn btn-primary" data-wizard-submit hidden data-default-label="建立订单并进入签名 →">建立订单并进入签名 →</button></div></div>
    </form>
    <?php
}

function v1344_board_date(?string $value=null): string {
    $value=trim((string)$value);
    if($value!=='' && preg_match('/^\d{4}-\d{2}-\d{2}$/',$value)) return $value;
    return (new DateTimeImmutable('now',new DateTimeZone('Asia/Kuala_Lumpur')))->format('Y-m-d');
}
function v1344_local_dt(?string $value): ?DateTimeImmutable {
    $value=trim((string)$value); if($value==='') return null;
    try { return (new DateTimeImmutable($value))->setTimezone(new DateTimeZone('Asia/Kuala_Lumpur')); }
    catch(Throwable $e){ return null; }
}
function v1344_board_status_meta(string $status): array {
    return match($status){
        'booked'=>['class'=>'scheduled','label'=>'预约 / 待到店'],
        'arrived'=>['class'=>'scheduled','label'=>'已到店 / 待确认'],
        'waiting'=>['class'=>'scheduled','label'=>'等候开始'],
        'draft'=>['class'=>'scheduled','label'=>'草稿'],
        'in_service'=>['class'=>'progress','label'=>'服务中'],
        'paused'=>['class'=>'progress','label'=>'暂停'],
        'ready_for_checkout'=>['class'=>'progress','label'=>'待结账'],
        'completed'=>['class'=>'done','label'=>'已完成 / 已结账'],
        'cancelled'=>['class'=>'cancelled','label'=>'已取消'],
        'no_show'=>['class'=>'cancelled','label'=>'未到'],
        default=>['class'=>'scheduled','label'=>v13_status_label($status)]
    };
}
function v135_rpc_missing(Throwable $e,string $rpc=''): bool {
    $m=strtolower($e->getMessage());
    if(!str_contains($m,'pgrst202') && !str_contains($m,'could not find the function') && !str_contains($m,'schema cache')) return false;
    return $rpc==='' || str_contains($m,strtolower($rpc));
}
function v135_in_filter(array $ids): string {
    $ids=array_values(array_unique(array_filter(array_map(static fn($v)=>trim((string)$v),$ids))));
    return '('.implode(',',array_map('rawurlencode',$ids)).')';
}
function v135_owner_board_snapshot_rest(string $boardDate): array {
    $org=v13_org_uuid(); $store=v13_store_uuid();
    if($org===''||$store==='') throw new RuntimeException('当前 Organization / Store 无效。');

    // This compatibility path deliberately uses select=* so a harmless schema drift
    // does not make the whole Service Board disappear because of one missing optional column.
    $employeeRows=v13_owner_rows('employees','select=*&organization_id=eq.'.rawurlencode($org).'&employment_status=eq.active&limit=2000');
    $links=v13_owner_rows('employee_stores','select=*&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&status=eq.active&limit=2000');
    $allowed=[]; foreach($links as $x){$id=trim((string)($x['employee_id']??''));if($id!=='')$allowed[$id]=true;}
    $employees=[]; foreach($employeeRows as $e1){$id=trim((string)($e1['id']??''));if($id!==''&&isset($allowed[$id]))$employees[]=$e1;}
    usort($employees,static fn($a,$b)=>strcmp((string)($a['name']??''),(string)($b['name']??'')));

    $tz=new DateTimeZone('Asia/Kuala_Lumpur');
    $localStart=new DateTimeImmutable($boardDate.' 00:00:00',$tz); $localEnd=$localStart->modify('+1 day');
    $utc=new DateTimeZone('UTC'); $startUtc=$localStart->setTimezone($utc)->format('Y-m-d\\TH:i:s\\Z'); $endUtc=$localEnd->setTimezone($utc)->format('Y-m-d\\TH:i:s\\Z');
    $base='select=*&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store);
    $a=v13_owner_rows('visits',$base.'&scheduled_at=gte.'.rawurlencode($startUtc).'&scheduled_at=lt.'.rawurlencode($endUtc).'&limit=5000');
    $b=v13_owner_rows('visits',$base.'&created_at=gte.'.rawurlencode($startUtc).'&created_at=lt.'.rawurlencode($endUtc).'&limit=5000');
    $byVisit=[]; foreach(array_merge($a,$b) as $v){$id=trim((string)($v['id']??''));if($id==='')continue;$dt=v1344_local_dt((string)($v['scheduled_at']??$v['created_at']??''));if($dt&&$dt->format('Y-m-d')===$boardDate)$byVisit[$id]=$v;}
    $visitIds=array_keys($byVisit); if(!$visitIds) return ['board_date'=>$boardDate,'can_see_all'=>true,'employees'=>$employees,'visits'=>[],'compatibility_mode'=>true];
    $in=v135_in_filter($visitIds);
    $recipients=v13_owner_rows('visit_recipients','select=*&organization_id=eq.'.rawurlencode($org).'&visit_id=in.'.$in.'&limit=10000');
    $items=v13_owner_rows('visit_service_items','select=*&organization_id=eq.'.rawurlencode($org).'&visit_id=in.'.$in.'&limit=10000');
    $itemIds=[]; foreach($items as $it){$id=trim((string)($it['id']??''));if($id!=='')$itemIds[]=$id;}
    $workers=[]; if($itemIds){$workers=v13_owner_rows('visit_service_workers','select=*&organization_id=eq.'.rawurlencode($org).'&service_item_id=in.'.v135_in_filter($itemIds).'&status=eq.active&limit=20000');}
    $payments=[]; try{$payments=v13_owner_rows('payments','select=*&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&visit_id=in.'.$in.'&limit=10000');}catch(Throwable $ignore){}
    $productItems=[]; try{$productItems=v13_owner_rows('visit_product_items','select=*&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&visit_id=in.'.$in.'&limit=10000');}catch(Throwable $ignore){}

    $empName=[]; foreach($employeeRows as $e1)$empName[(string)($e1['id']??'')]=(string)($e1['name']??'员工');
    $recBy=[]; foreach($recipients as $r)$recBy[(string)($r['visit_id']??'')][]=$r;
    $itemBy=[]; foreach($items as $it)$itemBy[(string)($it['visit_id']??'')][]=$it;
    $workerByItem=[]; foreach($workers as $w)$workerByItem[(string)($w['service_item_id']??'')][]=$w;
    $payBy=[]; foreach($payments as $x)$payBy[(string)($x['visit_id']??'')][]=$x;
    $prodBy=[]; foreach($productItems as $x)$prodBy[(string)($x['visit_id']??'')][]=$x;

    $visits=[];
    foreach($byVisit as $id=>$v){
        $rr=$recBy[$id]??[]; $primary=$rr[0]??[]; foreach($rr as $r)if(($r['recipient_type']??'')==='primary'){$primary=$r;break;}
        $ii=array_values(array_filter($itemBy[$id]??[],static fn($x)=>(string)($x['status']??'')!=='cancelled'));
        $serviceNames=[];$allWorkers=[];$mins=0;$serviceTotal=0.0;
        foreach($ii as $it){$serviceNames[]=(string)($it['service_name_snapshot']??'服务');$mins+=max(1,(int)($it['estimated_minutes_snapshot']??30));$serviceTotal+=(float)($it['line_total']??0);foreach($workerByItem[(string)($it['id']??'')]??[] as $w){$eid=(string)($w['employee_id']??'');$allWorkers[$eid.'|'.(string)($w['worker_role']??'')]=['employee_id'=>$eid,'employee_name'=>$empName[$eid]??'员工','worker_role'=>(string)($w['worker_role']??''),'contribution_percent'=>(float)($w['contribution_percent']??0)];}}
        $prodTotal=0.0;foreach($prodBy[$id]??[] as $pi)if(($pi['status']??'active')==='active')$prodTotal+=(float)($pi['line_total']??((float)($pi['unit_price']??0)*(float)($pi['quantity']??1)));
        $pp=$payBy[$id]??[]; usort($pp,static fn($x,$y)=>strcmp((string)($y['paid_at']??''),(string)($x['paid_at']??''))); $latest=$pp[0]??[];
        $sort=(string)($v['scheduled_at']??''); if($sort==='')$sort=(string)($v['created_at']??'');
        $visits[]=[
          'id'=>$id,'visit_number'=>(string)($v['visit_number']??''),'visit_type'=>(string)($v['visit_type']??'walk_in'),'status'=>(string)($v['status']??'waiting'),
          'scheduled_at'=>$v['scheduled_at']??null,'arrived_at'=>$v['arrived_at']??null,'started_at'=>$v['started_at']??null,'service_completed_at'=>$v['service_completed_at']??null,'checked_out_at'=>$v['checked_out_at']??null,'created_at'=>$v['created_at']??null,'sort_at'=>$sort,
          'customer_name'=>(string)($primary['name_snapshot']??'顾客'),'customer_phone'=>(string)($primary['phone_snapshot']??''),'member_number'=>null,
          'services'=>$serviceNames?implode('、',array_values(array_unique($serviceNames))):'尚未加入项目','service_count'=>count($ii),'estimated_minutes'=>max(30,$mins),
          'workers'=>array_values($allWorkers),'employees'=>$allWorkers?implode('、',array_values(array_unique(array_map(static fn($x)=>(string)$x['employee_name'],array_values($allWorkers))))):'待分配',
          'service_total'=>$serviceTotal,'product_total'=>$prodTotal,'total_amount'=>$latest['grand_total']??($serviceTotal+$prodTotal),'payment_status'=>(string)($latest['status']??'unpaid')
        ];
    }
    usort($visits,static fn($x,$y)=>strcmp((string)($x['sort_at']??''),(string)($y['sort_at']??'')));
    return ['board_date'=>$boardDate,'can_see_all'=>true,'employees'=>$employees,'visits'=>$visits,'compatibility_mode'=>true];
}
function v135_employee_board_snapshot_fallback(string $boardDate): array {
    $d=v13_employee_api('dashboard'); $ctx=is_array($d['context']??null)?$d['context']:[];
    $eId=(string)($ctx['employee_id']??''); $role=(string)($ctx['employee_role']??'staff');
    $cat=v13_employee_api('catalog'); $allE=is_array($cat['employees']??null)?$cat['employees']:[];
    $employees=[]; foreach($allE as $e1){if(in_array($role,['manager','receptionist'],true)||((string)($e1['id']??'')===$eId))$employees[]=$e1;}
    $raw=v13_employee_api('visits'); if(!array_is_list($raw))$raw=[]; $visits=[];
    foreach($raw as $v){$dt=v1344_local_dt((string)($v['sort_at']??$v['scheduled_at']??''));if(!$dt||$dt->format('Y-m-d')!==$boardDate)continue;$visits[]=['id'=>(string)($v['id']??''),'visit_number'=>(string)($v['visit_number']??''),'visit_type'=>(string)($v['visit_type']??'walk_in'),'status'=>(string)($v['status']??'waiting'),'scheduled_at'=>$v['scheduled_at']??null,'arrived_at'=>$v['arrived_at']??null,'started_at'=>$v['started_at']??null,'service_completed_at'=>$v['service_completed_at']??null,'created_at'=>$v['sort_at']??null,'sort_at'=>$v['sort_at']??null,'customer_name'=>(string)($v['customers']??'顾客'),'customer_phone'=>'','services'=>'服务项目','service_count'=>1,'estimated_minutes'=>60,'workers'=>$eId!==''?[['employee_id'=>$eId,'employee_name'=>(string)(user()['employee_name']??'员工'),'worker_role'=>'primary','contribution_percent'=>100]]:[],'employees'=>(string)(user()['employee_name']??'员工'),'service_total'=>(float)($v['total']??0),'product_total'=>0,'total_amount'=>(float)($v['total']??0),'payment_status'=>'unpaid'];}
    return ['board_date'=>$boardDate,'can_see_all'=>in_array($role,['manager','receptionist'],true),'employees'=>$employees,'visits'=>$visits,'compatibility_mode'=>true];
}
function v1344_board_snapshot(string $boardDate): array {
    if(v13_is_owner()){
        try { return v13_rpc_json('v1344_owner_service_board',['p_store_id'=>v13_store_uuid(),'p_board_date'=>$boardDate],v13_owner_token_required_all()); }
        catch(Throwable $e){ if(!v135_rpc_missing($e,'v1344_owner_service_board')) throw $e; return v135_owner_board_snapshot_rest($boardDate); }
    }
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($session==='') throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    try { return v13_rpc_json('v1344_employee_service_board',['p_session_token'=>$session,'p_board_date'=>$boardDate],''); }
    catch(Throwable $e){ if(!v135_rpc_missing($e,'v1344_employee_service_board')) throw $e; return v135_employee_board_snapshot_fallback($boardDate); }
}
function v13696_service_board_signature(array $snapshot): string {
    $visitRows=[];
    foreach((array)($snapshot['visits']??[]) as $visit){
        $visitRows[]=[
            'id'=>(string)($visit['id']??''),
            'status'=>(string)($visit['status']??''),
            'scheduled_at'=>(string)($visit['scheduled_at']??''),
            'arrived_at'=>(string)($visit['arrived_at']??''),
            'started_at'=>(string)($visit['started_at']??''),
            'service_completed_at'=>(string)($visit['service_completed_at']??''),
            'checked_out_at'=>(string)($visit['checked_out_at']??''),
            'services'=>(string)($visit['services']??''),
            'employees'=>(string)($visit['employees']??''),
            'total_amount'=>(string)($visit['total_amount']??''),
            'payment_status'=>(string)($visit['payment_status']??''),
        ];
    }
    usort($visitRows,static fn($a,$b)=>strcmp($a['id'],$b['id']));
    $employeeRows=[];
    foreach((array)($snapshot['employees']??[]) as $employee){
        $employeeRows[]=[
            'id'=>(string)($employee['id']??''),
            'availability_status'=>(string)($employee['availability_status']??''),
            'is_on_duty'=>!empty($employee['is_on_duty']),
            'employment_status'=>(string)($employee['employment_status']??''),
        ];
    }
    usort($employeeRows,static fn($a,$b)=>strcmp($a['id'],$b['id']));
    return hash('sha256',json_encode([
        'board_date'=>(string)($snapshot['board_date']??''),
        'visits'=>$visitRows,
        'employees'=>$employeeRows,
    ],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
}
function v13696_service_board_live_payload(string $boardDate): array {
    $snapshot=v1344_board_snapshot($boardDate);
    return [
        'ok'=>true,
        'board_date'=>$boardDate,
        'signature'=>v13696_service_board_signature($snapshot),
        'updated_at'=>(new DateTimeImmutable('now',new DateTimeZone('Asia/Kuala_Lumpur')))->format('H:i:s'),
    ];
}

function v1344_board_block_geometry(array $visit): ?array {
    $dt=v1344_local_dt((string)($visit['sort_at']??$visit['scheduled_at']??$visit['created_at']??''));
    if(!$dt) return null;
    $start=((int)$dt->format('H'))*60+(int)$dt->format('i');
    $base=9*60; $end=24*60; $duration=max(30,(int)($visit['estimated_minutes']??30));
    if($start>=$end || $start+$duration<=$base) return null;
    $displayStart=max($base,$start); $displayEnd=min($end,$start+$duration);
    $left=(($displayStart-$base)/($end-$base))*100;
    $width=max(1.6,(($displayEnd-$displayStart)/($end-$base))*100);
    $finish=$dt->modify('+'.$duration.' minutes');
    return ['left'=>$left,'width'=>$width,'time'=>$dt->format('H:i').' - '.$finish->format('H:i')];
}
function v1344_payment_label(string $status): string {
    return match($status){'paid'=>'已付款','partial'=>'部分付款','refunded'=>'已退款','void'=>'已作废',default=>'未付款'};
}
function v1344_worker_role_label(string $role): string {
    return match($role){'primary'=>'主理发师','support'=>'共同理发师','assistant'=>'助理',default=>$role};
}
function v1344_service_board_detail(string $visitId): array {
    if(v13_is_owner()) return v13_owner_visit_detail($visitId);
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($session==='') throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    try { return v13_rpc_json('v1344_employee_visit_detail',['p_session_token'=>$session,'p_visit_id'=>$visitId],''); }
    catch(Throwable $e){
        if(!v135_rpc_missing($e,'v1344_employee_visit_detail')) throw $e;
        $fallback=v13_employee_api('visit_detail',['visit_id'=>$visitId]);
        if(!is_array($fallback)) return [];
        $fallback['product_items']=$fallback['product_items']??[]; $fallback['payments']=$fallback['payments']??[];
        return $fallback;
    }
}
function v1344_status_form(string $visitId,string $status,string $label,string $boardDate,string $class='btn-primary'): string {
    $action=v13_is_owner()?'visit_status_v13':'board_employee_status_v1344';
    return '<form method="post" class="service-board-inline-action-form"><input type="hidden" name="csrf" value="'.e(csrf_token()).'"><input type="hidden" name="action" value="'.$action.'"><input type="hidden" name="visit_id" value="'.e($visitId).'"><input type="hidden" name="status" value="'.e($status).'"><input type="hidden" name="board_date" value="'.e($boardDate).'"><button class="btn '.e($class).'" type="submit">'.e($label).'</button></form>';
}
function v1344_service_board_modal_content(string $visitId,string $boardDate): string {
    $detail=v1344_service_board_detail($visitId);
    $visit=is_array($detail['visit']??null)?$detail['visit']:[];
    if(!$visit) return '<div class="commission-modal-error"><strong>找不到这笔预约／订单</strong><span>它可能已取消、被删除，或你没有权限查看。</span><button class="btn btn-light" type="button" data-service-board-modal-close>关闭</button></div>';
    $recipients=is_array($detail['recipients']??null)?$detail['recipients']:[];
    $items=is_array($detail['items']??null)?$detail['items']:[];
    $topWorkers=is_array($detail['workers']??null)?$detail['workers']:[];
    $productItems=is_array($detail['product_items']??null)?$detail['product_items']:[];
    $payments=is_array($detail['payments']??null)?$detail['payments']:[];
    $confirmations=is_array($detail['confirmations']??null)?$detail['confirmations']:[];
    $primary=$recipients[0]??[];
    foreach($recipients as $r){ if(($r['recipient_type']??'')==='primary'){ $primary=$r; break; } }
    $customer=(string)($primary['name_snapshot']??'顾客'); $phone=(string)($primary['phone_snapshot']??'');
    $employeeMap=[]; if(v13_is_owner()) foreach(v13_employee_rows_owner() as $e) $employeeMap[(string)($e['id']??'')]=(string)($e['name']??'员工');
    $serviceTotal=0.0; $serviceNames=[]; $workerNames=[];
    foreach($items as $it){
        if(($it['status']??'')==='cancelled') continue;
        $serviceTotal+=(float)($it['line_total']??0); $serviceNames[]=(string)($it['service_name_snapshot']??$it['name']??'服务');
        $workers=is_array($it['workers']??null)?$it['workers']:[];
        foreach($workers as $w) if(!empty($w['employee_name'])) $workerNames[]=(string)$w['employee_name'];
    }
    foreach($topWorkers as $w){ $name=trim((string)($w['employee_name']??($employeeMap[(string)($w['employee_id']??'')]??''))); if($name!=='')$workerNames[]=$name; }
    $serviceNames=array_values(array_unique(array_filter($serviceNames))); $workerNames=array_values(array_unique(array_filter($workerNames)));
    $productTotal=0.0; foreach($productItems as $pi) $productTotal+=(float)($pi['line_total']??0);
    $payment=$payments[0]??[]; $total=(float)($payment['grand_total']??($serviceTotal+$productTotal));
    $paymentStatus=(string)($payment['status']??'unpaid');
    $meta=v1344_board_status_meta((string)($visit['status']??''));
    $timeBase=(string)(($visit['visit_type']??'walk_in')==='appointment' ? ($visit['scheduled_at']??$visit['created_at']??'') : ($visit['created_at']??''));
    $dt=v1344_local_dt($timeBase); $timeText=$dt?$dt->format('d/m/Y H:i'):'—';
    $canManage=v13_is_owner()||has_permission('orders.manage');
    $canCheckout=v13_is_owner()||has_permission('checkout.manage');
    $isEmployee=!v13_is_owner();
    $assignedToMe=false;
    if($isEmployee){ foreach($items as $it){ if(!empty($it['assigned_to_me'])){$assignedToMe=true;break;} } }
    $canArrive=$canManage||$assignedToMe;
    ob_start(); ?>
    <div class="service-board-modal-inner">
      <header class="member-modal-head"><div><span class="eyebrow">SERVICE SLOT · SUPABASE</span><h2><?=e((string)($visit['visit_number']??'订单'))?></h2><p><?=e($customer)?><?=$phone!==''?' · '.e($phone):''?></p></div><button class="commission-modal-close" type="button" data-service-board-modal-close>×</button></header>
      <?php if(v13_is_owner()&&($visit['status']??'')==='completed'):?><p><a class="btn btn-light btn-small" href="<?=e(v1361062_receipt_url($visitId))?>">查看收据与退款</a></p><?php endif;?>
      <section class="service-board-modal-summary">
        <div><span>预约 / 到店时间</span><strong><?=e($timeText)?></strong></div>
        <div><span>当前状态</span><strong class="service-board-status-text status-<?=e($meta['class'])?>"><?=e($meta['label'])?></strong></div>
        <div><span>项目</span><strong><?=e($serviceNames?implode('、',$serviceNames):'尚未加入项目')?></strong></div>
        <div><span>员工</span><strong><?=e($workerNames?implode('、',$workerNames):'待分配')?></strong></div>
        <div><span>订单金额</span><strong><?=money($total)?></strong></div>
        <div><span>付款状态</span><strong><?=e(v1344_payment_label($paymentStatus))?></strong></div>
      </section>

      <?php $confirmation=$confirmations[0]??null; if(is_array($confirmation)): $sig=(string)($confirmation['signature_data']??''); $signedAt=(string)($confirmation['signed_at']??''); $snap=is_array($confirmation['order_snapshot']??null)?$confirmation['order_snapshot']:[]; ?>
      <section class="service-board-project-list v1361052-order-evidence"><div class="card-kicker">CUSTOMER CONFIRMATION EVIDENCE</div><article class="v1361052-evidence-card"><div class="v1361052-evidence-meta"><div><span>签名顾客</span><strong><?=e((string)($confirmation['customer_name']??$customer))?></strong></div><div><span>签名时间</span><strong><?=e($signedAt!==''?app_date($signedAt,true):'—')?></strong></div><div><span>确认订单</span><strong><?=e((string)($visit['visit_number']??''))?></strong></div><div><span>当时订单金额</span><strong><?=money($snap['total_amount']??$snap['grand_total']??$total)?></strong></div></div><?php if(str_starts_with($sig,'data:image/')):?><div class="v1361052-signature-proof"><span>顾客电子签名</span><img src="<?=e($sig)?>" alt="Customer signature for <?=e((string)($visit['visit_number']??'order'))?>"></div><?php else:?><div class="alert alert-warning">这笔订单有确认记录，但签名图片格式无法直接显示。</div><?php endif;?><small class="muted">此记录来自订单确认时保存的签名与订单快照，用于之后核对顾客当时确认的项目、人员与金额。</small></article></section>
      <?php else: ?><section class="service-board-project-list v1361052-order-evidence"><div class="card-kicker">CUSTOMER CONFIRMATION EVIDENCE</div><div class="alert alert-warning">这笔历史订单没有找到顾客确认签名记录。</div></section><?php endif; ?>

      <?php if($items): ?><section class="service-board-project-list"><div class="card-kicker">SERVICE ITEMS</div><?php foreach($items as $it): if(($it['status']??'')==='cancelled')continue; $iWorkers=is_array($it['workers']??null)?$it['workers']:[]; ?><article class="service-board-project-row"><div><strong><?=e((string)($it['service_name_snapshot']??$it['name']??'服务'))?></strong><small><?=money($it['line_total']??0)?> · <?=intval($it['estimated_minutes_snapshot']??30)?> 分钟</small></div><div class="service-board-project-workers"><?php if($iWorkers): foreach($iWorkers as $w): ?><span><?=e((string)($w['employee_name']??($employeeMap[(string)($w['employee_id']??'')]??'员工')))?> · <?=e(v1344_worker_role_label((string)($w['worker_role']??'')))?> <?=number_format((float)($w['contribution_percent']??0),0)?>%</span><?php endforeach; else: ?><span>待分配</span><?php endif; ?></div><?php if($isEmployee && in_array((string)($visit['status']??''),['waiting','in_service','paused','ready_for_checkout'],true) && !empty($it['assigned_to_me']) && empty($it['signed_by_me'])): ?><button class="btn btn-light btn-small" type="button" data-sign-open data-service-item-id="<?=e((string)$it['id'])?>" data-service-name="<?=e((string)($it['service_name_snapshot']??$it['name']??'服务'))?>">顾客项目签名</button><?php endif; ?></article><?php endforeach; ?></section><?php endif; ?>

      <?php if($productItems): ?><section class="service-board-project-list service-board-product-items"><div class="card-kicker">PRODUCT ITEMS</div><?php foreach($productItems as $pi): if(($pi['status']??'active')==='cancelled')continue; $pQty=(float)($pi['quantity']??1);$pUnit=(float)($pi['unit_price']??0);$pLine=(float)($pi['line_total']??($pQty*$pUnit)); ?><article class="service-board-project-row service-board-product-row"><div><strong><?=e((string)($pi['product_name_snapshot']??'销售产品'))?></strong><small><?=e((string)($pi['sku_snapshot']??''))?><?=$pi['sku_snapshot']??''?' · ':''?><?=number_format($pQty,2)?> × <?=money($pUnit)?></small></div><div class="service-board-product-line-actions"><div class="service-board-product-line-total"><span>产品金额</span><strong><?=money($pLine)?></strong><?php $sellerId=(string)($pi['salesperson_employee_id']??''); if($sellerId!==''): ?><small class="service-board-product-seller">销售员工：<?=e((string)($employeeMap[$sellerId]??'员工'))?></small><?php else: ?><small class="service-board-product-seller muted">销售员工：未指定</small><?php endif; ?></div><?php if(v13_is_owner() && !in_array((string)($visit['status']??''),['completed','checked_out','cancelled','no_show'],true)): ?><form method="post" class="service-board-remove-product-form" onsubmit="return confirm('确定从这张订单移除 <?=e(addslashes((string)($pi['product_name_snapshot']??'这个产品')))?>？');"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="remove_visit_product_v13"><input type="hidden" name="visit_id" value="<?=e($visitId)?>"><input type="hidden" name="product_item_id" value="<?=e((string)$pi['id'])?>"><input type="hidden" name="board_date" value="<?=e($boardDate)?>"><input type="hidden" name="return_page" value="orders"><button class="btn btn-danger-soft btn-small" type="submit">移除</button></form><?php endif; ?></div></article><?php endforeach; ?></section><?php endif; ?>

      <?php if(v13_is_owner() && !in_array((string)($visit['status']??''),['completed','cancelled','no_show'],true)): $productCategories=function_exists('v1353_product_categories')?v1353_product_categories(true):[]; ?>
      <section class="service-board-addon-panel v1353-service-product-addon"><div><strong>待结账追加产品</strong><small>先选择分类，再搜索该分类的销售产品。加入后会马上显示在上方 PRODUCT ITEMS；库存只在付款成功后正式扣减。</small></div><form method="post" class="service-board-product-form v1353-product-search-form" data-v1353-product-purchase><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="add_visit_product_v13"><input type="hidden" name="visit_id" value="<?=e($visitId)?>"><input type="hidden" name="board_date" value="<?=e($boardDate)?>"><input type="hidden" name="return_page" value="orders"><input type="hidden" name="product_id" data-product-id><div class="field"><label>产品分类</label><select class="select" data-product-category required><option value="">先选择产品分类</option><?php foreach($productCategories as $cat): ?><option value="<?=e((string)$cat['id'])?>"><?=e((string)$cat['name'])?></option><?php endforeach; ?></select></div><div class="field product-search-field"><label>搜索销售产品</label><input class="input" type="search" data-product-search placeholder="输入名称 / SKU / Barcode；或选分类后直接查看" autocomplete="off"><div class="product-search-results" data-product-results hidden></div></div><div class="selected-product-card" data-selected-product hidden><div class="product-search-thumb"><img data-selected-product-image hidden alt=""><b data-selected-product-placeholder>P</b></div><div><strong data-selected-product-name></strong><small data-selected-product-stock></small><small data-selected-product-description></small></div><strong data-selected-product-price></strong></div><div class="field"><label>产品销售员工</label><select class="select" name="salesperson_employee_id"><option value="">未指定 / 柜台销售</option><?php foreach(v13_employee_rows_owner() as $seller): if((string)($seller['employment_status']??'active')!=='active')continue; if(isset($seller['account_status']) && (string)$seller['account_status']!=='active')continue; ?><option value="<?=e((string)$seller['id'])?>"><?=e((string)($seller['name']??'员工'))?></option><?php endforeach; ?></select><small class="muted">这笔产品销售会计入所选员工的产品业绩与产品抽成。</small></div><div class="v1353-product-add-actions"><div class="field"><label>数量</label><input class="input" type="number" name="quantity" min="0.01" step="0.01" value="1" data-product-quantity></div><div class="field"><label>预计产品金额</label><input class="input" type="text" value="RM 0.00" readonly data-product-total></div><button class="btn btn-light" type="submit">加入订单</button></div></form></section>
      <?php endif; ?>

      <div class="service-board-modal-footer">
      <?php $status=(string)($visit['status']??''); ?>
      <?php if($status==='booked'): ?>
        <?php if($canArrive): ?><div class="order-action-pair"><form method="post" class="service-board-inline-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="board_arrive_v1344"><input type="hidden" name="visit_id" value="<?=e($visitId)?>"><input type="hidden" name="board_date" value="<?=e($boardDate)?>"><label class="phone-confirm-check"><input type="checkbox" name="phone_confirmed" value="1" required><span>已核对顾客手机号<?=$phone!==''?' · '.e($phone):''?></span></label><button class="btn btn-primary" type="submit">顾客已到达 →</button></form><?php if(v13_is_owner()): ?><?=v1344_status_form($visitId,'cancelled','取消预约',$boardDate,'btn-light')?><?php endif; ?></div><?php else: ?><div class="order-awaiting-checkout"><span>预约已排入时间表</span><strong>等待负责员工 / 柜台确认顾客到店</strong></div><?php endif; ?>
      <?php elseif($status==='arrived'): ?>
        <div class="order-awaiting-signature"><span>顾客已到店</span><strong>下一步：顾客确认订单并签名</strong><a class="btn btn-primary btn-block" href="index.php?page=confirm&id=<?=e($visitId)?>">进入顾客签名 →</a></div>
      <?php elseif($status==='waiting'): ?>
        <?=v1344_status_form($visitId,'in_service','开始服务',$boardDate,'btn-primary btn-block')?>
      <?php elseif($status==='in_service'): ?>
        <div class="order-action-pair"><?=v1344_status_form($visitId,'paused','暂停服务',$boardDate,'btn-light')?><?=v1344_status_form($visitId,'ready_for_checkout','服务完成，通知柜台',$boardDate,'btn-primary')?></div>
      <?php elseif($status==='paused'): ?>
        <div class="order-action-pair"><?=v1344_status_form($visitId,'in_service','继续服务',$boardDate,'btn-primary')?><?=v1344_status_form($visitId,'ready_for_checkout','完成并通知柜台',$boardDate,'btn-light')?></div>
      <?php elseif($status==='ready_for_checkout'): ?>
        <?php if($canCheckout): ?><form method="post" class="service-board-checkout-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="checkout_v13"><input type="hidden" name="visit_id" value="<?=e($visitId)?>"><input type="hidden" name="board_date" value="<?=e($boardDate)?>"><select class="select" name="payment_method"><option value="cash">现金</option><option value="card">Card</option><option value="ewallet">E-Wallet</option><option value="bank_transfer">Bank Transfer</option><option value="member_wallet">Member Wallet</option><option value="other">Other</option></select><input class="input" type="number" step="0.01" min="0" name="amount" value="<?=e(number_format($total,2,'.',''))?>" required><input class="input" type="number" step="0.01" min="0" name="discount_total" value="0" placeholder="折扣"><input class="input" type="number" step="0.01" min="0" name="tax_total" value="0" placeholder="税"><button class="btn btn-primary" type="submit">确认结账</button></form><?php else: ?><div class="order-awaiting-checkout"><span>已通知柜台</span><strong>等待前台收款结账</strong></div><?php endif; ?>
      <?php elseif($status==='completed'): ?><span class="order-finished-note">这笔订单已经完成 / 结账。</span>
      <?php elseif(in_array($status,['cancelled','no_show'],true)): ?><span class="order-finished-note"><?=e($meta['label'])?>，记录仍保留在 ALL ORDERS。</span>
      <?php else: ?><span class="order-finished-note">当前状态：<?=e($meta['label'])?></span><?php endif; ?>
      </div>
    </div>
    <?php return (string)ob_get_clean();
}
function v1344_render_project_signature_modal(): void {
    if(v13_is_owner()) return; ?>
    <div class="commission-modal project-signature-modal" id="sign-modal" hidden aria-hidden="true">
      <button class="commission-modal-backdrop" type="button" data-sign-close aria-label="关闭签名"></button>
      <section class="commission-modal-dialog project-signature-dialog" role="dialog" aria-modal="true" aria-labelledby="project-sign-title">
        <form method="post" id="sign-form" class="commission-modal-inner">
          <input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="employee_signoff_v13"><input type="hidden" name="service_item_id" id="sign-item"><input type="hidden" name="signature_data" id="project-signature-data"><input type="hidden" name="board_date" value="<?=e(v1344_board_date($_GET['board_date']??null))?>">
          <header class="commission-modal-head"><div><span class="eyebrow">CUSTOMER SIGNATURE</span><h2 id="project-sign-title">项目确认与顾客签名</h2><p id="sign-service-name"></p></div><button type="button" class="commission-modal-close" data-sign-close>×</button></header>
          <div class="commission-modal-scroll-area project-signature-scroll"><div class="project-signature-note"><strong>请顾客确认当前服务项目</strong><span>签名会保存到 Supabase。</span></div><div class="field"><label>请在下方签名</label><div class="project-signature-pad-wrap"><canvas id="signature-canvas" class="project-signature-canvas"></canvas></div><div class="project-signature-tools"><span>手指、触控笔或鼠标都可以；笔迹为白色。</span><button class="btn btn-light btn-small" type="button" id="clear-sign">清除签名</button></div></div></div>
          <footer class="commission-modal-actions"><div><strong>未签名不会提交</strong><span>签名与当前服务项目绑定。</span></div><div class="commission-modal-action-buttons"><button class="btn btn-light" type="button" data-sign-close>取消</button><button class="btn btn-primary" type="submit">确认并提交</button></div></footer>
        </form>
      </section>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded',()=>{const modal=document.getElementById('sign-modal'),canvas=document.getElementById('signature-canvas'),form=document.getElementById('sign-form'),hidden=document.getElementById('project-signature-data'),itemInput=document.getElementById('sign-item'),serviceName=document.getElementById('sign-service-name');const ctx=canvas?.getContext('2d');if(!modal||!canvas||!ctx||!form||!hidden||!itemInput)return;let drawing=false,hasInk=false,timer=0;const pen=()=>{ctx.lineWidth=2.8;ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle='#fff';};const resize=(clear=true)=>{const rect=canvas.getBoundingClientRect();if(rect.width<2||rect.height<2)return;const ratio=Math.max(devicePixelRatio||1,1);canvas.width=Math.round(rect.width*ratio);canvas.height=Math.round(rect.height*ratio);ctx.setTransform(ratio,0,0,ratio,0,0);pen();if(clear){ctx.clearRect(0,0,rect.width,rect.height);hasInk=false;hidden.value='';}};const point=e=>{const r=canvas.getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top]};const open=b=>{clearTimeout(timer);itemInput.value=b.dataset.serviceItemId||'';if(serviceName)serviceName.textContent=b.dataset.serviceName||'服务项目';modal.hidden=false;modal.setAttribute('aria-hidden','false');document.body.classList.add('commission-modal-open');requestAnimationFrame(()=>{modal.classList.add('is-open');requestAnimationFrame(()=>resize(true));});};const close=()=>{modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('commission-modal-open');drawing=false;timer=setTimeout(()=>modal.hidden=true,220);};canvas.addEventListener('pointerdown',e=>{if(e.button!==undefined&&e.button!==0)return;drawing=true;hasInk=true;ctx.beginPath();ctx.moveTo(...point(e));canvas.setPointerCapture?.(e.pointerId);e.preventDefault();});canvas.addEventListener('pointermove',e=>{if(!drawing)return;ctx.lineTo(...point(e));ctx.stroke();e.preventDefault();});const end=e=>{if(!drawing)return;drawing=false;try{canvas.releasePointerCapture?.(e.pointerId)}catch(_){}hidden.value=canvas.toDataURL('image/png');e.preventDefault?.();};canvas.addEventListener('pointerup',end);canvas.addEventListener('pointercancel',end);document.addEventListener('click',e=>{const b=e.target.closest('[data-sign-open]');if(b){open(b);return;}if(e.target.closest('[data-sign-close]'))close();});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!modal.hidden)close();});document.getElementById('clear-sign')?.addEventListener('click',()=>resize(true));form.addEventListener('submit',e=>{if(!hasInk){e.preventDefault();alert('请先让顾客完成签名。');return;}hidden.value=canvas.toDataURL('image/png');});});
    </script>
<?php }

function v13_page_orders(): void {
    $boardDate=v1344_board_date($_GET['board_date']??null);
    $snapshot=v1344_board_snapshot($boardDate);
    $boardSignature=v13696_service_board_signature($snapshot);
    $employees=is_array($snapshot['employees']??null)?$snapshot['employees']:[];
    $visits=is_array($snapshot['visits']??null)?$snapshot['visits']:[];
    $canSeeAll=!empty($snapshot['can_see_all'])||v13_is_owner();
    $rows=[];$rowMap=[];
    foreach($employees as $i=>$employee){$id=(string)($employee['id']??'');$rows[]=['employee'=>$employee,'blocks'=>[]];$rowMap[$id]=$i;}
    $counts=['scheduled'=>0,'progress'=>0,'done'=>0,'cancelled'=>0];
    foreach($visits as $visit){
        $meta=v1344_board_status_meta((string)($visit['status']??'')); $counts[$meta['class']] = ($counts[$meta['class']]??0)+1;
        if($meta['class']==='cancelled') continue;
        $geo=v1344_board_block_geometry($visit); if(!$geo) continue;
        $workerIds=[]; foreach((array)($visit['workers']??[]) as $w){$id=(string)($w['employee_id']??'');if($id!==''&&!in_array($id,$workerIds,true))$workerIds[]=$id;}
        $serviceText=(string)($visit['services']??'尚未加入项目'); $serviceCount=(int)($visit['service_count']??0);
        if($serviceCount>1){$parts=preg_split('/、/u',$serviceText)?:[];$serviceText=($parts[0]??$serviceText).' +'.max(0,$serviceCount-1);}
        $block=['visit'=>$visit,'meta'=>$meta,'geo'=>$geo,'service_text'=>$serviceText];
        foreach($workerIds as $wid) if(isset($rowMap[$wid])) $rows[$rowMap[$wid]]['blocks'][]=$block;
    }
    $prev=(new DateTimeImmutable($boardDate))->modify('-1 day')->format('Y-m-d');$next=(new DateTimeImmutable($boardDate))->modify('+1 day')->format('Y-m-d');
    ?>
    <?php if(!empty($snapshot['compatibility_mode'])): ?><div class="alert alert-warning service-board-compat-notice"><strong>兼容模式已自动接管</strong>：数据库尚未暴露 v13.4.4 Service Board RPC，但页面不会再整页报错。运行 v13.5.3 累计 SQL 后会自动切回完整 RPC 模式。</div><?php endif; ?>
    <div class="page-head service-board-head" data-service-board-live-root data-board-date="<?=e($boardDate)?>" data-service-board-signature="<?=e($boardSignature)?>"><div><span class="eyebrow">LIVE SERVICE CONTROL · SUPABASE</span><h1><?=$canSeeAll?'Team appointment board':'My appointment board'?></h1><p><?=$canSeeAll?'全部预约与现场服务直接放进员工时间轴；老板／经理／柜台一眼查看谁有空、谁在服务、谁待结账。':'这里只显示你本人负责的预约与服务，不显示其他员工的顾客资料。'?></p></div><div class="page-head-actions service-board-head-actions"><form class="service-board-date-form" method="get"><input type="hidden" name="page" value="orders"><button class="btn btn-light" name="board_date" value="<?=e($prev)?>">← 前一天</button><div class="field board-date-picker"><label>日期</label><input class="input" type="date" name="board_date" value="<?=e($boardDate)?>"></div><button class="btn btn-light" type="submit">查看</button><button class="btn btn-light" name="board_date" value="<?=e($next)?>">后一天 →</button></form><span class="badge badge-green" data-service-board-live-status>实时同步</span><?php if(has_permission('visits.create')): ?><a class="btn btn-primary" href="index.php?page=new_visit">＋ 新建订单</a><?php endif; ?></div></div>
    <section class="service-board-summary-strip"><div class="service-board-summary-card"><span>查看日期</span><strong><?=e((new DateTimeImmutable($boardDate))->format('d/m/Y'))?></strong><small>09:00 → 00:00</small></div><div class="service-board-summary-card status-scheduled"><span>黄色：预约 / 等候</span><strong><?=intval($counts['scheduled'])?></strong><small>预约、已到店、待确认、等候</small></div><div class="service-board-summary-card status-progress"><span>红色：处理中</span><strong><?=intval($counts['progress'])?></strong><small>服务中、暂停、待结账</small></div><div class="service-board-summary-card status-done"><span>绿色：完成</span><strong><?=intval($counts['done'])?></strong><small>已完成 / 已结账</small></div></section>
    <section class="card service-board-card"><div class="service-board-frame"><div class="service-board-axis"><div class="service-board-employee-head">EMPLOYEE</div><div class="service-board-time-head"><?php for($hour=9;$hour<=24;$hour++): ?><span><?=$hour===24?'00:00':sprintf('%02d:00',$hour)?></span><?php endfor; ?></div></div><div class="service-board-body"><?php foreach($rows as $row): $eRow=$row['employee']; $availability=strtolower((string)($eRow['availability_status']??'available')); ?><div class="service-board-row"><div class="service-board-employee-cell"><div class="leader-avatar"><?=e(mb_substr((string)($eRow['name']??'员'),0,1))?></div><div class="service-board-employee-info"><strong><?=e((string)($eRow['name']??'员工'))?></strong><small><?=e((string)($eRow['position']??'员工'))?></small><div class="employee-availability-line"><span class="availability-chip <?=$availability==='break'?'is-break':'is-available'?>"><?=$availability==='break'?'休息中':(!empty($eRow['is_on_duty'])?'可接单':'不当班')?></span><?php $isSelf=(string)($eRow['id']??'')===(string)(user()['id']??''); if($isSelf&&!v13_is_owner()): ?><form method="post" class="availability-toggle-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="employee_availability_v1344"><input type="hidden" name="board_date" value="<?=e($boardDate)?>"><input type="hidden" name="availability_status" value="<?=$availability==='break'?'available':'break'?>"><button type="submit"><?=$availability==='break'?'结束休息':'开始休息'?></button></form><?php endif; ?></div></div></div><div class="service-board-track"><?php for($hour=9;$hour<=24;$hour++): ?><span class="service-board-grid-line" style="left:<?=number_format((($hour-9)/15)*100,2,'.','')?>%"></span><?php endfor; ?><?php foreach($row['blocks'] as $block): $v=$block['visit']; ?><button type="button" class="service-board-block status-<?=e($block['meta']['class'])?>" style="left:<?=number_format($block['geo']['left'],2,'.','')?>%;width:<?=number_format($block['geo']['width'],2,'.','')?>%" data-service-board-open data-visit-id="<?=e((string)$v['id'])?>"><span class="service-board-block-time"><?=e($block['geo']['time'])?></span><strong><?=e((string)($v['customer_name']??'顾客'))?></strong><small><?=e($block['service_text'])?></small></button><?php endforeach; ?><?php if(!$row['blocks']): ?><div class="service-board-empty"><?=$availability==='break'?'Break':'Available'?></div><?php endif; ?></div></div><?php endforeach; ?><?php if(!$rows): ?><div class="empty compact-empty"><h3>还没有可显示员工</h3><p>先在员工管理建立并启用员工。</p></div><?php endif; ?></div></div></section>

    <section class="card service-board-all-orders"><div class="card-head service-board-all-orders-head"><div><span class="card-kicker">ALL ORDERS</span><h3><?=$canSeeAll?'当天全部订单':'我的当天订单'?></h3><p><?=e((new DateTimeImmutable($boardDate))->format('d/m/Y'))?> · 预约、待到店、待签名、等候、服务中、暂停、待结账、完成、取消都保留。</p></div><span class="badge badge-gray"><?=count($visits)?> 笔</span></div><div class="service-board-order-list"><?php foreach($visits as $visit): $meta=v1344_board_status_meta((string)($visit['status']??''));$dt=v1344_local_dt((string)($visit['sort_at']??$visit['created_at']??'')); ?><button type="button" class="service-board-order-row status-<?=e($meta['class'])?>" data-service-board-open data-visit-id="<?=e((string)$visit['id'])?>"><div class="service-board-order-status-dot"></div><div class="service-board-order-time"><strong><?=e($dt?$dt->format('H:i'):'--:--')?></strong><small><?=e(v13_visit_type_label((string)($visit['visit_type']??'')))?></small></div><div class="service-board-order-customer"><strong><?=e((string)($visit['customer_name']??'顾客'))?></strong><small><?=e((string)($visit['customer_phone']??''))?><?=!empty($visit['member_number'])?' · '.e((string)$visit['member_number']):' · 非会员'?></small></div><div class="service-board-order-services"><strong><?=e((string)($visit['services']??'尚未加入项目'))?></strong><small><?=e((string)($visit['employees']??'待分配员工'))?></small></div><div class="service-board-order-money"><strong><?=money($visit['total_amount']??0)?></strong><small><?=e(v1344_payment_label((string)($visit['payment_status']??'unpaid')))?></small></div><div class="service-board-order-state"><span class="badge <?=($meta['class']==='done'?'badge-green':($meta['class']==='progress'?'badge-red':($meta['class']==='cancelled'?'badge-gray':'badge-gold')))?>"><?=e($meta['label'])?></span></div><span class="service-board-order-arrow">›</span></button><?php endforeach; ?><?php if(!$visits): ?><div class="empty compact-empty"><h3>这一天没有订单</h3><p>切换其他日期，或建立新的预约 / Walk-in。</p></div><?php endif; ?></div></section>

    <div class="commission-modal service-board-modal" data-service-board-modal hidden aria-hidden="true"><div class="commission-modal-backdrop" data-service-board-modal-close></div><div class="commission-modal-dialog"><div class="commission-modal-loading" data-service-board-modal-loading>载入中...</div><div data-service-board-modal-content></div></div></div>
    <?php v1344_render_project_signature_modal(); ?>
    <?php
}


function v13_page_order_history(): void {
    if(!v13_is_owner()){echo '<section class="card" style="padding:24px"><h2>订单记录</h2><p>员工端不显示完整门店账务历史。</p></section>';return;}
    $page=max(1,(int)($_GET['history_page']??1)); $pageSize=100; $rows=v134_owner_history_page($page,$pageSize);
    $status=trim((string)($_GET['status']??'all')); $from=trim((string)($_GET['from']??'')); $to=trim((string)($_GET['to']??''));
    $qsBase=['page'=>'order_history','status'=>$status,'from'=>$from,'to'=>$to];
    ?>
    <div class="page-head"><div><span class="eyebrow">ORDER HISTORY · SUPABASE</span><h1>订单记录</h1><p>在已完成订单的详情中可以打开原收据、查看或登记退款。</p></div><a class="btn btn-light" href="index.php?page=operations">待处理事项</a></div>
    <section class="card history-filter-card">
      <form method="get" class="history-filter-form">
        <input type="hidden" name="page" value="order_history">
        <div class="field"><label>状态</label><select class="select" name="status"><option value="all" <?=$status==='all'?'selected':''?>>全部历史状态</option><option value="completed" <?=$status==='completed'?'selected':''?>>完成</option><option value="cancelled" <?=$status==='cancelled'?'selected':''?>>取消</option><option value="no_show" <?=$status==='no_show'?'selected':''?>>未到</option></select></div>
        <div class="field"><label>开始日期</label><input class="input" type="date" name="from" value="<?=e($from)?>"></div>
        <div class="field"><label>结束日期</label><input class="input" type="date" name="to" value="<?=e($to)?>"></div>
        <div class="history-filter-actions"><button class="btn btn-primary" type="submit">查询</button><a class="btn btn-light" href="index.php?page=order_history">清除筛选</a></div>
      </form>
    </section>
    <section class="card history-table-card"><div class="history-table-scroll"><table class="data-table v1361052-history-table"><thead><tr><th>订单</th><th>类型</th><th>状态</th><th>建立时间</th><th>结账时间</th><th></th></tr></thead><tbody><?php foreach($rows as $r): ?><tr class="v1361052-history-row" tabindex="0" role="button" data-service-board-open data-visit-id="<?=e((string)$r['id'])?>"><td><strong><?=e((string)$r['visit_number'])?></strong></td><td><?=e(v13_visit_type_label((string)$r['visit_type']))?></td><td><?=e(v13_status_label((string)$r['status']))?></td><td><?=e(app_date((string)$r['created_at'],true))?></td><td><?=!empty($r['checked_out_at'])?e(app_date((string)$r['checked_out_at'],true)):'—'?></td><td><button class="btn btn-light btn-small" type="button" data-service-board-open data-visit-id="<?=e((string)$r['id'])?>">查看详情</button></td></tr><?php endforeach; ?></tbody></table></div><?php if(!$rows): ?><div class="empty">这一页没有历史订单。</div><?php endif; ?>
      <div class="history-pagination">
        <span>第 <?=$page?> 页 · 每页最多 <?=$pageSize?> 笔</span>
        <div>
          <?php if($page>1): $prev=$qsBase; $prev['history_page']=$page-1; ?><a class="btn btn-light btn-small" href="index.php?<?=e(http_build_query($prev))?>">← 上一页</a><?php endif; ?>
          <?php if(count($rows)===$pageSize): $next=$qsBase; $next['history_page']=$page+1; ?><a class="btn btn-light btn-small" href="index.php?<?=e(http_build_query($next))?>">下一页 →</a><?php endif; ?>
        </div>
      </div>
    </section>
    <div class="commission-modal service-board-modal" data-service-board-modal hidden aria-hidden="true"><div class="commission-modal-backdrop" data-service-board-modal-close></div><div class="commission-modal-dialog"><div class="commission-modal-loading" data-service-board-modal-loading>载入订单证据…</div><div data-service-board-modal-content></div></div></div>
    <?php
}

function v1354_performance_filters(): array {
    $period=in_array((string)($_GET['period']??''),['day','month','year'],true)?(string)$_GET['period']:'month';
    $anchor=preg_match('/^\d{4}-\d{2}-\d{2}$/',(string)($_GET['anchor']??''))?(string)$_GET['anchor']:date('Y-m-d');
    return [$period,$anchor];
}
function v1354_performance_payload(string $employeeId=''): array {
    [$period,$anchor]=v1354_performance_filters();
    if(v13_is_owner()) return v13_rpc_json('v1355_owner_performance_board',['p_store_id'=>v13_store_uuid(),'p_period'=>$period,'p_anchor'=>$anchor,'p_employee_id'=>$employeeId!==''?$employeeId:null],v13_owner_token_required_all());
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    return v13_rpc_json('v1355_employee_performance_board',['p_session_token'=>$session,'p_period'=>$period,'p_anchor'=>$anchor,'p_employee_id'=>$employeeId!==''?$employeeId:null],'');
}
function v1354_performance_filter_html(string $page,string $employeeId=''): void {[$period,$anchor]=v1354_performance_filters();?>
  <form class="v1354-period-filter" method="get"><input type="hidden" name="page" value="<?=e($page)?>"><?php if($employeeId!==''):?><input type="hidden" name="id" value="<?=e($employeeId)?>"><?php endif;?><div class="v1354-period-tabs"><?php foreach(['day'=>'日','month'=>'月','year'=>'年'] as $k=>$label):?><button class="<?=$period===$k?'active':''?>" type="submit" name="period" value="<?=$k?>"><?=$label?></button><?php endforeach;?></div><input class="input" type="date" name="anchor" value="<?=e($anchor)?>"><button class="btn btn-light">查看</button></form><?php }
function v1354_avatar_html(array $employee,string $class='v1354-rank-avatar'): string {$url=salonos_v1354_employee_avatar_url((string)($employee['avatar_path']??''));if($url!=='')return '<div class="'.e($class).'"><img src="'.e($url).'" alt="'.e((string)($employee['name']??'员工')).'"></div>';return '<div class="'.e($class).'">'.e(mb_substr((string)($employee['name']??'E'),0,1)).'</div>';}
function v13_page_performance(): void {
    $data=v1354_performance_payload();$ranking=is_array($data['ranking']??null)?$data['ranking']:[];
    ?><div class="page-head responsive-page-head"><div><span class="eyebrow">TEAM PERFORMANCE RANKING</span><h1>员工业绩排行榜</h1><p><?=e((string)($data['label']??''))?> · 服务业绩 + 产品销售，门店营业额不会因为多人贡献重复计算。</p></div><?php v1354_performance_filter_html('performance');?></div>
    <section class="v1354-podium"><?php foreach(array_slice($ranking,0,3) as $r):$rank=intval($r['rank']??0);?><a class="card v1354-podium-card rank-<?=$rank?>" href="index.php?<?=e(http_build_query(['page'=>'performance_employee','id'=>$r['employee_id'],'period'=>$data['period']??'month','anchor'=>$data['anchor']??date('Y-m-d')]))?>"><span class="v1354-rank-medal"><?=$rank?></span><?=v1354_avatar_html($r)?><div><span class="card-kicker"><?=e((string)($r['position']??''))?></span><h2><?=e((string)$r['name'])?></h2><strong><?=money($r['total_performance']??0)?></strong><small>服务 <?=money($r['service_performance']??0)?> · 产品 <?=money($r['product_sales']??0)?></small></div></a><?php endforeach;?><?php if(!$ranking):?><section class="card empty-state"><h3>这个期间还没有员工业绩</h3></section><?php endif;?></section>
    <?php if(count($ranking)>3):?><section class="card v1354-ranking-list"><div class="card-head"><div><span class="card-kicker">FULL RANKING</span><h3>完整排名</h3></div></div><?php foreach(array_slice($ranking,3) as $r):?><a class="v1354-ranking-row" href="index.php?<?=e(http_build_query(['page'=>'performance_employee','id'=>$r['employee_id'],'period'=>$data['period']??'month','anchor'=>$data['anchor']??date('Y-m-d')]))?>"><b>#<?=intval($r['rank']??0)?></b><?=v1354_avatar_html($r,'v1354-rank-avatar small')?><div><strong><?=e((string)$r['name'])?></strong><small><?=e((string)($r['position']??''))?> · <?=intval($r['customer_count']??0)?> 位顾客</small></div><span><?=money($r['total_performance']??0)?></span></a><?php endforeach;?></section><?php endif;
}

function v13_page_analytics(): void {
    if(!v13_is_owner()){echo '<section class="card" style="padding:24px"><h2>经营分析</h2><p>仅老板可查看。</p></section>';return;}
    $payments=v13_owner_rows('payments','select=grand_total,service_subtotal,product_subtotal,discount_total,tax_total,paid_at,status&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&status=eq.paid&order=paid_at.desc&limit=5000'); $days=[];foreach($payments as $p){$d=substr((string)$p['paid_at'],0,10);$days[$d]['revenue']=($days[$d]['revenue']??0)+(float)$p['grand_total'];$days[$d]['service']=($days[$d]['service']??0)+(float)$p['service_subtotal'];$days[$d]['product']=($days[$d]['product']??0)+(float)$p['product_subtotal'];$days[$d]['orders']=($days[$d]['orders']??0)+1;}krsort($days); ?>
    <div class="page-head"><div><span class="eyebrow">BUSINESS ANALYTICS · SUPABASE</span><h1>经营分析</h1><p>这里只统计 Supabase 已付款订单。</p></div></div><section class="card" style="overflow:auto"><table class="data-table"><thead><tr><th>日期</th><th>订单</th><th>服务营业额</th><th>产品营业额</th><th>总营业额</th></tr></thead><tbody><?php foreach(array_slice($days,0,90,true) as $d=>$x):?><tr><td><?=e($d)?></td><td><?=intval($x['orders'])?></td><td><?=money($x['service'])?></td><td><?=money($x['product'])?></td><td><strong><?=money($x['revenue'])?></strong></td></tr><?php endforeach;?></tbody></table><?php if(!$days):?><div class="empty">还没有已付款数据。</div><?php endif;?></section><?php
}


function v135_analysis_range(): array {
    $period=in_array((string)($_GET['period']??''),['day','month','year'],true)?(string)$_GET['period']:'month';
    $anchor=trim((string)($_GET['anchor']??'')); $tz=new DateTimeZone('Asia/Kuala_Lumpur');
    try{$d=$anchor!==''?new DateTimeImmutable($anchor.' 00:00:00',$tz):new DateTimeImmutable('now',$tz);}catch(Throwable $e){$d=new DateTimeImmutable('now',$tz);}
    if($period==='day'){$start=$d->setTime(0,0);$end=$start->modify('+1 day');$label=$start->format('d/m/Y');}
    elseif($period==='year'){$start=$d->setDate((int)$d->format('Y'),1,1)->setTime(0,0);$end=$start->modify('+1 year');$label=$start->format('Y');}
    else{$start=$d->setDate((int)$d->format('Y'),(int)$d->format('m'),1)->setTime(0,0);$end=$start->modify('+1 month');$label=$start->format('m/Y');}
    $utc=new DateTimeZone('UTC');
    return ['period'=>$period,'anchor'=>$d->format('Y-m-d'),'start'=>$start,'end'=>$end,'start_utc'=>$start->setTimezone($utc)->format('Y-m-d\\TH:i:s\\Z'),'end_utc'=>$end->setTimezone($utc)->format('Y-m-d\\TH:i:s\\Z'),'label'=>$label];
}
function v135_ts_in_range(?string $value,array $range): bool {
    $dt=v1344_local_dt($value); return $dt && $dt >= $range['start'] && $dt < $range['end'];
}
function v13511_customer_age(array $customer,array $range): ?int {
    $birth=trim((string)($customer['birth_date']??''));
    if($birth!==''){
        try{
            $b=new DateTimeImmutable($birth,new DateTimeZone('Asia/Kuala_Lumpur'));
            $at=$range['end']->modify('-1 second');
            if($b<=$at) return max(0,min(120,(int)$b->diff($at)->y));
        }catch(Throwable $ignore){}
    }
    $notes=(string)($customer['notes']??'');
    if(preg_match('/Order intake age:\s*(\d{1,3})/i',$notes,$m)) return max(0,min(120,(int)$m[1]));
    return null;
}
function v13511_age_band(?int $age): string {
    if($age===null)return '未填写';
    if($age<18)return '<18';
    if($age<=24)return '18–24';
    if($age<=34)return '25–34';
    if($age<=44)return '35–44';
    if($age<=54)return '45–54';
    if($age<=64)return '55–64';
    return '65+';
}
function v13511_rows_for_visit_ids(string $table,string $select,array $ids,string $extra=''): array {
    $rows=[];
    foreach(array_chunk(array_values(array_unique(array_filter($ids))),120) as $chunk){
        if(!$chunk)continue;
        $q='select='.$select.'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&visit_id=in.'.v135_in_filter($chunk).$extra.'&limit=5000';
        foreach(v13_owner_rows($table,$q) as $row)$rows[]=$row;
    }
    return $rows;
}

function v136109_normalize_phone(string $phone): string {
    $d=preg_replace('/\D+/','',$phone) ?: '';
    // Canonical MY phone form follows the rest of SalonOS: +60 / 60xxxxxxxxx -> 0xxxxxxxxx.
    if(str_starts_with($d,'60')&&strlen($d)>10)$d='0'.substr($d,2);
    return $d;
}
function v136109_gender_label(?string $gender): string {
    $g=mb_strtolower(trim((string)$gender));
    if($g==='')return '未填写';
    if(in_array($g,['male','m','男','男性'],true))return '男';
    if(in_array($g,['female','f','女','女性'],true))return '女';
    return '其他';
}
function v136109_first_touch_rows(?array $range=null): array {
    $org=v13_org_uuid();$store=v13_store_uuid();
    $base='organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store);
    try{
        $q='select=id,organization_id,store_id,customer_id,customer_phone,normalized_phone,tracking_link_id,channel_id,social_account_id,content_id,staff_id,ref_code,attribution_status,source_fallback_needed,first_message_at&'.$base;
        if($range){
            $q.='&first_message_at=gte.'.rawurlencode((string)$range['start_utc']).'&first_message_at=lt.'.rawurlencode((string)$range['end_utc']);
        }
        return v13_owner_rows('marketing_customer_first_touch',$q.'&order=first_message_at.asc&limit=50000');
    }catch(Throwable $ignore){
        // Backward-compatible fallback before the v13.6.10.9 SQL is installed:
        // derive one immutable-looking first row per normalized phone from existing Marketing Leads.
        try{
            $leads=v13_owner_rows('marketing_leads','select=id,organization_id,store_id,customer_id,customer_phone,tracking_link_id,channel_id,social_account_id,content_id,staff_id,ref_code,attribution_status,source_fallback_needed,first_message_at,created_at&'.$base.'&order=created_at.asc&limit=50000');
        }catch(Throwable $e){return [];}
        $seen=[];$rows=[];
        foreach($leads as $l){
            $norm=v136109_normalize_phone((string)($l['customer_phone']??''));
            if($norm===''||isset($seen[$norm]))continue;
            $seen[$norm]=true;
            $l['normalized_phone']=$norm;
            $l['first_message_at']=$l['first_message_at']??$l['created_at']??null;
            if($range){
                $dt=v1344_local_dt((string)($l['first_message_at']??''));
                if(!$dt||$dt<$range['start']||$dt>=$range['end'])continue;
            }
            $rows[]=$l;
        }
        return $rows;
    }
}
function v136109_first_touch_source_map(): array {
    $rows=v136109_first_touch_rows(null);
    if(!$rows)return [];
    $org=v13_org_uuid();$store=v13_store_uuid();
    $base='organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store);
    $links=[];$channels=[];$accounts=[];$contents=[];$employees=[];
    try{foreach(v13_owner_rows('tracking_links','select=id,placement,channel_id,social_account_id,content_id,staff_id&'.$base.'&limit=10000') as $r)$links[(string)$r['id']]=$r;}catch(Throwable $ignore){}
    try{foreach(v13_owner_rows('marketing_channels','select=id,name,code&'.$base.'&limit=1000') as $r)$channels[(string)$r['id']]=$r;}catch(Throwable $ignore){}
    try{foreach(v13_owner_rows('social_accounts','select=id,display_name,username,staff_id&'.$base.'&limit=5000') as $r)$accounts[(string)$r['id']]=$r;}catch(Throwable $ignore){}
    try{foreach(v13_owner_rows('marketing_contents','select=id,content_type,title,content_code&'.$base.'&limit=10000') as $r)$contents[(string)$r['id']]=$r;}catch(Throwable $ignore){}
    try{foreach(v13_owner_rows('employees','select=id,name&organization_id=eq.'.rawurlencode($org).'&limit=5000') as $r)$employees[(string)$r['id']]=$r;}catch(Throwable $ignore){}
    $map=[];
    foreach($rows as $ft){
        $norm=v136109_normalize_phone((string)($ft['normalized_phone']??$ft['customer_phone']??''));
        if($norm==='')continue;
        $link=$links[(string)($ft['tracking_link_id']??'')]??[];
        $channelId=(string)($ft['channel_id']??$link['channel_id']??'');
        $accountId=(string)($ft['social_account_id']??$link['social_account_id']??'');
        $contentId=(string)($ft['content_id']??$link['content_id']??'');
        $staffId=(string)($ft['staff_id']??$link['staff_id']??($accounts[$accountId]['staff_id']??''));
        $channel=trim((string)($channels[$channelId]['name']??''));
        $account=trim((string)($accounts[$accountId]['display_name']??''));
        $staff=trim((string)($employees[$staffId]['name']??''));
        $placement=trim((string)($link['placement']??''));
        if($placement==='')$placement=trim((string)($contents[$contentId]['content_type']??''));
        if($placement==='')$placement=$accountId!==''?'profile':'direct';
        $source=$channel!==''?$channel:'未记录';
        $parts=[];
        if($channel!=='')$parts[]=$channel;
        if($account!=='')$parts[]=$account;
        if($placement!=='direct')$parts[]=ucfirst($placement);
        if($staff!=='')$parts[]='来源员工 '.$staff;
        $detail=$parts?implode(' · ',$parts):'Direct / 未记录';
        $map[$norm]=[
            'channel'=>$source,'account'=>$account!==''?$account:'Store / Direct','staff'=>$staff!==''?$staff:'—',
            'placement'=>$placement,'detail'=>$detail,'ref_code'=>(string)($ft['ref_code']??''),
            'first_message_at'=>(string)($ft['first_message_at']??''),'attribution_status'=>(string)($ft['attribution_status']??'unknown')
        ];
    }
    return $map;
}

function v13511_customer_segments(array $range): array {
    $org=v13_org_uuid();$store=v13_store_uuid();
    $visits=v13_owner_rows('visits','select=id,status,visit_type,checked_out_at,created_at,scheduled_at&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&status=eq.completed&order=created_at.asc&limit=50000');
    $visitIds=array_values(array_filter(array_map(static fn($v)=>(string)($v['id']??''),$visits)));
    $recipients=$visitIds?v13511_rows_for_visit_ids('visit_recipients','visit_id,customer_id,name_snapshot,phone_snapshot,recipient_type',$visitIds):[];
    $primary=[];
    foreach($recipients as $r){if((string)($r['recipient_type']??'primary')!=='primary')continue;$primary[(string)($r['visit_id']??'')]=$r;}
    $prefs=[];
    try{
        foreach(v13_owner_rows('appointment_employee_preferences','select=visit_id,preference_type,employee_id&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&limit=50000') as $pr)$prefs[(string)($pr['visit_id']??'')]=$pr;
    }catch(Throwable $ignore){}
    $customers=[];
    foreach(v13_owner_rows('customers','select=id,name,phone,gender,birth_date,ethnicity,acquisition_platform,notes,created_at&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&limit=50000') as $c)$customers[(string)($c['id']??'')]=$c;
    $employeeNames=[];
    try{foreach(v13_employee_rows_owner() as $e)$employeeNames[(string)($e['id']??'')]=(string)($e['name']??'');}catch(Throwable $ignore){}

    $profiles=[];$active=[];
    foreach($visits as $v){
        $vid=(string)($v['id']??'');$r=$primary[$vid]??null;if(!$r)continue;
        $cid=trim((string)($r['customer_id']??''));
        $phone=preg_replace('/\D+/','',(string)($r['phone_snapshot']??''));
        $key=$cid!==''?'c:'.$cid:($phone!==''?'p:'.$phone:'v:'.$vid);
        if(!isset($profiles[$key])){
            $c=$cid!==''?($customers[$cid]??[]):[];
            $profiles[$key]=[
                'customer_id'=>$cid,'name'=>(string)($c['name']??$r['name_snapshot']??'顾客'),'phone'=>(string)($c['phone']??$r['phone_snapshot']??''),
                'gender'=>(string)($c['gender']??''),'birth_date'=>$c['birth_date']??null,'ethnicity'=>trim((string)($c['ethnicity']??'')),'acquisition_platform'=>trim((string)($c['acquisition_platform']??'')),'notes'=>(string)($c['notes']??''),
                'visits'=>0,'specified'=>0,'random'=>0,'specified_employees'=>[],'first_visit'=>'','last_visit'=>''
            ];
        }
        $ts=(string)($v['checked_out_at']??$v['created_at']??'');$dt=v1344_local_dt($ts);
        $profiles[$key]['visits']++;
        if($profiles[$key]['first_visit']===''&&$dt)$profiles[$key]['first_visit']=$dt->format('d/m/Y');
        if($dt)$profiles[$key]['last_visit']=$dt->format('d/m/Y');
        $pref=$prefs[$vid]??null;$ptype=(string)($pref['preference_type']??'random');
        if($ptype==='specified'){
            $profiles[$key]['specified']++;
            $eid=trim((string)($pref['employee_id']??''));if($eid!=='')$profiles[$key]['specified_employees'][$eid]=($profiles[$key]['specified_employees'][$eid]??0)+1;
        }else $profiles[$key]['random']++;
        if($dt && $dt >= $range['start'] && $dt < $range['end'])$active[$key]=true;
    }

    $firstTouchMap=v136109_first_touch_source_map();
    $segments=['new'=>[],'random'=>[],'specified'=>[]];$sources=[];$ages=[];$ethnicities=[];$genders=[];
    foreach(array_keys($active) as $key){
        if(!isset($profiles[$key]))continue;$p=$profiles[$key];
        $p['age']=v13511_customer_age($p,$range);$p['age_band']=v13511_age_band($p['age']);
        $p['gender_label']=v136109_gender_label((string)($p['gender']??''));
        $p['ethnicity_label']=$p['ethnicity']!==''?$p['ethnicity']:'未填写';
        $norm=v136109_normalize_phone((string)($p['phone']??''));
        $ft=$norm!==''?($firstTouchMap[$norm]??null):null;
        if($ft){
            $p['source']=(string)$ft['channel'];
            $p['source_detail']=(string)$ft['detail'];
            $p['source_account']=(string)$ft['account'];
            $p['source_staff']=(string)$ft['staff'];
            $p['source_placement']=(string)$ft['placement'];
            $p['source_ref']=(string)$ft['ref_code'];
        }else{
            $p['source']=$p['acquisition_platform']!==''?$p['acquisition_platform']:'未记录';
            $p['source_detail']=$p['source'];
            $p['source_account']='—';$p['source_staff']='—';$p['source_placement']='direct';$p['source_ref']='';
        }
        $p['specified_rate']=$p['visits']>0?round(($p['specified']/$p['visits'])*100,1):0.0;
        $topEmployee='';$topCount=0;foreach($p['specified_employees'] as $eid=>$count){if($count>$topCount){$topCount=$count;$topEmployee=$employeeNames[$eid]??'已停用员工';}}
        $p['top_stylist']=$topEmployee;
        if((int)$p['visits']<=1){
            $segments['new'][]=$p;$sources[$p['source']]=($sources[$p['source']]??0)+1;$ages[$p['age_band']]=($ages[$p['age_band']]??0)+1;$ethnicities[$p['ethnicity_label']]=($ethnicities[$p['ethnicity_label']]??0)+1;$genders[$p['gender_label']]=($genders[$p['gender_label']]??0)+1;
        }elseif((int)$p['specified']>(int)$p['random'])$segments['specified'][]=$p;
        else $segments['random'][]=$p;
    }
    foreach($segments as &$rows)usort($rows,static fn($a,$b)=>($b['visits']<=>$a['visits']) ?: strcmp((string)$a['name'],(string)$b['name']));unset($rows);
    arsort($sources);arsort($ages);arsort($ethnicities);arsort($genders);
    $total=count($active);
    return ['total'=>$total,'segments'=>$segments,'sources'=>$sources,'ages'=>$ages,'ethnicities'=>$ethnicities,'genders'=>$genders,'legacy_note'=>'分类按累计完成到店记录；来源按手机号码匹配 WhatsApp 首次触达。相同号码重复发送不会重复计数，之后从其他平台再次进入也不会改写第一次来源。'];
}
function v13511_breakdown_rows(array $rows,int $total): string {
    if(!$rows)return '<div class="empty compact-empty">暂无数据</div>';
    $html='<div class="customer-breakdown-list">';
    foreach($rows as $label=>$count){$pct=$total>0?($count/$total)*100:0;$html.='<div class="customer-breakdown-row"><div><strong>'.e((string)$label).'</strong><small>'.intval($count).' 位</small></div><div class="customer-breakdown-meter"><i style="width:'.max(2,min(100,$pct)).'%"></i></div><b>'.number_format($pct,1).'%</b></div>';}
    return $html.'</div>';
}
function v135_analytics_dataset(): array {
    $range=v135_analysis_range(); $org=v13_org_uuid(); $store=v13_store_uuid();
    $pQ='select=*&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&status=eq.paid&paid_at=gte.'.rawurlencode($range['start_utc']).'&paid_at=lt.'.rawurlencode($range['end_utc']).'&order=paid_at.asc&limit=20000';
    $payments=v13_owner_rows('payments',$pQ);
    $visitMap=[]; $visits=[];
    $base='select=*&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store);
    foreach([
      $base.'&scheduled_at=gte.'.rawurlencode($range['start_utc']).'&scheduled_at=lt.'.rawurlencode($range['end_utc']).'&limit=10000',
      $base.'&created_at=gte.'.rawurlencode($range['start_utc']).'&created_at=lt.'.rawurlencode($range['end_utc']).'&limit=10000'
    ] as $q){foreach(v13_owner_rows('visits',$q) as $v){$id=(string)($v['id']??'');$ts=(string)($v['scheduled_at']??$v['created_at']??'');if($id!==''&&v135_ts_in_range($ts,$range))$visitMap[$id]=$v;}}
    $visits=array_values($visitMap); $paidVisitIds=[];foreach($payments as $p1){$id=(string)($p1['visit_id']??'');if($id!=='')$paidVisitIds[$id]=true;}
    $ids=array_keys($paidVisitIds); $items=[];$rec=[];$products=[];
    if($ids){$in=v135_in_filter($ids);$items=v13_owner_rows('visit_service_items','select=*&organization_id=eq.'.rawurlencode($org).'&visit_id=in.'.$in.'&limit=30000');$rec=v13_owner_rows('visit_recipients','select=*&organization_id=eq.'.rawurlencode($org).'&visit_id=in.'.$in.'&limit=30000');try{$products=v13_owner_rows('visit_product_items','select=*&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&visit_id=in.'.$in.'&status=eq.active&limit=30000');}catch(Throwable $ignore){}}
    $revenue=$serviceRevenue=$productRevenue=0.0;foreach($payments as $x){$revenue+=(float)($x['grand_total']??0);$serviceRevenue+=(float)($x['service_subtotal']??0);$productRevenue+=(float)($x['product_subtotal']??0);}
    $customers=[];foreach($rec as $r){$cid=(string)($r['customer_id']??'');if($cid!=='')$customers[$cid]=true;else{$phone=(string)($r['phone_snapshot']??'');if($phone!=='')$customers['p:'.$phone]=true;}}
    $appointments=0;$walkins=0;foreach($visits as $v){if((string)($v['visit_type']??'walk_in')==='appointment')$appointments++;else$walkins++;}
    $productCost=0.0;foreach($products as $pi)$productCost+=(float)($pi['cost_price_snapshot']??0)*(float)($pi['quantity']??1);
    $materialCost=0.0;try{$mv=v13_owner_rows('inventory_stock_movements','select=*&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&created_at=gte.'.rawurlencode($range['start_utc']).'&created_at=lt.'.rawurlencode($range['end_utc']).'&limit=30000');foreach($mv as $m){$type=strtolower((string)($m['movement_type']??$m['reason_type']??$m['type']??''));$qty=(float)($m['quantity_delta']??0);if($qty<0 && (str_contains($type,'service')||str_contains($type,'material')||str_contains($type,'consum')))$materialCost+=abs($qty)*(float)($m['unit_cost']??$m['cost_per_unit']??0);}}catch(Throwable $ignore){}
    $groups=[];foreach($payments as $x){$dt=v1344_local_dt((string)($x['paid_at']??''));if(!$dt)continue;if($range['period']==='year'){$key=$dt->format('Y-m');$label=$dt->format('m/Y');}elseif($range['period']==='day'){$key=$dt->format('H');$label=$dt->format('H:00');}else{$key=$dt->format('Y-m-d');$label=$dt->format('d/m');}$g=$groups[$key]??['label'=>$label,'revenue'=>0.0,'service'=>0.0,'product'=>0.0,'orders'=>0];$g['revenue']+=(float)($x['grand_total']??0);$g['service']+=(float)($x['service_subtotal']??0);$g['product']+=(float)($x['product_subtotal']??0);$g['orders']++;$groups[$key]=$g;}ksort($groups);
    $servicePerf=[];foreach($items as $it){if(($it['status']??'')==='cancelled')continue;$name=(string)($it['service_name_snapshot']??'服务');$servicePerf[$name]['count']=($servicePerf[$name]['count']??0)+1;$servicePerf[$name]['revenue']=($servicePerf[$name]['revenue']??0)+(float)($it['line_total']??0);}uasort($servicePerf,static fn($a,$b)=>($b['revenue']<=>$a['revenue']));
    $productPerf=[];foreach($products as $pi){$name=(string)($pi['product_name_snapshot']??'产品');$productPerf[$name]['qty']=($productPerf[$name]['qty']??0)+(float)($pi['quantity']??1);$productPerf[$name]['revenue']=($productPerf[$name]['revenue']??0)+(float)($pi['line_total']??((float)($pi['unit_price']??0)*(float)($pi['quantity']??1)));$productPerf[$name]['cost']=($productPerf[$name]['cost']??0)+(float)($pi['cost_price_snapshot']??0)*(float)($pi['quantity']??1);}uasort($productPerf,static fn($a,$b)=>($b['revenue']<=>$a['revenue']));
    $customerSegments=v13511_customer_segments($range);
    return ['range'=>$range,'payments'=>$payments,'visits'=>$visits,'summary'=>['revenue'=>$revenue,'orders'=>count($payments),'customers'=>count($customers),'avg_ticket'=>count($payments)?$revenue/count($payments):0,'appointments'=>$appointments,'walkins'=>$walkins,'product_revenue'=>$productRevenue,'service_revenue'=>$serviceRevenue,'material_cost'=>$materialCost,'product_cost'=>$productCost],'groups'=>$groups,'services'=>$servicePerf,'products'=>$productPerf,'customer_segments'=>$customerSegments];
}
function v135_export_analytics_csv(): never {
    if(!v13_is_owner())throw new RuntimeException('只有老板可以导出经营报告。'); $d=v135_analytics_dataset();$r=$d['range'];$s=$d['summary'];
    $name='SalonOS_经营分析_'.$r['period'].'_'.$r['anchor'].'.csv';header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="'.rawurlencode($name).'"');echo "\xEF\xBB\xBF";$out=fopen('php://output','w');
    fputcsv($out,['SalonOS 经营分析',$r['label'],'Store',current_store()['name']??'']);fputcsv($out,[]);fputcsv($out,['指标','数值']);foreach(['营业额'=>'revenue','完成订单'=>'orders','顾客人数'=>'customers','平均客单价'=>'avg_ticket','预约订单'=>'appointments','Walk-in'=>'walkins','产品销售'=>'product_revenue','服务营业额'=>'service_revenue','材料成本'=>'material_cost','产品成本'=>'product_cost'] as $label=>$key)fputcsv($out,[$label,$s[$key]??0]);fputcsv($out,[]);fputcsv($out,['期间','营业额','服务','产品','订单','Avg Ticket']);foreach($d['groups'] as $g)fputcsv($out,[$g['label'],$g['revenue'],$g['service'],$g['product'],$g['orders'],$g['orders']?$g['revenue']/$g['orders']:0]);
    $cs=$d['customer_segments']??[];$seg=$cs['segments']??[];fputcsv($out,[]);fputcsv($out,['顾客结构分析',$r['label']]);fputcsv($out,['分类','人数','占本期活跃顾客']);$ct=max(1,(int)($cs['total']??0));foreach([['首次到店新客','new'],['回访随机／未固定型','random'],['指定理发师忠诚客','specified']] as [$label,$key]){$n=count($seg[$key]??[]);fputcsv($out,[$label,$n,round($n/$ct*100,1).'%']);}
    foreach([['新客首次来源',$cs['sources']??[]],['新客年龄分段',$cs['ages']??[]],['新客种族',$cs['ethnicities']??[]],['新客性别',$cs['genders']??[]]] as [$title,$rows]){fputcsv($out,[]);fputcsv($out,[$title,'人数']);foreach($rows as $label=>$count)fputcsv($out,[$label,$count]);}
    fputcsv($out,[]);fputcsv($out,['顾客分类明细','姓名','电话','累计到店','随机/系统','指定','指定率','常指定理发师','首次媒体来源','来源明细','年龄','年龄分段','性别','种族','最近到店']);foreach([['首次到店新客','new'],['回访随机／未固定型','random'],['指定理发师忠诚客','specified']] as [$label,$key])foreach($seg[$key]??[] as $row)fputcsv($out,[$label,$row['name'],$row['phone'],$row['visits'],$row['random'],$row['specified'],$row['specified_rate'].'%',$row['top_stylist'],$row['source'],$row['source_detail']??$row['source'],$row['age']??'',$row['age_band']??'',$row['gender_label']??'',$row['ethnicity_label'],$row['last_visit']]);
    fclose($out);exit;
}
function v1361011_is_social_channel(string $name): bool {
    $v=mb_strtolower(trim($name));
    if($v==='')return false;
    foreach(['instagram','facebook','tiktok','tik tok','xhs','小红书','threads','youtube'] as $token){
        if(str_contains($v,$token))return true;
    }
    return false;
}
function v1361011_owner_snapshot(array $customerSegments): array {
    $empty=['range'=>v135_analysis_range(),'groups'=>[],'channels'=>[],'staff'=>[],'accounts'=>[],'summary'=>[
        'customers'=>0,'matched'=>0,'booked_customers'=>0,'bookings'=>0,'arrived_customers'=>0,'arrived_visits'=>0,
        'repeat_customers'=>0,'loyal_customers'=>0,'completed_visits'=>0,'revenue'=>0.0,'raw_link_opens'=>0,'avg_revenue_per_customer'=>0.0
    ]];
    $m=$empty;
    try{if(function_exists('v13611_marketing_analytics_dataset'))$m=v13611_marketing_analytics_dataset();}catch(Throwable $ignore){$m=$empty;}
    $segments=is_array($customerSegments['segments']??null)?$customerSegments['segments']:['new'=>[],'random'=>[],'specified'=>[]];
    $newRows=is_array($segments['new']??null)?$segments['new']:[];
    $socialNew=[];
    foreach($newRows as $row){if(v1361011_is_social_channel((string)($row['source']??'')))$socialNew[]=$row;}

    $channels=[];
    foreach(($m['channels']??[]) as $key=>$g){
        if(strtolower(trim((string)($g['label']??$key)))==='unknown')continue;
        $channels[$key]=$g;
    }
    $bestChannel=$channels?reset($channels):null;
    $staff=is_array($m['staff']??null)?$m['staff']:[];
    $bestStaff=$staff?reset($staff):null;

    $conversion=[];
    foreach(($m['groups']??[]) as $g){
        $customers=(int)($g['customers']??0);if($customers<=0)continue;
        $channel=(string)($g['channel']??'Unknown');if(strtolower(trim($channel))==='unknown')continue;
        $g['arrival_rate']=((int)($g['arrived_customers']??0)/$customers)*100;
        $g['booking_rate']=((int)($g['booked_customers']??0)/$customers)*100;
        $conversion[]=$g;
    }
    usort($conversion,static fn($a,$b)=>($b['arrival_rate']<=>$a['arrival_rate'])?:($b['booking_rate']<=>$a['booking_rate'])?:($b['revenue']<=>$a['revenue'])?:($b['customers']<=>$a['customers']));
    $bestConversion=$conversion[0]??null;

    $socialGroups=[];$socialRevenue=0.0;$socialCustomers=0;
    foreach(($m['groups']??[]) as $g){
        if(!v1361011_is_social_channel((string)($g['channel']??'')))continue;
        $socialGroups[]=$g;$socialRevenue+=(float)($g['revenue']??0);$socialCustomers+=(int)($g['customers']??0);
    }
    usort($socialGroups,static fn($a,$b)=>($b['revenue']<=>$a['revenue'])?:($b['customers']<=>$a['customers']));
    $ms=is_array($m['summary']??null)?$m['summary']:$empty['summary'];
    $mc=max(0,(int)($ms['customers']??0));
    return [
        'marketing'=>$m,'new_rows'=>$newRows,'social_new_rows'=>$socialNew,'best_channel'=>$bestChannel,'best_staff'=>$bestStaff,
        'conversion_rows'=>$conversion,'best_conversion'=>$bestConversion,'social_groups'=>$socialGroups,'social_revenue'=>$socialRevenue,'social_customers'=>$socialCustomers,
        'repeat_rate'=>$mc>0?((int)($ms['repeat_customers']??0)/$mc*100):0.0,
        'loyal_rate'=>$mc>0?((int)($ms['loyal_customers']??0)/$mc*100):0.0,
        'arrive_rate'=>$mc>0?((int)($ms['arrived_customers']??0)/$mc*100):0.0,
    ];
}
function v1361011_source_rows_table(array $rows,bool $includeCustomerValue=true): string {
    if(!$rows)return '<div class="empty compact-empty">本期还没有可显示的数据。</div>';
    ob_start();?><div class="history-table-scroll owner-overview-table"><table class="data-table compact"><thead><tr><th>来源</th><th>账号 / 员工</th><th>顾客</th><th>预约</th><th>到店</th><th>回头</th><th>忠诚</th><th>Revenue</th><?php if($includeCustomerValue):?><th>RM / 客</th><?php endif;?></tr></thead><tbody><?php foreach($rows as $g):$c=max(1,(int)($g['customers']??0));?><tr><td><strong><?=e((string)($g['channel']??$g['label']??'Unknown'))?></strong><small><?=e(ucfirst((string)($g['placement']??'')))?></small></td><td><?=e((string)($g['account']??'—'))?><small><?=e((string)($g['staff']??'—'))?></small></td><td><?=number_format((int)($g['customers']??0))?></td><td><?=number_format((int)($g['booked_customers']??0))?></td><td><?=number_format((int)($g['arrived_customers']??0))?></td><td><?=number_format((int)($g['repeat_customers']??0))?></td><td><?=number_format((int)($g['loyal_customers']??0))?></td><td><strong><?=money((float)($g['revenue']??0))?></strong></td><?php if($includeCustomerValue):?><td><?=money((float)($g['revenue']??0)/$c)?></td><?php endif;?></tr><?php endforeach;?></tbody></table></div><?php return (string)ob_get_clean();
}

function v135_page_analytics(): void {
    if(!v13_is_owner()){echo '<section class="card" style="padding:24px"><h2>经营分析</h2><p>仅老板可查看。</p></section>';return;}
    $d=v135_analytics_dataset();$r=$d['range'];$s=$d['summary'];$period=$r['period'];$anchor=$r['anchor'];$totalService=max(0.01,(float)$s['service_revenue']);
    $cs=$d['customer_segments']??['total'=>0,'segments'=>['new'=>[],'random'=>[],'specified'=>[]],'sources'=>[],'ages'=>[],'ethnicities'=>[],'genders'=>[]];
    $seg=$cs['segments'];$ct=max(1,(int)$cs['total']);$owner=v1361011_owner_snapshot($cs);$md=$owner['marketing'];$ms=$md['summary']??[];
    $bestChannel=$owner['best_channel'];$bestStaff=$owner['best_staff'];$bestConversion=$owner['best_conversion'];
    $bestChannelName=$bestChannel?(string)($bestChannel['label']??'—'):'—';$bestStaffName=$bestStaff?(string)($bestStaff['label']??'—'):'—';
    $bestConversionLabel=$bestConversion?trim((string)($bestConversion['channel']??'').' · '.(string)($bestConversion['account']??'')):'—';
    if($bestConversionLabel===' · ')$bestConversionLabel='—';
    ?>
    <div class="page-head"><div><span class="eyebrow">BUSINESS ANALYTICS · OWNER OVERVIEW</span><h1>经营分析</h1><p><?=e((string)(current_store()['name']??'当前分行'))?> · 先看老板摘要，再按需要展开经营明细或 Marketing 深层分析。</p></div><div class="page-head-actions"><form method="get" class="analytics-period-form"><input type="hidden" name="page" value="analytics"><div class="segmented-control"><button name="period" value="day" class="<?=$period==='day'?'active':''?>">日</button><button name="period" value="month" class="<?=$period==='month'?'active':''?>">月</button><button name="period" value="year" class="<?=$period==='year'?'active':''?>">年</button></div><input class="input" type="date" name="anchor" value="<?=e($anchor)?>"><button class="btn btn-light">查看</button></form><a class="btn btn-light" href="index.php?page=marketing_analytics&period=<?=e($period)?>&anchor=<?=e($anchor)?>">Marketing 来源分析 →</a><a class="btn btn-primary" href="index.php?action=export_analytics_v135&period=<?=e($period)?>&anchor=<?=e($anchor)?>">导出报告</a></div></div>

    <section class="card owner-overview-panel"><div class="card-head owner-overview-head"><div><span class="card-kicker">OWNER SNAPSHOT</span><h3><?=$r['label']?> 老板重点</h3><p>卡片只放需要马上判断的数字；点击任何卡片用小浮窗看来源与顾客明细。</p></div><span class="badge badge-gold"><?=intval($cs['total'])?> 位本期到店顾客</span></div>
      <div class="owner-insight-grid">
        <button type="button" class="owner-insight-card" data-v1350-modal-open="customer-segment-new"><span>本期新客</span><strong><?=count($owner['new_rows'])?> 位</strong><small>第一次完成到店</small><b>查看顾客 →</b></button>
        <button type="button" class="owner-insight-card" data-v1350-modal-open="owner-social-new"><span>社媒新客</span><strong><?=count($owner['social_new_rows'])?> 位</strong><small>首次来源匹配社交媒体</small><b>查看来源 →</b></button>
        <button type="button" class="owner-insight-card" data-v1350-modal-open="owner-best-channel"><span>最佳来源平台</span><strong><?=e($bestChannelName)?></strong><small><?=$bestChannel?number_format((int)($bestChannel['customers']??0)).' 位首触顾客 · '.money((float)($bestChannel['revenue']??0)):'暂无来源数据'?></small><b>比较平台 →</b></button>
        <button type="button" class="owner-insight-card" data-v1350-modal-open="owner-best-staff"><span>最佳员工 IP</span><strong><?=e($bestStaffName)?></strong><small><?=$bestStaff?number_format((int)($bestStaff['customers']??0)).' 位首触顾客 · '.money((float)($bestStaff['revenue']??0)):'暂无员工 IP 数据'?></small><b>查看排名 →</b></button>
        <button type="button" class="owner-insight-card" data-v1350-modal-open="owner-best-conversion"><span>最高到店转化</span><strong><?=$bestConversion?number_format((float)($bestConversion['arrival_rate']??0),1).'%':'—'?></strong><small><?=e($bestConversionLabel)?></small><b>比较来源 →</b></button>
        <button type="button" class="owner-insight-card" data-v1350-modal-open="owner-lifecycle"><span>回头客率</span><strong><?=number_format((float)$owner['repeat_rate'],1)?>%</strong><small><?=number_format((int)($ms['repeat_customers']??0))?> / <?=number_format((int)($ms['customers']??0))?> 首触顾客</small><b>看生命周期 →</b></button>
        <button type="button" class="owner-insight-card" data-v1350-modal-open="owner-lifecycle"><span>指定理发师转化率</span><strong><?=number_format((float)$owner['loyal_rate'],1)?>%</strong><small><?=number_format((int)($ms['loyal_customers']??0))?> 位忠诚客</small><b>看生命周期 →</b></button>
        <button type="button" class="owner-insight-card owner-insight-revenue" data-v1350-modal-open="owner-social-revenue"><span>社媒归因 Revenue</span><strong><?=money((float)$owner['social_revenue'])?></strong><small><?=number_format((int)$owner['social_customers'])?> 位社媒首触顾客</small><b>查看来源价值 →</b></button>
      </div>
    </section>

    <details class="card owner-analytics-detail"><summary><span><b>经营详细指标</b><small>营业额、订单、客单价、Walk-in、产品与成本</small></span><strong>展开 / 收起</strong></summary><div class="owner-analytics-detail-body"><section class="stats analytics-summary-grid"><?php foreach([['营业额','revenue'],['完成订单','orders'],['顾客人数','customers'],['平均客单价','avg_ticket'],['预约订单','appointments'],['Walk-in','walkins'],['产品销售','product_revenue'],['服务营业额','service_revenue'],['材料成本','material_cost'],['产品成本','product_cost']] as [$label,$key]):?><div class="stat"><span><?=e($label)?></span><strong><?=in_array($key,['orders','customers','appointments','walkins'],true)?number_format((float)$s[$key],0):money($s[$key])?></strong><small><?=$r['label']?></small></div><?php endforeach;?></section></div></details>
    <section class="card analytics-l-report"><div class="card-head"><div><span class="card-kicker">L-SHAPED OPERATING REPORT</span><h3><?=$r['label']?> 经营表</h3></div></div><div class="history-table-scroll"><table class="data-table"><thead><tr><th><?=$period==='year'?'月份':($period==='day'?'小时':'日期')?></th><th>营业额</th><th>服务</th><th>产品</th><th>订单</th><th>Avg Ticket</th></tr></thead><tbody><?php foreach($d['groups'] as $g):?><tr><td><?=e($g['label'])?></td><td><strong><?=money($g['revenue'])?></strong></td><td><?=money($g['service'])?></td><td><?=money($g['product'])?></td><td><?=intval($g['orders'])?></td><td><?=money($g['orders']?$g['revenue']/$g['orders']:0)?></td></tr><?php endforeach;?></tbody></table><?php if(!$d['groups']):?><div class="empty">这个期间还没有已付款订单。</div><?php endif;?></div></section>
    <div class="analytics-detail-grid"><section class="card"><div class="card-head"><div><span class="card-kicker">SERVICE PERFORMANCE</span><h3>服务项目表现</h3></div></div><div class="history-table-scroll"><table class="data-table"><thead><tr><th>服务</th><th>次数</th><th>Revenue</th><th>占比</th></tr></thead><tbody><?php foreach(array_slice($d['services'],0,30,true) as $name=>$x):?><tr><td><?=e($name)?></td><td><?=intval($x['count'])?></td><td><?=money($x['revenue'])?></td><td><?=number_format(((float)$x['revenue']/$totalService)*100,1)?>%</td></tr><?php endforeach;?></tbody></table></div></section><section class="card"><div class="card-head"><div><span class="card-kicker">PRODUCT PERFORMANCE</span><h3>产品表现</h3></div></div><div class="history-table-scroll"><table class="data-table"><thead><tr><th>产品</th><th>销量</th><th>销售额</th><th>毛利</th></tr></thead><tbody><?php foreach(array_slice($d['products'],0,30,true) as $name=>$x):?><tr><td><?=e($name)?></td><td><?=number_format((float)$x['qty'],2)?></td><td><?=money($x['revenue'])?></td><td><?=money((float)$x['revenue']-(float)$x['cost'])?></td></tr><?php endforeach;?></tbody></table></div></section></div>
    <section class="card customer-segment-analytics"><div class="card-head customer-segment-head"><div><span class="card-kicker">CUSTOMER STRUCTURE ANALYSIS</span><h3>顾客结构分析</h3><p>人数按当前筛选期间实际到店顾客计算；点任何分类卡片会打开小浮窗查看顾客明细、首次媒体来源、年龄分段、种族与性别。</p></div><span class="badge badge-gold"><?=intval($cs['total'])?> 位活跃顾客</span></div>
      <div class="customer-segment-cards">
        <?php foreach([['new','01','首次到店新客','第一次来店；重点看首次媒体来源与人口资料'],['random','02','回访 · 随机／未固定型','累计 2 次以上，随机/系统分配次数 ≥ 指定次数'],['specified','03','指定理发师忠诚客','累计 2 次以上，并且指定理发师次数 > 随机次数']] as [$key,$no,$title,$desc]):$n=count($seg[$key]??[]);$pct=$cs['total']?($n/$cs['total']*100):0;?>
        <button type="button" class="customer-segment-card customer-segment-trigger segment-<?=$key?>" data-v1350-modal-open="customer-segment-<?=$key?>" aria-label="查看 <?=e($title)?> 详细资料"><span class="segment-number"><?=$no?></span><div><span class="card-kicker"><?=e($title)?></span><strong><?=$n?> 位</strong><p><?=e($desc)?></p><span class="segment-open-hint">点击查看详细资料 →</span></div><b><?=number_format($pct,1)?>%</b></button>
        <?php endforeach;?>
      </div>
      <div class="customer-segment-note"><strong>首次来源规则</strong><span><?=e((string)($cs['legacy_note']??''))?></span></div>
    </section>

    <div class="commission-modal customer-segment-modal" hidden aria-hidden="true" data-v1350-modal="owner-social-new"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog customer-segment-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">SOCIAL NEW CUSTOMERS</span><h3>社媒带来的本期新客 · <?=count($owner['social_new_rows'])?> 位</h3><p>只认顾客第一次 WhatsApp 来源；同手机号重复发送、之后改从其他平台进入，都不会重复人数或覆盖第一次来源。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><div class="history-table-scroll owner-overview-table"><table class="data-table compact"><thead><tr><th>顾客</th><th>首次来源</th><th>账号 / 来源员工</th><th>年龄</th><th>性别</th><th>种族</th><th>最近到店</th></tr></thead><tbody><?php foreach($owner['social_new_rows'] as $row):?><tr><td><strong><?=e((string)$row['name'])?></strong><small><?=e((string)$row['phone'])?></small></td><td><strong><?=e((string)($row['source']??'未记录'))?></strong><small><?=e((string)($row['source_placement']??'profile'))?></small></td><td><?=e((string)($row['source_account']??'—'))?><small><?=e((string)($row['source_staff']??'—'))?></small></td><td><?=$row['age']===null?'—':intval($row['age'])?><small><?=e((string)($row['age_band']??'未填写'))?></small></td><td><?=e((string)($row['gender_label']??'未填写'))?></td><td><?=e((string)($row['ethnicity_label']??'未填写'))?></td><td><?=e((string)($row['last_visit']??'—'))?></td></tr><?php endforeach;?><?php if(!$owner['social_new_rows']):?><tr><td colspan="7"><div class="empty compact-empty">本期还没有匹配到社交媒体首次来源的新客。</div></td></tr><?php endif;?></tbody></table></div></div></section></div>

    <div class="commission-modal customer-segment-modal" hidden aria-hidden="true" data-v1350-modal="owner-best-channel"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog customer-segment-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">CHANNEL QUALITY</span><h3>来源平台比较</h3><p>最佳平台优先看归因营业额，再看去重后的首触顾客人数；Unknown 不参加最佳来源排名。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><div class="history-table-scroll owner-overview-table"><table class="data-table compact"><thead><tr><th>平台</th><th>首触顾客</th><th>有预约</th><th>到店</th><th>回头</th><th>忠诚</th><th>Revenue</th></tr></thead><tbody><?php foreach(($md['channels']??[]) as $g):$ch=(string)($g['label']??'Unknown');if(strtolower(trim($ch))==='unknown')continue;?><tr><td><strong><?=e($ch)?></strong></td><td><?=number_format((int)($g['customers']??0))?></td><td><?=number_format((int)($g['booked_customers']??0))?></td><td><?=number_format((int)($g['arrived_customers']??0))?></td><td><?=number_format((int)($g['repeat_customers']??0))?></td><td><?=number_format((int)($g['loyal_customers']??0))?></td><td><strong><?=money((float)($g['revenue']??0))?></strong></td></tr><?php endforeach;?></tbody></table></div></div></section></div>

    <div class="commission-modal customer-segment-modal" hidden aria-hidden="true" data-v1350-modal="owner-best-staff"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog customer-segment-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">STAFF IP QUALITY</span><h3>员工 Personal IP 排名</h3><p>这里比较员工经营媒体账号实际带来的首触顾客质量，不会把重复 WhatsApp 消息当成更多顾客。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><div class="history-table-scroll owner-overview-table"><table class="data-table compact"><thead><tr><th>员工</th><th>首触顾客</th><th>有预约</th><th>到店</th><th>回头</th><th>忠诚</th><th>Revenue</th></tr></thead><tbody><?php foreach(($md['staff']??[]) as $g):?><tr><td><strong><?=e((string)($g['label']??'—'))?></strong></td><td><?=number_format((int)($g['customers']??0))?></td><td><?=number_format((int)($g['booked_customers']??0))?></td><td><?=number_format((int)($g['arrived_customers']??0))?></td><td><?=number_format((int)($g['repeat_customers']??0))?></td><td><?=number_format((int)($g['loyal_customers']??0))?></td><td><strong><?=money((float)($g['revenue']??0))?></strong></td></tr><?php endforeach;?><?php if(!($md['staff']??[])):?><tr><td colspan="7"><div class="empty compact-empty">本期没有员工 Personal IP 首次来源。</div></td></tr><?php endif;?></tbody></table></div></div></section></div>

    <div class="commission-modal customer-segment-modal" hidden aria-hidden="true" data-v1350-modal="owner-best-conversion"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog customer-segment-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">ARRIVAL CONVERSION</span><h3>最高到店转化来源</h3><p>到店转化 = 至少到店 1 次的顾客 ÷ 去重后的第一次 WhatsApp 顾客。Link Click 完全不参与。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><div class="history-table-scroll owner-overview-table"><table class="data-table compact"><thead><tr><th>平台 / 账号</th><th>员工</th><th>位置</th><th>顾客</th><th>预约率</th><th>到店率</th><th>Revenue</th></tr></thead><tbody><?php foreach($owner['conversion_rows'] as $g):?><tr><td><strong><?=e((string)($g['channel']??'Unknown'))?></strong><small><?=e((string)($g['account']??'—'))?></small></td><td><?=e((string)($g['staff']??'—'))?></td><td><?=e(ucfirst((string)($g['placement']??'direct')))?></td><td><?=number_format((int)($g['customers']??0))?></td><td><?=number_format((float)($g['booking_rate']??0),1)?>%</td><td><strong><?=number_format((float)($g['arrival_rate']??0),1)?>%</strong></td><td><?=money((float)($g['revenue']??0))?></td></tr><?php endforeach;?><?php if(!$owner['conversion_rows']):?><tr><td colspan="7"><div class="empty compact-empty">本期还没有可计算转化率的来源。</div></td></tr><?php endif;?></tbody></table></div></div></section></div>

    <div class="commission-modal customer-segment-modal" hidden aria-hidden="true" data-v1350-modal="owner-lifecycle"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog customer-segment-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">CUSTOMER LIFECYCLE</span><h3>首触顾客生命周期</h3><p>这个漏斗只看当前筛选期间第一次 WhatsApp 进入的去重顾客，并持续追踪他们之后的预约、到店、回头和指定理发师忠诚度。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><div class="owner-lifecycle-mini-grid"><div><span>首触顾客</span><strong><?=number_format((int)($ms['customers']??0))?></strong></div><div><span>有预约</span><strong><?=number_format((int)($ms['booked_customers']??0))?></strong></div><div><span>到店</span><strong><?=number_format((int)($ms['arrived_customers']??0))?></strong></div><div><span>回头</span><strong><?=number_format((int)($ms['repeat_customers']??0))?></strong><small><?=number_format((float)$owner['repeat_rate'],1)?>%</small></div><div><span>指定忠诚</span><strong><?=number_format((int)($ms['loyal_customers']??0))?></strong><small><?=number_format((float)$owner['loyal_rate'],1)?>%</small></div><div><span>归因 Revenue</span><strong><?=money((float)($ms['revenue']??0))?></strong></div></div><div class="owner-modal-note"><strong>First Touch 锁定</strong><span>同一手机号重复发消息只算 1 位；以后从其他平台再次进入不会改写第一次来源。</span></div></div></section></div>

    <div class="commission-modal customer-segment-modal" hidden aria-hidden="true" data-v1350-modal="owner-social-revenue"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog customer-segment-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">SOCIAL ATTRIBUTED VALUE</span><h3>社媒带来的 Revenue · <?=money((float)$owner['social_revenue'])?></h3><p>只汇总 Instagram / Facebook / TikTok / XHS / Threads / YouTube 等社交媒体 First Touch；顾客第一次来源锁定后，后续消费继续归回第一次来源。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><?=v1361011_source_rows_table($owner['social_groups'])?></div></section></div>

    <?php foreach([['new','01','首次到店新客'],['random','02','回访 · 随机／未固定型'],['specified','03','指定理发师忠诚客']] as [$key,$no,$title]):
      $rows=$seg[$key]??[];$sourceBreak=[];$ageBreak=[];$ethBreak=[];$genderBreak=[];
      foreach($rows as $row){$sl=(string)($row['source']??'未记录');$al=(string)($row['age_band']??'未填写');$el=(string)($row['ethnicity_label']??'未填写');$gl=(string)($row['gender_label']??'未填写');$sourceBreak[$sl]=($sourceBreak[$sl]??0)+1;$ageBreak[$al]=($ageBreak[$al]??0)+1;$ethBreak[$el]=($ethBreak[$el]??0)+1;$genderBreak[$gl]=($genderBreak[$gl]??0)+1;}arsort($sourceBreak);arsort($ageBreak);arsort($ethBreak);arsort($genderBreak);$rowTotal=max(1,count($rows));?>
    <div class="commission-modal customer-segment-modal" hidden aria-hidden="true" data-v1350-modal="customer-segment-<?=$key?>"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog customer-segment-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">CUSTOMER GROUP <?=$no?></span><h3><?=e($title)?> · <?=count($rows)?> 位</h3><p>手机号与 WhatsApp 首次触达一对一匹配；重复发送不会增加人数，之后从其他平台进入也不会改写首次来源。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content">
      <div class="customer-segment-modal-breakdowns">
        <section><div class="mini-section-head"><h4>首次媒体来源</h4><span>First Touch</span></div><?=v13511_breakdown_rows($sourceBreak,$rowTotal)?></section>
        <section><div class="mini-section-head"><h4>年龄分段</h4><span>Age Range</span></div><?=v13511_breakdown_rows($ageBreak,$rowTotal)?></section>
        <section><div class="mini-section-head"><h4>种族</h4><span>Ethnicity</span></div><?=v13511_breakdown_rows($ethBreak,$rowTotal)?></section>
        <section><div class="mini-section-head"><h4>性别</h4><span>Gender</span></div><?=v13511_breakdown_rows($genderBreak,$rowTotal)?></section>
      </div>
      <div class="history-table-scroll customer-segment-modal-table"><table class="data-table compact"><thead><tr><th>顾客</th><th>首次媒体来源</th><th>年龄</th><th>性别</th><th>种族</th><th>累计到店</th><th>随机</th><th>指定</th><th>常指定</th><th>最近到店</th></tr></thead><tbody>
      <?php foreach($rows as $row):?><tr><td><strong><?=e((string)$row['name'])?></strong><small><?=e((string)$row['phone'])?></small></td><td><strong><?=e((string)($row['source']??'未记录'))?></strong><small><?=e((string)($row['source_detail']??$row['source']??'未记录'))?></small></td><td><?=$row['age']===null?'—':intval($row['age'])?><small><?=e((string)($row['age_band']??'未填写'))?></small></td><td><?=e((string)($row['gender_label']??'未填写'))?></td><td><?=e((string)($row['ethnicity_label']??'未填写'))?></td><td><?=intval($row['visits'])?></td><td><?=intval($row['random'])?></td><td><?=intval($row['specified'])?></td><td><?=e((string)($row['top_stylist']?:'—'))?></td><td><?=e((string)$row['last_visit'])?></td></tr><?php endforeach;?>
      <?php if(!$rows):?><tr><td colspan="10"><div class="empty compact-empty">这个期间没有这一类顾客。</div></td></tr><?php endif;?></tbody></table></div>
    </div></section></div>
    <?php endforeach;?>
    <?php
}

function v13_page_stock_hub(): void {
    if(!v13_is_owner()){echo '<section class="card" style="padding:24px"><h2>产品与库存</h2><p>员工端不开放库存管理。</p></section>';return;}
    $products=v13_product_rows(false);$stock=v13_inventory_map();$bundles=v13_owner_rows('v13_product_bundles','select=id,name,sku,sale_price,active,created_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&order=created_at.desc&limit=500'); ?>
    <div class="page-head"><div><span class="eyebrow">PRODUCTS & INVENTORY · SUPABASE</span><h1>产品与库存</h1><p>库存、销售产品与产品配套统一保存在 Supabase。</p></div></div>
    <section class="stats"><div class="stat"><span>产品</span><strong><?=count($products)?></strong></div><div class="stat"><span>低库存</span><strong><?=count(array_filter($products,fn($p)=>($stock[(string)$p['id']]??0)<=(float)($p['reorder_level']??0)))?></strong></div><div class="stat"><span>配套</span><strong><?=count($bundles)?></strong></div></section>
    <div class="dashboard-grid" style="align-items:start"><section class="card" style="padding:22px"><span class="card-kicker">NEW PRODUCT</span><h3>新增产品／库存货品</h3><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_product_v13"><div class="field"><label>名称</label><input class="input" name="name" required></div><div class="field"><label>SKU</label><input class="input" name="sku"></div><div class="field"><label>分类</label><input class="input" name="category"></div><div class="field"><label>用途</label><input class="input" name="purpose" placeholder="门店耗材 / 零售"></div><div class="field"><label>售价 RM</label><input class="input" type="number" step="0.01" name="sale_price" value="0"></div><div class="field"><label>成本 RM</label><input class="input" type="number" step="0.01" name="cost_price" value="0"></div><div class="field"><label>补货线</label><input class="input" type="number" step="0.01" name="reorder_level" value="0"></div><div class="field"><label>产品抽成 %</label><input class="input" type="number" step="0.01" name="commission_rate" value="0"></div><label class="check-row"><input type="checkbox" name="retail_enabled" value="1" checked>可销售</label><label class="check-row"><input type="checkbox" name="active" value="1" checked>启用</label><div><button class="btn btn-primary">新增产品</button></div></form></section>
    <section class="card" style="padding:22px"><span class="card-kicker">STOCK MOVEMENT</span><h3>进货／库存调整</h3><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="adjust_stock_v13"><div class="field span-2"><label>产品</label><select class="select" name="product_id" required><option value="">选择</option><?php foreach($products as $p):?><option value="<?=e((string)$p['id'])?>"><?=e((string)$p['name'])?> · 当前 <?=number_format($stock[(string)$p['id']]??0,2)?></option><?php endforeach;?></select></div><div class="field"><label>数量变化</label><input class="input" type="number" step="0.01" name="quantity_delta" placeholder="进货 +10 / 扣除 -2" required></div><div class="field"><label>单位成本</label><input class="input" type="number" step="0.01" name="unit_cost" value="0"></div><div class="field span-2"><label>备注</label><input class="input" name="notes"></div><button class="btn btn-primary">写入库存流水</button></form></section></div>
    <section class="card" style="margin-top:18px;overflow:auto"><table class="data-table"><thead><tr><th>产品</th><th>SKU</th><th>当前库存</th><th>补货线</th><th>售价</th><th>成本</th><th>状态</th></tr></thead><tbody><?php foreach($products as $p):$qty=$stock[(string)$p['id']]??0;?><tr><td><strong><?=e((string)$p['name'])?></strong><small style="display:block"><?=e((string)($p['purpose']??''))?></small></td><td><?=e((string)($p['sku']??''))?></td><td class="<?=$qty<=(float)($p['reorder_level']??0)?'text-danger':''?>"><?=number_format($qty,2)?></td><td><?=number_format((float)($p['reorder_level']??0),2)?></td><td><?=money($p['sale_price']??0)?></td><td><?=money($p['cost_price']??0)?></td><td><?=!empty($p['active'])?'启用':'停用'?></td></tr><?php endforeach;?></tbody></table></section>
    <section class="card" style="margin-top:18px;padding:22px"><span class="card-kicker">PRODUCT BUNDLES</span><h3>产品配套</h3><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_bundle_v13"><div class="field"><label>配套名称</label><input class="input" name="name" required></div><div class="field"><label>售价</label><input class="input" name="sale_price" type="number" step="0.01"></div><label class="check-row"><input type="checkbox" name="active" value="1" checked>启用</label><div><button class="btn btn-primary">新增配套</button></div></form><div class="chip-list" style="margin-top:16px"><?php foreach($bundles as $b):?><span class="chip"><?=e((string)$b['name'])?> · <?=money($b['sale_price']??0)?></span><?php endforeach;?></div></section>
    <?php
}

function v13_page_kpi(): void {
    if(!v13_is_owner()){
        $rows=v13_employee_api('performance'); ?>
        <div class="page-head"><div><span class="eyebrow">MY KPI</span><h1>我的 KPI</h1><p>这里只显示你自己的 KPI 与业绩基础数据。</p></div></div>
        <section class="v1350-dashboard-data-grid"><article class="v1350-data-tile"><div class="v1350-data-icon"><?=ui_icon('chart')?></div><div><span>服务贡献</span><strong><?=money($rows['service_performance']??0)?></strong></div></article><article class="v1350-data-tile"><div class="v1350-data-icon"><?=ui_icon('award')?></div><div><span>产品抽成</span><strong><?=money($rows['product_commission']??0)?></strong></div></article></section>
        <?php return;
    }
    $employees=v13_employee_rows_owner();
    $rules=v13_owner_rows('v13_kpi_rules','select=id,name,metric_type,target_value,bonus_amount,active,created_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&order=created_at.desc&limit=500');
    $assignments=v13_owner_rows('v13_kpi_assignments','select=id,employee_id,rule_id,effective_from,effective_to,target_value,bonus_amount,status,active&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&active=eq.true&limit=5000');
    $counts=[];foreach($assignments as $a){$eid=(string)($a['employee_id']??'');$counts[$eid]=($counts[$eid]??0)+1;}
    ?>
    <div class="page-head"><div><span class="eyebrow">EMPLOYEE KPI CENTER · SUPABASE</span><h1>KPI 管理</h1><p>先选择员工，再进入员工 KPI 页面设定任务、目标与奖金。KPI Template 独立管理，不需要每次重打名称。</p></div><button class="btn btn-light" type="button" data-toggle-panel="kpi-template-panel">管理 KPI Template</button></div>
    <section class="v1350-employee-kpi-grid">
      <?php foreach($employees as $employee):$eid=(string)$employee['id'];?><a class="card v1350-employee-kpi-card" href="index.php?page=kpi_employee&id=<?=e($eid)?>"><div class="customer-large-avatar"><?=e(mb_substr((string)$employee['name'],0,1))?></div><div><span class="card-kicker"><?=e((string)($employee['employee_code']??'STAFF'))?></span><h3><?=e((string)$employee['name'])?></h3><p><?=e((string)($employee['position']??''))?></p><div class="v1350-kpi-card-meta"><span><?=intval($counts[$eid]??0)?> 个进行中 KPI</span><strong>进入设置 →</strong></div></div></a><?php endforeach;?>
      <?php if(!$employees):?><section class="card empty-state"><h3>还没有员工</h3><p>先到员工管理建立员工。</p></section><?php endif;?>
    </section>
    <section class="card collapsible-panel" id="kpi-template-panel" hidden><div class="card-head"><div><span class="card-kicker">KPI TEMPLATE</span><h3>KPI 模板</h3><p>建立后可以分配给不同员工，并为每个员工单独调整目标与奖金。</p></div><button class="panel-close" type="button" data-toggle-panel="kpi-template-panel"><?=ui_icon('x')?></button></div><div class="card-body"><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_kpi_v13"><input type="hidden" name="return_page" value="kpi"><div class="field"><label>KPI 名称</label><input class="input" name="name" required placeholder="例如 月营业额"></div><div class="field"><label>计算方式</label><select class="select" name="metric_type"><option value="service_performance">服务业绩</option><option value="product_sales">产品销售额</option><option value="total_sales">总业绩</option><option value="service_count">完成服务数</option><option value="customer_count">顾客人数</option><option value="avg_ticket">平均客单价</option><option value="requested_count">被指定次数</option><option value="training_completion">培训完成率</option><option value="manual">手动 KPI</option></select></div><div class="field"><label>默认目标</label><input class="input" type="number" step="0.01" min="0" name="target_value" value="0"></div><div class="field"><label>默认奖金 RM</label><input class="input" type="number" step="0.01" min="0" name="bonus_amount" value="0"></div><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" checked><span>启用 Template</span></label><button class="btn btn-primary">建立 Template</button></form><div class="v1350-template-list"><?php foreach($rules as $r):?><div class="v1350-template-row"><div><strong><?=e((string)$r['name'])?></strong><small><?=e((string)$r['metric_type'])?> · 目标 <?=number_format((float)$r['target_value'],2)?> · 奖金 <?=money($r['bonus_amount']??0)?></small></div><span class="badge <?=!empty($r['active'])?'badge-green':'badge-gray'?>"><?=!empty($r['active'])?'启用':'停用'?></span></div><?php endforeach;?></div></div></section>
    <?php
}

function v1350_page_kpi_employee(): void {
    if(!v13_is_owner()){echo '<section class="card empty-state"><h3>没有权限</h3></section>';return;}
    $id=trim((string)($_GET['id']??''));$employees=v13_employee_rows_owner();$employee=null;foreach($employees as $e)if((string)$e['id']===$id)$employee=$e;
    if(!$employee){echo '<section class="card empty-state"><h3>找不到员工</h3></section>';return;}
    $rules=v13_owner_rows('v13_kpi_rules','select=id,name,metric_type,target_value,bonus_amount,active&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&active=eq.true&order=name.asc&limit=500');
    $assignments=v13_owner_rows('v13_kpi_assignments','select=id,rule_id,effective_from,effective_to,target_value,bonus_amount,status,active,created_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&employee_id=eq.'.rawurlencode($id).'&order=effective_from.desc&limit=500');
    $ruleMap=[];foreach($rules as $r)$ruleMap[(string)$r['id']]=$r;
    ?>
    <div class="page-head"><div><a class="back-link" href="index.php?page=kpi">← 返回 KPI 员工名单</a><span class="eyebrow">EMPLOYEE KPI</span><h1><?=e((string)$employee['name'])?></h1><p><?=e((string)($employee['position']??''))?> · 为这位员工单独设置 KPI 任务。</p></div><button class="btn btn-primary" type="button" data-v1350-modal-open="kpi-assignment">＋ 设置 KPI 任务</button></div>
    <section class="v1350-kpi-task-grid"><?php foreach($assignments as $a):$r=$ruleMap[(string)$a['rule_id']]??null;if(!$r)continue;$target=(float)($a['target_value']??0);if($target<=0)$target=(float)($r['target_value']??0);$bonus=(float)($a['bonus_amount']??0);if($bonus<=0)$bonus=(float)($r['bonus_amount']??0);?><article class="card v1350-kpi-task"><div><span class="card-kicker"><?=e((string)$r['metric_type'])?></span><h3><?=e((string)$r['name'])?></h3><p><?=e(app_date((string)$a['effective_from']))?> → <?=!empty($a['effective_to'])?e(app_date((string)$a['effective_to'])):'持续'?></p></div><div class="v1350-kpi-target"><span>目标</span><strong><?=number_format($target,2)?></strong><small>奖金 <?=money($bonus)?></small></div><span class="badge <?=($a['status']??'active')==='achieved'?'badge-green':'badge-gold'?>"><?=e((string)($a['status']??'active'))?></span></article><?php endforeach;?><?php if(!$assignments):?><section class="card empty-state"><h3>这位员工还没有 KPI</h3><p>点击右上角「设置 KPI 任务」。</p></section><?php endif;?></section>
    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="kpi-assignment"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">ASSIGN KPI</span><h3>设置 KPI 任务</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="assign_kpi_v1350"><input type="hidden" name="return_page" value="kpi_employee"><input type="hidden" name="employee_id" value="<?=e($id)?>"><div class="field"><label>KPI Template</label><select class="select" name="rule_id" required><option value="">选择 KPI</option><?php foreach($rules as $r):?><option value="<?=e((string)$r['id'])?>"><?=e((string)$r['name'])?> · 默认 <?=number_format((float)$r['target_value'],2)?></option><?php endforeach;?></select></div><div class="field"><label>月份</label><input class="input" type="month" name="period_month" value="<?=date('Y-m')?>" required></div><div class="field"><label>员工目标值</label><input class="input" type="number" step="0.01" min="0" name="target_value" value="0"><small class="field-help">填 0 时可按 Template 默认目标理解；也可以为这个员工单独设置。</small></div><div class="field"><label>奖金 RM</label><input class="input" type="number" step="0.01" min="0" name="bonus_amount" value="0"></div><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存 KPI 任务</button></div></form></section></div>
    <?php
}

function v13_page_training(): void {
    if(!v13_is_owner()){
        $courses=v13_employee_api('training');$groups=[];foreach($courses as $c){$cat=(string)($c['category']??'通用培训');$groups[$cat][]=$c;} ?>
        <div class="page-head"><div><span class="eyebrow">ROLE BASED TRAINING</span><h1>培训中心</h1><p>系统只显示与你职位 / 角色对应的培训分类与课程。</p></div></div>
        <?php foreach($groups as $cat=>$list):?><section class="v1350-training-section"><div class="section-heading"><div><h2><?=e($cat)?></h2><p><?=count($list)?> 个课程</p></div></div><div class="v1350-training-grid"><?php foreach($list as $c):?><a class="card v1350-training-card" href="index.php?page=training_course&id=<?=e((string)$c['id'])?>"><?php if(!empty($c['cover_image_path'])):?><img src="<?=e((string)$c['cover_image_path'])?>" alt=""><?php endif;?><div><span class="card-kicker"><?=!empty($c['required'])?'REQUIRED':'TRAINING'?> · <?=e((string)($c['status']??'not_started'))?></span><h3><?=e((string)$c['title'])?></h3><p><?=e((string)($c['description']??''))?></p><strong><?=intval($c['progress_percent']??0)?>%</strong></div></a><?php endforeach;?></div></section><?php endforeach;?><?php if(!$courses):?><section class="card empty-state"><h3>目前没有适合你职位的培训课程</h3></section><?php endif;return;
    }
    $courses=v13_owner_rows('v13_training_courses','select=id,title,category,description,content,content_url,cover_image_path,target_roles,estimated_minutes,version_label,required,publication_status,active,created_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&order=category.asc,created_at.desc&limit=1000');
    $groups=[];foreach($courses as $c){$cat=(string)($c['category']??'通用培训');$groups[$cat][]=$c;}
    $roleDefs=function_exists('v132_role_definitions')?v132_role_definitions():[];$roles=[];foreach($roleDefs as $key=>$meta)$roles[$key]=(string)($meta['label']??$key);
    ?>
    <div class="page-head"><div><span class="eyebrow">TRAINING CENTER · SUPABASE</span><h1>培训中心</h1><p>课程按分类与职位发布；主题、简介、照片和视频链接都保留在课程里。</p></div><button class="btn btn-primary" type="button" data-v1350-modal-open="training-course">＋ 建立培训</button></div>
    <?php foreach($groups as $cat=>$list):?><section class="v1350-training-section"><div class="section-heading"><div><h2><?=e($cat)?></h2><p><?=count($list)?> 个课程</p></div></div><div class="v1350-training-grid"><?php foreach($list as $c):$targets=is_array($c['target_roles']??null)?$c['target_roles']:[];?><a class="card v1350-training-card" href="index.php?page=training_course&id=<?=e((string)$c['id'])?>"><?php if(!empty($c['cover_image_path'])):?><img src="<?=e((string)$c['cover_image_path'])?>" alt=""><?php endif;?><div><span class="card-kicker"><?=!empty($c['required'])?'REQUIRED':'OPTIONAL'?> · <?=!empty($c['active'])?'PUBLISHED':'ARCHIVED'?></span><h3><?=e((string)$c['title'])?></h3><p><?=e((string)($c['description']??''))?></p><small><?=empty($targets)?'全部职位':implode(' · ',array_map(fn($r)=>$roles[$r]??$r,$targets))?></small></div></a><?php endforeach;?></div></section><?php endforeach;?><?php if(!$courses):?><section class="card empty-state"><h3>还没有培训课程</h3></section><?php endif;?>
    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="training-course"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">NEW TRAINING</span><h3>建立培训课程</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" enctype="multipart/form-data" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_training_v13"><input type="hidden" name="return_page" value="training"><div class="form-grid"><div class="field"><label>分类 *</label><input class="input" name="category" required placeholder="例如 Colour / Customer Service / Hygiene"></div><div class="field"><label>主题 *</label><input class="input" name="title" required></div><div class="field span-2"><label>简介</label><textarea class="textarea" name="description" rows="3"></textarea></div><div class="field span-2"><label>课程内容</label><textarea class="textarea" name="content" rows="6" placeholder="文字步骤 / 注意事项 / 课程重点"></textarea></div><div class="field span-2"><label>视频 URL</label><input class="input" name="content_url" placeholder="YouTube / Vimeo / Supabase Storage URL"><small class="field-help">视频建议放外部视频平台或独立 Storage，不把视频二进制写入数据库。</small></div><div class="field span-2"><label>封面 / 教学照片</label><div class="v1351-media-upload" data-v1351-media-upload><div class="v1351-media-preview"><img hidden alt="培训图片预览" data-v1351-image-preview><span data-v1351-image-empty>尚未选择照片<br>可上传课程封面 / 教学图</span></div><div class="v1351-media-control"><strong>选择培训照片</strong><input class="input" type="file" name="cover_image_file" accept="image/jpeg,image/png,image/webp" data-v1351-image-input><small>图片会压缩后存到独立 Supabase Storage <code>salonos-media</code>；数据库只保存 URL。视频仍建议使用 YouTube / Vimeo 或独立 Storage URL。</small></div></div></div><div class="field"><label>预计分钟</label><input class="input" type="number" min="0" name="estimated_minutes" value="0"></div><div class="field"><label>Version</label><input class="input" name="version_label" placeholder="例如 2026.1"></div><div class="field span-2"><label>对应职位（不选 = 全部职位）</label><div class="v1350-role-checks"><?php foreach($roles as $key=>$label):?><label class="confirm-checkbox"><input type="checkbox" name="target_roles[]" value="<?=e($key)?>"><span><?=e($label)?></span></label><?php endforeach;?></div></div><label class="confirm-checkbox"><input type="checkbox" name="required" value="1"><span>Required Training</span></label><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" checked><span>立即发布</span></label></div><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">建立培训</button></div></form></section></div>
    <?php
}

function v13_page_commission(): void {
    if(!v13_is_owner()){echo '<section class="card" style="padding:24px"><h2>抽成管理</h2><p>员工可在「员工业绩」查看自己的结果，抽成规则由老板管理。</p></section>';return;}
    $settings=v13_owner_rows('service_commission_settings','select=organization_id,mode,fixed_rate,updated_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&limit=1');$s=$settings[0]??['mode'=>'fixed','fixed_rate'=>0];$tiers=v13_owner_rows('service_commission_tiers','select=id,tier_name,min_monthly_performance,max_monthly_performance,commission_rate,active&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&order=min_monthly_performance.asc&limit=100'); ?>
    <div class="page-head"><div><span class="eyebrow">COMMISSION · SUPABASE</span><h1>抽成管理</h1><p>服务抽成规则、阶梯和已发放历史全部由 Supabase 管理。</p></div></div><section class="card" style="padding:22px"><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_commission_v13"><div class="field"><label>模式</label><select class="select" name="mode"><option value="fixed" <?=($s['mode']??'')==='fixed'?'selected':''?>>统一比例</option><option value="tiered" <?=($s['mode']??'')==='tiered'?'selected':''?>>业绩阶梯</option></select></div><div class="field"><label>统一服务抽成 %</label><input class="input" type="number" step="0.01" min="0" max="100" name="fixed_rate" value="<?=e((string)($s['fixed_rate']??0))?>"></div><button class="btn btn-primary">保存规则</button></form></section><section class="card" style="margin-top:18px;overflow:auto"><table class="data-table"><thead><tr><th>阶梯</th><th>最低业绩</th><th>最高业绩</th><th>比例</th><th>状态</th></tr></thead><tbody><?php foreach($tiers as $t):?><tr><td><?=e((string)$t['tier_name'])?></td><td><?=money($t['min_monthly_performance']??0)?></td><td><?=isset($t['max_monthly_performance'])&&$t['max_monthly_performance']!==null?money($t['max_monthly_performance']):'以上'?></td><td><?=number_format((float)($t['commission_rate']??0),2)?>%</td><td><?=!empty($t['active'])?'启用':'停用'?></td></tr><?php endforeach;?></tbody></table></section><?php
}

function v13_page_branches(): void {
    if(!v13_is_owner()){echo '<section class="card" style="padding:24px"><h2>分行管理</h2><p>仅主老板可管理分行。</p></section>';return;}
    $identity=salonos_supabase_identity()??[];
    $stores=$identity['stores']??[];
    $subs=v13_owner_rows('saas_subscriptions','select=id,store_id,subscription_type,plan_code,amount_rm,billing_months,status,starts_at,expires_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&order=created_at.asc&limit=200');
    $by=[];foreach($subs as $s)if(!empty($s['store_id']))$by[(string)$s['store_id']]=$s;
    $autoOpen=((string)($_GET['new_branch']??''))==='1';
    ?>
    <div class="page-head responsive-page-head v1338-branch-page-head">
      <div><span class="eyebrow">MULTI BRANCH · SUPABASE</span><h1>分行管理</h1><p>查看所有分行与订阅状态。需要新增分行时，不会离开这个页面。</p></div>
      <button class="btn btn-primary" type="button" data-v1350-modal-open="branch-create">＋ 新增分行</button>
    </div>

    <div class="v13-board-grid v1338-branch-grid">
      <?php foreach($stores as $st):$sub=$by[(string)$st['id']]??null;?>
        <article class="card v1338-branch-card">
          <div class="v1338-branch-card-head"><div><span class="card-kicker"><?=!empty($st['is_main'])?'MAIN STORE':'BRANCH'?></span><h3><?=e((string)$st['name'])?></h3><p><?=e((string)($st['code']??''))?> · <?=e((string)($st['status']??''))?></p></div><span class="badge <?=((string)($st['status']??''))==='active'?'badge-green':'badge-gray'?>"><?=e((string)($st['status']??'unknown'))?></span></div>
          <div class="mini-metrics"><div><span>订阅</span><strong><?=e((string)($sub['plan_code']??(!empty($st['is_main'])?'owner':'未绑定')))?></strong></div><div><span>状态</span><strong><?=e((string)($sub['status']??'—'))?></strong></div><div><span>到期</span><strong><?=!empty($sub['expires_at'])?e(app_date((string)$sub['expires_at'],true)):'—'?></strong></div></div>
        </article>
      <?php endforeach;?>
    </div>

    <section class="card v1338-branch-create-card">
      <div class="v1338-branch-create-copy"><span class="card-kicker">ADD BRANCH</span><h3>建立新分行</h3><p>先在 Creator 的「分行订阅」生成 5 分钟 BRN Code。拿到 Code 后，老板可以直接在这里建立分行账号，不需要跳去注册页面。</p><div class="v1338-branch-hints"><span>① Creator 生成 BRN Code</span><span>② 填分行资料</span><span>③ 建立登录账号</span></div></div>
      <button class="btn btn-primary" type="button" data-v1350-modal-open="branch-create">新增分行 →</button>
    </section>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="branch-create" data-v1338-branch-modal>
      <div class="commission-modal-backdrop" data-v1350-modal-close></div>
      <section class="commission-modal-dialog v1338-branch-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="v1338-branch-modal-title">
        <div class="commission-modal-header v1338-branch-modal-header">
          <div><span class="card-kicker">NEW BRANCH</span><h3 id="v1338-branch-modal-title">新增分行账号</h3><p>建立后会自动加入当前公司，不会离开分行管理。</p></div>
          <button class="panel-close" type="button" data-v1350-modal-close aria-label="关闭"><?=ui_icon('x')?></button>
        </div>
        <form method="post" class="commission-modal-content v1338-branch-modal-content" data-v1338-branch-form novalidate>
          <input type="hidden" name="csrf" value="<?=csrf_token()?>">
          <input type="hidden" name="action" value="create_branch_modal_v1338">
          <input type="hidden" name="return_page" value="branches">

          <div class="v1338-branch-steps" aria-label="建立分行步骤">
            <button type="button" class="is-active" data-v1338-step-dot="1"><span>1</span><small>分行资料</small></button>
            <i></i><button type="button" data-v1338-step-dot="2"><span>2</span><small>登录账号</small></button>
            <i></i><button type="button" data-v1338-step-dot="3"><span>3</span><small>确认建立</small></button>
          </div>

          <section class="v1338-branch-step" data-v1338-branch-step="1">
            <div class="v1338-step-heading"><span>STEP 1 OF 3</span><h4>分行资料</h4><p>BRN Code 由 Creator 为这家分行生成，有效期 5 分钟。</p></div>
            <div class="field span-2"><div class="v1338-field-label"><label>BRN Code *</label><button type="button" class="v1338-help-link" data-v1338-help-toggle>什么是 BRN Code？</button></div><input class="input license-code-input" name="branch_code" placeholder="BRN-XXXX-XXXX" autocomplete="one-time-code" required><div class="v1338-inline-help" hidden data-v1338-help-panel><strong>BRN Code 在哪里拿？</strong><p>到 Creator →「分行订阅」，输入分行名称、登录 Email 和方案后生成。Code 只在 5 分钟内有效。</p></div></div>
            <div class="field"><label>分行名称 *</label><input class="input" name="branch_name" placeholder="例如 Pavilion KL" autocomplete="organization" required></div>
            <div class="field"><label>联系电话</label><input class="input" name="phone" inputmode="tel" placeholder="例如 03-1234 5678"></div>
            <div class="field span-2"><label>分行地址</label><textarea class="textarea" name="address" rows="3" placeholder="门店地址（可稍后再补）"></textarea></div>
            <div class="v1338-step-actions"><span></span><button class="btn btn-primary" type="button" data-v1338-branch-next>下一步：登录账号 →</button></div>
          </section>

          <section class="v1338-branch-step" data-v1338-branch-step="2" hidden>
            <div class="v1338-step-heading"><span>STEP 2 OF 3</span><h4>建立分行登录账号</h4><p>这个 Email 和密码将用于该分行管理员登录 SalonOS。</p></div>
            <div class="field span-2"><label>分行 Email *</label><input class="input" type="email" name="email" placeholder="branch@example.com" autocomplete="email" required></div>
            <div class="field"><label>密码 *</label><input class="input" type="password" name="password" minlength="8" autocomplete="new-password" placeholder="至少 8 位" required></div>
            <div class="field"><label>再次输入密码 *</label><input class="input" type="password" name="password_confirm" minlength="8" autocomplete="new-password" placeholder="再次输入" required></div>
            <div class="v1338-password-note">建议使用至少 8 位，并混合字母与数字。SalonOS 不会在页面上显示已保存密码。</div>
            <div class="v1338-step-actions"><button class="btn btn-light" type="button" data-v1338-branch-prev>← 返回</button><button class="btn btn-primary" type="button" data-v1338-branch-next>下一步：确认资料 →</button></div>
          </section>

          <section class="v1338-branch-step" data-v1338-branch-step="3" hidden>
            <div class="v1338-step-heading"><span>STEP 3 OF 3</span><h4>确认建立</h4><p>确认以下资料。建立后，这家分行会自动加入当前 Organization。</p></div>
            <div class="v1338-branch-summary">
              <div><span>分行名称</span><strong data-v1338-summary="branch_name">—</strong></div>
              <div><span>登录 Email</span><strong data-v1338-summary="email">—</strong></div>
              <div><span>联系电话</span><strong data-v1338-summary="phone">—</strong></div>
              <div><span>地址</span><strong data-v1338-summary="address">—</strong></div>
              <div class="span-2"><span>BRN Code</span><strong data-v1338-summary="branch_code">—</strong><small>提交时才会验证是否有效及是否属于正确 Organization。</small></div>
            </div>
            <label class="confirm-checkbox v1338-confirm"><input type="checkbox" data-v1338-confirm-check required><span>我确认分行名称与登录 Email 正确。</span></label>
            <div class="v1338-step-actions"><button class="btn btn-light" type="button" data-v1338-branch-prev>← 返回修改</button><button class="btn btn-primary" type="submit" data-v1338-branch-submit>确认并建立分行</button></div>
          </section>
        </form>
      </section>
    </div>
    <?php if($autoOpen):?><button type="button" hidden data-v1350-modal-open="branch-create" data-v1338-auto-open-branch></button><?php endif;?>
    <?php
}

function v13_page_settings(): void {
    if(!v13_is_owner()){echo '<section class="card" style="padding:24px"><h2>系统设置</h2><p>员工设置由老板控制。</p></section>';return;}
    $rows=v13_owner_rows('v13_organization_settings','select=general,role_permissions,whatsapp&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&limit=1');$s=$rows[0]??[];$g=is_array($s['general']??null)?$s['general']:[];$w=is_array($s['whatsapp']??null)?$s['whatsapp']:[]; ?>
    <div class="page-head"><div><span class="eyebrow">SYSTEM SETTINGS · SUPABASE</span><h1>系统设置</h1><p>通用设置、角色权限和 WhatsApp 配置都保存在 Supabase。</p></div></div>
    <div class="settings-grid"><section class="card" style="padding:22px"><span class="card-kicker">GENERAL</span><h3>门店通用设置</h3><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_settings_v13"><input type="hidden" name="settings_section" value="general"><div class="field"><label>语言</label><select class="select" name="language"><option value="zh" <?=($g['language']??'zh')==='zh'?'selected':''?>>中文</option><option value="en" <?=($g['language']??'')==='en'?'selected':''?>>English</option></select></div><div class="field"><label>时区</label><input class="input" name="timezone" value="<?=e((string)($g['timezone']??'Asia/Kuala_Lumpur'))?>"></div><div class="field"><label>货币</label><input class="input" name="currency" value="<?=e((string)($g['currency']??'MYR'))?>"></div><div class="field"><label>单据编号前缀</label><input class="input" name="receipt_prefix" value="<?=e((string)($g['receipt_prefix']??'SAL'))?>"></div><button class="btn btn-primary">保存通用设置</button></form></section>
    <section class="card" style="padding:22px"><span class="card-kicker">WHATSAPP BUSINESS</span><h3>WhatsApp Business API</h3><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_settings_v13"><input type="hidden" name="settings_section" value="whatsapp"><label class="check-row"><input type="checkbox" name="wa_enabled" value="1" <?=!empty($w['enabled'])?'checked':''?>>启用提醒</label><div class="field"><label>Phone Number ID</label><input class="input" name="wa_phone_number_id" value="<?=e((string)($w['phone_number_id']??''))?>"></div><div class="field"><label>Business Account ID</label><input class="input" name="wa_business_account_id" value="<?=e((string)($w['business_account_id']??''))?>"></div><div class="field span-2"><label>Access Token</label><input class="input" type="password" name="wa_access_token" value="<?=e((string)($w['access_token']??''))?>"></div><div class="field"><label>预约提前提醒分钟</label><input class="input" type="number" min="0" name="wa_reminder_minutes" value="<?=intval($w['reminder_minutes']??60)?>"></div><button class="btn btn-primary">保存 WhatsApp 设置</button></form></section></div>
    <section class="card" style="margin-top:18px;padding:22px"><span class="card-kicker">DATABASE</span><h3>数据库隔离状态</h3><p><strong>Supabase Only</strong> · 当前 Organization：<?=e(v13_org_uuid())?> · 当前 Store：<?=e(v13_store_uuid())?></p><p class="muted">v13 运行时不读取 InfinityFree MySQL。InfinityFree 只负责 PHP / PWA / 静态资源托管。</p><a class="btn btn-light" href="system-test.php">运行完整系统自检 →</a></section><?php
}

function v13_render_full_page(string $page): bool {
    return match($page){
        'dashboard'=>(v13_page_dashboard()??true),
        'new_visit'=>(v13_page_new_visit()??true),
        'confirm'=>(v1331_page_confirm((string)($_GET['id']??''))??true),
        'orders'=>(v13_page_orders()??true),
        'performance'=>(v13_page_performance()??true),
        'order_history'=>(v13_page_order_history()??true),
        'receipt'=>(v1361062_page_receipt()??true),
        'operations'=>(v1361062_page_operations()??true),
        'analytics'=>(v135_page_analytics()??true),
        'kpi'=>(v13_page_kpi()??true),
        'kpi_employee'=>(v1350_page_kpi_employee()??true),
        'training'=>(v13_page_training()??true),
        'services'=>(v13_page_services()??true),
        'stock_hub'=>(v13_page_stock_hub()??true),
        'commission'=>(v13_page_commission()??true),
        'branches'=>(v13_page_branches()??true),
        'settings'=>(v13_page_settings()??true),
        default=>false,
    };
}
