<?php
declare(strict_types=1);

/** SalonOS v13.6.10.49 · rotating QR attendance + leave requests. */

function salonos_v1361039_employee_session_token(): string {
    return trim((string)($_SESSION['v13_employee_session_token'] ?? ''));
}

function salonos_v1361039_attendance_snapshot(): array {
    if (v13_is_owner()) {
        $storeId=(string)(current_store()['id'] ?? '');
        if($storeId==='') throw new RuntimeException('找不到当前分行。');
        return v13_rpc_json('v1361039_owner_attendance_snapshot',['p_store_id'=>$storeId],v13_owner_token_required_all());
    }
    $session=salonos_v1361039_employee_session_token();
    if($session==='') throw new RuntimeException('员工登录已过期，请重新登录。');
    return v13_rpc_json('v1361039_employee_attendance_snapshot',['p_session_token'=>$session],'');
}

function salonos_v1361039_owner_attendance_map(): array {
    if(!v13_is_owner()) return [];
    try{$payload=salonos_v1361039_attendance_snapshot();}catch(Throwable $e){return [];}
    $rows=is_array($payload['employees']??null)?$payload['employees']:[];
    $map=[];foreach($rows as $row){if(is_array($row)&&!empty($row['employee_id']))$map[(string)$row['employee_id']]=$row;}
    return $map;
}

function salonos_v1361039_save_employee_setting(string $employeeId): void {
    if($employeeId==='') return;
    $storeId=(string)(current_store()['id']??'');
    if($storeId==='') return;
    $enabled=((string)($_POST['attendance_enabled']??'1'))==='1';
    $start=trim((string)($_POST['attendance_start_time']??'09:00')) ?: '09:00';
    $end=trim((string)($_POST['attendance_end_time']??'18:00')) ?: '18:00';
    $grace=max(0,min(240,(int)($_POST['late_grace_minutes']??10)));
    v13_rpc_json('v1361039_owner_save_attendance_setting',[
        'p_store_id'=>$storeId,'p_employee_id'=>$employeeId,'p_enabled'=>$enabled,
        'p_start_time'=>$start,'p_end_time'=>$end,'p_late_grace_minutes'=>$grace
    ],v13_owner_token_required_all());
}

function salonos_v1361049_leave_payload(): array {
    try{
        if(v13_is_owner()){
            $storeId=(string)(current_store()['id']??'');
            if($storeId==='') return ['requests'=>[]];
            return v13_rpc_json('v1361049_owner_leave_requests',['p_store_id'=>$storeId],v13_owner_token_required_all());
        }
        $session=salonos_v1361039_employee_session_token();
        if($session==='') return ['requests'=>[]];
        return v13_rpc_json('v1361049_employee_leave_requests',['p_session_token'=>$session],'');
    }catch(Throwable $e){ return ['requests'=>[],'error'=>v136_user_error($e)]; }
}

function salonos_v1361049_leave_status_meta(string $status): array {
    return match($status){
        'approved'=>['label'=>'已批准','class'=>'is-approved'],
        'rejected'=>['label'=>'已拒绝','class'=>'is-rejected'],
        'cancelled'=>['label'=>'已撤回','class'=>'is-cancelled'],
        default=>['label'=>'待审批','class'=>'is-pending'],
    };
}

function salonos_v1361039_status_meta(string $status): array {
    return match($status){
        'working'=>['label'=>'上班中','class'=>'is-working','detail'=>'已到店，可参与 Walk-in 派单'],
        'working_late'=>['label'=>'上班中 · 迟到','class'=>'is-late','detail'=>'已到店，迟到记录已保存'],
        'clocked_out'=>['label'=>'已下班','class'=>'is-out','detail'=>'已下班，不再参与 Walk-in 派单'],
        'not_arrived'=>['label'=>'未到','class'=>'is-missing','detail'=>'已超过到店时间，尚未打卡'],
        'on_leave'=>['label'=>'请假','class'=>'is-leave','detail'=>'老板已批准今天请假，不参与 Walk-in 派单'],
        'attendance_disabled'=>['label'=>'免打卡','class'=>'is-disabled','detail'=>'老板已关闭此员工打卡规则'],
        default=>['label'=>'待上班','class'=>'is-waiting','detail'=>'尚未到上班时间或还没打卡'],
    };
}

function salonos_v1361039_time(?string $value): string {
    if(!$value)return '—';
    $t=strtotime($value); return $t?date('H:i',$t):$value;
}

function salonos_v1361039_ajax(): never {
    $op=trim((string)($_POST['attendance_op']??''));
    try{
        if($op==='snapshot'){
            v1352_json_response(['success'=>true,'data'=>salonos_v1361039_attendance_snapshot()]);
        }
        if($op==='qr'){
            $qrAction=((string)($_POST['qr_action']??'in'))==='out'?'out':'in';
            if(v13_is_owner()){
                $payload=v13_rpc_json('v1361039_owner_attendance_qr',['p_store_id'=>(string)(current_store()['id']??''),'p_action'=>$qrAction],v13_owner_token_required_all());
            }else{
                $session=salonos_v1361039_employee_session_token();
                if($session==='')throw new RuntimeException('员工登录已过期。');
                $payload=v13_rpc_json('v1361039_employee_attendance_qr',['p_session_token'=>$session,'p_action'=>$qrAction],'');
            }
            v1352_json_response(['success'=>true,'data'=>$payload]);
        }
        if($op==='clock'){
            if(v13_is_owner()) throw new RuntimeException('老板账号不用员工打卡；请由员工端扫描二维码。');
            $session=salonos_v1361039_employee_session_token();
            $raw=trim((string)($_POST['qr_token']??''));
            if(str_contains($raw,'scan_token=')){
                $query=parse_url($raw,PHP_URL_QUERY);$params=[];if(is_string($query))parse_str($query,$params);$raw=trim((string)($params['scan_token']??$raw));
            }
            if($raw==='')throw new RuntimeException('没有读到有效的打卡二维码。');
            $payload=v13_rpc_json('v1361039_employee_clock',['p_session_token'=>$session,'p_qr_token'=>$raw],'');
            v1352_json_response(['success'=>true,'data'=>$payload,'message'=>(string)($payload['message']??'打卡成功。')]);
        }
        if($op==='manual_clock'){
            $employeeId=trim((string)($_POST['employee_id']??''));
            $clockAction=((string)($_POST['clock_action']??'in'))==='out'?'out':'in';
            $note=trim((string)($_POST['note']??''));
            if($employeeId==='') throw new RuntimeException('请选择员工。');
            if(v13_is_owner()){
                $payload=v13_rpc_json('v1361052_owner_manual_clock',[
                    'p_store_id'=>(string)(current_store()['id']??''),'p_employee_id'=>$employeeId,'p_action'=>$clockAction,'p_note'=>$note
                ],v13_owner_token_required_all());
            }else{
                if(!has_permission('attendance.manual')) throw new RuntimeException('你的职位没有替员工打卡的权限。');
                $session=salonos_v1361039_employee_session_token();
                if($session==='') throw new RuntimeException('员工登录已过期。');
                $payload=v13_rpc_json('v1361052_employee_manual_clock',[
                    'p_session_token'=>$session,'p_employee_id'=>$employeeId,'p_action'=>$clockAction,'p_note'=>$note
                ],'');
            }
            v1352_json_response(['success'=>true,'data'=>$payload,'message'=>(string)($payload['message']??'员工打卡已处理。')]);
        }
        if($op==='leave_submit'){
            if(v13_is_owner()) throw new RuntimeException('老板账号不需要提交员工请假。');
            $session=salonos_v1361039_employee_session_token();
            if($session==='') throw new RuntimeException('员工登录已过期，请重新登录。');
            $start=trim((string)($_POST['start_date']??''));
            $end=trim((string)($_POST['end_date']??''));
            $reason=trim((string)($_POST['reason']??''));
            $payload=v13_rpc_json('v1361049_employee_submit_leave',[
                'p_session_token'=>$session,'p_start_date'=>$start,'p_end_date'=>$end,'p_reason'=>$reason
            ],'');
            v1352_json_response(['success'=>true,'data'=>$payload,'message'=>(string)($payload['message']??'请假申请已提交。')]);
        }
        if($op==='leave_cancel'){
            if(v13_is_owner()) throw new RuntimeException('无效操作。');
            $session=salonos_v1361039_employee_session_token();
            $requestId=trim((string)($_POST['request_id']??''));
            $payload=v13_rpc_json('v1361049_employee_cancel_leave',['p_session_token'=>$session,'p_request_id'=>$requestId],'');
            v1352_json_response(['success'=>true,'data'=>$payload,'message'=>(string)($payload['message']??'请假申请已撤回。')]);
        }
        if($op==='leave_review'){
            if(!v13_is_owner()) throw new RuntimeException('只有老板可以审批请假。');
            $storeId=(string)(current_store()['id']??'');
            $requestId=trim((string)($_POST['request_id']??''));
            $decision=trim((string)($_POST['decision']??''));
            $note=trim((string)($_POST['manager_note']??''));
            $payload=v13_rpc_json('v1361049_owner_review_leave',[
                'p_store_id'=>$storeId,'p_request_id'=>$requestId,'p_decision'=>$decision,'p_manager_note'=>$note
            ],v13_owner_token_required_all());
            v1352_json_response(['success'=>true,'data'=>$payload,'message'=>(string)($payload['message']??'审批完成。')]);
        }
        throw new RuntimeException('未知打卡操作。');
    }catch(Throwable $e){v1352_json_response(['success'=>false,'message'=>v136_user_error($e)],422);}
}

function page_attendance_v1361039(): void {
    try{$snapshot=salonos_v1361039_attendance_snapshot();}
    catch(Throwable $e){
        echo '<section class="card" style="padding:24px"><span class="eyebrow">ATTENDANCE CONTRACT</span><h2>员工打卡系统尚未安装</h2><div class="alert alert-error">'.e(v136_user_error($e)).'</div><p>请在 Supabase SQL Editor 运行 <code>RUN_ONCE_V13_6_10_39_CREATOR_ATTENDANCE.sql</code> 后刷新。</p></section>';return;
    }
    $isOwner=v13_is_owner();
    $leavePayload=salonos_v1361049_leave_payload();
    $leaveRequests=is_array($leavePayload['requests']??null)?$leavePayload['requests']:[];
    $canScan=$isOwner || has_permission('attendance.scan');
    $canTeam=$isOwner || has_permission('attendance.team.view');
    $canStation=$isOwner || has_permission('attendance.station');
    $canManual=$isOwner || has_permission('attendance.manual');
    $rows=[];$self=null;$canDisplay=$isOwner;
    if($isOwner){$rows=is_array($snapshot['employees']??null)?$snapshot['employees']:[];}
    else{
        $selfRows=is_array($snapshot['self']??null)?$snapshot['self']:[];$self=$selfRows[0]??null;
        $rows=is_array($snapshot['employees']??null)?$snapshot['employees']:[];
        $canDisplay=$canStation && !empty($snapshot['can_display_qr']);
        if(!$canTeam)$rows=[];
    }
    $working=0;$missing=0;$out=0;
    foreach($rows as $r){$s=(string)($r['attendance_status']??'not_clocked_in');if(in_array($s,['working','working_late'],true))$working++;elseif($s==='not_arrived')$missing++;elseif($s==='clocked_out')$out++;}
    $scanToken=trim((string)($_GET['scan_token']??''));
    ?>
    <div class="page-head responsive-page-head attendance-page-head"><div><span class="eyebrow">ATTENDANCE · ROTATING QR</span><h1>员工打卡</h1><p><?=$isOwner?'柜台显示每 15 秒刷新的上班／下班二维码，并实时确认员工是否已经到店。':'到店后扫描柜台二维码上班；离店前再扫描下班二维码。打卡只影响当天 Walk-in 派单，不影响未来预约。'?></p></div><?php if(!$isOwner):?><div class="attendance-head-actions"><?php if($canScan):?><button class="btn btn-primary" type="button" data-attendance-scan-open><?=ui_icon('search')?> 扫码打卡</button><?php endif;?><button class="btn btn-light" type="button" data-leave-open>请假申请</button></div><?php endif;?></div>

    <?php if($isOwner || $rows):?>
    <section class="stats attendance-stats"><div class="stat"><span>上班中</span><strong data-attendance-stat-working><?=$working?></strong><small>可根据当前服务状态参与派单</small></div><div class="stat"><span>未到</span><strong data-attendance-stat-missing><?=$missing?></strong><small>超过上班时间仍未打卡</small></div><div class="stat"><span>已下班</span><strong data-attendance-stat-out><?=$out?></strong><small>不会再进入 Walk-in 员工池</small></div><div class="stat"><span>二维码刷新</span><strong>15s</strong><small>服务器 20 秒后强制失效</small></div></section>
    <?php endif;?>

    <?php if(!$isOwner && is_array($self)): $meta=salonos_v1361039_status_meta((string)($self['attendance_status']??'')); ?>
    <section class="card attendance-self-card <?=$meta['class']?>"><div><span class="card-kicker">MY ATTENDANCE</span><h2>今天 · <?=e((string)($self['name']??user()['employee_name']??'员工'))?></h2><p><?=e($meta['detail'])?></p></div><div class="attendance-self-status"><span><?=e($meta['label'])?></span><small>上班 <?=e(substr((string)($self['scheduled_start_time']??'09:00'),0,5))?> · 下班 <?=e(substr((string)($self['scheduled_end_time']??'18:00'),0,5))?></small><small>上班卡 <?=e(salonos_v1361039_time($self['clock_in_at']??null))?> · 下班卡 <?=e(salonos_v1361039_time($self['clock_out_at']??null))?></small></div></section>
    <?php endif;?>

    <?php if(!$isOwner):?>
    <section class="card leave-request-card">
      <div class="card-head"><div><span class="card-kicker">LEAVE REQUESTS</span><h3>我的请假申请</h3><p>提交后由老板审批。只有「已批准」的请假日期才会从预约可选员工中排除。</p></div><button class="btn btn-light" type="button" data-leave-open>＋ 申请请假</button></div>
      <div class="leave-request-list">
        <?php foreach($leaveRequests as $lr): if(!is_array($lr))continue; $lm=salonos_v1361049_leave_status_meta((string)($lr['status']??'')); ?>
        <article class="leave-request-row <?=$lm['class']?>"><div><strong><?=e((string)($lr['start_date']??''))?><?=($lr['end_date']??'')!==($lr['start_date']??'')?' → '.e((string)($lr['end_date']??'')):''?></strong><p><?=e((string)($lr['reason']??''))?></p><?php if(!empty($lr['manager_note'])):?><small>老板备注：<?=e((string)$lr['manager_note'])?></small><?php endif;?></div><div class="leave-request-actions"><span class="leave-status <?=$lm['class']?>"><?=e($lm['label'])?></span><?php if(($lr['status']??'')==='pending'):?><button class="btn btn-ghost btn-sm" type="button" data-leave-cancel="<?=e((string)($lr['id']??''))?>">撤回</button><?php endif;?></div></article>
        <?php endforeach;?>
        <?php if(!$leaveRequests):?><div class="empty compact-empty">还没有请假申请。</div><?php endif;?>
      </div>
    </section>
    <?php else:?>
    <section class="card leave-approval-card">
      <div class="card-head"><div><span class="card-kicker">LEAVE APPROVAL</span><h3>员工请假审批</h3><p>批准后，该员工在请假日期不会出现在 AI 预约可选员工中；未批准的申请不会影响预约。</p></div></div>
      <div class="leave-request-list">
        <?php foreach($leaveRequests as $lr): if(!is_array($lr))continue; $lm=salonos_v1361049_leave_status_meta((string)($lr['status']??'')); ?>
        <article class="leave-request-row <?=$lm['class']?>" data-leave-owner-row><div><strong><?=e((string)($lr['employee_name']??''))?> · <?=e((string)($lr['start_date']??''))?><?=($lr['end_date']??'')!==($lr['start_date']??'')?' → '.e((string)($lr['end_date']??'')):''?></strong><p><?=e((string)($lr['reason']??''))?></p><small><?=e((string)($lr['position']??''))?> · 申请于 <?=e(salonos_v1361039_time($lr['requested_at']??null))?></small></div><div class="leave-request-actions"><span class="leave-status <?=$lm['class']?>"><?=e($lm['label'])?></span><?php if(($lr['status']??'')==='pending'):?><input class="leave-manager-note" type="text" placeholder="审批备注（可选）" data-leave-note><div class="leave-review-buttons"><button class="btn btn-light btn-sm" type="button" data-leave-review="rejected" data-request-id="<?=e((string)($lr['id']??''))?>">拒绝</button><button class="btn btn-primary btn-sm" type="button" data-leave-review="approved" data-request-id="<?=e((string)($lr['id']??''))?>">批准</button></div><?php elseif(!empty($lr['manager_note'])):?><small>备注：<?=e((string)$lr['manager_note'])?></small><?php endif;?></div></article>
        <?php endforeach;?>
        <?php if(!$leaveRequests):?><div class="empty compact-empty">目前没有员工请假申请。</div><?php endif;?>
      </div>
    </section>
    <?php endif;?>

    <?php if($canDisplay):?>
    <section class="attendance-layout">
      <article class="card attendance-qr-card" data-attendance-qr-station data-csrf="<?=e(csrf_token())?>">
        <div class="card-head"><div><span class="card-kicker">COUNTER QR STATION</span><h3>柜台打卡二维码</h3><p>员工必须人在店里扫描当前二维码；旧截图最多约 20 秒就会失效。</p></div><div class="attendance-qr-toggle"><button type="button" class="is-active" data-attendance-qr-action="in">上班</button><button type="button" data-attendance-qr-action="out">下班</button></div></div>
        <div class="attendance-qr-stage"><div class="attendance-qr-box" data-attendance-qr-box><div class="attendance-qr-loading">正在建立安全二维码…</div></div><div class="attendance-qr-side"><span class="attendance-qr-kind" data-attendance-qr-kind>上班签到</span><strong><span data-attendance-countdown>15</span> 秒后刷新</strong><p>二维码每 15 秒自动换新，服务器 20 秒后拒绝旧码。</p><button class="btn btn-light" type="button" data-attendance-refresh>立即刷新</button></div></div>
      </article>
      <article class="card attendance-rules-card"><span class="card-kicker">ASSIGNMENT RULE</span><h3>为什么员工会显示「未到」？</h3><p>员工管理可以设置每个人的上班时间和迟到宽限分钟。超过时间仍未扫描上班码，就显示「未到」。</p><div class="attendance-rule-flow"><span>未打卡</span><b>→</b><span>不可 Walk-in 派单</span><b>→</b><span>顾客也不能指定</span></div><?php if($isOwner):?><a class="btn btn-light" href="index.php?page=employees">去员工管理设置时间 →</a><?php endif;?></article>
    </section>
    <?php endif;?>

    <?php if($isOwner || $rows):?>
    <section class="card attendance-team-card"><div class="card-head"><div><span class="card-kicker">TODAY · LIVE STATUS</span><h3>今日员工到店状态</h3><p>这里显示当前最新状态。真正能否接单还会继续检查休息、技能与当前订单冲突。</p></div><button class="btn btn-light" type="button" data-attendance-list-refresh>刷新状态</button></div><div class="attendance-team-list" data-attendance-team-list>
      <?php foreach($rows as $r): $m=salonos_v1361039_status_meta((string)($r['attendance_status']??''));?><article class="attendance-team-row <?=$m['class']?>"><div class="attendance-team-person"><div class="leader-avatar"><?=e(mb_substr((string)($r['name']??'E'),0,1))?></div><div><strong><?=e((string)($r['name']??''))?></strong><small><?=e((string)($r['position']??''))?></small></div></div><div class="attendance-team-schedule"><span><?=e(substr((string)($r['scheduled_start_time']??'09:00'),0,5))?> – <?=e(substr((string)($r['scheduled_end_time']??'18:00'),0,5))?></span><small>迟到宽限 <?=intval($r['late_grace_minutes']??10)?> 分钟</small></div><div class="attendance-team-times"><span>IN <?=e(salonos_v1361039_time($r['clock_in_at']??null))?></span><span>OUT <?=e(salonos_v1361039_time($r['clock_out_at']??null))?></span></div><div class="attendance-status-pill <?=$m['class']?>"><strong><?=e($m['label'])?></strong><small><?=!empty($r['can_assign_walkin'])?'Walk-in 可用':'Walk-in 不可用'?></small></div><?php if($canManual):?><button class="btn btn-light btn-small" type="button" data-attendance-manual-open data-employee-id="<?=e((string)($r['employee_id']??''))?>" data-employee-name="<?=e((string)($r['name']??'员工'))?>" data-clocked-in="<?=!empty($r['clock_in_at'])?'1':'0'?>" data-clocked-out="<?=!empty($r['clock_out_at'])?'1':'0'?>">代打卡</button><?php endif;?></article><?php endforeach;?>
      <?php if(!$rows):?><div class="empty compact-empty">当前分行还没有需要打卡的在职员工。</div><?php endif;?>
    </div></section>
    <?php endif;?>

    <?php if(!$isOwner):?>
    <div class="commission-modal leave-request-modal" data-leave-modal hidden aria-hidden="true"><button class="commission-modal-backdrop" type="button" data-leave-close></button><section class="commission-modal-dialog leave-request-dialog"><header class="commission-modal-head"><div><span class="eyebrow">LEAVE REQUEST</span><h2>申请请假</h2><p>选择日期并填写原因。老板批准后，这些日期不会再被 AI 安排预约。</p></div><button class="commission-modal-close" type="button" data-leave-close>×</button></header><div class="leave-request-form"><label>开始日期<input type="date" data-leave-start required></label><label>结束日期<input type="date" data-leave-end required></label><label class="leave-reason-field">请假原因<textarea rows="4" data-leave-reason placeholder="例如：家庭事务、身体不适、学校事务…" required></textarea></label><div class="leave-form-actions"><button class="btn btn-light" type="button" data-leave-close>取消</button><button class="btn btn-primary" type="button" data-leave-submit>提交申请</button></div></div></section></div>
    <?php endif;?>

    <?php if(!$isOwner && $canScan):?>
    <div class="commission-modal attendance-scanner-modal" data-attendance-scanner hidden aria-hidden="true"><button class="commission-modal-backdrop" type="button" data-attendance-scan-close></button><section class="commission-modal-dialog attendance-scanner-dialog"><header class="commission-modal-head"><div><span class="eyebrow">SCAN ATTENDANCE QR</span><h2>扫码打卡</h2><p>对准柜台当前显示的二维码。二维码会不断刷新，拍照带走的旧码无法长期使用。</p></div><button class="commission-modal-close" type="button" data-attendance-scan-close>×</button></header><div class="attendance-scanner-body"><div id="attendance-qr-reader"></div><div class="attendance-scanner-message" data-attendance-scan-message>点击下方按钮启动相机。</div><button class="btn btn-primary btn-block" type="button" data-attendance-camera-start>启动相机</button></div></section></div>
    <?php endif;?>

    <?php if($canManual):?>
    <div class="commission-modal attendance-manual-modal" data-attendance-manual-modal hidden aria-hidden="true"><button class="commission-modal-backdrop" type="button" data-attendance-manual-close></button><section class="commission-modal-dialog v1350-small-modal"><header class="commission-modal-head"><div><span class="eyebrow">MANUAL ATTENDANCE</span><h2>替员工打卡</h2><p>仅用于员工手机故障、相机无法扫码等例外情况。系统会保留是谁代打卡与备注。</p></div><button class="commission-modal-close" type="button" data-attendance-manual-close>×</button></header><div class="commission-modal-content"><div class="alert alert-warning">代打卡会直接改变员工当天 Walk-in 可派单状态，请先确认员工本人确实已经到店或离店。</div><div class="field"><label>员工</label><input class="input" data-attendance-manual-name readonly><input type="hidden" data-attendance-manual-employee></div><div class="field"><label>操作</label><select class="select" data-attendance-manual-action><option value="in">替员工上班打卡</option><option value="out">替员工下班打卡</option></select></div><div class="field"><label>原因 / 备注 *</label><textarea class="input" rows="3" data-attendance-manual-note required placeholder="例如：员工手机损坏，柜台确认本人已到店"></textarea></div><div class="form-actions"><button class="btn btn-light" type="button" data-attendance-manual-close>取消</button><button class="btn btn-primary" type="button" data-attendance-manual-submit>确认代打卡</button></div></div></section></div>
    <?php endif;?>

    <div data-attendance-root data-csrf="<?=e(csrf_token())?>" data-auto-token="<?=e($scanToken)?>" data-is-owner="<?=$isOwner?'1':'0'?>"></div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" defer></script>
    <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js" defer></script>
    <?php
}
