<?php
declare(strict_types=1);

define('SALONOS_SUPABASE_URL', function_exists('salonos_env') ? salonos_env('SALONOS_SUPABASE_URL','https://YOUR_PROJECT.supabase.co') : 'https://YOUR_PROJECT.supabase.co');
define('SALONOS_SUPABASE_PUBLISHABLE_KEY', function_exists('salonos_env') ? salonos_env('SALONOS_SUPABASE_PUBLISHABLE_KEY','YOUR_PUBLISHABLE_KEY') : 'YOUR_PUBLISHABLE_KEY');

class SalonosSupabaseHttpException extends RuntimeException
{
    public int $httpStatus;
    public array $payload;

    public function __construct(string $message, int $httpStatus = 0, array $payload = [])
    {
        parent::__construct($message);
        $this->httpStatus = $httpStatus;
        $this->payload = $payload;
    }
}

function salonos_supabase_request(string $path, string $accessToken = '', string $method = 'GET', ?array $body = null, array $extraHeaders = []): array
{
    // If the PHP process has just proven that it cannot reach Supabase, do not spend
    // another 10-12 seconds for every single migrated row. The one-shot migration can
    // contain hundreds of REST calls; without this circuit breaker a temporary DNS/TLS
    // problem turns into a 900-second Apache/PHP fatal timeout.
    $blockedUntil = (int)($_SESSION['salonos_supabase_transport_down_until'] ?? 0);
    if ($blockedUntil > time()) {
        throw new RuntimeException('Supabase PHP 网络暂时不可用，请等待约 '.max(1,$blockedUntil-time()).' 秒后重试。');
    }

    $url = rtrim(SALONOS_SUPABASE_URL, '/') . '/' . ltrim($path, '/');
    $headers = [
        'Accept: application/json',
        'apikey: ' . SALONOS_SUPABASE_PUBLISHABLE_KEY,
    ];
    if ($accessToken !== '') $headers[] = 'Authorization: Bearer ' . $accessToken;
    if ($body !== null) $headers[] = 'Content-Type: application/json';
    foreach ($extraHeaders as $header) {
        if (is_string($header) && trim($header) !== '') $headers[] = trim($header);
    }

    $payload = $body === null ? null : json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $status = 0;
    $raw = false;
    $transportError = '';

    if (function_exists('curl_init')) {
        // PHP request-local: retain the connection pool, but clear the previous
        // method, body and Authorization header before configuring each call.
        static $ch = null;
        $ch ??= curl_init();
        if ($ch === false) throw new RuntimeException('无法初始化 Supabase PHP 网络连接。');
        curl_reset($ch);
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_NOSIGNAL => true,
            CURLOPT_TCP_KEEPALIVE => 1,
            // XAMPP/Windows can occasionally prefer a broken IPv6 route while Chrome
            // silently falls back to IPv4. Force IPv4 for server-side migration calls.
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
        ]);
        if ($payload !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        $raw = curl_exec($ch);
        if ($raw === false) $transportError = (string)curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    } else {
        $opts = [
            'http' => [
                'method' => $method,
                'header' => implode("\r\n", $headers),
                'ignore_errors' => true,
                'timeout' => 12,
            ],
        ];
        if ($payload !== null) $opts['http']['content'] = $payload;
        $context = stream_context_create($opts);
        $raw = @file_get_contents($url, false, $context);
        if ($raw === false) $transportError = 'Unable to reach Supabase. Enable PHP cURL or allow_url_fopen.';
        if (!empty($http_response_header) && preg_match('/\s(\d{3})\s/', (string)$http_response_header[0], $match)) {
            $status = (int)$match[1];
        }
    }

    if ($raw === false) {
        $_SESSION['salonos_supabase_transport_down_until'] = time() + 20;
        throw new RuntimeException('Supabase PHP 网络连接失败：' . ($transportError ?: 'Unknown network error'));
    }
    unset($_SESSION['salonos_supabase_transport_down_until']);

    $decoded = json_decode((string)$raw, true);
    if ($decoded === null && trim((string)$raw) !== '' && trim((string)$raw) !== 'null') {
        throw new RuntimeException('Supabase 返回了无法解析的数据。');
    }

    if ($status < 200 || $status >= 300) {
        $message = is_array($decoded)
            ? (string)($decoded['msg'] ?? $decoded['message'] ?? $decoded['error_description'] ?? $decoded['error'] ?? ('HTTP ' . $status))
            : ('HTTP ' . $status);
        $parts = ['Supabase 验证失败：' . $message];
        if (is_array($decoded)) {
            if (!empty($decoded['code'])) $parts[] = 'code=' . (string)$decoded['code'];
            if (!empty($decoded['hint'])) $parts[] = 'hint=' . (string)$decoded['hint'];
            if (!empty($decoded['details'])) $parts[] = 'details=' . (string)$decoded['details'];
        }
        throw new SalonosSupabaseHttpException(implode(' | ', $parts), $status, is_array($decoded) ? $decoded : []);
    }

    return is_array($decoded) ? $decoded : [];
}

function salonos_supabase_rest_rows(string $table, string $query, string $accessToken): array
{
    $path = 'rest/v1/' . rawurlencode($table) . ($query !== '' ? '?' . $query : '');
    $rows = salonos_supabase_request($path, $accessToken);
    return array_is_list($rows) ? $rows : [];
}

function salonos_supabase_owner_context(string $accessToken): array
{
    $accessToken = trim($accessToken);
    if ($accessToken === '') throw new RuntimeException('缺少 Supabase 登录 Session，请重新登录。');

    $authUser = salonos_supabase_request('auth/v1/user', $accessToken);
    $userId = trim((string)($authUser['id'] ?? ''));
    $email = trim((string)($authUser['email'] ?? ''));
    if ($userId === '') throw new RuntimeException('Supabase 用户资料无效。');

    $memberScope = '&user_id=eq.' . rawurlencode($userId) . '&status=eq.active&limit=1';
    $memberQuery = 'select=organization_id,role,status' . $memberScope;
    // Same user token and table policies; fetch the member, organization and
    // active stores together rather than waiting on three REST calls.
    $organizationFields = 'id,name,status';
    $storeFields = 'id,organization_id,name,code,is_main,status';
    $embeddedQuery = 'select=organization_id,role,status,organization:organizations!organization_members_organization_id_fkey('
        . $organizationFields . ',stores!stores_organization_id_fkey(' . $storeFields . '))'
        . $memberScope
        . '&organization.stores.status=eq.active&organization.stores.order=is_main.desc,name.asc';
    $useEmbedded = true;
    try {
        $members = salonos_supabase_rest_rows('organization_members', $embeddedQuery, $accessToken);
    } catch (SalonosSupabaseHttpException $e) {
        // Older projects may have different relationship names in the schema cache.
        if (!in_array(strtoupper((string)($e->payload['code'] ?? '')), ['PGRST200', 'PGRST201'], true)) throw $e;
        $useEmbedded = false;
        $members = salonos_supabase_rest_rows('organization_members', $memberQuery, $accessToken);
    }
    $member = $members[0] ?? null;
    // v12.1 public registrations are Creator-code controlled. They may not need a
    // duplicate Supabase organization row: Creator provides the stable tenant identity
    // while Supabase continues to authenticate the Owner email/password.
    if (!$member && function_exists('salonos_public_mode') && salonos_public_mode() && function_exists('salonos_public_creator_identity_for_auth_user')) {
        $creatorIdentity = salonos_public_creator_identity_for_auth_user($authUser);
        if ($creatorIdentity) return $creatorIdentity;
    }
    if (!$member) throw new RuntimeException('这个 Supabase 用户没有有效的 SalonOS 公司权限，也没有 Creator 开户记录。');

    $role = (string)($member['role'] ?? '');
    if (!in_array($role, ['owner','manager'], true)) throw new RuntimeException('这个入口只允许老板或分行管理员登录。当前角色：' . ($role ?: 'unknown'));

    $organizationId = trim((string)($member['organization_id'] ?? ''));
    if ($organizationId === '') throw new RuntimeException('找不到 Supabase Organization。');

    if ($useEmbedded) {
        $organization = $member['organization'] ?? null;
    } else {
        $orgQuery = 'select=' . $organizationFields . '&id=eq.' . rawurlencode($organizationId) . '&limit=1';
        $organizations = salonos_supabase_rest_rows('organizations', $orgQuery, $accessToken);
        $organization = $organizations[0] ?? null;
    }
    if (!$organization) throw new RuntimeException('找不到可访问的 SalonOS Organization。');
    if (!in_array((string)($organization['status'] ?? ''), ['active','trialing'], true)) throw new RuntimeException('这个 SalonOS Organization 当前不可使用：'.(string)($organization['status'] ?? 'unknown'));

    if ($useEmbedded) {
        $stores = is_array($organization['stores'] ?? null) ? $organization['stores'] : [];
    } else {
        $storesQuery = 'select=' . $storeFields . '&organization_id=eq.' . rawurlencode($organizationId)
            . '&status=eq.active&order=is_main.desc,name.asc';
        $stores = salonos_supabase_rest_rows('stores', $storesQuery, $accessToken);
    }
    if (!$stores) throw new RuntimeException('这个 SalonOS Organization 目前没有可访问的 active 分行。');

    $profileQuery = 'select=id,full_name,phone,avatar_path&id=eq.' . rawurlencode($userId) . '&limit=1';
    try {
        $profiles = salonos_supabase_rest_rows('profiles', $profileQuery, $accessToken);
    } catch (Throwable $profileError) {
        // v13.6.10.55 compatibility: an uploaded web build may arrive a few seconds
        // before the additive owner-avatar SQL. Keep login working until SQL is run.
        $fallbackProfileQuery = 'select=id,full_name,phone&id=eq.' . rawurlencode($userId) . '&limit=1';
        $profiles = salonos_supabase_rest_rows('profiles', $fallbackProfileQuery, $accessToken);
    }
    $profile = $profiles[0] ?? null;

    return [
        'user_id' => $userId,
        'email' => $email,
        'role' => $role,
        'organization_id' => $organizationId,
        'organization_name' => (string)($organization['name'] ?? 'SalonOS'),
        'organization_status' => (string)($organization['status'] ?? ''),
        'profile' => $profile,
        'stores' => array_values($stores),
        'primary_store_id' => (string)($stores[0]['id'] ?? ''),
        'verified_at' => date(DATE_ATOM),
    ];
}

function salonos_supabase_identity(): ?array
{
    $identity = $_SESSION['supabase_identity'] ?? null;
    return is_array($identity) ? $identity : null;
}
