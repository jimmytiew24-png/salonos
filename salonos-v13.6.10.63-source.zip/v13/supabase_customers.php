<?php
declare(strict_types=1);

function salonos_is_uuid(string $value): bool
{
    return (bool)preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', trim($value));
}

function salonos_supabase_access_token(): string
{
    return trim((string)($_SESSION['supabase_access_token'] ?? ''));
}

function salonos_supabase_customer_mode(): bool
{
    $hasSession = salonos_supabase_identity() !== null && salonos_supabase_access_token() !== '';
    if (!$hasSession) return false;
    // v13.0.2 intentionally enables the Supabase customer/member data source even
    // on the public InfinityFree host. InfinityFree is hosting only; it is no longer
    // the source of truth for this module.
    if (defined('SALONOS_V13_SUPABASE_CUSTOMERS') && SALONOS_V13_SUPABASE_CUSTOMERS) return true;
    if (function_exists('salonos_public_mode') && salonos_public_mode()) return false;
    return true;
}

function salonos_supabase_current_store_uuid(): string
{
    $identity = salonos_supabase_identity();
    if (!$identity) return '';
    $stores = is_array($identity['stores'] ?? null) ? $identity['stores'] : [];
    if (!$stores) return trim((string)($identity['primary_store_id'] ?? ''));

    // v13 pure Supabase runtime stores the selected branch as a Supabase store UUID.
    $sessionStore = trim((string)($_SESSION['v13_current_store_uuid'] ?? ''));
    if ($sessionStore !== '') {
        foreach ($stores as $store) {
            if (trim((string)($store['id'] ?? '')) === $sessionStore) return $sessionStore;
        }
    }

    $local = null;
    try { $local = fetch_one('SELECT code,name,is_main FROM stores WHERE id=?', [current_store_id()]); } catch (Throwable $ignored) {}
    $localCode = strtoupper(trim((string)($local['code'] ?? '')));
    if ($localCode !== '') {
        foreach ($stores as $store) {
            if (strtoupper(trim((string)($store['code'] ?? ''))) === $localCode) return trim((string)($store['id'] ?? ''));
        }
    }
    foreach ($stores as $store) if (!empty($store['is_main'])) return trim((string)($store['id'] ?? ''));
    return trim((string)($stores[0]['id'] ?? $identity['primary_store_id'] ?? ''));
}

function salonos_supabase_rest_write(string $table, string $query, string $method, array $body, string $prefer = 'return=representation'): array
{
    $token = salonos_supabase_access_token();
    if ($token === '') throw new RuntimeException('Supabase Session 已过期，请退出后重新登录。');
    $path = 'rest/v1/' . rawurlencode($table) . ($query !== '' ? '?' . $query : '');
    return salonos_supabase_request($path, $token, $method, $body, $prefer !== '' ? ['Prefer: ' . $prefer] : []);
}

function salonos_supabase_rpc_is_schema_mismatch(Throwable $error): bool
{
    if ($error instanceof SalonosSupabaseHttpException) {
        $code = strtoupper(trim((string)($error->payload['code'] ?? '')));
        if ($code === 'PGRST202') return true;
        $message = strtolower((string)($error->payload['message'] ?? $error->getMessage()));
        if (str_contains($message, 'could not find the function') || str_contains($message, 'schema cache')) return true;
    }
    $message = strtolower($error->getMessage());
    return str_contains($message, 'could not find the function') || str_contains($message, 'schema cache');
}

function salonos_supabase_rpc_hint_arguments(Throwable $error, string $functionName): array
{
    $texts = [$error->getMessage()];
    if ($error instanceof SalonosSupabaseHttpException) {
        foreach (['hint','details','message'] as $key) {
            $value = trim((string)($error->payload[$key] ?? ''));
            if ($value !== '') $texts[] = $value;
        }
    }
    foreach ($texts as $text) {
        if (!preg_match('/public\\.' . preg_quote($functionName, '/') . '\\(([^)]*)\\)/i', $text, $match)) continue;
        $inside = trim((string)$match[1]);
        if ($inside === '') return [];
        $args = [];
        foreach (explode(',', $inside) as $part) {
            $part = trim($part);
            // PostgREST hints normally return parameter names. Be defensive if a type/default appears.
            $part = preg_split('/\\s+/', $part, 2)[0] ?? $part;
            $part = trim($part, " \\t\\n\\r\\0\\x0B\"");
            if ($part !== '') $args[] = $part;
        }
        if ($args) return $args;
    }
    return [];
}

function salonos_supabase_rpc_alias_value(array $aliases, string $expected, bool &$found): mixed
{
    $found = false;
    if (array_key_exists($expected, $aliases)) { $found = true; return $aliases[$expected]; }

    $norm = static function(string $key): string {
        $key = strtolower($key);
        $key = preg_replace('/^(p_|target_)/', '', $key) ?? $key;
        $key = str_replace(['loyalty_','requested_'], '', $key);
        return preg_replace('/[^a-z0-9]/', '', $key) ?? $key;
    };
    $wanted = $norm($expected);
    foreach ($aliases as $key => $value) {
        if ($norm((string)$key) === $wanted) { $found = true; return $value; }
    }

    $e = strtolower($expected);
    $patterns = [];
    if (str_contains($e, 'visit') && str_contains($e, 'id')) $patterns = ['visit_id','target_visit_id','p_visit_id'];
    elseif (str_contains($e, 'product') && str_contains($e, 'id')) $patterns = ['product_id','target_product_id','p_product_id'];
    elseif (str_contains($e, 'membership') && str_contains($e, 'id')) $patterns = ['membership_id','loyalty_membership_id','target_membership_id','p_membership_id','p_loyalty_membership_id'];
    elseif (str_contains($e, 'payment')) $patterns = ['payment_lines','payments','p_payment_lines','p_payments'];
    elseif (str_contains($e, 'discount')) $patterns = ['discount_total','discount_amount','p_discount_total'];
    elseif (str_contains($e, 'tax')) $patterns = ['tax_total','tax_amount','p_tax_total'];
    elseif ((str_contains($e, 'quantity') || str_contains($e, 'qty')) && !str_contains($e, 'id')) $patterns = ['quantity','quantity_delta','p_quantity','p_quantity_delta'];
    elseif (str_contains($e, 'unit') && str_contains($e, 'cost')) $patterns = ['unit_cost','p_unit_cost'];
    elseif (str_contains($e, 'note')) $patterns = ['notes','note','p_notes'];
    elseif ($e === 'amount' || str_ends_with($e, '_amount')) $patterns = ['amount','p_amount'];

    foreach ($patterns as $key) {
        if (array_key_exists($key, $aliases)) { $found = true; return $aliases[$key]; }
    }
    return null;
}

function salonos_supabase_rpc_body_from_hint(Throwable $error, string $functionName, array $candidateBodies): array
{
    $args = salonos_supabase_rpc_hint_arguments($error, $functionName);
    if (!$args) return [];
    $aliases = [];
    foreach ($candidateBodies as $body) foreach ($body as $key => $value) if (!array_key_exists($key, $aliases)) $aliases[$key] = $value;
    $body = [];
    foreach ($args as $arg) {
        $found = false;
        $value = salonos_supabase_rpc_alias_value($aliases, $arg, $found);
        if (!$found) return [];
        $body[$arg] = $value;
    }
    return $body;
}

function salonos_supabase_rpc_try(string $functionName, array $candidateBodies): array
{
    $token = salonos_supabase_access_token();
    if ($token === '') throw new RuntimeException('Supabase Session 已过期，请退出后重新登录。');
    $lastSchemaError = null;
    $triedJson = [];

    foreach ($candidateBodies as $body) {
        $fingerprint = json_encode(array_keys($body));
        if (isset($triedJson[$fingerprint])) continue;
        $triedJson[$fingerprint] = true;
        try {
            return salonos_supabase_request('rest/v1/rpc/' . rawurlencode($functionName), $token, 'POST', $body, ['Prefer: return=representation']);
        } catch (Throwable $error) {
            // Only try alternate argument-name shapes when PostgREST explicitly says the
            // function signature was not found. A real business/permission/validation
            // error must be surfaced immediately instead of being hidden by the last alias.
            if (!salonos_supabase_rpc_is_schema_mismatch($error)) throw $error;
            $lastSchemaError = $error;
        }
    }

    // PostgREST usually returns a “Perhaps you meant to call …(arg1,arg2)” hint.
    // Build that exact named-argument body automatically so older SalonOS SQL builds
    // with different parameter names remain migratable without guessing.
    if ($lastSchemaError) {
        $autoBody = salonos_supabase_rpc_body_from_hint($lastSchemaError, $functionName, $candidateBodies);
        if ($autoBody) {
            return salonos_supabase_request('rest/v1/rpc/' . rawurlencode($functionName), $token, 'POST', $autoBody, ['Prefer: return=representation']);
        }
        throw $lastSchemaError;
    }
    throw new RuntimeException('Supabase RPC 调用失败：' . $functionName);
}

function salonos_supabase_customer_rows_raw(): array
{
    $identity = salonos_supabase_identity();
    $org = trim((string)($identity['organization_id'] ?? ''));
    $store = salonos_supabase_current_store_uuid();
    if ($org === '' || $store === '') throw new RuntimeException('找不到当前 Supabase Organization / Store。');
    $token = salonos_supabase_access_token();
    return salonos_supabase_rest_rows(
        'customers',
        'select=id,organization_id,store_id,name,phone,gender,birth_date,ethnicity,identification_number,email,address,acquisition_platform,notes,created_at,updated_at'
        . '&organization_id=eq.' . rawurlencode($org)
        . '&store_id=eq.' . rawurlencode($store)
        . '&order=created_at.desc&limit=1000',
        $token
    );
}

function salonos_supabase_membership_levels_rows(): array
{
    $identity = salonos_supabase_identity();
    $org = trim((string)($identity['organization_id'] ?? ''));
    if ($org === '') return [];
    return salonos_supabase_rest_rows(
        'membership_levels',
        'select=id,organization_id,level_number,name,min_experience,discount_percent,points_multiplier,active'
        . '&organization_id=eq.' . rawurlencode($org)
        . '&order=level_number.asc&limit=100',
        salonos_supabase_access_token()
    );
}

function salonos_supabase_memberships_rows(): array
{
    $identity = salonos_supabase_identity();
    $org = trim((string)($identity['organization_id'] ?? ''));
    if ($org === '') return [];
    return salonos_supabase_rest_rows(
        'memberships',
        'select=id,organization_id,customer_id,current_level_id,member_number,status,joined_at,notes,created_at,updated_at'
        . '&organization_id=eq.' . rawurlencode($org)
        . '&limit=3000',
        salonos_supabase_access_token()
    );
}

function salonos_supabase_wallet_ledgers_rows(): array
{
    $identity = salonos_supabase_identity();
    $org = trim((string)($identity['organization_id'] ?? ''));
    if ($org === '') return [];
    return salonos_supabase_rest_rows(
        'member_wallet_ledger',
        'select=id,organization_id,membership_id,amount_delta,transaction_type,reference_type,reference_id,notes,created_at'
        . '&organization_id=eq.' . rawurlencode($org)
        . '&order=created_at.desc&limit=5000',
        salonos_supabase_access_token()
    );
}

function salonos_supabase_loyalty_ledgers_rows(): array
{
    $identity = salonos_supabase_identity();
    $org = trim((string)($identity['organization_id'] ?? ''));
    if ($org === '') return [];
    return salonos_supabase_rest_rows(
        'member_loyalty_ledger',
        'select=id,organization_id,membership_id,experience_delta,points_delta,transaction_type,reference_type,reference_id,notes,created_at'
        . '&organization_id=eq.' . rawurlencode($org)
        . '&order=created_at.desc&limit=5000',
        salonos_supabase_access_token()
    );
}

function salonos_supabase_visit_recipient_rows(): array
{
    $identity = salonos_supabase_identity();
    $org = trim((string)($identity['organization_id'] ?? ''));
    if ($org === '') return [];
    return salonos_supabase_rest_rows(
        'visit_recipients',
        'select=visit_id,customer_id,created_at&organization_id=eq.' . rawurlencode($org) . '&limit=5000',
        salonos_supabase_access_token()
    );
}

function salonos_supabase_level_for_experience(array $levels, float $experience): ?array
{
    $eligible = array_values(array_filter($levels, static fn($row) => !empty($row['active']) && (float)($row['min_experience'] ?? 0) <= $experience));
    usort($eligible, static fn($a,$b) => ((float)($b['min_experience'] ?? 0) <=> (float)($a['min_experience'] ?? 0)) ?: ((int)($b['level_number'] ?? 0) <=> (int)($a['level_number'] ?? 0)));
    return $eligible[0] ?? null;
}

function salonos_supabase_customer_dataset(string $q = ''): array
{
    $customers = salonos_supabase_customer_rows_raw();
    $memberships = salonos_supabase_memberships_rows();
    $levels = salonos_supabase_membership_levels_rows();
    $walletRows = salonos_supabase_wallet_ledgers_rows();
    $loyaltyRows = salonos_supabase_loyalty_ledgers_rows();
    $recipientRows = salonos_supabase_visit_recipient_rows();

    $levelsById = [];
    foreach ($levels as $level) $levelsById[(string)$level['id']] = $level;
    $membersByCustomer = [];
    foreach ($memberships as $member) $membersByCustomer[(string)$member['customer_id']] = $member;

    $walletByMember = [];
    foreach ($walletRows as $row) {
        $id = (string)($row['membership_id'] ?? '');
        if ($id === '') continue;
        $walletByMember[$id] = ($walletByMember[$id] ?? 0) + (float)($row['amount_delta'] ?? 0);
    }

    $loyaltyByMember = [];
    foreach ($loyaltyRows as $row) {
        $id = (string)($row['membership_id'] ?? '');
        if ($id === '') continue;
        $loyaltyByMember[$id] ??= ['points'=>0.0,'experience'=>0.0,'spend'=>0.0];
        $loyaltyByMember[$id]['points'] += (float)($row['points_delta'] ?? 0);
        $loyaltyByMember[$id]['experience'] += (float)($row['experience_delta'] ?? 0);
        if (($row['transaction_type'] ?? '') === 'purchase' && (float)($row['experience_delta'] ?? 0) > 0) {
            $loyaltyByMember[$id]['spend'] += (float)$row['experience_delta'];
        }
    }

    $visitStats = [];
    foreach ($recipientRows as $row) {
        $customerId = trim((string)($row['customer_id'] ?? ''));
        if ($customerId === '') continue;
        $visitId = trim((string)($row['visit_id'] ?? ''));
        $visitStats[$customerId] ??= ['visits'=>[],'last'=>null];
        if ($visitId !== '') $visitStats[$customerId]['visits'][$visitId] = true;
        $created = (string)($row['created_at'] ?? '');
        if ($created !== '' && (!$visitStats[$customerId]['last'] || strtotime($created) > strtotime((string)$visitStats[$customerId]['last']))) {
            $visitStats[$customerId]['last'] = $created;
        }
    }

    $rows = [];
    foreach ($customers as $customer) {
        $customerId = (string)$customer['id'];
        $member = $membersByCustomer[$customerId] ?? null;
        $membershipId = (string)($member['id'] ?? '');
        $loyalty = $membershipId !== '' ? ($loyaltyByMember[$membershipId] ?? ['points'=>0,'experience'=>0,'spend'=>0]) : ['points'=>0,'experience'=>0,'spend'=>0];
        $level = null;
        if ($member) {
            $level = $levelsById[(string)($member['current_level_id'] ?? '')] ?? salonos_supabase_level_for_experience($levels, (float)$loyalty['experience']);
        }
        $customer['membership_id'] = $membershipId ?: null;
        $customer['member_number'] = $member['member_number'] ?? null;
        $customer['member_status'] = $member['status'] ?? null;
        $customer['level_number'] = $level['level_number'] ?? null;
        $customer['member_level'] = $level['name'] ?? null;
        $customer['points'] = (float)$loyalty['points'];
        $customer['experience_points'] = (float)$loyalty['experience'];
        $customer['wallet_balance'] = $membershipId !== '' ? (float)($walletByMember[$membershipId] ?? 0) : 0.0;
        $customer['total_spend'] = (float)$loyalty['spend'];
        $customer['visit_count'] = isset($visitStats[$customerId]['visits']) ? count($visitStats[$customerId]['visits']) : 0;
        $customer['last_visit'] = $visitStats[$customerId]['last'] ?? null;
        $rows[] = $customer;
    }

    // Merge duplicate display cards by normalized phone. Historical duplicate rows are not deleted here
    // because orders / memberships may reference them; the directory presents one canonical customer card.
    $deduped = [];
    foreach ($rows as $row) {
        $phoneKey = preg_replace('/\D+/', '', (string)($row['phone'] ?? '')) ?: '';
        $key = $phoneKey !== '' ? 'phone:' . $phoneKey : 'id:' . (string)($row['id'] ?? '');
        if (!isset($deduped[$key])) {
            $deduped[$key] = $row;
            continue;
        }
        $current = $deduped[$key];
        $currentIsMember = !empty($current['membership_id']);
        $rowIsMember = !empty($row['membership_id']);
        // Prefer a membership-bearing record as the canonical detail card.
        if ($rowIsMember && !$currentIsMember) {
            $row['visit_count'] = (int)($row['visit_count'] ?? 0) + (int)($current['visit_count'] ?? 0);
            $row['last_visit'] = max((string)($row['last_visit'] ?? ''), (string)($current['last_visit'] ?? '')) ?: null;
            $deduped[$key] = $row;
        } else {
            $current['visit_count'] = (int)($current['visit_count'] ?? 0) + (int)($row['visit_count'] ?? 0);
            $a = (string)($current['last_visit'] ?? '');
            $b = (string)($row['last_visit'] ?? '');
            if ($b !== '' && ($a === '' || strtotime($b) > strtotime($a))) $current['last_visit'] = $b;
            $deduped[$key] = $current;
        }
    }
    $rows = array_values($deduped);
    $uniqueCustomerCount = count($rows);

    $needle = mb_strtolower(trim($q), 'UTF-8');
    if ($needle !== '') {
        $rows = array_values(array_filter($rows, static function($row) use ($needle) {
            $hay = mb_strtolower(implode(' ', [
                (string)($row['name'] ?? ''),
                (string)($row['phone'] ?? ''),
                (string)($row['member_number'] ?? ''),
                (string)($row['email'] ?? ''),
                (string)($row['identification_number'] ?? ''),
            ]), 'UTF-8');
            return str_contains($hay, $needle);
        }));
    }

    $monthStart = date('Y-m-01 00:00:00');
    $activeMembers = 0;
    $walletTotal = 0.0;
    $newThisMonth = 0;
    foreach ($customers as $customer) {
        if (!empty($membersByCustomer[(string)$customer['id']]) && ($membersByCustomer[(string)$customer['id']]['status'] ?? '') === 'active') {
            $activeMembers++;
            $mid = (string)$membersByCustomer[(string)$customer['id']]['id'];
            $walletTotal += (float)($walletByMember[$mid] ?? 0);
        }
        if (!empty($customer['created_at']) && strtotime((string)$customer['created_at']) >= strtotime($monthStart)) $newThisMonth++;
    }

    return [
        'customers' => array_slice($rows, 0, 60),
        'summary' => [
            'customers' => $uniqueCustomerCount,
            'members' => $activeMembers,
            'new_this_month' => $newThisMonth,
            'wallet_total' => $walletTotal,
        ],
        'levels' => array_values(array_filter($levels, static fn($row) => !empty($row['active']))),
    ];
}

/**
 * v13.5.3 order-intake customer search.
 * Uses the already de-duplicated current-store customer dataset, then performs
 * a tolerant local fuzzy match so a customer visible in 顾客与会员 is also
 * guaranteed to be discoverable in 新建顾客订单.
 */
function salonos_supabase_customer_search_rows(string $query, int $limit=20): array
{
    $query = trim($query);
    if ($query === '') return [];
    $dataset = salonos_supabase_customer_dataset($query);
    $rows = is_array($dataset['customers'] ?? null) ? $dataset['customers'] : [];
    $needle = mb_strtolower(preg_replace('/\s+/u',' ', $query) ?? $query, 'UTF-8');
    $digits = preg_replace('/\D+/', '', $query) ?: '';

    $matched = [];
    foreach ($rows as $row) {
        $name = mb_strtolower((string)($row['name'] ?? ''), 'UTF-8');
        $phone = (string)($row['phone'] ?? '');
        $phoneDigits = preg_replace('/\D+/', '', $phone) ?: '';
        $memberNumber = mb_strtolower((string)($row['member_number'] ?? ''), 'UTF-8');
        $email = mb_strtolower((string)($row['email'] ?? ''), 'UTF-8');
        $idNo = mb_strtolower((string)($row['identification_number'] ?? ''), 'UTF-8');

        $ok = str_contains($name, $needle)
            || str_contains($memberNumber, $needle)
            || str_contains($email, $needle)
            || str_contains($idNo, $needle)
            || ($digits !== '' && str_contains($phoneDigits, $digits));

        if (!$ok) continue;

        $score = 0;
        if ($name === $needle) $score += 100;
        elseif (str_starts_with($name, $needle)) $score += 70;
        elseif (str_contains($name, $needle)) $score += 40;
        if ($digits !== '' && $phoneDigits === $digits) $score += 100;
        elseif ($digits !== '' && str_starts_with($phoneDigits, $digits)) $score += 60;
        elseif ($digits !== '' && str_contains($phoneDigits, $digits)) $score += 30;
        if ($memberNumber === $needle) $score += 80;
        if (!empty($row['membership_id'])) $score += 5;

        $row['_search_score'] = $score;
        $matched[] = $row;
    }

    usort($matched, static function(array $a, array $b): int {
        $score = ((int)($b['_search_score'] ?? 0)) <=> ((int)($a['_search_score'] ?? 0));
        if ($score !== 0) return $score;
        $visits = ((int)($b['visit_count'] ?? 0)) <=> ((int)($a['visit_count'] ?? 0));
        if ($visits !== 0) return $visits;
        return strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? ''));
    });

    foreach ($matched as &$row) unset($row['_search_score']);
    unset($row);
    return array_slice($matched, 0, max(1, min(50, $limit)));
}

function salonos_supabase_customer_detail(string $customerId): ?array
{
    if (!salonos_is_uuid($customerId)) return null;
    $identity = salonos_supabase_identity();
    $org = trim((string)($identity['organization_id'] ?? ''));
    $store = salonos_supabase_current_store_uuid();
    $token = salonos_supabase_access_token();
    $customers = salonos_supabase_rest_rows('customers',
        'select=id,organization_id,store_id,name,phone,gender,birth_date,ethnicity,identification_number,email,address,acquisition_platform,notes,created_at,updated_at'
        . '&id=eq.' . rawurlencode($customerId)
        . '&organization_id=eq.' . rawurlencode($org)
        . '&store_id=eq.' . rawurlencode($store)
        . '&limit=1', $token);
    $customer = $customers[0] ?? null;
    if (!$customer) return null;

    $members = salonos_supabase_rest_rows('memberships',
        'select=id,organization_id,customer_id,current_level_id,member_number,status,joined_at,notes,created_at,updated_at'
        . '&organization_id=eq.' . rawurlencode($org)
        . '&customer_id=eq.' . rawurlencode($customerId)
        . '&limit=1', $token);
    $member = $members[0] ?? null;
    $levels = salonos_supabase_membership_levels_rows();
    $levelsById = [];
    foreach ($levels as $level) $levelsById[(string)$level['id']] = $level;

    $wallet = [];
    $loyalty = [];
    $walletBalance = 0.0;
    $points = 0.0;
    $experience = 0.0;
    $totalSpend = 0.0;
    if ($member) {
        $membershipId = (string)$member['id'];
        $wallet = salonos_supabase_rest_rows('member_wallet_ledger',
            'select=id,membership_id,amount_delta,transaction_type,reference_type,reference_id,notes,created_at'
            . '&membership_id=eq.' . rawurlencode($membershipId)
            . '&order=created_at.desc&limit=30', $token);
        foreach ($wallet as $row) $walletBalance += (float)($row['amount_delta'] ?? 0);
        $loyalty = salonos_supabase_rest_rows('member_loyalty_ledger',
            'select=id,membership_id,experience_delta,points_delta,transaction_type,reference_type,reference_id,notes,created_at'
            . '&membership_id=eq.' . rawurlencode($membershipId)
            . '&order=created_at.desc&limit=30', $token);
        foreach ($loyalty as $row) {
            $points += (float)($row['points_delta'] ?? 0);
            $experience += (float)($row['experience_delta'] ?? 0);
            if (($row['transaction_type'] ?? '') === 'purchase' && (float)($row['experience_delta'] ?? 0) > 0) $totalSpend += (float)$row['experience_delta'];
        }
    }

    $level = $member ? ($levelsById[(string)($member['current_level_id'] ?? '')] ?? salonos_supabase_level_for_experience($levels, $experience)) : null;
    $next = null;
    foreach ($levels as $candidate) {
        if (empty($candidate['active'])) continue;
        if ((float)($candidate['min_experience'] ?? 0) > $experience) {
            if (!$next || (float)$candidate['min_experience'] < (float)$next['min_experience']) $next = $candidate;
        }
    }

    $productSales = [];
    if ($member) {
        try {
            $productSales = salonos_supabase_rest_rows('v13_member_product_sales',
                'select=id,total_amount,wallet_amount,external_amount,external_method,status,created_at'
                . '&organization_id=eq.' . rawurlencode($org)
                . '&store_id=eq.' . rawurlencode($store)
                . '&membership_id=eq.' . rawurlencode((string)$member['id'])
                . '&order=created_at.desc&limit=20', $token);
            $saleIds=array_values(array_filter(array_map(static fn($r)=>(string)($r['id']??''),$productSales)));
            $itemsBySale=[];
            if($saleIds){
                $in='('.implode(',',array_map('rawurlencode',$saleIds)).')';
                $saleItems=salonos_supabase_rest_rows('v13_member_product_sale_items',
                    'select=sale_id,product_name_snapshot,sku_snapshot,quantity,unit_price,line_total'
                    . '&organization_id=eq.' . rawurlencode($org)
                    . '&store_id=eq.' . rawurlencode($store)
                    . '&sale_id=in.' . $in . '&order=created_at.asc&limit=200', $token);
                foreach($saleItems as $item)$itemsBySale[(string)($item['sale_id']??'')][]=$item;
            }
            foreach($productSales as &$sale)$sale['items']=$itemsBySale[(string)($sale['id']??'')]??[];
            unset($sale);
        } catch (Throwable $ignored) { $productSales = []; }
    }

    return [
        'customer' => $customer,
        'membership' => $member,
        'level' => $level,
        'next_level' => $next,
        'wallet_rows' => $wallet,
        'loyalty_rows' => $loyalty,
        'wallet_balance' => $walletBalance,
        'points' => $points,
        'experience' => $experience,
        'total_spend' => $totalSpend,
        'levels' => $levels,
        'product_sales' => $productSales,
    ];
}

function salonos_supabase_create_membership_for_customer(string $customerId): string
{
    $identity = salonos_supabase_identity();
    $org = trim((string)($identity['organization_id'] ?? ''));
    $token = salonos_supabase_access_token();
    $existing = salonos_supabase_rest_rows('memberships',
        'select=id&organization_id=eq.' . rawurlencode($org) . '&customer_id=eq.' . rawurlencode($customerId) . '&limit=1', $token);
    if (!empty($existing[0]['id'])) return (string)$existing[0]['id'];

    $levels = array_values(array_filter(salonos_supabase_membership_levels_rows(), static fn($row) => !empty($row['active'])));
    usort($levels, static fn($a,$b) => ((float)($a['min_experience'] ?? 0) <=> (float)($b['min_experience'] ?? 0)) ?: ((int)($a['level_number'] ?? 0) <=> (int)($b['level_number'] ?? 0)));
    $level = $levels[0] ?? null;
    if (!$level) throw new RuntimeException('Supabase 还没有会员等级 1，请先建立 Membership Level。');

    $memberNumber = 'MEM-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
    $result = salonos_supabase_rest_write('memberships', 'select=id,member_number', 'POST', [
        'organization_id' => $org,
        'customer_id' => $customerId,
        'current_level_id' => (string)$level['id'],
        'member_number' => $memberNumber,
        'status' => 'active',
        'joined_at' => date('Y-m-d'),
    ]);
    if (!empty($result[0]['id'])) return (string)$result[0]['id'];
    throw new RuntimeException('会员建立失败，Supabase 没有返回 Membership ID。');
}

function salonos_supabase_create_customer_data(): array
{
    $identity = salonos_supabase_identity();
    $org = trim((string)($identity['organization_id'] ?? ''));
    $store = salonos_supabase_current_store_uuid();
    $token = salonos_supabase_access_token();
    $name = trim((string)($_POST['name'] ?? ''));
    $phone = trim((string)($_POST['phone'] ?? ''));
    if ($name === '' || $phone === '') throw new RuntimeException('姓名与电话号码为必填。');

    // v13.5.0 canonical-customer rule:
    // within the same organization + store, the normalized phone identifies a returning customer.
    // Do not create another non-member card just because staff typed the customer again during a new order.
    $digits = preg_replace('/\D+/', '', $phone) ?: '';
    $existing = [];
    if ($digits !== '') {
        $existing = salonos_supabase_rest_rows(
            'customers',
            'select=id,name,phone,gender,birth_date,ethnicity,identification_number,email,address,acquisition_platform,notes,created_at'
            . '&organization_id=eq.' . rawurlencode($org)
            . '&store_id=eq.' . rawurlencode($store)
            . '&order=created_at.asc&limit=1000',
            $token
        );
        $existing = array_values(array_filter($existing, static function($row) use ($digits) {
            return (preg_replace('/\D+/', '', (string)($row['phone'] ?? '')) ?: '') === $digits;
        }));
    }
    if ($existing) {
        $customerId = (string)$existing[0]['id'];
        $patch = [
            'name' => $name,
            'phone' => $phone,
            'gender' => in_array($_POST['gender'] ?? '', ['male','female','unspecified'], true) ? $_POST['gender'] : ($existing[0]['gender'] ?? 'unspecified'),
            'birth_date' => trim((string)($_POST['birth_date'] ?? '')) ?: ($existing[0]['birth_date'] ?? null),
            'ethnicity' => trim((string)($_POST['ethnicity'] ?? '')) ?: ($existing[0]['ethnicity'] ?? null),
            'identification_number' => trim((string)($_POST['identification_number'] ?? '')) ?: ($existing[0]['identification_number'] ?? null),
            'email' => trim((string)($_POST['email'] ?? '')) ?: ($existing[0]['email'] ?? null),
            'address' => trim((string)($_POST['address'] ?? '')) ?: ($existing[0]['address'] ?? null),
            'acquisition_platform' => trim((string)($_POST['acquisition_platform'] ?? '')) ?: ($existing[0]['acquisition_platform'] ?? null),
            'notes' => trim((string)($_POST['notes'] ?? '')) ?: ($existing[0]['notes'] ?? null),
            'updated_at' => date(DATE_ATOM),
        ];
        salonos_supabase_rest_write('customers', 'id=eq.' . rawurlencode($customerId) . '&select=id', 'PATCH', $patch);
        if (!empty($_POST['is_member'])) salonos_supabase_create_membership_for_customer($customerId);
        return ['message'=>'这位顾客以前来过，系统已沿用原本顾客资料，不会建立重复记录。','customer_id'=>$customerId];
    }

    $body = [
        'organization_id' => $org,
        'store_id' => $store,
        'name' => $name,
        'phone' => $phone,
        'gender' => in_array($_POST['gender'] ?? '', ['male','female','unspecified'], true) ? $_POST['gender'] : 'unspecified',
        'birth_date' => trim((string)($_POST['birth_date'] ?? '')) ?: null,
        'ethnicity' => trim((string)($_POST['ethnicity'] ?? '')) ?: null,
        'identification_number' => trim((string)($_POST['identification_number'] ?? '')) ?: null,
        'email' => trim((string)($_POST['email'] ?? '')) ?: null,
        'address' => trim((string)($_POST['address'] ?? '')) ?: null,
        'acquisition_platform' => trim((string)($_POST['acquisition_platform'] ?? '')) ?: null,
        'notes' => trim((string)($_POST['notes'] ?? '')) ?: null,
    ];
    $result = salonos_supabase_rest_write('customers', 'select=id,name,phone', 'POST', $body);
    $customer = $result[0] ?? null;
    if (!$customer || empty($customer['id'])) throw new RuntimeException('顾客建立失败，Supabase 没有返回 Customer ID。');
    $customerId = (string)$customer['id'];
    if (!empty($_POST['is_member'])) salonos_supabase_create_membership_for_customer($customerId);
    return ['message'=>'顾客资料已建立。','customer_id'=>$customerId];
}

function salonos_supabase_update_customer_data(): array
{
    $customerId = trim((string)($_POST['customer_id'] ?? ''));
    if (!salonos_is_uuid($customerId)) throw new RuntimeException('顾客 ID 无效。');
    $detail = salonos_supabase_customer_detail($customerId);
    if (!$detail) throw new RuntimeException('找不到顾客。');
    $name = trim((string)($_POST['name'] ?? ''));
    $phone = trim((string)($_POST['phone'] ?? ''));
    if ($name === '' || $phone === '') throw new RuntimeException('姓名与电话号码为必填。');
    salonos_supabase_rest_write('customers', 'id=eq.' . rawurlencode($customerId) . '&select=id', 'PATCH', [
        'name' => $name,
        'phone' => $phone,
        'gender' => in_array($_POST['gender'] ?? '', ['male','female','unspecified'], true) ? $_POST['gender'] : 'unspecified',
        'birth_date' => trim((string)($_POST['birth_date'] ?? '')) ?: null,
        'ethnicity' => trim((string)($_POST['ethnicity'] ?? '')) ?: null,
        'identification_number' => trim((string)($_POST['identification_number'] ?? '')) ?: null,
        'email' => trim((string)($_POST['email'] ?? '')) ?: null,
        'address' => trim((string)($_POST['address'] ?? '')) ?: null,
        'acquisition_platform' => trim((string)($_POST['acquisition_platform'] ?? '')) ?: null,
        'notes' => trim((string)($_POST['notes'] ?? '')) ?: null,
        'updated_at' => date(DATE_ATOM),
    ]);
    if (!empty($_POST['is_member']) && empty($detail['membership'])) salonos_supabase_create_membership_for_customer($customerId);
    return ['message'=>'顾客与会员资料已经更新。','customer_id'=>$customerId];
}

function salonos_supabase_topup_member_wallet_data(): array
{
    $membershipId = trim((string)($_POST['membership_id'] ?? ''));
    $amount = round((float)($_POST['amount'] ?? 0), 2);
    if (!salonos_is_uuid($membershipId) || $amount <= 0) throw new RuntimeException('充值金额必须大于 RM 0。');
    $method = strtolower(trim((string)($_POST['topup_payment_method'] ?? 'cash')));
    if (!in_array($method,['cash','card','ewallet'],true)) $method='cash';
    $methodLabel = ['cash'=>'现金','card'=>'银行卡 / Card','ewallet'=>'电子钱包'][$method] ?? '现金';
    $noteText = trim((string)($_POST['note'] ?? ''));
    $note = $methodLabel . '充值' . ($noteText!=='' ? ' · '.$noteText : '');
    salonos_supabase_rpc_try('top_up_member_wallet', [
        ['target_membership_id'=>$membershipId,'amount'=>$amount,'notes'=>$note],
        ['membership_id'=>$membershipId,'amount'=>$amount,'notes'=>$note],
        ['p_membership_id'=>$membershipId,'p_amount'=>$amount,'p_notes'=>$note],
    ]);
    $token = salonos_supabase_access_token();
    $rows = salonos_supabase_rest_rows('member_wallet_ledger',
        'select=amount_delta&membership_id=eq.' . rawurlencode($membershipId) . '&limit=5000', $token);
    $balance = 0.0;
    foreach ($rows as $row) $balance += (float)($row['amount_delta'] ?? 0);
    $members = salonos_supabase_rest_rows('memberships','select=customer_id&id=eq.'.rawurlencode($membershipId).'&limit=1',$token);
    return [
        'message'=>'充值成功，当前会员余额 '.money($balance).'。',
        'membership_id'=>$membershipId,
        'customer_id'=>(string)($members[0]['customer_id'] ?? ''),
        'wallet_balance'=>$balance,
        'wallet_balance_text'=>money($balance),
    ];
}


function salonos_supabase_member_product_purchase_data(): array
{
    $membershipId = trim((string)($_POST['membership_id'] ?? ''));
    $productId = trim((string)($_POST['product_id'] ?? ''));
    $quantity = max(0.001, (float)($_POST['quantity'] ?? 1));
    $walletAmount = max(0, (float)($_POST['wallet_amount'] ?? 0));
    $externalMethod = strtolower(trim((string)($_POST['external_method'] ?? 'cash')));
    if (!in_array($externalMethod,['cash','card','ewallet','none'],true)) $externalMethod='cash';
    $externalAmount = max(0, (float)($_POST['external_amount'] ?? 0));
    if (!salonos_is_uuid($membershipId) || !salonos_is_uuid($productId)) throw new RuntimeException('请先选择会员与销售产品。');
    $result = salonos_supabase_rpc_try('v1353_member_product_purchase', [[
        'p_store_id'=>salonos_supabase_current_store_uuid(),
        'p_membership_id'=>$membershipId,
        'p_product_id'=>$productId,
        'p_quantity'=>$quantity,
        'p_wallet_amount'=>$walletAmount,
        'p_external_method'=>$externalMethod,
        'p_external_amount'=>$externalAmount,
    ]]);
    if (is_array($result) && array_is_list($result)) $result = is_array($result[0]??null)?$result[0]:[];
    $members = salonos_supabase_rest_rows('memberships','select=customer_id&id=eq.'.rawurlencode($membershipId).'&limit=1',salonos_supabase_access_token());
    $productName=(string)($result['product_name']??'产品');
    $total=(float)($result['total_amount']??0);
    return [
        'message'=>'产品购买完成：'.$productName.' · '.money($total).'。库存、会员经验与积分已同步更新。',
        'membership_id'=>$membershipId,
        'customer_id'=>(string)($result['customer_id']??$members[0]['customer_id']??''),
        'wallet_balance'=>(float)($result['wallet_balance']??0),
        'sale_id'=>(string)($result['sale_id']??''),
    ];
}

function salonos_supabase_save_membership_rules_data(): void
{
    $identity = salonos_supabase_identity();
    $org = trim((string)($identity['organization_id'] ?? ''));
    $levelsInput = is_array($_POST['levels'] ?? null) ? $_POST['levels'] : [];
    if (!$levelsInput) throw new RuntimeException('至少需要一个会员等级。');
    $existing = salonos_supabase_membership_levels_rows();
    $existingByNumber = [];
    foreach ($existing as $row) $existingByNumber[(int)$row['level_number']] = $row;
    $seen = [];
    foreach (array_values($levelsInput) as $index => $row) {
        $number = $index + 1;
        $seen[$number] = true;
        $name = trim((string)($row['name'] ?? ''));
        $required = max(0, (float)($row['required'] ?? 0));
        if ($number === 1) $required = 0;
        if ($name === '') throw new RuntimeException('会员等级名称不能为空。');
        if (isset($existingByNumber[$number])) {
            salonos_supabase_rest_write('membership_levels',
                'organization_id=eq.'.rawurlencode($org).'&level_number=eq.'.$number.'&select=id', 'PATCH', [
                    'name'=>$name,
                    'min_experience'=>$required,
                    'active'=>true,
                    'updated_at'=>date(DATE_ATOM),
                ]);
        } else {
            salonos_supabase_rest_write('membership_levels','select=id','POST',[
                'organization_id'=>$org,
                'level_number'=>$number,
                'name'=>$name,
                'min_experience'=>$required,
                'discount_percent'=>0,
                'points_multiplier'=>1,
                'active'=>true,
            ]);
        }
    }
    foreach ($existingByNumber as $number => $row) {
        if (!isset($seen[$number])) {
            salonos_supabase_rest_write('membership_levels', 'id=eq.'.rawurlencode((string)$row['id']).'&select=id','PATCH',['active'=>false,'updated_at'=>date(DATE_ATOM)]);
        }
    }
    salonos_supabase_refresh_all_membership_levels();
}

function salonos_supabase_refresh_all_membership_levels(): void
{
    $levels = array_values(array_filter(salonos_supabase_membership_levels_rows(), static fn($row) => !empty($row['active'])));
    $members = salonos_supabase_memberships_rows();
    $loyalty = salonos_supabase_loyalty_ledgers_rows();
    $experienceByMember = [];
    foreach ($loyalty as $row) {
        $id = (string)($row['membership_id'] ?? '');
        $experienceByMember[$id] = ($experienceByMember[$id] ?? 0) + (float)($row['experience_delta'] ?? 0);
    }
    foreach ($members as $member) {
        $mid = (string)$member['id'];
        $level = salonos_supabase_level_for_experience($levels, (float)($experienceByMember[$mid] ?? 0));
        if (!$level || (string)($member['current_level_id'] ?? '') === (string)$level['id']) continue;
        salonos_supabase_rest_write('memberships', 'id=eq.'.rawurlencode($mid).'&select=id', 'PATCH', ['current_level_id'=>(string)$level['id'],'updated_at'=>date(DATE_ATOM)]);
    }
}

function salonos_supabase_wallet_type_label(string $type): string
{
    return [
        'top_up'=>'会员充值','payment'=>'消费付款','refund'=>'退款','adjustment'=>'余额调整',
        'topup'=>'会员充值','service_payment'=>'支付服务订单','product_payment'=>'购买产品'
    ][$type] ?? $type;
}

function salonos_supabase_loyalty_type_label(string $type): string
{
    return ['purchase'=>'消费获得','redeem'=>'积分兑换','refund'=>'退款调整','adjustment'=>'积分调整'][$type] ?? $type;
}

function salonos_supabase_member_workspace_content(string $customerId): string
{
    $detail = salonos_supabase_customer_detail($customerId);
    if (!$detail) return '<section class="card empty-state"><h3>找不到顾客</h3><p>这位顾客可能不属于当前 Supabase 分行。</p></section>';
    $c = $detail['customer'];
    $m = $detail['membership'];
    $level = $detail['level'];
    $next = $detail['next_level'];
    $experience = (float)$detail['experience'];
    $progress = 100;
    if ($next) {
        $currentMin = (float)($level['min_experience'] ?? 0);
        $nextMin = (float)($next['min_experience'] ?? max(1,$currentMin+1));
        $progress = min(100,max(0,($experience-$currentMin)/max(1,$nextMin-$currentMin)*100));
    }
    ob_start(); ?>
    <div data-member-workspace data-customer-id="<?=e($customerId)?>">
      <section class="card member-workspace-hero"><div class="member-workspace-head"><div class="member-workspace-profile"><div class="customer-large-avatar"><?=e(mb_substr((string)$c['name'],0,1))?></div><div><span class="eyebrow">SUPABASE CUSTOMER PROFILE</span><h2><?=e((string)$c['name'])?></h2><p><?=e((string)$c['phone'])?><?=$m?' · '.e((string)$m['member_number']):' · 非会员'?></p></div></div><div class="member-workspace-tags"><?=$m?'<span class="badge badge-gold">LV'.intval($level['level_number']??1).'</span>':'<span class="badge badge-gray">非会员</span>'?></div></div>
      <?php if($m): ?><section class="member-overview member-overview-embedded"><div><span>会员等级</span><strong>LV<?=intval($level['level_number']??1)?></strong><small><?=e((string)($level['name']??'等级 1'))?></small></div><div><span>可用积分</span><strong><?=number_format((float)$detail['points'],0)?></strong><small>来自 Supabase Loyalty Ledger</small></div><div><span>储值余额</span><strong><?=money((float)$detail['wallet_balance'])?></strong><small>来自 Supabase Wallet Ledger</small></div><div><span>累计消费</span><strong><?=money((float)$detail['total_spend'])?></strong><small><?=number_format($experience,0)?> 经验</small></div></section><div class="member-level-progress member-level-progress-embedded"><div><span>等级成长</span><strong><?=$next?'距离 '.e((string)$next['name']).' 还差 '.max(0,(int)ceil((float)$next['min_experience']-$experience)).' 经验':'已达到最高等级'?></strong></div><div class="progress"><span style="width:<?=number_format($progress,2,'.','')?>%"></span></div></div><?php else: ?><div class="nonmember-invite workspace-nonmember"><span>这位顾客还不是会员</span><small>勾选下方“升级为会员”后，会直接在 Supabase 建立 Membership。</small></div><?php endif; ?></section>

      <section class="card member-form-card"><div class="card-head"><div><span class="card-kicker">SUPABASE PROFILE</span><h3>修改顾客资料</h3></div><span class="badge badge-green">Supabase</span></div><form method="post" class="card-body" data-member-ajax-form><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="update_customer"><input type="hidden" name="ajax" value="1"><input type="hidden" name="customer_id" value="<?=e($customerId)?>"><div class="form-grid"><div class="field"><label>姓名 *</label><input class="input" name="name" value="<?=e((string)$c['name'])?>" required></div><div class="field"><label>电话号码 *</label><input class="input" name="phone" value="<?=e((string)$c['phone'])?>" required></div><div class="field"><label>性别</label><select class="select" name="gender"><option value="unspecified" <?=($c['gender']??'')==='unspecified'?'selected':''?>>不填写</option><option value="male" <?=($c['gender']??'')==='male'?'selected':''?>>男</option><option value="female" <?=($c['gender']??'')==='female'?'selected':''?>>女</option></select></div><div class="field"><label>出生日期</label><input class="input" type="date" name="birth_date" value="<?=e((string)($c['birth_date']??''))?>"></div><div class="field span-2"><label>族群</label><input class="input" name="ethnicity" value="<?=e((string)($c['ethnicity']??''))?>"></div><div class="field"><label>Email</label><input class="input" type="email" name="email" value="<?=e((string)($c['email']??''))?>"></div><div class="field"><label>身份证／证件号码</label><input class="input" name="identification_number" value="<?=e((string)($c['identification_number']??''))?>"></div><div class="field span-2"><label>地址</label><input class="input" name="address" value="<?=e((string)($c['address']??''))?>"></div><div class="field span-2"><label>顾客来源平台</label><input class="input" name="acquisition_platform" value="<?=e((string)($c['acquisition_platform']??''))?>" placeholder="例如 Google Search / Facebook"></div><div class="field span-2"><label>备注</label><textarea class="textarea" name="notes" rows="3"><?=e((string)($c['notes']??''))?></textarea></div><?php if(!$m): ?><label class="confirm-checkbox span-2"><input type="checkbox" name="is_member" value="1"><span>升级为会员，自动从 Supabase 等级 1 开始。</span></label><?php else: ?><input type="hidden" name="is_member" value="1"><?php endif; ?></div><div class="form-actions"><button class="btn btn-primary" type="submit">保存顾客</button></div></form></section>

      <?php if($m): $productCategories=function_exists('v1353_product_categories')?v1353_product_categories(true):[]; ?><div class="member-money-grid"><section class="card member-form-card"><div class="card-head"><div><span class="card-kicker">SUPABASE TOP UP</span><h3>会员充值</h3><p>充值资金进入 Wallet Ledger；可记录现金、银行卡或电子钱包收款。</p></div></div><form method="post" class="card-body" data-member-ajax-form><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="topup_member_wallet"><input type="hidden" name="ajax" value="1"><input type="hidden" name="membership_id" value="<?=e((string)$m['id'])?>"><div class="field"><label>充值金额 RM</label><input class="input" type="number" min="0.01" step="0.01" name="amount" required></div><div class="field"><label>收款方式</label><select class="select" name="topup_payment_method"><option value="cash">现金</option><option value="card">银行卡 / Card</option><option value="ewallet">电子钱包</option></select></div><div class="field"><label>备注</label><input class="input" name="note" placeholder="例如：柜台充值"></div><button class="btn btn-primary btn-block" type="submit">确认充值</button></form></section><section class="card member-form-card member-product-purchase-card"><div class="card-head"><div><span class="card-kicker">MEMBER RETAIL</span><h3>会员购买门店产品</h3><p>先选分类，再即时搜索该分类的销售产品；可用会员储值，或现金 / 银行卡 / 电子钱包支付。</p></div><span class="badge badge-gold">余额 <?=money((float)$detail['wallet_balance'])?></span></div><form method="post" class="card-body" data-member-product-ajax data-v1353-product-purchase data-member-product-payment data-wallet-max="<?=e((string)(float)$detail['wallet_balance'])?>"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="member_product_purchase_v1353"><input type="hidden" name="ajax" value="1"><input type="hidden" name="membership_id" value="<?=e((string)$m['id'])?>"><input type="hidden" name="product_id" data-product-id><div class="field"><label>产品分类</label><select class="select" data-product-category required><option value="">先选择产品分类</option><?php foreach($productCategories as $cat):?><option value="<?=e((string)$cat['id'])?>"><?=e((string)$cat['name'])?></option><?php endforeach;?></select></div><div class="field product-search-field"><label>搜索销售产品</label><input class="input" type="search" data-product-search placeholder="输入产品名称 / SKU / Barcode"><div class="product-search-results" data-product-results hidden></div></div><div class="selected-product-card" data-selected-product hidden><div class="product-search-thumb"><img data-selected-product-image hidden alt=""><b data-selected-product-placeholder>P</b></div><div><strong data-selected-product-name></strong><small data-selected-product-stock></small><small data-selected-product-description></small></div><strong data-selected-product-price></strong></div><div class="form-grid"><div class="field"><label>数量</label><input class="input" type="number" name="quantity" min="1" step="1" value="1" data-product-quantity></div><div class="field"><label>商品总额</label><input class="input" type="text" value="RM 0.00" readonly data-product-total></div><div class="field"><label>使用会员储值 RM</label><input class="input" type="number" name="wallet_amount" min="0" step="0.01" value="0" data-member-wallet-amount></div><div class="field"><label>剩余付款方式</label><select class="select" name="external_method" data-member-external-method><option value="cash">现金</option><option value="card">银行卡 / Card</option><option value="ewallet">电子钱包</option><option value="none">全部使用会员储值</option></select></div><div class="field span-2"><label>剩余应付 RM</label><input class="input" type="number" name="external_amount" step="0.01" value="0" readonly data-member-external-amount></div></div><button class="btn btn-primary btn-block" type="submit">确认购买产品</button></form></section></div>
      <section class="card member-history-card"><div class="card-head"><div><span class="card-kicker">SUPABASE LEDGER</span><h3>会员记录</h3></div></div><div class="member-ledger-grid"><div><h4>储值记录</h4><?php foreach($detail['wallet_rows'] as $row): ?><div class="ledger-row"><div><strong><?=e(salonos_supabase_wallet_type_label((string)($row['transaction_type']??'')))?></strong><small><?=e(!empty($row['created_at'])?app_date((string)$row['created_at'],true):'')?> · <?=e((string)($row['notes']??''))?></small></div><span class="<?=((float)($row['amount_delta']??0))>=0?'positive':'negative'?>"><?=((float)($row['amount_delta']??0))>=0?'+':''?><?=money((float)($row['amount_delta']??0))?></span></div><?php endforeach; ?><?php if(!$detail['wallet_rows']): ?><p class="muted">还没有储值记录。</p><?php endif; ?></div><div><h4>积分记录</h4><?php foreach($detail['loyalty_rows'] as $row): ?><div class="ledger-row"><div><strong><?=e(salonos_supabase_loyalty_type_label((string)($row['transaction_type']??'')))?></strong><small><?=e(!empty($row['created_at'])?app_date((string)$row['created_at'],true):'')?> · <?=e((string)($row['notes']??''))?></small></div><span class="<?=((float)($row['points_delta']??0))>=0?'positive':'negative'?>"><?=((float)($row['points_delta']??0))>=0?'+':''?><?=number_format((float)($row['points_delta']??0),0)?> 分</span></div><?php endforeach; ?><?php if(!$detail['loyalty_rows']): ?><p class="muted">还没有积分记录。</p><?php endif; ?></div></div><?php if(!empty($detail['product_sales'])):?><div class="member-retail-history"><h4>最近产品购买</h4><?php foreach($detail['product_sales'] as $sale): $saleNames=[]; foreach((array)($sale['items']??[]) as $saleItem){$saleNames[]=trim((string)($saleItem['product_name_snapshot']??'产品')).' × '.rtrim(rtrim(number_format((float)($saleItem['quantity']??1),2,'.',''),'0'),'.');} ?><div class="ledger-row"><div><strong><?=e($saleNames?implode(' · ',$saleNames):'门店产品')?> · <?=money((float)($sale['total_amount']??0))?></strong><small><?=e(!empty($sale['created_at'])?app_date((string)$sale['created_at'],true):'')?> · 储值 <?=money((float)($sale['wallet_amount']??0))?> · <?=e(['cash'=>'现金','card'=>'银行卡','ewallet'=>'电子钱包','none'=>'全额储值'][(string)($sale['external_method']??'cash')]??'付款')?></small></div><span class="negative">已付款</span></div><?php endforeach;?></div><?php endif;?></section><?php endif; ?>
    </div>
    <?php return (string)ob_get_clean();
}

function salonos_supabase_member_modal_content(string $customerId): string
{
    if (!salonos_is_uuid($customerId)) return '<div class="commission-modal-error"><strong>顾客 ID 无效</strong><button class="btn btn-light" type="button" data-member-modal-close>关闭</button></div>';
    ob_start(); ?>
    <div class="member-modal-inner"><header class="member-modal-head"><div><span class="eyebrow">SUPABASE CUSTOMER</span><h2>顾客与会员</h2><p>资料直接来自 Supabase。</p></div><button class="commission-modal-close" type="button" data-member-modal-close>×</button></header><div class="member-modal-scroll"><?=salonos_supabase_member_workspace_content($customerId)?></div></div>
    <?php return (string)ob_get_clean();
}

function page_customers_supabase(): void
{
    $q = trim((string)($_GET['q'] ?? ''));
    try {
        $dataset = salonos_supabase_customer_dataset($q);
    } catch (Throwable $error) {
        echo '<section class="card empty-state"><h3>顾客资料暂时无法读取</h3><p>'.e($error->getMessage()).'</p><a class="btn btn-primary" href="index.php?action=logout">重新登录</a></section>';
        return;
    }
    $customers = $dataset['customers'];
    $summary = $dataset['summary'];
    $levels = $dataset['levels'];
    $selectedCustomerId = trim((string)($_GET['customer_id'] ?? ($customers[0]['id'] ?? '')));
    if ($selectedCustomerId !== '' && !salonos_is_uuid($selectedCustomerId)) $selectedCustomerId = '';
    ?>
    <div class="page-head"><div><span class="eyebrow">CUSTOMER DIRECTORY</span><h1>顾客与会员</h1><p>顾客资料、会员等级、积分与储值统一由云端资料库管理，并按门店权限隔离。</p></div><div class="hero-actions"><?php if(can_manage()): ?><button class="btn btn-light" type="button" data-toggle-panel="membership-rules"><?=ui_icon('target')?> 会员等级</button><?php endif; ?><button class="btn btn-primary" type="button" data-toggle-panel="new-customer"><?=ui_icon('plus')?> 建立顾客</button></div></div>
    <div class="step-note"><strong>云端资料已启用</strong><span>顾客、会员等级与储值已使用统一云端数据。订单、会员储值与门店产品购买现在都使用 Supabase；会员可使用储值或现金 / Card / E-Wallet 购买产品。</span></div>
    <section class="customer-summary member-summary"><div><span>顾客总数</span><strong><?=(int)($summary['customers']??0)?></strong></div><div><span>有效会员</span><strong><?=(int)($summary['members']??0)?></strong></div><div><span>本月新顾客</span><strong><?=(int)($summary['new_this_month']??0)?></strong></div><div><span>会员储值总额</span><strong><?=money((float)($summary['wallet_total']??0))?></strong></div></section>
    <section class="card customer-search-card"><form class="searchbar"><input type="hidden" name="page" value="customers"><div class="input-shell"><span class="input-icon"><?=ui_icon('search')?></span><input class="input" name="q" value="<?=e($q)?>" placeholder="输入姓名、电话、会员编号、Email 或证件号码"></div><button class="btn btn-primary">搜索顾客</button><?php if($q!==''): ?><a class="btn btn-light" href="index.php?page=customers">清除</a><?php endif; ?></form></section>

    <section class="card collapsible-panel" id="new-customer" hidden><div class="card-head"><div><span class="card-kicker">NEW CUSTOMER</span><h3>建立新顾客资料</h3><p>保存后直接建立顾客资料；勾选会员会同时建立会员账号。</p></div><button class="panel-close" type="button" data-toggle-panel="new-customer"><?=ui_icon('x')?></button></div><form method="post" class="card-body"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="create_customer"><div class="form-grid"><div class="field"><label>姓名 *</label><input class="input" name="name" required></div><div class="field"><label>电话号码 *</label><input class="input" name="phone" inputmode="tel" required></div><div class="field"><label>性别</label><select class="select" name="gender"><option value="unspecified">不填写</option><option value="male">男</option><option value="female">女</option></select></div><div class="field"><label>出生日期</label><input class="input" type="date" name="birth_date"></div><div class="field span-2"><label>族群（选填）</label><input class="input" name="ethnicity" placeholder="华人 / 马来人 / 印度人 / 其他"></div><div class="field"><label>Email</label><input class="input" type="email" name="email"></div><div class="field"><label>身份证／证件号码</label><input class="input" name="identification_number"></div><div class="field span-2"><label>地址</label><input class="input" name="address"></div><div class="field span-2"><label>顾客来源平台</label><input class="input" name="acquisition_platform" placeholder="例如 Google Search / Facebook"></div><label class="confirm-checkbox span-2"><input type="checkbox" name="is_member" value="1"><span>同时建立 Supabase 会员账号；初始等级 1、积分 0、储值余额 RM 0。</span></label><div class="field span-2"><label>顾客备注</label><textarea class="textarea" name="notes" rows="3" placeholder="例如：头皮敏感、过敏记录、沟通偏好"></textarea></div></div><div class="form-actions"><button class="btn btn-light" type="button" data-toggle-panel="new-customer">取消</button><button class="btn btn-primary">保存顾客</button></div></form></section>

    <?php if(can_manage()): ?><section class="card collapsible-panel membership-rules-panel" id="membership-rules" hidden data-membership-level-editor><div class="card-head"><div><span class="card-kicker">MEMBERSHIP LEVELS</span><h3>会员成长等级</h3><p>实际消费会累积经验与积分；这里负责设置会员成长等级门槛。</p></div><button class="panel-close" type="button" data-toggle-panel="membership-rules"><?=ui_icon('x')?></button></div><form method="post" class="card-body"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_membership_rules"><div class="rule-example">等级 1 的门槛固定为 0。修改等级后，现有会员会按当前经验重新匹配等级。</div><div class="membership-level-list" data-membership-level-list><?php foreach($levels as $i=>$level): ?><div class="membership-level-row" data-membership-level-row><div class="level-number">LV<?=$i+1?></div><div class="field"><label>等级名称</label><input class="input" name="levels[<?=$i?>][name]" value="<?=e((string)$level['name'])?>" required></div><div class="field"><label>所需累计经验</label><input class="input" type="number" min="0" step="1" name="levels[<?=$i?>][required]" value="<?=e((string)$level['min_experience'])?>" required <?=$i===0?'readonly':''?>></div><button class="tier-remove" type="button" data-remove-membership-level <?=$i===0?'disabled':''?>>×</button></div><?php endforeach; ?></div><template data-membership-level-template><div class="membership-level-row" data-membership-level-row><div class="level-number">LV0</div><div class="field"><label>等级名称</label><input class="input" data-level-field="name" required></div><div class="field"><label>所需累计经验</label><input class="input" data-level-field="required" type="number" min="1" step="1" required></div><button class="tier-remove" type="button" data-remove-membership-level>×</button></div></template><div class="form-actions"><button class="btn btn-light" type="button" data-add-membership-level>＋ 添加等级</button><button class="btn btn-primary">保存等级</button></div></form></section><?php endif; ?>

    <div class="section-heading"><div><h2><?=$q!==''?'搜索结果':'顾客名单'?></h2><p><?=$q!==''?'找到 '.count($customers).' 位匹配顾客':'左边选择顾客，右边显示顾客与会员详细资料。'?></p></div></div>
    <section class="customer-directory-layout"><aside class="card customer-directory-list-card"><div class="card-head sticky-card-head"><div><span class="card-kicker">CUSTOMER LIST</span><h3><?=$q!==''?'匹配顾客':'最近顾客'?></h3></div><span class="muted"><?=count($customers)?> 位</span></div><div class="customer-directory-list">
    <?php foreach($customers as $c): $active=$selectedCustomerId===(string)$c['id']; $href='index.php?'.http_build_query(['page'=>'customers','q'=>$q!==''?$q:null,'customer_id'=>$c['id']]); ?><a class="customer-directory-item <?=$active?'active':''?>" href="<?=e($href)?>" data-customer-ajax data-customer-id="<?=e((string)$c['id'])?>" data-no-page-loader><div class="customer-directory-main"><div class="customer-large-avatar"><?=e(mb_substr((string)$c['name'],0,1))?></div><div><strong><?=e((string)$c['name'])?></strong><small><?=e((string)$c['phone'])?></small></div></div><div class="customer-directory-side"><?=$c['member_number']?'<span class="badge badge-gold">LV'.intval($c['level_number']??1).'</span>':'<span class="badge badge-gray">非会员</span>'?><small><?=e((string)($c['member_number']?:'未开通会员'))?></small></div><div class="customer-directory-meta"><span>到店 <?=(int)$c['visit_count']?> 次</span><span><?=e($c['last_visit']?app_date((string)$c['last_visit']):'暂无到店')?></span></div></a><?php endforeach; ?>
    <?php if(!$customers): ?><div class="empty compact-empty"><div class="empty-icon"><?=ui_icon('search')?></div><h3>没有找到对应顾客</h3><p>检查姓名或电话，或者建立一份新的顾客资料。</p></div><?php endif; ?></div></aside><div class="customer-directory-detail"><?php if($selectedCustomerId): echo salonos_supabase_member_workspace_content($selectedCustomerId); else: ?><section class="card empty-state"><div class="empty-icon"><?=ui_icon('users')?></div><h3>请选择一位顾客</h3><p>左边会列出当前门店顾客名单。</p></section><?php endif; ?></div></section>
    <?php
}


function salonos_v1354_employee_customer_dataset(string $query='',string $customerId=''): array {
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($session==='') throw new RuntimeException('员工登录已过期，请重新登录。');
    return v13_rpc_json('v1354_employee_customer_directory',['p_session_token'=>$session,'p_query'=>$query,'p_customer_id'=>$customerId!==''?$customerId:null],'');
}
function page_customers_employee_v1354(): void {
    if(!has_any_permission(['customers.view','customers.manage'])){echo '<section class="card empty-state"><h3>没有顾客与会员权限</h3><p>请让老板到「系统设置 → 员工权限角色」开启查看顾客权限。</p></section>';return;}
    $q=trim((string)($_GET['q']??''));$selected=trim((string)($_GET['customer_id']??''));$data=salonos_v1354_employee_customer_dataset($q,$selected);$customers=is_array($data['customers']??null)?$data['customers']:[];$detail=is_array($data['detail']??null)?$data['detail']:null;
    ?>
    <div class="page-head responsive-page-head"><div><span class="eyebrow">CUSTOMERS · EMPLOYEE ACCESS</span><h1>顾客与会员</h1><p>只显示当前分行资料；是否出现这个入口由老板给你的职位权限决定。</p></div><form class="v1354-customer-search" method="get"><input type="hidden" name="page" value="customers"><div class="input-shell"><span class="input-icon"><?=ui_icon('search')?></span><input class="input" name="q" value="<?=e($q)?>" placeholder="搜索姓名 / 手机号 / 会员编号 / Email"></div><button class="btn btn-light">搜索</button></form></div>
    <section class="v1354-customer-grid"><?php foreach($customers as $c):?><a class="card v1354-customer-card <?=($selected===(string)$c['id'])?'active':''?>" href="index.php?<?=e(http_build_query(['page'=>'customers','q'=>$q!==''?$q:null,'customer_id'=>$c['id']]))?>"><div class="customer-large-avatar"><?=e(mb_substr((string)($c['name']??'顾'),0,1))?></div><div><span class="card-kicker"><?=!empty($c['member_number'])?'MEMBER':'CUSTOMER'?></span><h3><?=e((string)$c['name'])?></h3><p><?=e((string)$c['phone'])?></p><small><?=!empty($c['member_number'])?'LV'.intval($c['level_number']??1).' · '.e((string)$c['member_number']):'非会员'?> · 到店 <?=intval($c['visit_count']??0)?> 次</small></div></a><?php endforeach;?><?php if(!$customers):?><section class="card empty-state"><h3>没有找到顾客</h3><p>可以换姓名、手机号或会员编号再搜索。</p></section><?php endif;?></section>
    <?php if($detail):$c=$detail['customer']??[];$m=$detail['membership']??null;?><section class="card v1354-customer-detail"><div class="card-head"><div><span class="card-kicker">CUSTOMER DETAIL</span><h2><?=e((string)($c['name']??''))?></h2><p><?=e((string)($c['phone']??''))?> · <?=$m?'会员 '.e((string)($m['member_number']??'')):'非会员'?></p></div><a class="btn btn-primary" href="index.php?page=new_visit&customer_id=<?=e((string)($c['id']??''))?>">为顾客建立订单</a></div><div class="v1354-customer-detail-grid"><div><span>性别</span><strong><?=e((string)($c['gender']??'—'))?></strong></div><div><span>出生日期</span><strong><?=e((string)($c['birth_date']??'—'))?></strong></div><div><span>族群</span><strong><?=e((string)($c['ethnicity']??'—'))?></strong></div><div><span>Email</span><strong><?=e((string)($c['email']??'—'))?></strong></div><div><span>到店次数</span><strong><?=intval($detail['visit_count']??0)?></strong></div><div><span>会员积分</span><strong><?=number_format((float)($detail['points']??0),0)?></strong></div><div><span>经验</span><strong><?=number_format((float)($detail['experience']??0),0)?></strong></div><div><span>储值余额</span><strong><?=money($detail['wallet_balance']??0)?></strong></div></div><?php if(!empty($c['notes'])):?><div class="v1354-customer-note"><span>备注</span><p><?=nl2br(e((string)$c['notes']))?></p></div><?php endif;?></section><?php endif;?>
    <?php
}
