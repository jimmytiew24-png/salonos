<?php
declare(strict_types=1);
require_once __DIR__ . '/v13_supabase.php';

function salonos_v13_phone_normalize(string $phone): string {
    return preg_replace('/\D+/', '', $phone) ?: '';
}

function salonos_v13_employee_login(string $phone): void {
    $phone=salonos_v13_phone_normalize($phone);
    if(strlen($phone)<8) throw new RuntimeException('请输入有效的员工手机号码。');
    [$deviceId] = v13_device_identity();
    $rows=v13_rpc('employee_phone_login',[
        'p_phone'=>$phone,
        'p_device_id'=>$deviceId,
        'p_user_agent'=>substr((string)($_SERVER['HTTP_USER_AGENT']??'Browser'),0,250),
    ],'');
    $row=v13_first_rpc_row($rows);
    $sessionToken=trim((string)($row['session_token']??''));
    if($sessionToken==='') throw new RuntimeException('Supabase 没有返回员工 Session。');
    $_SESSION['v13_employee_session_token']=$sessionToken;
    salonos_v13_apply_employee_context($row);
    session_regenerate_id(true);
}

function salonos_v13_apply_employee_context(array $row): void {
    $employeeId=(string)($row['employee_id']??'');
    $storeId=(string)($row['store_id']??'');
    $orgId=(string)($row['organization_id']??'');
    if($employeeId===''||$storeId===''||$orgId==='') throw new RuntimeException('员工 Supabase Session 资料不完整。');
    $_SESSION['v13_business_user']=[
        'id'=>$employeeId,
        'email'=>'',
        'employee_name'=>(string)($row['employee_name']??'员工'),
        'employee_code'=>(string)($row['employee_code']??''),
        'employee_phone'=>(string)($row['employee_phone']??''),
        'position'=>(string)($row['employee_position']??''),
        'role'=>(string)($row['employee_role']??'staff'),
        'role_label'=>salonos_v13_employee_role_label((string)($row['employee_role']??'staff')),
        'avatar_path'=>(string)($row['avatar_path']??''),
    ];
    $_SESSION['supabase_identity']=[
        'user_id'=>$employeeId,
        'email'=>'',
        'role'=>(string)($row['employee_role']??'staff'),
        'organization_id'=>$orgId,
        'organization_name'=>(string)($row['organization_name']??'SalonOS'),
        'organization_status'=>'active',
        'profile'=>['full_name'=>(string)($row['employee_name']??'员工'),'phone'=>(string)($row['employee_phone']??''),'avatar_path'=>(string)($row['avatar_path']??'')],
        'stores'=>[[
            'id'=>$storeId,'organization_id'=>$orgId,'name'=>(string)($row['store_name']??'SalonOS'),
            'code'=>'','is_main'=>true,'status'=>'active'
        ]],
        'primary_store_id'=>$storeId,
        'employee_id'=>$employeeId,
        'verified_at'=>date(DATE_ATOM),
    ];
    $_SESSION['v13_current_store_uuid']=$storeId;
}

function salonos_v13_refresh_employee_context(): array {
    $sessionToken=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($sessionToken==='') throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    $rows=v13_rpc('employee_session_context',['p_session_token'=>$sessionToken],'');
    $row=v13_first_rpc_row($rows);
    if(empty($row['employee_id'])) throw new RuntimeException('员工登录已过期，请重新输入手机号。');
    // v13.5.4 avatar is an additive profile RPC so older employee-session RPCs remain dependency-safe.
    try {
        $profile=v13_rpc_json('v1354_employee_profile',['p_session_token'=>$sessionToken],'');
        if(is_array($profile) && !empty($profile['avatar_path'])) $row['avatar_path']=(string)$profile['avatar_path'];
    } catch(Throwable $e) { /* database patch may not be installed yet; login must still work */ }
    salonos_v13_apply_employee_context($row);
    return $row;
}

function salonos_v13_employee_logout(): void {
    $token=trim((string)($_SESSION['v13_employee_session_token']??''));
    if($token!=='') { try { v13_rpc('employee_session_logout',['p_session_token'=>$token],''); } catch(Throwable $e) {} }
}

function salonos_v13_employee_role_label(string $role): string {
    if(function_exists('v132_role_label')) return v132_role_label($role);
    return match($role){
        'manager'=>'经理',
        'receptionist'=>'前台 / 接待',
        'accountant'=>'会计',
        'stylist'=>'理发师',
        'assistant'=>'助理',
        default=>'员工',
    };
}

function salonos_v13_employee_gender_label(string $gender): string {
    return match($gender){'male'=>'男','female'=>'女',default=>'未注明'};
}


function salonos_v1354_employee_avatar_url(?string $path=null): string {
    $path=trim((string)($path ?? (user()['avatar_path']??'')));
    if($path==='') return '';
    if(preg_match('#^https?://#i',$path)) return $path;
    return function_exists('v1350_storage_public_url')?v1350_storage_public_url('salonos-media',$path):'';
}
function salonos_v1354_storage_put_employee_avatar(string $path,string $bytes,string $mime): void {
    $url=rtrim(SALONOS_SUPABASE_URL,'/').'/storage/v1/object/'.rawurlencode('salonos-media').'/'.implode('/',array_map('rawurlencode',explode('/',trim($path,'/'))));
    $key=SALONOS_SUPABASE_PUBLISHABLE_KEY;
    $headers=['apikey: '.$key,'Content-Type: '.$mime,'x-upsert: false'];
    $status=0;$raw=false;$err='';
    if(function_exists('curl_init')){$ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>25,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$bytes,CURLOPT_HTTPHEADER=>$headers,CURLOPT_IPRESOLVE=>CURL_IPRESOLVE_V4]);$raw=curl_exec($ch);if($raw===false)$err=(string)curl_error($ch);$status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);}else{$ctx=stream_context_create(['http'=>['method'=>'POST','header'=>implode("\r\n",$headers),'content'=>$bytes,'ignore_errors'=>true,'timeout'=>25]]);$raw=@file_get_contents($url,false,$ctx);if(!empty($http_response_header)&&preg_match('/\s(\d{3})\s/',(string)$http_response_header[0],$m))$status=(int)$m[1];if($raw===false)$err='Storage upload failed';}
    if($raw===false||$status<200||$status>=300) throw new RuntimeException('头像上传到 Supabase Storage 失败，请重新选择图片。');
}
function salonos_v1354_employee_avatar_upload(): string {
    if(v13_is_owner()) throw new RuntimeException('这个头像入口只用于员工账号。');
    $session=trim((string)($_SESSION['v13_employee_session_token']??''));if($session==='')throw new RuntimeException('员工登录已过期，请重新登录。');
    $file=$_FILES['avatar_file']??null;if(!is_array($file)||(int)($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new RuntimeException('请选择一张头像图片。');
    $size=(int)($file['size']??0);if($size<=0||$size>6*1024*1024)throw new RuntimeException('头像图片必须小于 6MB。');
    $tmp=(string)($file['tmp_name']??'');$info=@getimagesize($tmp);$mime=(string)($info['mime']??'');if(!in_array($mime,['image/jpeg','image/png','image/webp'],true))throw new RuntimeException('头像只支持 JPG / PNG / WebP。');
    $bytes='';$outMime=$mime;$ext=match($mime){'image/jpeg'=>'jpg','image/png'=>'png',default=>'webp'};
    if(function_exists('imagecreatefromstring')){$src=@imagecreatefromstring((string)file_get_contents($tmp));if($src){$w=imagesx($src);$h=imagesy($src);$side=min($w,$h);$sx=(int)(($w-$side)/2);$sy=(int)(($h-$side)/2);$dst=imagecreatetruecolor(512,512);imagealphablending($dst,false);imagesavealpha($dst,true);$tr=imagecolorallocatealpha($dst,0,0,0,127);imagefilledrectangle($dst,0,0,512,512,$tr);imagecopyresampled($dst,$src,0,0,$sx,$sy,512,512,$side,$side);if(function_exists('imagewebp')){ob_start();imagewebp($dst,null,80);$bytes=(string)ob_get_clean();$outMime='image/webp';$ext='webp';}elseif(function_exists('imagejpeg')){ob_start();imagejpeg($dst,null,84);$bytes=(string)ob_get_clean();$outMime='image/jpeg';$ext='jpg';}imagedestroy($dst);imagedestroy($src);}}
    if($bytes===''){$bytes=(string)file_get_contents($tmp);if(strlen($bytes)>2*1024*1024)throw new RuntimeException('服务器无法压缩这张头像，请先压到 2MB 以下。');}
    $ticket=v13_rpc_json('v1354_employee_avatar_upload_ticket',['p_session_token'=>$session],'');$org=(string)($ticket['organization_id']??'');$employee=(string)($ticket['employee_id']??'');$token=(string)($ticket['upload_token']??'');if($org===''||$employee===''||$token==='')throw new RuntimeException('无法取得头像上传授权。');
    $path=$org.'/employee-avatars/'.$employee.'/'.$token.'.'.$ext;salonos_v1354_storage_put_employee_avatar($path,$bytes,$outMime);v13_rpc_json('v1354_employee_set_avatar',['p_session_token'=>$session,'p_avatar_path'=>$path],'');
    $_SESSION['v13_business_user']['avatar_path']=$path;if(is_array($_SESSION['supabase_identity']['profile']??null))$_SESSION['supabase_identity']['profile']['avatar_path']=$path;return $path;
}

function salonos_v13_owner_token_required(): string {
    if(!v13_is_owner()) throw new RuntimeException('这个操作只允许老板或分行管理员使用。');
    $token=v13_business_token();
    if($token==='') throw new RuntimeException('老板 Supabase Session 已过期，请重新登录。');
    return $token;
}

function salonos_v13_store_employees(): array {
    $token=salonos_v13_owner_token_required();
    $storeId=(string)(current_store()['id']??'');
    if($storeId==='') return [];
    $rows=v13_rpc('v13_employee_directory',['p_store_id'=>$storeId],$token);
    return is_array($rows) ? (array_is_list($rows)?$rows:[]) : [];
}

function salonos_v13_save_employee_data(): array {
    $token=salonos_v13_owner_token_required();
    $storeId=(string)(current_store()['id']??'');
    if($storeId==='') throw new RuntimeException('找不到当前门店。');
    $employeeId=trim((string)($_POST['employee_id']??''));
    $ageRaw=trim((string)($_POST['age']??''));
    $joined=trim((string)($_POST['joined_at']??''));
    $requestedRole=preg_replace('/[^a-z0-9_]/','',strtolower(trim((string)($_POST['role_name']??'staff')))) ?: 'staff';
    $roleDefs=function_exists('v132_role_definitions')?v132_role_definitions():[
        'manager'=>[],'receptionist'=>[],'accountant'=>[],'stylist'=>[],'assistant'=>[],'staff'=>[]
    ];
    if(!isset($roleDefs[$requestedRole])) $requestedRole='staff';
    $rpcRole=in_array($requestedRole,['manager','receptionist','accountant','stylist','assistant','staff'],true)?$requestedRole:'staff';
    $args=[
        'p_store_id'=>$storeId,
        'p_employee_id'=>$employeeId!==''?$employeeId:null,
        'p_name'=>trim((string)($_POST['name']??'')),
        'p_phone'=>salonos_v13_phone_normalize((string)($_POST['phone']??'')),
        'p_position'=>trim((string)($_POST['position']??'')),
        'p_age'=>$ageRaw!==''?(int)$ageRaw:null,
        'p_gender'=>in_array((string)($_POST['gender']??''),['male','female','unspecified'],true)?(string)$_POST['gender']:'unspecified',
        'p_skill_tags'=>trim((string)($_POST['skill_tags']??'')),
        'p_base_salary'=>max(0,(float)($_POST['base_salary']??0)),
        'p_joined_at'=>$joined!==''?$joined:null,
        'p_app_role'=>$rpcRole,
    ];
    $result=v13_rpc('v13_save_employee',$args,$token);
    $row=v13_first_rpc_row($result);
    $id=(string)($row['employee_id']??'');
    if($id==='') throw new RuntimeException('Supabase 没有返回员工 ID。');
    if($requestedRole!==$rpcRole && function_exists('v13_owner_write')){
        v13_owner_write('employees',
            'id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode((string)(salonos_supabase_identity()['organization_id']??'')),
            'PATCH',
            ['app_role'=>$requestedRole,'updated_at'=>date(DATE_ATOM)],
            'return=minimal'
        );
    }
    if(function_exists('salonos_v1361039_save_employee_setting')) salonos_v1361039_save_employee_setting($id);
    return ['created'=>$employeeId==='','employee_id'=>$id];
}

function salonos_v13_toggle_employee_status_data(): string {
    $token=salonos_v13_owner_token_required();
    $employeeId=trim((string)($_POST['employee_id']??''));
    if($employeeId==='') throw new RuntimeException('缺少员工 ID。');
    $target=(string)($_POST['target_status']??'inactive')==='active'?'active':'inactive';
    $result=v13_rpc('v13_toggle_employee',['p_employee_id'=>$employeeId,'p_target_status'=>$target],$token);
    $row=v13_first_rpc_row($result);
    return (string)($row['message']??'员工状态已更新。');
}

function page_employees_supabase(): void {
    try {
        $employees=salonos_v13_store_employees();
    } catch(Throwable $e) {
        ?>
        <section class="card" style="padding:24px">
          <span class="eyebrow">EMPLOYEE MANAGEMENT · SUPABASE</span>
          <h2 style="margin:8px 0 10px">员工管理暂时无法读取</h2>
          <p style="color:var(--muted);line-height:1.7">页面已经成功进入员工模块，但 Supabase 员工 RPC 返回了错误。请先运行 v13.2.0 的修复 SQL，再刷新此页。</p>
          <div class="alert alert-error" style="margin-top:16px"><?=e($e->getMessage())?></div>
        </section>
        <?php
        return;
    }
    $attendanceMap=function_exists('salonos_v1361039_owner_attendance_map')?salonos_v1361039_owner_attendance_map():[];
    $total=count($employees); $active=0; $salary=0.0; $workingNow=0; $missingNow=0;
    foreach($attendanceMap as $att){$st=(string)($att['attendance_status']??'');if(in_array($st,['working','working_late'],true))$workingNow++;if($st==='not_arrived')$missingNow++;}
    foreach($employees as $employee){
        if(($employee['employment_status']??'')==='active'){ $active++; $salary+=(float)($employee['base_salary']??0); }
    }
    $inactive=$total-$active;
    $roleDefs=function_exists('v132_role_definitions')?v132_role_definitions():[
        'stylist'=>['label'=>'理发师'],'assistant'=>['label'=>'助理'],'receptionist'=>['label'=>'前台 / 接待'],
        'manager'=>['label'=>'经理'],'accountant'=>['label'=>'会计'],'staff'=>['label'=>'一般员工']
    ];
    $roles=[];foreach($roleDefs as $code=>$meta)$roles[]=['name'=>$code,'label'=>(string)($meta['label']??$code)];
    ?>
    <div class="page-head responsive-page-head"><div><span class="eyebrow">EMPLOYEE MANAGEMENT · SUPABASE</span><h1>员工管理</h1><p>由老板统一管理员工资料、底薪、手机号员工端登录与离职状态。停用后 Supabase Session 会立即失效，历史资料继续保留。</p></div><button class="btn btn-primary" type="button" data-employee-open><?=ui_icon('plus')?> 新增员工</button></div>
    <section class="stats"><div class="stat"><span>全部员工</span><strong><?=$total?></strong><small>包含离职资料</small></div><div class="stat"><span>今日上班中</span><strong><?=$workingNow?></strong><small>已扫描上班二维码</small></div><div class="stat"><span>今日未到</span><strong><?=$missingNow?></strong><small>超过到店时间仍未打卡</small></div><div class="stat"><span>停用／离职</span><strong><?=$inactive?></strong><small>历史数据保留</small></div></section>
    <section class="card employee-directory-card"><div class="card-head"><div><span class="card-kicker">EMPLOYEE DIRECTORY</span><h3>员工名单</h3><p>这张名单直接读取 Supabase employees + employee_compensation + employee_stores。</p></div><div class="employee-list-search"><span><?=ui_icon('search')?></span><input class="input" type="search" placeholder="搜索姓名、手机号、职位或技能" data-employee-search></div></div>
      <div class="employee-management-grid" data-employee-grid>
      <?php foreach($employees as $employee): $isActive=($employee['employment_status']??'')==='active'; $att=$attendanceMap[(string)($employee['id']??'')]??[]; $attMeta=function_exists('salonos_v1361039_status_meta')?salonos_v1361039_status_meta((string)($att['attendance_status']??'not_clocked_in')):['label'=>'待上班','class'=>'is-waiting']; ?>
        <article class="employee-management-card <?=$isActive?'is-active':'is-inactive'?>" data-employee-card data-employee-search-text="<?=e(mb_strtolower((string)($employee['name']??'').' '.(string)($employee['phone']??'').' '.(string)($employee['position']??'').' '.(string)($employee['skill_tags']??'')))?>">
          <header><div class="employee-profile-mini"><div class="leader-avatar v1354-avatar"><?php $employeeAvatar=salonos_v1354_employee_avatar_url((string)($employee['avatar_path']??'')); if($employeeAvatar!==''):?><img src="<?=e($employeeAvatar)?>" alt="<?=e((string)($employee['name']??'员工'))?>"><?php else:?><?=e(mb_substr((string)($employee['name']??'E'),0,1))?><?php endif;?></div><div><strong><?=e((string)($employee['name']??''))?></strong><small><?=e((string)($employee['employee_code']??'').' · '.(string)($employee['position']??''))?></small></div></div><div><span class="badge <?=$isActive?'badge-green':'badge-gray'?>"><?=$isActive?'在职／账号启用':'离职／账号停用'?></span><?php if($isActive):?><span class="attendance-card-status <?=e($attMeta['class'])?>"><?=e($attMeta['label'])?></span><?php endif;?></div></header>
          <div class="employee-info-grid"><div><span>手机号登录</span><strong><?=e((string)($employee['phone']??'—'))?></strong></div><div><span>年龄／性别</span><strong><?=!empty($employee['age'])?intval($employee['age']).' 岁':'—'?> · <?=e(salonos_v13_employee_gender_label((string)($employee['gender']??'unspecified')))?></strong></div><div><span>员工端权限</span><strong><?=e(salonos_v13_employee_role_label((string)($employee['app_role']??'staff')))?></strong></div><div><span>今日打卡</span><strong><?=e($attMeta['label'])?></strong><small><?=e(substr((string)($att['scheduled_start_time']??'09:00'),0,5))?> 上班 · 宽限 <?=intval($att['late_grace_minutes']??10)?> 分</small></div></div>
          <div class="employee-skill-tags"><?php foreach(array_filter(array_map('trim',explode(',',(string)($employee['skill_tags']??'')))) as $skill): ?><span><?=e($skill)?></span><?php endforeach; ?><?php if(empty($employee['skill_tags'])): ?><span>未填写技能</span><?php endif; ?></div>
          <div class="employee-account-meta"><span>历史订单 <?=intval($employee['order_count']??0)?> 笔</span><span>最后登录 <?=!empty($employee['last_login_at'])?app_date((string)$employee['last_login_at'],true):'从未登录'?></span></div>
          <footer class="employee-card-actions"><button class="btn btn-light btn-small" type="button" data-employee-open data-employee-id="<?=e((string)$employee['id'])?>" data-employee-name="<?=e((string)$employee['name'])?>" data-employee-phone="<?=e((string)($employee['phone']??''))?>" data-employee-position="<?=e((string)($employee['position']??''))?>" data-employee-age="<?=e((string)($employee['age']??''))?>" data-employee-gender="<?=e((string)($employee['gender']??'unspecified'))?>" data-employee-skills="<?=e((string)($employee['skill_tags']??''))?>" data-employee-salary="<?=e((string)($employee['base_salary']??0))?>" data-employee-joined="<?=e((string)($employee['joined_at']??''))?>" data-employee-role="<?=e((string)($employee['app_role']??'staff'))?>" data-employee-attendance-enabled="<?=!array_key_exists('attendance_enabled',$att)||!empty($att['attendance_enabled'])?'1':'0'?>" data-employee-attendance-start="<?=e(substr((string)($att['scheduled_start_time']??'09:00'),0,5))?>" data-employee-attendance-end="<?=e(substr((string)($att['scheduled_end_time']??'18:00'),0,5))?>" data-employee-attendance-grace="<?=intval($att['late_grace_minutes']??10)?>">修改</button><?php if($isActive): ?><button class="btn btn-danger-soft btn-small" type="button" data-employee-status-open data-employee-id="<?=e((string)$employee['id'])?>" data-employee-name="<?=e((string)$employee['name'])?>" data-employee-target="inactive">离职／停用</button><?php else: ?><button class="btn btn-primary btn-small" type="button" data-employee-status-open data-employee-id="<?=e((string)$employee['id'])?>" data-employee-name="<?=e((string)$employee['name'])?>" data-employee-target="active">重新启用</button><?php endif; ?></footer>
        </article>
      <?php endforeach; ?>
      </div><div class="empty compact-empty" data-employee-empty <?=$employees?'hidden':''?>><?=$employees?'找不到符合条件的员工。':'还没有员工。点击右上角“新增员工”即可建立第一位员工。'?></div>
    </section>

    <div class="commission-modal employee-editor-modal" data-employee-modal hidden aria-hidden="true"><button class="commission-modal-backdrop" type="button" data-employee-modal-close></button><section class="commission-modal-dialog employee-editor-dialog"><form method="post" data-employee-form><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_employee"><input type="hidden" name="employee_id" data-employee-id><header class="commission-modal-head"><div><span class="eyebrow" data-employee-kicker>NEW EMPLOYEE</span><h2 data-employee-title>新增员工</h2><p>保存后员工只需输入这支手机号即可进入员工端，不需要密码，也不需要 Creator 设备 Code。</p></div><button class="commission-modal-close" type="button" data-employee-modal-close>×</button></header><div class="employee-editor-body"><div class="form-grid employee-form-grid"><div class="field"><label>员工姓名 *</label><input class="input" name="name" required data-employee-name></div><div class="field"><label>手机号码 *</label><input class="input" name="phone" inputmode="tel" required data-employee-phone><small class="field-help">这个号码就是员工端登录账号。</small></div><div class="field"><label>职位 *</label><input class="input" name="position" placeholder="例如 高级理发师／前台／助理" required data-employee-position></div><div class="field"><label>员工端权限</label><select class="select" name="role_name" data-employee-role><?php foreach($roles as $role): ?><option value="<?=e($role['name'])?>"><?=e($role['label'])?></option><?php endforeach; ?></select></div><div class="field"><label>年龄</label><input class="input" type="number" min="15" max="100" name="age" data-employee-age></div><div class="field"><label>性别</label><select class="select" name="gender" data-employee-gender><option value="unspecified">未注明</option><option value="male">男</option><option value="female">女</option></select></div><div class="field"><label>每月底薪 RM</label><input class="input" type="number" min="0" step="0.01" name="base_salary" value="0.00" data-employee-salary></div><div class="field"><label>入职日期</label><input class="input" type="date" name="joined_at" value="<?=date('Y-m-d')?>" data-employee-joined></div><div class="attendance-setting-box"><h4>每日打卡规则</h4><p class="field-help">没有扫描上班二维码的员工不会进入 Walk-in 可派单名单；超过上班时间 + 宽限分钟会显示「未到」。</p><input type="hidden" name="attendance_enabled" value="0"><label class="attendance-setting-toggle"><input type="checkbox" name="attendance_enabled" value="1" checked data-employee-attendance-enabled> 启用员工打卡</label><div class="attendance-setting-grid"><div class="field"><label>上班时间</label><input class="input" type="time" name="attendance_start_time" value="09:00" data-employee-attendance-start></div><div class="field"><label>下班时间</label><input class="input" type="time" name="attendance_end_time" value="18:00" data-employee-attendance-end></div><div class="field"><label>迟到宽限（分钟）</label><input class="input" type="number" min="0" max="240" name="late_grace_minutes" value="10" data-employee-attendance-grace></div></div></div><div class="field span-2"><label>技能</label><input class="input" name="skill_tags" placeholder="例如：剪发, 染发, 烫发, 会员接待" data-employee-skills><small class="field-help">使用逗号分开多个技能。</small></div></div><div class="employee-security-note"><strong>员工端登录控制</strong><p>员工只需输入老板登记的手机号。老板一旦停用员工，所有 Supabase 员工 Session 会立即失效。</p></div></div><footer class="commission-modal-actions"><div><strong data-employee-footer-title>建立员工与登录账号</strong><span>手机号直登模式要求号码不能与其他员工重复。</span></div><div class="commission-modal-action-buttons"><button class="btn btn-light" type="button" data-employee-modal-close>取消</button><button class="btn btn-primary" type="submit" data-employee-submit>建立员工</button></div></footer></form></section></div>

    <div class="commission-modal employee-status-modal" data-employee-status-modal hidden aria-hidden="true"><button class="commission-modal-backdrop" type="button" data-employee-status-close></button><section class="commission-modal-dialog employee-confirm-dialog"><form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="toggle_employee_status"><input type="hidden" name="employee_id" data-employee-status-id><input type="hidden" name="target_status" data-employee-status-target><header class="commission-modal-head"><div><span class="eyebrow">ACCOUNT STATUS</span><h2 data-employee-status-title>停用员工账号</h2><p data-employee-status-copy>员工将无法继续登录，但所有数据都会保留。</p></div><button class="commission-modal-close" type="button" data-employee-status-close>×</button></header><div class="employee-confirm-body"><div class="employee-confirm-icon">!</div><strong data-employee-status-name>员工姓名</strong><p data-employee-status-detail>订单、顾客、业绩、抽成和培训记录不会被删除。</p></div><footer class="commission-modal-actions"><div><strong>历史资料永久保留</strong><span>之后可随时重新启用员工与账号。</span></div><div class="commission-modal-action-buttons"><button class="btn btn-light" type="button" data-employee-status-close>取消</button><button class="btn btn-danger-soft" type="submit" data-employee-status-submit>确认停用</button></div></footer></form></section></div>
    <?php
}

// SalonOS v13.6.10.55 · owner profile avatar
function salonos_v1361055_owner_avatar_url(): string {
    if(!v13_is_owner()) return '';
    $path=trim((string)(user()['avatar_path'] ?? (salonos_supabase_identity()['profile']['avatar_path'] ?? '')));
    if($path==='') return '';
    if(preg_match('#^https?://#i',$path)) return $path;
    return function_exists('v1350_storage_public_url')?v1350_storage_public_url('salonos-media',$path):'';
}

function salonos_v1361055_storage_put_owner_avatar(string $path,string $bytes,string $mime,string $accessToken): void {
    $url=rtrim(SALONOS_SUPABASE_URL,'/').'/storage/v1/object/'.rawurlencode('salonos-media').'/'.implode('/',array_map('rawurlencode',explode('/',trim($path,'/'))));
    $headers=['apikey: '.SALONOS_SUPABASE_PUBLISHABLE_KEY,'Authorization: Bearer '.$accessToken,'Content-Type: '.$mime,'x-upsert: false'];
    $status=0;$raw=false;
    if(function_exists('curl_init')){
        $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>25,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$bytes,CURLOPT_HTTPHEADER=>$headers,CURLOPT_IPRESOLVE=>CURL_IPRESOLVE_V4]);$raw=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);
    }else{
        $ctx=stream_context_create(['http'=>['method'=>'POST','header'=>implode("\r\n",$headers),'content'=>$bytes,'ignore_errors'=>true,'timeout'=>25]]);$raw=@file_get_contents($url,false,$ctx);if(!empty($http_response_header)&&preg_match('/\s(\d{3})\s/',(string)$http_response_header[0],$m))$status=(int)$m[1];
    }
    if($raw===false||$status<200||$status>=300) throw new RuntimeException('老板头像上传到 Supabase Storage 失败，请重新选择图片。');
}

function salonos_v1361055_owner_avatar_upload(): string {
    if(!v13_is_owner()) throw new RuntimeException('只有老板账号可以使用这个头像入口。');
    $token=salonos_v13_owner_token_required();
    $identity=salonos_supabase_identity()??[];$org=trim((string)($identity['organization_id']??''));$uid=trim((string)($identity['user_id']??''));
    if($org===''||$uid==='') throw new RuntimeException('老板身份资料不完整，请重新登录。');
    $file=$_FILES['avatar_file']??null;if(!is_array($file)||(int)($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new RuntimeException('请选择一张头像图片。');
    $size=(int)($file['size']??0);if($size<=0||$size>6*1024*1024)throw new RuntimeException('头像图片必须小于 6MB。');
    $tmp=(string)($file['tmp_name']??'');$info=@getimagesize($tmp);$mime=(string)($info['mime']??'');if(!in_array($mime,['image/jpeg','image/png','image/webp'],true))throw new RuntimeException('头像只支持 JPG / PNG / WebP。');
    $bytes='';$outMime=$mime;$ext=match($mime){'image/jpeg'=>'jpg','image/png'=>'png',default=>'webp'};
    if(function_exists('imagecreatefromstring')){$src=@imagecreatefromstring((string)file_get_contents($tmp));if($src){$w=imagesx($src);$h=imagesy($src);$side=min($w,$h);$sx=(int)(($w-$side)/2);$sy=(int)(($h-$side)/2);$dst=imagecreatetruecolor(512,512);imagealphablending($dst,false);imagesavealpha($dst,true);$tr=imagecolorallocatealpha($dst,0,0,0,127);imagefilledrectangle($dst,0,0,512,512,$tr);imagecopyresampled($dst,$src,0,0,$sx,$sy,512,512,$side,$side);if(function_exists('imagewebp')){ob_start();imagewebp($dst,null,80);$bytes=(string)ob_get_clean();$outMime='image/webp';$ext='webp';}elseif(function_exists('imagejpeg')){ob_start();imagejpeg($dst,null,84);$bytes=(string)ob_get_clean();$outMime='image/jpeg';$ext='jpg';}imagedestroy($dst);imagedestroy($src);}}
    if($bytes===''){$bytes=(string)file_get_contents($tmp);if(strlen($bytes)>2*1024*1024)throw new RuntimeException('服务器无法压缩这张头像，请先压到 2MB 以下。');}
    $path=$org.'/owner-avatars/'.$uid.'/'.bin2hex(random_bytes(12)).'.'.$ext;
    salonos_v1361055_storage_put_owner_avatar($path,$bytes,$outMime,$token);
    v13_rpc_json('v1361055_owner_set_avatar',['p_avatar_path'=>$path],$token);
    $_SESSION['v13_business_user']['avatar_path']=$path;if(is_array($_SESSION['supabase_identity']['profile']??null))$_SESSION['supabase_identity']['profile']['avatar_path']=$path;
    return $path;
}
