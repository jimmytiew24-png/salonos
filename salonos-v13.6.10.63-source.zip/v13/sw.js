const RELEASE = '13.6.10.63';
const CACHE_NAME = 'salonos-app-v' + RELEASE + '-exact-assets';
const OFFLINE_URL = new URL('./offline.html', self.location.href).pathname;
const VERSIONED_ASSETS = new Set([
  './assets/app.css',
  './assets/pwa.css',
  './assets/luxe.css',
  './assets/v13-supabase-compat.css',
  './assets/v13-attendance.css',
  './assets/app.js',
  './assets/v13-product-member.js',
  './assets/v13-attendance.js',
  './assets/pwa-install.js',
  './assets/i18n.js',
  './assets/i18n-en.json'
].map(path => new URL(path, self.location.href).pathname));
const STATIC_FILES = [
  './offline.html',
  './assets/app.css',
  './assets/pwa.css',
  './assets/luxe.css',
  './assets/v13-supabase-compat.css',
  './assets/brand-wave.svg',
  './assets/app.js',
  './assets/v13-product-member.js',
  './assets/pwa-install.js',
  './assets/i18n.js',
  './assets/i18n-en.json',
  './assets/supabase-config.js',
  './assets/supabase-client.js',
  './assets/supabase-bridge.js',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/icons/icon-maskable-512.png',
  './assets/icons/apple-touch-icon.png',
  './assets/icons/favicon.ico'
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key.startsWith('salonos-app-') && key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

function isVersionedAssetResponse(response, path) {
  if (!response.ok || response.redirected) return false;
  const mime = (response.headers.get('Content-Type') || '').split(';')[0].trim().toLowerCase();
  if (path.endsWith('.css')) return mime === 'text/css';
  if (path.endsWith('.json')) return mime === 'application/json';
  return ['application/javascript', 'text/javascript', 'application/x-javascript'].includes(mime);
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // /creator/ has its own more specific PWA and service worker.
  if (url.pathname.includes('/creator/')) return;

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.match(OFFLINE_URL)));
    return;
  }

  const isStatic = /\.(?:css|js|json|png|jpg|jpeg|webp|svg|ico|webmanifest)$/i.test(url.pathname);
  if (!isStatic) return;

  // Only this release's explicitly versioned public files can skip the network.
  // The full URL, including its query, is the key. Never mix different releases.
  if (VERSIONED_ASSETS.has(url.pathname) && url.search === '?v=' + RELEASE) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME).catch(() => null);
      const cached = await cache?.match(request).catch(() => undefined);
      if (cached) return cached;
      const response = await fetch(new Request(request, { cache: 'no-store' }));
      if (cache && isVersionedAssetResponse(response, url.pathname)) {
        event.waitUntil(cache.put(request, response.clone()).catch(() => {}));
      }
      return response;
    })());
    return;
  }

  event.respondWith(
    fetch(new Request(request, { cache: 'no-store' })).then((response) => {
      // Only unversioned URLs can enter the legacy network-first cache. In
      // particular, don't prime a future release's exact-version entry early.
      if (response && response.ok && !url.searchParams.has('v')) {
        const responseForCache = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(request, responseForCache)).catch(() => {});
      }
      return response;
    }).catch(() => url.searchParams.has('v') ? Response.error() : caches.match(request))
  );
});

// SalonOS v11.3.5 schema auto-repair release

// SalonOS v13.0.1 Creator live control + public owner registration
