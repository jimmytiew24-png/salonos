<?php
declare(strict_types=1);

session_name('salonos_v13_business');
if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params(['lifetime'=>0,'path'=>'/v13/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
require_once __DIR__ . '/v13_supabase.php';

function st_e(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
function st_token(): string {
    $token=trim((string)($_SESSION['supabase_access_token']??''));
    $refresh=trim((string)($_SESSION['supabase_refresh_token']??''));
    if($token!=='' && (v13_jwt_exp($token)===0 || v13_jwt_exp($token)>time()+60)) return $token;
    if($refresh==='') return '';
    try{
        $auth=salonos_supabase_request('auth/v1/token?grant_type=refresh_token','', 'POST',['refresh_token'=>$refresh]);
        $token=v13_access_token_from_auth($auth);
        if($token!=='') $_SESSION['supabase_access_token']=$token;
        $r=v13_refresh_token_from_auth($auth); if($r!=='') $_SESSION['supabase_refresh_token']=$r;
        return $token;
    }catch(Throwable $e){ return ''; }
}

$tests=[];
$add=function(string $group,string $name,bool $ok,string $detail='')use(&$tests){$tests[]=['group'=>$group,'name'=>$name,'ok'=>$ok,'detail'=>$detail];};
$token=st_token();
$identity=is_array($_SESSION['supabase_identity']??null)?$_SESSION['supabase_identity']:null;

$add('PHP / Hosting','PHP 8+',version_compare(PHP_VERSION,'8.0.0','>='),'PHP '.PHP_VERSION);
$add('PHP / Hosting','JSON extension',function_exists('json_encode'),'json_encode');
$add('PHP / Hosting','cURL / HTTPS client',function_exists('curl_init') || (bool)ini_get('allow_url_fopen'),function_exists('curl_init')?'cURL ready':'allow_url_fopen='.(string)ini_get('allow_url_fopen'));
$add('PHP / Hosting','v13 Supabase-only boot',defined('SALONOS_SUPABASE_URL') && str_contains(SALONOS_SUPABASE_URL,'supabase.co'),defined('SALONOS_SUPABASE_URL')?SALONOS_SUPABASE_URL:'missing');

$activeFiles=['index.php','v13_supabase.php','supabase_auth.php','supabase_customers.php','supabase_employees.php','supabase_all_modules.php','v12_feature_bridge.php','register.php','register-branch.php','creator/index.php'];
$legacyHits=[];
foreach($activeFiles as $file){
    $path=__DIR__.'/'.$file; if(!is_file($path)){ $legacyHits[]=$file.' missing'; continue; }
    $txt=(string)file_get_contents($path);
    foreach(['require __DIR__ . \'/config.php\'','require_once __DIR__ . \'/config.php\'','mysqli_connect(','new PDO(','bootstrap_db()','active_business_database_name()'] as $needle){
        if(str_contains($txt,$needle)) $legacyHits[]=$file.' → '.$needle;
    }
}
$add('PHP / Hosting','Active runtime does not load InfinityFree MySQL',!$legacyHits,$legacyHits?implode(' | ',$legacyHits):'hosting only; no MySQL runtime dependency');

$uiBaseline=[
  'assets/app.css'=>'348b62b1c485f71ecd767b9cd77202bd85b0dd80679ef105b9ae4e3db1badc2f',
  'assets/luxe.css'=>'16517f779d6b85b50404d4020c88d484c5b03c30413a0fb34b4ef1f428423617',
  'assets/pwa.css'=>'eaf90eb76b4de1ddf8c64c8c6b510b11048835c70fc409ddfcd1516a00e0ae14',
  'assets/pwa-install.js'=>'ab6d8f5ecab72a11277a40b8f61e5b04887086b57704dc415da0404eba8cfa0e',
];
foreach($uiBaseline as $file=>$expected){
    $path=__DIR__.'/'.$file; $actual=is_file($path)?hash_file('sha256',$path):'';
    $add('UI v12.4.4 Lock',$file,$actual!=='' && hash_equals($expected,$actual),$actual===$expected?'exact v12.4.4 baseline':'UI baseline changed');
}
$compat=__DIR__.'/assets/v13-supabase-compat.css';
$add('UI v12.4.4 Lock','Supabase compatibility stylesheet',is_file($compat),'v13-only styles isolated from locked UI baseline');
$wizardJs=@file_get_contents(__DIR__.'/assets/app.js');
$add('Order Wizard','4-step JS behavior',is_string($wizardJs)&&str_contains($wizardJs,'v13.4.0: appointment and Walk-in both stay on the same 4-step'), 'v12.4.4 visual baseline + v13.4 multi-worker 4-step Supabase order behavior');
$modulePhp=@file_get_contents(__DIR__.'/supabase_all_modules.php');
$add('Order Wizard','Project signature modal open-state hotfix',
    is_string($modulePhp)&&str_contains($modulePhp,"modal.classList.add('is-open')")&&str_contains($modulePhp,'project-signature-data'),
    'project signature uses shared modal .is-open state + validated signature canvas');
$add('Service Board','v12.4.4 Team Appointment Board markup restored',
    is_string($modulePhp)&&str_contains($modulePhp,'service-board-axis')&&str_contains($modulePhp,'service-board-all-orders')&&str_contains($modulePhp,'v1344_owner_service_board'),
    'employee rows + 09:00–00:00 timeline + ALL ORDERS + shared modal');


$indexPhp=@file_get_contents(__DIR__.'/index.php');
$customerPhp=@file_get_contents(__DIR__.'/supabase_customers.php');
$rolePhp=@file_get_contents(__DIR__.'/v12_feature_bridge.php');
$add('v13.5.4 UX','Customer AJAX returns JSON',
    is_string($indexPhp)&&str_contains($indexPhp,'v1352_json_response')&&str_contains($indexPhp,"if(v1352_is_ajax_request())"),
    '顾客修改 / 会员升级不再把 HTML redirect 当 JSON');
$add('v13.5.4 UX','Order customer/member fuzzy search contract',
    is_string($customerPhp)&&str_contains($customerPhp,'salonos_supabase_customer_search_rows')&&str_contains($customerPhp,'$dataset[\'customers\']'),
    '当前分行顾客目录与新建订单搜索使用同一份去重 customers dataset；可按姓名 / 电话 / 会员编号搜索');
$add('v13.5.4 UX','Custom permission roles UI',
    is_string($rolePhp)&&str_contains($rolePhp,'add_role_v1352')&&str_contains($rolePhp,'delete_role_v1352'),
    '老板可新增 / 删除自定义员工权限职位');

$productJs=@file_get_contents(__DIR__.'/assets/v13-product-member.js');
$add('v13.5.4 UX','Category-first product fuzzy search UI',
    is_string($productJs)&&str_contains($productJs,'action=search_products')&&str_contains($productJs,'data-product-category')&&str_contains($productJs,'data-product-results'),
    '会员购买与服务现场追加产品共用分类 → 模糊搜索 → 选择产品流程');
$add('v13.5.4 UX','Retail / bundle modal-first editor',
    is_string($rolePhp)&&str_contains($rolePhp,'data-v1350-modal="product-item"')&&str_contains($rolePhp,'data-v1350-modal="bundle-item"')&&str_contains($rolePhp,'data-v1350-modal="inventory-item"'),
    '库存 / 销售产品 / 产品配套均由按钮打开小浮窗新增或修改');
$add('v13.5.4 UX','Service Board displays added product lines',
    is_string($modulePhp)&&str_contains($modulePhp,'PRODUCT ITEMS')&&str_contains($modulePhp,'product_name_snapshot')&&str_contains($modulePhp,'v1353-product-purchase'),
    '追加产品后名称 / SKU / 数量 / 金额显示在同一订单浮窗');

if($token==='' || !$identity){
    $add('Supabase Auth','Owner / branch manager session',false,'请先回 SalonOS 用老板账号登录，再重新打开自检。');
}else{
    try{
        $ctx=salonos_supabase_owner_context($token);
        $add('Supabase Auth','Auth + Organization context',!empty($ctx['organization_id']),(string)($ctx['email']??'').' · '.(string)($ctx['organization_name']??''));
        $identity=$ctx;
        $_SESSION['supabase_identity']=$ctx;
    }catch(Throwable $e){$add('Supabase Auth','Auth + Organization context',false,$e->getMessage());}

    try{
        $health=v13_rpc('v13_healthcheck',[],$token);
        $h=is_array($health)?$health:[];
        $add('Supabase RPC','Supabase healthcheck',is_array($h) && !empty($h['version']),'version='.(string)($h['version']??'unknown'));
    }catch(Throwable $e){$add('Supabase RPC','v13.2.0 healthcheck',false,$e->getMessage());}

    try{
        $contract=v13_rpc('v1350_runtime_contract_status',[],$token);
        if(is_array($contract) && array_is_list($contract)) $contract=is_array($contract[0]??null)?$contract[0]:[];
        $missing=is_array($contract['missing_contracts']??null)?$contract['missing_contracts']:[];
        $detail='version='.(string)($contract['version']??'?').' · Storage='.(string)($contract['storage_bucket']??'?');
        if($missing)$detail.=' · missing='.implode(', ',$missing);
        $add('Runtime Contract','v13.5.0 base product UX contract',!empty($contract['ok']),$detail);
    }catch(Throwable $e){
        $add('Runtime Contract','v13.5.0 base product UX contract',false,'请运行 RUN_ONCE_V13_5_5_CUMULATIVE_RUNTIME.sql，然后重新检查。');
    }

    try{
        // A deliberately invalid employee session should fail as an employee-session error.
        // If the RPC itself is missing, PostgREST returns PGRST202 / function-not-found instead.
        v13_rpc('v1352_employee_role_permissions',['p_session_token'=>'__salonos_contract_probe__'],$token);
        $add('Runtime Contract','v13.5.2 employee role-permission RPC',true,'RPC reachable');
    }catch(Throwable $e){
        $m=strtolower($e->getMessage());
        $missingRpc=str_contains($m,'pgrst202')||str_contains($m,'could not find the function');
        $add('Runtime Contract','v13.5.2 employee role-permission RPC',!$missingRpc,$missingRpc?'请运行 RUN_ONCE_V13_5_2_PERMISSION_ROLE_FIX.sql。':'RPC reachable · session validation correctly rejected probe');
    }

    try{
        $contract1353=v13_rpc('v1353_runtime_contract_status',[],$token);
        if(is_array($contract1353) && array_is_list($contract1353)) $contract1353=is_array($contract1353[0]??null)?$contract1353[0]:[];
        $detail='version='.(string)($contract1353['version']??'?')
            .' · categories='.(empty($contract1353['product_categories_ok'])?'FAIL':'OK')
            .' · memberRetail='.(empty($contract1353['member_product_sales_ok'])?'FAIL':'OK')
            .' · productSearchRPC='.(empty($contract1353['employee_product_search_rpc_ok'])?'FAIL':'OK');
        $add('Runtime Contract','v13.5.4 Product / Member / Search contract',!empty($contract1353['ok']),$detail);
    }catch(Throwable $e){
        $add('Runtime Contract','v13.5.4 Product / Member / Search contract',false,'请运行 RUN_ONCE_V13_5_3_PRODUCT_MEMBER_SEARCH.sql，或使用 v13.5.4 累计 SQL。');
    }

    try{
        $contract1354=v13_rpc('v1354_runtime_contract_status',[],$token);
        if(is_array($contract1354) && array_is_list($contract1354)) $contract1354=is_array($contract1354[0]??null)?$contract1354[0]:[];
        $add('Runtime Contract','v13.5.4 Employee Workspace contract',!empty($contract1354['ok']),'version='.(string)($contract1354['version']??'?').' · avatar='.(empty($contract1354['employee_avatar_column_ok'])?'FAIL':'OK').' · customers='.(empty($contract1354['employee_customer_rpc_ok'])?'FAIL':'OK').' · performance='.(empty($contract1354['employee_performance_rpc_ok'])?'FAIL':'OK'));
    }catch(Throwable $e){$add('Runtime Contract','v13.5.4 Employee Workspace contract',false,'请运行 RUN_ONCE_V13_5_4_EMPLOYEE_WORKSPACE.sql，或使用 v13.5.5 累计 SQL。');}

    try{
        $contract1355=v13_rpc('v1355_runtime_contract_status',[],$token);
        if(is_array($contract1355) && array_is_list($contract1355)) $contract1355=is_array($contract1355[0]??null)?$contract1355[0]:[];
        $add('Runtime Contract','v13.5.5 Performance + Employee Product/Inventory contract',!empty($contract1355['ok']),
          'version='.(string)($contract1355['version']??'?').' · performanceLink='.(empty($contract1355['performance_payment_link_ok'])?'FAIL':'OK').' · employeeProducts='.(empty($contract1355['employee_product_inventory_rpc_ok'])?'FAIL':'OK'));
    }catch(Throwable $e){$add('Runtime Contract','v13.5.5 Performance + Employee Product/Inventory contract',false,'请运行 RUN_ONCE_V13_5_5_PERFORMANCE_EMPLOYEE_PRODUCTS_HOTFIX.sql，或使用 v13.5.5 累计 SQL。');}

    $org=(string)($identity['organization_id']??'');
    $stores=is_array($identity['stores']??null)?$identity['stores']:[];
    $store=(string)($_SESSION['v13_current_store_uuid']??($identity['primary_store_id']??($stores[0]['id']??'')));
    $add('Tenant isolation','Organization UUID resolved',$org!=='',$org?:'missing');
    $add('Tenant isolation','Store UUID resolved',$store!=='',$store?:'missing');

    if($store!==''){
        try{
            $d=v13_rpc('v13_owner_dashboard',['p_store_id'=>$store],$token);
            $add('Supabase RPC','Dashboard RPC',is_array($d),'customers='.(string)($d['customers']??'?').' · employees='.(string)($d['active_employees']??'?').' · visits='.(string)($d['today_visits']??'?'));
        }catch(Throwable $e){$add('Supabase RPC','Dashboard RPC',false,$e->getMessage());}
        try{
            $stock=v13_rpc('v132_inventory_snapshot',['p_store_id'=>$store],$token);
            $add('Supabase RPC','v12.4.4 UI fusion inventory snapshot',is_array($stock),'products='.(is_array($stock)?count($stock):0).' · no inventory_balances.quantity dependency');
        }catch(Throwable $e){$add('Supabase RPC','v12.4.4 UI fusion inventory snapshot',false,$e->getMessage());}
        try{
            $emps=v13_rpc('v13_employee_directory',['p_store_id'=>$store],$token);
            $add('Supabase RPC','Employee directory (ambiguity regression test)',is_array($emps),'rows='.(is_array($emps)?count($emps):0));
        }catch(Throwable $e){$add('Supabase RPC','Employee directory (ambiguity regression test)',false,$e->getMessage());}
        try{
            $board=v13_rpc('v1344_owner_service_board',['p_store_id'=>$store,'p_board_date'=>date('Y-m-d')],$token);
            $add('Service Board','v13.5.0 Team Appointment Board RPC',is_array($board) && isset($board['employees'],$board['visits']),'employees='.(is_array($board['employees']??null)?count($board['employees']):0).' · visits='.(is_array($board['visits']??null)?count($board['visits']):0));
        }catch(Throwable $e){$detail=$e->getMessage(); if(str_contains(strtolower($detail),'pgrst202')||str_contains(strtolower($detail),'could not find the function')) $detail='网站文件已经更新，但 Supabase Runtime Contract 还没安装。请运行 RUN_ONCE_V13_5_5_CUMULATIVE_RUNTIME.sql。Service Board 页面本身会自动进入兼容模式，不会整页中断。'; $add('Service Board','v13.5.0 Team Appointment Board RPC',false,$detail);}
    }

    $tables=[
      'organizations'=>'Organization','stores'=>'Stores / branches','customers'=>'Customers','membership_levels'=>'Membership levels','memberships'=>'Memberships',
      'member_wallet_ledger'=>'Member wallet','member_loyalty_ledger'=>'Member loyalty','employees'=>'Employees','employee_compensation'=>'Employee compensation','employee_stores'=>'Employee-store map',
      'employee_login_sessions'=>'Phone-login sessions','services'=>'Services','visits'=>'Visits / orders','visit_recipients'=>'Visit recipients','visit_service_items'=>'Visit services',
      'visit_service_workers'=>'Visit workers','visit_service_signoffs'=>'Service signoffs','v13_visit_confirmations'=>'Order customer signatures','appointment_employee_preferences'=>'Appointment stylist preferences','visit_product_items'=>'Checkout product add-ons','payments'=>'Payments','payment_items'=>'Payment lines','products'=>'Products','inventory_stock_movements'=>'Inventory ledger',
      'service_performance_ledger'=>'Performance ledger','service_commission_settings'=>'Commission settings','service_commission_tiers'=>'Commission tiers','v13_kpi_rules'=>'KPI rules',
      'v13_training_courses'=>'Training courses','v13_training_progress'=>'Training progress','service_categories'=>'Service categories','v13_product_categories'=>'Product category folders','v13_member_product_sales'=>'Member retail sales','v13_member_product_sale_items'=>'Member retail sale items','v13_monthly_commission_overrides'=>'Monthly commission overrides','v13_product_bundles'=>'Product bundles','v13_organization_settings'=>'Settings','saas_subscriptions'=>'Subscriptions',
      'saas_activation_codes'=>'ACT / BRN / DVC codes','saas_trusted_devices'=>'Trusted devices'
    ];
    try{
        $rows=salonos_supabase_rest_rows('employee_stores','select=updated_at&organization_id=eq.'.rawurlencode($org).'&limit=1',$token);
        $add('Schema compatibility','employee_stores.updated_at',true,'column reachable');
    }catch(Throwable $e){$add('Schema compatibility','employee_stores.updated_at',false,$e->getMessage());}

    try{
        $rows=salonos_supabase_rest_rows('employees','select=avatar_path&organization_id=eq.'.rawurlencode($org).'&limit=1',$token);
        $add('v13.5.4 Employee Workspace','Employee avatar Storage path column',true,'employees.avatar_path reachable');
    }catch(Throwable $e){$add('v13.5.4 Employee Workspace','Employee avatar Storage path column',false,'请运行 RUN_ONCE_V13_5_4_EMPLOYEE_WORKSPACE.sql。');}
    foreach([
        'Employee customer/member permission RPC'=>['v1354_employee_customer_directory',['p_session_token'=>'__salonos_contract_probe__','p_query'=>'','p_customer_id'=>null]],
        'Employee avatar upload ticket RPC'=>['v1354_employee_avatar_upload_ticket',['p_session_token'=>'__salonos_contract_probe__']],
    ] as $label=>$probe){
        try{v13_rpc($probe[0],$probe[1],$token);$add('v13.5.4 Employee Workspace',$label,true,'RPC reachable');}
        catch(Throwable $e){$m=strtolower($e->getMessage());$missing=str_contains($m,'pgrst202')||str_contains($m,'could not find the function');$add('v13.5.4 Employee Workspace',$label,!$missing,$missing?'RPC missing · run v13.5.4 SQL':'RPC reachable · invalid probe session correctly rejected');}
    }
    if($store!==''){
        try{$pb=v13_rpc('v1355_owner_performance_board',['p_store_id'=>$store,'p_period'=>'month','p_anchor'=>date('Y-m-d'),'p_employee_id'=>null],$token);$add('v13.5.5 Performance','Performance leaderboard day/month/year RPC',is_array($pb)&&isset($pb['ranking']),'ranking='.(is_array($pb['ranking']??null)?count($pb['ranking']):0));}
        catch(Throwable $e){$add('v13.5.5 Performance','Performance leaderboard day/month/year RPC',false,'请运行 RUN_ONCE_V13_5_5_PERFORMANCE_EMPLOYEE_PRODUCTS_HOTFIX.sql。');}
    }

    try{
        v13_rpc('v1355_employee_product_inventory',['p_session_token'=>'__salonos_contract_probe__'],$token);
        $add('v13.5.5 Employee Products','Employee Product / Inventory RPC',true,'RPC reachable');
    }catch(Throwable $e){
        $m=strtolower($e->getMessage());$missing=str_contains($m,'pgrst202')||str_contains($m,'could not find the function');
        $add('v13.5.5 Employee Products','Employee Product / Inventory RPC',!$missing,$missing?'RPC missing · run v13.5.5 SQL':'RPC reachable · invalid probe session correctly rejected');
    }

    try{
        $rows=salonos_supabase_rest_rows('service_categories','select=id,name&organization_id=eq.'.rawurlencode($org).'&limit=1',$token);
        $add('v13.5 Product UX','Service category folders',true,'service_categories reachable');
    }catch(Throwable $e){$add('v13.5 Product UX','Service category folders',false,'请运行 v13.5.0 累计 SQL。');}
    try{
        $rows=salonos_supabase_rest_rows('v13_monthly_commission_overrides','select=id&organization_id=eq.'.rawurlencode($org).'&limit=1',$token);
        $add('v13.5 Product UX','Monthly commission adjustments',true,'override table reachable');
    }catch(Throwable $e){$add('v13.5 Product UX','Monthly commission adjustments',false,'请运行 v13.5.0 累计 SQL。');}
    try{
        $rows=salonos_supabase_rest_rows('products','select=stock_unit&organization_id=eq.'.rawurlencode($org).'&limit=1',$token);
        $add('v13.5 Product UX','Inventory unit + Storage URL contract',true,'stock_unit reachable · image binary not stored in DB');
    }catch(Throwable $e){$add('v13.5 Product UX','Inventory unit + Storage URL contract',false,'请运行 v13.5.0 累计 SQL。');}

    try{
        $rows=salonos_supabase_rest_rows('v13_product_categories','select=id,name&organization_id=eq.'.rawurlencode($org).'&limit=1',$token);
        $add('v13.5.4 Product / Member','Product category folders',true,'v13_product_categories reachable');
    }catch(Throwable $e){$add('v13.5.4 Product / Member','Product category folders',false,'请运行 v13.5.4 Product / Member / Search SQL。');}
    try{
        $rows=salonos_supabase_rest_rows('products','select=category_id&organization_id=eq.'.rawurlencode($org).'&limit=1',$token);
        $add('v13.5.4 Product / Member','products.category_id',true,'category_id reachable');
    }catch(Throwable $e){$add('v13.5.4 Product / Member','products.category_id',false,'产品分类字段尚未安装。');}
    try{
        $rows=salonos_supabase_rest_rows('v13_member_product_sales','select=id,total_amount,wallet_amount,external_amount&organization_id=eq.'.rawurlencode($org).'&limit=1',$token);
        $add('v13.5.4 Product / Member','Member retail purchase ledger',true,'wallet + Cash/Card/E-Wallet sales table reachable');
    }catch(Throwable $e){$add('v13.5.4 Product / Member','Member retail purchase ledger',false,'会员产品购买表尚未安装。');}

    try{
        $rows=salonos_supabase_rest_rows('visit_service_items','select=service_category_snapshot&organization_id=eq.'.rawurlencode($org).'&limit=1',$token);
        $add('Schema compatibility','visit_service_items.service_category_snapshot',true,'column reachable');
    }catch(Throwable $e){$add('Schema compatibility','visit_service_items.service_category_snapshot',false,$e->getMessage());}

    foreach($tables as $table=>$label){
        try{
            // Most tenant tables use organization_id, but organizations itself is keyed by id.
            // Activation codes are intentionally checked without an org filter because their
            // tenant reference is target_organization_id and Creator/RLS decides visibility.
            $tenantFilter='';
            if($org!==''){
                if($table==='organizations'){
                    $tenantFilter='&id=eq.'.rawurlencode($org);
                }elseif($table!=='saas_activation_codes'){
                    $tenantFilter='&organization_id=eq.'.rawurlencode($org);
                }
            }
            $q='select=*'.$tenantFilter.'&limit=1';
            $rows=salonos_supabase_rest_rows($table,$q,$token);
            $add('Core tables',$label.' · '.$table,true,'reachable');
        }catch(Throwable $e){$add('Core tables',$label.' · '.$table,false,$e->getMessage());}
    }
}

$pass=count(array_filter($tests,fn($t)=>$t['ok']));
$total=count($tests); $fail=$total-$pass;
?><!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>SalonOS v13.5.5 Master Spec 自检</title><meta name="theme-color" content="#070b10"><style>
:root{color-scheme:dark;--bg:#070b10;--panel:#0c1621;--line:#20303d;--text:#f2f6fa;--muted:#8fa4b6;--gold:#efbd69;--green:#53d994;--red:#ff8d9a;--blue:#86d8ff}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 80% 0,rgba(78,164,221,.09),transparent 32%),var(--bg);color:var(--text);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}.wrap{max-width:1180px;margin:auto;padding:28px 22px 70px}.top{display:flex;justify-content:space-between;align-items:end;gap:20px;flex-wrap:wrap}.eyebrow{font-size:12px;letter-spacing:.15em;color:var(--gold);font-weight:800}.top h1{font-size:34px;margin:4px 0}.score{border:1px solid var(--line);border-radius:20px;padding:16px 20px;background:var(--panel);font-size:20px;font-weight:800}.score .good{color:var(--green)}.score .bad{color:var(--red)}.intro{margin:18px 0 26px;padding:15px 18px;border:1px solid rgba(134,216,255,.2);background:rgba(134,216,255,.06);border-radius:15px;color:#bfe8ff}.group{margin-top:24px}.group h2{font-size:14px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em}.grid{display:grid;gap:9px}.row{display:grid;grid-template-columns:34px 1fr;gap:12px;padding:14px 16px;background:linear-gradient(135deg,#0c1621,#0a121b);border:1px solid var(--line);border-radius:14px}.mark{font-size:19px;font-weight:900}.ok .mark{color:var(--green)}.bad .mark{color:var(--red)}.detail{color:var(--muted);font-size:12px;margin-top:3px;overflow-wrap:anywhere}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:26px}a{color:var(--text);text-decoration:none}.btn{display:inline-flex;padding:12px 16px;border:1px solid var(--line);border-radius:12px;background:#101a24}.btn.primary{color:#101010;border-color:#d7a452;background:linear-gradient(135deg,#b98035,#ffd793)}
</style></head><body><main class="wrap"><header class="top"><div><div class="eyebrow">SALONOS V13.5.4 · MASTER SPEC · UI v12.4.4 · SUPABASE ONLY</div><h1>一次完整系统自检</h1><div style="color:var(--muted)">这页只读取状态，不会删除或修改业务数据。</div></div><div class="score"><span class="good"><?=$pass?> PASS</span> · <span class="bad"><?=$fail?> FAIL</span> / <?=$total?></div></header><div class="intro">验收标准：活跃 v13 Runtime 不连接 InfinityFree MySQL；老板/分行管理员由 Supabase Auth + RLS 控制；员工手机号通过 Supabase Session；所有核心业务表与 RPC 都必须可访问。</div>
<?php $groups=array_values(array_unique(array_column($tests,'group'))); foreach($groups as $g): ?><section class="group"><h2><?=st_e($g)?></h2><div class="grid"><?php foreach($tests as $t): if($t['group']!==$g)continue; ?><div class="row <?=$t['ok']?'ok':'bad'?>"><div class="mark"><?=$t['ok']?'✓':'×'?></div><div><strong><?=st_e($t['name'])?></strong><div class="detail"><?=st_e($t['detail'])?></div></div></div><?php endforeach;?></div></section><?php endforeach;?>
<div class="actions"><a class="btn primary" href="index.php">← 回 SalonOS</a><a class="btn" href="system-test.php">重新检查</a><a class="btn" href="creator/">Creator</a></div></main><?php /* v13.5.5 contract markers: employees.avatar_path, v1354_employee_customer_directory, v1355_employee_performance_board, v1355_owner_performance_board, v1355_employee_product_inventory, v1354_employee_avatar_upload_ticket */ ?>
</body></html>
