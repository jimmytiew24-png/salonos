<?php
declare(strict_types=1);

/**
 * SalonOS /t fallback router.
 *
 * Normal route:
 *   /t/fatchew-profile -> ../track.php?slug=fatchew-profile
 *
 * This file exists for shared hosting where the root rewrite rule is not applied
 * before directory handling. It delegates to the same production tracker, so there
 * is only one attribution implementation.
 */

$slug = trim((string)($_GET['slug'] ?? ''));
if ($slug === '') {
    $requestUri = (string)($_SERVER['REQUEST_URI'] ?? '');
    $path = parse_url($requestUri, PHP_URL_PATH);
    if (is_string($path)) {
        $parts = array_values(array_filter(explode('/', trim($path, '/'))));
        $tIndex = array_search('t', $parts, true);
        if ($tIndex !== false && isset($parts[$tIndex + 1])) {
            $slug = trim((string)$parts[$tIndex + 1]);
        }
    }
}

if ($slug !== '') {
    $_GET['slug'] = $slug;
}

require dirname(__DIR__) . '/track.php';
