<?php
declare(strict_types=1);

// SalonOS public marketing-attribution route.
// Supports both content links and social-profile links (content_id may be NULL).
// A unique Ref is written to tracking_clicks, then embedded into the WhatsApp prefill
// so the webhook can map the conversation back to the exact tracking_link.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

require_once __DIR__.'/supabase_auth.php';

$slug=strtolower(trim((string)($_GET['slug']??'')));
$slug=preg_replace('/[^a-z0-9_-]+/','-',$slug)?:'';
$slug=trim($slug,'-_');
if($slug==='') { http_response_code(404); exit('Tracking link not found.'); }
$prefix=strtoupper(preg_replace('/[^A-Za-z0-9]+/','-', $slug)?:'REF');
try { $suffix=strtoupper(substr(bin2hex(random_bytes(4)),0,4)); }
catch(Throwable $e) { $suffix=strtoupper(substr(hash('sha256',microtime(true).'|'.mt_rand()),0,4)); }
$ref=substr($prefix,0,32).'-'.$suffix;
try {
    $payload=salonos_supabase_request('rest/v1/rpc/v1360_marketing_track','', 'POST',[
      'p_slug'=>$slug,'p_ref_code'=>$ref,'p_user_agent'=>substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,500)
    ],['Prefer: return=representation']);
} catch(Throwable $e) {
    http_response_code(503); exit('Tracking is temporarily unavailable.');
}
if(empty($payload['ok'])) { http_response_code(404); exit('Tracking link not found.'); }
$type=(string)($payload['destination_type']??'whatsapp');
if($type==='url'){
    $url=trim((string)($payload['destination_url']??''));
    if($url==='' || !preg_match('#^https?://#i',$url)){http_response_code(422);exit('Destination URL is not configured.');}
    $sep=str_contains($url,'?')?'&':'?';
    header('Location: '.$url.$sep.'ref='.rawurlencode($ref),true,302); exit;
}
$phone=preg_replace('/\D+/','',(string)($payload['destination_phone']??''))?:'';
if(str_starts_with($phone,'0'))$phone='60'.substr($phone,1);
if($phone===''){http_response_code(422);exit('WhatsApp destination is not configured.');}
$message=trim((string)($payload['prefill_message']??'')); if($message==='')$message="Hi, I'd like to make an appointment.";
if(str_contains($message,'{ref}')) $message=str_replace('{ref}',$ref,$message);
else $message.="\n\nRef: ".$ref;
header('Location: https://wa.me/'.$phone.'?text='.rawurlencode($message),true,302); exit;
