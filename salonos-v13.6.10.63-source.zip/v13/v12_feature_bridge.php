<?php
declare(strict_types=1);

/**
 * SalonOS v13.2 bridge
 *
 * Goal: keep the v12.4.4 information architecture / feature entry points while
 * the runtime remains Supabase-only. This file intentionally contains no PDO,
 * mysqli or InfinityFree MySQL fallback.
 */

function v132_settings_row(): array {
    static $cache = null;
    if ($cache !== null) return $cache;
    if (!v13_is_owner()) {
        $session=trim((string)($_SESSION['v13_employee_session_token']??''));
        if($session==='') return $cache=[];
        try{
            $payload=v13_rpc_json('v1352_employee_role_permissions',['p_session_token'=>$session],'');
            return $cache=[
                'organization_id'=>(string)($payload['organization_id']??''),
                'general'=>is_array($payload['general']??null)?$payload['general']:[],
                'role_permissions'=>is_array($payload['role_permissions']??null)?$payload['role_permissions']:[],
                'whatsapp'=>[],
            ];
        }catch(Throwable $e){return $cache=[];}
    }
    try {
        $rows = v13_owner_rows(
            'v13_organization_settings',
            'select=organization_id,general,role_permissions,whatsapp&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&limit=1'
        );
        return $cache = (is_array($rows[0] ?? null) ? $rows[0] : []);
    } catch (Throwable $e) {
        return $cache = [];
    }
}

function v132_general_settings(): array {
    $row = v132_settings_row();
    return is_array($row['general'] ?? null) ? $row['general'] : [];
}

function v132_whatsapp_settings(): array {
    $row = v132_settings_row();
    return is_array($row['whatsapp'] ?? null) ? $row['whatsapp'] : [];
}

function v1361_whatsapp_connection(): array {
    if(!v13_is_owner()) return [];
    try {
        $rows=v13_owner_rows('whatsapp_business_connections','select=id,organization_id,store_id,phone_number_id,business_account_id,display_phone_number,enabled,connection_status,last_webhook_at,last_error,updated_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&order=updated_at.desc&limit=1');
        return is_array($rows[0]??null)?$rows[0]:[];
    } catch(Throwable $e){ return []; }
}
function v1361_whatsapp_effective_settings(): array {
    $w=v132_whatsapp_settings();$c=v1361_whatsapp_connection();
    if($c){
        $w['phone_number_id']=(string)($c['phone_number_id']??$w['phone_number_id']??'');
        $w['business_account_id']=(string)($c['business_account_id']??$w['business_account_id']??'');
        $w['public_phone']=(string)($c['display_phone_number']??$w['public_phone']??'');
        $w['enabled']=isset($c['enabled'])?(bool)$c['enabled']:(!empty($w['enabled']));
    }
    // v13.6.10.35: prefer the branch-scoped send status when available. This
    // keeps the UI honest after Embedded Signup enables auto reply / stores a
    // business token without exposing the token itself to authenticated users.
    if(v13_is_owner()){
        try{
            $status=v13_rpc_json('v136635_owner_whatsapp_embedded_signup_status',['p_store_id'=>v13_store_uuid()],v13_owner_token_required_all());
            if(!empty($status['configured'])){
                if(array_key_exists('auto_reply_enabled',$status)) $w['auto_reply_enabled']=!empty($status['auto_reply_enabled']);
                $w['access_token_configured']=!empty($status['token_configured']);
                $w['onboarding_method']=(string)($status['onboarding_method']??'manual');
                $w['embedded_signup_status']=(string)($status['embedded_signup_status']??'not_started');
                $w['token_source']=(string)($status['token_source']??'manual');
                $w['embedded_signup_connected_at']=(string)($status['embedded_signup_connected_at']??'');
                $w['webhook_subscribed_at']=(string)($status['webhook_subscribed_at']??'');
                $w['embedded_signup_last_error']=(string)($status['embedded_signup_last_error']??'');
            }
        }catch(Throwable $ignore){}
    }
    // v13.6.8: reminder policy is branch-scoped. Keep compatibility when the SQL
    // has not yet been installed by falling back to legacy organization settings.
    if(v13_is_owner()){
        try{
            $r=v13_rpc_json('v1368_owner_whatsapp_reminder_config_status',['p_store_id'=>v13_store_uuid()],v13_owner_token_required_all());
            if(!empty($r['configured'])){
                $w['reminder_enabled']=!empty($r['reminder_enabled']);
                $w['reminder_minutes']=(int)($r['reminder_minutes_before']??60);
                $w['message_template']=(string)($r['reminder_text_template']??$w['message_template']??'');
                $w['reminder_template_name']=(string)($r['reminder_template_name']??'');
                $w['reminder_template_language']=(string)($r['reminder_template_language']??'zh_CN');
            }
        }catch(Throwable $ignore){}
    }
    return $w;
}
function v1361_whatsapp_webhook_url(): string {
    return rtrim(SALONOS_SUPABASE_URL,'/').'/functions/v1/whatsapp-webhook';
}

/** v13.6.10.35: server-side bridge for Meta Embedded Signup. The browser never
 * receives the owner's Supabase JWT or Meta App Secret. */
function v136635_whatsapp_embedded_signup_api(array $payload): array {
    if(!v13_is_owner()) throw new RuntimeException('只有老板账号可以连接 WhatsApp Business。');
    $payload['store_id']=v13_store_uuid();
    return salonos_supabase_request(
        'functions/v1/whatsapp-embedded-signup',
        v13_owner_token_required_all(),
        'POST',
        $payload
    );
}
function v136635_whatsapp_embedded_signup_public_config(): array {
    try { return v136635_whatsapp_embedded_signup_api(['action'=>'config']); }
    catch(Throwable $e){ return ['ready'=>false,'missing'=>[],'error'=>$e->getMessage()]; }
}

/** v13.6.10.36: authenticated server-side bridge for customer-owned Meta Apps.
 * App Secret and Access Token are forwarded only to the Edge Function and are
 * never written into the browser-visible organization settings JSON. */
function v136636_whatsapp_manual_connect_api(array $payload): array {
    if(!v13_is_owner()) throw new RuntimeException('只有老板账号可以连接 WhatsApp Business。');
    $payload['store_id']=v13_store_uuid();
    return salonos_supabase_request(
        'functions/v1/whatsapp-manual-connect',
        v13_owner_token_required_all(),
        'POST',
        $payload
    );
}
function v136636_whatsapp_manual_status(): array {
    if(!v13_is_owner()) return [];
    try{
        return v13_rpc_json('v136636_owner_whatsapp_manual_status',['p_store_id'=>v13_store_uuid()],v13_owner_token_required_all());
    }catch(Throwable $e){ return ['configured'=>false,'error'=>$e->getMessage()]; }
}

function v132_role_permissions_settings(): array {
    $row = v132_settings_row();
    return is_array($row['role_permissions'] ?? null) ? $row['role_permissions'] : [];
}

function v132_builtin_role_definitions(): array {
    return [
        'manager'=>['label'=>'经理','system'=>true],
        'receptionist'=>['label'=>'柜台 / 接待','system'=>true],
        'accountant'=>['label'=>'会计','system'=>true],
        'stylist'=>['label'=>'理发师','system'=>true],
        'assistant'=>['label'=>'助理','system'=>true],
        'staff'=>['label'=>'员工','system'=>true],
    ];
}

function v132_role_definitions(): array {
    $saved = v132_role_permissions_settings();
    $deleted = is_array($saved['_deleted_roles'] ?? null) ? array_values(array_map('strval',$saved['_deleted_roles'])) : [];
    $defs = [];
    foreach (v132_builtin_role_definitions() as $code=>$meta) {
        if (!in_array($code,$deleted,true)) $defs[$code]=$meta;
    }
    $custom = is_array($saved['_roles'] ?? null) ? $saved['_roles'] : [];
    foreach ($custom as $code=>$meta) {
        $code = preg_replace('/[^a-z0-9_]/','',strtolower((string)$code)) ?: '';
        if ($code === '' || isset($defs[$code])) continue;
        $label = trim((string)(is_array($meta) ? ($meta['label'] ?? '') : $meta));
        if ($label === '') continue;
        $defs[$code] = ['label'=>$label,'system'=>false];
    }
    return $defs;
}

function v132_role_label(string $role): string {
    $defs = v132_role_definitions();
    return (string)($defs[$role]['label'] ?? $role ?: '员工');
}

function v132_role_is_custom(string $role): bool {
    $defs = v132_role_definitions();
    return isset($defs[$role]) && empty($defs[$role]['system']);
}

function system_setting(string $key, string $default=''): string {
    $g = v132_general_settings();
    $aliases = [
        'system_language' => 'language',
        'invoice_prefix' => 'receipt_prefix',
    ];
    $actual = $aliases[$key] ?? $key;
    if (array_key_exists($actual, $g) && !is_array($g[$actual])) return (string)$g[$actual];
    if ($key === 'business_name') {
        $identity = salonos_supabase_identity() ?? [];
        return (string)($g['business_name'] ?? $identity['organization_name'] ?? $default);
    }
    return $default;
}


function v1361051_effective_ui_language(): string {
    $cached=(string)($_SESSION['v1361051_ui_language']??'');
    if(in_array($cached,['zh','en'],true)) return $cached;
    if(!v13_is_owner()){
        $session=trim((string)($_SESSION['v13_employee_session_token']??''));
        if($session!==''){
            try{
                $pref=v13_rpc_json('v1361051_employee_ui_preference',['p_session_token'=>$session],'');
                $lang=(string)($pref['ui_language']??'');
                if(in_array($lang,['zh','en'],true)) return $_SESSION['v1361051_ui_language']=$lang;
            }catch(Throwable $e){ /* patch may not be installed yet */ }
        }
    }else{
        $cookie=(string)($_COOKIE['salonos_v13_owner_ui_language']??'');
        if(in_array($cookie,['zh','en'],true)) return $_SESSION['v1361051_ui_language']=$cookie;
    }
    $fallback=system_setting('system_language','zh');
    return in_array($fallback,['zh','en'],true)?$fallback:'zh';
}

function can_manage(): bool { return v13_is_owner(); }

function v132_default_permissions(string $role): array {
    // Keep defaults conservative. Owners always bypass this matrix; staff only receive what their role needs.
    $base = ['dashboard.view','visits.create','orders.view','performance.view','training.view','attendance.scan'];
    return match ($role) {
        'manager' => ['*'],
        'receptionist' => array_merge($base,[
            'orders.manage','appointments.manage','checkout.manage',
            'customers.view','customers.manage','products.view',
            'attendance.team.view','attendance.station',
            'order_history.view'
        ]),
        'accountant' => [
            'dashboard.view','order_history.view','analytics.view','performance.view',
            'commission.view','reports.export','attendance.scan'
        ],
        'stylist' => array_merge($base,['customers.view','products.view','kpi.view']),
        'assistant' => array_merge($base,['kpi.view']),
        default => $base,
    };
}

function has_permission(string $permission): bool {
    if (v13_is_owner()) return true;
    $role = (string)(user()['role'] ?? 'staff');
    $configured = v132_role_permissions_settings();
    $list = is_array($configured[$role] ?? null) ? array_values(array_map('strval',$configured[$role])) : v132_default_permissions($role);
    if(in_array('*',$list,true)) return true;
    // Settings sub-permissions are nested under settings.view. A role cannot reach a child setting without the Settings entry itself.
    if($permission!=='settings.view' && str_starts_with($permission,'settings.') && !in_array('settings.view',$list,true)) return false;
    return in_array($permission,$list,true);
}

function has_any_permission(array $permissions): bool {
    foreach ($permissions as $p) if (has_permission((string)$p)) return true;
    return false;
}

function current_store_id(): string { return v13_store_uuid(); }
function fetch_one(string $sql, array $params=[]): ?array { return null; } // Legacy signature only; never used as a datastore in v13.2.

function v132_upsert_org_settings(string $section, array $value): void {
    v13_owner_token_required_all();
    $rows = v13_owner_rows('v13_organization_settings','select=organization_id,general,role_permissions,whatsapp&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&limit=1');
    $current = $rows[0] ?? ['organization_id'=>v13_org_uuid(),'general'=>[],'role_permissions'=>[],'whatsapp'=>[]];
    $current['organization_id'] = v13_org_uuid();
    $current[$section] = $value;
    v13_owner_write('v13_organization_settings','on_conflict=organization_id','POST',$current,'resolution=merge-duplicates,return=representation');
}

function v132_normalize_phone(string $phone): string {
    $d = preg_replace('/[^0-9]/','',$phone) ?? '';
    if (str_starts_with($d,'60') && strlen($d) > 10) $d = '0'.substr($d,2);
    return $d;
}

function v132_handle_action(string $action): ?string {
    if ($action === 'save_personal_ui_language_v1361051') {
        if(!v13_is_owner() && !has_permission('settings.view')) throw new RuntimeException('没有系统设置权限。');
        $lang=in_array((string)($_POST['ui_language']??''),['zh','en'],true)?(string)$_POST['ui_language']:'zh';
        if(v13_is_owner()){
            $_SESSION['v1361051_ui_language']=$lang;
            $secure=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';
            setcookie('salonos_v13_owner_ui_language',$lang,['expires'=>time()+86400*365,'path'=>'/v13/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
            $_COOKIE['salonos_v13_owner_ui_language']=$lang;
        }else{
            $session=trim((string)($_SESSION['v13_employee_session_token']??''));
            if($session==='') throw new RuntimeException('员工登录已过期，请重新登录。');
            v13_rpc_json('v1361051_employee_set_ui_language',['p_session_token'=>$session,'p_language'=>$lang],'');
            $_SESSION['v1361051_ui_language']=$lang;
        }
        flash('success',$lang==='en'?'Your personal interface language is now English.':'你的个人界面语言已经切换为中文。');
        return 'settings';
    }
    if (!v13_is_owner()) return null;
    if ($action === 'save_general_settings') {
        v132_upsert_org_settings('general',[
            'business_name'=>trim((string)($_POST['business_name']??'SalonOS')) ?: 'SalonOS',
            'language'=>in_array((string)($_POST['system_language']??'zh'),['zh','en'],true)?(string)$_POST['system_language']:'zh',
            'timezone'=>trim((string)($_POST['timezone']??'Asia/Kuala_Lumpur')) ?: 'Asia/Kuala_Lumpur',
            'currency'=>trim((string)($_POST['currency']??'MYR')) ?: 'MYR',
            'receipt_prefix'=>mb_substr(trim((string)($_POST['invoice_prefix']??'INV')),0,10) ?: 'INV',
            'device_remember_days'=>max(1,min(365,(int)($_POST['device_remember_days']??30))),
        ]);
        flash('success','门店通用设置已经保存到 Supabase。');
        return 'settings_general';
    }
    if ($action === 'save_role_permissions_v132') {
        $defs = v132_role_definitions();
        $current = v132_role_permissions_settings();
        $out=['_roles'=>is_array($current['_roles']??null)?$current['_roles']:[],'_deleted_roles'=>is_array($current['_deleted_roles']??null)?array_values(array_map('strval',$current['_deleted_roles'])):[]];
        foreach(array_keys($defs) as $r){
            $vals=(array)($_POST['permissions'][$r]??[]);
            $out[$r]=array_values(array_unique(array_filter(array_map('strval',$vals))));
            if($r==='manager' && !$out[$r])$out[$r]=['*'];
        }
        v132_upsert_org_settings('role_permissions',$out);
        flash('success','员工权限矩阵已经保存到 Supabase。');
        return 'settings_roles';
    }
    if ($action === 'save_single_role_permissions_v1361051') {
        $role=preg_replace('/[^a-z0-9_]/','',strtolower(trim((string)($_POST['role_code']??'')))) ?: '';
        $defs=v132_role_definitions();
        if($role==='' || !isset($defs[$role])) throw new RuntimeException('找不到这个职位。');
        $settings=v132_role_permissions_settings();
        $vals=(array)($_POST['permissions']??[]);
        $settings[$role]=array_values(array_unique(array_filter(array_map('strval',$vals))));
        if($role==='manager' && !$settings[$role]) $settings[$role]=['*'];
        v132_upsert_org_settings('role_permissions',$settings);
        flash('success','职位「'.v132_role_label($role).'」的权限已经保存。');
        return 'settings_roles';
    }
    if ($action === 'add_role_v1352') {
        $label=trim((string)($_POST['role_label']??''));
        if($label==='') throw new RuntimeException('请输入职位名称。');
        if(mb_strlen($label)>40) throw new RuntimeException('职位名称最多 40 个字。');
        $settings=v132_role_permissions_settings();
        $custom=is_array($settings['_roles']??null)?$settings['_roles']:[];
        foreach(v132_role_definitions() as $meta){
            if(mb_strtolower(trim((string)($meta['label']??'')))===mb_strtolower($label)) throw new RuntimeException('这个职位名称已经存在。');
        }
        do {
            $code='role_'.substr(hash('sha256',$label.'|'.microtime(true).'|'.random_int(1,PHP_INT_MAX)),0,10);
        } while(isset($custom[$code]));
        $custom[$code]=['label'=>$label,'created_at'=>date(DATE_ATOM)];
        $settings['_roles']=$custom;
        $settings[$code]=v132_default_permissions('staff');
        v132_upsert_org_settings('role_permissions',$settings);
        flash('success','新职位「'.$label.'」已经建立，可以马上分配权限和员工。');
        return 'settings_roles';
    }
    if ($action === 'delete_role_v1352') {
        $role=preg_replace('/[^a-z0-9_]/','',strtolower(trim((string)($_POST['role_code']??'')))) ?: '';
        $defs=v132_role_definitions();
        if($role==='' || !isset($defs[$role])) throw new RuntimeException('找不到这个职位。');
        if(count($defs)<=1) throw new RuntimeException('至少要保留一个员工职位，不能把最后一个职位删除。');
        $settings=v132_role_permissions_settings();
        $label=v132_role_label($role);
        $remaining=$defs; unset($remaining[$role]);
        $fallback=array_key_exists('staff',$remaining)?'staff':(string)array_key_first($remaining);
        try{
            v13_owner_write('employees',
                'organization_id=eq.'.rawurlencode(v13_org_uuid()).'&app_role=eq.'.rawurlencode($role),
                'PATCH',['app_role'=>$fallback,'updated_at'=>date(DATE_ATOM)],'return=minimal'
            );
        }catch(Throwable $e){throw new RuntimeException('删除职位前无法安全重新分配员工，请稍后再试。',0,$e);}
        if(!empty($defs[$role]['system'])){
            $deleted=is_array($settings['_deleted_roles']??null)?array_values(array_map('strval',$settings['_deleted_roles'])):[];
            if(!in_array($role,$deleted,true))$deleted[]=$role;
            $settings['_deleted_roles']=$deleted;
        }else{
            if(is_array($settings['_roles']??null)) unset($settings['_roles'][$role]);
        }
        unset($settings[$role]);
        v132_upsert_org_settings('role_permissions',$settings);
        flash('success','职位「'.$label.'」已删除；使用这个职位的员工已自动改为「'.v132_role_label($fallback).'」，历史订单和业绩不会删除。');
        return 'settings_roles';
    }
    if ($action === 'connect_whatsapp_manual_v136636') {
        $appId=trim((string)($_POST['wa_manual_app_id']??''));
        $appSecret=trim((string)($_POST['wa_manual_app_secret']??''));
        $accessToken=trim((string)($_POST['wa_manual_access_token']??''));
        $wabaId=trim((string)($_POST['wa_manual_waba_id']??''));
        $phoneNumberId=trim((string)($_POST['wa_manual_phone_number_id']??''));
        $publicPhone=preg_replace('/[^0-9]+/','',trim((string)($_POST['wa_manual_public_phone']??'')))?:'';
        $autoReply=!empty($_POST['wa_manual_auto_reply_enabled']);
        if($appId===''||$appSecret===''||$accessToken===''||$wabaId===''||$phoneNumberId===''){
            throw new RuntimeException('Manual Connect 需要填写 Meta App ID、App Secret、WABA ID、Phone Number ID 和 Access Token。');
        }
        $result=v136636_whatsapp_manual_connect_api([
            'action'=>'connect',
            'meta_app_id'=>$appId,
            'meta_app_secret'=>$appSecret,
            'access_token'=>$accessToken,
            'waba_id'=>$wabaId,
            'phone_number_id'=>$phoneNumberId,
            'display_phone_number'=>$publicPhone!==''?$publicPhone:null,
            'auto_reply_enabled'=>$autoReply,
        ]);
        if(empty($result['ok'])) throw new RuntimeException('Manual WhatsApp Connect 验证没有完成，请检查 Meta 资料。');
        $_SESSION['v136636_manual_webhook_setup']=[
            'callback_url'=>(string)($result['callback_url']??v1361_whatsapp_webhook_url()),
            'verify_token'=>(string)($result['verify_token']??''),
            'webhook_field'=>(string)($result['webhook_field']??'messages'),
            'display_phone_number'=>(string)($result['display_phone_number']??''),
            'verified_name'=>(string)($result['verified_name']??''),
            'phone_number_id'=>(string)($result['phone_number_id']??$phoneNumberId),
            'waba_id'=>(string)($result['waba_id']??$wabaId),
            'meta_app_id'=>(string)($result['meta_app_id']??$appId),
            'token_expires_at'=>(string)($result['token_expires_at']??''),
            'warnings'=>is_array($result['warnings']??null)?$result['warnings']:[],
        ];
        flash('success','客户自己的 Meta App / WABA 已验证并保存。下一步把一次性 Verify Token 和 Callback URL 填到客户的 Meta Webhooks，然后订阅 messages。');
        return 'settings_whatsapp';
    }

    if ($action === 'save_whatsapp_settings') {
        $phoneNumberId=trim((string)($_POST['wa_phone_number_id']??''));
        $businessAccountId=trim((string)($_POST['wa_business_account_id']??''));
        $publicPhone=preg_replace('/[^0-9]+/','',trim((string)($_POST['wa_public_phone']??'')))?:'';
        $newToken=trim((string)($_POST['wa_access_token']??''));
        $enabled=!empty($_POST['wa_enabled']);
        $autoReply=!empty($_POST['wa_auto_reply_enabled']);
        if($phoneNumberId==='') throw new RuntimeException('请填写 Meta Phone Number ID。');

        // v13.6.6: access token is branch-scoped and server-side only. The RPC never returns it.
        $saved=v13_rpc_json('v1366_owner_save_whatsapp_store_config',[
            'p_store_id'=>v13_store_uuid(),
            'p_phone_number_id'=>$phoneNumberId,
            'p_business_account_id'=>$businessAccountId!==''?$businessAccountId:null,
            'p_display_phone_number'=>$publicPhone!==''?$publicPhone:null,
            'p_access_token'=>$newToken!==''?$newToken:null,
            'p_enabled'=>$enabled,
            'p_auto_reply_enabled'=>$autoReply,
            'p_graph_api_version'=>'v26.0',
        ],v13_owner_token_required_all());

        if($newToken!==''){
            try{v13_rpc_json('v136635_owner_mark_whatsapp_manual_token',['p_store_id'=>v13_store_uuid()],v13_owner_token_required_all());}catch(Throwable $ignore){}
        }

        $reminderEnabled=!empty($_POST['wa_reminder_enabled']);
        $reminderMinutes=max(0,min(10080,(int)($_POST['wa_reminder_minutes']??60)));
        $reminderText=trim((string)($_POST['wa_message_template']??''));
        $reminderTemplateName=trim((string)($_POST['wa_reminder_template_name']??''));
        $reminderTemplateLanguage=trim((string)($_POST['wa_reminder_template_language']??'zh_CN'))?:'zh_CN';
        v13_rpc_json('v1368_owner_save_whatsapp_reminder_config',[
            'p_store_id'=>v13_store_uuid(),
            'p_reminder_enabled'=>$reminderEnabled,
            'p_reminder_minutes_before'=>$reminderMinutes,
            'p_reminder_text_template'=>$reminderText!==''?$reminderText:null,
            'p_reminder_template_name'=>$reminderTemplateName!==''?$reminderTemplateName:null,
            'p_reminder_template_language'=>$reminderTemplateLanguage,
        ],v13_owner_token_required_all());

        // Keep only non-secret preferences in the legacy organization settings JSON.
        v132_upsert_org_settings('whatsapp',[
            'enabled'=>$enabled,
            'phone_number_id'=>$phoneNumberId,
            'business_account_id'=>$businessAccountId,
            'public_phone'=>$publicPhone,
            'access_token_configured'=>!empty($saved['token_configured']),
            'auto_reply_enabled'=>$autoReply,
            'reminder_enabled'=>$reminderEnabled,
            'reminder_minutes'=>$reminderMinutes,
            'message_template'=>$reminderText,
            'reminder_template_name'=>$reminderTemplateName,
            'reminder_template_language'=>$reminderTemplateLanguage,
        ]);
        flash('success','WhatsApp Business 设置已经保存；AI 自动回复与预约提醒都按当前分行独立生效。');
        return 'settings_whatsapp';
    }

    if ($action === 'complete_whatsapp_embedded_signup_v136635') {
        $code=trim((string)($_POST['wa_es_code']??''));
        $wabaId=trim((string)($_POST['wa_es_waba_id']??''));
        $phoneNumberId=trim((string)($_POST['wa_es_phone_number_id']??''));
        $businessId=trim((string)($_POST['wa_es_business_id']??''));
        $flow=((string)($_POST['wa_es_flow_type']??'standard'))==='business_app'?'business_app':'standard';
        if($code==='' || $wabaId==='' || $phoneNumberId==='') throw new RuntimeException('Meta Embedded Signup 没有返回完整的 WABA / Phone Number 资料，请重新连接。');
        $result=v136635_whatsapp_embedded_signup_api([
            'action'=>'complete',
            'code'=>$code,
            'waba_id'=>$wabaId,
            'phone_number_id'=>$phoneNumberId,
            'meta_business_id'=>$businessId!==''?$businessId:null,
            'flow_type'=>$flow,
        ]);
        if(empty($result['ok'])) throw new RuntimeException('WhatsApp Embedded Signup 没有完成，请重新连接。');
        $label=trim((string)($result['display_phone_number']??''));
        flash('success','WhatsApp 已通过 Meta Embedded Signup 连接'.($label!==''?'：'.$label:'').'。Business Token 已安全保存到当前分行，Webhook 也已订阅。');
        return 'settings_whatsapp';
    }

    if ($action === 'save_marketing_channel_v1360') {
        $name=trim((string)($_POST['channel_name']??''));
        if($name==='') throw new RuntimeException('请输入媒体／来源渠道名称。');
        $code=strtoupper(preg_replace('/[^A-Za-z0-9]+/','_',trim((string)($_POST['channel_code']??$name)))?:'OTHER');
        $type=in_array((string)($_POST['channel_type']??'social'),['social','search','owned','offline','referral','other'],true)?(string)$_POST['channel_type']:'other';
        v13_owner_write('marketing_channels','on_conflict=organization_id,store_id,code','POST',[
            'organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'code'=>$code,'name'=>$name,'channel_type'=>$type,'active'=>true,'updated_at'=>date(DATE_ATOM)
        ],'resolution=merge-duplicates,return=representation');
        flash('success','媒体／来源渠道已经建立。');
        return 'settings_marketing';
    }
    if ($action === 'archive_marketing_channel_v1360') {
        $id=trim((string)($_POST['channel_id']??'')); if($id==='') throw new RuntimeException('找不到渠道。');
        v13_owner_write('marketing_channels','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',['active'=>false,'updated_at'=>date(DATE_ATOM)],'return=minimal');
        flash('success','渠道已经停用；历史归因不会删除。'); return 'settings_marketing';
    }
    if ($action === 'save_social_account_v1360') {
        $accountId=trim((string)($_POST['account_id']??''));
        $channelId=trim((string)($_POST['channel_id']??'')); $display=trim((string)($_POST['display_name']??''));
        if($channelId===''||$display==='') throw new RuntimeException('请选择平台并填写账号名称。');
        $channels=v13_owner_rows('marketing_channels','select=id,code,name,active&id=eq.'.rawurlencode($channelId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=1');
        if(!$channels) throw new RuntimeException('这个渠道不存在或不属于当前分行。');
        $accountType=in_array((string)($_POST['account_type']??'store'),['store','staff','other'],true)?(string)$_POST['account_type']:'store';
        $staffId=trim((string)($_POST['staff_id']??'')); if($accountType!=='staff')$staffId='';
        if($accountType==='staff' && $staffId==='') throw new RuntimeException('员工账号必须选择对应员工。');
        if($accountType==='staff'){
            $validStaff=false;
            foreach(v13_employee_rows_owner() as $employee){
                if((string)($employee['id']??'')===$staffId){$validStaff=true;break;}
            }
            if(!$validStaff) throw new RuntimeException('选择的员工不属于当前分行或已不可用。');
        }
        $active=$accountId===''?true:!empty($_POST['active']);
        $body=[
          'organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'channel_id'=>$channelId,'platform'=>(string)($channels[0]['code']??''),
          'account_type'=>$accountType,'staff_id'=>$staffId!==''?$staffId:null,'display_name'=>$display,'username'=>trim((string)($_POST['username']??''))?:null,
          'profile_url'=>trim((string)($_POST['profile_url']??''))?:null,'external_account_id'=>trim((string)($_POST['external_account_id']??''))?:null,
          'connection_status'=>'tracking_only','active'=>$active,'updated_at'=>date(DATE_ATOM)
        ];
        if($accountId!==''){
            $existing=v13_owner_rows('social_accounts','select=id&id=eq.'.rawurlencode($accountId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=1');
            if(!$existing) throw new RuntimeException('找不到要修改的媒体账号。');
            v13_owner_write('social_accounts','id=eq.'.rawurlencode($accountId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',$body,'return=representation');
            // Tracking links created from this account inherit its channel/staff identity.
            // Keep future attribution consistent after the owner corrects the account mapping.
            v13_owner_write('tracking_links','social_account_id=eq.'.rawurlencode($accountId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',[
                'channel_id'=>$channelId,
                'staff_id'=>$staffId!==''?$staffId:null,
                'updated_at'=>date(DATE_ATOM)
            ],'return=minimal');
            flash('success','媒体账号已经修改；相关 Tracking Link 的平台／员工归属也已同步。');
        }else{
            v13_owner_write('social_accounts','','POST',$body);
            flash('success','媒体账号已经加入。');
        }
        return 'settings_marketing';
    }
    if ($action === 'archive_social_account_v1360') {
        $id=trim((string)($_POST['account_id']??'')); if($id==='') throw new RuntimeException('找不到媒体账号。');
        v13_owner_write('social_accounts','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',['active'=>false,'updated_at'=>date(DATE_ATOM)],'return=minimal');
        flash('success','媒体账号已经停用；旧 Tracking Link 与历史数据继续保留。'); return 'settings_marketing';
    }
    if ($action === 'save_social_inbox_connection_v1361052') {
        if(!v13_is_owner()) throw new RuntimeException('只有老板可以连接 Instagram / Facebook Direct Message。');
        $socialAccountId=trim((string)($_POST['social_account_id']??''));
        $platform=strtolower(trim((string)($_POST['platform']??'')));
        $externalAccountId=trim((string)($_POST['external_account_id']??''));
        $appId=trim((string)($_POST['meta_app_id']??''));
        $appSecret=trim((string)($_POST['meta_app_secret']??''));
        $accessToken=trim((string)($_POST['page_access_token']??''));
        if(!in_array($platform,['instagram','facebook'],true)) throw new RuntimeException('目前 Direct Message Inbox 只支持 Instagram 与 Facebook。');
        if($socialAccountId===''||$externalAccountId===''||$appId===''||$appSecret===''||$accessToken==='') throw new RuntimeException('请填写媒体账号、Meta Account/Page ID、App ID、App Secret 与 Page Access Token。');
        $result=v13_rpc_json('v1361052_owner_upsert_social_inbox_connection',[
            'p_store_id'=>v13_store_uuid(),'p_social_account_id'=>$socialAccountId,'p_platform'=>$platform,
            'p_external_account_id'=>$externalAccountId,'p_meta_app_id'=>$appId,'p_app_secret'=>$appSecret,'p_access_token'=>$accessToken
        ],v13_owner_token_required_all());
        $_SESSION['v1361052_social_verify_token']=(string)($result['verify_token']??'');
        $_SESSION['v1361052_social_connection_id']=(string)($result['connection_id']??'');
        flash('success','Social Inbox 连接资料已安全保存。请按页面显示的 Callback URL / Verify Token 到 Meta App 完成 Webhook。');
        return 'settings_marketing';
    }
    if ($action === 'save_manual_social_lead_v1361054') {
        if(!v13_is_owner()) throw new RuntimeException('只有老板可以手动收录社交来源。');
        $platform=strtolower(trim((string)($_POST['platform']??'')));
        $socialAccountId=trim((string)($_POST['social_account_id']??''));
        $customerName=trim((string)($_POST['customer_name']??''));
        $customerPhone=preg_replace('/[^0-9+]+/','',trim((string)($_POST['customer_phone']??'')));
        $note=trim((string)($_POST['note']??''));
        if(!in_array($platform,['instagram','facebook','tiktok','xhs','other'],true)) throw new RuntimeException('请选择有效的平台。');
        if($socialAccountId==='') throw new RuntimeException('请选择来源账号。');
        $accRows=v13_owner_rows('social_accounts','select=id,staff_id,display_name&id=eq.'.rawurlencode($socialAccountId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=1');
        if(!$accRows) throw new RuntimeException('来源账号不属于当前分行。');
        v13_owner_write('social_manual_leads','','POST',[
          'organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'social_account_id'=>$socialAccountId,
          'platform'=>$platform,'customer_name'=>$customerName!==''?$customerName:null,'customer_phone'=>$customerPhone!==''?$customerPhone:null,
          'note'=>$note!==''?$note:null,'created_by_user_id'=>(string)(user()['id']??'')?:null,'created_at'=>date(DATE_ATOM)
        ]);
        flash('success','已经手动收录这条社交来源线索。之后可以继续把它合并到顾客／预约流程。');
        return 'settings_marketing';
    }
    if ($action === 'save_tracking_link_v1360') {
        $trackingLinkId=trim((string)($_POST['tracking_link_id']??''));
        $existingLink=null;
        if($trackingLinkId!==''){
          $rows=v13_owner_rows('tracking_links','select=id,content_id,slug&id=eq.'.rawurlencode($trackingLinkId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=1');
          if(!$rows) throw new RuntimeException('找不到要修改的 Tracking Link。');
          $existingLink=$rows[0];
        }

        $channelId=trim((string)($_POST['channel_id']??''));
        if($channelId==='') throw new RuntimeException('请选择来源平台。');
        $channels=v13_owner_rows('marketing_channels','select=id,code,name&id=eq.'.rawurlencode($channelId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=1');
        if(!$channels) throw new RuntimeException('找不到这个来源平台。');

        $accountId=trim((string)($_POST['social_account_id']??''));
        $staffId=trim((string)($_POST['staff_id']??''));
        $accountRow=null;
        if($accountId!==''){
          $accRows=v13_owner_rows('social_accounts','select=id,channel_id,staff_id,display_name,username&id=eq.'.rawurlencode($accountId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=1');
          if(!$accRows) throw new RuntimeException('媒体账号不属于当前分行。');
          $accountRow=$accRows[0];
          if((string)($accountRow['channel_id']??'')!=='' && (string)$accountRow['channel_id']!==$channelId) {
            throw new RuntimeException('媒体账号与选择的平台不一致，请重新选择。');
          }
          if($staffId===''&&!empty($accountRow['staff_id']))$staffId=(string)$accountRow['staff_id'];
        }

        if($staffId!==''){
          $validStaff=false;
          foreach(v13_employee_rows_owner() as $employee){
            if((string)($employee['id']??'')===$staffId){$validStaff=true;break;}
          }
          if(!$validStaff) throw new RuntimeException('选择的员工不属于当前分行或已不可用。');
        }

        $requestedType=strtolower(trim((string)($_POST['content_type']??'profile')));
        $allowedTypes=['profile','bio','reel','post','story','ad','qr','landing','other'];
        if(!in_array($requestedType,$allowedTypes,true))$requestedType='other';
        $placement=$requestedType==='bio'?'profile':$requestedType;
        $contentType=$placement==='profile'?'bio':$placement;
        $contentLabel=trim((string)($_POST['content_label']??''));
        $contentCode=trim((string)($_POST['content_code']??''));
        $contentUrl=trim((string)($_POST['content_url']??''));
        $contentId=trim((string)($_POST['content_id']??''));

        if($placement!=='profile' && $contentLabel==='') {
          throw new RuntimeException('Reel / Post / Story 等内容请填写内容名称，方便以后分析。');
        }

        if($placement==='profile'){
          // Profile / Bio is account-level attribution. It intentionally has no marketing_contents row.
          $contentId='';
        }else{
          $contentBody=[
            'organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'social_account_id'=>$accountId!==''?$accountId:null,
            'content_type'=>$contentType,'content_code'=>$contentCode!==''?$contentCode:null,
            'title'=>$contentLabel!==''?$contentLabel:ucfirst($contentType),
            'external_url'=>$contentUrl!==''?$contentUrl:null,'active'=>true,'updated_at'=>date(DATE_ATOM)
          ];
          if($contentId!==''){
            $known=v13_owner_rows('marketing_contents','select=id&id=eq.'.rawurlencode($contentId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=1');
            if(!$known) throw new RuntimeException('找不到这个媒体内容。');
            v13_owner_write('marketing_contents','id=eq.'.rawurlencode($contentId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',$contentBody,'return=representation');
          }else{
            $created=v13_owner_write('marketing_contents','','POST',$contentBody);
            $contentId=(string)($created[0]['id']??'');
          }
        }

        $slug=strtolower(trim((string)($_POST['slug']??'')));
        $slug=preg_replace('/[^a-z0-9_-]+/','-',$slug)?:'';
        $slug=trim($slug,'-_');
        if($slug===''){
          $accountSeed=(string)($accountRow['username']??$accountRow['display_name']??'');
          $accountSeed=ltrim($accountSeed,'@');
          $seed=trim($accountSeed.'-'.($placement==='profile'?'profile':($contentLabel!==''?$contentLabel:$contentType)));
          $slug=strtolower(preg_replace('/[^A-Za-z0-9]+/','-',$seed)?:'');
          $slug=trim($slug,'-');
        }
        if($slug==='') throw new RuntimeException('无法自动产生短链，请填写 Slug。');

        $dupes=v13_owner_rows('tracking_links','select=id&slug=eq.'.rawurlencode($slug).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=5');
        foreach($dupes as $dup){
          if((string)($dup['id']??'')!==$trackingLinkId) throw new RuntimeException('这个短链 Slug 已经存在，请换一个名称。');
        }

        $destinationType=in_array((string)($_POST['destination_type']??'whatsapp'),['whatsapp','url'],true)?(string)$_POST['destination_type']:'whatsapp';
        $postedPhone=preg_replace('/[^0-9]+/','',trim((string)($_POST['destination_phone']??'')))?:'';
        $businessPhone='';
        if($destinationType==='whatsapp'){
          $waNow=v1361_whatsapp_effective_settings();
          $businessPhone=preg_replace('/[^0-9]+/','',(string)($waNow['public_phone']??''))?:'';
        }
        $phone=$destinationType==='whatsapp'?($businessPhone!==''?$businessPhone:$postedPhone):$postedPhone;
        if($destinationType==='whatsapp' && $phone==='') throw new RuntimeException('请先在 WhatsApp Business 设置中连接门店号码，再建立 Tracking Link。');

        $destinationUrl=trim((string)($_POST['destination_url']??''));
        if($destinationType==='url' && $destinationUrl==='') throw new RuntimeException('最终去向选择 Website / URL 时必须填写网址。');

        $refPrefix=strtoupper(preg_replace('/[^A-Za-z0-9]+/','-',trim((string)($_POST['ref_prefix']??$slug)))?:'REF');
        $active=$trackingLinkId===''?true:!empty($_POST['active']);

        // v13.6.10.13: one media account may have only one ACTIVE Profile/Bio link.
        // Reel/Post/Story/etc. remain unlimited.
        if($active && $placement==='profile' && $accountId!==''){
          $profileDupes=v13_owner_rows(
            'tracking_links',
            'select=id,slug,active,placement,content_id&organization_id=eq.'.rawurlencode(v13_org_uuid()).
            '&store_id=eq.'.rawurlencode(v13_store_uuid()).
            '&social_account_id=eq.'.rawurlencode($accountId).
            '&active=eq.true&limit=50'
          );
          foreach($profileDupes as $profileDupe){
            if((string)($profileDupe['id']??'')===$trackingLinkId)continue;
            $dupePlacement=strtolower(trim((string)($profileDupe['placement']??'')));
            if($dupePlacement==='bio')$dupePlacement='profile';
            // Legacy Profile links may have empty placement + no content row.
            if($dupePlacement==='' && empty($profileDupe['content_id']))$dupePlacement='profile';
            if($dupePlacement!=='profile')continue;
            throw new RuntimeException(
              '这个媒体账号已经有一个启用中的 Profile / Bio Tracking Link（'.
              (string)($profileDupe['slug']??'existing-profile').
              '）。请修改现有 Link，或先停用旧 Link，再启用新的。'
            );
          }
        }

        $linkBody=[
          'organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'channel_id'=>$channelId,
          'social_account_id'=>$accountId!==''?$accountId:null,'content_id'=>$contentId!==''?$contentId:null,
          'staff_id'=>$staffId!==''?$staffId:null,'slug'=>$slug,'ref_prefix'=>mb_substr($refPrefix,0,32),
          'placement'=>$placement,'destination_type'=>$destinationType,
          'destination_phone'=>$destinationType==='whatsapp'&&$phone!==''?$phone:null,
          'destination_url'=>$destinationType==='url'?$destinationUrl:null,
          'prefill_message'=>trim((string)($_POST['prefill_message']??'Hi, I would like to make an appointment.'))?:'Hi, I would like to make an appointment.',
          'active'=>$active,'updated_at'=>date(DATE_ATOM)
        ];

        if($trackingLinkId!==''){
          v13_owner_write('tracking_links','id=eq.'.rawurlencode($trackingLinkId).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',$linkBody,'return=representation');
          flash('success','媒体内容 / Tracking Link 已修改；历史 First-Touch 顾客不会被重写。');
        }else{
          v13_owner_write('tracking_links','','POST',$linkBody);
          flash('success','媒体内容 / Tracking Link 已建立，可以直接复制或测试。');
        }
        return 'settings_marketing';
    }
    if ($action === 'archive_tracking_link_v1360') {
        $id=trim((string)($_POST['tracking_link_id']??'')); if($id==='') throw new RuntimeException('找不到 Tracking Link。');
        v13_owner_write('tracking_links','id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()),'PATCH',['active'=>false,'updated_at'=>date(DATE_ATOM)],'return=minimal');
        flash('success','Tracking Link 已停用；历史点击和归因仍然保留。'); return 'settings_marketing';
    }

    if ($action === 'preview_tunaipro_import_v132') {
        v132_prepare_tunaipro_preview();
        return 'data_import';
    }
    if ($action === 'confirm_tunaipro_import_v132') {
        v132_confirm_tunaipro_import();
        return 'data_import';
    }
    if ($action === 'import_transfer_v132') {
        v132_import_transfer_package();
        return 'data_transfer';
    }
    return null;
}

function v132_inventory_snapshot(): array {
    if (!v13_is_owner()) {
        $r=v1355_employee_product_inventory_payload()['inventory']??[];
        return is_array($r)?$r:[];
    }
    try {
        $r = v13_rpc('v132_inventory_snapshot',['p_store_id'=>v13_store_uuid()],v13_owner_token_required_all());
        if (is_array($r) && array_is_list($r)) return $r;
        return is_array($r) ? $r : [];
    } catch (Throwable $e) { return []; }
}

function v132_inventory_map(): array {
    $out=[];
    foreach(v132_inventory_snapshot() as $r) $out[(string)($r['product_id']??'')] = (float)($r['quantity']??0);
    return $out;
}

function v132_nav_active_page(string $page): string {
    if(in_array($page,['inventory','products','product_items','product_bundles','product_showcase'],true))return 'stock_hub';
    if(in_array($page,['settings_general','settings_roles','settings_whatsapp','settings_marketing','data_import','data_transfer'],true))return 'settings';
    if($page==='marketing_analytics')return 'analytics';
    if(in_array($page,['commission_monthly','commission_tiers'],true))return 'commission';
    if($page==='performance_employee')return 'performance';
    if($page==='training_course')return 'training';
    if($page==='kpi_employee')return 'kpi';
    if($page==='confirm')return 'orders';
    return $page;
}

function v132_titles(): array {
    return [
        'dashboard'=>'工作台','new_visit'=>'新建顾客订单','orders'=>'服务现场','customers'=>'顾客与会员','performance'=>'员工业绩',
        'employees'=>'员工管理','attendance'=>'员工打卡','order_history'=>'订单记录','analytics'=>'经营分析','marketing_analytics'=>'Marketing 来源分析','kpi'=>'KPI 管理','training'=>'培训中心','services'=>'服务项目',
        'stock_hub'=>'产品与库存','inventory'=>'库存管理','products'=>'销售产品','product_items'=>'销售产品','product_bundles'=>'产品配套','product_showcase'=>'顾客产品展示',
        'commission'=>'抽成管理','commission_monthly'=>'员工月度业绩抽成','commission_tiers'=>'业绩抽成阶梯',
        'branches'=>'分行管理','settings'=>'系统设置','settings_general'=>'门店通用设置','settings_roles'=>'员工权限角色','settings_whatsapp'=>'WhatsApp Business','settings_marketing'=>'媒体账号与归因',
        'data_import'=>'Tunaipro CSV 导入','data_transfer'=>'分行资料迁移','performance_employee'=>'员工业绩详情','kpi_employee'=>'员工 KPI','training_course'=>'培训课程','confirm'=>'顾客确认'
    ];
}

function v132_page_stock_hub(): void {
    $canInventory=has_any_permission(['inventory.manage']);
    $canProducts=has_any_permission(['products.view','products.manage']);
    $products=v13_product_rows(false);$stock=v132_inventory_map();
    $single=0;$active=0;$low=0;$units=0.0;
    foreach($products as $p){$single++;if(!empty($p['active']))$active++;$q=$stock[(string)$p['id']]??0;$units+=$q;if(!empty($p['stock_enabled'])&&$q<=(float)($p['reorder_level']??0))$low++;}
    $bundles=v1355_bundle_rows(false);
    ?>
    <div class="page-head"><div><span class="eyebrow">PRODUCT & INVENTORY</span><h1>产品与库存</h1><p>保留 v12.4.4 的分入口：库存、销售产品、产品配套和顾客展示；底层全部读取 Supabase。</p></div><a class="btn btn-light" href="index.php?page=product_showcase">顾客展示模式 →</a></div>
    <section class="stock-hub-grid">
      <?php if($canInventory):?><a class="card stock-hub-card stock-hub-inventory" href="index.php?page=inventory"><div class="stock-hub-card-icon"><?=ui_icon('box')?></div><div><span class="card-kicker">INVENTORY</span><h2>库存管理</h2><p>查看当前数量、补货线、成本并做进货／调整。</p><div class="stock-hub-mini-stats"><div><span>库存单位</span><strong><?=number_format($units,2)?></strong></div><div><span>低库存</span><strong><?=$low?></strong></div></div></div><strong>进入库存 →</strong></a><?php endif;?>
      <?php if($canProducts):?><a class="card stock-hub-card stock-hub-products" href="index.php?page=products"><div class="stock-hub-card-icon"><?=ui_icon('receipt')?></div><div><span class="card-kicker">SELLABLE PRODUCTS</span><h2>销售产品</h2><p>售价、本钱、条码、图片路径与销售抽成集中管理。</p><div class="stock-hub-mini-stats"><div><span>产品</span><strong><?=$single?></strong></div><div><span>启用</span><strong><?=$active?></strong></div></div></div><strong>查看产品 →</strong></a>
      <a class="card stock-hub-card stock-hub-bundles" href="index.php?page=product_bundles"><div class="stock-hub-card-icon"><?=ui_icon('award')?></div><div><span class="card-kicker">BUNDLES</span><h2>产品配套</h2><p>组合多个产品并设置每份扣除数量与销售价格。</p><div class="stock-hub-mini-stats"><div><span>配套</span><strong><?=count($bundles)?></strong></div><div><span>启用</span><strong><?=count(array_filter($bundles,fn($b)=>!empty($b['active'])))?></strong></div></div></div><strong>查看配套 →</strong></a><?php endif;?>
    </section>
    <?php
}

function v132_page_inventory(): void {
    $canEdit=v13_is_owner();
    $all=v13_product_rows(false);$products=array_values(array_filter($all,fn($p)=>!empty($p['stock_enabled'])));$stock=v132_inventory_map();
    $categories=v1353_product_categories(true);$filter=trim((string)($_GET['category_id']??''));
    $countBy=[];foreach($products as $p){$cid=(string)($p['category_id']??'');$countBy[$cid]=($countBy[$cid]??0)+1;}
    $initialVisibleCount=$filter!==''?(int)($countBy[$filter]??0):count($products);
    ?>
    <div class="page-head responsive-page-head"><div><a class="back-link" href="index.php?page=stock_hub">← 返回产品与库存</a><span class="eyebrow">INVENTORY · SUPABASE LEDGER</span><h1>库存管理</h1><p>像服务项目一样先建立分类文件夹，再管理分类里的库存货品。照片独立存到 Supabase Storage。</p></div><?php if($canEdit):?><div class="hero-actions"><button class="btn btn-light" type="button" data-v1350-modal-open="product-category">＋ 新建分类</button><button class="btn btn-primary" type="button" data-v1350-modal-open="inventory-item">＋ 增加库存</button></div><?php else:?><span class="badge badge-blue">员工只读</span><?php endif;?></div>
    <section class="v1350-folder-grid" data-inline-category-nav="inventory"><a class="v1350-folder-card <?=$filter===''?'active':''?>" href="index.php?page=inventory" data-inline-category-filter="" data-no-page-loader><div class="v1350-folder-icon"><?=ui_icon('box')?></div><div><strong>全部库存</strong><span><?=count($products)?> 项</span></div></a><?php foreach($categories as $cat):$cid=(string)$cat['id'];?><a class="v1350-folder-card <?=$filter===$cid?'active':''?>" href="index.php?page=inventory&category_id=<?=e($cid)?>" data-inline-category-filter="<?=e($cid)?>" data-no-page-loader><div class="v1350-folder-icon"><?=ui_icon('box')?></div><div><strong><?=e((string)$cat['name'])?></strong><span><?=intval($countBy[$cid]??0)?> 项</span></div></a><?php endforeach;?></section>
    <section class="v1350-inventory-grid" data-inline-category-content="inventory">
      <?php foreach($products as $p):$pcid=(string)($p['category_id']??'');$hidden=$filter!==''&&$pcid!==$filter;$q=(float)($stock[(string)$p['id']]??0);$low=$q<=(float)($p['reorder_level']??0);?>
      <article class="card v1350-inventory-card" data-inline-category-item="<?=e($pcid)?>" <?=$hidden?'hidden':''?>><div class="v1350-inventory-photo"><?php if(!empty($p['image_path'])):?><img src="<?=e((string)$p['image_path'])?>" alt="<?=e((string)$p['name'])?>" loading="lazy" decoding="async"><?php else:?><span><?=ui_icon('box')?></span><?php endif;?></div><div class="v1350-inventory-copy"><div class="v1350-row-title"><div><span class="card-kicker"><?=e((string)($p['sku']??''))?></span><h3><?=e((string)$p['name'])?></h3><small><?=e((string)($p['category']??'未分类'))?></small></div><span class="badge <?=$low?'badge-red':'badge-green'?>"><?=number_format($q,2)?> <?=e((string)($p['stock_unit']??'pcs'))?></span></div><div class="mini-metrics"><div><span>补货线</span><strong><?=number_format((float)($p['reorder_level']??0),2)?></strong></div><div><span>单位成本</span><strong><?=money($p['cost_price']??0)?></strong></div><div><span>库存成本</span><strong><?=money($q*(float)($p['cost_price']??0))?></strong></div></div><?php if($canEdit):?><div class="v1350-row-actions"><button class="btn btn-light btn-small" type="button" data-v1350-modal-open="inventory-stock" data-product_id="<?=e((string)$p['id'])?>" data-name="<?=e((string)$p['name'])?>" data-unit_cost="<?=e((string)($p['cost_price']??0))?>">进货 / 调整</button><button class="btn btn-light btn-small" type="button" data-v1350-modal-open="inventory-item" data-product_id="<?=e((string)$p['id'])?>" data-name="<?=e((string)$p['name'])?>" data-sku="<?=e((string)($p['sku']??''))?>" data-barcode="<?=e((string)($p['barcode']??''))?>" data-category_id="<?=e((string)($p['category_id']??''))?>" data-cost_price="<?=e((string)($p['cost_price']??0))?>" data-sale_price="<?=e((string)($p['sale_price']??0))?>" data-reorder_level="<?=e((string)($p['reorder_level']??0))?>" data-stock_unit="<?=e((string)($p['stock_unit']??'pcs'))?>" data-purpose="<?=e((string)($p['purpose']??''))?>" data-existing_image_path="<?=e((string)($p['image_path']??''))?>" data-retail_enabled="<?=!empty($p['retail_enabled'])?'1':'0'?>" data-active="<?=!empty($p['active'])?'1':'0'?>">修改</button><button class="btn btn-danger btn-small" type="button" data-v1350-modal-open="inventory-delete" data-product_id="<?=e((string)$p['id'])?>" data-name="<?=e((string)$p['name'])?>">删除</button></div><?php endif;?></div></article><?php endforeach;?><section class="card empty-state" data-inline-category-empty <?=$initialVisibleCount>0?'hidden':''?>><h3>这个分类还没有库存货品</h3><p>点击右上角「增加库存」。</p></section>
    </section>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="product-category"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">PRODUCT CATEGORY</span><h3>新建产品 / 库存分类</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_product_category_v1353"><input type="hidden" name="return_page" value="inventory"><div class="field"><label>分类名称 *</label><input class="input" name="name" required placeholder="例如 Hair Care / Colour / Retail"></div><div class="field"><label>说明</label><textarea class="textarea" name="description" rows="3"></textarea></div><div class="field"><label>排序</label><input class="input" type="number" name="sort_order" value="0"></div><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" checked><span>启用分类</span></label><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存分类</button></div></form></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="inventory-item"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">INVENTORY ITEM</span><h3>增加 / 修改库存货品</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" enctype="multipart/form-data" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_inventory_v1350"><input type="hidden" name="return_page" value="inventory"><input type="hidden" name="product_id" data-bind="product_id"><input type="hidden" name="existing_image_path" data-bind="existing_image_path"><div class="form-grid"><div class="field"><label>库存名称 *</label><input class="input" name="name" data-bind="name" required></div><div class="field"><label>SKU</label><input class="input" name="sku" data-bind="sku" placeholder="INV-001"></div><div class="field"><label>Barcode</label><input class="input" name="barcode" data-bind="barcode"></div><div class="field"><label>分类 *</label><select class="select" name="category_id" data-bind="category_id" required><option value="">选择分类</option><?php foreach($categories as $cat):?><option value="<?=e((string)$cat['id'])?>"><?=e((string)$cat['name'])?></option><?php endforeach;?></select></div><div class="field"><label>库存单位</label><input class="input" name="stock_unit" data-bind="stock_unit" placeholder="pcs / ml / g / bottle"></div><div class="field"><label>成本 RM</label><input class="input" type="number" step="0.01" min="0" name="cost_price" data-bind="cost_price" value="0"></div><div class="field"><label>售价 RM（如可零售）</label><input class="input" type="number" step="0.01" min="0" name="sale_price" data-bind="sale_price" value="0"></div><div class="field"><label>最低库存提醒</label><input class="input" type="number" step="0.001" min="0" name="reorder_level" data-bind="reorder_level" value="0"></div><div class="field span-2"><label>用途 / 说明</label><input class="input" name="purpose" data-bind="purpose"></div><div class="field span-2"><label>库存照片（JPG / PNG / WebP）</label><div class="v1351-media-upload" data-v1351-media-upload><div class="v1351-media-preview"><img hidden alt="库存照片预览" data-v1351-image-preview><span data-v1351-image-empty>尚未选择照片<br>选择后会在这里预览</span></div><div class="v1351-media-control"><strong>选择库存照片</strong><input class="input" type="file" name="image_file" accept="image/jpeg,image/png,image/webp" data-v1351-image-input><small>上传后先缩放并尽量转 WebP，再保存到 Supabase Storage <code>salonos-media</code>；数据库只保存 URL。</small></div></div></div><label class="confirm-checkbox"><input type="checkbox" name="retail_enabled" value="1" data-bind="retail_enabled"><span>同时作为销售产品</span></label><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" data-bind="active" checked><span>启用库存货品</span></label></div><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存库存</button></div></form></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="inventory-stock"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">STOCK MOVEMENT</span><h3>进货 / 调整库存</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="adjust_stock_v13"><input type="hidden" name="return_page" value="inventory"><input type="hidden" name="product_id" data-bind="product_id"><p>货品：<strong data-v1350-copy="name"></strong></p><div class="field"><label>数量变化</label><input class="input" type="number" step="0.001" name="quantity_delta" required placeholder="进货 +10 / 盘点 -2"></div><div class="field"><label>单位成本 RM</label><input class="input" type="number" step="0.01" min="0" name="unit_cost" data-bind="unit_cost" value="0"></div><div class="field"><label>备注</label><input class="input" name="notes" placeholder="进货 / 盘点调整"></div><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">确认库存流水</button></div></form></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="inventory-delete"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">DELETE INVENTORY</span><h3>删除 / 归档库存货品</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="archive_inventory_v1350"><input type="hidden" name="return_page" value="inventory"><input type="hidden" name="product_id" data-bind="product_id"><p>确定移除「<strong data-v1350-copy="name">这个库存货品</strong>」？历史库存流水不会删除。</p><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-danger">确认移除</button></div></form></section></div>
    <?php
}


function v132_page_products(): void {
    $canEdit=v13_is_owner();
    $showArchived=!empty($_GET['show_archived']);$all=v13_product_rows(false);
    $rows=array_values(array_filter($all,fn($p)=>$showArchived?(!empty($p['stock_enabled'])&&!empty($p['retail_enabled'])&&!empty($p['active'])?false:(!empty($p['retail_enabled'])||((float)($p['sale_price']??0)>0))):(!empty($p['retail_enabled'])&&!empty($p['active']))));
    $categories=v1353_product_categories(true);$filter=trim((string)($_GET['category_id']??''));$countBy=[];foreach($rows as $p){$cid=(string)($p['category_id']??'');$countBy[$cid]=($countBy[$cid]??0)+1;}$initialVisibleCount=$filter!==''?(int)($countBy[$filter]??0):count($rows);
    ?>
    <div class="page-head responsive-page-head"><div><a class="back-link" href="index.php?page=stock_hub">← 返回产品与库存</a><span class="eyebrow">SELLABLE PRODUCTS · SUPABASE</span><h1>销售产品</h1><p>销售产品不再把新增表单长期堆在页面；点击按钮才打开小浮窗。先选分类文件夹，再管理分类内产品。</p></div><div class="hero-actions"><a class="btn btn-light" href="index.php?page=products<?=$showArchived?'':'&show_archived=1'?>"><?=$showArchived?'返回可用产品':'查看已归档'?></a><?php if($canEdit):?><button class="btn btn-light" type="button" data-v1350-modal-open="product-category">＋ 新建分类</button><button class="btn btn-primary" type="button" data-v1350-modal-open="retail-product">＋ 增加产品</button><?php else:?><span class="badge badge-blue">员工只读</span><?php endif;?></div></div>
    <section class="v1350-folder-grid" data-inline-category-nav="products"><a class="v1350-folder-card <?=$filter===''?'active':''?>" href="index.php?page=products<?=$showArchived?'&show_archived=1':''?>" data-inline-category-filter="" data-no-page-loader><div class="v1350-folder-icon"><?=ui_icon('box')?></div><div><strong><?=$showArchived?'全部已归档':'全部销售产品'?></strong><span><?=count($rows)?> 项</span></div></a><?php foreach($categories as $cat):$cid=(string)$cat['id'];?><a class="v1350-folder-card <?=$filter===$cid?'active':''?>" href="index.php?page=products&category_id=<?=e($cid)?><?=$showArchived?'&show_archived=1':''?>" data-inline-category-filter="<?=e($cid)?>" data-no-page-loader><div class="v1350-folder-icon"><?=ui_icon('receipt')?></div><div><strong><?=e((string)$cat['name'])?></strong><span><?=intval($countBy[$cid]??0)?> 项</span></div></a><?php endforeach;?></section>
    <section class="product-catalog-grid" data-inline-category-content="products"><?php foreach($rows as $p):$pcid=(string)($p['category_id']??'');$hidden=$filter!==''&&$pcid!==$filter;?><article class="card product-catalog-card has-image" data-inline-category-item="<?=e($pcid)?>" <?=$hidden?'hidden':''?>><?php if(!empty($p['image_path'])):?><button class="product-catalog-image" type="button" data-catalog-image-view data-image-src="<?=e((string)$p['image_path'])?>" data-image-title="<?=e((string)$p['name'])?>"><img src="<?=e((string)$p['image_path'])?>" alt="<?=e((string)$p['name'])?>" loading="lazy" decoding="async"><span>点击放大</span></button><?php else:?><div class="product-catalog-image"><div class="catalog-image-placeholder"><?=ui_icon('box')?></div></div><?php endif;?><header><div><span class="card-kicker"><?=e((string)($p['sku']??''))?></span><h3><?=e((string)$p['name'])?></h3><small><?=e((string)($p['category']??'未分类'))?></small></div><span class="badge <?=!empty($p['active'])?'badge-green':'badge-gray'?>"><?=!empty($p['active'])?'销售中':'已归档'?></span></header><div class="product-catalog-metrics"><div><span>售价</span><strong><?=money($p['sale_price']??0)?></strong></div><div><span>本钱</span><strong><?=v13_is_owner()?money($p['cost_price']??0):'—'?></strong></div><div><span>抽成</span><strong><?=number_format((float)($p['default_commission_rate']??0),2)?>%</strong></div></div><?php if($canEdit):?><div class="v1350-row-actions"><button class="btn btn-light btn-small" type="button" data-v1350-modal-open="retail-product" data-product_id="<?=e((string)$p['id'])?>" data-existing_image_path="<?=e((string)($p['image_path']??''))?>" data-sku="<?=e((string)($p['sku']??''))?>" data-name="<?=e((string)$p['name'])?>" data-barcode="<?=e((string)($p['barcode']??''))?>" data-category_id="<?=e((string)($p['category_id']??''))?>" data-sale_price="<?=e((string)($p['sale_price']??0))?>" data-cost_price="<?=e((string)($p['cost_price']??0))?>" data-commission_rate="<?=e((string)($p['default_commission_rate']??0))?>" data-reorder_level="<?=e((string)($p['reorder_level']??0))?>" data-purpose="<?=e((string)($p['purpose']??''))?>" data-stock_unit="<?=e((string)($p['stock_unit']??'pcs'))?>" data-active="<?=!empty($p['active'])?'1':'0'?>">修改</button><button class="btn btn-danger-soft btn-small" type="button" data-v1350-modal-open="product-delete" data-product_id="<?=e((string)$p['id'])?>" data-product_name="<?=e((string)$p['name'])?>">删除</button></div><?php endif;?></article><?php endforeach;?><section class="card empty-state" data-inline-category-empty <?=$initialVisibleCount>0?'hidden':''?>><h3>这个分类还没有销售产品</h3><p>点击右上角「增加产品」。</p></section></section>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="product-category"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">PRODUCT CATEGORY</span><h3>新建产品分类</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_product_category_v1353"><input type="hidden" name="return_page" value="products"><div class="field"><label>分类名称 *</label><input class="input" name="name" required></div><div class="field"><label>说明</label><textarea class="textarea" name="description" rows="3"></textarea></div><div class="field"><label>排序</label><input class="input" type="number" name="sort_order" value="0"></div><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" checked><span>启用分类</span></label><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存分类</button></div></form></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="retail-product"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">SELLABLE PRODUCT</span><h3>增加 / 修改销售产品</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" enctype="multipart/form-data" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_product_v13"><input type="hidden" name="return_page" value="products"><input type="hidden" name="product_id" data-bind="product_id"><input type="hidden" name="existing_image_path" data-bind="existing_image_path"><div class="form-grid"><div class="field"><label>SKU / 产品编号</label><input class="input" name="sku" data-bind="sku" placeholder="PRD-001"></div><div class="field"><label>产品名称 *</label><input class="input" name="name" data-bind="name" required></div><div class="field"><label>条码</label><input class="input" name="barcode" data-bind="barcode"></div><div class="field"><label>产品分类 *</label><select class="select" name="category_id" data-bind="category_id" required><option value="">选择分类</option><?php foreach($categories as $cat):?><option value="<?=e((string)$cat['id'])?>"><?=e((string)$cat['name'])?></option><?php endforeach;?></select></div><div class="field"><label>售价 RM</label><input class="input" type="number" step="0.01" min="0" name="sale_price" data-bind="sale_price" value="0"></div><div class="field"><label>本钱 RM</label><input class="input" type="number" step="0.01" min="0" name="cost_price" data-bind="cost_price" value="0"></div><div class="field"><label>默认产品抽成 %</label><input class="input" type="number" step="0.01" min="0" max="100" name="commission_rate" data-bind="commission_rate" value="0"></div><div class="field"><label>补货线</label><input class="input" type="number" step="0.001" min="0" name="reorder_level" data-bind="reorder_level" value="0"></div><div class="field"><label>库存单位</label><input class="input" name="stock_unit" data-bind="stock_unit" placeholder="pcs / bottle"></div><div class="field span-2"><label>用途 / 产品简介</label><input class="input" name="purpose" data-bind="purpose"></div><div class="field span-2"><label>产品照片</label><div class="v1351-media-upload" data-v1351-media-upload><div class="v1351-media-preview"><img hidden alt="产品照片预览" data-v1351-image-preview><span data-v1351-image-empty>尚未选择照片</span></div><div class="v1351-media-control"><strong>选择产品照片</strong><input class="input" type="file" name="image_file" accept="image/jpeg,image/png,image/webp" data-v1351-image-input><small>压缩后存到 Supabase Storage；数据库只保存 URL。</small></div></div></div><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" data-bind="active" checked><span>启用销售产品</span></label></div><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存产品</button></div></form></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="product-delete"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">DELETE PRODUCT</span><h3>删除销售产品</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="delete_product_v1352"><input type="hidden" name="return_page" value="products"><input type="hidden" name="product_id" data-bind="product_id"><p>确定删除「<strong data-v1350-copy="product_name">这个产品</strong>」？有历史库存 / 销售记录会安全归档，不破坏旧账。</p><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-danger">确认删除</button></div></form></section></div>
    <?php
}


function v132_page_product_bundles(): void {
    $canEdit=v13_is_owner();
    $bundles=v1353_bundle_rows(true);$products=array_values(array_filter(v13_product_rows(true),fn($p)=>!empty($p['retail_enabled'])));$categories=v1353_product_categories(true);$filter=trim((string)($_GET['category_id']??''));
    $items=v1355_bundle_items();$itemsBy=[];foreach($items as $it)$itemsBy[(string)$it['bundle_id']][]=$it;
    $countBy=[];foreach($bundles as $b){$cid=(string)($b['category_id']??'');$countBy[$cid]=($countBy[$cid]??0)+1;}$initialVisibleCount=$filter!==''?(int)($countBy[$filter]??0):count($bundles);
    ?>
    <div class="page-head responsive-page-head"><div><a class="back-link" href="index.php?page=stock_hub">← 返回产品与库存</a><span class="eyebrow">PRODUCT BUNDLES · SUPABASE</span><h1>产品配套</h1><p>新增 / 修改配套使用小浮窗；分类文件夹与销售产品共用，方便柜台和顾客查找。</p></div><?php if($canEdit):?><div class="hero-actions"><button class="btn btn-light" type="button" data-v1350-modal-open="product-category">＋ 新建分类</button><button class="btn btn-primary" type="button" data-v1350-modal-open="bundle-item">＋ 增加配套</button></div><?php else:?><span class="badge badge-blue">员工只读</span><?php endif;?></div>
    <section class="v1350-folder-grid" data-inline-category-nav="product_bundles"><a class="v1350-folder-card <?=$filter===''?'active':''?>" href="index.php?page=product_bundles" data-inline-category-filter="" data-no-page-loader><div class="v1350-folder-icon"><?=ui_icon('award')?></div><div><strong>全部配套</strong><span><?=count($bundles)?> 项</span></div></a><?php foreach($categories as $cat):$cid=(string)$cat['id'];?><a class="v1350-folder-card <?=$filter===$cid?'active':''?>" href="index.php?page=product_bundles&category_id=<?=e($cid)?>" data-inline-category-filter="<?=e($cid)?>" data-no-page-loader><div class="v1350-folder-icon"><?=ui_icon('award')?></div><div><strong><?=e((string)$cat['name'])?></strong><span><?=intval($countBy[$cid]??0)?> 项</span></div></a><?php endforeach;?></section>
    <section class="product-catalog-grid" data-inline-category-content="product_bundles"><?php foreach($bundles as $b):$bcid=(string)($b['category_id']??'');$hidden=$filter!==''&&$bcid!==$filter;$bitems=$itemsBy[(string)$b['id']]??[];?><article class="card product-catalog-card has-image" data-inline-category-item="<?=e($bcid)?>" <?=$hidden?'hidden':''?>><?php if(!empty($b['image_path'])):?><button class="product-catalog-image" type="button" data-catalog-image-view data-image-src="<?=e((string)$b['image_path'])?>" data-image-title="<?=e((string)$b['name'])?>"><img src="<?=e((string)$b['image_path'])?>" alt="<?=e((string)$b['name'])?>" loading="lazy" decoding="async"></button><?php endif;?><header><div><span class="card-kicker"><?=e((string)($b['sku']??''))?></span><h3><?=e((string)$b['name'])?></h3><small><?=e((string)($b['category']??'未分类'))?> · <?=count($bitems)?> 个组成产品</small></div><span class="badge badge-green">启用</span></header><div class="product-catalog-metrics"><div><span>售价</span><strong><?=money($b['sale_price']??0)?></strong></div></div><?php if($canEdit):?><div class="v1350-row-actions"><button class="btn btn-light btn-small" type="button" data-v1350-modal-open="bundle-item" data-bundle_id="<?=e((string)$b['id'])?>" data-existing_image_path="<?=e((string)($b['image_path']??''))?>" data-sku="<?=e((string)($b['sku']??''))?>" data-name="<?=e((string)$b['name'])?>" data-category_id="<?=e((string)($b['category_id']??''))?>" data-sale_price="<?=e((string)($b['sale_price']??0))?>" data-active="<?=!empty($b['active'])?'1':'0'?>" data-items_json="<?=e(json_encode(array_values(array_map(fn($x)=>['product_id'=>(string)$x['product_id'],'quantity'=>(float)$x['quantity']],$bitems)),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?>">修改</button><button class="btn btn-danger-soft btn-small" type="button" data-v1350-modal-open="bundle-delete" data-bundle_id="<?=e((string)$b['id'])?>" data-bundle_name="<?=e((string)$b['name'])?>">删除</button></div><?php endif;?></article><?php endforeach;?><section class="card empty-state" data-inline-category-empty <?=$initialVisibleCount>0?'hidden':''?>><h3>这个分类还没有产品配套</h3></section></section>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="product-category"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">PRODUCT CATEGORY</span><h3>新建产品分类</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_product_category_v1353"><input type="hidden" name="return_page" value="product_bundles"><div class="field"><label>分类名称 *</label><input class="input" name="name" required></div><div class="field"><label>说明</label><textarea class="textarea" name="description" rows="3"></textarea></div><div class="field"><label>排序</label><input class="input" type="number" name="sort_order" value="0"></div><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" checked><span>启用分类</span></label><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存分类</button></div></form></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="bundle-item"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog"><div class="commission-modal-header"><div><span class="card-kicker">PRODUCT BUNDLE</span><h3>增加 / 修改产品配套</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" enctype="multipart/form-data" class="commission-modal-content" data-bundle-editor><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_bundle_v13"><input type="hidden" name="return_page" value="product_bundles"><input type="hidden" name="bundle_id" data-bind="bundle_id"><input type="hidden" name="existing_image_path" data-bind="existing_image_path"><input type="hidden" data-bind="items_json" data-bundle-items-json><div class="form-grid"><div class="field"><label>配套编号</label><input class="input" name="sku" data-bind="sku" placeholder="PKG-001"></div><div class="field"><label>配套名称 *</label><input class="input" name="name" data-bind="name" required></div><div class="field"><label>分类 *</label><select class="select" name="category_id" data-bind="category_id" required><option value="">选择分类</option><?php foreach($categories as $cat):?><option value="<?=e((string)$cat['id'])?>"><?=e((string)$cat['name'])?></option><?php endforeach;?></select></div><div class="field"><label>售价 RM</label><input class="input" type="number" step="0.01" min="0" name="sale_price" data-bind="sale_price" value="0"></div><div class="field span-2"><label>配套照片</label><div class="v1351-media-upload" data-v1351-media-upload><div class="v1351-media-preview"><img hidden alt="配套照片预览" data-v1351-image-preview><span data-v1351-image-empty>尚未选择照片</span></div><div class="v1351-media-control"><strong>选择配套照片</strong><input class="input" type="file" name="image_file" accept="image/jpeg,image/png,image/webp" data-v1351-image-input><small>照片压缩后存到 Supabase Storage。</small></div></div></div><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" data-bind="active" checked><span>启用配套</span></label></div><div class="section-head"><div><h3>配套内容</h3><p>选择组成的销售产品以及每套扣除数量。</p></div></div><div class="product-component-list" data-bundle-component-list><?php for($i=0;$i<6;$i++):?><div class="product-component-row"><div class="field"><label>产品 <?=$i+1?></label><select class="select" name="bundle_product_id[]" data-bundle-product><option value="">不使用</option><?php foreach($products as $p):?><option value="<?=e((string)$p['id'])?>"><?=e((string)$p['name'])?> · <?=money($p['sale_price']??0)?></option><?php endforeach;?></select></div><div class="field"><label>数量</label><input class="input" name="bundle_quantity[]" data-bundle-quantity type="number" min="0.01" step="0.01" value="1"></div></div><?php endfor;?></div><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存配套</button></div></form></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="bundle-delete"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">DELETE BUNDLE</span><h3>删除产品配套</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="delete_bundle_v1352"><input type="hidden" name="return_page" value="product_bundles"><input type="hidden" name="bundle_id" data-bind="bundle_id"><p>确定删除「<strong data-v1350-copy="bundle_name">这个配套</strong>」？配套定义会从可用列表移除。</p><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-danger">确认删除</button></div></form></section></div>
    <?php
}


function v132_page_product_showcase(): void {
    $q=mb_strtolower(trim((string)($_GET['q']??'')));$rows=v13_product_rows(true);$stock=v132_inventory_map();
    if($q!=='')$rows=array_values(array_filter($rows,fn($p)=>str_contains(mb_strtolower((string)($p['name'].' '.($p['category']??'').' '.($p['sku']??''))),$q)));
    ?>
    <div class="page-head product-showcase-head"><div><a class="back-link" href="index.php?page=stock_hub">← 返回产品与库存</a><span class="eyebrow">CUSTOMER PRODUCT SHOWCASE</span><h1>顾客产品展示</h1><p>不显示产品本钱，适合把屏幕转向顾客介绍产品。</p></div><form class="showcase-search"><input type="hidden" name="page" value="product_showcase"><input class="input" name="q" value="<?=e((string)($_GET['q']??''))?>" placeholder="搜索产品名称或分类"><button class="btn btn-primary">搜索</button></form></div>
    <section class="customer-showcase-grid"><?php foreach($rows as $p):$qty=(float)($stock[(string)$p['id']]??0);?><article class="customer-product-card"><?php if(!empty($p['image_path'])):?><button class="customer-product-image" type="button" data-catalog-image-view data-image-src="<?=e((string)$p['image_path'])?>" data-image-title="<?=e((string)$p['name'])?>" data-image-subtitle="<?=e(money($p['sale_price']??0))?>"><img src="<?=e((string)$p['image_path'])?>" alt="<?=e((string)$p['name'])?>"></button><?php else:?><div class="customer-product-image"><div class="catalog-image-placeholder"><?=ui_icon('box')?><strong>产品图片准备中</strong></div></div><?php endif;?><div class="customer-product-content"><span class="card-kicker"><?=e((string)($p['category']??'产品'))?></span><h2><?=e((string)$p['name'])?></h2><p><?=e((string)($p['purpose']??'欢迎向员工了解产品详情。'))?></p><footer><strong><?=money($p['sale_price']??0)?></strong><span class="badge <?=$qty>0?'badge-green':'badge-gray'?>"><?=$qty>0?'现货可售':'暂时缺货'?></span></footer></div></article><?php endforeach;?><?php if(!$rows):?><section class="card empty-state"><h3>没有找到产品</h3></section><?php endif;?></section>
    <?php
}

function v132_page_settings_hub(): void {
    $rp=v132_role_permissions_settings();$identity=salonos_supabase_identity()??[];$stores=is_array($identity['stores']??null)?$identity['stores']:[];$lang=v1361051_effective_ui_language();
    ?>
    <div class="page-head"><div><span class="eyebrow">SYSTEM SETTINGS</span><h1>系统设置</h1><p>老板可以按职位逐项开放设置模块；每个用户也可以只修改自己的界面语言，不会影响其他人的 SalonOS。</p></div></div>
    <section class="card v1361051-personal-language"><div class="card-head"><div><span class="card-kicker">MY INTERFACE</span><h3>我的界面语言</h3><p>这里只改变你当前账号看到的 UI。不会修改其他员工、老板或整个门店的界面语言。</p></div><span class="badge badge-gold"><?=$lang==='en'?'English':'中文'?></span></div><form method="post" class="card-body v1361051-language-form"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_personal_ui_language_v1361051"><input type="hidden" name="return_page" value="settings"><label class="field"><span>Interface Language / 界面语言</span><select class="select" name="ui_language"><option value="zh" <?=$lang==='zh'?'selected':''?>>中文</option><option value="en" <?=$lang==='en'?'selected':''?>>English</option></select></label><button class="btn btn-primary">应用到我的账号</button></form></section>
    <section class="settings-entry-grid v1361051-settings-grid">
      <?php if(v13_is_owner()||has_permission('settings.general.view')):?><a class="settings-entry-card" href="index.php?page=settings_general"><div class="settings-entry-icon"><?=ui_icon('settings')?></div><div><span>GENERAL SETTINGS</span><h2>门店通用设置</h2><p>门店默认语言、品牌、时区、币种、单据编号和设备登录期限。</p><small>Organization defaults</small></div><strong>查看设置 →</strong></a><?php endif;?>
      <?php if(v13_is_owner()||has_permission('settings.roles.view')):?><a class="settings-entry-card" href="index.php?page=settings_roles"><div class="settings-entry-icon"><?=ui_icon('employee')?></div><div><span>ROLE PERMISSIONS</span><h2>员工职位权限</h2><p>按职位控制员工可以看到和使用的功能。</p><small><?=count(v132_role_definitions())?> 个职位</small></div><strong>查看职位 →</strong></a><?php endif;?>
      <?php if(v13_is_owner()||has_permission('settings.whatsapp.view')):?><a class="settings-entry-card" href="index.php?page=settings_whatsapp"><div class="settings-entry-icon">WA</div><div><span>WHATSAPP BUSINESS</span><h2>WhatsApp Business</h2><p>Cloud API、Webhook、AI 自动回复与预约提醒。</p><small>敏感凭据仅老板可管理</small></div><strong>查看 →</strong></a><?php endif;?>
      <?php if(v13_is_owner()||has_permission('settings.marketing.view')):?><a class="settings-entry-card" href="index.php?page=settings_marketing"><div class="settings-entry-icon">MKT</div><div><span>MEDIA ATTRIBUTION</span><h2>媒体账号与 Tracking</h2><p>Instagram / TikTok / XHS / Google / QR 来源与 Tracking Link。</p></div><strong>查看 →</strong></a><?php endif;?>
      <?php if(v13_is_owner()||has_permission('settings.data_import.view')):?><a class="settings-entry-card" href="index.php?page=data_import"><div class="settings-entry-icon"><?=ui_icon('receipt')?></div><div><span>DATA IMPORT</span><h2>Tunaipro CSV 导入</h2><p>产品、配套、服务与会员资料导入中心。</p></div><strong>查看 →</strong></a><?php endif;?>
      <?php if(v13_is_owner()||has_permission('settings.data_transfer.view')):?><a class="settings-entry-card" href="index.php?page=data_transfer"><div class="settings-entry-icon"><?=ui_icon('branch')?></div><div><span>BRANCH DATA TRANSFER</span><h2>分行资料迁移</h2><p>分行之间的 SalonOS JSON 资料包迁移。</p></div><strong>查看 →</strong></a><?php endif;?>
      <?php if(v13_is_owner()||has_any_permission(['branches.view','branches.manage'])):?><a class="settings-entry-card" href="index.php?page=branches"><div class="settings-entry-icon"><?=ui_icon('branch')?></div><div><span>MULTI BRANCH</span><h2>分行管理</h2><p>查看分行订阅并进入分行工作区。</p><small><?=count($stores)?> 家分行</small></div><strong>查看 →</strong></a><?php endif;?>
    </section>
    <?php if(v13_is_owner()||has_permission('settings.diagnostics.view')):?><section class="card settings-database-isolation" style="margin-top:18px"><div class="card-head"><div><span class="card-kicker">SYSTEM DIAGNOSTICS</span><h3>系统自检</h3></div></div><div class="card-body"><p class="muted">检查当前 SalonOS 与 Supabase 的运行状态。</p><a class="btn btn-light" href="system-test.php">运行完整系统自检 →</a></div></section><?php endif;?>
    <?php
}

function v132_page_settings_general(): void {$g=v132_general_settings();$owner=v13_is_owner();?>
    <div class="page-head"><div><a class="back-link" href="index.php?page=settings">← 返回系统设置</a><span class="eyebrow">GENERAL SETTINGS</span><h1>门店通用设置</h1><p>这里是 Organization 默认规则。每个用户可以在「系统设置」首页另外选择自己的界面语言。</p></div></div>
    <section class="card settings-form-card"><?php if($owner):?><form method="post" class="card-body"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_general_settings"><input type="hidden" name="return_page" value="settings_general"><?php else:?><div class="card-body"><?php endif;?><div class="form-grid"><div class="field"><label>品牌／系统名称</label><input class="input" name="business_name" value="<?=e((string)($g['business_name']??system_setting('business_name','SalonOS')))?>" <?=$owner?'':'readonly'?>></div><div class="field"><label>门店默认界面语言</label><select class="select" name="system_language" <?=$owner?'':'disabled'?>><option value="zh" <?=($g['language']??'zh')==='zh'?'selected':''?>>中文</option><option value="en" <?=($g['language']??'')==='en'?'selected':''?>>English</option></select><small>只作为没有个人语言偏好的账号默认值。</small></div><div class="field"><label>时区</label><input class="input" value="<?=e((string)($g['timezone']??'Asia/Kuala_Lumpur'))?>" readonly></div><div class="field"><label>币种</label><input class="input" value="<?=e((string)($g['currency']??'MYR'))?>" readonly></div><div class="field"><label>单据编号前缀</label><input class="input" name="invoice_prefix" maxlength="10" value="<?=e((string)($g['receipt_prefix']??'INV'))?>" <?=$owner?'':'readonly'?>></div><div class="field"><label>员工设备记住登录天数</label><input class="input" type="number" min="1" max="365" name="device_remember_days" value="<?=intval($g['device_remember_days']??30)?>" <?=$owner?'':'readonly'?>></div></div><?php if($owner):?><div class="form-actions"><button class="btn btn-primary">保存门店默认设置</button></div></form><?php else:?><div class="alert alert-info">你拥有查看权限；Organization 默认规则只能由老板修改。你的个人语言请回到系统设置首页修改。</div></div><?php endif;?></section>
<?php }

function v132_permission_catalog(): array {return [
 '门店运营'=>[
   'dashboard.view'=>'查看工作台',
   'visits.create'=>'建立顾客订单 / Walk-in',
   'orders.view'=>'查看服务现场与自己的预约',
   'orders.manage'=>'修改订单进度 / 员工分配',
   'appointments.manage'=>'确认预约到店 / 处理预约',
   'checkout.manage'=>'柜台结账与待结账产品',
 ],
 '员工打卡'=>[
   'attendance.scan'=>'员工扫码上班 / 下班',
   'attendance.team.view'=>'查看当前分行员工到店状态',
   'attendance.station'=>'打开柜台动态打卡二维码',
   'attendance.manual'=>'替员工手动上班 / 下班打卡',
 ],
 '顾客与会员'=>[
   'customers.view'=>'查看顾客与会员资料',
   'customers.manage'=>'修改顾客 / 建立会员',
   'member.wallet.manage'=>'会员储值 / 充值操作',
   'member.products.sell'=>'销售会员产品 / 配套',
 ],
 '员工与成长'=>[
   'performance.view'=>'查看员工业绩',
   'kpi.view'=>'查看 KPI',
   'kpi.manage'=>'建立 / 修改 / 审核 KPI',
   'training.view'=>'查看培训中心',
   'training.manage'=>'建立 / 修改培训课程',
   'employees.manage'=>'管理员工资料 / 状态',
 ],
 '服务、产品与库存'=>[
   'services.view'=>'查看服务项目',
   'services.manage'=>'建立 / 修改 / 删除服务项目',
   'products.view'=>'查看销售产品与配套',
   'products.manage'=>'建立 / 修改 / 删除销售产品与配套',
   'inventory.view'=>'查看库存数量与低库存',
   'inventory.manage'=>'进货 / 调整 / 管理库存',
 ],
 '经营与财务'=>[
   'order_history.view'=>'查看订单记录',
   'analytics.view'=>'查看经营分析',
   'commission.view'=>'查看抽成结果',
   'commission.manage'=>'设置抽成规则 / 阶梯 / 月度调整',
   'reports.export'=>'导出报表',
   'branches.view'=>'查看分行管理',
   'branches.manage'=>'建立 / 管理分行',
 ],
 '系统与设置'=>[
   'settings.view'=>'查看系统设置入口',
   'settings.general.view'=>'查看门店通用设置',
   'settings.roles.view'=>'查看员工职位权限',
   'settings.whatsapp.view'=>'查看 WhatsApp Business 设置入口',
   'settings.marketing.view'=>'查看媒体账号与 Tracking',
   'settings.data_import.view'=>'查看 Tunaipro 数据导入',
   'settings.data_transfer.view'=>'查看分行资料迁移',
   'settings.diagnostics.view'=>'查看系统自检入口',
 ],
];}
function v132_page_settings_roles(): void {
    $roles=v132_role_definitions();
    $saved=v132_role_permissions_settings();
    $catalog=v132_permission_catalog();
    $canEdit=v13_is_owner(); ?>
    <div class="page-head responsive-page-head"><div><a class="back-link" href="index.php?page=settings">← 返回系统设置</a><span class="eyebrow">ROLE PERMISSIONS</span><h1>员工职位权限</h1><p>这里只显示员工职位。点击一个职位才会打开权限浮窗，老板可以在浮窗里查看和修改该职位能使用的功能。</p></div><?php if($canEdit):?><button class="btn btn-primary" type="button" data-v1350-modal-open="role-create">＋ 增加职位</button><?php endif;?></div>
    <section class="v1361051-role-list">
      <?php foreach($roles as $role=>$meta):$label=(string)$meta['label'];$assigned=is_array($saved[$role]??null)?$saved[$role]:v132_default_permissions($role);$custom=empty($meta['system']);$count=in_array('*',$assigned,true)?'全部':(string)count($assigned);?>
        <button class="card v1361051-role-row" type="button" data-v1350-modal-open="role-edit-<?=e($role)?>">
          <div class="v1361051-role-main"><span class="v1361051-role-icon"><?=ui_icon('employee')?></span><div><strong><?=e($label)?></strong><small><?=e($custom?'自定义职位':'系统职位')?> · <?=e($count)?> 项权限</small></div></div><span class="v1361051-role-open">查看 / 修改 →</span>
        </button>
      <?php endforeach;?>
    </section>

    <?php foreach($roles as $role=>$meta):$label=(string)$meta['label'];$assigned=is_array($saved[$role]??null)?$saved[$role]:v132_default_permissions($role);$custom=empty($meta['system']);?>
    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="role-edit-<?=e($role)?>"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1361051-role-modal"><div class="commission-modal-header"><div><span class="card-kicker">ROLE PERMISSIONS</span><h3><?=e($label)?></h3><p><?=e($role)?></p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content v1361051-role-form"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_single_role_permissions_v1361051"><input type="hidden" name="return_page" value="settings_roles"><input type="hidden" name="role_code" value="<?=e($role)?>">
      <?php if($role==='manager'):?><label class="permission-check v1361051-all-access"><input type="checkbox" name="permissions[]" value="*" <?=in_array('*',$assigned,true)?'checked':''?> <?=$canEdit?'':'disabled'?>> <span><strong>全部管理权限</strong><small>开启后，这个职位会拥有所有现有与未来功能权限。</small></span></label><?php endif;?>
      <div class="permission-role-groups">
      <?php foreach($catalog as $group=>$items):?><section class="permission-role-group"><div class="permission-role-group-head"><strong><?=e($group)?></strong><small><?=count($items)?> 项权限</small></div><div class="permission-check-grid"><?php foreach($items as $code=>$name):?><label class="permission-check"><input type="checkbox" name="permissions[]" value="<?=e($code)?>" <?=in_array($code,$assigned,true)||in_array('*',$assigned,true)?'checked':''?> <?=$canEdit?'':'disabled'?>> <span><strong><?=e($name)?></strong><small><?=e($code)?></small></span></label><?php endforeach;?></div></section><?php endforeach;?>
      </div>
      <div class="form-actions v1361051-role-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>关闭</button><?php if($canEdit):?><button class="btn btn-primary">保存这个职位权限</button><?php endif;?></div>
    </form><?php if($canEdit):?><div class="v1361051-role-delete-zone"><button class="btn btn-danger-soft btn-small" type="button" data-v1350-modal-close data-v1350-modal-open="role-delete" data-role_code="<?=e($role)?>" data-role_label="<?=e($label)?>">删除职位</button></div><?php endif;?></section></div>
    <?php endforeach;?>

    <?php if($canEdit):?>
    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="role-create"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">CUSTOM ROLE</span><h3>增加职位</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="add_role_v1352"><input type="hidden" name="return_page" value="settings_roles"><div class="field"><label>职位名称 *</label><input class="input" name="role_label" required placeholder="例如 Senior Stylist / Supervisor / Cashier"></div><p class="field-help">建立后会出现在员工资料的职位选择中，再点击这个职位设置权限。</p><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">建立职位</button></div></form></section></div>
    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="role-delete"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">DELETE ROLE</span><h3>删除职位</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="delete_role_v1352"><input type="hidden" name="return_page" value="settings_roles"><input type="hidden" name="role_code" data-bind="role_code"><p>确定删除「<strong data-v1350-copy="role_label">这个职位</strong>」？使用这个职位的员工会自动转移到另一个仍存在的职位。</p><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-danger">确认删除职位</button></div></form></section></div>
    <?php endif;?>
<?php }

function v132_page_settings_whatsapp(): void {
    if(!v13_is_owner()){ ?>
      <div class="page-head"><div><a class="back-link" href="index.php?page=settings">← 返回系统设置</a><span class="eyebrow">WHATSAPP BUSINESS</span><h1>WhatsApp Business</h1><p>老板已经允许你的职位看到这个设置入口。</p></div></div>
      <section class="card"><div class="card-body"><div class="alert alert-info">为了保护门店的 Meta App Secret、Access Token、Phone Number ID 与 Webhook 凭据，员工账号不会显示或修改敏感连接资料。连接与 Token 仍只由老板账号管理。</div></div></section>
    <?php return; }
    $w=v1361_whatsapp_effective_settings();
    $c=v1361_whatsapp_connection();
    $org=v13_org_uuid();
    $store=v13_store_uuid();
    $conversations=[];$messages=[];$queue=[];
    try{$conversations=v13_owner_rows('whatsapp_conversations','select=id&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&limit=5000');}catch(Throwable $e){}
    try{$messages=v13_owner_rows('whatsapp_messages','select=id&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&direction=eq.inbound&limit=5000');}catch(Throwable $e){}
    try{$queue=v13_owner_rows('whatsapp_ai_queue','select=id,status&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&limit=5000');}catch(Throwable $e){}

    $queued=count(array_filter($queue,fn($x)=>($x['status']??'')==='queued'));
    $webhook=v1361_whatsapp_webhook_url();
    $status=(string)($c['connection_status']??'configured');
    $esConfig=v136635_whatsapp_embedded_signup_public_config();
    $esReady=!empty($esConfig['ready']);
    $esMethod=(string)($w['onboarding_method']??'manual');
    $esStatus=(string)($w['embedded_signup_status']??'not_started');
    $manualStatus=v136636_whatsapp_manual_status();
    $manualSetup=(isset($_SESSION['v136636_manual_webhook_setup'])&&is_array($_SESSION['v136636_manual_webhook_setup']))?$_SESSION['v136636_manual_webhook_setup']:[];
    unset($_SESSION['v136636_manual_webhook_setup']);
    $manualState=(string)($manualStatus['manual_setup_status']??'not_started');
    $manualLive=$esMethod==='manual'&&$manualState==='live';
    $autoReplyOn=!isset($w['auto_reply_enabled'])||!empty($w['auto_reply_enabled']);
    $reminderOn=!isset($w['reminder_enabled'])||!empty($w['reminder_enabled']);
    $connectionOn=!empty($w['enabled'])||$status==='live'||$manualLive||($esMethod==='embedded_signup'&&$esStatus==='connected');
    $hasConnection=$status==='live'||!empty($w['phone_number_id'])||!empty($manualStatus['configured'])||($esMethod==='embedded_signup'&&$esStatus==='connected');
    $displayPhone=(string)($manualStatus['display_phone_number']??$w['public_phone']??$c['display_phone_number']??'');
    $connectionLabel=$esMethod==='embedded_signup'?'Meta Quick Connect':'Manual Cloud API';
    $initialManualStep=!empty($manualSetup)?5:1;
    ?>

    <div class="page-head responsive-page-head wa37-page-head">
      <div>
        <a class="back-link" href="index.php?page=settings">← 返回系统设置</a>
        <span class="eyebrow">WHATSAPP BUSINESS</span>
        <h1>连接你的 WhatsApp</h1>
        <p>把门店 WhatsApp 接入 SalonOS。顾客发消息后，系统可以自动处理预约、改期、取消与提醒。</p>
      </div>
      <button class="btn btn-light" type="button" data-v1350-modal-open="wa37-start-guide">查看新手教程</button>
    </div>

    <section class="card wa37-status-hero <?=$status==='live'?'is-live':'is-pending'?>">
      <div class="wa37-status-main">
        <div class="wa37-status-icon">WA</div>
        <div class="wa37-status-copy">
          <span class="card-kicker">CURRENT CONNECTION</span>
          <div class="wa37-status-title-row">
            <h2><?=$hasConnection?e($displayPhone!==''?$displayPhone:'WhatsApp 已连接'):'尚未连接 WhatsApp'?></h2>
            <span class="badge <?=$status==='live'?'badge-green':'badge-gray'?>"><?=$status==='live'?'CONNECTED':'SETUP NEEDED'?></span>
          </div>
          <p><?=$status==='live'?'SalonOS 已收到 Meta Webhook，可以继续使用下面的自动回复与提醒设置。':'先选择一种连接方式。现在建议使用 Manual Cloud API Setup。'?></p>
        </div>
      </div>
      <div class="wa37-health-grid">
        <div><span>AI 自动回复</span><strong class="<?=$autoReplyOn?'is-good':''?>"><?=$autoReplyOn?'已开启':'已关闭'?></strong></div>
        <div><span>Webhook</span><strong class="<?=$status==='live'?'is-good':''?>"><?=$status==='live'?'正常':'等待连接'?></strong></div>
        <div><span>连接方式</span><strong><?=e($hasConnection?$connectionLabel:'—')?></strong></div>
        <div><span>最后收到消息</span><strong><?=!empty($c['last_webhook_at'])?e(app_date((string)$c['last_webhook_at'],true)):'—'?></strong></div>
      </div>
      <div class="wa37-status-actions">
        <button class="btn btn-primary" type="button" data-wa37-scroll="connection-methods"><?=$hasConnection?'管理连接':'开始连接'?></button>
        <?php if($hasConnection):?><button class="btn btn-light" type="button" data-wa37-scroll="automation-settings">自动回复与提醒</button><?php endif;?>
      </div>
    </section>

    <section class="wa37-section" id="connection-methods">
      <div class="wa37-section-head">
        <div><span class="card-kicker">STEP 1</span><h2>选择连接方式</h2><p>不懂技术也没关系。现在有一种可直接使用的方法；以后完成 Meta 企业验证后会开放一键连接。</p></div>
      </div>
      <div class="wa37-method-grid">
        <article class="wa37-method-card is-recommended">
          <div class="wa37-method-top"><span class="wa37-method-number">1</span><span class="badge badge-green">AVAILABLE NOW</span></div>
          <h3>Manual Setup</h3>
          <p>适合现在使用。客户用自己的 Meta App 与 Cloud API 号码，SalonOS 会帮忙验证资料。</p>
          <ul><li>客户自己的 WhatsApp Cloud API</li><li>客户自己的 Token 与 App Secret</li><li>每家门店独立连接，不会串号</li></ul>
          <div class="wa37-method-actions">
            <button class="btn btn-primary" type="button" data-wa37-open-manual>开始 Manual Setup</button>
            <button class="btn btn-light" type="button" data-v1350-modal-open="wa37-manual-overview">这是什么？</button>
          </div>
        </article>
        <article class="wa37-method-card <?=$esReady?'is-ready':'is-disabled'?>">
          <div class="wa37-method-top"><span class="wa37-method-number">2</span><span class="badge <?=$esReady?'badge-green':'badge-gray'?>"><?=$esReady?'AVAILABLE':'COMING LATER'?></span></div>
          <h3>Connect with Meta</h3>
          <p>以后推荐的方法。老板只要在 Meta 官方窗口授权，不用自己找 Token、WABA 或 Phone Number ID。</p>
          <ul><li>最适合正式 SaaS 客户</li><li>可减少人工设置</li><li>需要完成 Meta Tech Provider / 企业验证</li></ul>
          <?php if($esReady):?>
            <div class="wa37-method-actions"><button class="btn btn-primary" type="button" data-wa-es-launch="business_app">连接现有号码</button><button class="btn btn-light" type="button" data-wa-es-launch="standard">连接 Cloud API 号码</button></div>
          <?php else:?>
            <div class="wa37-method-actions"><button class="btn btn-light" type="button" disabled>暂未开放</button><button class="btn btn-light" type="button" data-v1350-modal-open="wa37-auto-connect-info">为什么不能用？</button></div>
          <?php endif;?>
        </article>
      </div>
      <?php if($esReady):?><div class="alert alert-info wa37-es-status" data-wa-es-status><strong>Connect with Meta 已准备好。</strong><br>连接时会打开 Meta 官方授权窗口。</div><?php endif;?>
    </section>

    <section class="card wa37-wizard-shell" data-wa37-manual-panel <?=$hasConnection&&empty($manualSetup)?'hidden':''?>>
      <div class="wa37-wizard-head">
        <div><span class="card-kicker">MANUAL CLOUD API SETUP</span><h2>跟着 5 步完成连接</h2><p>每一步只处理一件事。看不懂某个资料时，直接点「查看教程」。</p></div>
        <?php if($hasConnection):?><button class="btn btn-light btn-small" type="button" data-wa37-close-manual>收起</button><?php endif;?>
      </div>

      <div class="wa37-stepper" data-wa37-stepper>
        <?php foreach([1=>'准备资料',2=>'填写编号',3=>'安全凭据',4=>'确认连接',5=>'设置 Webhook'] as $n=>$label):?>
          <button type="button" data-wa37-step-dot="<?=$n?>" class="<?=$n===$initialManualStep?'is-active':''?>"><span><?=$n?></span><small><?=e($label)?></small></button>
        <?php endforeach;?>
      </div>

      <?php if(!empty($manualStatus['error'])):?><div class="alert alert-warning wa37-inline-alert"><strong>Manual Connect 后端还没准备好。</strong><br>请先完成 v13.6.10.36 的 SQL 与 <code>whatsapp-manual-connect</code> Edge Function。</div><?php endif;?>

      <form method="post" autocomplete="off" data-wa37-manual-form data-initial-step="<?=$initialManualStep?>">
        <input type="hidden" name="csrf" value="<?=csrf_token()?>">
        <input type="hidden" name="action" value="connect_whatsapp_manual_v136636">
        <input type="hidden" name="return_page" value="settings_whatsapp">

        <section class="wa37-step-panel" data-wa37-step="1" <?=$initialManualStep!==1?'hidden':''?>>
          <div class="wa37-step-copy"><span>STEP 1 OF 5</span><h3>先准备 5 项资料</h3><p>这些资料全部来自客户自己的 Meta。不要把 Facebook 密码交给任何人。</p></div>
          <div class="wa37-checklist">
            <div><b>01</b><span><strong>Meta App ID</strong><small>应用的公开编号</small></span></div>
            <div><b>02</b><span><strong>Meta App Secret</strong><small>只由客户本人填写</small></span></div>
            <div><b>03</b><span><strong>WABA ID</strong><small>WhatsApp Business Account ID</small></span></div>
            <div><b>04</b><span><strong>Phone Number ID</strong><small>不是电话号码本身</small></span></div>
            <div><b>05</b><span><strong>System User Token</strong><small>正式营业建议使用长期 Token</small></span></div>
          </div>
          <div class="wa37-help-banner"><div><strong>不知道去哪里找？</strong><span>打开教程会逐步告诉你点击 Meta 的哪个菜单。</span></div><button class="btn btn-light" type="button" data-v1350-modal-open="wa37-prepare-guide">查看准备资料教程</button></div>
          <div class="wa37-step-actions"><span></span><button class="btn btn-primary" type="button" data-wa37-next="2">我准备好了 →</button></div>
        </section>

        <section class="wa37-step-panel" data-wa37-step="2" hidden>
          <div class="wa37-step-copy"><span>STEP 2 OF 5</span><h3>填写账号编号</h3><p>这一页只有编号，没有密码。可以先从 Meta API Setup 页面找到 WABA 与 Phone Number ID。</p></div>
          <div class="form-grid wa37-form-grid">
            <div class="field"><div class="wa37-label-row"><label>Meta App ID *</label><button type="button" data-v1350-modal-open="wa37-appid-guide">在哪里找？</button></div><input class="input" name="wa_manual_app_id" inputmode="numeric" required value="<?=e((string)($manualStatus['meta_app_id']??''))?>" placeholder="例如 123456789012345"></div>
            <div class="field"><div class="wa37-label-row"><label>WABA ID *</label><button type="button" data-v1350-modal-open="wa37-waba-guide">在哪里找？</button></div><input class="input" name="wa_manual_waba_id" inputmode="numeric" required value="<?=e((string)($manualStatus['business_account_id']??$w['business_account_id']??''))?>" placeholder="WhatsApp Business Account ID"></div>
            <div class="field"><div class="wa37-label-row"><label>Phone Number ID *</label><button type="button" data-v1350-modal-open="wa37-waba-guide">在哪里找？</button></div><input class="input" name="wa_manual_phone_number_id" inputmode="numeric" required value="<?=e((string)($manualStatus['phone_number_id']??$w['phone_number_id']??''))?>" placeholder="Phone Number ID"></div>
            <div class="field"><label>WhatsApp 对外号码（可选）</label><input class="input" name="wa_manual_public_phone" inputmode="tel" value="<?=e((string)($manualStatus['display_phone_number']??$w['public_phone']??''))?>" placeholder="例如 60123456789"><small class="field-help">这是顾客平时看到的电话号码；没有也可以先留空。</small></div>
          </div>
          <div class="wa37-step-actions"><button class="btn btn-light" type="button" data-wa37-prev="1">← 上一步</button><button class="btn btn-primary" type="button" data-wa37-next="3">下一步 →</button></div>
        </section>

        <section class="wa37-step-panel" data-wa37-step="3" hidden>
          <div class="wa37-step-copy"><span>STEP 3 OF 5</span><h3>填写安全凭据</h3><p>这两项相当于钥匙。SalonOS 不会把内容显示回页面，也不会要求客户提供 Facebook 密码。</p></div>
          <div class="wa37-security-note"><strong>安全提醒</strong><span>App Secret 与 Access Token 请由客户本人在这里输入。正式营业不要长期使用 API Setup 的 Temporary Token。</span></div>
          <div class="form-grid wa37-form-grid">
            <div class="field span-2"><div class="wa37-label-row"><label>Meta App Secret *</label><button type="button" data-v1350-modal-open="wa37-appsecret-guide">查看教程</button></div><input class="input" type="password" name="wa_manual_app_secret" required value="" autocomplete="new-password" placeholder="粘贴客户自己的 App Secret"><small class="field-help">保存到 service-role-only secrets table；浏览器不会再次读取。</small></div>
            <div class="field span-2"><div class="wa37-label-row"><label>System User Access Token *</label><button type="button" data-v1350-modal-open="wa37-token-guide">查看生成教程</button></div><input class="input" type="password" name="wa_manual_access_token" required value="" autocomplete="new-password" placeholder="建议使用 System User Token"><small class="field-help">SalonOS 会先向 Meta 验证，确认 Token、App、WABA 与 Phone Number ID 对得上才保存。</small></div>
          </div>
          <div class="wa37-step-actions"><button class="btn btn-light" type="button" data-wa37-prev="2">← 上一步</button><button class="btn btn-primary" type="button" data-wa37-next="4">下一步 →</button></div>
        </section>

        <section class="wa37-step-panel" data-wa37-step="4" hidden>
          <div class="wa37-step-copy"><span>STEP 4 OF 5</span><h3>确认并连接</h3><p>SalonOS 会先检查资料，不会在验证失败时建立一个假的「已连接」状态。</p></div>
          <div class="wa37-validation-list">
            <div><span>1</span><p><strong>验证 Token</strong><small>确认 Token 仍有效并属于这个 Meta App</small></p></div>
            <div><span>2</span><p><strong>验证 WhatsApp 账号</strong><small>确认 Phone Number ID 属于填写的 WABA</small></p></div>
            <div><span>3</span><p><strong>建立门店连接</strong><small>绑定当前 Organization 与 Branch</small></p></div>
            <div><span>4</span><p><strong>生成 Webhook Verify Token</strong><small>下一步会告诉你复制到 Meta 哪里</small></p></div>
          </div>
          <label class="wa37-toggle-card"><input type="checkbox" name="wa_manual_auto_reply_enabled" value="1" <?=$autoReplyOn?'checked':''?>><span><strong>连接成功后开启 AI 自动回复</strong><small>建议开启。之后仍可以在设置里随时关闭。</small></span></label>
          <div class="wa37-step-actions"><button class="btn btn-light" type="button" data-wa37-prev="3">← 上一步</button><button class="btn btn-primary" type="submit">验证并连接 WhatsApp</button></div>
        </section>

        <section class="wa37-step-panel" data-wa37-step="5" <?=$initialManualStep!==5?'hidden':''?>>
          <div class="wa37-step-copy"><span>STEP 5 OF 5</span><h3><?=!empty($manualSetup)?'最后一步：连接 Webhook':'Webhook 会在验证后生成'?></h3><p><?=!empty($manualSetup)?'把下面两项复制到客户自己的 Meta App。完成后发一条测试消息，SalonOS 会自动识别为 LIVE。':'先完成前面的验证。SalonOS 验证成功后会在这里生成 Callback URL 与一次性 Verify Token。'?></p></div>
          <?php if(!empty($manualSetup)):?>
            <div class="wa37-webhook-result">
              <div class="field"><label>Callback URL</label><div class="wa37-copy-row"><input class="input" id="wa-manual-callback" value="<?=e((string)($manualSetup['callback_url']??''))?>" readonly><button class="btn btn-light" type="button" data-copy-input="wa-manual-callback">复制</button></div></div>
              <div class="field"><label>Verify Token <span class="wa37-once-badge">只显示这一次</span></label><div class="wa37-copy-row"><input class="input" id="wa-manual-verify" value="<?=e((string)($manualSetup['verify_token']??''))?>" readonly><button class="btn btn-light" type="button" data-copy-input="wa-manual-verify">复制</button></div></div>
              <div class="wa37-webhook-mini"><span>订阅字段</span><strong><?=e((string)($manualSetup['webhook_field']??'messages'))?></strong></div>
              <div class="wa37-webhook-mini"><span>已验证号码</span><strong><?=e(trim((string)($manualSetup['verified_name']??'').' '.(string)($manualSetup['display_phone_number']??'')))?></strong></div>
            </div>
            <div class="wa37-help-banner is-success"><div><strong>资料已经验证成功。</strong><span>现在只差在 Meta 设置 Webhook。教程里会告诉你每一格填什么。</span></div><button class="btn btn-primary" type="button" data-v1350-modal-open="wa37-webhook-guide">打开 Webhook 教程</button></div>
            <?php if(!empty($manualSetup['token_expires_at'])):?><div class="alert alert-warning"><strong>当前 Token 有到期时间：</strong> <?=e((string)$manualSetup['token_expires_at'])?>。正式营业建议换 System User Token。</div><?php endif;?>
          <?php else:?>
            <div class="wa37-empty-step"><span>5</span><strong>等待完成连接验证</strong><p>验证成功后会自动回到这一步。</p></div>
          <?php endif;?>
          <div class="wa37-step-actions"><button class="btn btn-light" type="button" data-wa37-prev="4">← 返回</button><button class="btn btn-light" type="button" data-v1350-modal-open="wa37-webhook-guide">提前看 Webhook 教程</button></div>
        </section>
      </form>
    </section>

    <section class="wa37-section" id="automation-settings">
      <div class="wa37-section-head"><div><span class="card-kicker">AFTER CONNECTION</span><h2>自动回复与预约提醒</h2><p>日常最常用的设置放这里。技术 ID、Token 与 Template 细节默认隐藏。</p></div></div>
      <form method="post" class="card wa37-automation-card">
        <input type="hidden" name="csrf" value="<?=csrf_token()?>">
        <input type="hidden" name="action" value="save_whatsapp_settings">
        <input type="hidden" name="return_page" value="settings_whatsapp">
        <input type="hidden" name="wa_phone_number_id" value="<?=e((string)($w['phone_number_id']??''))?>">
        <input type="hidden" name="wa_business_account_id" value="<?=e((string)($w['business_account_id']??''))?>">
        <input type="hidden" name="wa_public_phone" value="<?=e((string)($w['public_phone']??''))?>">
        <input type="hidden" name="wa_reminder_template_language" value="<?=e((string)($w['reminder_template_language']??'zh_CN'))?>">
        <input type="hidden" name="wa_message_template" value="<?=e((string)($w['message_template']??''))?>">
        <input type="hidden" name="wa_reminder_template_name" value="<?=e((string)($w['reminder_template_name']??''))?>">
        <div class="wa37-toggle-list">
          <label class="wa37-toggle-card"><input type="checkbox" name="wa_enabled" value="1" <?=$connectionOn?'checked':''?>><span><strong>启用 WhatsApp 连接</strong><small>关闭后该分行不会使用此连接。</small></span></label>
          <label class="wa37-toggle-card"><input type="checkbox" name="wa_auto_reply_enabled" value="1" <?=$autoReplyOn?'checked':''?>><span><strong>AI 自动回复</strong><small>处理预约、改期、取消与可用时段等已验证业务资料。</small></span></label>
          <label class="wa37-toggle-card"><input type="checkbox" name="wa_reminder_enabled" value="1" <?=$reminderOn?'checked':''?>><span><strong>预约自动提醒</strong><small>在预约前自动提醒顾客。</small></span></label>
        </div>
        <div class="wa37-reminder-row"><div><span>提前多久提醒？</span><small>默认 60 分钟 = 预约前 1 小时</small></div><div class="wa37-number-control"><input class="input" type="number" min="0" max="10080" name="wa_reminder_minutes" value="<?=intval($w['reminder_minutes']??60)?>"><span>分钟</span></div></div>
        <div class="form-actions"><button class="btn btn-primary">保存日常设置</button></div>
      </form>
    </section>

    <details class="card wa37-advanced" id="advanced-settings">
      <summary><div><span class="card-kicker">ADVANCED</span><strong>高级连接设置</strong><small>只有更换 Token、修改技术 ID 或 Template 时才需要打开。</small></div><span>展开</span></summary>
      <form method="post" class="wa37-advanced-body">
        <input type="hidden" name="csrf" value="<?=csrf_token()?>">
        <input type="hidden" name="action" value="save_whatsapp_settings">
        <input type="hidden" name="return_page" value="settings_whatsapp">
        <input type="hidden" name="wa_enabled" value="<?=$connectionOn?'1':'0'?>">
        <input type="hidden" name="wa_auto_reply_enabled" value="<?=$autoReplyOn?'1':'0'?>">
        <input type="hidden" name="wa_reminder_enabled" value="<?=$reminderOn?'1':'0'?>">
        <input type="hidden" name="wa_reminder_minutes" value="<?=intval($w['reminder_minutes']??60)?>">
        <div class="form-grid">
          <div class="field"><label>Phone Number ID *</label><input class="input" name="wa_phone_number_id" value="<?=e((string)($w['phone_number_id']??''))?>" required></div>
          <div class="field"><label>WABA ID</label><input class="input" name="wa_business_account_id" value="<?=e((string)($w['business_account_id']??''))?>"></div>
          <div class="field"><label>WhatsApp 对外号码</label><input class="input" name="wa_public_phone" inputmode="tel" value="<?=e((string)($w['public_phone']??''))?>"></div>
          <div class="field"><label>连接状态</label><input class="input" value="<?=e($status==='live'?'Live · 已收到 Meta Webhook':'Configured · 等待 Meta Webhook')?>" readonly></div>
          <div class="field span-2"><label>更换 Access Token</label><input class="input" type="password" name="wa_access_token" value="" autocomplete="new-password" placeholder="不更换就留空"><small class="field-help">只有 Token 失效或轮换时才填写。</small></div>
          <div class="field"><label>Template Language</label><input class="input" name="wa_reminder_template_language" value="<?=e((string)($w['reminder_template_language']??'zh_CN'))?>"></div>
          <div class="field"><label>Approved Template Name</label><input class="input" name="wa_reminder_template_name" value="<?=e((string)($w['reminder_template_name']??''))?>" placeholder="例如 salon_appointment_reminder"></div>
          <div class="field span-2"><label>24 小时内提醒文字</label><textarea class="textarea" name="wa_message_template" rows="4"><?=e((string)($w['message_template']??''))?></textarea><small class="field-help">可用变量：{customer} {date} {time} {store} {service} {staff}</small></div>
        </div>
        <div class="form-actions"><button class="btn btn-primary">保存高级设置</button></div>
      </form>
    </details>

    <details class="card wa37-developer-details">
      <summary><div><span class="card-kicker">DIAGNOSTICS</span><strong>开发者 / 故障排查资料</strong><small>普通门店老板不需要使用这一块。</small></div><span>展开</span></summary>
      <div class="wa37-developer-body">
        <div class="wa37-diagnostic-grid">
          <div><span>Conversation</span><strong><?=count($conversations)?></strong></div>
          <div><span>Inbound Messages</span><strong><?=count($messages)?></strong></div>
          <div><span>AI Queue</span><strong><?=$queued?></strong></div>
          <div><span>Last Webhook</span><strong><?=!empty($c['last_webhook_at'])?e(app_date((string)$c['last_webhook_at'],true)):'—'?></strong></div>
        </div>
        <div class="field"><label>SalonOS Webhook Callback URL</label><div class="wa37-copy-row"><input class="input" id="wa37-webhook-url" value="<?=e($webhook)?>" readonly><button class="btn btn-light" type="button" data-copy-input="wa37-webhook-url">复制</button></div></div>
        <p class="field-help">Manual 多 App 模式会使用每个客户独立的 App Secret / Verify Token；旧的全局 Secret 只作为 legacy fallback。</p>
      </div>
    </details>

    <?php if($esReady):?>
      <section class="card whatsapp-embedded-signup-card" data-wa-es-root data-app-id="<?=e((string)($esConfig['app_id']??''))?>" data-config-id="<?=e((string)($esConfig['config_id']??''))?>" data-graph-version="<?=e((string)($esConfig['graph_api_version']??'v26.0'))?>" data-session-info-version="<?=e((string)($esConfig['session_info_version']??'3'))?>" data-ready="1" hidden></section>
      <form method="post" hidden data-wa-es-complete-form><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="complete_whatsapp_embedded_signup_v136635"><input type="hidden" name="return_page" value="settings_whatsapp"><input type="hidden" name="wa_es_code"><input type="hidden" name="wa_es_waba_id"><input type="hidden" name="wa_es_phone_number_id"><input type="hidden" name="wa_es_business_id"><input type="hidden" name="wa_es_flow_type"></form>
    <?php endif;?>

    <!-- Tutorial modals -->
    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="wa37-start-guide"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog wa37-guide-modal"><div class="commission-modal-header"><div><span class="card-kicker">BEGINNER GUIDE</span><h3>第一次连接 WhatsApp</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content wa37-guide-content"><div class="wa37-guide-intro"><strong>现在推荐使用 Manual Setup</strong><p>你不需要懂 API。准备好 Meta App、WABA、Phone Number ID、App Secret 与 System User Token，然后跟着 SalonOS 5 步向导即可。</p></div><ol class="wa37-guide-list"><li><b>1</b><div><strong>客户登录自己的 Meta</strong><span>不要把 Facebook 密码给 SalonOS 或管理员。</span></div></li><li><b>2</b><div><strong>准备 5 项 Meta 资料</strong><span>每个资料旁边都有「在哪里找？」教程。</span></div></li><li><b>3</b><div><strong>SalonOS 自动验证</strong><span>Token、WABA 与 Phone Number 对不上时不会保存。</span></div></li><li><b>4</b><div><strong>设置 Webhook</strong><span>复制 SalonOS 生成的 Callback URL 与 Verify Token 到 Meta。</span></div></li><li><b>5</b><div><strong>发一条测试消息</strong><span>状态变成 Connected 后即可开启 AI 自动回复。</span></div></li></ol><div class="form-actions"><button class="btn btn-primary" type="button" data-v1350-modal-close>明白了</button></div></div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="wa37-manual-overview"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog wa37-guide-modal"><div class="commission-modal-header"><div><span class="card-kicker">MANUAL SETUP</span><h3>Manual Setup 是什么？</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content wa37-guide-content"><p>Manual Setup 让每个 Salon 客户使用<strong>自己的 Meta App、自己的 WABA 与自己的 WhatsApp Cloud API 号码</strong>连接 SalonOS。它适合你还没完成 Meta Tech Provider 企业验证的阶段。</p><div class="alert alert-warning"><strong>它不是 Coexistence 绕过方案。</strong><br>如果客户要求同一个号码同时继续登录手机 WhatsApp Business App，又让 Cloud API 自动回复，这类号码仍应等 Meta 官方 Embedded Signup / Coexistence 流程。</div><div class="form-actions"><button class="btn btn-primary" type="button" data-v1350-modal-close>继续使用 Manual Setup</button></div></div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="wa37-auto-connect-info"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog wa37-guide-modal"><div class="commission-modal-header"><div><span class="card-kicker">CONNECT WITH META</span><h3>为什么暂时不能一键连接？</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content wa37-guide-content"><p>Meta 的正式 SaaS Embedded Signup 需要你的平台完成 Business Verification / Tech Provider 与相应 App Review。现在不需要让这件事卡住 SalonOS，先用 Manual Setup 服务真实 Cloud API 客户即可。</p><div class="form-actions"><button class="btn btn-primary" type="button" data-v1350-modal-close>知道了</button></div></div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="wa37-prepare-guide"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog wa37-guide-modal"><div class="commission-modal-header"><div><span class="card-kicker">PREPARE META INFO</span><h3>准备资料总教程</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content wa37-guide-content"><ol class="wa37-guide-list"><li><b>1</b><div><strong>打开 Meta for Developers</strong><span>选择客户自己的 App，并确认已添加 WhatsApp 产品。</span></div></li><li><b>2</b><div><strong>App Settings → Basic</strong><span>这里找 App ID 与 App Secret。</span></div></li><li><b>3</b><div><strong>WhatsApp → API Setup</strong><span>这里找 WABA ID 与 Phone Number ID。</span></div></li><li><b>4</b><div><strong>Meta Business Settings → System Users</strong><span>建立 System User、分配 WhatsApp 资产，再 Generate Token。</span></div></li></ol><div class="wa37-guide-links"><a class="btn btn-light" href="https://developers.facebook.com/apps/" target="_blank" rel="noopener">打开 Meta for Developers ↗</a><a class="btn btn-light" href="https://business.facebook.com/settings/system-users" target="_blank" rel="noopener">打开 System Users ↗</a></div><div class="form-actions"><button class="btn btn-primary" type="button" data-v1350-modal-close>返回填写</button></div></div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="wa37-appid-guide"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog wa37-guide-modal"><div class="commission-modal-header"><div><span class="card-kicker">APP ID</span><h3>在哪里找 Meta App ID？</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content wa37-guide-content"><ol class="wa37-guide-list"><li><b>1</b><div><strong>进入 Meta for Developers</strong><span>选择客户自己的 App。</span></div></li><li><b>2</b><div><strong>打开 App Settings → Basic</strong><span>页面上会显示 App ID。</span></div></li><li><b>3</b><div><strong>复制纯数字 App ID</strong><span>不要复制 App 名称。</span></div></li></ol><div class="form-actions"><button class="btn btn-primary" type="button" data-v1350-modal-close>我找到了</button></div></div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="wa37-appsecret-guide"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog wa37-guide-modal"><div class="commission-modal-header"><div><span class="card-kicker">APP SECRET</span><h3>在哪里找 App Secret？</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content wa37-guide-content"><ol class="wa37-guide-list"><li><b>1</b><div><strong>Meta App → App Settings → Basic</strong><span>和 App ID 在同一个页面。</span></div></li><li><b>2</b><div><strong>找到 App Secret → Show</strong><span>Meta 可能要求重新验证账号。</span></div></li><li><b>3</b><div><strong>直接粘进 SalonOS</strong><span>不要把 App Secret 发到聊天、Email 或截图。</span></div></li></ol><div class="alert alert-warning"><strong>App Secret 属于敏感凭据。</strong><br>SalonOS 保存后不会再次显示明文。</div><div class="form-actions"><button class="btn btn-primary" type="button" data-v1350-modal-close>我知道了</button></div></div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="wa37-waba-guide"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog wa37-guide-modal"><div class="commission-modal-header"><div><span class="card-kicker">WABA + PHONE NUMBER ID</span><h3>在哪里找 WABA ID 与 Phone Number ID？</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content wa37-guide-content"><ol class="wa37-guide-list"><li><b>1</b><div><strong>Meta App → WhatsApp → API Setup</strong><span>进入客户号码所在的 WhatsApp API Setup。</span></div></li><li><b>2</b><div><strong>找到 WhatsApp Business Account ID</strong><span>这就是 WABA ID。</span></div></li><li><b>3</b><div><strong>找到 Phone Number ID</strong><span>注意：它不是 +60 开头的电话号码，而是一串 Meta 数字 ID。</span></div></li></ol><div class="form-actions"><button class="btn btn-primary" type="button" data-v1350-modal-close>我找到了</button></div></div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="wa37-token-guide"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog wa37-guide-modal"><div class="commission-modal-header"><div><span class="card-kicker">SYSTEM USER TOKEN</span><h3>生成长期 Access Token</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content wa37-guide-content"><ol class="wa37-guide-list"><li><b>1</b><div><strong>打开 Meta Business Settings</strong><span>进入 Users → System Users。</span></div></li><li><b>2</b><div><strong>建立或选择 System User</strong><span>给它分配客户自己的 App 与 WhatsApp Business Account 资产。</span></div></li><li><b>3</b><div><strong>Generate new token</strong><span>选择正确 App，并授予 WhatsApp Business Messaging / Management 所需权限。</span></div></li><li><b>4</b><div><strong>复制 Token 到 SalonOS</strong><span>Token 只显示给客户本人，不要发给 SalonOS 管理员。</span></div></li></ol><div class="alert alert-warning"><strong>不要把 API Setup 的 Temporary Token 当长期生产 Token。</strong><br>Temporary Token 适合测试，过期后 AI 会无法回 WhatsApp。</div><div class="wa37-guide-links"><a class="btn btn-light" href="https://business.facebook.com/settings/system-users" target="_blank" rel="noopener">打开 System Users ↗</a></div><div class="form-actions"><button class="btn btn-primary" type="button" data-v1350-modal-close>返回填写</button></div></div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="wa37-webhook-guide"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog wa37-guide-modal"><div class="commission-modal-header"><div><span class="card-kicker">FINAL STEP</span><h3>在 Meta 设置 Webhook</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content wa37-guide-content"><ol class="wa37-guide-list"><li><b>1</b><div><strong>打开客户自己的 Meta App</strong><span>进入 WhatsApp → Configuration / Webhooks。</span></div></li><li><b>2</b><div><strong>填 Callback URL</strong><span>复制 SalonOS Step 5 显示的 Callback URL。</span></div></li><li><b>3</b><div><strong>填 Verify Token</strong><span>复制 SalonOS 一次性显示的 Verify Token，然后按 Verify and Save。</span></div></li><li><b>4</b><div><strong>订阅 messages</strong><span>在 Webhook fields 里确认 messages 已订阅。</span></div></li><li><b>5</b><div><strong>发送测试 WhatsApp</strong><span>用另一个号码给店铺号码发消息；SalonOS 状态应更新为 Connected。</span></div></li></ol><div class="alert alert-info"><strong>不需要在这里填 Facebook 密码。</strong><br>Meta Webhook 只需要 Callback URL 与 Verify Token；真实 POST 还会由 SalonOS 使用客户独立 App Secret 验证签名。</div><div class="form-actions"><button class="btn btn-primary" type="button" data-v1350-modal-close>明白了</button></div></div></section></div>

    <script>
    (()=>{
      const panel=document.querySelector('[data-wa37-manual-panel]');
      const form=document.querySelector('[data-wa37-manual-form]');
      const stepper=document.querySelector('[data-wa37-stepper]');
      let step=Number(form?.dataset.initialStep||1);
      const showStep=(next)=>{
        if(!form)return;
        step=Math.max(1,Math.min(5,Number(next)||1));
        form.querySelectorAll('[data-wa37-step]').forEach(el=>el.hidden=Number(el.dataset.wa37Step)!==step);
        stepper?.querySelectorAll('[data-wa37-step-dot]').forEach(el=>{const n=Number(el.dataset.wa37StepDot);el.classList.toggle('is-active',n===step);el.classList.toggle('is-done',n<step);});
        panel?.scrollIntoView({behavior:'smooth',block:'start'});
      };
      document.querySelectorAll('[data-wa37-open-manual]').forEach(btn=>btn.addEventListener('click',()=>{if(panel){panel.hidden=false;showStep(1);}}));
      document.querySelectorAll('[data-wa37-close-manual]').forEach(btn=>btn.addEventListener('click',()=>{if(panel)panel.hidden=true;}));
      document.querySelectorAll('[data-wa37-next]').forEach(btn=>btn.addEventListener('click',()=>{
        if(!form)return;
        const current=form.querySelector(`[data-wa37-step="${step}"]`);
        const required=[...(current?.querySelectorAll('[required]')||[])];
        const invalid=required.find(el=>!el.checkValidity());
        if(invalid){invalid.reportValidity();invalid.focus();return;}
        showStep(btn.dataset.wa37Next);
      }));
      document.querySelectorAll('[data-wa37-prev]').forEach(btn=>btn.addEventListener('click',()=>showStep(btn.dataset.wa37Prev)));
      stepper?.querySelectorAll('[data-wa37-step-dot]').forEach(btn=>btn.addEventListener('click',()=>{const target=Number(btn.dataset.wa37StepDot);if(target<=step)showStep(target);}));
      document.querySelectorAll('[data-wa37-scroll]').forEach(btn=>btn.addEventListener('click',()=>document.getElementById(btn.dataset.wa37Scroll||'')?.scrollIntoView({behavior:'smooth',block:'start'})));
      document.querySelectorAll('[data-copy-input]').forEach(btn=>btn.addEventListener('click',async()=>{const el=document.getElementById(btn.dataset.copyInput||'');if(!el)return;try{await navigator.clipboard.writeText(el.value||'');const old=btn.textContent;btn.textContent='已复制';setTimeout(()=>btn.textContent=old,1200);}catch{el.select();document.execCommand('copy');}}));
    })();
    </script>

    <?php if($esReady):?>
    <script>
    (()=>{
      const root=document.querySelector('[data-wa-es-root]');
      const form=document.querySelector('[data-wa-es-complete-form]');
      if(!root||!form)return;
      const appId=root.dataset.appId||'';
      const configId=root.dataset.configId||'';
      const graphVersion=root.dataset.graphVersion||'v26.0';
      const sessionInfoVersion=root.dataset.sessionInfoVersion||'3';
      const statusBox=document.querySelector('[data-wa-es-status]');
      let authCode='';let sessionData=null;let flowType='standard';let submitted=false;
      const setStatus=(title,detail,isError=false)=>{if(!statusBox)return;statusBox.classList.toggle('alert-danger',!!isError);statusBox.classList.toggle('alert-info',!isError);statusBox.replaceChildren();const strong=document.createElement('strong');strong.textContent=String(title||'');statusBox.append(strong,document.createElement('br'),document.createTextNode(String(detail||'')));};
      const submitIfReady=()=>{if(submitted||!authCode||!sessionData)return;const waba=String(sessionData.waba_id||sessionData.wabaId||'');const phone=String(sessionData.phone_number_id||sessionData.phoneNumberId||'');const business=String(sessionData.business_id||sessionData.businessId||'');if(!waba||!phone){setStatus('Meta 已完成授权，但资料不完整','缺少 WABA ID 或 Phone Number ID，请重新连接。',true);return;}submitted=true;form.querySelector('[name="wa_es_code"]').value=authCode;form.querySelector('[name="wa_es_waba_id"]').value=waba;form.querySelector('[name="wa_es_phone_number_id"]').value=phone;form.querySelector('[name="wa_es_business_id"]').value=business;form.querySelector('[name="wa_es_flow_type"]').value=flowType;setStatus('Meta 授权完成','SalonOS 正在验证号码并建立连接…');form.submit();};
      window.addEventListener('message',(event)=>{if(event.origin!=='https://www.facebook.com'&&event.origin!=='https://web.facebook.com')return;let data=event.data;try{if(typeof data==='string')data=JSON.parse(data);}catch{return;}if(!data||data.type!=='WA_EMBEDDED_SIGNUP')return;if(data.event==='FINISH'){sessionData=data.data||{};submitIfReady();}else if(data.event==='CANCEL'){setStatus('连接已取消','你可以随时重新连接。');}else if(data.event==='ERROR'){setStatus('Meta 连接出错',String(data.data?.error_message||data.data?.message||'请稍后再试。'),true);}});
      window.fbAsyncInit=()=>{FB.init({appId,autoLogAppEvents:true,xfbml:false,version:graphVersion});};
      if(!document.getElementById('facebook-jssdk')){const js=document.createElement('script');js.id='facebook-jssdk';js.async=true;js.defer=true;js.crossOrigin='anonymous';js.src='https://connect.facebook.net/en_US/sdk.js';document.head.appendChild(js);}
      document.querySelectorAll('[data-wa-es-launch]').forEach(button=>button.addEventListener('click',()=>{if(typeof FB==='undefined'){setStatus('Meta SDK 仍在载入','请等 1–2 秒后再点一次。',true);return;}submitted=false;authCode='';sessionData=null;flowType=button.dataset.waEsLaunch==='business_app'?'business_app':'standard';const extras={setup:{},sessionInfoVersion};if(flowType==='business_app')extras.featureType='whatsapp_business_app_onboarding';setStatus('正在打开 Meta','请在 Meta 官方窗口完成授权。');FB.login((response)=>{const code=response?.authResponse?.code||'';if(!code){setStatus('没有取得 Meta authorization code','如果关闭了授权窗口，请重新连接。',true);return;}authCode=code;submitIfReady();},{config_id:configId,response_type:'code',override_default_response_type:true,extras});}));
    })();
    </script>
    <?php endif;?>
<?php }

function v1360_marketing_defaults(): array { return [
 ['INSTAGRAM','Instagram','social'],['FACEBOOK','Facebook','social'],['TIKTOK','TikTok','social'],['GOOGLE','Google','search'],['XHS','XHS / 小红书','social'],
 ['WEBSITE','Website','owned'],['QR','QR','owned'],['REFERRAL','Referral','referral'],['WALK_IN','Walk-in','offline'],['OTHER','Other','other']
]; }
function v1360_ensure_default_channels(): void {
    $existing=v13_owner_rows('marketing_channels','select=code&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=500');
    $have=[];foreach($existing as $r)$have[strtoupper((string)($r['code']??''))]=true;
    foreach(v1360_marketing_defaults() as [$code,$name,$type]) if(empty($have[$code])){
        v13_owner_write('marketing_channels','','POST',['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'code'=>$code,'name'=>$name,'channel_type'=>$type,'is_system'=>true,'active'=>true,'updated_at'=>date(DATE_ATOM)]);
    }
}
function v1360_tracking_base_url(): string {
    $https=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO']??''))==='https';
    $scheme=$https?'https':'http';$host=trim((string)($_SERVER['HTTP_HOST']??'localhost'))?:'localhost';
    $dir=rtrim(str_replace('\\','/',dirname((string)($_SERVER['SCRIPT_NAME']??'/index.php'))),'/'); if($dir==='.')$dir='';
    return $scheme.'://'.$host.$dir.'/t/';
}
function v1360_page_settings_marketing(): void {
    if(!v13_is_owner()){ ?>
      <div class="page-head"><div><a class="back-link" href="index.php?page=settings">← 返回系统设置</a><span class="eyebrow">MEDIA ATTRIBUTION</span><h1>媒体账号与 Tracking</h1><p>老板已经允许你的职位看到这个设置入口。</p></div></div>
      <section class="card"><div class="card-body"><p>员工账号目前为只读入口。新增、修改、停用媒体账号和 Tracking Link 仍由老板执行，避免误改全门店的营销归因。</p></div></section>
    <?php return; }
    if(!v13_is_owner()){echo '<section class="card empty-state"><h3>只有老板可以管理媒体归因</h3></section>';return;}
    v1360_ensure_default_channels();
    $org=v13_org_uuid();$store=v13_store_uuid();
    $channels=v13_owner_rows('marketing_channels','select=id,code,name,channel_type,is_system,active,created_at&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&order=is_system.desc,name.asc&limit=500');
    $accounts=v13_owner_rows('social_accounts','select=id,channel_id,platform,account_type,staff_id,display_name,username,profile_url,external_account_id,connection_status,active,created_at&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&order=active.desc,created_at.desc&limit=1000');
    $socialInboxConnections=[]; try{$socialInboxConnections=v13_owner_rows('social_inbox_connections','select=id,social_account_id,platform,external_account_id,connection_status,enabled,last_webhook_at,last_error,created_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&order=created_at.desc&limit=100');}catch(Throwable $ignore){}
    $contents=v13_owner_rows('marketing_contents','select=id,social_account_id,content_type,content_code,title,external_url,active,created_at&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&limit=2000');
    $links=v13_owner_rows('tracking_links','select=id,channel_id,social_account_id,content_id,staff_id,slug,ref_prefix,placement,destination_type,destination_phone,destination_url,prefill_message,active,created_at&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&order=active.desc,created_at.desc&limit=2000');
    $clicks=v13_owner_rows('tracking_clicks','select=tracking_link_id&id=not.is.null&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&limit=50000');
    $employees=v13_employee_rows_owner();$emp=[];foreach($employees as $e)$emp[(string)($e['id']??'')]=(string)($e['name']??$e['full_name']??'员工');
    $ch=[];foreach($channels as $r)$ch[(string)$r['id']]=$r;$acc=[];foreach($accounts as $r)$acc[(string)$r['id']]=$r;$cont=[];foreach($contents as $r)$cont[(string)$r['id']]=$r;$cc=[];foreach($clicks as $r){$id=(string)($r['tracking_link_id']??'');if($id!=='')$cc[$id]=($cc[$id]??0)+1;}

    // Legacy duplicate detector. We never auto-delete/disable historical links.
    $activeProfileGroups=[];
    foreach($links as $linkRow){
      if(empty($linkRow['active']))continue;
      $aidNow=(string)($linkRow['social_account_id']??'');
      if($aidNow==='')continue;
      $placementNow=strtolower(trim((string)($linkRow['placement']??'')));
      if($placementNow==='bio')$placementNow='profile';
      if($placementNow==='' && empty($linkRow['content_id']))$placementNow='profile';
      if($placementNow!=='profile')continue;
      $activeProfileGroups[$aidNow][]=$linkRow;
    }
    $duplicateActiveProfiles=array_filter($activeProfileGroups,fn($rows)=>count($rows)>1);

    $wa=v1361_whatsapp_effective_settings();$defaultPhone=preg_replace('/[^0-9]+/','',(string)($wa['public_phone']??''))?:'';$base=v1360_tracking_base_url();
    ?>
    <div class="page-head responsive-page-head"><div><a class="back-link" href="index.php?page=settings">← 返回系统设置</a><span class="eyebrow">MEDIA ATTRIBUTION · AI READY</span><h1>媒体账号与 Tracking</h1><p>把「平台 → 账号 → 员工 → 内容 → Tracking Link」变成可分析的数据。所有链接可以最终进入同一个 WhatsApp Business，但 SalonOS 会保留入口身份。</p></div><a class="btn btn-light" href="index.php?page=settings_whatsapp">WhatsApp 设置 →</a></div>
    <section class="stats marketing-attribution-stats"><div class="stat"><span>来源渠道</span><strong><?=count(array_filter($channels,fn($x)=>!empty($x['active'])))?></strong><small>Instagram / Google / QR 等</small></div><div class="stat"><span>媒体账号</span><strong><?=count(array_filter($accounts,fn($x)=>!empty($x['active'])))?></strong><small>门店 + 员工 IP</small></div><div class="stat"><span>Tracking Links</span><strong><?=count(array_filter($links,fn($x)=>!empty($x['active'])))?></strong><small>Bio / Reel / Story / QR</small></div><div class="stat"><span>累计点击</span><strong><?=array_sum($cc)?></strong><small>AI Agent 后续接 Lead / Appointment / Revenue</small></div></section>
    <section class="card marketing-ai-flow"><div class="card-head"><div><span class="card-kicker">ATTRIBUTION FLOW</span><h3>以后 AI Agent 会沿这条链路读取</h3></div><span class="badge badge-green">WEBHOOK FOUNDATION READY</span></div><div class="marketing-flow-line"><span>Channel</span><b>→</b><span>Account</span><b>→</b><span>Content</span><b>→</b><span>Tracking Ref</span><b>→</b><span>WhatsApp Lead</span><b>→</b><span>Appointment</span><b>→</b><span>Arrived</span><b>→</b><span>Revenue</span></div><p class="muted">v13.6.1 已加入 WhatsApp Webhook / Conversation / Lead / AI Queue。收到含 Ref 的 WhatsApp 消息会自动回查 Tracking Link；没有 Ref 时会标记 fallback，交给下一阶段 AI 询问来源。</p></section>

    <div class="marketing-settings-grid">
      <section class="card"><div class="card-head"><div><span class="card-kicker">CHANNELS</span><h3>一、来源平台</h3><p>默认已经建立你指定的 10 个来源，也可以继续增加。</p></div></div><div class="card-body"><div class="marketing-chip-list"><?php foreach($channels as $r):?><div class="marketing-chip <?=empty($r['active'])?'is-off':''?>"><div><strong><?=e((string)$r['name'])?></strong><small><?=e((string)$r['code'])?> · <?=e((string)$r['channel_type'])?></small></div><?php if(!empty($r['active'])):?><form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="archive_marketing_channel_v1360"><input type="hidden" name="return_page" value="settings_marketing"><input type="hidden" name="channel_id" value="<?=e((string)$r['id'])?>"><button class="btn btn-light btn-small">停用</button></form><?php else:?><span class="badge badge-gray">已停用</span><?php endif;?></div><?php endforeach;?></div><form method="post" class="marketing-inline-form"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_marketing_channel_v1360"><input type="hidden" name="return_page" value="settings_marketing"><div class="field"><label>增加来源</label><input class="input" name="channel_name" placeholder="例如 Threads / YouTube"></div><div class="field"><label>Code</label><input class="input" name="channel_code" placeholder="THREADS"></div><div class="field"><label>类型</label><select class="select" name="channel_type"><option value="social">Social</option><option value="search">Search</option><option value="owned">Owned</option><option value="offline">Offline</option><option value="referral">Referral</option><option value="other">Other</option></select></div><button class="btn btn-primary">增加</button></form></div></section>

      <section class="card"><div class="card-head"><div><span class="card-kicker">SOCIAL ACCOUNTS</span><h3>二、媒体／员工账号</h3><p>Instagram 不再只有一个 Instagram；门店官方账号和员工 Personal IP 分开记录。新增与修改统一使用小浮窗，不离开当前页面。</p></div><button class="btn btn-primary btn-small" type="button" data-v1350-modal-open="marketing-account-editor" data-modal-kicker="NEW SOCIAL ACCOUNT" data-modal-title="增加媒体账号" data-account-id="" data-channel-id="" data-account-type="store" data-display-name="" data-username="" data-staff-id="" data-profile-url="" data-external-account-id="" data-active="1">＋ 增加账号</button></div><div class="card-body"><div class="marketing-account-list"><?php foreach($accounts as $r):$cid=(string)$r['channel_id'];?><article class="marketing-account-row <?=empty($r['active'])?'is-off':''?>"><div><span class="badge badge-gray"><?=e((string)($ch[$cid]['name']??$r['platform']))?></span><strong><?=e((string)$r['display_name'])?></strong><small><?=e((string)($r['username']??''))?><?=!empty($r['staff_id'])?' · '.e($emp[(string)$r['staff_id']]??'员工'):''?> · <?=e((string)$r['account_type'])?></small></div><div class="marketing-account-actions"><button class="btn btn-light btn-small" type="button" data-v1350-modal-open="marketing-account-editor" data-modal-kicker="EDIT SOCIAL ACCOUNT" data-modal-title="修改媒体账号" data-account-id="<?=e((string)$r['id'])?>" data-channel-id="<?=e((string)$r['channel_id'])?>" data-account-type="<?=e((string)($r['account_type']??'store'))?>" data-display-name="<?=e((string)($r['display_name']??''))?>" data-username="<?=e((string)($r['username']??''))?>" data-staff-id="<?=e((string)($r['staff_id']??''))?>" data-profile-url="<?=e((string)($r['profile_url']??''))?>" data-external-account-id="<?=e((string)($r['external_account_id']??''))?>" data-active="<?=!empty($r['active'])?'1':'0'?>">修改</button><?php if(!empty($r['active'])):?><form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="archive_social_account_v1360"><input type="hidden" name="return_page" value="settings_marketing"><input type="hidden" name="account_id" value="<?=e((string)$r['id'])?>"><button class="btn btn-light btn-small">停用</button></form><?php else:?><span class="badge badge-gray">已停用</span><?php endif;?></div></article><?php endforeach;?><?php if(!$accounts):?><div class="empty compact-empty">还没有媒体账号。</div><?php endif;?></div></div></section>
    </div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="marketing-account-editor"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal marketing-account-editor-dialog"><div class="commission-modal-header"><div><span class="card-kicker" data-v1350-copy="modalKicker">SOCIAL ACCOUNT</span><h3 data-v1350-copy="modalTitle">媒体账号</h3><p>只修改账号资料与未来归因映射；历史 Lead、预约与已完成分析不会被重写。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><form method="post" class="marketing-account-form marketing-account-modal-form"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_social_account_v1360"><input type="hidden" name="return_page" value="settings_marketing"><input type="hidden" name="account_id" value="" data-bind="accountId"><div class="form-grid"><div class="field"><label>平台 *</label><select class="select" name="channel_id" required data-bind="channelId"><option value="">选择平台</option><?php foreach($channels as $r):?><option value="<?=e((string)$r['id'])?>"><?=e((string)$r['name'])?><?=empty($r['active'])?'（已停用）':''?></option><?php endforeach;?></select></div><div class="field"><label>账号类型</label><select class="select" name="account_type" data-marketing-account-type data-bind="accountType"><option value="store">门店官方</option><option value="staff">员工 Personal IP</option><option value="other">其他</option></select></div><div class="field"><label>显示名称 *</label><input class="input" name="display_name" placeholder="Jason Personal IP" required data-bind="displayName"></div><div class="field"><label>Username</label><input class="input" name="username" placeholder="@jasonhair" data-bind="username"></div><div class="field" data-marketing-staff-field><label>对应员工</label><select class="select" name="staff_id" data-bind="staffId"><option value="">选择员工</option><?php foreach($employees as $e):$eid=(string)($e['id']??'');?><option value="<?=e($eid)?>"><?=e((string)($e['name']??$e['full_name']??'员工'))?></option><?php endforeach;?></select></div><div class="field"><label>Profile URL</label><input class="input" name="profile_url" placeholder="https://instagram.com/..." data-bind="profileUrl"></div><div class="field span-2"><label>平台 Account ID（以后 API 用，可留空）</label><input class="input" name="external_account_id" placeholder="不需要填写账号密码" data-bind="externalAccountId"></div><div class="field span-2"><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" data-bind="active"><span>启用这个媒体账号（取消勾选 = 停用；之后仍可再次打开修改并重新启用）</span></label></div></div><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary" type="submit">保存账号</button></div></form></div></section></div>

    <?php
      $socialContacts=[];$socialMessages=[];
      try{$socialContacts=v13_owner_rows('social_inbox_contacts','select=id,connection_id,social_account_id,platform,external_user_id,display_name,customer_phone,last_message_at,customer_id&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&order=last_message_at.desc&limit=8');}catch(Throwable $ignore){}
      try{$socialMessages=v13_owner_rows('social_inbox_messages','select=id,contact_id,platform,message_text,received_at,direction&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&order=received_at.desc&limit=10');}catch(Throwable $ignore){}
      $socialCallbackBase=rtrim(SALONOS_SUPABASE_URL,'/').'/functions/v1/meta-social-webhook';
      $lastVerify=(string)($_SESSION['v1361052_social_verify_token']??'');
      $lastConn=(string)($_SESSION['v1361052_social_connection_id']??'');
      $lastCallback=$socialCallbackBase.($lastConn!==''?'?connection_id='.rawurlencode($lastConn):'');
      $igConnections=array_values(array_filter($socialInboxConnections,fn($c)=>strtolower((string)($c['platform']??''))==='instagram'));
      $fbConnections=array_values(array_filter($socialInboxConnections,fn($c)=>strtolower((string)($c['platform']??''))==='facebook'));
      $platformStatus=function(array $rows):array{
        if(!$rows)return ['label'=>'Not connected','class'=>'badge-gray','detail'=>'还没有建立连接'];
        foreach($rows as $row){if(!empty($row['enabled'])&&strtolower((string)($row['connection_status']??''))==='live')return ['label'=>'Connected','class'=>'badge-green','detail'=>!empty($row['last_webhook_at'])?'Last webhook '.app_date((string)$row['last_webhook_at'],true):'Webhook connected'];}
        foreach($rows as $row){if(!empty($row['last_error']))return ['label'=>'Needs attention','class'=>'badge-gold','detail'=>(string)$row['last_error']];}
        return ['label'=>'Configured','class'=>'badge-gold','detail'=>'等待 Meta Webhook 验证 / 第一条私讯'];
      };
      $igStatus=$platformStatus($igConnections);$fbStatus=$platformStatus($fbConnections);
    ?>
    <section class="card v1361054-social-hub" data-social-hub>
      <div class="card-head">
        <div><span class="card-kicker">SOCIAL INBOX · GUIDED SETUP</span><h3>Instagram / Facebook 私讯收录</h3><p>像 WhatsApp Business 一样按步骤连接。SalonOS 会把直接私讯保留为 Social Contact，并记录来自门店官方账号还是员工 Personal IP。</p></div>
        <span class="badge badge-green">TUTORIAL MODE</span>
      </div>
      <div class="card-body">
        <div class="v1361054-social-overview">
          <div class="v1361054-flow"><span>顾客 DM</span><b>→</b><span>Meta Webhook</span><b>→</b><span>Social Contact</span><b>→</b><span>来源账号 / 员工</span><b>→</b><span>Phone 后合并 Customer</span></div>
          <div class="alert alert-info"><strong>先知道：</strong>这里不需要输入 Instagram / Facebook 密码。正式收录走 Meta 官方 Messaging API、Webhook 与 Access Token。</div>
        </div>

        <?php if($lastVerify!==''):?>
          <div class="v1361054-verify-once">
            <div><span class="card-kicker">WEBHOOK GENERATED</span><h4>Verify Token 只显示这一次</h4><p>把下面两项复制到 Meta App Webhook 页面。完成后建议立即测试一条私讯。</p></div>
            <label>Callback URL</label><div class="v1361054-copy-row"><code><?=e($lastCallback)?></code><button class="btn btn-light btn-small" type="button" data-copy-text="<?=e($lastCallback)?>">复制</button></div>
            <label>Verify Token</label><div class="v1361054-copy-row"><code><?=e($lastVerify)?></code><button class="btn btn-light btn-small" type="button" data-copy-text="<?=e($lastVerify)?>">复制</button></div>
          </div>
          <?php unset($_SESSION['v1361052_social_verify_token'],$_SESSION['v1361052_social_connection_id']);?>
        <?php endif;?>

        <div class="v1361054-platform-grid">
          <article class="v1361054-platform-card">
            <div class="v1361054-platform-head"><div class="v1361054-platform-icon">IG</div><div><span class="card-kicker">INSTAGRAM DIRECT</span><h4>Instagram Direct</h4><p>收录门店官方 IG 或员工 Personal IP 的私讯。</p></div><span class="badge <?=$igStatus['class']?>"><?=e($igStatus['label'])?></span></div>
            <div class="v1361054-progress"><i></i><i></i><i></i><i></i><i></i></div>
            <small><?=e($igStatus['detail'])?></small>
            <div class="v1361054-platform-actions">
              <button class="btn btn-primary" type="button" data-v1350-modal-open="social-connect-wizard" data-social-platform="instagram">开始 / 继续设置</button>
              <button class="btn btn-light" type="button" data-v1350-modal-open="social-tutorial-instagram">查看教程</button>
            </div>
          </article>
          <article class="v1361054-platform-card">
            <div class="v1361054-platform-head"><div class="v1361054-platform-icon">FB</div><div><span class="card-kicker">FACEBOOK MESSENGER</span><h4>Facebook Messenger</h4><p>收录连接到 Meta App 的 Facebook Page 私讯。</p></div><span class="badge <?=$fbStatus['class']?>"><?=e($fbStatus['label'])?></span></div>
            <div class="v1361054-progress"><i></i><i></i><i></i><i></i><i></i></div>
            <small><?=e($fbStatus['detail'])?></small>
            <div class="v1361054-platform-actions">
              <button class="btn btn-primary" type="button" data-v1350-modal-open="social-connect-wizard" data-social-platform="facebook">开始 / 继续设置</button>
              <button class="btn btn-light" type="button" data-v1350-modal-open="social-tutorial-facebook">查看教程</button>
            </div>
          </article>
        </div>

        <div class="v1361054-diagnostics-grid">
          <section class="v1361054-mini-panel"><div class="v1361054-mini-head"><div><span class="card-kicker">CONNECTIONS</span><h4>已建立连接</h4></div><span><?=count($socialInboxConnections)?></span></div>
            <div class="marketing-account-list v1361052-social-connection-list"><?php foreach($socialInboxConnections as $c):?><article class="marketing-account-row"><div><span class="badge badge-gray"><?=e(strtoupper((string)$c['platform']))?></span><strong><?=e((string)$c['external_account_id'])?></strong><small><?=e((string)($c['connection_status']??'configured'))?><?=!empty($c['last_webhook_at'])?' · '.e(app_date((string)$c['last_webhook_at'],true)):''?><?=!empty($c['last_error'])?' · '.e((string)$c['last_error']):''?></small></div><span class="badge <?=!empty($c['enabled'])?'badge-green':'badge-gray'?>"><?=!empty($c['enabled'])?'Enabled':'Disabled'?></span></article><?php endforeach;?><?php if(!$socialInboxConnections):?><div class="empty compact-empty">还没有连接。先选择 Instagram 或 Facebook 开始设置。</div><?php endif;?></div>
          </section>
          <section class="v1361054-mini-panel"><div class="v1361054-mini-head"><div><span class="card-kicker">RECENT INBOX</span><h4>最近收到的私讯</h4></div><span><?=count($socialMessages)?></span></div>
            <div class="v1361054-message-list"><?php foreach($socialMessages as $m):?><article><div><span class="badge badge-gray"><?=e(strtoupper((string)($m['platform']??'')))?></span><strong><?=e((string)($m['direction']??'inbound'))?></strong><small><?=e(app_date((string)($m['received_at']??''),true))?></small></div><p><?=e(mb_strimwidth((string)($m['message_text']??'(non-text message)'),0,120,'…','UTF-8'))?></p></article><?php endforeach;?><?php if(!$socialMessages):?><div class="empty compact-empty">还没有收到私讯。连接完成后，从 IG / FB 发一条测试消息。</div><?php endif;?></div>
          </section>
        </div>

        <section class="v1361054-manual-capture">
          <div class="v1361054-mini-head"><div><span class="card-kicker">MANUAL SOURCE CAPTURE</span><h4>还没接 Meta？先手动收录顾客来源</h4><p>适合暂时不能连接 API 的账号。这里只记录来源线索，不会伪装成 Meta Webhook 消息。</p></div><button class="btn btn-light" type="button" data-v1350-modal-open="social-manual-lead">＋ 手动收录</button></div>
        </section>
      </div>
    </section>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="social-connect-wizard"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1361054-wizard-dialog"><div class="commission-modal-header"><div><span class="card-kicker">SOCIAL INBOX SETUP</span><h3 data-social-wizard-title>连接 Instagram Direct</h3><p>按步骤完成。技术字段只有在需要时才出现。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content">
      <?php if(v13_is_owner()):?>
      <div class="v1361054-stepper"><button type="button" class="is-active" data-social-step-button="1"><b>1</b><span>准备账号</span></button><button type="button" data-social-step-button="2"><b>2</b><span>Meta 设置</span></button><button type="button" data-social-step-button="3"><b>3</b><span>填写资料</span></button><button type="button" data-social-step-button="4"><b>4</b><span>Webhook</span></button><button type="button" data-social-step-button="5"><b>5</b><span>测试</span></button></div>
      <div class="v1361054-step-panel is-active" data-social-step="1"><span class="card-kicker">STEP 1</span><h4>确认账号类型</h4><div data-social-copy="instagram"><p>Instagram 建议使用 Professional / Business 账号，并确认它属于你要收录的门店或员工 Personal IP。</p></div><div data-social-copy="facebook" hidden><p>Facebook 需要使用要收录私讯的 Facebook Page，而不是个人 Facebook Profile。</p></div><div class="alert alert-info">先在「媒体／员工账号」建立对应账号，这样每条 DM 才能正确归因到门店或员工。</div></div>
      <div class="v1361054-step-panel" data-social-step="2"><span class="card-kicker">STEP 2</span><h4>准备 Meta App</h4><p>在 Meta for Developers 建立 / 选择 App，并启用目标平台所需的 Messaging / Webhook 能力。App 必须与实际 Page / IG 资产完成授权关系。</p><button class="btn btn-light" type="button" data-social-open-tutorial>打开详细教程</button></div>
      <div class="v1361054-step-panel" data-social-step="3"><span class="card-kicker">STEP 3</span><h4>填写连接资料</h4>
        <form method="post" class="form-grid v1361052-social-connect-form" data-social-connect-form><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_social_inbox_connection_v1361052"><input type="hidden" name="return_page" value="settings_marketing"><input type="hidden" name="platform" value="instagram" data-social-platform-input>
          <div class="field"><label>SalonOS 媒体账号 *</label><select class="select" name="social_account_id" required><option value="">选择已建立的账号</option><?php foreach($accounts as $a):?><option value="<?=e((string)$a['id'])?>"><?=e((string)$a['display_name'])?><?=!empty($a['username'])?' · '.e((string)$a['username']):''?></option><?php endforeach;?></select></div>
          <div class="field"><label data-social-external-label>IG Business Account ID *</label><input class="input" name="external_account_id" required></div>
          <div class="field"><label>Meta App ID *</label><input class="input" name="meta_app_id" required autocomplete="off"></div>
          <div class="field"><label>Meta App Secret *</label><input class="input" type="password" name="meta_app_secret" required autocomplete="new-password"></div>
          <div class="field span-2"><label>Page Access Token *</label><input class="input" type="password" name="page_access_token" required autocomplete="new-password"><small>不要把 Token 发到聊天或截图公开。保存后前台不会再次显示。</small></div>
          <div class="field span-2"><button class="btn btn-primary" type="submit">保存连接并生成 Verify Token</button></div>
        </form>
      </div>
      <div class="v1361054-step-panel" data-social-step="4"><span class="card-kicker">STEP 4</span><h4>把 Webhook 填回 Meta</h4><p>保存 Step 3 后，SalonOS 会在页面顶部显示一次 Callback URL 与 Verify Token。复制到 Meta App 对应 Webhook 设置，并订阅目标 Messaging 事件。</p><div class="v1361054-copy-row"><code><?=e($socialCallbackBase)?>?connection_id=YOUR_CONNECTION_ID</code></div><div class="alert alert-warning">Verify Token 是一次性显示；如果没保存，请重新建立连接生成新的 Token。</div></div>
      <div class="v1361054-step-panel" data-social-step="5"><span class="card-kicker">STEP 5</span><h4>发送真实测试私讯</h4><p>从另一个 Instagram / Facebook 用户账号发送一条 DM。成功后回到此页，「最近收到的私讯」应该出现记录，Connection 状态会变成 Connected / live。</p><div class="alert alert-info">如果没有出现：先检查 Edge Function <code>meta-social-webhook</code> 已 Deploy、Verify JWT 已关闭，再检查 Meta Webhook 是否完成验证。</div></div>
      <div class="v1361054-wizard-nav"><button class="btn btn-light" type="button" data-social-prev disabled>上一步</button><button class="btn btn-primary" type="button" data-social-next>下一步</button></div>
      <?php else:?><div class="alert alert-info">你的职位可以查看这个设置，但只有老板可以填写 Meta App Secret / Access Token 并建立连接。</div><?php endif;?>
    </div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="social-tutorial-instagram"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1361054-tutorial-dialog"><div class="commission-modal-header"><div><span class="card-kicker">INSTAGRAM DIRECT TUTORIAL</span><h3>Instagram 私讯收录教程</h3><p>按照下面顺序做，不需要把 IG 密码交给 SalonOS。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><ol class="v1361054-tutorial-list"><li><b>准备账号</b><span>确认要收录的是门店官方 IG 或员工经营的 Professional / Business IG，并先在 SalonOS 建立对应媒体账号。</span></li><li><b>确认 Meta 资产关系</b><span>确认该 IG 与正确 Facebook Page / Business Portfolio 的关系已完成。</span></li><li><b>Meta App</b><span>在 Meta for Developers 中准备 App，启用 Instagram Messaging / Webhook 所需能力，并对目标资产授权。</span></li><li><b>回 SalonOS 填资料</b><span>选择对应 SalonOS 媒体账号，填写 IG Business Account ID、App ID、App Secret 与 Page Access Token。</span></li><li><b>Webhook</b><span>复制 SalonOS 生成的 Callback URL 与 Verify Token 到 Meta App，完成验证和事件订阅。</span></li><li><b>测试</b><span>用另一个 IG 账号发 DM；回 SalonOS 看「最近收到的私讯」。</span></li></ol><div class="alert alert-warning">如果 Meta 要求 App Review / Advanced Access，正式商用前必须按 Meta 当前要求完成。SalonOS 不会绕过平台审核。</div></div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="social-tutorial-facebook"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1361054-tutorial-dialog"><div class="commission-modal-header"><div><span class="card-kicker">FACEBOOK MESSENGER TUTORIAL</span><h3>Facebook Messenger 收录教程</h3><p>使用 Facebook Page + Meta App，而不是个人 Profile。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><ol class="v1361054-tutorial-list"><li><b>准备 Facebook Page</b><span>确认这个 Page 就是门店或员工业务身份，并先在 SalonOS 建立媒体账号映射。</span></li><li><b>准备 Meta App</b><span>在 Meta for Developers 选择正确 App，并把目标 Page 授权给 App。</span></li><li><b>Messaging / Webhook</b><span>启用 Messenger / Pages Messaging 对应 Webhook 能力。</span></li><li><b>回 SalonOS 填资料</b><span>填写 Facebook Page ID、Meta App ID、App Secret 与 Page Access Token。</span></li><li><b>Webhook 验证</b><span>把 SalonOS Callback URL / Verify Token 填到 Meta，完成验证并订阅消息事件。</span></li><li><b>测试</b><span>从另一个 Facebook 用户私讯 Page，回 SalonOS 检查最近消息。</span></li></ol><div class="alert alert-warning">Page Access、消息权限与 App Review 以 Meta 当前控制台要求为准。</div></div></section></div>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="social-manual-lead"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">MANUAL SOURCE CAPTURE</span><h3>手动收录社交来源</h3><p>Meta 还没接通时，用这个记录顾客来自哪个账号 / 员工 IP。</p></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><div class="commission-modal-content"><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_manual_social_lead_v1361054"><input type="hidden" name="return_page" value="settings_marketing"><div class="field"><label>平台 *</label><select class="select" name="platform" required><option value="instagram">Instagram</option><option value="facebook">Facebook</option><option value="tiktok">TikTok</option><option value="xhs">XHS / 小红书</option><option value="other">Other</option></select></div><div class="field"><label>来源账号 *</label><select class="select" name="social_account_id" required><option value="">选择账号</option><?php foreach($accounts as $a):?><option value="<?=e((string)$a['id'])?>"><?=e((string)$a['display_name'])?><?=!empty($a['staff_id'])?' · '.e($emp[(string)$a['staff_id']]??'员工'):''?></option><?php endforeach;?></select></div><div class="field"><label>顾客名称</label><input class="input" name="customer_name"></div><div class="field"><label>电话</label><input class="input" name="customer_phone"></div><div class="field span-2"><label>备注 / 私讯摘要</label><textarea class="textarea" name="note" rows="4" placeholder="例如：顾客从 Jason IG 私讯，询问染发价格。"></textarea></div><div class="field span-2"><button class="btn btn-primary" type="submit">保存来源线索</button></div></form></div></section></div>

    <section class="card marketing-content-center">
      <div class="card-head">
        <div><span class="card-kicker">MEDIA CONTENT & TRACKING</span><h3>三、媒体内容 & Tracking Link 管理中心</h3><p>Profile / Reel / Post / Story 都在这里管理。新增和修改统一使用小浮窗；系统自动沿账号带入平台与员工归属。</p></div>
        <button class="btn btn-primary btn-small" type="button"
          data-v1350-modal-open="marketing-tracking-editor"
          data-modal-kicker="NEW TRACKING CONTENT"
          data-modal-title="新增媒体内容 / Tracking Link"
          data-tracking-link-id="" data-content-id="" data-channel-id="" data-social-account-id="" data-staff-id=""
          data-content-type="profile" data-content-label="" data-content-code="" data-content-url=""
          data-slug="" data-ref-prefix="" data-destination-type="whatsapp" data-destination-url=""
          data-prefill-message="Hi, I would like to make an appointment." data-active="1">＋ 新增内容 / Link</button>
      </div>

      <?php if($duplicateActiveProfiles):?>
      <div class="marketing-profile-duplicate-warning">
        <strong>发现旧版本留下的重复 Profile Link</strong>
        <p>同一个媒体账号以后只允许 1 个启用中的 Profile / Bio Link。下面这些旧重复项不会被系统自动删除，避免影响历史归因；请保留你要正式使用的那一条，其余点「停用」。</p>
        <div class="marketing-profile-duplicate-list">
          <?php foreach($duplicateActiveProfiles as $dupAccountId=>$dupRows):?>
            <span class="badge badge-gold"><?=e((string)($acc[$dupAccountId]['display_name']??'媒体账号'))?> · <?=count($dupRows)?> 个启用 Profile</span>
          <?php endforeach;?>
        </div>
      </div>
      <?php endif;?>

      <div class="marketing-content-toolbar">
        <div><strong><?=count(array_filter($links,fn($x)=>!empty($x['active'])))?> 个启用中的 Tracking Link</strong><small>Link opens 仅保留作技术诊断，不当成顾客人数。</small></div>
        <span class="badge badge-green">FIRST TOUCH READY</span>
      </div>

      <div class="marketing-link-list marketing-content-link-list">
      <?php foreach($links as $r):
        $cid=(string)$r['channel_id'];$aid=(string)($r['social_account_id']??'');$coid=(string)($r['content_id']??'');$url=$base.(string)$r['slug'];
        $contentRow=$coid!==''&&isset($cont[$coid])?$cont[$coid]:[];
        $placement=(string)($r['placement']??'');
        if($placement==='')$placement=(string)($contentRow['content_type']??'profile');
        if($placement==='bio')$placement='profile';
        $contentLabel=(string)($contentRow['title']??'');
        $contentCode=(string)($contentRow['content_code']??'');
        $contentUrl=(string)($contentRow['external_url']??'');
        $typeLabel=match($placement){'profile'=>'Profile','reel'=>'Reel','post'=>'Post','story'=>'Story','ad'=>'Ad','qr'=>'QR','landing'=>'Landing',default=>ucfirst($placement?:'Other')};
      ?>
        <article class="marketing-link-row marketing-content-link-row <?=empty($r['active'])?'is-off':''?>">
          <div class="marketing-link-main">
            <div class="marketing-link-badges">
              <span class="badge badge-gold"><?=e((string)($ch[$cid]['name']??'Other'))?></span>
              <?php if($aid!==''&&isset($acc[$aid])):?><span class="badge badge-gray"><?=e((string)$acc[$aid]['display_name'])?></span><?php endif;?>
              <span class="badge badge-gray"><?=e($typeLabel)?></span>
              <?=!empty($r['active'])?'<span class="badge badge-green">ACTIVE</span>':'<span class="badge badge-gray">OFF</span>'?>
            </div>
            <strong><?=e($contentLabel!==''?$contentLabel:($placement==='profile'?'Profile / Bio':$url))?></strong>
            <a class="marketing-link-url" href="<?=e($url)?>" target="_blank" rel="noopener"><?=e($url)?></a>
            <small>
              Ref <?=e((string)$r['ref_prefix'])?>
              · <?=intval($cc[(string)$r['id']]??0)?> link opens
              <?=!empty($r['staff_id'])?' · '.e($emp[(string)$r['staff_id']]??'员工'):''?>
              <?=$contentUrl!==''?' · 原始内容已连接':''?>
            </small>
          </div>
          <div class="marketing-link-actions">
            <button class="btn btn-light btn-small" type="button" data-copy-text="<?=e($url)?>">复制链接</button>
            <a class="btn btn-light btn-small" href="<?=e($url)?>" target="_blank" rel="noopener">测试</a>
            <button class="btn btn-light btn-small" type="button"
              data-v1350-modal-open="marketing-tracking-editor"
              data-modal-kicker="EDIT TRACKING CONTENT"
              data-modal-title="修改媒体内容 / Tracking Link"
              data-tracking-link-id="<?=e((string)$r['id'])?>"
              data-content-id="<?=e($coid)?>"
              data-channel-id="<?=e($cid)?>"
              data-social-account-id="<?=e($aid)?>"
              data-staff-id="<?=e((string)($r['staff_id']??''))?>"
              data-content-type="<?=e($placement)?>"
              data-content-label="<?=e($contentLabel)?>"
              data-content-code="<?=e($contentCode)?>"
              data-content-url="<?=e($contentUrl)?>"
              data-slug="<?=e((string)$r['slug'])?>"
              data-ref-prefix="<?=e((string)$r['ref_prefix'])?>"
              data-destination-type="<?=e((string)$r['destination_type'])?>"
              data-destination-url="<?=e((string)($r['destination_url']??''))?>"
              data-prefill-message="<?=e((string)($r['prefill_message']??''))?>"
              data-active="<?=!empty($r['active'])?'1':'0'?>">修改</button>
            <?php if(!empty($r['active'])):?><form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="archive_tracking_link_v1360"><input type="hidden" name="return_page" value="settings_marketing"><input type="hidden" name="tracking_link_id" value="<?=e((string)$r['id'])?>"><button class="btn btn-light btn-small">停用</button></form><?php endif;?>
          </div>
        </article>
      <?php endforeach;?>
      <?php if(!$links):?><div class="empty">还没有 Tracking Link。按「＋ 新增内容 / Link」开始。</div><?php endif;?>
      </div>
    </section>

    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="marketing-tracking-editor">
      <div class="commission-modal-backdrop" data-v1350-modal-close></div>
      <section class="commission-modal-dialog v1350-small-modal marketing-tracking-editor-dialog">
        <div class="commission-modal-header">
          <div><span class="card-kicker" data-v1350-copy="modalKicker">TRACKING CONTENT</span><h3 data-v1350-copy="modalTitle">媒体内容 / Tracking Link</h3><p>Profile / Reel / Post / Story 用同一个小浮窗管理。第一次来源仍按 WhatsApp 手机号锁定，不会因后续平台点击而覆盖。</p></div>
          <button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button>
        </div>
        <div class="commission-modal-content">
          <form method="post" class="marketing-tracking-modal-form" data-marketing-tracking-form>
            <input type="hidden" name="csrf" value="<?=csrf_token()?>">
            <input type="hidden" name="action" value="save_tracking_link_v1360">
            <input type="hidden" name="return_page" value="settings_marketing">
            <input type="hidden" name="tracking_link_id" value="" data-bind="trackingLinkId">
            <input type="hidden" name="content_id" value="" data-bind="contentId">

            <div class="form-grid">
              <div class="field"><label>平台 *</label><select class="select" name="channel_id" required data-bind="channelId" data-marketing-tracking-channel><option value="">选择平台</option><?php foreach($channels as $r):?><option value="<?=e((string)$r['id'])?>"><?=e((string)$r['name'])?><?=empty($r['active'])?'（已停用）':''?></option><?php endforeach;?></select></div>

              <div class="field"><label>媒体账号</label><select class="select" name="social_account_id" data-bind="socialAccountId" data-marketing-tracking-account><option value="">无指定账号 / Direct</option><?php foreach($accounts as $r):?><option value="<?=e((string)$r['id'])?>" data-channel-id="<?=e((string)$r['channel_id'])?>" data-staff-id="<?=e((string)($r['staff_id']??''))?>" data-account-seed="<?=e(ltrim((string)($r['username']??$r['display_name']??''),'@'))?>"><?=e((string)$r['display_name'])?><?=!empty($r['username'])?' · '.e((string)$r['username']):''?><?=empty($r['active'])?'（已停用）':''?></option><?php endforeach;?></select><small class="field-help">选择账号后会自动带入平台与对应员工。</small></div>

              <div class="field"><label>来源员工</label><select class="select" name="staff_id" data-bind="staffId" data-marketing-tracking-staff><option value="">无 / 从账号自动判断</option><?php foreach($employees as $e):?><option value="<?=e((string)($e['id']??''))?>"><?=e((string)($e['name']??$e['full_name']??'员工'))?></option><?php endforeach;?></select></div>

              <div class="field"><label>位置 / 内容类型 *</label><select class="select" name="content_type" data-bind="contentType" data-marketing-content-type><option value="profile">Profile / Bio（每账号仅 1 个启用）</option><option value="reel">Reel</option><option value="post">Post</option><option value="story">Story</option><option value="ad">Ad</option><option value="qr">QR</option><option value="landing">Landing Page</option><option value="other">Other</option></select></div>

              <div class="field" data-marketing-content-field><label>内容名称 *</label><input class="input" name="content_label" placeholder="例如 Hair Color Reel 001" data-bind="contentLabel" data-marketing-content-label><small class="field-help">Profile / Bio 不必填写；Reel / Post / Story 建议用看得懂的名称。</small></div>
              <div class="field" data-marketing-content-field><label>Content Code（选填）</label><input class="input" name="content_code" placeholder="例如 JASON-R001" data-bind="contentCode"></div>

              <div class="field span-2" data-marketing-content-field><label>原始内容 URL（选填）</label><input class="input" name="content_url" placeholder="https://instagram.com/reel/..." data-bind="contentUrl"></div>

              <div class="field"><label>短链 Slug</label><input class="input" name="slug" placeholder="自动产生，也可以自己修改" data-bind="slug" data-marketing-slug><small class="field-help">最终链接：<?=e($base)?><span data-marketing-slug-preview>...</span></small></div>
              <div class="field"><label>Ref Prefix</label><input class="input" name="ref_prefix" placeholder="留空会跟 Slug 自动产生" data-bind="refPrefix"></div>

              <div class="field"><label>最终去向</label><select class="select" name="destination_type" data-bind="destinationType" data-marketing-destination-type><option value="whatsapp">WhatsApp Business</option><option value="url">Website / URL</option></select></div>
              <div class="field" data-marketing-whatsapp-field><label>当前分行 WhatsApp Business</label><input class="input" name="destination_phone" inputmode="tel" value="<?=e($defaultPhone)?>" readonly><small class="field-help">不会从媒体账号取号码；统一走当前分行已连接的 WhatsApp Business。</small></div>

              <div class="field span-2" data-marketing-url-field hidden><label>Website URL *</label><input class="input" name="destination_url" placeholder="https://..." data-bind="destinationUrl"></div>

              <div class="field span-2" data-marketing-whatsapp-field><label>WhatsApp 预填文字</label><textarea class="textarea" name="prefill_message" rows="3" data-bind="prefillMessage">Hi, I would like to make an appointment.</textarea><small class="field-help">系统跳转时会自动附加唯一 Ref；顾客不需要自己填写来源。</small></div>

              <div class="field span-2"><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" checked data-bind="active"><span>启用这个 Tracking Link（取消勾选 = 停用；之后仍可修改再启用）</span></label></div>
            </div>

            <div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary" type="submit">保存内容 / Link</button></div>
          </form>
        </div>
      </section>
    </div>
    <?php
}

function v132_tunaipro_label(string $type): string {return match($type){'product'=>'产品','package'=>'产品配套','service'=>'服务项目','member'=>'会员资料',default=>'CSV'};}
function v132_csv_headers(array $row): array {return array_map(fn($v)=>strtolower(trim(preg_replace('/^\xEF\xBB\xBF/','',(string)$v))),$row);}
function v132_parse_tunaipro(string $path,string $type): array {
    if(!is_file($path))throw new RuntimeException('找不到上传的 CSV。');$h=fopen($path,'rb');if(!$h)throw new RuntimeException('无法读取 CSV。');
    $required=$type==='member'?['member name','member phone number']:['skuid','sku name'];$headers=[];$line=0;$rows=[];$invalid=[];
    while(($r=fgetcsv($h))!==false&&$line<80){$line++;$n=v132_csv_headers($r);if(!array_diff($required,$n)){$headers=$n;break;}}
    if(!$headers){fclose($h);throw new RuntimeException('找不到 Tunaipro 标题列。');}
    while(($v=fgetcsv($h))!==false){$line++;if(count($v)===1&&trim((string)$v[0])==='')continue;$v=array_pad($v,count($headers),'');$raw=array_combine($headers,array_slice($v,0,count($headers)));
      if($type==='member'){$name=trim((string)($raw['member name']??''));$phone=v132_normalize_phone((string)($raw['member phone number']??''));if($name===''||$phone===''){$invalid[]="第 {$line} 行缺少姓名/电话";continue;}$rows[]=['name'=>$name,'phone'=>$phone,'email'=>trim((string)($raw['email']??'')),'ethnicity'=>trim((string)($raw['ethnic']??'')),'address'=>trim((string)($raw['address']??'')),'gender'=>tunaipro_member_gender($raw['gender']??''),'birth_date'=>tunaipro_date_value($raw['birthday']??'',true)];continue;}
      $id=trim((string)($raw['skuid']??''));$name=trim((string)($raw['sku name']??''));if($id===''||$name===''){$invalid[]="第 {$line} 行缺少 skuID / sku name";continue;}$num=fn($x)=>(float)(preg_replace('/[^0-9.\-]/','',(string)$x)?:0);$section=trim((string)($raw['section name']??''));$folder=trim((string)($raw['folder name']??''));$cat=$section?:($folder?:'其他');$rows[]=['external_id'=>$id,'name'=>$name,'sale_price'=>max(0,$num($raw['selling price']??0)),'cost_price'=>max(0,$num($raw['base price']??0)),'category'=>$cat,'barcode'=>trim((string)($raw['barcode']??'')),'duration'=>max(1,(int)round($num($raw['duration']??60))),'active'=>strtolower(trim((string)($raw['status']??'')))!=='disabled'];
    } fclose($h);return ['rows'=>$rows,'invalid'=>$invalid];
}
function tunaipro_member_gender(mixed $value): string {$v=strtolower(trim((string)$value));return in_array($v,['male','m','man','男'],true)?'male':(in_array($v,['female','f','woman','女'],true)?'female':'unspecified');}
function tunaipro_date_value(mixed $value,bool $birthday=false): ?string {$v=trim((string)$value);if($v===''||$v==='01/01/0000'||$v==='00/00/0000')return null;foreach(['!d/m/Y','!d-m-Y','!Y-m-d'] as $f){$d=DateTime::createFromFormat($f,$v);if($d&&(!$birthday||$d<=new DateTime('today'))&&(int)$d->format('Y')>=1900)return $d->format('Y-m-d');}return null;}
function v132_prepare_tunaipro_preview(): void {
    if(empty($_FILES['csv_file'])||!is_uploaded_file($_FILES['csv_file']['tmp_name']))throw new RuntimeException('请选择 CSV 文件。');
    $type=in_array((string)($_POST['import_type']??''),['product','package','service','member'],true)?(string)$_POST['import_type']:'product';
    if((int)($_FILES['csv_file']['size']??0)>5*1024*1024)throw new RuntimeException('CSV 最大 5MB。');
    $token=bin2hex(random_bytes(12));$path=sys_get_temp_dir().DIRECTORY_SEPARATOR.'salonos_v132_'.$token.'.csv';if(!move_uploaded_file($_FILES['csv_file']['tmp_name'],$path))throw new RuntimeException('暂存 CSV 失败。');
    $parsed=v132_parse_tunaipro($path,$type);$_SESSION['v132_import_preview']=['token'=>$token,'path'=>$path,'type'=>$type,'name'=>(string)($_FILES['csv_file']['name']??'import.csv'),'created_at'=>time(),'count'=>count($parsed['rows'])];
    $_SESSION['v132_import_preview_rows']=$parsed['rows'];$_SESSION['v132_import_preview_invalid']=$parsed['invalid'];flash('success','CSV 已完成预览；确认后才会写入 Supabase。');
}
function v132_confirm_tunaipro_import(): void {
    $entry=$_SESSION['v132_import_preview']??null;$rows=$_SESSION['v132_import_preview_rows']??null;if(!is_array($entry)||!is_array($rows)||time()-(int)($entry['created_at']??0)>3600)throw new RuntimeException('导入预览已过期，请重新上传。');
    $type=(string)$entry['type'];$existingProducts=$type==='product'?v13_product_rows(false):[];$pBy=[];foreach($existingProducts as $p)$pBy[(string)$p['sku']]=$p;$existingBundles=$type==='package'?v13_owner_rows('v13_product_bundles','select=id,sku,name&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&limit=2000'):[];$bBy=[];foreach($existingBundles as $b)$bBy[(string)($b['sku']??'')]=$b;
    $existingServices=$type==='service'?v13_service_rows(false):[];$sBy=[];foreach($existingServices as $s)$sBy[mb_strtolower((string)$s['category'].'|'.(string)$s['name'])]=$s;
    $existingCustomers=$type==='member'?v13_customer_rows_owner(''):[];$cBy=[];foreach($existingCustomers as $c)$cBy[v132_normalize_phone((string)($c['phone']??''))]=$c;
    $ok=0;$updated=0;$errors=0;foreach($rows as $row){try{
      if($type==='product'){$sku='TN-'.preg_replace('/[^A-Za-z0-9_-]/','',(string)$row['external_id']);$body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'sku'=>$sku,'barcode'=>$row['barcode']?:null,'name'=>$row['name'],'category'=>$row['category']?:null,'sale_price'=>$row['sale_price'],'cost_price'=>$row['cost_price'],'default_commission_rate'=>0,'reorder_level'=>0,'purpose'=>'Tunaipro import','retail_enabled'=>true,'stock_enabled'=>true,'active'=>(bool)$row['active'],'updated_at'=>date(DATE_ATOM)];if(isset($pBy[$sku])){v13_owner_write('products','id=eq.'.rawurlencode((string)$pBy[$sku]['id']),'PATCH',$body);$updated++;}else{v13_owner_write('products','','POST',$body);$ok++;}}
      elseif($type==='package'){$sku='TNP-'.preg_replace('/[^A-Za-z0-9_-]/','',(string)$row['external_id']);$body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'sku'=>$sku,'name'=>$row['name'],'sale_price'=>$row['sale_price'],'active'=>false,'updated_at'=>date(DATE_ATOM)];if(isset($bBy[$sku])){v13_owner_write('v13_product_bundles','id=eq.'.rawurlencode((string)$bBy[$sku]['id']),'PATCH',$body);$updated++;}else{v13_owner_write('v13_product_bundles','','POST',$body);$ok++;}}
      elseif($type==='service'){$key=mb_strtolower($row['category'].'|'.$row['name']);$body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'category'=>$row['category'],'name'=>$row['name'],'default_price'=>$row['sale_price'],'estimated_minutes'=>$row['duration'],'allows_assistant'=>true,'active'=>(bool)$row['active'],'updated_at'=>date(DATE_ATOM)];if(isset($sBy[$key])){v13_owner_write('services','id=eq.'.rawurlencode((string)$sBy[$key]['id']),'PATCH',$body);$updated++;}else{v13_owner_write('services','','POST',$body);$ok++;}}
      else{$phone=$row['phone'];$body=['organization_id'=>v13_org_uuid(),'store_id'=>v13_store_uuid(),'name'=>$row['name'],'phone'=>$phone,'gender'=>$row['gender'],'birth_date'=>$row['birth_date'],'ethnicity'=>$row['ethnicity']?:null,'email'=>$row['email']?:null,'address'=>$row['address']?:null,'updated_at'=>date(DATE_ATOM)];if(isset($cBy[$phone])){$cid=(string)$cBy[$phone]['id'];v13_owner_write('customers','id=eq.'.rawurlencode($cid),'PATCH',$body);$updated++;}else{$created=v13_owner_write('customers','','POST',$body);$cid=(string)($created[0]['id']??'');$ok++;}if($cid!==''){try{salonos_supabase_create_membership_for_customer($cid);}catch(Throwable $ignore){}}}
    }catch(Throwable $e){$errors++;}}
    if(!empty($entry['path']))@unlink((string)$entry['path']);unset($_SESSION['v132_import_preview'],$_SESSION['v132_import_preview_rows'],$_SESSION['v132_import_preview_invalid']);flash($errors?'error':'success',"导入完成：新增 {$ok}、更新 {$updated}、失败 {$errors}。");
}

function v13611_marketing_analytics_dataset(): array {
    if(!v13_is_owner()) return [];
    $range=function_exists('v135_analysis_range')?v135_analysis_range():['period'=>'month','anchor'=>date('Y-m-d'),'label'=>'本期','start_utc'=>gmdate('c',strtotime('-30 days')),'end_utc'=>gmdate('c',strtotime('+1 day'))];
    $org=v13_org_uuid();$store=v13_store_uuid();
    $base='organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store);

    // Cohort rule: one immutable WhatsApp first-touch phone acquired inside the selected period.
    // All later outcomes are attributed back to that first source; raw link opens never affect customer counts.
    $firstTouches=function_exists('v136109_first_touch_rows')?v136109_first_touch_rows($range):[];
    $links=v13_owner_rows('tracking_links','select=*&'.$base.'&limit=5000');
    $channels=v13_owner_rows('marketing_channels','select=*&'.$base.'&limit=1000');
    $accounts=v13_owner_rows('social_accounts','select=*&'.$base.'&limit=5000');
    $contents=v13_owner_rows('marketing_contents','select=*&'.$base.'&limit=10000');
    $employees=v13_owner_rows('employees','select=id,name&organization_id=eq.'.rawurlencode($org).'&limit=5000');
    $lm=[];$cm=[];$am=[];$xm=[];$em=[];
    foreach($links as $x)$lm[(string)$x['id']]=$x;
    foreach($channels as $x)$cm[(string)$x['id']]=$x;
    foreach($accounts as $x)$am[(string)$x['id']]=$x;
    foreach($contents as $x)$xm[(string)$x['id']]=$x;
    foreach($employees as $x)$em[(string)$x['id']]=$x;

    $ftByPhone=[];$cohortPhones=[];$closedLoopCustomerPhones=[];$closedLoopVisitPhones=[];
    foreach($firstTouches as $ft){
        $phone=v136109_normalize_phone((string)($ft['normalized_phone']??$ft['customer_phone']??''));
        if($phone==='')continue;
        $ftByPhone[$phone]=$ft;$cohortPhones[$phone]=true;
    }

    // Resolve the acquired phone cohort to canonical SalonOS customers.
    // We scope visit lookups by those customer IDs instead of downloading every visit in the branch.
    $customerPhoneById=[];$customerIdByPhone=[];$customerProfileByPhone=[];
    try{
        foreach(v13_owner_rows('customers','select=id,name,phone,gender,birth_date,ethnicity&'.$base.'&limit=50000') as $c){
            $id=(string)($c['id']??'');$norm=v136109_normalize_phone((string)($c['phone']??''));
            if($id!==''&&$norm!==''){
                $customerPhoneById[$id]=$norm;
                if(!isset($customerIdByPhone[$norm]))$customerIdByPhone[$norm]=$id;
                if(!isset($customerProfileByPhone[$norm]))$customerProfileByPhone[$norm]=$c;
            }
        }
    }catch(Throwable $ignore){}
    $cohortCustomerIds=[];
    foreach($ftByPhone as $phone=>$ft){
        $cid=trim((string)($ft['customer_id']??''));
        if($cid===''&&isset($customerIdByPhone[$phone]))$cid=$customerIdByPhone[$phone];
        if($cid!==''){
            $cohortCustomerIds[$cid]=$phone;
            $customerPhoneById[$cid]=$phone;
            $closedLoopCustomerPhones[$phone]=true;
        }
    }

    // Canonical customer ↔ visit relation lives in visit_recipients. Fetch only recipients for the acquired cohort.
    $visitPhone=[];$candidateVisitIds=[];
    if($cohortCustomerIds){
        foreach(array_chunk(array_keys($cohortCustomerIds),120) as $chunk){
            try{
                $q='select=visit_id,customer_id,phone_snapshot,recipient_type&organization_id=eq.'.rawurlencode($org).'&recipient_type=eq.primary&customer_id=in.'.v135_in_filter($chunk).'&limit=5000';
                foreach(v13_owner_rows('visit_recipients',$q) as $r){
                    $vid=(string)($r['visit_id']??'');$cid=(string)($r['customer_id']??'');if($vid==='')continue;
                    $phone=$cohortCustomerIds[$cid]??v136109_normalize_phone((string)($r['phone_snapshot']??''));
                    if($phone!==''&&isset($cohortPhones[$phone])){$visitPhone[$vid]=$phone;$candidateVisitIds[$vid]=true;}
                }
            }catch(Throwable $ignore){}
        }
    }

    // Fallback: a WhatsApp lead can already carry visit_id before customer_id is attached. Include those known visits too.
    try{
        foreach(v13_owner_rows('marketing_leads','select=customer_phone,visit_id&'.$base.'&visit_id=not.is.null&limit=50000') as $l){
            $phone=v136109_normalize_phone((string)($l['customer_phone']??''));$vid=trim((string)($l['visit_id']??''));
            if($phone!==''&&$vid!==''&&isset($cohortPhones[$phone])){
                $visitPhone[$vid]=$phone;
                $candidateVisitIds[$vid]=true;
                $closedLoopVisitPhones[$phone]=true;
            }
        }
    }catch(Throwable $ignore){}

    $visits=[];$prefs=[];$paymentsByVisit=[];
    if($candidateVisitIds){
        foreach(array_chunk(array_keys($candidateVisitIds),120) as $chunk){
            $in=v135_in_filter($chunk);
            try{foreach(v13_owner_rows('visits','select=id,status,visit_type,customer_id,scheduled_at,arrived_at,checked_out_at,created_at&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&id=in.'.$in.'&limit=5000') as $v)$visits[(string)$v['id']]=$v;}catch(Throwable $ignore){}
            try{foreach(v13_owner_rows('appointment_employee_preferences','select=visit_id,preference_type,employee_id&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&visit_id=in.'.$in.'&limit=5000') as $pr)$prefs[(string)($pr['visit_id']??'')]=$pr;}catch(Throwable $ignore){}
            try{
                foreach(v13_owner_rows('payments','select=visit_id,grand_total,status,paid_at&organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&status=eq.paid&visit_id=in.'.$in.'&limit=5000') as $p){
                    $vid=(string)($p['visit_id']??'');$paymentsByVisit[$vid]=($paymentsByVisit[$vid]??0)+(float)($p['grand_total']??0);
                }
            }catch(Throwable $ignore){}
        }
    }

    $outcomes=[];
    foreach(array_keys($cohortPhones) as $phone)$outcomes[$phone]=[
        'bookings'=>0,'arrived_visits'=>0,'completed_visits'=>0,'specified'=>0,'random'=>0,'revenue'=>0.0,
        'booked_customer'=>0,'arrived_customer'=>0,'repeat_customer'=>0,'loyal_customer'=>0
    ];

    foreach($visits as $vid=>$v){
        $phone=$visitPhone[$vid]??'';if($phone===''||!isset($cohortPhones[$phone]))continue;
        $firstAt=v1344_local_dt((string)($ftByPhone[$phone]['first_message_at']??''));
        $visitAt=v1344_local_dt((string)($v['scheduled_at']??$v['created_at']??$v['arrived_at']??$v['checked_out_at']??''));
        if($firstAt&&$visitAt&&$visitAt<$firstAt)continue; // never attribute pre-acquisition history to a later media touch.

        $status=strtolower((string)($v['status']??''));
        if((string)($v['visit_type']??'walk_in')==='appointment')$outcomes[$phone]['bookings']++;
        if(!empty($v['arrived_at'])||in_array($status,['arrived','waiting','in_service','ready_for_checkout','completed'],true))$outcomes[$phone]['arrived_visits']++;
        $isCompleted=$status==='completed'||isset($paymentsByVisit[$vid]);
        if($isCompleted){
            $outcomes[$phone]['completed_visits']++;
            $ptype=strtolower((string)(($prefs[$vid]['preference_type']??'random')));
            if($ptype==='specified')$outcomes[$phone]['specified']++;else $outcomes[$phone]['random']++;
        }
        $outcomes[$phone]['revenue']+=(float)($paymentsByVisit[$vid]??0);
    }
    $closedLoopPaidPhones=[];
    foreach($outcomes as $phone=>&$o){
        $o['booked_customer']=$o['bookings']>0?1:0;
        $o['arrived_customer']=$o['arrived_visits']>0?1:0;
        $o['repeat_customer']=$o['completed_visits']>=2?1:0;
        $o['loyal_customer']=($o['completed_visits']>=2&&$o['specified']>$o['random'])?1:0;
        if((float)$o['revenue']>0)$closedLoopPaidPhones[$phone]=true;
    }unset($o);

    $closedLoopBridgeReady=false;
    $closedLoopHealth=[
        'first_touch_customers'=>count($ftByPhone),
        'customer_linked'=>count($closedLoopCustomerPhones),
        'visit_linked_customers'=>count($closedLoopVisitPhones),
        'arrived_customers'=>0,
        'paid_customers'=>count($closedLoopPaidPhones),
        'revenue'=>0.0,
        'bridge_version'=>''
    ];
    try{
        $health=v13_rpc_json(
            'v13619_closed_loop_health',
            [
                'p_organization_id'=>$org,
                'p_store_id'=>$store,
                'p_start_at'=>(string)$range['start_utc'],
                'p_end_at'=>(string)$range['end_utc']
            ],
            v13_owner_token_required_all()
        );
        if(!empty($health['ok'])){
            $closedLoopHealth=array_merge($closedLoopHealth,$health);
            $closedLoopBridgeReady=!empty($health['bridge_ready']);
        }
    }catch(Throwable $ignore){
        // v13.6.10.18 fallback: old UI can still render until the 10.19 RPC SQL is installed.
    }

    // v13.6.10.21: canonical per-customer lifecycle source of truth.
    // CLOSED LOOP HEALTH already proved the DB can see the real Visits/Payments.
    // Use the same SECURITY DEFINER approach for the detailed outcomes that power
    // KPI cards, funnel, content performance and source rankings.
    $lifecycleRpcReady=false;
    try{
        $life=v13_rpc_json(
            'v13621_marketing_lifecycle_rows',
            [
                'p_organization_id'=>$org,
                'p_store_id'=>$store,
                'p_start_at'=>(string)$range['start_utc'],
                'p_end_at'=>(string)$range['end_utc']
            ],
            v13_owner_token_required_all()
        );
        if(!empty($life['ok']) && is_array($life['rows']??null)){
            foreach($life['rows'] as $row){
                if(!is_array($row))continue;
                $phone=v136109_normalize_phone((string)($row['normalized_phone']??''));
                if($phone===''||!isset($outcomes[$phone]))continue;
                $outcomes[$phone]=[
                    'bookings'=>(int)($row['bookings']??0),
                    'arrived_visits'=>(int)($row['arrived_visits']??0),
                    'completed_visits'=>(int)($row['completed_visits']??0),
                    'specified'=>(int)($row['specified']??0),
                    'random'=>(int)($row['random']??0),
                    'revenue'=>(float)($row['revenue']??0),
                    'booked_customer'=>(int)($row['booked_customer']??0),
                    'arrived_customer'=>(int)($row['arrived_customer']??0),
                    'repeat_customer'=>(int)($row['repeat_customer']??0),
                    'loyal_customer'=>(int)($row['loyal_customer']??0)
                ];
            }
            $lifecycleRpcReady=true;
        }
    }catch(Throwable $ignore){
        // Keep the old PHP join as a temporary fallback until the 10.21 RPC is installed.
    }

    $rawLinkOpens=0;$linkOpenCounts=[];
    try{
        $clickRows=v13_owner_rows(
            'tracking_clicks',
            'select=id,tracking_link_id&'.$base.
            '&clicked_at=gte.'.rawurlencode($range['start_utc']).
            '&clicked_at=lt.'.rawurlencode($range['end_utc']).
            '&limit=50000'
        );
        $rawLinkOpens=count($clickRows);
        foreach($clickRows as $clickRow){
            $tid=(string)($clickRow['tracking_link_id']??'');
            if($tid!=='')$linkOpenCounts[$tid]=($linkOpenCounts[$tid]??0)+1;
        }
    }catch(Throwable $ignore){}

    $groups=[];
    $make=function(array $ft)use($lm,$cm,$am,$xm,$em){
        $link=$lm[(string)($ft['tracking_link_id']??'')]??[];
        $channelId=(string)($ft['channel_id']??$link['channel_id']??'');
        $accId=(string)($ft['social_account_id']??$link['social_account_id']??'');
        $contentId=(string)($ft['content_id']??$link['content_id']??'');
        $staffId=(string)($ft['staff_id']??$link['staff_id']??($am[$accId]['staff_id']??''));
        $placement=trim((string)($link['placement']??''));
        if($placement==='')$placement=trim((string)($xm[$contentId]['content_type']??''));
        if($placement==='')$placement=$accId!==''?'profile':'direct';
        $channel=(string)($cm[$channelId]['name']??'Unknown');
        $account=(string)($am[$accId]['display_name']??'Store / Direct');
        $staff=(string)($em[$staffId]['name']??'—');
        $key=$channelId.'|'.$accId.'|'.$staffId.'|'.$placement;
        return [$key,[
            'channel'=>$channel,'account'=>$account,'staff'=>$staff,'placement'=>$placement,
            'customers'=>0,'booked_customers'=>0,'bookings'=>0,'arrived_customers'=>0,'arrived_visits'=>0,
            'repeat_customers'=>0,'loyal_customers'=>0,'completed_visits'=>0,'revenue'=>0.0
        ]];
    };

    $contentGroups=[];
    $makeContent=function(array $ft)use($lm,$cm,$am,$xm,$em,$linkOpenCounts){
        $linkId=(string)($ft['tracking_link_id']??'');
        $link=$lm[$linkId]??[];
        $channelId=(string)($ft['channel_id']??$link['channel_id']??'');
        $accId=(string)($ft['social_account_id']??$link['social_account_id']??'');
        $contentId=(string)($ft['content_id']??$link['content_id']??'');
        $staffId=(string)($ft['staff_id']??$link['staff_id']??($am[$accId]['staff_id']??''));
        $placement=strtolower(trim((string)($link['placement']??'')));
        if($placement==='bio')$placement='profile';
        if($placement==='')$placement=strtolower(trim((string)($xm[$contentId]['content_type']??'')));
        if($placement==='bio')$placement='profile';
        if($placement==='')$placement=$accId!==''?'profile':'direct';

        $contentRow=$contentId!==''?($xm[$contentId]??[]):[];
        $title=trim((string)($contentRow['title']??''));
        if($title===''){
            $title=$placement==='profile'?'Profile / Bio':(
                $placement==='direct'?'Direct / Unknown':ucfirst($placement)
            );
        }

        $channel=(string)($cm[$channelId]['name']??'Unknown');
        $account=(string)($am[$accId]['display_name']??'Store / Direct');
        $staff=(string)($em[$staffId]['name']??'—');
        $slug=(string)($link['slug']??'');
        $externalUrl=(string)($contentRow['external_url']??'');
        $key=$linkId!==''?'link:'.$linkId:'direct:'.$channelId.'|'.$accId.'|'.$staffId.'|'.$placement;

        $linkActive=$linkId!=='' ? !empty($link['active']) : true;
        return [$key,[
            'tracking_link_id'=>$linkId,'content_id'=>$contentId,'title'=>$title,'placement'=>$placement,
            'channel'=>$channel,'account'=>$account,'staff'=>$staff,'slug'=>$slug,'external_url'=>$externalUrl,
            'link_active'=>$linkActive,'lifecycle_status'=>$linkActive?'active':'historical',
            'customers'=>0,'booked_customers'=>0,'bookings'=>0,'arrived_customers'=>0,'arrived_visits'=>0,
            'repeat_customers'=>0,'loyal_customers'=>0,'completed_visits'=>0,'revenue'=>0.0,
            'link_opens'=>(int)($linkOpenCounts[$linkId]??0),'first_touch_at'=>'','last_touch_at'=>'','customers_detail'=>[]
        ]];
    };

    $matched=0;$bookedCustomers=0;$bookingTotal=0;$arrivedCustomers=0;$arrivedVisitTotal=0;$repeatCustomers=0;$loyalCustomers=0;$completedTotal=0;$revenueTotal=0.0;
    foreach($ftByPhone as $phone=>$ft){
        [$k,$seed]=$make($ft);if(!isset($groups[$k]))$groups[$k]=$seed;
        [$contentKey,$contentSeed]=$makeContent($ft);if(!isset($contentGroups[$contentKey]))$contentGroups[$contentKey]=$contentSeed;

        $o=$outcomes[$phone]??['bookings'=>0,'arrived_visits'=>0,'completed_visits'=>0,'revenue'=>0,'booked_customer'=>0,'arrived_customer'=>0,'repeat_customer'=>0,'loyal_customer'=>0];

        foreach([['group',$k],['content',$contentKey]] as [$bucket,$bucketKey]){
            if($bucket==='group')$target=&$groups[$bucketKey];else $target=&$contentGroups[$bucketKey];
            $target['customers']++;
            $target['booked_customers']+=(int)$o['booked_customer'];$target['bookings']+=(int)$o['bookings'];
            $target['arrived_customers']+=(int)$o['arrived_customer'];$target['arrived_visits']+=(int)$o['arrived_visits'];
            $target['repeat_customers']+=(int)$o['repeat_customer'];$target['loyal_customers']+=(int)$o['loyal_customer'];
            $target['completed_visits']+=(int)$o['completed_visits'];$target['revenue']+=(float)$o['revenue'];
            unset($target);
        }

        $profile=$customerProfileByPhone[$phone]??[];
        $displayPhone=(string)($profile['phone']??$ft['customer_phone']??$phone);
        $touchAt=(string)($ft['first_message_at']??$ft['created_at']??'');
        if($touchAt!==''){
            if((string)($contentGroups[$contentKey]['first_touch_at']??'')==='' || strcmp($touchAt,(string)$contentGroups[$contentKey]['first_touch_at'])<0){
                $contentGroups[$contentKey]['first_touch_at']=$touchAt;
            }
            if((string)($contentGroups[$contentKey]['last_touch_at']??'')==='' || strcmp($touchAt,(string)$contentGroups[$contentKey]['last_touch_at'])>0){
                $contentGroups[$contentKey]['last_touch_at']=$touchAt;
            }
        }

        $contentGroups[$contentKey]['customers_detail'][]=[
            'name'=>(string)($profile['name']??'WhatsApp Customer'),
            'phone'=>$displayPhone,
            'first_message_at'=>(string)($ft['first_message_at']??$ft['created_at']??''),
            'booked'=>(int)$o['booked_customer'],
            'arrived'=>(int)$o['arrived_customer'],
            'repeat'=>(int)$o['repeat_customer'],
            'loyal'=>(int)$o['loyal_customer'],
            'revenue'=>(float)$o['revenue']
        ];

        if(($ft['attribution_status']??'')==='matched'||!empty($ft['channel_id']))$matched++;
        $bookedCustomers+=(int)$o['booked_customer'];$bookingTotal+=(int)$o['bookings'];$arrivedCustomers+=(int)$o['arrived_customer'];$arrivedVisitTotal+=(int)$o['arrived_visits'];
        $repeatCustomers+=(int)$o['repeat_customer'];$loyalCustomers+=(int)$o['loyal_customer'];$completedTotal+=(int)$o['completed_visits'];$revenueTotal+=(float)$o['revenue'];
    }
    uasort($groups,fn($a,$b)=>($b['revenue']<=>$a['revenue'])?:($b['customers']<=>$a['customers']));
    uasort($contentGroups,fn($a,$b)=>($b['revenue']<=>$a['revenue'])?:($b['arrived_customers']<=>$a['arrived_customers'])?:($b['customers']<=>$a['customers']));

    $aggregate=function(array $rows,string $kind): array {
        $out=[];
        foreach($rows as $g){
            if($kind==='channel'){$key=$g['channel'];$label=$g['channel'];$meta=[];}
            elseif($kind==='staff'){$label=$g['staff'];if($label==='—'||$label==='')continue;$key=$label;$meta=['staff'=>$label];}
            else{$label=$g['account'];if($label==='Store / Direct'||$label==='')continue;$key=$g['channel'].'|'.$label;$meta=['channel'=>$g['channel'],'account'=>$label];}
            if(!isset($out[$key]))$out[$key]=array_merge(['label'=>$label,'customers'=>0,'booked_customers'=>0,'bookings'=>0,'arrived_customers'=>0,'arrived_visits'=>0,'repeat_customers'=>0,'loyal_customers'=>0,'completed_visits'=>0,'revenue'=>0.0],$meta);
            foreach(['customers','booked_customers','bookings','arrived_customers','arrived_visits','repeat_customers','loyal_customers','completed_visits'] as $f)$out[$key][$f]+=(int)$g[$f];
            $out[$key]['revenue']+=(float)$g['revenue'];
        }
        uasort($out,fn($a,$b)=>($b['revenue']<=>$a['revenue'])?:($b['customers']<=>$a['customers']));
        return $out;
    };
    $channelSummary=$aggregate($groups,'channel');
    $staffSummary=$aggregate($groups,'staff');
    $accountSummary=$aggregate($groups,'account');

    $customerTotal=count($ftByPhone);
    $contentPerformance=array_filter(
        $contentGroups,
        fn($g)=>(string)($g['placement']??'direct')!=='direct' && (
            (string)($g['tracking_link_id']??'')!=='' || (string)($g['account']??'')!=='Store / Direct'
        )
    );

    return [
        'range'=>$range,'groups'=>$groups,'channels'=>$channelSummary,'staff'=>$staffSummary,'accounts'=>$accountSummary,
        'content_performance'=>$contentPerformance,
        'summary'=>[
            'customers'=>$customerTotal,'matched'=>$matched,'booked_customers'=>$bookedCustomers,'bookings'=>$bookingTotal,
            'arrived_customers'=>$arrivedCustomers,'arrived_visits'=>$arrivedVisitTotal,'repeat_customers'=>$repeatCustomers,
            'loyal_customers'=>$loyalCustomers,'completed_visits'=>$completedTotal,'revenue'=>$revenueTotal,'raw_link_opens'=>$rawLinkOpens,
            'avg_revenue_per_customer'=>$customerTotal>0?$revenueTotal/$customerTotal:0,
            'closed_loop_customer_linked'=>(int)($closedLoopHealth['customer_linked']??count($closedLoopCustomerPhones)),
            'closed_loop_visit_linked'=>(int)($closedLoopHealth['visit_linked_customers']??count($closedLoopVisitPhones)),
            'closed_loop_arrived_customers'=>(int)($closedLoopHealth['arrived_customers']??0),
            'closed_loop_paid_customers'=>(int)($closedLoopHealth['paid_customers']??count($closedLoopPaidPhones)),
            'closed_loop_revenue'=>(float)($closedLoopHealth['revenue']??0),
            'closed_loop_bridge_version'=>(string)($closedLoopHealth['bridge_version']??''),
            'closed_loop_bridge_ready'=>$closedLoopBridgeReady,
            'lifecycle_rpc_ready'=>$lifecycleRpcReady
        ]
    ];
}

function v13611_page_marketing_analytics(): void {
    if(!v13_is_owner()){
        echo '<section class="card" style="padding:24px"><h2>Marketing 来源分析</h2><p>仅老板可查看。</p></section>';
        return;
    }

    $d=v13611_marketing_analytics_dataset();
    $r=$d['range'];
    $period=(string)($r['period']??'month');
    $anchor=(string)($r['anchor']??date('Y-m-d'));

    // v13.6.10.17 — owner filters and ranking controls.
    $channelFilter=trim((string)($_GET['channel']??''));
    $staffFilter=trim((string)($_GET['source_staff']??''));
    $placementFilter=strtolower(trim((string)($_GET['placement']??'')));
    $sortKey=strtolower(trim((string)($_GET['rank_by']??'revenue')));
    $allowedSort=['customers','booked','arrived','revenue','repeat_rate','loyal'];
    if(!in_array($sortKey,$allowedSort,true))$sortKey='revenue';

    $sortLabels=[
        'customers'=>'顾客最多',
        'booked'=>'预约最多',
        'arrived'=>'到店最多',
        'revenue'=>'Revenue 最高',
        'repeat_rate'=>'回头率最高',
        'loyal'=>'忠诚客最多',
    ];

    $allGroups=(array)($d['groups']??[]);
    $allContent=(array)($d['content_performance']??[]);

    $channelOptions=[];$staffOptions=[];$placementOptions=[];
    foreach($allGroups as $g){
        $channel=(string)($g['channel']??'Unknown');
        $staff=(string)($g['staff']??'—');
        $placement=strtolower((string)($g['placement']??'direct'));
        if($channel!=='')$channelOptions[$channel]=true;
        if($staff!==''&&$staff!=='—')$staffOptions[$staff]=true;
        if($placement!=='')$placementOptions[$placement]=true;
    }
    ksort($channelOptions,SORT_NATURAL|SORT_FLAG_CASE);
    ksort($staffOptions,SORT_NATURAL|SORT_FLAG_CASE);

    $placementLabel=function(string $p): string {
        return match(strtolower($p)){
            'profile','bio'=>'Profile / Bio',
            'reel'=>'Reel',
            'post'=>'Post',
            'story'=>'Story',
            'ad'=>'Ad',
            'qr'=>'QR',
            'landing'=>'Landing Page',
            'direct'=>'Direct',
            default=>ucfirst($p?:'Other')
        };
    };

    $matches=function(array $g)use($channelFilter,$staffFilter,$placementFilter): bool{
        if($channelFilter!=='' && strcasecmp((string)($g['channel']??''),$channelFilter)!==0)return false;
        if($staffFilter!=='' && strcasecmp((string)($g['staff']??''),$staffFilter)!==0)return false;
        if($placementFilter!=='' && strtolower((string)($g['placement']??''))!==$placementFilter)return false;
        return true;
    };

    $metric=function(array $g)use($sortKey): float{
        $customers=max(1,(int)($g['customers']??0));
        return match($sortKey){
            'customers'=>(float)($g['customers']??0),
            'booked'=>(float)($g['booked_customers']??0),
            'arrived'=>(float)($g['arrived_customers']??0),
            'repeat_rate'=>((float)($g['repeat_customers']??0)/$customers)*100,
            'loyal'=>(float)($g['loyal_customers']??0),
            default=>(float)($g['revenue']??0),
        };
    };

    $sortRows=function(array &$rows)use($metric): void{
        uasort($rows,function($a,$b)use($metric){
            $primary=$metric((array)$b)<=>$metric((array)$a);
            if($primary!==0)return $primary;
            $secondary=((float)($b['revenue']??0))<=>((float)($a['revenue']??0));
            if($secondary!==0)return $secondary;
            return ((int)($b['customers']??0))<=>((int)($a['customers']??0));
        });
    };

    $filteredGroups=array_filter($allGroups,$matches);
    $sortRows($filteredGroups);

    $filteredContent=array_filter($allContent,$matches);
    $sortRows($filteredContent);

    $rollup=function(array $rows,string $type)use($sortRows): array{
        $out=[];
        foreach($rows as $g){
            if($type==='channel'){
                $key=(string)($g['channel']??'Unknown');
                $seed=['label'=>$key,'channel'=>$key];
            }elseif($type==='staff'){
                $key=(string)($g['staff']??'—');
                if($key===''||$key==='—')continue;
                $seed=['label'=>$key];
            }else{
                $account=(string)($g['account']??'Store / Direct');
                $channel=(string)($g['channel']??'Unknown');
                $key=$channel.'|'.$account;
                $seed=['account'=>$account,'channel'=>$channel,'label'=>$account];
            }
            if(!isset($out[$key])){
                $out[$key]=$seed+[
                    'customers'=>0,'booked_customers'=>0,'bookings'=>0,
                    'arrived_customers'=>0,'arrived_visits'=>0,
                    'repeat_customers'=>0,'loyal_customers'=>0,
                    'completed_visits'=>0,'revenue'=>0.0
                ];
            }
            foreach(['customers','booked_customers','bookings','arrived_customers','arrived_visits','repeat_customers','loyal_customers','completed_visits'] as $field){
                $out[$key][$field]+=(int)($g[$field]??0);
            }
            $out[$key]['revenue']+=(float)($g['revenue']??0);
        }
        $sortRows($out);
        return $out;
    };

    $filteredChannels=$rollup($filteredGroups,'channel');
    $filteredStaff=$rollup($filteredGroups,'staff');
    $filteredAccounts=$rollup($filteredGroups,'account');

    $datasetSummary=(array)($d['summary']??[]);
    $summary=[
        'customers'=>0,'matched'=>0,'booked_customers'=>0,'bookings'=>0,
        'arrived_customers'=>0,'arrived_visits'=>0,'repeat_customers'=>0,
        'loyal_customers'=>0,'completed_visits'=>0,'revenue'=>0.0,
        'raw_link_opens'=>(int)($datasetSummary['raw_link_opens']??0),

        // v13.6.10.20: carry database Closed Loop Health fields from the
        // dataset into the page-local filtered summary. These diagnostics
        // describe bridge health, not filtered marketing ranking totals.
        'closed_loop_customer_linked'=>(int)($datasetSummary['closed_loop_customer_linked']??0),
        'closed_loop_visit_linked'=>(int)($datasetSummary['closed_loop_visit_linked']??0),
        'closed_loop_arrived_customers'=>(int)($datasetSummary['closed_loop_arrived_customers']??0),
        'closed_loop_paid_customers'=>(int)($datasetSummary['closed_loop_paid_customers']??0),
        'closed_loop_revenue'=>(float)($datasetSummary['closed_loop_revenue']??0),
        'closed_loop_bridge_version'=>(string)($datasetSummary['closed_loop_bridge_version']??''),
        'closed_loop_bridge_ready'=>!empty($datasetSummary['closed_loop_bridge_ready']),
        'lifecycle_rpc_ready'=>!empty($datasetSummary['lifecycle_rpc_ready'])
    ];
    foreach($filteredGroups as $g){
        foreach(['customers','booked_customers','bookings','arrived_customers','arrived_visits','repeat_customers','loyal_customers','completed_visits'] as $field){
            $summary[$field]+=(int)($g[$field]??0);
        }
        $summary['revenue']+=(float)($g['revenue']??0);
        if(strtolower((string)($g['channel']??'unknown'))!=='unknown')$summary['matched']+=(int)($g['customers']??0);
    }
    $summary['avg_revenue_per_customer']=$summary['customers']>0?$summary['revenue']/$summary['customers']:0;

    $customers=max(0,(int)$summary['customers']);
    $bookRate=$customers>0?((int)$summary['booked_customers']/$customers*100):0;
    $arriveRate=$customers>0?((int)$summary['arrived_customers']/$customers*100):0;
    $repeatRate=$customers>0?((int)$summary['repeat_customers']/$customers*100):0;
    $loyalRate=$customers>0?((int)$summary['loyal_customers']/$customers*100):0;
    $matchedRate=$customers>0?((int)$summary['matched']/$customers*100):0;
    $activeFilterCount=($channelFilter!==''?1:0)+($staffFilter!==''?1:0)+($placementFilter!==''?1:0);
    ?>
    <div class="page-head">
      <div>
        <a class="back-link" href="index.php?page=analytics">← 返回经营分析</a>
        <span class="eyebrow">MARKETING ATTRIBUTION · FIRST TOUCH COHORT</span>
        <h1>Marketing 来源分析</h1>
        <p><?=e((string)(current_store()['name']??'当前分行'))?> · 第一次 WhatsApp 来源永久锁定；后续预约、到店、回头、指定理发师与营业额持续归回第一次媒体来源。</p>
      </div>
      <div class="page-head-actions">
        <form method="get" class="analytics-period-form">
          <input type="hidden" name="page" value="marketing_analytics">
          <input type="hidden" name="channel" value="<?=e($channelFilter)?>">
          <input type="hidden" name="source_staff" value="<?=e($staffFilter)?>">
          <input type="hidden" name="placement" value="<?=e($placementFilter)?>">
          <input type="hidden" name="rank_by" value="<?=e($sortKey)?>">
          <div class="segmented-control">
            <button name="period" value="day" class="<?=$period==='day'?'active':''?>">日</button>
            <button name="period" value="month" class="<?=$period==='month'?'active':''?>">月</button>
            <button name="period" value="year" class="<?=$period==='year'?'active':''?>">年</button>
          </div>
          <input class="input" type="date" name="anchor" value="<?=e($anchor)?>">
          <button class="btn btn-light">查看</button>
        </form>
        <a class="btn btn-light" href="index.php?page=settings_marketing">媒体账号与 Tracking →</a>
      </div>
    </div>

    <section class="card marketing-filter-console">
      <div class="marketing-filter-console-head">
        <div>
          <span class="card-kicker">FILTER & RANKING</span>
          <h3>筛选来源，再决定用什么指标排行</h3>
          <p>日期继续使用上方 日 / 月 / 年；这里可按平台、员工 IP、内容位置筛选，并切换排行逻辑。</p>
        </div>
        <?php if($activeFilterCount>0):?><span class="badge badge-gold"><?=$activeFilterCount?> 个筛选启用</span><?php else:?><span class="badge badge-gray">ALL SOURCES</span><?php endif;?>
      </div>
      <form method="get" class="marketing-filter-form">
        <input type="hidden" name="page" value="marketing_analytics">
        <input type="hidden" name="period" value="<?=e($period)?>">
        <input type="hidden" name="anchor" value="<?=e($anchor)?>">

        <div class="field">
          <label>平台</label>
          <select class="select" name="channel">
            <option value="">全部平台</option>
            <?php foreach(array_keys($channelOptions) as $option):?>
              <option value="<?=e($option)?>" <?=$channelFilter===$option?'selected':''?>><?=e($option)?></option>
            <?php endforeach;?>
          </select>
        </div>

        <div class="field">
          <label>员工 IP</label>
          <select class="select" name="source_staff">
            <option value="">全部员工 IP</option>
            <?php foreach(array_keys($staffOptions) as $option):?>
              <option value="<?=e($option)?>" <?=$staffFilter===$option?'selected':''?>><?=e($option)?></option>
            <?php endforeach;?>
          </select>
        </div>

        <div class="field">
          <label>内容位置</label>
          <select class="select" name="placement">
            <option value="">全部内容</option>
            <?php foreach(['profile','reel','post','story','ad','qr','landing','direct'] as $option):?>
              <?php if(isset($placementOptions[$option])||in_array($option,['profile','reel','post','story'],true)):?>
                <option value="<?=e($option)?>" <?=$placementFilter===$option?'selected':''?>><?=e($placementLabel($option))?></option>
              <?php endif;?>
            <?php endforeach;?>
          </select>
        </div>

        <div class="field">
          <label>排行方式</label>
          <select class="select" name="rank_by">
            <?php foreach($sortLabels as $key=>$label):?>
              <option value="<?=e($key)?>" <?=$sortKey===$key?'selected':''?>><?=e($label)?></option>
            <?php endforeach;?>
          </select>
        </div>

        <div class="marketing-filter-actions">
          <button class="btn btn-primary">套用筛选</button>
          <a class="btn btn-light" href="index.php?<?=e(http_build_query(['page'=>'marketing_analytics','period'=>$period,'anchor'=>$anchor]))?>">清除筛选</a>
        </div>
      </form>

      <div class="marketing-active-filter-row">
        <span class="badge badge-gray">排行：<?=e($sortLabels[$sortKey])?></span>
        <?php if($channelFilter!==''):?><span class="badge badge-gold">平台 · <?=e($channelFilter)?></span><?php endif;?>
        <?php if($staffFilter!==''):?><span class="badge badge-gold">员工 IP · <?=e($staffFilter)?></span><?php endif;?>
        <?php if($placementFilter!==''):?><span class="badge badge-gold">内容 · <?=e($placementLabel($placementFilter))?></span><?php endif;?>
      </div>
    </section>

    <section class="marketing-funnel-summary marketing-lifecycle-summary">
      <article class="card marketing-funnel-card"><span>UNIQUE WHATSAPP CUSTOMERS</span><strong><?=number_format($customers)?></strong><small>同一号码永远只算 1 位</small></article>
      <article class="card marketing-funnel-card"><span>BOOKED CUSTOMERS</span><strong><?=number_format((int)$summary['booked_customers'])?></strong><small><?=number_format($bookRate,1)?>% · 共 <?=number_format((int)$summary['bookings'])?> 个预约</small></article>
      <article class="card marketing-funnel-card"><span>ARRIVED CUSTOMERS</span><strong><?=number_format((int)$summary['arrived_customers'])?></strong><small><?=number_format($arriveRate,1)?>% · 至少到店 1 次</small></article>
      <article class="card marketing-funnel-card"><span>REPEAT CUSTOMERS</span><strong><?=number_format((int)$summary['repeat_customers'])?></strong><small><?=number_format($repeatRate,1)?>% · 首次触达后完成 ≥ 2 次</small></article>
      <article class="card marketing-funnel-card"><span>STYLIST-LOYAL CUSTOMERS</span><strong><?=number_format((int)$summary['loyal_customers'])?></strong><small><?=number_format($loyalRate,1)?>% · 指定次数 &gt; 随机次数</small></article>
      <article class="card marketing-funnel-card marketing-funnel-revenue"><span>ATTRIBUTED REVENUE</span><strong><?=money((float)$summary['revenue'])?></strong><small>平均 <?=money((float)$summary['avg_revenue_per_customer'])?> / 首触顾客</small></article>
    </section>


    <section class="card marketing-closed-loop-health">
      <div class="card-head">
        <div>
          <span class="card-kicker">CLOSED LOOP HEALTH</span>
          <h3>WhatsApp → SalonOS → 到店 → 收款 的数据桥接状态</h3>
          <p>这不是新的顾客计数，而是检查 First-Touch 顾客有没有真正接到 SalonOS 顾客、预约/订单与付款生命周期。</p>
        </div>
        <?php if(!empty($summary['closed_loop_bridge_ready'])&&!empty($summary['lifecycle_rpc_ready'])):?><span class="badge badge-green">FULL LOOP READY</span><?php elseif(!empty($summary['closed_loop_bridge_ready'])):?><span class="badge badge-gold">ANALYTICS RPC REQUIRED</span><?php else:?><span class="badge badge-gold">SQL REQUIRED</span><?php endif;?>
      </div>
      <div class="marketing-closed-loop-grid">
        <article>
          <span>FIRST TOUCH</span>
          <strong><?=number_format($customers)?></strong>
          <small>去重 WhatsApp 顾客</small>
        </article>
        <article>
          <span>CUSTOMER LINKED</span>
          <strong><?=number_format((int)($summary['closed_loop_customer_linked']??0))?></strong>
          <small>已经对应 SalonOS Customer</small>
        </article>
        <article>
          <span>VISIT / BOOKING LINKED</span>
          <strong><?=number_format((int)($summary['closed_loop_visit_linked']??0))?></strong>
          <small>Marketing Lead 已绑到第一笔后续 Visit</small>
        </article>
        <article>
          <span>ARRIVED</span>
          <strong><?=number_format((int)($summary['closed_loop_arrived_customers']??$summary['arrived_customers']))?></strong>
          <small>至少真正到店 1 次</small>
        </article>
        <article>
          <span>PAID</span>
          <strong><?=number_format((int)($summary['closed_loop_paid_customers']??0))?></strong>
          <small>已有 Paid Payment / Revenue</small>
        </article>
      </div>
      <?php if(!empty($summary['closed_loop_bridge_ready'])&&!empty($summary['lifecycle_rpc_ready'])):?>
        <div class="marketing-closed-loop-sync">
          <strong>ANALYTICS SOURCE SYNCED</strong>
          <span>Closed Loop Health、顶部 KPI、Customer Funnel、Content Performance、Channel / Staff IP / Media Account Ranking 现在全部使用同一套 canonical lifecycle RPC。</span>
        </div>
      <?php endif;?>

      <?php if(empty($summary['closed_loop_bridge_ready'])):?>
        <div class="marketing-closed-loop-warning">
          你刚才的 v13.6.10.18 Bridge SQL 已经成功；现在缺的是 Dashboard 专用的安全状态 RPC。请运行本版 ZIP 内的 <strong>RUN_ONCE_V13_6_10_19_CLOSED_LOOP_HEALTH_RPC.sql</strong>，页面就会直接读取数据库真实的 Customer / Visit / Arrived / Paid 桥接状态。
        </div>
      <?php else:?>
        <div class="marketing-closed-loop-ok">
          Closed Loop Bridge 已安装<?=!empty($summary['closed_loop_bridge_version'])?' · v'.e((string)$summary['closed_loop_bridge_version']):''?>。<?=!empty($summary['lifecycle_rpc_ready'])?'Dashboard 主 KPI、漏斗、内容排行与来源排行现在全部读取同一套真实 Visits / Payments 生命周期。':'Closed Loop Health 已正确，但主 KPI / 内容排行还需要运行 v13.6.10.21 Lifecycle RPC SQL。'?>
        </div>
      <?php endif;?>
    </section>

    <section class="card marketing-customer-funnel">
      <div class="card-head">
        <div><span class="card-kicker">CUSTOMER JOURNEY FUNNEL</span><h3>第一次来源 → 真正顾客质量</h3><p>当前筛选下的转化率全部用“去重后的 WhatsApp 顾客”做分母，不使用 Link Click。</p></div>
        <span class="badge badge-gold"><?=number_format($matchedRate,1)?>% 来源已识别</span>
      </div>
      <div class="marketing-funnel-steps">
        <?php foreach([
          ['WhatsApp 顾客',$customers,100],
          ['有预约顾客',(int)$summary['booked_customers'],$bookRate],
          ['到店顾客',(int)$summary['arrived_customers'],$arriveRate],
          ['回头客',(int)$summary['repeat_customers'],$repeatRate],
          ['指定理发师忠诚客',(int)$summary['loyal_customers'],$loyalRate]
        ] as [$label,$count,$pct]):?>
          <div class="marketing-funnel-step"><span><?=e($label)?></span><strong><?=number_format($count)?></strong><div class="marketing-funnel-bar"><i style="width:<?=max(2,min(100,(float)$pct))?>%"></i></div><small><?=number_format((float)$pct,1)?>%</small></div>
        <?php endforeach;?>
      </div>
    </section>

    <div class="marketing-diagnostic-note">
      <strong>防刷 / First Touch</strong>
      <span>本期所有 Tracking Link 实际打开 <?=number_format((int)($summary['raw_link_opens']??0))?> 次，只作技术排错；Dashboard 顾客人数仍按手机号码去重。当前筛选不会改变 First-Touch 历史。</span>
    </div>

    <section class="card marketing-content-performance">
      <div class="card-head">
        <div>
          <span class="card-kicker">CONTENT PERFORMANCE · <?=e(strtoupper($sortKey))?></span>
          <h3>Profile / Reel / Post / Story 内容排行</h3>
          <p>当前按「<?=e($sortLabels[$sortKey])?>」排序；Link opens 不参与顾客人数或排行。</p>
        </div>
        <a class="btn btn-light btn-small" href="index.php?page=settings_marketing">管理内容 / Link →</a>
      </div>

      <div class="marketing-content-performance-grid">
        <?php $contentRank=0;foreach(array_slice($filteredContent,0,12,true) as $contentKey=>$g):
          $contentRank++;$c=max(1,(int)$g['customers']);$arrivePct=(int)$g['arrived_customers']/$c*100;
          $modalId='content-performance-'.substr(md5((string)$contentKey),0,12);
        ?>
          <button class="marketing-content-performance-card" type="button" data-v1350-modal-open="<?=e($modalId)?>">
            <div class="marketing-content-performance-top">
              <span class="marketing-content-rank">#<?=$contentRank?></span>
              <span class="badge badge-gray"><?=e($placementLabel((string)$g['placement']))?></span>
              <?php if(!empty($g['link_active'])):?><span class="badge badge-green">ACTIVE</span><?php else:?><span class="badge badge-history">OFF · HISTORICAL</span><?php endif;?>
              <?php if($contentRank===1):?><span class="badge badge-gold">TOP</span><?php endif;?>
            </div>
            <strong><?=e((string)$g['title'])?></strong>
            <small><?=e((string)$g['channel'])?> · <?=e((string)$g['account'])?><?=($g['staff']??'—')!=='—'?' · '.e((string)$g['staff']):''?></small>
            <div class="marketing-content-performance-metrics">
              <span><b><?=number_format((int)$g['customers'])?></b> 顾客</span>
              <span><b><?=number_format((int)$g['booked_customers'])?></b> 预约</span>
              <span><b><?=number_format((int)$g['arrived_customers'])?></b> 到店</span>
            </div>
            <div class="marketing-content-performance-bottom">
              <strong><?=money((float)$g['revenue'])?></strong>
              <small><?=number_format($arrivePct,1)?>% arrived</small>
            </div>
          </button>

          <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="<?=e($modalId)?>">
            <div class="commission-modal-backdrop" data-v1350-modal-close></div>
            <section class="commission-modal-dialog v1350-small-modal marketing-content-performance-modal">
              <div class="commission-modal-header">
                <div>
                  <span class="card-kicker"><?=e(strtoupper((string)$g['placement']))?> · FIRST TOUCH CONTENT</span>
                  <div class="marketing-content-modal-titleline">
                    <h3><?=e((string)$g['title'])?></h3>
                    <?php if(!empty($g['link_active'])):?><span class="badge badge-green">ACTIVE</span><?php else:?><span class="badge badge-history">OFF · HISTORICAL</span><?php endif;?>
                  </div>
                  <p><?=e((string)$g['channel'])?> · <?=e((string)$g['account'])?><?=($g['staff']??'—')!=='—'?' · 来源员工 '.e((string)$g['staff']):''?></p>
                </div>
                <button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button>
              </div>

              <div class="commission-modal-content">
                <div class="marketing-content-modal-stats">
                  <div><span>UNIQUE CUSTOMERS</span><strong><?=number_format((int)$g['customers'])?></strong></div>
                  <div><span>BOOKED</span><strong><?=number_format((int)$g['booked_customers'])?></strong></div>
                  <div><span>ARRIVED</span><strong><?=number_format((int)$g['arrived_customers'])?></strong></div>
                  <div><span>REPEAT</span><strong><?=number_format((int)$g['repeat_customers'])?></strong></div>
                  <div><span>LOYAL</span><strong><?=number_format((int)$g['loyal_customers'])?></strong></div>
                  <div><span>REVENUE</span><strong><?=money((float)$g['revenue'])?></strong></div>
                </div>

                <div class="marketing-content-lifecycle-banner <?=!empty($g['link_active'])?'is-active':'is-historical'?>">
                  <div><span>CURRENT LINK STATUS</span><strong><?=!empty($g['link_active'])?'ACTIVE':'OFF · HISTORICAL'?></strong></div>
                  <?php if(!empty($g['link_active'])):?><p>这条 Tracking Link 目前仍可用于新的引流。已有 First-Touch 顾客会继续保留原始来源。</p><?php else:?><p>这条 Link 已停用，不再用于新的引流；过去的 First-Touch 顾客与后续 Revenue 仍永久保留。</p><?php endif;?>
                </div>

                <div class="marketing-content-modal-context">
                  <?php if(!empty($g['slug'])):?><div><span>Tracking Link</span><strong><?=e((string)$g['slug'])?></strong><small><?=!empty($g['link_active'])?'当前可用':'已停用，仅保留历史归因'?></small></div><?php endif;?>
                  <?php if(!empty($g['external_url'])):?><div><span>原始内容</span><a href="<?=e((string)$g['external_url'])?>" target="_blank" rel="noopener">打开原始内容 →</a></div><?php endif;?>
                  <div><span>First Touch 生命周期</span><strong><?=!empty($g['first_touch_at'])?e(app_date((string)$g['first_touch_at'],true)):'—'?><?php if(!empty($g['last_touch_at']) && (string)$g['last_touch_at']!==(string)$g['first_touch_at']):?> → <?=e(app_date((string)$g['last_touch_at'],true))?><?php endif;?></strong><small>这条来源首次/最近取得 First-Touch 顾客的时间</small></div>
                  <div><span>技术诊断 Link opens</span><strong><?=number_format((int)($g['link_opens']??0))?></strong><small>不会计入顾客人数或排名</small></div>
                  <div><span>RM / Customer</span><strong><?=money((float)$g['revenue']/max(1,(int)$g['customers']))?></strong></div>
                </div>

                <div class="marketing-content-customer-list">
                  <div class="marketing-content-customer-title"><strong>First-Touch 顾客</strong><small>同一个手机号只会出现一次；以后从其他平台回来不会改变第一次来源。</small></div>
                  <?php foreach((array)($g['customers_detail']??[]) as $customer):?>
                    <div class="marketing-content-customer-row">
                      <div><strong><?=e((string)$customer['name'])?></strong><small><?=e((string)$customer['phone'])?><?=!empty($customer['first_message_at'])?' · 首次 '.e(app_date((string)$customer['first_message_at'],true)):''?></small></div>
                      <div class="marketing-content-customer-badges">
                        <?=!empty($customer['booked'])?'<span class="badge badge-gray">Booked</span>':''?>
                        <?=!empty($customer['arrived'])?'<span class="badge badge-green">Arrived</span>':''?>
                        <?=!empty($customer['repeat'])?'<span class="badge badge-gold">Repeat</span>':''?>
                        <?=!empty($customer['loyal'])?'<span class="badge badge-gold">Loyal</span>':''?>
                        <strong><?=money((float)$customer['revenue'])?></strong>
                      </div>
                    </div>
                  <?php endforeach;?>
                </div>
              </div>
            </section>
          </div>
        <?php endforeach;?>
        <?php if(!$filteredContent):?><div class="empty">当前筛选下还没有 Profile / Reel / Post / Story 的 First-Touch 顾客数据。</div><?php endif;?>
      </div>
    </section>

    <section class="card marketing-channel-overview">
      <div class="card-head"><div><span class="card-kicker">CHANNEL QUALITY · <?=e(strtoupper($sortKey))?></span><h3>平台表现排行</h3><p>当前按「<?=e($sortLabels[$sortKey])?>」排序，并遵循上方来源筛选。</p></div></div>
      <div class="marketing-channel-grid marketing-quality-grid">
        <?php foreach($filteredChannels as $name=>$g):$c=max(1,(int)$g['customers']);$b=(int)$g['booked_customers']/$c*100;$rep=(int)$g['repeat_customers']/$c*100;$loy=(int)$g['loyal_customers']/$c*100;?>
          <article class="marketing-channel-card marketing-quality-card">
            <div><strong><?=e((string)($g['label']??$name))?></strong><span><?=number_format($b,1)?>% booked · <?=number_format($rep,1)?>% repeat · <?=number_format($loy,1)?>% loyal</span></div>
            <strong class="marketing-channel-revenue"><?=money((float)$g['revenue'])?></strong>
            <div class="marketing-channel-metrics marketing-channel-quality-metrics">
              <span><b><?=number_format((int)$g['customers'])?></b> Customers</span><span><b><?=number_format((int)$g['booked_customers'])?></b> Booked</span><span><b><?=number_format((int)$g['arrived_customers'])?></b> Arrived</span><span><b><?=number_format((int)$g['repeat_customers'])?></b> Repeat</span><span><b><?=number_format((int)$g['loyal_customers'])?></b> Loyal</span>
            </div>
          </article>
        <?php endforeach;?>
        <?php if(!$filteredChannels):?><div class="empty">当前筛选下没有平台数据。</div><?php endif;?>
      </div>
    </section>

    <div class="marketing-ranking-grid">
      <section class="card marketing-ranking-card">
        <div class="card-head"><div><span class="card-kicker">STAFF IP RANKING · <?=e(strtoupper($sortKey))?></span><h3>员工个人 IP 带客排名</h3><p>当前按「<?=e($sortLabels[$sortKey])?>」排序。</p></div></div>
        <div class="marketing-ranking-list">
          <?php $rank=0;foreach(array_slice($filteredStaff,0,12,true) as $g):$rank++;$c=max(1,(int)$g['customers']);?>
            <div class="marketing-ranking-row"><b>#<?=$rank?></b><div><strong><?=e((string)$g['label'])?></strong><small><?=number_format((int)$g['customers'])?> 顾客 · <?=number_format((int)$g['repeat_customers'])?> 回头 · <?=number_format((int)$g['loyal_customers'])?> 忠诚</small></div><span><?=money((float)$g['revenue'])?><small><?=number_format(((int)$g['booked_customers']/$c)*100,1)?>% booked</small></span></div>
          <?php endforeach;?>
          <?php if(!$filteredStaff):?><div class="empty compact-empty">当前筛选下没有员工 Personal IP 首次来源。</div><?php endif;?>
        </div>
      </section>

      <section class="card marketing-ranking-card">
        <div class="card-head"><div><span class="card-kicker">MEDIA ACCOUNT RANKING · <?=e(strtoupper($sortKey))?></span><h3>媒体账号带客排名</h3><p>当前按「<?=e($sortLabels[$sortKey])?>」排序。</p></div></div>
        <div class="marketing-ranking-list">
          <?php $rank=0;foreach(array_slice($filteredAccounts,0,12,true) as $g):$rank++;$c=max(1,(int)$g['customers']);?>
            <div class="marketing-ranking-row"><b>#<?=$rank?></b><div><strong><?=e((string)$g['account'])?></strong><small><?=e((string)$g['channel'])?> · <?=number_format((int)$g['customers'])?> 顾客 · <?=number_format((int)$g['arrived_customers'])?> 到店</small></div><span><?=money((float)$g['revenue'])?><small><?=number_format(((int)$g['repeat_customers']/$c)*100,1)?>% repeat</small></span></div>
          <?php endforeach;?>
          <?php if(!$filteredAccounts):?><div class="empty compact-empty">当前筛选下没有媒体账号首次来源。</div><?php endif;?>
        </div>
      </section>
    </div>

    <section class="card marketing-attribution-table">
      <div class="card-head">
        <div><span class="card-kicker">FIRST TOUCH SOURCE DETAIL · <?=e(strtoupper($sortKey))?></span><h3>平台 / 账号 / 员工 IP / 第一次位置</h3><p>表格遵循同一组筛选与排行方式；First-Touch 历史本身不会被筛选动作修改。</p></div>
      </div>
      <div class="history-table-scroll">
        <table class="data-table">
          <thead><tr><th>#</th><th>平台</th><th>媒体账号</th><th>来源员工</th><th>首次位置</th><th>顾客</th><th>有预约</th><th>到店</th><th>回头</th><th>忠诚</th><th>Revenue</th><th>RM / 客</th></tr></thead>
          <tbody>
            <?php $rowRank=0;foreach($filteredGroups as $g):$rowRank++;$c=max(1,(int)$g['customers']);?>
              <tr><td><strong>#<?=$rowRank?></strong></td><td><strong><?=e((string)$g['channel'])?></strong></td><td><?=e((string)$g['account'])?></td><td><?=e((string)$g['staff'])?></td><td><span class="badge badge-gray"><?=e($placementLabel((string)$g['placement']))?></span></td><td><strong><?=number_format((int)$g['customers'])?></strong></td><td><?=number_format((int)$g['booked_customers'])?></td><td><?=number_format((int)$g['arrived_customers'])?></td><td><?=number_format((int)$g['repeat_customers'])?></td><td><?=number_format((int)$g['loyal_customers'])?></td><td><strong><?=money((float)$g['revenue'])?></strong></td><td><?=money((float)$g['revenue']/$c)?></td></tr>
            <?php endforeach;?>
            <?php if(!$filteredGroups):?><tr><td colspan="12"><div class="empty">当前筛选下没有可分析的 First-Touch 顾客。</div></td></tr><?php endif;?>
          </tbody>
        </table>
      </div>
    </section>
    <?php
}

function v132_page_data_import(): void {if(!v13_is_owner()){?><div class="page-head"><div><a class="back-link" href="index.php?page=settings">← 返回系统设置</a><span class="eyebrow">DATA IMPORT</span><h1>Tunaipro CSV 导入</h1></div></div><section class="card"><div class="card-body"><p>老板已经允许你的职位看到这个入口。实际导入会写入门店数据库，因此目前仍只允许老板账号执行。</p></div></section><?php return;}$entry=$_SESSION['v132_import_preview']??null;$rows=is_array($_SESSION['v132_import_preview_rows']??null)?$_SESSION['v132_import_preview_rows']:[];$invalid=(array)($_SESSION['v132_import_preview_invalid']??[]);?>
    <div class="page-head"><div><a class="back-link" href="index.php?page=settings">← 返回系统设置</a><span class="eyebrow">TUNAIPRO DATA IMPORT</span><h1>Tunaipro CSV 导入</h1><p>产品、配套、服务与会员会先预览，确认后才写入当前 Supabase 分行。</p></div></div>
    <section class="import-type-grid"><article class="card import-type-card"><span>PRODUCT</span><h3>产品导入</h3><p>SKU、售价、本钱、分类与条码。</p></article><article class="card import-type-card"><span>PACKAGE</span><h3>产品配套导入</h3><p>先建立停用的配套草稿，再由你连接配套组成。</p></article><article class="card import-type-card"><span>SERVICE</span><h3>服务项目导入</h3><p>服务名称、价格、分类、时长与状态。</p></article><article class="card import-type-card"><span>MEMBER</span><h3>会员资料导入</h3><p>按电话号码匹配顾客，并建立会员。</p></article></section>
    <section class="card import-upload-card"><form method="post" enctype="multipart/form-data" class="card-body"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="preview_tunaipro_import_v132"><input type="hidden" name="return_page" value="data_import"><div class="form-grid"><div class="field"><label>导入类型</label><select class="select" name="import_type"><option value="product">Product · 产品</option><option value="package">Package · 产品配套</option><option value="service">Service · 服务项目</option><option value="member">Basic Member Source · 会员</option></select></div><div class="field span-2"><label>CSV 文件</label><input class="input" type="file" name="csv_file" accept=".csv,text/csv" required></div></div><button class="btn btn-primary">上传并预览 CSV →</button></form></section>
    <?php if(is_array($entry)&&$rows):?><section class="card import-preview-card" style="margin-top:18px"><div class="card-head"><div><span class="card-kicker">IMPORT PREVIEW</span><h3><?=e(v132_tunaipro_label((string)$entry['type']))?>预览</h3><p><?=e((string)$entry['name'])?> · <?=count($rows)?> 行可导入</p></div></div><?php if($invalid):?><div class="alert alert-error">有 <?=count($invalid)?> 行不会导入。<?=e(implode('；',array_slice($invalid,0,5)))?></div><?php endif;?><div class="table-wrap"><table class="table"><thead><tr><?php foreach(array_keys($rows[0]) as $k):?><th><?=e($k)?></th><?php endforeach;?></tr></thead><tbody><?php foreach(array_slice($rows,0,50) as $r):?><tr><?php foreach($r as $v):?><td><?=e(is_scalar($v)||$v===null?(string)$v:json_encode($v,JSON_UNESCAPED_UNICODE))?></td><?php endforeach;?></tr><?php endforeach;?></tbody></table></div><form method="post" style="padding:18px"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="confirm_tunaipro_import_v132"><input type="hidden" name="return_page" value="data_import"><button class="btn btn-primary">确认导入全部 <?=count($rows)?> 行到 Supabase →</button></form></section><?php endif;?>
<?php }

function v132_transfer_export_data(): array {
    $org=v13_org_uuid();$store=v13_store_uuid();$q='organization_id=eq.'.rawurlencode($org).'&store_id=eq.'.rawurlencode($store).'&limit=5000';
    return ['format'=>'SalonOS-v13.2-branch-transfer','created_at'=>date(DATE_ATOM),'source_store'=>current_store(),'products'=>v13_owner_rows('products','select=*&'.$q),'services'=>v13_owner_rows('services','select=*&'.$q),'customers'=>v13_owner_rows('customers','select=*&'.$q)];
}
function v132_export_transfer_package(): never {
    if(!v13_is_owner())throw new RuntimeException('只有老板可以导出资料。');$data=v132_transfer_export_data();$name='SalonOS-Branch-'.preg_replace('/[^A-Za-z0-9_-]/','-',(string)(current_store()['name']??'Store')).'-'.date('Ymd-His').'.json';header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="'.$name.'"');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);exit;
}
function v132_import_transfer_package(): void {
    if(empty($_FILES['transfer_file'])||!is_uploaded_file($_FILES['transfer_file']['tmp_name']))throw new RuntimeException('请选择 SalonOS JSON 资料包。');$raw=file_get_contents($_FILES['transfer_file']['tmp_name']);$data=json_decode((string)$raw,true);if(!is_array($data)||($data['format']??'')!=='SalonOS-v13.2-branch-transfer')throw new RuntimeException('资料包格式不正确。');
    $insert=0;$update=0;foreach((array)($data['products']??[]) as $r){$sku=trim((string)($r['sku']??''));if($sku==='')continue;$exist=v13_owner_rows('products','select=id&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&sku=eq.'.rawurlencode($sku).'&limit=1');unset($r['id'],$r['created_at']);$r['organization_id']=v13_org_uuid();$r['store_id']=v13_store_uuid();$r['updated_at']=date(DATE_ATOM);if($exist){v13_owner_write('products','id=eq.'.rawurlencode((string)$exist[0]['id']),'PATCH',$r);$update++;}else{v13_owner_write('products','','POST',$r);$insert++;}}
    foreach((array)($data['services']??[]) as $r){$name=trim((string)($r['name']??''));if($name==='')continue;$exist=v13_owner_rows('services','select=id&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&name=eq.'.rawurlencode($name).'&limit=1');unset($r['id'],$r['created_at']);$r['organization_id']=v13_org_uuid();$r['store_id']=v13_store_uuid();$r['updated_at']=date(DATE_ATOM);if($exist){v13_owner_write('services','id=eq.'.rawurlencode((string)$exist[0]['id']),'PATCH',$r);$update++;}else{v13_owner_write('services','','POST',$r);$insert++;}}
    foreach((array)($data['customers']??[]) as $r){$phone=v132_normalize_phone((string)($r['phone']??''));if($phone==='')continue;$exist=v13_owner_rows('customers','select=id&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&phone=eq.'.rawurlencode($phone).'&limit=1');unset($r['id'],$r['created_at']);$r['organization_id']=v13_org_uuid();$r['store_id']=v13_store_uuid();$r['phone']=$phone;$r['updated_at']=date(DATE_ATOM);if($exist){v13_owner_write('customers','id=eq.'.rawurlencode((string)$exist[0]['id']),'PATCH',$r);$update++;}else{v13_owner_write('customers','','POST',$r);$insert++;}}
    flash('success',"分行资料包导入完成：新增 {$insert}、更新 {$update}。图片 URL / Storage path 会跟随产品资料保留。");
}
function v132_page_data_transfer(): void {if(!v13_is_owner()){?><div class="page-head"><div><a class="back-link" href="index.php?page=settings">← 返回系统设置</a><span class="eyebrow">BRANCH DATA TRANSFER</span><h1>分行资料迁移</h1></div></div><section class="card"><div class="card-body"><p>老板已经允许你的职位看到这个入口。导入 / 导出分行资料属于高风险数据库操作，目前仍只允许老板账号执行。</p></div></section><?php return;}?>
    <div class="page-head"><div><a class="back-link" href="index.php?page=settings">← 返回系统设置</a><span class="eyebrow">BRANCH DATA TRANSFER</span><h1>分行资料迁移</h1><p>在 Supabase 分行之间迁移产品、服务和顾客；同一 Storage 项目的图片路径会保留。</p></div></div><section class="settings-entry-grid"><a class="settings-entry-card" href="index.php?action=export_transfer_v132"><div class="settings-entry-icon"><?=ui_icon('receipt')?></div><div><span>EXPORT</span><h2>导出当前分行资料</h2><p>生成 SalonOS v13.2 JSON 资料包，不包含密码或 Session。</p></div><strong>下载资料包 →</strong></a><article class="card settings-entry-card" style="display:block"><div><span>IMPORT</span><h2>导入到当前分行</h2><p>相同 SKU / 服务名 / 电话号码会更新，不会复制成重复资料。</p></div><form method="post" enctype="multipart/form-data" style="margin-top:16px"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="import_transfer_v132"><input type="hidden" name="return_page" value="data_transfer"><input class="input" type="file" name="transfer_file" accept=".json,application/json" required><button class="btn btn-primary" style="margin-top:10px">上传并导入 →</button></form></article></section>
<?php }

function v132_page_commission_hub(): void {
    $s=v13_owner_rows('service_commission_settings','select=mode,fixed_rate&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&limit=1');$setting=$s[0]??['mode'=>'fixed','fixed_rate'=>0];
    ?>
    <div class="page-head"><div><span class="eyebrow">COMMISSION MANAGEMENT</span><h1>抽成管理</h1><p>抽成这里只保留真正的抽成设置：业绩阶梯与员工月度抽成。员工业绩已经在左侧有独立入口，不重复放。</p></div></div>
    <section class="settings-entry-grid"><a class="settings-entry-card" href="index.php?page=commission_tiers"><div class="settings-entry-icon"><?=ui_icon('award')?></div><div><span>COMMISSION TIERS</span><h2>业绩抽成阶梯</h2><p>用按钮增加阶段，设定「多少业绩到多少业绩 → 多少 % 提成」。</p><small><?=e((string)($setting['mode']??'fixed'))?> · <?=number_format((float)($setting['fixed_rate']??0),2)?>%</small></div><strong>管理阶梯 →</strong></a><a class="settings-entry-card" href="index.php?page=commission_monthly"><div class="settings-entry-icon"><?=ui_icon('chart')?></div><div><span>MONTHLY COMMISSION</span><h2>员工月度业绩抽成</h2><p>看每位员工本月基础抽成，并可手动调整最终抽成 / Rate。</p></div><strong>查看与调整 →</strong></a></section>
    <?php
}
function v132_page_commission_monthly(): void {
    $month=preg_match('/^\d{4}-\d{2}$/',(string)($_GET['month']??''))?(string)$_GET['month']:date('Y-m');$start=$month.'-01';$end=date('Y-m-t',strtotime($start));
    $ledger=v13_owner_rows('employee_commission_ledger','select=employee_id,source_type,commission_amount,created_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&created_at=gte.'.rawurlencode($start.'T00:00:00Z').'&created_at=lte.'.rawurlencode($end.'T23:59:59Z').'&limit=5000');
    $employees=v13_employee_rows_owner();$sum=[];foreach($ledger as $l){$id=(string)$l['employee_id'];$sum[$id]['service']=($sum[$id]['service']??0)+(($l['source_type']??'')==='service'?(float)$l['commission_amount']:0);$sum[$id]['product']=($sum[$id]['product']??0)+(($l['source_type']??'')==='product'?(float)$l['commission_amount']:0);$sum[$id]['total']=($sum[$id]['total']??0)+(float)$l['commission_amount'];}
    $overrides=v13_owner_rows('v13_monthly_commission_overrides','select=employee_id,override_rate,final_commission_amount,notes,updated_at&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&month_start=eq.'.rawurlencode($start).'&limit=1000');$overrideMap=[];foreach($overrides as $o)$overrideMap[(string)$o['employee_id']]=$o;
    ?>
    <div class="page-head"><div><a class="back-link" href="index.php?page=commission">← 返回抽成管理</a><span class="eyebrow">MONTHLY COMMISSION</span><h1>员工月度业绩抽成</h1><p>基础抽成来自 Ledger；老板可以按员工按月份做最终调整，调整不会修改原始历史记录。</p></div><form><input type="hidden" name="page" value="commission_monthly"><input class="input" type="month" name="month" value="<?=e($month)?>" onchange="this.form.submit()"></form></div>
    <section class="card" style="overflow:auto"><table class="data-table"><thead><tr><th>员工</th><th>职位</th><th>服务抽成</th><th>产品抽成</th><th>基础总抽成</th><th>手动 Rate</th><th>最终抽成</th><th></th></tr></thead><tbody><?php foreach($employees as $e1):$id=(string)$e1['id'];$ov=$overrideMap[$id]??[];$base=(float)($sum[$id]['total']??0);$final=isset($ov['final_commission_amount'])&&$ov['final_commission_amount']!==null?(float)$ov['final_commission_amount']:$base;?><tr><td><strong><?=e((string)$e1['name'])?></strong></td><td><?=e((string)($e1['position']??''))?></td><td><?=money($sum[$id]['service']??0)?></td><td><?=money($sum[$id]['product']??0)?></td><td><?=money($base)?></td><td><?=isset($ov['override_rate'])&&$ov['override_rate']!==null?number_format((float)$ov['override_rate'],2).'%':'—'?></td><td><strong><?=money($final)?></strong><?php if(!empty($ov['notes'])):?><small style="display:block"><?=e((string)$ov['notes'])?></small><?php endif;?></td><td><button class="btn btn-light btn-small" type="button" data-v1350-modal-open="monthly-commission" data-employee_id="<?=e($id)?>" data-name="<?=e((string)$e1['name'])?>" data-month="<?=e($month)?>" data-override_rate="<?=e((string)($ov['override_rate']??''))?>" data-final_commission_amount="<?=e((string)($ov['final_commission_amount']??''))?>" data-notes="<?=e((string)($ov['notes']??''))?>">调整</button></td></tr><?php endforeach;?></tbody></table></section>
    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="monthly-commission"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">MONTHLY OVERRIDE</span><h3>调整员工月度抽成</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_monthly_commission_override_v1350"><input type="hidden" name="return_page" value="commission_monthly"><input type="hidden" name="employee_id" data-bind="employee_id"><input type="hidden" name="month" data-bind="month"><div class="field"><label>员工</label><input class="input" data-bind="name" readonly></div><div class="field"><label>手动抽成 Rate %（选填）</label><input class="input" type="number" min="0" max="100" step="0.01" name="override_rate" data-bind="override_rate" placeholder="例如 10"></div><div class="field"><label>最终抽成金额 RM（选填）</label><input class="input" type="number" min="0" step="0.01" name="final_commission_amount" data-bind="final_commission_amount" placeholder="留空 = 使用系统基础抽成"></div><div class="field"><label>调整说明</label><textarea class="textarea" name="notes" rows="3" data-bind="notes" placeholder="例如 本月特别奖励 / 手动修正"></textarea></div><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存调整</button></div></form></section></div>
<?php }
function v132_page_commission_tiers(): void {
    $settings=v13_owner_rows('service_commission_settings','select=organization_id,mode,fixed_rate&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&limit=1');$setting=$settings[0]??['mode'=>'tiered','fixed_rate'=>0];
    $tiers=v13_owner_rows('service_commission_tiers','select=id,tier_name,min_monthly_performance,max_monthly_performance,commission_rate,active&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&order=min_monthly_performance.asc&limit=200');
    ?>
    <div class="page-head"><div><a class="back-link" href="index.php?page=commission">← 返回抽成管理</a><span class="eyebrow">COMMISSION TIERS</span><h1>业绩抽成阶梯</h1><p>每个阶段都可以独立设置最低业绩、最高业绩和抽成比例。</p></div><button class="btn btn-primary" type="button" data-v1350-modal-open="commission-tier">＋ 增加阶段</button></div>
    <section class="card" style="padding:22px"><form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_commission_v13"><input type="hidden" name="return_page" value="commission_tiers"><div class="field"><label>模式</label><select class="select" name="mode"><option value="fixed" <?=($setting['mode']??'')==='fixed'?'selected':''?>>统一比例</option><option value="tiered" <?=($setting['mode']??'')==='tiered'?'selected':''?>>业绩阶梯</option></select></div><div class="field"><label>统一抽成 %（Fixed 模式）</label><input class="input" type="number" min="0" max="100" step="0.01" name="fixed_rate" value="<?=e((string)($setting['fixed_rate']??0))?>"></div><button class="btn btn-light">保存模式</button></form></section>
    <section class="v1350-tier-grid"><?php foreach($tiers as $t):?><article class="card v1350-tier-card"><div><span class="card-kicker"><?=e((string)$t['tier_name'])?></span><h3><?=money($t['min_monthly_performance']??0)?> → <?=isset($t['max_monthly_performance'])&&$t['max_monthly_performance']!==null?money($t['max_monthly_performance']):'以上'?></h3><strong><?=number_format((float)($t['commission_rate']??0),2)?>%</strong></div><div class="v1350-row-actions"><span class="badge <?=!empty($t['active'])?'badge-green':'badge-gray'?>"><?=!empty($t['active'])?'启用':'停用'?></span><button class="btn btn-light btn-small" type="button" data-v1350-modal-open="commission-tier" data-tier_id="<?=e((string)$t['id'])?>" data-tier_name="<?=e((string)$t['tier_name'])?>" data-min_performance="<?=e((string)($t['min_monthly_performance']??0))?>" data-max_performance="<?=e((string)($t['max_monthly_performance']??''))?>" data-commission_rate="<?=e((string)($t['commission_rate']??0))?>" data-active="<?=!empty($t['active'])?'1':'0'?>">修改</button></div></article><?php endforeach;?><?php if(!$tiers):?><section class="card empty-state"><h3>还没有抽成阶梯</h3><p>点击「增加阶段」。</p></section><?php endif;?></section>
    <div class="commission-modal" hidden aria-hidden="true" data-v1350-modal="commission-tier"><div class="commission-modal-backdrop" data-v1350-modal-close></div><section class="commission-modal-dialog v1350-small-modal"><div class="commission-modal-header"><div><span class="card-kicker">COMMISSION TIER</span><h3>增加 / 修改阶段</h3></div><button class="panel-close" type="button" data-v1350-modal-close><?=ui_icon('x')?></button></div><form method="post" class="commission-modal-content"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save_commission_tier_v1350"><input type="hidden" name="return_page" value="commission_tiers"><input type="hidden" name="tier_id" data-bind="tier_id"><div class="field"><label>阶段名称</label><input class="input" name="tier_name" data-bind="tier_name" placeholder="例如 Tier 1"></div><div class="field"><label>最低月业绩 RM</label><input class="input" type="number" min="0" step="0.01" name="min_performance" data-bind="min_performance" required></div><div class="field"><label>最高月业绩 RM</label><input class="input" type="number" min="0" step="0.01" name="max_performance" data-bind="max_performance" placeholder="留空 = 以上"></div><div class="field"><label>抽成 %</label><input class="input" type="number" min="0" max="100" step="0.01" name="commission_rate" data-bind="commission_rate" required></div><label class="confirm-checkbox"><input type="checkbox" name="active" value="1" data-bind="active" checked><span>启用阶段</span></label><div class="form-actions"><button class="btn btn-light" type="button" data-v1350-modal-close>取消</button><button class="btn btn-primary">保存阶段</button></div></form></section></div>
<?php }

function v1361047_employee_attendance_monthly(string $employeeId,int $year): array {
    $months=[];
    for($m=1;$m<=12;$m++)$months[$m]=['clock_ins'=>0,'completed'=>0,'late'=>0];
    if(!v13_is_owner() || $employeeId==='') return ['year'=>$year,'months'=>$months,'total_clock_ins'=>0,'total_completed'=>0,'total_late'=>0];
    $start=sprintf('%04d-01-01',$year); $end=sprintf('%04d-12-31',$year);
    try{
        $rows=v13_owner_rows('employee_attendance_days','select=work_date,clock_in_at,clock_out_at,arrival_status&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&store_id=eq.'.rawurlencode(v13_store_uuid()).'&employee_id=eq.'.rawurlencode($employeeId).'&work_date=gte.'.rawurlencode($start).'&work_date=lte.'.rawurlencode($end).'&order=work_date.asc&limit=500');
    }catch(Throwable $e){$rows=[];}
    $totalIn=0;$totalOut=0;$totalLate=0;
    foreach($rows as $row){
        $date=(string)($row['work_date']??''); if(!preg_match('/^\\d{4}-(\\d{2})-\\d{2}$/',$date,$mm))continue;
        $m=(int)$mm[1]; if($m<1||$m>12)continue;
        if(!empty($row['clock_in_at'])){$months[$m]['clock_ins']++;$totalIn++;}
        if(!empty($row['clock_out_at'])){$months[$m]['completed']++;$totalOut++;}
        if((string)($row['arrival_status']??'')==='late'){$months[$m]['late']++;$totalLate++;}
    }
    return ['year'=>$year,'months'=>$months,'total_clock_ins'=>$totalIn,'total_completed'=>$totalOut,'total_late'=>$totalLate];
}

function v132_page_performance_employee(): void {
    $id=trim((string)($_GET['id']??''));if($id===''){echo '<section class="card empty-state"><h3>请选择员工</h3></section>';return;}
    $data=v1354_performance_payload($id);$d=is_array($data['detail']??null)?$data['detail']:null;$activity=is_array($data['activity']??null)?$data['activity']:[];
    if(!$d){echo '<section class="card empty-state"><h3>找不到员工或这个员工不属于当前分行</h3></section>';return;}
    $attendanceYear=(int)substr((string)($data['anchor']??date('Y-m-d')),0,4); if($attendanceYear<2000||$attendanceYear>2100)$attendanceYear=(int)date('Y');
    $attendance=v1361047_employee_attendance_monthly($id,$attendanceYear);
    ?>
    <div class="page-head responsive-page-head"><div><a class="back-link" href="index.php?<?=e(http_build_query(['page'=>'performance','period'=>$data['period']??'month','anchor'=>$data['anchor']??date('Y-m-d')]))?>">← 返回排行榜</a><span class="eyebrow">EMPLOYEE PERFORMANCE DETAIL</span><div class="v1354-detail-person"><?=v1354_avatar_html($d,'v1354-detail-avatar')?><div><h1><?=e((string)$d['name'])?></h1><p>#<?=intval($d['rank']??0)?> · <?=e((string)($d['position']??''))?> · <?=e((string)($data['label']??''))?></p></div></div></div><?php v1354_performance_filter_html('performance_employee',$id);?></div>
    <section class="stats v1354-performance-stats"><div class="stat"><span>总业绩</span><strong><?=money($d['total_performance']??0)?></strong><small>服务 + 产品</small></div><div class="stat"><span>服务业绩</span><strong><?=money($d['service_performance']??0)?></strong><small><?=intval($d['service_count']??0)?> 个服务贡献记录</small></div><div class="stat"><span>产品销售</span><strong><?=money($d['product_sales']??0)?></strong><small><?=number_format((float)($d['product_units']??0),0)?> 件</small></div><div class="stat"><span>预计抽成</span><strong><?=money($d['commission_amount']??0)?></strong></div><div class="stat"><span>服务顾客</span><strong><?=intval($d['customer_count']??0)?></strong></div><div class="stat"><span>预约</span><strong><?=intval($d['appointments']??0)?></strong></div><div class="stat"><span>Walk-in</span><strong><?=intval($d['walkins']??0)?></strong></div><div class="stat"><span>当前排名</span><strong>#<?=intval($d['rank']??0)?></strong></div></section>
    <?php if(v13_is_owner()):?>
    <section class="card v1361047-attendance-history"><div class="card-head"><div><span class="card-kicker">MONTHLY ATTENDANCE · <?=intval($attendance['year'])?></span><h3>每月出勤</h3><p>每个月实际扫描上班二维码的次数。迟到与完成下班打卡也会一起统计。</p></div><div class="v1361047-attendance-summary"><span><small>本年签到</small><strong><?=intval($attendance['total_clock_ins']??0)?></strong></span><span><small>完成班次</small><strong><?=intval($attendance['total_completed']??0)?></strong></span><span><small>本年迟到</small><strong><?=intval($attendance['total_late']??0)?></strong></span></div></div><div class="v1361047-attendance-months"><?php foreach(($attendance['months']??[]) as $month=>$m):?><article class="v1361047-attendance-month <?=intval($m['clock_ins']??0)>0?'has-attendance':''?>"><span><?=str_pad((string)$month,2,'0',STR_PAD_LEFT)?> 月</span><strong><?=intval($m['clock_ins']??0)?> 次</strong><small>完成 <?=intval($m['completed']??0)?> · 迟到 <?=intval($m['late']??0)?></small></article><?php endforeach;?></div></section>
    <?php endif;?>
    <section class="card v1354-performance-activity"><div class="card-head"><div><span class="card-kicker">PERFORMANCE ACTIVITY</span><h3>期间明细</h3><p>点击期间筛选可以查看这一天、这个月或这一整年的数据。</p></div></div><div class="v1354-activity-list"><?php foreach($activity as $a):?><div class="v1354-activity-row"><div><span class="badge <?=($a['type']??'')==='product'?'badge-gold':'badge-green'?>"><?=($a['type']??'')==='product'?'产品':'服务'?></span><strong><?=e((string)($a['label']??''))?></strong><small><?=!empty($a['occurred_at'])?e(app_date((string)$a['occurred_at'],true)):''?></small></div><b><?=money($a['amount']??0)?></b></div><?php endforeach;?><?php if(!$activity):?><div class="empty">这个期间没有明细。</div><?php endif;?></div></section>
    <?php
}

function v132_page_training_course(): void {
    $id=trim((string)($_GET['id']??''));if($id===''){echo '<section class="card empty-state"><h3>找不到课程</h3></section>';return;}
    if(v13_is_owner()){$rows=v13_owner_rows('v13_training_courses','select=*&id=eq.'.rawurlencode($id).'&organization_id=eq.'.rawurlencode(v13_org_uuid()).'&limit=1');$c=$rows[0]??null;}else{$courses=v13_employee_api('training');$c=null;foreach($courses as $x)if((string)($x['id']??'')===$id)$c=$x;}
    if(!$c){echo '<section class="card empty-state"><h3>找不到课程或你的职位不适用</h3></section>';return;}
    $url=trim((string)($c['content_url']??''));$cover=trim((string)($c['cover_image_path']??''));
    ?>
    <div class="page-head"><div><a class="back-link" href="index.php?page=training">← 返回培训中心</a><span class="eyebrow"><?=e((string)($c['category']??'TRAINING'))?></span><h1><?=e((string)$c['title'])?></h1><p><?=e((string)($c['description']??''))?></p></div><div class="hero-actions"><?php if(!empty($c['required'])):?><span class="badge badge-gold">Required</span><?php endif;?><?php if(!empty($c['estimated_minutes'])):?><span class="badge badge-gray"><?=intval($c['estimated_minutes'])?> min</span><?php endif;?></div></div>
    <section class="card v1350-training-reader">
      <?php if($cover!==''):?><img class="v1350-training-cover" src="<?=e($cover)?>" alt="<?=e((string)$c['title'])?>"><?php endif;?>
      <?php if($url!==''):?><div class="v1350-training-media"><a class="btn btn-light" href="<?=e($url)?>" target="_blank" rel="noopener">打开培训视频 / 媒体 →</a></div><?php endif;?>
      <div class="lesson-content"><?=nl2br(e((string)($c['content']??'暂无课程内容。')))?> </div>
      <?php if(!v13_is_owner()):?><form method="post" style="margin-top:22px"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="employee_training_v13"><input type="hidden" name="course_id" value="<?=e($id)?>"><input type="hidden" name="return_page" value="training_course"><div class="field"><label>完成进度</label><input class="input" type="range" min="0" max="100" name="progress_percent" value="<?=intval($c['progress_percent']??0)?>"></div><button class="btn btn-primary">保存进度 <?=intval($c['progress_percent']??0)?>%</button></form><?php endif;?>
    </section>
<?php }

function v132_render_page(string $page): bool {
    return match($page){
      'stock_hub'=>(v132_page_stock_hub()??true),'inventory'=>(v132_page_inventory()??true),'products','product_items'=>(v132_page_products()??true),'product_bundles'=>(v132_page_product_bundles()??true),'product_showcase'=>(v132_page_product_showcase()??true),
      'settings'=>(v132_page_settings_hub()??true),'settings_general'=>(v132_page_settings_general()??true),'settings_roles'=>(v132_page_settings_roles()??true),'settings_whatsapp'=>(v132_page_settings_whatsapp()??true),'settings_marketing'=>(v1360_page_settings_marketing()??true),'marketing_analytics'=>(v13611_page_marketing_analytics()??true),'data_import'=>(v132_page_data_import()??true),'data_transfer'=>(v132_page_data_transfer()??true),
      'commission'=>(v132_page_commission_hub()??true),'commission_monthly'=>(v132_page_commission_monthly()??true),'commission_tiers'=>(v132_page_commission_tiers()??true),'performance_employee'=>(v132_page_performance_employee()??true),'training_course'=>(v132_page_training_course()??true),'confirm'=>(v1331_page_confirm((string)($_GET['id']??''))??true),
      default=>false,
    };
}
