<?php
declare(strict_types=1);
require_once __DIR__ . '/supabase_auth.php';

function v13_auth_password(string $email, string $password): array {
    return salonos_supabase_request('auth/v1/token?grant_type=password','', 'POST', [
        'email'=>strtolower(trim($email)),
        'password'=>$password,
    ]);
}

function v13_auth_signup(string $email,string $password,array $data=[]): array {
    return salonos_supabase_request('auth/v1/signup','', 'POST', [
        'email'=>strtolower(trim($email)),
        'password'=>$password,
        'data'=>$data,
    ]);
}

function v13_access_token_from_auth(array $auth): string {
    return trim((string)($auth['access_token'] ?? $auth['session']['access_token'] ?? ''));
}

function v13_refresh_token_from_auth(array $auth): string {
    return trim((string)($auth['refresh_token'] ?? $auth['session']['refresh_token'] ?? ''));
}

function v13_jwt_exp(string $token): int {
    $parts=explode('.',$token);
    if(count($parts)<2)return 0;
    $raw=strtr($parts[1],'-_','+/');
    $raw.=str_repeat('=',(4-strlen($raw)%4)%4);
    $json=base64_decode($raw,true);
    if($json===false)return 0;
    $payload=json_decode($json,true);
    return is_array($payload)?(int)($payload['exp']??0):0;
}

function v13_creator_token(): string {
    $token=trim((string)($_SESSION['v13_creator_access_token']??''));
    $refresh=trim((string)($_SESSION['v13_creator_refresh_token']??''));
    if($token==='' || (v13_jwt_exp($token)>0 && v13_jwt_exp($token)<time()+90)){
        if($refresh==='')return '';
        try{
            $auth=salonos_supabase_request('auth/v1/token?grant_type=refresh_token','', 'POST',['refresh_token'=>$refresh]);
            $token=v13_access_token_from_auth($auth);
            $refreshNew=v13_refresh_token_from_auth($auth);
            if($token!=='')$_SESSION['v13_creator_access_token']=$token;
            if($refreshNew!=='')$_SESSION['v13_creator_refresh_token']=$refreshNew;
        }catch(Throwable $e){
            unset($_SESSION['v13_creator_access_token'],$_SESSION['v13_creator_refresh_token'],$_SESSION['v13_creator_user']);
            return '';
        }
    }
    return $token;
}

function v13_rpc(string $name,array $args,string $token): mixed {
    return salonos_supabase_request('rest/v1/rpc/'.rawurlencode($name),$token,'POST',$args,['Prefer: return=representation']);
}

function v13_creator_verify(string $token): array {
    $auth=salonos_supabase_request('auth/v1/user',$token);
    $uid=trim((string)($auth['id']??''));
    if($uid==='')throw new RuntimeException('Creator Supabase Session 无效。');
    $rows=salonos_supabase_rest_rows('creator_admins','select=user_id,display_name,status&user_id=eq.'.rawurlencode($uid).'&status=eq.active&limit=1',$token);
    if(!$rows)throw new RuntimeException('这个 Supabase 账号不是 active Creator Admin。');
    return [
        'id'=>$uid,
        'email'=>(string)($auth['email']??''),
        'name'=>(string)($rows[0]['display_name']??'SalonOS Creator'),
    ];
}

function v13_creator_snapshot(string $token): array {
    $data=v13_rpc('creator_dashboard_snapshot',[],$token);
    return is_array($data)?$data:[];
}

function v13_first_rpc_row(mixed $data): array {
    if(is_array($data) && array_is_list($data))return is_array($data[0]??null)?$data[0]:[];
    return is_array($data)?$data:[];
}
