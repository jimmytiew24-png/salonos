<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
$root=__DIR__;
$version=trim((string)@file_get_contents($root.'/VERSION')) ?: 'dev';
$extensions=['php','js','css','json','webmanifest','md'];
$files=[];
$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
foreach($it as $file){
    if(!$file->isFile())continue;
    $path=$file->getPathname();
    $rel=str_replace('\\','/',substr($path,strlen($root)+1));
    if(str_starts_with($rel,'storage/')||str_starts_with($rel,'migration_backups/'))continue;
    $ext=strtolower(pathinfo($rel,PATHINFO_EXTENSION));
    if(!in_array($ext,$extensions,true)&&basename($rel)!=='VERSION')continue;
    $files[]=$rel.'|'.$file->getMTime().'|'.$file->getSize();
}
sort($files,SORT_STRING);
$fingerprint=substr(hash('sha256',implode("\n",$files)),0,20);
echo json_encode(['version'=>$version,'fingerprint'=>$fingerprint,'generated_at'=>date(DATE_ATOM)],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
