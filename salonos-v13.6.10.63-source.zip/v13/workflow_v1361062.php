<?php
declare(strict_types=1);

function v1361062_is_uuid(mixed $value): bool {
    return is_string($value) && preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i',$value)===1;
}
function v1361062_required_uuid(mixed $value): string {
    if(!v1361062_is_uuid($value))throw new RuntimeException('资料编号无效，请返回列表重新选择。');
    return $value;
}
function v1361062_draft_key(): string {
    return 'salonos.v1340.visit.'.preg_replace('/[^a-zA-Z0-9_-]/','',(string)(user()['id']??'user')).'.new';
}
function v1361062_workflow_rpc(string $name,array $arguments=[]): array {
    $token=v13_owner_token_required_all();
    try {
        return v13_rpc_json($name,['p_store_id'=>v13_store_uuid()]+$arguments,$token);
    } catch(Throwable $err) {
        if(v136_rpc_signature_mismatch($err,$name))throw new RuntimeException('当前版本的订单流程数据库更新尚未安装，请联系系统管理员。',0,$err);
        throw $err;
    }
}
function v1361062_receipt_url(string $visitId): string {
    return 'index.php?page=receipt&visit_id='.rawurlencode($visitId);
}
function v1361062_myt(string $value,string $format='d/m/Y H:i'): string {
    if($value==='')return '—';
    try{return (new DateTimeImmutable($value))->setTimezone(new DateTimeZone('Asia/Kuala_Lumpur'))->format($format);}
    catch(Throwable $e){return '—';}
}

function v1361062_page_receipt(): void {
    $visit=v1361062_required_uuid($_GET['visit_id']??null);
    $receipt=v1361062_workflow_rpc('v1361062_receipt_for_visit',['p_visit_id'=>$visit]);
    $refund=is_array($receipt['refund']??null)?$receipt['refund']:null;
    $status=(string)($receipt['status']??'');
    ?>
    <div class="page-head responsive-page-head"><div><a class="back-link" href="index.php?page=order_history">← 返回订单记录</a><h1>收据与退款</h1><p>从原收据查看付款，并登记全额退款。</p></div></div>
    <?php if(!$receipt):?><section class="card card-body"><h2>没有可查看的收据</h2><p>请确认订单已结账并属于当前分行。</p></section><?php return;endif;?>
    <section class="card"><div class="card-body">
        <h2><?=e((string)$receipt['receipt'])?></h2>
        <p>原收据 <?=money($receipt['total']??0)?> · 会员钱包 <?=money($receipt['wallet']??0)?> · 外部付款 <?=money($receipt['external']??0)?></p>
        <p><?=e(match($status){'paid'=>'已收款','refunded'=>'已退款','voided'=>'已作废',default=>'状态未知'})?></p>
        <?php $receiptLines=array_merge((array)($receipt['services']??[]),(array)($receipt['products']??[])); if($receiptLines):?>
            <div class="history-table-scroll"><table class="data-table"><thead><tr><th>原单项目</th><th>数量</th><th>金额</th></tr></thead><tbody>
                <?php foreach($receiptLines as $line):?><tr><td><?=e((string)($line['label']??''))?><?=!empty($line['returned'])?' · 已退货':''?></td><td><?=intval($line['quantity']??0)?></td><td><?=money($line['amount']??0)?></td></tr><?php endforeach;?>
            </tbody></table></div>
        <?php endif;?>
        <?php if($refund): $breakdown=(array)($refund['breakdown']??[]);?>
            <h3>退款记录</h3><p><?=e(v1361062_myt((string)($refund['created_at']??'')))?> · <?=money($refund['total']??0)?></p>
            <p>原因：<?=e((string)($refund['reason']??''))?></p>
            <?php if(!empty($refund['external_reference'])):?><p>外部退款凭证：<?=e((string)$refund['external_reference'])?></p><?php endif;?>
            <p>库存回补 <?=intval($breakdown['stock_rows']??0)?> 条 · 会员钱包 <?=intval($breakdown['wallet_rows']??0)?> 条 · 积分/经验 <?=intval($breakdown['loyalty_rows']??0)?> 条</p>
            <p>排除原单业绩 <?=money($breakdown['performance_amount']??0)?> · 抽成冲销 <?=money($breakdown['commission_amount']??0)?></p>
        <?php elseif($status==='paid'):?>
            <form method="post" class="form-grid">
                <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                <input type="hidden" name="action" value="refund_receipt_v1361062">
                <input type="hidden" name="visit_id" value="<?=e($visit)?>">
                <input type="hidden" name="payment_id" value="<?=e((string)$receipt['payment_id'])?>">
                <div class="field"><label for="refund-reason">退款原因</label><textarea id="refund-reason" class="textarea" name="reason" required minlength="3" maxlength="500" rows="3"></textarea></div>
                <?php if((float)($receipt['external']??0)>0):?>
                    <div class="field"><label for="refund-reference">外部退款凭证</label><input id="refund-reference" class="input" name="external_reference" maxlength="150" placeholder="柜台记录号或支付平台退款编号" required></div>
                    <label class="confirm-checkbox"><input type="checkbox" name="external_confirmed" value="1" required><span>已通过原付款方式退回 <?=money($receipt['external'])?>。SalonOS 只登记这笔外部退款。</span></label>
                <?php endif;?>
                <label class="confirm-checkbox"><input type="checkbox" name="stock_return_confirmed" value="1" required><span>确认整单退款；如有扣库商品，已收到全部退回商品。已发放的抽成请在下一期对账。</span></label>
                <div class="form-actions"><button class="btn btn-danger-soft" type="submit">登记全额退款</button></div>
            </form>
        <?php endif;?>
    </div></section>
    <?php
}

function v1361062_review_form(string $kind,string $id): void {
    $wa=$kind==='wa_manual';
    ?>
    <form method="post" class="form-grid">
        <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
        <input type="hidden" name="action" value="review_operation_v1361062">
        <input type="hidden" name="kind" value="<?=e($kind)?>">
        <input type="hidden" name="subject_id" value="<?=e($id)?>">
        <label class="field"><span>处理备注</span><input class="input" name="note" minlength="3" maxlength="500" required placeholder="<?=$wa?'例如：由柜台通过门店号码跟进':'例如：已确认是测试单，待主管取消'?>"></label>
        <?php if($wa):?><label class="confirm-checkbox"><input type="checkbox" name="pause_ai" value="1"><span>同时暂停该对话的 AI 自动回复</span></label><?php endif;?>
        <div class="form-actions"><button class="btn btn-light btn-small" type="submit"><?=$wa?'人工接手并跳过旧任务':'记录已核查'?></button></div>
    </form>
    <?php
}

function v1361062_page_operations(): void {
    $result=v1361062_workflow_rpc('v1361062_operations');
    $orders=(array)($result['orders']??[]);$messages=(array)($result['messages']??[]);
    ?>
    <div class="page-head responsive-page-head"><div><a class="back-link" href="index.php?page=order_history">← 返回订单记录</a><h1>待处理事项</h1><p>处理逾期订单和旧消息。核查记录不会结账，也不会自动发送 WhatsApp。</p></div></div>
    <section class="card"><div class="card-head"><div><h2>超过 7 天未关闭的订单</h2><p>打开对应日期的看板处理，或先记录核查结果。</p></div></div>
        <div class="card-body">
        <?php if(!$orders):?><p>没有需要核查的逾期订单。</p><?php endif;?>
        <?php foreach($orders as $o): $at=(string)($o['order_at']??'');$date=v1361062_myt($at,'Y-m-d');?>
            <details><summary><?=e((string)($o['visit_number']??'订单'))?> · <?=e(v13_status_label((string)($o['status']??'')))?> · <?=e(v1361062_myt($at))?><?=!empty($o['reviewed_at'])?' · 已核查':''?></summary>
                <p><a class="btn btn-light btn-small" href="index.php?page=orders&amp;board_date=<?=e($date)?>">打开当天看板</a></p>
                <?php if(!empty($o['reviewed_at'])):?><p><?=e((string)$o['review_note'])?> · <?=e(v1361062_myt((string)$o['reviewed_at']))?></p><?php else:v1361062_review_form('order_review',(string)$o['id']);endif;?>
            </details>
        <?php endforeach;?>
        </div>
    </section>
    <section class="card"><div class="card-head"><div><h2>WhatsApp 失败或积压任务</h2><p>接手后，旧任务会被跳过。请用门店号码人工跟进；不要补发过期预约消息。</p></div></div>
        <div class="card-body">
        <?php if(!$messages):?><p>没有失败或积压任务。</p><?php endif;?>
        <?php foreach($messages as $m):?>
            <details><summary><?=e((string)($m['error_group']??'待核查'))?> · <?=e(v1361062_myt((string)($m['created_at']??'')))?> · <?=!empty($m['reviewed_at'])?'已接手':e((string)($m['status']??''))?></summary>
                <p>顾客 WhatsApp：<?=e((string)($m['customer_phone']??'无'))?> · 尝试 <?=intval($m['attempts']??0)?> 次</p>
                <?php if(!empty($m['reviewed_at'])):?><p><?=e((string)$m['review_note'])?> · <?=e(v1361062_myt((string)$m['reviewed_at']))?></p><?php else:v1361062_review_form('wa_manual',(string)$m['id']);endif;?>
                <?php if(!empty($m['can_resume'])&&!empty($m['conversation_id'])):?>
                    <form method="post">
                        <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                        <input type="hidden" name="action" value="resume_conversation_v1361062">
                        <input type="hidden" name="conversation_id" value="<?=e((string)$m['conversation_id'])?>">
                        <button class="btn btn-light btn-small" type="submit">恢复新消息自动回复</button>
                    </form>
                <?php endif;?>
            </details>
        <?php endforeach;?>
        </div>
    </section>
    <?php
}
